"""
SEC EDGAR fundamentals provider.

Why EDGAR: it's the primary source — audited figures straight from the companies' own 10-K/10-Q
filings — it's free, and it requires no API key or paid plan (which matters given the project
constraint of not adding paid data vendors). Endpoints and response shapes below were verified
against SEC's live API and documentation, not assumed:

  ticker -> CIK map : https://www.sec.gov/files/company_tickers.json
                      {"0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."}, ...}
  company facts     : https://data.sec.gov/api/xbrl/companyfacts/CIK##########.json
                      root -> facts -> us-gaap -> {TAG} -> units -> {UNIT} -> [ {start,end,val,
                      accn,fy,fp,form,filed,frame}, ... ]
  submissions       : https://data.sec.gov/submissions/CIK##########.json
                      recent filings in columnar arrays (form[], filingDate[], reportDate[])

SEC requires a descriptive User-Agent with contact info for programmatic access and asks for
<= 10 requests/second; both are honored here (see SEC_USER_AGENT and the fact that this
provider is called at most once per ticker per cache-TTL, not per page load).
"""
import json
import statistics
from datetime import datetime, timedelta, timezone

import requests

from providers.base import DataStatus, ProviderError
from providers.edgar_concepts import (DEFAULT_PERIOD_TOLERANCE_DAYS, HISTORY_VALUE_FIELDS,
                                      TAXONOMIES, TAXONOMY_ANCHOR, UNIT_CURRENCY,
                                      UNIT_PER_SHARE, UNIT_SHARES, is_duration,
                                      period_tolerance, tags_for, unit_kind)
from providers.fundamentals_base import (AnnualPeriod, EarningsInfo, FundamentalDataProvider,
                                         Fundamentals)

SEC_TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"
SEC_FACTS_URL = "https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json"
SEC_SUBMISSIONS_URL = "https://data.sec.gov/submissions/CIK{cik:010d}.json"

# SEC's fair-access policy requires a real contact address in the User-Agent.
SEC_USER_AGENT = "SwingSignalApp/1.0 (personal swing-trading research; nickberry123@icloud.com)"

# The concept -> namespace -> tag chains now live in providers/edgar_concepts.py, alongside the
# unit-kind and duration metadata that has to travel with them. See that file for why the
# namespace and the currency are treated as data rather than as assumptions.
ANNUAL_FORMS = ("10-K", "20-F", "40-F")

# Bounds on how much history is extracted per company. A 10-K carries two to three years of
# comparatives, so twenty years of filings can produce a lot of (period, vintage) pairs. These
# caps keep a refresh predictable in time and in database transfer — the Neon allowance is a
# finite monthly budget, and an unbounded history walk is exactly how the last one was spent.
MAX_HISTORY_PERIODS = 12          # fiscal years retained, newest first
MAX_VINTAGES_PER_PERIOD = 4       # versions of one fiscal year (original + restatements)

def _pct(numerator, denominator):
    if numerator is None or not denominator:
        return None
    return round(numerator / denominator * 100, 4)


def _growth(latest, prior):
    if latest is None or prior in (None, 0):
        return None
    return round((latest - prior) / abs(prior) * 100, 4)


class SecEdgarProvider(FundamentalDataProvider):
    name = "sec-edgar"

    def __init__(self, timeout: float = 20.0, user_agent: str = SEC_USER_AGENT):
        self.timeout = timeout
        self.user_agent = user_agent
        self._ticker_map = None  # lazily fetched ticker -> CIK, cached per process

    # ---------- HTTP ----------

    def _get(self, url: str) -> dict:
        try:
            resp = requests.get(
                url,
                headers={"User-Agent": self.user_agent, "Accept": "application/json"},
                timeout=self.timeout,
            )
        except requests.RequestException as e:
            raise ProviderError(f"Network error contacting SEC EDGAR: {e}", DataStatus.UNAVAILABLE)

        if resp.status_code == 403:
            raise ProviderError(
                "SEC EDGAR rejected the request (403) — this usually means the User-Agent is "
                "missing/blocked or the fair-access rate limit was exceeded.",
                DataStatus.UNAVAILABLE,
            )
        if resp.status_code == 404:
            raise ProviderError("SEC EDGAR has no record at that URL (404).", DataStatus.UNAVAILABLE)
        if resp.status_code != 200:
            raise ProviderError(f"SEC EDGAR returned HTTP {resp.status_code}.", DataStatus.UNAVAILABLE)
        try:
            return resp.json()
        except ValueError as e:
            raise ProviderError(f"SEC EDGAR returned non-JSON content: {e}", DataStatus.UNAVAILABLE)

    # ---------- ticker -> CIK ----------

    def get_cik(self, ticker: str) -> int:
        """Resolved from SEC's own published mapping rather than a hard-coded table, so a wrong
        or stale CIK can't silently attach one company's financials to another's ticker."""
        if self._ticker_map is None:
            raw = self._get(SEC_TICKERS_URL)
            mapping = {}
            # The file is keyed by row index: {"0": {"cik_str":..., "ticker":..., "title":...}}
            rows = raw.values() if isinstance(raw, dict) else raw
            for row in rows:
                if not isinstance(row, dict):
                    continue
                t, cik = row.get("ticker"), row.get("cik_str")
                if t and cik is not None:
                    mapping[str(t).upper()] = int(cik)
            self._ticker_map = mapping

        t = ticker.upper()
        # Class-share tickers differ between vendors: Alpaca uses "BRK.B", SEC uses "BRK-B".
        for candidate in (t, t.replace(".", "-"), t.replace("-", ".")):
            if candidate in self._ticker_map:
                return self._ticker_map[candidate]
        raise ProviderError(f"No SEC CIK found for ticker {ticker}.", DataStatus.UNAVAILABLE)

    # ---------- fact extraction ----------

    @staticmethod
    def _select_unit(units: dict, kind: str):
        """Pick the unit block for a concept, and SAY WHICH ONE WAS PICKED.

        The old rule was "USD, else USD/shares, else whatever unit comes out of the dict first".
        For a US filer that is correct by luck. For a company reporting in euros it is a coin
        toss that silently decides the currency of every figure downstream — and a euro revenue
        against a dollar share price yields a price/earnings ratio that is wrong by the exchange
        rate and looks completely ordinary.

        Now the kind of unit is declared per concept, so a share count can never be read out of
        a dollar block and a per-share figure can never be read out of a total. When nothing
        matching exists the answer is None, not a substitute.
        """
        if not units:
            return None, None
        if kind == UNIT_PER_SHARE:
            if "USD/shares" in units:
                return units["USD/shares"], "USD/shares"
            per_share = sorted(k for k in units if k.endswith("/shares"))
            return (units[per_share[0]], per_share[0]) if per_share else (None, None)
        if kind == UNIT_SHARES:
            return (units["shares"], "shares") if "shares" in units else (None, None)
        # Currency. USD wins outright when present; otherwise take the ISO-looking code with the
        # most entries, choosing alphabetically on a tie so the result is deterministic rather
        # than dependent on dict ordering.
        if "USD" in units:
            return units["USD"], "USD"
        codes = [k for k in units if len(k) == 3 and k.isalpha() and k.isupper()]
        if not codes:
            return None, None
        best = min(codes, key=lambda k: (-len(units[k] or []), k))
        return units[best], best

    @classmethod
    def _annual_facts(cls, facts: dict, tag: str, namespace: str = "us-gaap",
                      kind: str = UNIT_CURRENCY, dedupe: bool = True) -> list:
        """Annual facts for ONE tag in ONE namespace, newest period first.

        `dedupe=True` collapses every version of a fiscal period to the latest-filed one, which
        is what the current-snapshot path wants. `dedupe=False` keeps every version, which is
        what the point-in-time history path needs — a restatement filed in 2026 must not be
        usable when scoring 2023, and that is only possible if both versions still exist.

        Each returned entry is a shallow copy carrying `_unit` and `_ns`, so the currency and the
        accounting standard travel with the number instead of being re-derived (or assumed)
        later.
        """
        node = (facts.get(namespace) or {}).get(tag)
        if not node:
            return []
        entries, unit = cls._select_unit(node.get("units") or {}, kind)
        if not entries:
            return []

        annual = []
        for e in entries:
            if e.get("form") not in ANNUAL_FORMS:
                continue
            end = e.get("end")
            if not end:
                continue
            start = e.get("start")
            if start:
                # Duration fact: keep only ~full-year periods so a Q4 figure is never mistaken
                # for a full fiscal year.
                try:
                    days = (datetime.fromisoformat(end) - datetime.fromisoformat(start)).days
                except (TypeError, ValueError):
                    continue
                if days < 300 or days > 400:
                    continue
            annual.append({**e, "_unit": unit, "_ns": namespace})

        if not dedupe:
            return sorted(annual, key=lambda x: (x["end"], x.get("filed") or ""), reverse=True)

        by_end = {}
        for e in annual:
            end = e["end"]
            prev = by_end.get(end)
            if prev is None or (e.get("filed") or "") > (prev.get("filed") or ""):
                by_end[end] = e
        return sorted(by_end.values(), key=lambda x: x["end"], reverse=True)

    @classmethod
    def _merged_annual_facts(cls, facts: dict, concept: str, taxonomy: str = "us-gaap",
                             dedupe: bool = True) -> list:
        """Merge annual facts across EVERY tag in a concept's fallback chain, newest first.

        Companies migrate between tags over time — NVIDIA, for example, reported
        `RevenueFromContractWithCustomerExcludingAssessedTax` only through FY2022 and has used
        `Revenues` ever since. Taking the first tag that has *any* data would therefore return
        2022 figures in 2026. Merging across the chain and sorting by period end fixes that.

        Where two tags report the same period AT THE SAME VINTAGE, the higher-priority tag
        (earlier in the chain) wins — but only for that period, so it can never drag the whole
        result back in time. When `dedupe` is False the vintage is part of the key, so the
        original and restated versions of a year both survive.
        """
        best = {}
        for priority, (namespace, tag) in enumerate(tags_for(concept, taxonomy)):
            for entry in cls._annual_facts(facts, tag, namespace=namespace,
                                           kind=unit_kind(concept), dedupe=dedupe):
                key = entry["end"] if dedupe else (entry["end"], entry.get("filed") or "")
                current = best.get(key)
                if current is None or priority < current[0]:
                    # `_priority` travels with the fact because closeness to the period end is
                    # NOT the only thing that should decide between two tags for the same
                    # concept. A cover-page share count is legitimately dated weeks after the
                    # year end, so a lower-priority tag sitting exactly on the year end would
                    # win on distance alone and quietly override the preferred source.
                    best[key] = (priority, {**entry, "_priority": priority})
        return [e for _, e in sorted(best.values(),
                                     key=lambda x: (x[1]["end"], x[1].get("filed") or ""),
                                     reverse=True)]

    @classmethod
    def detect_taxonomy(cls, facts: dict) -> str:
        """Decide ONCE which XBRL namespace a company's figures are read from.

        NOT the accounting standard, and the distinction cost me a wrong label once already:
        ASML files a 20-F under IFRS but tags its EDGAR data with us-gaap element names in
        euros, so this correctly returns "us-gaap" for a company that does not use US-GAAP.
        The namespace is a fact about the data; the accounting standard is an inference, and
        this app does not make it.

        Chosen by which namespace reports more annual revenue periods, because every operating
        company reports revenue under either standard, so coverage of that one concept is a
        reliable read on the taxonomy.

        The decision is made once and then applies to every concept, which is the point:
        resolving each concept independently could take revenue from us-gaap and equity from
        ifrs-full for the same company, producing a return-on-equity that belongs to no
        accounting standard at all. Ties and empty data fall back to us-gaap, which preserves the
        existing behaviour exactly for every US filer.
        """
        best, best_n = TAXONOMIES[0], 0
        for taxonomy in TAXONOMIES:
            n = len(cls._merged_annual_facts(facts, TAXONOMY_ANCHOR, taxonomy))
            if n > best_n:
                best, best_n = taxonomy, n
        return best

    @staticmethod
    def _within(entry_end: str, anchor: datetime, window: tuple):
        """Signed distance from the period end, if the fact falls inside the window.

        The window is (days_before, days_after) and is ASYMMETRIC for a reason — see
        CONCEPT_PERIOD_TOLERANCE_DAYS. A cover-page share count is always dated after the year it
        accompanies, so a symmetric window either misses it or has to be widened in both
        directions, and widening backwards is what lets one year's figure attach to another.
        """
        try:
            gap = (datetime.fromisoformat(entry_end) - anchor).days
        except (TypeError, ValueError):
            return None
        before, after = window
        if gap < -before or gap > after:
            return None
        return abs(gap)

    @classmethod
    def _pick_for_period(cls, entries: list, anchor_end: str,
                         window: tuple = DEFAULT_PERIOD_TOLERANCE_DAYS):
        """Return the fact whose period end is closest to `anchor_end`, within the window.

        Fiscal year ends drift by a few days year to year (NVIDIA's FY2025 ended 2025-01-26,
        FY2024 ended 2024-01-28), so an exact string match would miss legitimate alignments.
        Returns None when nothing lands in the window — which is the correct answer, because
        using a different year's figure would silently produce a cross-period ratio.
        """
        if not entries or not anchor_end:
            return None
        try:
            anchor = datetime.fromisoformat(anchor_end)
        except (TypeError, ValueError):
            return None
        best, best_key = None, None
        for e in entries:
            gap = cls._within(e.get("end"), anchor, window)
            if gap is None:
                continue
            key = (int(e.get("_priority") or 0), gap)     # preferred tag first, then closest
            if best_key is None or key < best_key:
                best, best_key = e, key
        return best

    def _latest_and_prior(self, facts: dict, concept: str, taxonomy: str = "us-gaap"):
        """Kept for the anchor concept (revenue): newest annual value plus the one before it."""
        entries = self._merged_annual_facts(facts, concept, taxonomy)
        if not entries:
            return None, None, None, None
        latest = entries[0].get("val")
        prior = entries[1].get("val") if len(entries) > 1 else None
        return latest, prior, entries[0], None

    @staticmethod
    def _combine_debt(noncurrent, current, reported):
        """Sum the current + non-current pair when either is present, else fall back to a single
        aggregate tag. Callers must pass values drawn from ONE period — debt summed across years
        is not a number that means anything."""
        if noncurrent is not None or current is not None:
            return float(noncurrent or 0.0) + float(current or 0.0)
        return float(reported) if reported is not None else None

    def _total_debt(self, facts: dict, anchor_end: str, taxonomy: str = "us-gaap"):
        """Total debt at the anchor period, via the concept chains so IFRS filers work too."""
        def at(concept):
            entry = self._pick_for_period(
                self._merged_annual_facts(facts, concept, taxonomy), anchor_end)
            return entry.get("val") if entry else None
        return self._combine_debt(at("debt_noncurrent"), at("debt_current"),
                                  at("debt_total_reported"))

    # ---------- public API ----------

    def get_fundamentals(self, ticker: str) -> Fundamentals:
        cik = self.get_cik(ticker)
        payload = self._get(SEC_FACTS_URL.format(cik=cik))
        facts = payload.get("facts") or {}
        warnings = []

        f = Fundamentals(ticker=ticker.upper(), source=self.name,
                         fetched_at=datetime.now(timezone.utc))

        # ---- Anchor every figure to ONE fiscal period ----------------------------------
        # Mixing periods is the single most dangerous failure mode here: a gross margin built
        # from one year's revenue and another year's gross profit, or a free-cash-flow figure
        # larger than revenue, looks like real data while being meaningless. The anchor is the
        # most recent annual period end for which revenue is reported; every other concept must
        # match that period (within a fiscal-calendar tolerance) or be reported as None.
        taxonomy = self.detect_taxonomy(facts)
        f.taxonomy = taxonomy
        revenue_entries = self._merged_annual_facts(facts, "revenue", taxonomy)
        if not revenue_entries:
            warnings.append("No annual revenue concept found in this company's XBRL filings — "
                            "figures cannot be period-anchored, so none are reported.")
            f.warnings = warnings
            return f

        anchor = revenue_entries[0]
        anchor_end = anchor["end"]
        f.as_of = anchor_end
        f.fiscal_year = anchor.get("fy")
        f.filed = anchor.get("filed")
        f.currency = anchor.get("_unit")
        if f.currency and f.currency != "USD":
            warnings.append(
                f"This company reports in {f.currency}, not US dollars, and no currency "
                f"conversion exists anywhere in this app. The ratios below (margins, growth, "
                f"returns) are unaffected because they divide {f.currency} by {f.currency}. "
                f"Any figure that would combine these with a US-dollar share price — market "
                f"capitalisation, P/E, enterprise value, free-cash-flow yield — is NOT "
                f"calculated and reads UNKNOWN rather than being converted at a guessed rate.")

        revenue = anchor.get("val")
        prior_entry = None
        try:
            anchor_dt = datetime.fromisoformat(anchor_end)
            for e in revenue_entries[1:]:
                gap = (anchor_dt - datetime.fromisoformat(e["end"])).days
                if 330 <= gap <= 400:
                    prior_entry = e
                    break
        except (TypeError, ValueError):
            pass
        revenue_prior = prior_entry.get("val") if prior_entry else None

        def at_anchor(concept):
            entry = self._pick_for_period(
                self._merged_annual_facts(facts, concept, taxonomy), anchor_end,
                period_tolerance(concept))
            return entry.get("val") if entry else None

        def at_prior(concept):
            if not prior_entry:
                return None
            entry = self._pick_for_period(
                self._merged_annual_facts(facts, concept, taxonomy), prior_entry["end"],
                period_tolerance(concept))
            return entry.get("val") if entry else None

        net_income = at_anchor("net_income")
        eps = at_anchor("eps_diluted")
        eps_prior = at_prior("eps_diluted")
        gross_profit = at_anchor("gross_profit")
        operating_income = at_anchor("operating_income")
        ocf = at_anchor("operating_cash_flow")
        capex = at_anchor("capex")
        cash = at_anchor("total_cash")
        equity = at_anchor("stockholders_equity")
        debt = self._total_debt(facts, anchor_end, taxonomy)

        fcf = (ocf - capex) if (ocf is not None and capex is not None) else None

        # Sanity guard: free cash flow cannot plausibly exceed revenue for an operating company.
        # If it does, the underlying tags disagree in a way this parser can't reconcile, so the
        # figure is dropped rather than displayed. Better a visible gap than a confident wrong
        # number driving a hold-or-sell decision.
        if fcf is not None and revenue and abs(fcf) > abs(revenue) * 1.5:
            warnings.append(
                f"Free cash flow derived from XBRL ({fcf:,.0f}) exceeds reported revenue "
                f"({revenue:,.0f}), which indicates mismatched source tags. It has been "
                f"discarded rather than displayed.")
            fcf = ocf = capex = None

        f.revenue = revenue
        f.revenue_prior = revenue_prior
        f.revenue_growth_pct = _growth(revenue, revenue_prior)
        f.net_income = net_income
        f.eps_diluted = eps
        f.eps_diluted_prior = eps_prior
        f.eps_growth_pct = _growth(eps, eps_prior)
        f.gross_profit = gross_profit
        f.gross_margin_pct = _pct(gross_profit, revenue)
        f.operating_income = operating_income
        f.operating_margin_pct = _pct(operating_income, revenue)
        f.operating_cash_flow = ocf
        f.capex = capex
        f.free_cash_flow = fcf
        f.fcf_margin_pct = _pct(fcf, revenue)
        f.total_cash = cash
        f.total_debt = debt
        f.stockholders_equity = equity
        if operating_income is not None and equity:
            invested = equity + (debt or 0.0)
            f.roic_pct = _pct(operating_income, invested) if invested else None

        for label, value in (("gross profit", gross_profit), ("operating cash flow", ocf),
                             ("capital expenditure", capex)):
            if value is None:
                warnings.append(f"No annual {label} reported under the tags this app checks.")
        f.warnings = warnings
        return f

    # ---------- multi-year, point-in-time history ----------

    @classmethod
    def _pick_at_vintage(cls, entries: list, period_end: str, vintage_filed: str,
                         window: tuple = DEFAULT_PERIOD_TOLERANCE_DAYS):
        """The best figure for `period_end` THAT WAS PUBLIC BY `vintage_filed`.

        This one function is what makes historical scoring honest, so it is worth being explicit
        about what it refuses to do: it never looks at an entry filed after the vintage date,
        even when that entry is a correction and is therefore the *better* number. Using it would
        mean scoring 2023 with knowledge that did not exist until 2026 — and because restatements
        usually make a company look worse, the bias runs consistently in the flattering
        direction. A backtest built on that would show an edge that no one could have traded.

        Among the entries that were public, the latest-filed wins (a correction issued in March
        is legitimately available in April), with the closest period end as the tie-break.
        """
        if not entries or not period_end or not vintage_filed:
            return None
        try:
            anchor = datetime.fromisoformat(period_end)
        except (TypeError, ValueError):
            return None
        best, best_key = None, None
        for e in entries:
            filed = e.get("filed") or ""
            if not filed or filed > vintage_filed:
                continue                      # not yet public — the whole point
            gap = cls._within(e.get("end"), anchor, window)
            if gap is None:
                continue
            # Latest-public first (a correction issued in March is available in April), then the
            # preferred tag, then the closest period end. Filing date leads because the
            # point-in-time guarantee outranks every preference below it.
            key = (filed, -int(e.get("_priority") or 0), -gap)
            if best_key is None or key > best_key:
                best, best_key = e, key
        return best

    def get_fundamentals_history(self, ticker: str) -> list:
        """Every annual period EDGAR reports, in every version it was reported in.

        Replaces the old behaviour of parsing the full history and then throwing all but one year
        away because the `fundamentals` table is keyed on ticker alone. Returns a list of
        AnnualPeriod, newest period first, newest vintage first within a period.
        """
        cik = self.get_cik(ticker)
        payload = self._get(SEC_FACTS_URL.format(cik=cik))
        return self.parse_history(ticker, payload)

    def parse_history(self, ticker: str, payload: dict) -> list:
        """The pure parsing half of get_fundamentals_history, split out so it can be tested
        against fixtures without a network round trip."""
        facts = payload.get("facts") or {}
        taxonomy = self.detect_taxonomy(facts)

        # Every concept, every version, resolved once. Building this pool up front matters:
        # doing it inside the period loop would re-walk the whole fact tree ~50 times per ticker.
        concepts = [c for c in HISTORY_VALUE_FIELDS if c != "total_debt"] + [
            "debt_noncurrent", "debt_current", "debt_total_reported"]
        pool = {c: self._merged_annual_facts(facts, c, taxonomy, dedupe=False) for c in concepts}

        anchor_entries = pool.get(TAXONOMY_ANCHOR) or []
        if not anchor_entries:
            return []

        period_ends = sorted({e["end"] for e in anchor_entries}, reverse=True)[:MAX_HISTORY_PERIODS]

        records = []
        for period_end in period_ends:
            vintages = sorted({e.get("filed") for e in anchor_entries
                               if e["end"] == period_end and e.get("filed")})
            if len(vintages) > MAX_VINTAGES_PER_PERIOD:
                # Keep the ORIGINAL report and the most recent versions. The original is what a
                # point-in-time score for the year just after the period needs; the recent ones
                # are what today's score needs. The middle restatements of a heavily-amended year
                # are the least useful and the ones dropped.
                vintages = [vintages[0]] + vintages[-(MAX_VINTAGES_PER_PERIOD - 1):]

            for vintage in vintages:
                anchor = self._pick_at_vintage(anchor_entries, period_end, vintage)
                if anchor is None:
                    continue
                currency = anchor.get("_unit")
                warnings, values = [], {}

                for concept in concepts:
                    entry = self._pick_at_vintage(pool.get(concept) or [], period_end,
                                                  vintage, period_tolerance(concept))
                    if entry is None:
                        values[concept] = None
                        continue
                    # A money figure reported in a different currency from the rest of the
                    # statement cannot be combined with them. This should never happen within one
                    # filing; if it does, the figure is dropped rather than quietly mixed.
                    if (unit_kind(concept) == UNIT_CURRENCY and currency
                            and entry.get("_unit") != currency):
                        warnings.append(
                            f"{concept} was reported in {entry.get('_unit')} while the rest of "
                            f"this period is in {currency}; it has been dropped rather than "
                            f"combined across currencies.")
                        values[concept] = None
                        continue
                    values[concept] = entry.get("val")

                values["total_debt"] = self._combine_debt(
                    values.pop("debt_noncurrent", None), values.pop("debt_current", None),
                    values.pop("debt_total_reported", None))

                records.append(AnnualPeriod(
                    ticker=ticker.upper(), source=self.name, period_end=period_end,
                    filed=vintage, taxonomy=taxonomy, currency=currency,
                    fiscal_year=anchor.get("fy"), form=anchor.get("form"),
                    accn=anchor.get("accn"),
                    values={k: values.get(k) for k in HISTORY_VALUE_FIELDS},
                    warnings=warnings,
                ))

        records.sort(key=lambda r: (r.period_end, r.filed), reverse=True)
        return records

    def list_tags(self, ticker: str, contains: str | None = None, limit: int = 300) -> dict:
        """Every XBRL tag this company actually publishes, by namespace, with its units.

        A DIAGNOSTIC, NOT A DATA PATH — nothing scores off it. It exists because the alternative
        to it is guessing. NVO's diluted share count came back empty against live data, and the
        only two ways to find the right tag are to read SEC's response or to keep inventing
        plausible-looking tag names and shipping them. The second is how a wrong number gets a
        confident label, so this endpoint reads the response instead.
        """
        cik = self.get_cik(ticker)
        payload = self._get(SEC_FACTS_URL.format(cik=cik))
        facts = payload.get("facts") or {}
        needle = (contains or "").lower()
        out = {}
        for namespace, tags in facts.items():
            names = sorted(n for n in tags if needle in n.lower())
            out[namespace] = {
                "tags_in_namespace": len(tags),
                "matched": len(names),
                "tags": {n: sorted((tags[n].get("units") or {}).keys()) for n in names[:limit]},
            }
        return out

    def get_earnings_info(self, ticker: str) -> EarningsInfo:
        cik = self.get_cik(ticker)
        payload = self._get(SEC_SUBMISSIONS_URL.format(cik=cik))
        recent = ((payload.get("filings") or {}).get("recent") or {})
        forms = recent.get("form") or []
        filing_dates = recent.get("filingDate") or []
        report_dates = recent.get("reportDate") or []

        info = EarningsInfo(ticker=ticker.upper(), source=self.name)

        periodic = [
            (filing_dates[i], report_dates[i] if i < len(report_dates) else None, forms[i])
            for i in range(min(len(forms), len(filing_dates)))
            if forms[i] in ("10-Q", "10-K")
        ]
        if not periodic:
            info.warnings.append("No 10-Q/10-K filings found — earnings timing unavailable.")
            return info

        periodic.sort(key=lambda x: x[0], reverse=True)
        info.last_filed, info.last_period_end, info.last_form = periodic[0]

        gaps = []
        for i in range(min(len(periodic) - 1, 8)):
            try:
                a = datetime.fromisoformat(periodic[i][0])
                b = datetime.fromisoformat(periodic[i + 1][0])
                gaps.append((a - b).days)
            except (TypeError, ValueError):
                continue
        gaps = [g for g in gaps if 30 <= g <= 200]
        if gaps:
            info.median_days_between_reports = float(statistics.median(gaps))
            try:
                last = datetime.fromisoformat(info.last_filed)
                info.estimated_next_report = (
                    last + timedelta(days=info.median_days_between_reports)
                ).date().isoformat()
                info.estimate_confidence = "MEDIUM" if len(gaps) >= 4 else "LOW"
            except (TypeError, ValueError):
                pass
        else:
            info.warnings.append("Filing cadence too irregular to estimate the next report date.")

        info.warnings.append(
            "Estimated from historical SEC filing cadence — this is NOT a confirmed, "
            "company-announced earnings date."
        )
        return info
