"""
Does a BUY signal mark a better-than-ordinary moment to buy something you then HOLD?

The backtest could not answer this. Every trade in it was closed at a price target or a time
limit after about three weeks, so it measured the round trip — entry AND exit together. When it
underperformed buy-and-hold, that told us the exits were costly; it said nothing about whether
the entries were any good. This module isolates the entry and never sells.

THREE ARMS, measured identically
--------------------------------
  SIGNAL    buy on the bar after a BUY/STRONG BUY close
  MONTHLY   buy on the first trading day of every month, ignoring price entirely
  EVERY_DAY buy on every single trading day

MONTHLY is the realistic alternative for someone contributing from income. EVERY_DAY is the
control: it is the average outcome of buying at a moment chosen with no information at all, so
"does the signal beat a coin flip" has an answer and not just a vibe.

FOUR WAYS THIS COMPARISON COULD LIE, AND WHAT STOPS EACH
-------------------------------------------------------
1. Look-ahead. Signals are scored from a physically truncated slice of history and filled at the
   NEXT bar's open, reusing the backtest's own machinery so the two cannot drift apart.

2. Truncation. A 24-month forward return only exists for entries at least 24 months from the end
   of the data. Dropping incomplete ones silently would compare a signal arm weighted to older
   (higher-returning) dates against a baseline weighted differently. So EVERY arm is restricted
   to the SAME eligible date window per horizon, and the window is reported.

3. Ticker mix. If signals fire disproportionately on the stock that ran hardest, the signal arm
   wins on stock selection, not on timing. So arms are compared PER TICKER first and only then
   averaged, equal-weight — and a ticker contributes to a horizon only if BOTH arms have entries
   for it.

4. Overlap. Signal entries cluster, so their forward returns are correlated and the effective
   sample is far smaller than the row count. Nothing here can fix that; the row counts are
   reported so the numbers are not mistaken for independent observations, and the summary says
   so in words.
"""
import logging
from datetime import datetime, timezone

import pandas as pd

from services.backtest_service import (ENTRY_LABELS, MIN_WARMUP_BARS, _indicators_at,
                                       _precompute, _regime_by_date, _score_from_indicators,
                                       effective_min_score)

log = logging.getLogger(__name__)

# Forward horizons in TRADING days (~21 per month), so a horizon is a fixed number of bars
# rather than a calendar span that lands on a weekend.
HORIZONS = [
    ("1 month", 21),
    ("3 months", 63),
    ("6 months", 126),
    ("12 months", 252),
    ("24 months", 504),
]

ARMS = ("SIGNAL", "MONTHLY", "EVERY_DAY")


def _forward_return(df: pd.DataFrame, entry_i: int, horizon: int):
    """Buy at the open of bar `entry_i`, value it at the close `horizon` bars later.

    Returns None when the horizon runs past the end of the data — never a partial-period return
    dressed up as a full one.
    """
    exit_i = entry_i + horizon
    if entry_i >= len(df) or exit_i >= len(df):
        return None
    entry = float(df["open"].iloc[entry_i])
    if entry <= 0:
        return None
    return (float(df["close"].iloc[exit_i]) - entry) / entry * 100


def _signal_entry_indices(df: pd.DataFrame, regime_by_date: dict, min_score: float) -> list:
    """Bar indices where the strategy would have bought, computed without look-ahead.

    Unlike the backtest this does NOT stop at one position per ticker: the question is the
    quality of the signal itself, so every signal counts, including ones the backtest would have
    skipped because it was already holding.
    """
    out = []
    pre = _precompute(df)
    for i in range(MIN_WARMUP_BARS, len(df) - 1):
        ind = _indicators_at(df, pre, i)
        if not ind.get("bars_used"):
            continue
        scored = _score_from_indicators(ind, regime_by_date.get(df["ts"].iloc[i], {}))
        if scored["label"] in ENTRY_LABELS and scored["score"] >= min_score:
            out.append(i + 1)          # fill on the NEXT bar's open
    return out


def _monthly_entry_indices(df: pd.DataFrame, first_i: int) -> list:
    """First trading day of each calendar month — a standing order, blind to price."""
    ts = pd.to_datetime(df["ts"], format="mixed", utc=True)
    # year*100+month rather than to_period("M"), which warns that it is discarding the timezone.
    # The bars are already UTC and a calendar month is what we want, so the integer key says
    # exactly that without the ambiguity.
    period = ts.dt.year * 100 + ts.dt.month
    out = []
    seen = set()
    for i in range(first_i, len(df)):
        p = period.iloc[i]
        if p not in seen:
            seen.add(p)
            out.append(i)
    return out


def _summarise(returns: list) -> dict:
    if not returns:
        return {"n": 0, "mean_pct": None, "median_pct": None, "positive_pct": None}
    s = pd.Series(returns, dtype="float64")
    return {
        "n": int(len(s)),
        "mean_pct": round(float(s.mean()), 2),
        "median_pct": round(float(s.median()), 2),
        "positive_pct": round(float((s > 0).mean() * 100), 1),
    }


def _eligible_window(df: pd.DataFrame, horizon: int) -> tuple:
    """(first_index, last_index) of entries that can have a COMPLETE forward return.

    Both bounds matter. The lower bound is the warm-up the signal needs — applying it to the
    baselines too is what stops the baselines from claiming an extra year of history the signal
    arm never had. The upper bound is the horizon.
    """
    first = MIN_WARMUP_BARS + 1
    last = len(df) - horizon - 1
    return first, last


def analyse_ticker(df: pd.DataFrame, regime_by_date: dict, min_score: float) -> dict:
    """Per-horizon, per-arm forward returns for one ticker."""
    signal_idx = _signal_entry_indices(df, regime_by_date, min_score)
    out = {"signal_entries_total": len(signal_idx), "bars": len(df), "horizons": {}}

    for label, horizon in HORIZONS:
        first, last = _eligible_window(df, horizon)
        if last < first:
            out["horizons"][label] = {arm: _summarise([]) for arm in ARMS}
            out["horizons"][label]["window"] = None
            continue

        eligible = lambda idx: [i for i in idx if first <= i <= last]      # noqa: E731
        arms_idx = {
            "SIGNAL": eligible(signal_idx),
            "MONTHLY": eligible(_monthly_entry_indices(df, first)),
            "EVERY_DAY": list(range(first, last + 1)),
        }
        row = {}
        for arm, idx in arms_idx.items():
            rets = [r for r in (_forward_return(df, i, horizon) for i in idx) if r is not None]
            row[arm] = _summarise(rets)
        row["window"] = {"from": str(df["ts"].iloc[first]), "to": str(df["ts"].iloc[last])}
        out["horizons"][label] = row

    return out


def _aggregate(per_ticker: dict) -> dict:
    """Equal-weight across tickers, per horizon.

    Averaging every entry in one pool would let a ticker with many signals dominate, so each
    ticker contributes one number and they are averaged. A ticker joins a horizon only if the
    SIGNAL and MONTHLY arms both have entries for it — otherwise the arms would be built from
    different companies, and the difference between them would be stock picking rather than
    timing.
    """
    out = {}
    for label, _h in HORIZONS:
        usable = [t for t, data in per_ticker.items()
                  if data["horizons"].get(label)
                  and data["horizons"][label]["SIGNAL"]["n"] > 0
                  and data["horizons"][label]["MONTHLY"]["n"] > 0]
        row = {"tickers_compared": len(usable), "tickers": sorted(usable)}
        for arm in ARMS:
            means = [per_ticker[t]["horizons"][label][arm]["mean_pct"] for t in usable
                     if per_ticker[t]["horizons"][label][arm]["mean_pct"] is not None]
            entries = sum(per_ticker[t]["horizons"][label][arm]["n"] for t in usable)
            wins = [per_ticker[t]["horizons"][label][arm]["positive_pct"] for t in usable
                    if per_ticker[t]["horizons"][label][arm]["positive_pct"] is not None]
            row[arm] = {
                "mean_pct": round(sum(means) / len(means), 2) if means else None,
                "positive_pct": round(sum(wins) / len(wins), 1) if wins else None,
                "entries": entries,
            }
        sig = row["SIGNAL"]["mean_pct"]
        row["edge_vs_monthly_pct"] = (round(sig - row["MONTHLY"]["mean_pct"], 2)
                                      if sig is not None and row["MONTHLY"]["mean_pct"] is not None
                                      else None)
        row["edge_vs_every_day_pct"] = (round(sig - row["EVERY_DAY"]["mean_pct"], 2)
                                        if sig is not None and row["EVERY_DAY"]["mean_pct"] is not None
                                        else None)
        out[label] = row
    return out


def _verdict(overall: dict) -> dict:
    """Plain-language reading of the result, written to resist over-claiming.

    A backtest that says "the signal wins" is the most dangerous output this app can produce, so
    the wording only strengthens when the edge holds at the LONGER horizons — a one-month edge in
    a bull market is close to meaningless for someone buying to hold for years.
    """
    long_horizons = ["12 months", "24 months"]
    edges = [overall[h]["edge_vs_monthly_pct"] for h in long_horizons
             if overall.get(h) and overall[h].get("edge_vs_monthly_pct") is not None]
    all_edges = [overall[h]["edge_vs_monthly_pct"] for h, _ in HORIZONS
                 if overall.get(h) and overall[h].get("edge_vs_monthly_pct") is not None]

    if not all_edges:
        return {"headline": "UNAVAILABLE",
                "detail": "Not enough history to compare entries at any horizon."}

    positive_long = [e for e in edges if e > 0]
    if not edges:
        return {"headline": "TOO SHORT TO JUDGE",
                "detail": ("Only the short horizons could be measured. Whether these entries are "
                           "better for a position you hold for years is still untested.")}

    avg_long = sum(edges) / len(edges)
    if avg_long <= 0:
        headline = "NO ADVANTAGE"
        detail = ("At 12 and 24 months, signal entries did not beat buying on the first trading "
                  "day of each month. On this evidence the timing work is not earning its keep "
                  "for long-term holding.")
    elif avg_long < 2 or len(positive_long) < len(edges):
        headline = "TOO SMALL TO RELY ON"
        detail = (f"Signal entries came out {avg_long:.1f} percentage points ahead on average at "
                  f"the long horizons, which is inside the range that fees, spreads and luck "
                  f"could account for — and it did not hold at every horizon.")
    else:
        headline = "SOME ADVANTAGE"
        detail = (f"Signal entries came out {avg_long:.1f} percentage points ahead on average at "
                  f"12 and 24 months. Real, but see the caveats before acting on it: the entries "
                  f"overlap heavily, so this is far fewer independent observations than the row "
                  f"counts suggest.")
    return {"headline": headline, "detail": detail, "avg_long_horizon_edge_pct": round(avg_long, 2)}


LIMITATIONS = [
    "SURVIVORSHIP BIAS: these 15 are today's winners. Any entry into them looks good in "
    "hindsight, which flatters every arm — including the one that ignores price entirely.",
    "Signal entries cluster together, so their forward returns overlap and are correlated. The "
    "entry counts are NOT independent observations and the true sample is much smaller.",
    "One market period, and it begins near the 2022 low. A different window can give a "
    "different answer.",
    "No fees, spreads, slippage or tax. Buying monthly incurs 12 transactions a year; signal "
    "entries incur however many the rules fire.",
    "Nothing here is ever sold, so this measures ENTRY quality only. It says nothing about when "
    "to take a profit.",
    "Forward returns use the close N trading days later — one specific day, not an average "
    "around it, so a single volatile session can move a horizon's figure.",
]


def run_entry_quality(bars_by_ticker: dict, tickers: list, config: dict | None = None) -> dict:
    config = config or {}
    min_score = effective_min_score(config.get("min_score", 0))
    regime_by_date = (_regime_by_date(bars_by_ticker)
                      if config.get("use_regime", True) else {})

    per_ticker = {}
    skipped = {}
    for t in tickers:
        df = bars_by_ticker.get(t)
        if df is None or len(df) < MIN_WARMUP_BARS + 30:
            skipped[t] = f"needs more than {MIN_WARMUP_BARS + 30} daily bars, has {0 if df is None else len(df)}"
            continue
        per_ticker[t] = analyse_ticker(df.reset_index(drop=True), regime_by_date, min_score)

    overall = _aggregate(per_ticker)
    return {
        "config": {
            "min_score": config.get("min_score", 0),
            "min_score_effective": min_score,
            "use_regime": config.get("use_regime", True),
            "horizons": [{"label": l, "trading_days": h} for l, h in HORIZONS],
            "arms": {
                "SIGNAL": "Buy on the bar after a BUY or STRONG BUY close.",
                "MONTHLY": "Buy on the first trading day of every month, ignoring price.",
                "EVERY_DAY": "Buy on every trading day — the no-information control.",
            },
        },
        "overall": overall,
        "by_ticker": per_ticker,
        "tickers_skipped": skipped,
        "verdict": _verdict(overall),
        "limitations": LIMITATIONS,
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
