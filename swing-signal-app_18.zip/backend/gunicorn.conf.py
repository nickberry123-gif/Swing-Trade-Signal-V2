"""
Gunicorn settings.

Gunicorn automatically loads `gunicorn.conf.py` from its working directory, and the Render start
command is `cd backend && gunicorn --bind 0.0.0.0:$PORT app:app` — so this file is picked up
without needing to change that command (there is no Render API to edit a service's start
command).

=== WHY THESE VALUES ===

The defaults took the site down twice.

`timeout` defaults to 30s. Anything slower — a cold cache refetching bars for 24 tickers, or a
backtest — got the worker SIGKILLed mid-request, restarted, and retried, producing a crash loop
that made every page unreachable:

    [CRITICAL] WORKER TIMEOUT (pid:68)
    [ERROR] Worker (pid:68) was sent SIGKILL! Perhaps out of memory?

`worker_class` defaults to `sync`, which handles exactly one request at a time per worker. The
backtester runs in a background thread inside the worker process, and under the sync worker that
thread starves request handling. `gthread` lets the background work and incoming requests
interleave, so the site stays responsive while a backtest runs.

Worker count stays at 1 deliberately: Render's free tier has limited memory and pandas/numpy
carry a large per-process footprint, so a second worker risks genuine out-of-memory kills.
Concurrency comes from threads instead.
"""

# Long enough for a cold-cache request or a heavy computation, short enough that a genuinely
# hung worker is still recycled rather than wedging forever.
timeout = 300
graceful_timeout = 30

# Threads, not processes — see the memory note above.
worker_class = "gthread"
workers = 1
threads = 4

# Recycle periodically so any slow leak in a long-lived process can't accumulate indefinitely.
max_requests = 400
max_requests_jitter = 50

accesslog = "-"
errorlog = "-"
loglevel = "info"
