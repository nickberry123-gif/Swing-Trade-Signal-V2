// Build B2 — the Data Check page.
//
// Read-only. It starts a background run, polls it, and renders the result. It does not compute
// anything itself: every number and every verdict comes from the server, so the page and any
// future score can never disagree about what the data says.

const DV = { runId: null, timer: null, results: [] };

function el(id) { return document.getElementById(id); }

function esc(s) {
  return String(s === null || s === undefined ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function fmtBig(v) {
  if (v === null || v === undefined) return "—";
  const n = Number(v);
  const abs = Math.abs(n);
  if (abs >= 1e12) return "$" + (n / 1e12).toFixed(2) + "T";
  if (abs >= 1e9) return "$" + (n / 1e9).toFixed(2) + "B";
  if (abs >= 1e6) return "$" + (n / 1e6).toFixed(2) + "M";
  return "$" + n.toFixed(0);
}

function fmtNum(v, dp) {
  if (v === null || v === undefined) return "—";
  return Number(v).toFixed(dp === undefined ? 2 : dp);
}

// Verdict is ALWAYS rendered as text, never as colour alone — the project's status-display rule.
function verdictCell(r) {
  if (!r) return '<span class="text-dim">—</span>';
  if (r.verdict === "OK") return "";
  const cls = r.verdict === "IMPLAUSIBLE" ? "num-neg" : "text-dim";
  return ` <span class="${cls}">[${esc(r.verdict)}]</span>`;
}

function metricText(r, formatter) {
  if (!r) return '<span class="text-dim">—</span>';
  if (r.verdict === "UNAVAILABLE") {
    return `<span class="text-dim" title="${esc(r.reason || "")}">UNAVAILABLE</span>`;
  }
  return esc(formatter(r.value)) + verdictCell(r);
}

async function post(path, body) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body || {}),
  });
  if (!res.ok && res.status !== 202) throw new Error(`Request to ${path} failed: ${res.status}`);
  return res.json();
}

function message(html, kind) {
  el("dv-message").innerHTML = html
    ? `<div class="${kind === "error" ? "warn-banner" : "footer-note"}">${html}</div>` : "";
}

async function startRun(refresh) {
  message("");
  try {
    const out = await post("/api/data-validation/runs", { refresh: refresh });
    DV.runId = out.run_id;
    el("dv-status").innerHTML =
      `<div>Run #${out.run_id} started on ${out.tickers} companies. ` +
      (refresh
        ? "Fetching filings from SEC — this takes several minutes."
        : "Re-checking already-stored filings.") +
      "</div>";
    poll();
  } catch (e) {
    message("Could not start the check: " + esc(e.message), "error");
  }
}

function poll() {
  clearTimeout(DV.timer);
  DV.timer = setTimeout(loadRun, 4000);
}

async function loadRun() {
  if (!DV.runId) return;
  try {
    const run = await apiGet(`/api/data-validation/runs/${DV.runId}`);
    if (run.status === "running") {
      el("dv-status").innerHTML =
        `<div>Run #${run.id} — <strong>${esc(run.progress || "working…")}</strong></div>`;
      poll();
      return;
    }
    if (run.status === "failed") {
      el("dv-status").innerHTML =
        `<div class="num-neg">Run #${run.id} failed.</div><div class="text-dim">${esc(run.error || "")}</div>`;
      return;
    }
    el("dv-status").innerHTML = `<div>Run #${run.id} complete.</div>`;
    render(run.results || {});
  } catch (e) {
    message("Could not read the run: " + esc(e.message), "error");
  }
}

function render(payload) {
  const summary = payload.summary || {};
  DV.results = payload.results || [];

  const blocked = summary.blocked_by_coverage || 0;
  const impl = summary.tickers_with_implausible_metrics || {};
  const implCount = Object.keys(impl).length;

  let html = `<div style="font-size:14px; margin-bottom:10px;"><strong>${esc(summary.verdict || "")}</strong></div>`;
  html += `<div>Companies checked: <strong>${summary.tickers || 0}</strong></div>`;
  html += `<div>Clearing the v3 spec's own 75% Company Health gate: <strong>${summary.clearing_the_75pct_gate || 0}</strong>` +
          ` &middot; blocked by coverage: <strong>${blocked}</strong></div>`;
  html += `<div>Average Company Health coverage: <strong>${fmtNum(summary.mean_company_health_coverage_pct, 1)}%</strong>` +
          ` &middot; average valuation coverage: <strong>${fmtNum(summary.mean_valuation_coverage_pct, 1)}%</strong></div>`;

  if (implCount) {
    html += `<div class="num-neg" style="margin-top:10px;"><strong>${implCount} company(s) produced a figure that could not be true.</strong> ` +
            `These are bugs to fix before any score consumes them, not rows to skip:</div><ul>`;
    Object.keys(impl).forEach(function (t) {
      html += `<li>${esc(t)}: ${esc(impl[t].join(", "))}</li>`;
    });
    html += "</ul>";
  } else {
    html += `<div style="margin-top:10px;">No metric fell outside its plausible range.</div>`;
  }

  if ((summary.tickers_not_in_usd || []).length) {
    html += `<div style="margin-top:10px;">Reporting in a currency other than US dollars, so every ` +
            `price-based metric is withheld rather than converted: <strong>${esc(summary.tickers_not_in_usd.join(", "))}</strong></div>`;
  }
  if ((summary.tickers_with_no_history || []).length) {
    html += `<div class="num-neg" style="margin-top:10px;">No stored filings at all: ` +
            `<strong>${esc(summary.tickers_with_no_history.join(", "))}</strong></div>`;
  }

  const missing = summary.most_commonly_missing_inputs || [];
  if (missing.length) {
    html += `<div style="margin-top:10px;">Most commonly missing inputs — fixing the top of this ` +
            `list moves coverage furthest:</div><ol>`;
    missing.forEach(function (pair) {
      html += `<li>${esc(pair[0])} — missing on ${pair[1]} companies</li>`;
    });
    html += "</ol>";
  }

  if ((payload.failures || []).length) {
    html += `<div class="num-neg" style="margin-top:10px;">${payload.failures.length} company(s) ` +
            `could not be refreshed from SEC. Stored filings were used instead where available.</div>`;
  }
  html += `<div class="text-dim" style="margin-top:10px;">${esc(payload.price_source || "")}</div>`;

  el("dv-summary").innerHTML = html;
  el("dv-summary-section").style.display = "";
  renderTable();
  el("dv-results-section").style.display = "";
}

function renderTable() {
  const rows = DV.results.slice().sort(function (a, b) {
    return (b.company_health_coverage_pct || 0) - (a.company_health_coverage_pct || 0);
  });
  el("dv-tbody").innerHTML = rows.map(function (r, i) {
    const m = r.metrics || {};
    const gate = r.clears_75pct_gate
      ? '<span class="num-pos">YES</span>' : '<span class="num-neg">NO</span>';
    const bad = (r.implausible || []).length
      ? `<span class="num-neg">${r.implausible.length}</span>` : '<span class="text-dim">none</span>';
    return `<tr class="dv-row" data-i="${i}" style="cursor:pointer;">
      <td><strong>${esc(r.ticker)}</strong></td>
      <td>${r.periods || 0}</td>
      <td>${esc(r.currency || "—")}</td>
      <td>${fmtNum(r.company_health_coverage_pct, 1)}%</td>
      <td>${gate}</td>
      <td>${fmtNum(r.valuation_coverage_pct, 1)}%</td>
      <td>${metricText(m.market_cap, fmtBig)}</td>
      <td>${metricText(m.pe_ratio, function (v) { return fmtNum(v, 1); })}</td>
      <td>${bad}</td>
    </tr>
    <tr class="dv-detail" id="dv-detail-${i}" style="display:none;"><td colspan="9"></td></tr>`;
  }).join("");

  Array.prototype.forEach.call(document.querySelectorAll(".dv-row"), function (tr) {
    tr.addEventListener("click", function () { toggleDetail(Number(tr.dataset.i)); });
  });
}

function toggleDetail(i) {
  const row = el("dv-detail-" + i);
  if (!row) return;
  if (row.style.display !== "none") { row.style.display = "none"; return; }
  const r = DV.results[i];
  const m = r.metrics || {};

  let html = '<div class="card-pad">';
  if ((r.notes || []).length) {
    html += r.notes.map(function (n) { return `<div class="text-dim">${esc(n)}</div>`; }).join("");
  }
  html += `<div style="margin:8px 0;">Fiscal periods stored: ${esc((r.period_ends || []).join(", ") || "none")}</div>`;
  if (r.shares_basis) {
    html += `<div style="margin:8px 0;">Share count used: ${esc(r.shares_basis)}</div>`;
  }

  html += '<div style="margin-top:10px;"><strong>Company Health, by category</strong></div><ul>';
  const cats = r.company_health_categories || {};
  Object.keys(cats).forEach(function (k) {
    const c = cats[k];
    html += `<li>${esc(k.replace(/_/g, " "))} — weight ${c.weight}%, ${c.available}/${c.inputs} inputs available (${fmtNum(c.coverage_pct, 0)}%)` +
            (c.missing.length ? ` &middot; missing: ${esc(c.missing.join(", "))}` : "") + "</li>";
  });
  html += "</ul>";

  html += '<div style="margin-top:10px;"><strong>Every metric</strong></div>';
  html += '<table class="table"><thead><tr><th>Metric</th><th>Value</th><th>Verdict</th><th>Why not</th></tr></thead><tbody>';
  Object.keys(m).forEach(function (k) {
    const v = m[k];
    const cls = v.verdict === "IMPLAUSIBLE" ? "num-neg" : v.verdict === "OK" ? "" : "text-dim";
    html += `<tr><td>${esc(k.replace(/_/g, " "))}</td><td>${v.value === null ? "—" : esc(fmtNum(v.value, 3))}</td>` +
            `<td class="${cls}">${esc(v.verdict)}</td><td class="text-dim">${esc(v.reason || "")}</td></tr>`;
  });
  html += "</tbody></table>";

  if ((r.fields_never_reported || []).length) {
    html += `<div class="text-dim" style="margin-top:8px;">Never reported in any stored filing: ${esc(r.fields_never_reported.join(", "))}</div>`;
  }
  html += "</div>";

  row.firstElementChild.innerHTML = html;
  row.style.display = "";
}

async function loadLatest() {
  try {
    const out = await apiGet("/api/data-validation/runs");
    const runs = out.runs || [];
    if (!runs.length) {
      el("dv-status").innerHTML =
        '<div class="text-dim">No check has been run yet. The full run fetches all 50 companies ' +
        'from SEC and takes several minutes.</div>';
      return;
    }
    DV.runId = runs[0].id;
    loadRun();
  } catch (e) {
    message("Could not list previous runs: " + esc(e.message), "error");
  }
}

el("dv-run").addEventListener("click", function () { startRun(true); });
el("dv-run-cached").addEventListener("click", function () { startRun(false); });
loadLatest();
