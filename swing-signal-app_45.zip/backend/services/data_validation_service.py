"""
Build B2 — does the data actually support v3, and are the numbers it produces possible?

WHY THIS EXISTS RATHER THAN "THE FIELDS ARE POPULATED, SHIP IT"
--------------------------------------------------------------
This project's recurring failure is not missing data. It is CORRECT CODE PRODUCING IMPOSSIBLE
NUMBERS: unadjusted prices, a fundamentals mix-up, a +88,446% backtest return. Every one had
passing tests and a populated field. A coverage report that only counts non-null values would
have called all three healthy.

So this module does two separate jobs and reports them separately:

  1. COVERAGE — is the input present at all, per Company Health category and per valuation
     metric, weighted exactly as the v3 spec weights them. Answers "would v3 clear its own 75%
     gate", which is the question that decides whether Build C can start.

  2. PLAUSIBILITY — having computed the metric, could it be true in the real world. Every derived
     figure is checked against a stated bound, and a figure outside it is reported IMPLAUSIBLE
     with its actual value quoted rather than being quietly dropped or quietly displayed.

The bounds below are deliberately WIDE. They are not opinions about what makes a good company —
a P/E of 300 is not a judgement, it is a fact about a real stock. They are the boundary between
"unusual" and "arithmetically impossible or catastrophically mis-parsed". A gross margin of 4,000%
is a parsing bug. A gross margin of 92% is NVIDIA.

THREE VERDICTS, AND THE DIFFERENCE BETWEEN THEM MATTERS
  OK           — computed, and inside the bound
  IMPLAUSIBLE  — computed, outside the bound. A bug until proven otherwise.
  UNAVAILABLE  — could not be computed, with the reason. NOT a zero, and NOT a failure of the
                 company: "we have no share count" and "the company has no shares" are different
                 statements and only one of them is ever true.

CURRENCY. Every price-based metric refuses outright unless the fundamentals are in USD, because
no FX conversion exists anywhere in this app. That refusal is reported as UNAVAILABLE with the
currency named, not hidden.
"""
import logging
from datetime import datetime, timezone

from providers.edgar_concepts import HISTORY_VALUE_FIELDS
from services import fundamentals_history_service as fh

logger = logging.getLogger(__name__)

OK = "OK"
IMPLAUSIBLE = "IMPLAUSIBLE"
UNAVAILABLE = "UNAVAILABLE"

# (low, high) bounds for each derived metric. Wide on purpose — see the module docstring.
# Anything outside these is a parsing or arithmetic fault, not an unusual company.
BOUNDS = {
    "market_cap":          (1e8, 1e13),      # $100m to $10tn
    "pe_ratio":            (0.0, 500.0),     # negative earnings handled separately, not clamped
    "enterprise_value":    (0.0, 1.2e13),
    "ev_to_ebit":          (0.0, 500.0),
    "ev_to_ebitda":        (0.0, 500.0),
    "fcf_yield_pct":       (-50.0, 50.0),
    "gross_margin_pct":    (-100.0, 100.0),
    "operating_margin_pct": (-200.0, 100.0),
    "fcf_margin_pct":      (-200.0, 100.0),
    "net_margin_pct":      (-500.0, 100.0),
    "roic_pct":            (-200.0, 500.0),
    "roe_pct":             (-500.0, 500.0),
    "interest_coverage":   (-1000.0, 10000.0),
    "net_debt_to_ebitda":  (-50.0, 50.0),
    "current_ratio":       (0.0, 50.0),
    "revenue_cagr_pct":    (-50.0, 200.0),
    "eps_cagr_pct":        (-100.0, 300.0),
    "share_change_pct":    (-90.0, 500.0),
    "buyback_yield_pct":   (0.0, 30.0),
    "dividend_yield_pct":  (0.0, 30.0),
    "rnd_intensity_pct":   (0.0, 100.0),
}

# ---------------------------------------------------------------------------------------------
# The v3 spec's own weights, reproduced exactly. Coverage is measured against these rather than
# against "how many fields are non-null", because the spec's Gate 4 is expressed in them: a BUY
# requires >= 75% coverage of Company Health, and the weight of an unmeasurable component leaves
# the denominator rather than scoring zero.
# ---------------------------------------------------------------------------------------------
COMPANY_HEALTH_CATEGORIES = {
    "profitability_returns": (25, ["gross_margin_pct", "operating_margin_pct", "net_margin_pct",
                                   "roic_pct", "roe_pct"]),
    "growth_durability":     (20, ["revenue_cagr_pct", "eps_cagr_pct", "revenue_consistency"]),
    "cashflow_quality":      (15, ["fcf_margin_pct", "fcf_to_net_income", "ocf_to_net_income"]),
    "balance_sheet":         (15, ["net_debt_to_ebitda", "interest_coverage", "current_ratio"]),
    # Renamed at Nick's instruction: the system infers competitive strength from its financial
    # footprint. It does not measure a moat, and does not claim to.
    "moat_evidence":         (15, ["gross_margin_stability", "roic_persistence",
                                   "revenue_consistency", "rnd_intensity_pct"]),
    "capital_allocation":    (10, ["buyback_yield_pct", "dividend_yield_pct", "share_change_pct"]),
}

VALUATION_METRICS = {
    "forward_pe_vs_history": 7,     # needs analyst estimates — none of the free sources carry them
    "forward_pe_vs_peers":   4,
    "ev_to_ebit":            4,
    "fcf_yield_pct":         6,
    "growth_adjusted_pe":    5,
    "intrinsic_value":       9,
}
COMPANY_HEALTH_BUY_GATE = 75.0     # the spec's own number


def _v(value):
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _div(a, b):
    a, b = _v(a), _v(b)
    if a is None or b in (None, 0):
        return None
    return a / b


def _pct(a, b):
    r = _div(a, b)
    return None if r is None else r * 100.0


def _verdict(name, value, reason_if_missing=None):
    """One metric's result. Never returns a bare number: the verdict travels with it."""
    if value is None:
        return {"value": None, "verdict": UNAVAILABLE,
                "reason": reason_if_missing or "not reported in the filings this app reads"}
    low, high = BOUNDS.get(name, (float("-inf"), float("inf")))
    if not (low <= value <= high):
        return {"value": round(value, 4), "verdict": IMPLAUSIBLE,
                "reason": f"outside the plausible range {low:g} to {high:g} — treat as a parsing "
                          f"or arithmetic fault until shown otherwise"}
    return {"value": round(value, 4), "verdict": OK, "reason": None}


def _cagr(latest, earliest, years):
    """Compound annual growth. Returns None when the sign flips or the base is non-positive —
    a CAGR from a negative starting value is not a number that means anything, and producing one
    anyway is how a nonsensical growth rate ends up on a page looking authoritative."""
    latest, earliest = _v(latest), _v(earliest)
    if latest is None or earliest is None or years <= 0:
        return None
    if earliest <= 0 or latest <= 0:
        return None
    return ((latest / earliest) ** (1.0 / years) - 1.0) * 100.0


def _consistency(series):
    """Fraction of year-on-year changes that were positive, as a percentage. The plainest honest
    measure of durability available from annual figures: it says how often the number went up,
    and nothing more."""
    values = [_v(x) for x in series if _v(x) is not None]
    if len(values) < 3:
        return None
    ups = sum(1 for a, b in zip(values, values[1:]) if a > b)   # series is newest-first
    return ups / (len(values) - 1) * 100.0


def _stability(series):
    """Coefficient of variation, inverted and expressed 0-100. Used for gross-margin stability:
    a company holding a 70% margin for a decade is fending competitors off, and that is the
    financial footprint of a moat rather than a measurement of one."""
    values = [_v(x) for x in series if _v(x) is not None]
    if len(values) < 3:
        return None
    mean = sum(values) / len(values)
    if mean == 0:
        return None
    var = sum((x - mean) ** 2 for x in values) / len(values)
    cv = (var ** 0.5) / abs(mean)
    return max(0.0, min(100.0, (1.0 - cv) * 100.0))


def validate_ticker(db, ticker: str, price: float | None = None,
                    as_of_filed: str | None = None, years: int = 6) -> dict:
    """Every v3 input for one company: computed, bounded, and verdicted.

    `price` is the latest close. When it is absent — or when the fundamentals are not in USD —
    every price-based metric reports UNAVAILABLE with the reason, rather than being skipped
    silently or computed against a currency it does not belong to.
    """
    ticker = ticker.upper()
    rows = fh.history(db, ticker, as_of_filed=as_of_filed, limit=years)
    out = {
        "ticker": ticker,
        "price": _v(price),
        "as_of_filed": as_of_filed or "today",
        "periods": len(rows),
        "period_ends": [r["period_end"] for r in rows],
        "currency": rows[0]["currency"] if rows else None,
        "taxonomy": rows[0]["taxonomy"] if rows else None,
        "metrics": {},
        "notes": [],
    }
    if not rows:
        out["notes"].append(
            "No stored fundamentals history for this ticker. Nothing below can be computed, and "
            "that is a gap in this app's data — not a statement about the company.")
        out["company_health_coverage_pct"] = 0.0
        out["valuation_coverage_pct"] = 0.0
        out["clears_75pct_gate"] = False
        return out

    latest = rows[0]
    currency = latest.get("currency")
    usd = currency == "USD"
    if not usd:
        out["notes"].append(
            f"Figures are in {currency or 'an unrecorded currency'}. No currency conversion "
            f"exists anywhere in this app, so every metric that multiplies a fundamental by a "
            f"US-dollar share price is reported UNAVAILABLE rather than converted at a guessed "
            f"rate. Ratios that divide {currency} by {currency} are unaffected.")

    g = latest.get                     # shorthand for the newest period
    revenue, net_income = _v(g("revenue")), _v(g("net_income"))
    op_income, gross_profit = _v(g("operating_income")), _v(g("gross_profit"))
    ocf, capex = _v(g("operating_cash_flow")), _v(g("capex"))
    fcf = (ocf - capex) if (ocf is not None and capex is not None) else None
    equity, debt, cash = _v(g("stockholders_equity")), _v(g("total_debt")), _v(g("total_cash"))
    dna, interest = _v(g("depreciation_amortisation")), _v(g("interest_expense"))
    ebitda = (op_income + dna) if (op_income is not None and dna is not None) else None

    # Share count: the cover-page count is the better input for market capitalisation (it is a
    # point-in-time count, which is what a market cap is), with the weighted-average diluted
    # count as the fallback. Which one was used is reported, because they are different things.
    shares = _v(g("shares_outstanding"))
    shares_basis = "cover-page shares outstanding (dei)"
    if shares is None:
        shares = _v(g("diluted_shares"))
        shares_basis = "weighted-average diluted shares (a full-year average, not a point-in-time count)"
    if shares is None:
        shares_basis = None
    out["shares_basis"] = shares_basis

    price_v = _v(price)
    no_price = ("no share price available" if price_v is None else
                f"fundamentals are in {currency}, not USD" if not usd else None)

    market_cap = (shares * price_v) if (shares and price_v and usd) else None
    ev = ((market_cap + (debt or 0.0) - (cash or 0.0)) if market_cap is not None else None)

    m = out["metrics"]

    # ---- valuation (price x fundamental) ----
    m["market_cap"] = _verdict("market_cap", market_cap,
                               no_price or "no share count in any filing this app reads")
    m["enterprise_value"] = _verdict("enterprise_value", ev,
                                     no_price or "market capitalisation unavailable")
    eps = _v(g("eps_diluted"))
    pe = (price_v / eps) if (price_v and eps and eps > 0 and usd) else None
    m["pe_ratio"] = _verdict(
        "pe_ratio", pe,
        no_price or ("diluted EPS is zero or negative, so a P/E would not be meaningful"
                     if eps is not None and eps <= 0 else "no diluted EPS reported"))
    m["ev_to_ebit"] = _verdict("ev_to_ebit", _div(ev, op_income) if op_income and op_income > 0 else None,
                               no_price or "operating income missing or not positive")
    m["ev_to_ebitda"] = _verdict("ev_to_ebitda", _div(ev, ebitda) if ebitda and ebitda > 0 else None,
                                 no_price or "EBITDA needs operating income and D&A; one is missing")
    m["fcf_yield_pct"] = _verdict("fcf_yield_pct", _pct(fcf, market_cap),
                                  no_price or "free cash flow needs operating cash flow and capex")

    # ---- profitability (currency-neutral: safe for every filer) ----
    m["gross_margin_pct"] = _verdict("gross_margin_pct", _pct(gross_profit, revenue))
    m["operating_margin_pct"] = _verdict("operating_margin_pct", _pct(op_income, revenue))
    m["net_margin_pct"] = _verdict("net_margin_pct", _pct(net_income, revenue))
    m["fcf_margin_pct"] = _verdict("fcf_margin_pct", _pct(fcf, revenue))
    invested = (equity + (debt or 0.0)) if equity is not None else None
    m["roic_pct"] = _verdict("roic_pct", _pct(op_income, invested) if invested else None,
                             "needs operating income and shareholders' equity")
    m["roe_pct"] = _verdict("roe_pct", _pct(net_income, equity) if equity else None)

    # ---- cash-flow quality ----
    m["fcf_to_net_income"] = _verdict("fcf_to_net_income", _div(fcf, net_income)
                                      if net_income and net_income > 0 else None,
                                      "needs free cash flow and positive net income")
    m["ocf_to_net_income"] = _verdict("ocf_to_net_income", _div(ocf, net_income)
                                      if net_income and net_income > 0 else None,
                                      "needs operating cash flow and positive net income")

    # ---- balance sheet ----
    net_debt = ((debt or 0.0) - (cash or 0.0)) if (debt is not None or cash is not None) else None
    m["net_debt_to_ebitda"] = _verdict("net_debt_to_ebitda",
                                       _div(net_debt, ebitda) if ebitda and ebitda > 0 else None,
                                       "needs net debt and EBITDA")
    m["interest_coverage"] = _verdict(
        "interest_coverage", _div(op_income, interest) if interest and interest > 0 else None,
        "interest expense is not separately tagged in these filings")
    m["current_ratio"] = _verdict("current_ratio",
                                  _div(g("current_assets"), g("current_liabilities")))

    # ---- growth and durability, across the whole history ----
    span_years = max(len(rows) - 1, 0)
    m["revenue_cagr_pct"] = _verdict(
        "revenue_cagr_pct", _cagr(revenue, rows[-1].get("revenue"), span_years),
        f"needs at least two annual periods (this ticker has {len(rows)})")
    m["eps_cagr_pct"] = _verdict(
        "eps_cagr_pct", _cagr(g("eps_diluted"), rows[-1].get("eps_diluted"), span_years),
        "needs diluted EPS in the earliest and latest periods, both positive")
    m["revenue_consistency"] = _verdict("revenue_consistency",
                                        _consistency([r.get("revenue") for r in rows]),
                                        "needs at least three annual periods")

    # ---- moat evidence (financial footprint, never presented as a measured moat) ----
    margins = [_pct(r.get("gross_profit"), r.get("revenue")) for r in rows]
    m["gross_margin_stability"] = _verdict("gross_margin_stability", _stability(margins),
                                           "needs gross profit in at least three periods")
    roics = [_pct(r.get("operating_income"),
                  (_v(r.get("stockholders_equity")) or 0) + (_v(r.get("total_debt")) or 0) or None)
             for r in rows]
    m["roic_persistence"] = _verdict("roic_persistence", _stability(roics),
                                     "needs operating income and equity in at least three periods")
    m["rnd_intensity_pct"] = _verdict(
        "rnd_intensity_pct", _pct(g("rnd_expense"), revenue),
        "no research and development expense is separately tagged — normal outside technology "
        "and pharmaceuticals, and NOT the same as spending nothing")

    # ---- capital allocation ----
    m["buyback_yield_pct"] = _verdict("buyback_yield_pct", _pct(g("buybacks"), market_cap),
                                      no_price or "no share-repurchase line reported")
    m["dividend_yield_pct"] = _verdict("dividend_yield_pct", _pct(g("dividends_paid"), market_cap),
                                       no_price or "no dividends-paid line reported")
    oldest_shares = rows[-1].get("diluted_shares") or rows[-1].get("shares_outstanding")
    newest_shares = g("diluted_shares") or g("shares_outstanding")
    m["share_change_pct"] = _verdict(
        "share_change_pct",
        _pct((_v(newest_shares) - _v(oldest_shares)), oldest_shares)
        if (_v(newest_shares) is not None and _v(oldest_shares)) else None,
        "needs a share count in both the earliest and latest periods")

    # ---- coverage, weighted exactly as the v3 spec weights it ----
    health, categories = 0.0, {}
    for name, (weight, inputs) in COMPANY_HEALTH_CATEGORIES.items():
        have = sum(1 for i in inputs if m.get(i, {}).get("verdict") == OK)
        share = have / len(inputs)
        categories[name] = {"weight": weight, "inputs": len(inputs), "available": have,
                            "coverage_pct": round(share * 100, 1),
                            "missing": [i for i in inputs if m.get(i, {}).get("verdict") != OK]}
        health += weight * share
    out["company_health_categories"] = categories
    out["company_health_coverage_pct"] = round(health, 1)
    out["clears_75pct_gate"] = health >= COMPANY_HEALTH_BUY_GATE

    # ---- the remaining valuation components, and the honest status of each ----
    # Growth-adjusted P/E (PEG). Derivable right now from two figures already computed above, so
    # it is computed rather than left blank.
    peg = None
    if (m["pe_ratio"]["verdict"] == OK and m["eps_cagr_pct"]["verdict"] == OK
            and (m["eps_cagr_pct"]["value"] or 0) > 0):
        peg = m["pe_ratio"]["value"] / m["eps_cagr_pct"]["value"]
    m["growth_adjusted_pe"] = _verdict(
        "growth_adjusted_pe", peg,
        "needs a positive P/E and a positive EPS growth rate; one of them is missing or negative")

    # Forward-looking valuation. NOT a gap in this app's plumbing — a gap in what free data
    # exists. Every source this app reads (SEC filings, Alpaca prices) is backward-looking, and
    # analyst estimates are the one thing neither carries. Reported explicitly so the missing 11%
    # is visible in the coverage figure rather than quietly excluded from the denominator.
    m["forward_pe_vs_history"] = _verdict(
        "forward_pe_vs_history", None,
        "needs forward analyst EPS estimates. No source this app reads carries them, so this is "
        "permanently unavailable unless an estimates provider is added.")
    m["forward_pe_vs_peers"] = _verdict(
        "forward_pe_vs_peers", None,
        "needs forward estimates for genuine sector peers. The other 49 tickers are not a sector, "
        "so even a trailing version would be labelled as weak rather than presented as peer data.")
    # Intrinsic value is deliberately NOT built yet. A discounted cash flow needs a growth rate,
    # a discount rate and a terminal assumption; change those three and it produces any answer
    # you like. It is the most authoritative-looking number on a page and the most arbitrary, so
    # it gets built with its assumptions displayed beside it or not at all.
    m["intrinsic_value"] = _verdict(
        "intrinsic_value", None,
        "not built. A discounted cash flow is assumption-driven — growth rate, discount rate and "
        "terminal value — and will only be added with those assumptions shown beside the answer.")

    val = 0.0
    for name, weight in VALUATION_METRICS.items():
        if m.get(name, {}).get("verdict") == OK:
            val += weight
    out["valuation_coverage_pct"] = round(val / sum(VALUATION_METRICS.values()) * 100, 1)
    out["valuation_unavailable"] = [n for n in VALUATION_METRICS
                                    if m.get(n, {}).get("verdict") != OK]

    out["implausible"] = [n for n, r in m.items() if r["verdict"] == IMPLAUSIBLE]
    out["fields_never_reported"] = [f for f in HISTORY_VALUE_FIELDS
                                    if all(r.get(f) is None for r in rows)]
    return out


def summarise(results: list) -> dict:
    """The one thing Build B2 has to answer: can Build C start, and if not, what is stopping it."""
    n = len(results)
    if not n:
        return {"tickers": 0}
    clearing = [r for r in results if r.get("clears_75pct_gate")]
    implausible = {r["ticker"]: r["implausible"] for r in results if r.get("implausible")}
    no_data = [r["ticker"] for r in results if not r.get("periods")]
    non_usd = [r["ticker"] for r in results if r.get("currency") not in (None, "USD")]

    missing_counts = {}
    for r in results:
        for cat, info in (r.get("company_health_categories") or {}).items():
            for miss in info["missing"]:
                missing_counts[miss] = missing_counts.get(miss, 0) + 1

    return {
        "tickers": n,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "clearing_the_75pct_gate": len(clearing),
        "blocked_by_coverage": n - len(clearing),
        "mean_company_health_coverage_pct": round(
            sum(r.get("company_health_coverage_pct") or 0 for r in results) / n, 1),
        "mean_valuation_coverage_pct": round(
            sum(r.get("valuation_coverage_pct") or 0 for r in results) / n, 1),
        "tickers_with_no_history": no_data,
        "tickers_not_in_usd": non_usd,
        "tickers_with_implausible_metrics": implausible,
        # Ranked so the single most productive fix is visible rather than buried in fifty rows.
        "most_commonly_missing_inputs": sorted(
            missing_counts.items(), key=lambda kv: -kv[1])[:12],
        "verdict": (
            "READY — coverage clears the gate on enough of the universe for Build C to proceed."
            if len(clearing) >= n * 0.8 and not implausible else
            "NOT READY — see blocked_by_coverage and tickers_with_implausible_metrics. An "
            "implausible metric is a bug to fix before any score consumes it, not a row to skip."),
    }
