-- LONG-ONLY SWING TRADING SIGNAL SYSTEM
-- Relational schema (SQLite). Phase 1 populates/uses: stocks, quotes, market_bars (partial),
-- strategy_versions, alerts (schema only). Remaining tables are created now so later phases
-- (2-9) don't require migrations, but stay empty until their phase is implemented.

PRAGMA foreign_keys = ON;

-- Static reference: the fixed 50-stock universe.
CREATE TABLE IF NOT EXISTS stocks (
    ticker      TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    sector      TEXT,
    industry    TEXT,
    exchange    TEXT,
    active      INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- OHLCV bars across timeframes (daily, 4h, 1h, 30m, 15m). Populated in Phase 2.
-- NOTE: ticker intentionally has NO foreign key to stocks(ticker) — this table also holds
-- bars for benchmark/regime symbols (SPY, QQQ, VIXY, sector ETFs) that are not part of the
-- tracked 50-stock universe. See `benchmark_symbols` below.
CREATE TABLE IF NOT EXISTS market_bars (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT NOT NULL,
    timeframe   TEXT NOT NULL,          -- '1Day','4Hour','1Hour','30Min','15Min'
    ts          TEXT NOT NULL,          -- bar timestamp, ISO 8601 UTC
    open        REAL NOT NULL,
    high        REAL NOT NULL,
    low         REAL NOT NULL,
    close       REAL NOT NULL,
    volume      REAL NOT NULL,
    trade_count INTEGER,
    vwap        REAL,
    source      TEXT NOT NULL DEFAULT 'alpaca',
    fetched_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(ticker, timeframe, ts)
);
CREATE INDEX IF NOT EXISTS idx_market_bars_ticker_tf_ts ON market_bars(ticker, timeframe, ts);

-- Latest trade/quote snapshots — one row per ticker, overwritten on each refresh, so the
-- dashboard always reflects the most recent poll. Historical snapshots aren't needed; signal
-- history (Phase 6) is what stores time-series of decisions.
CREATE TABLE IF NOT EXISTS quotes (
    ticker          TEXT PRIMARY KEY REFERENCES stocks(ticker),
    last_trade_px   REAL,
    last_trade_ts   TEXT,
    bid_px          REAL,
    bid_size        REAL,
    ask_px          REAL,
    ask_size        REAL,
    quote_ts        TEXT,
    daily_open      REAL,
    daily_high      REAL,
    daily_low       REAL,
    daily_close     REAL,
    daily_volume    REAL,
    prev_close      REAL,
    data_source     TEXT NOT NULL DEFAULT 'alpaca',
    data_status     TEXT NOT NULL,      -- LIVE / DELAYED / MARKET_CLOSED / STALE / UNAVAILABLE
    fetched_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Reference list of non-tradeable-universe symbols used for market regime and relative
-- strength (index proxies + sector ETFs). Not part of the 15-stock swing-trading universe.
CREATE TABLE IF NOT EXISTS benchmark_symbols (
    ticker      TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    category    TEXT NOT NULL   -- 'BROAD_MARKET' / 'VOLATILITY_PROXY' / 'SECTOR'
);

-- Computed technical indicators per ticker/timeframe/timestamp. Populated in Phase 2.
-- ticker has no FK for the same reason as market_bars (also stores SPY/QQQ/sector rows
-- needed for market regime and relative-strength calculations).
CREATE TABLE IF NOT EXISTS technical_indicators (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT NOT NULL,
    timeframe   TEXT NOT NULL,
    ts          TEXT NOT NULL,
    ema20 REAL, ema50 REAL, sma20 REAL, sma50 REAL, sma100 REAL, sma200 REAL,
    sma200_slope REAL,     -- % change of SMA200 over the prior 10 bars (trend direction, not just level)
    rsi14 REAL, rsi7 REAL,
    macd REAL, macd_signal REAL, macd_hist REAL,
    adx REAL, roc REAL, stoch_rsi REAL,
    atr14 REAL, atr_pct REAL,
    bb_upper REAL, bb_middle REAL, bb_lower REAL, bb_width REAL,
    hist_volatility REAL,
    volume REAL, avg_volume_20d REAL, relative_volume REAL, volume_trend TEXT,
    swing_high REAL, swing_low REAL,
    high_20d REAL, low_20d REAL, high_50d REAL, low_50d REAL,
    high_52w REAL, low_52w REAL,
    support_low REAL, support_high REAL,
    resistance_low REAL, resistance_high REAL,
    trend_label TEXT,       -- e.g. 'Strong Uptrend' / 'Uptrend' / 'Neutral' / 'Downtrend' / 'Strong Downtrend'
    trend_reasons TEXT,     -- JSON list of the specific conditions behind trend_label (transparency)
    sector_etf TEXT,        -- which sector ETF this ticker is compared against for relative strength
    rs_spy_5d REAL, rs_spy_20d REAL, rs_spy_50d REAL, rs_spy_200d REAL,
    rs_qqq_5d REAL, rs_qqq_20d REAL, rs_qqq_50d REAL, rs_qqq_200d REAL,
    rs_sector_5d REAL, rs_sector_20d REAL, rs_sector_50d REAL, rs_sector_200d REAL,
    bars_used INTEGER,      -- how many bars fed the calculation (transparency / low-data warning)
    computed_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(ticker, timeframe, ts)
);

-- Current live signal per ticker (one row each, overwritten). Populated in Phase 3.
CREATE TABLE IF NOT EXISTS signals (
    ticker              TEXT PRIMARY KEY REFERENCES stocks(ticker),
    score_total         INTEGER,
    score_long_trend    INTEGER,
    score_short_trend   INTEGER,
    score_momentum      INTEGER,
    score_rsi_pullback  INTEGER,
    score_volume        INTEGER,
    score_support_resistance INTEGER,
    score_relative_strength  INTEGER,
    score_market_regime INTEGER,
    score_news          INTEGER,
    score_earnings_risk INTEGER,
    signal_label        TEXT,          -- STRONG BUY / BUY / BUY ZONE-WATCH / WATCH / NO TRADE / AVOID
    strategy_setup      TEXT,          -- PULLBACK / BREAKOUT / DEEP_CORRECTION / NONE
    current_price       REAL,
    ideal_buy           REAL,
    buy_zone_low        REAL,
    buy_zone_high       REAL,
    max_entry           REAL,
    target1             REAL,
    primary_target      REAL,
    target3             REAL,
    expected_upside_pct REAL,
    long_term_quality   INTEGER,
    long_term_thesis    TEXT,          -- STRONG / HEALTHY / WATCH / DETERIORATING / BROKEN
    market_regime       TEXT,
    earnings_blackout   INTEGER NOT NULL DEFAULT 0,
    explanation         TEXT,
    strategy_version     TEXT,
    computed_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Append-only signal history — never overwritten. Populated in Phase 6.
CREATE TABLE IF NOT EXISTS signal_history (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker              TEXT NOT NULL REFERENCES stocks(ticker),
    ts                  TEXT NOT NULL DEFAULT (datetime('now')),
    score_total         INTEGER,
    signal_label        TEXT,
    current_price       REAL,
    ideal_buy           REAL,
    buy_zone_low        REAL,
    buy_zone_high       REAL,
    max_entry           REAL,
    target1             REAL,
    primary_target       REAL,
    target3              REAL,
    market_regime        TEXT,
    long_term_quality    INTEGER,
    long_term_thesis     TEXT,
    strategy_version     TEXT
);
CREATE INDEX IF NOT EXISTS idx_signal_history_ticker_ts ON signal_history(ticker, ts);

-- News items (Phase 4), sourced from Alpaca's news endpoint — the same vendor already in use,
-- so no new data provider is introduced.
-- NOTE on `sentiment`: Alpaca publishes no sentiment field. This column holds the output of the
-- transparent keyword classifier in providers/news_provider.py and is labeled as keyword-based
-- everywhere it is displayed. It is not, and is never presented as, NLP/AI sentiment analysis.
CREATE TABLE IF NOT EXISTS news (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT REFERENCES stocks(ticker),
    headline    TEXT NOT NULL,
    summary     TEXT,
    source      TEXT,
    url         TEXT,
    published_at TEXT,
    sentiment   TEXT,               -- BULLISH / BEARISH / NEUTRAL (keyword-derived)
    impact      TEXT,               -- HIGH / NORMAL (keyword-derived)
    impact_score INTEGER,
    fetched_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_news_ticker_published ON news(ticker, published_at);

-- Manual trade journal entries (Phase 5). Every row is a trade the user executed THEMSELVES in
-- a separate brokerage app and then recorded here by hand. This app has no broker write path.
-- The CHECK constraint enforces long-only at the database level: there is no SHORT side.
CREATE TABLE IF NOT EXISTS trades (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT NOT NULL REFERENCES stocks(ticker),
    side        TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
    trade_date  TEXT NOT NULL,
    quantity    REAL NOT NULL,
    price       REAL NOT NULL,
    fees        REAL NOT NULL DEFAULT 0,
    notes       TEXT,
    fx_rate_usd_gbp REAL,       -- optional rate at trade time, if the user recorded one
    linked_signal_id INTEGER REFERENCES signal_history(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_trades_ticker_date ON trades(ticker, trade_date);

-- Derived current holdings (could also be computed on the fly from trades; stored for speed
-- in later phases once partial-sale lot accounting is implemented).
CREATE TABLE IF NOT EXISTS portfolio_positions (
    ticker          TEXT PRIMARY KEY REFERENCES stocks(ticker),
    quantity        REAL NOT NULL DEFAULT 0,
    avg_entry_price REAL,
    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Fundamental data snapshots, sourced from a FundamentalDataProvider (Phase 4). Never fabricated:
-- every column here is nullable, and NULL means "the source did not report this", which the UI
-- renders as UNAVAILABLE rather than as a zero.
CREATE TABLE IF NOT EXISTS fundamentals (
    ticker              TEXT PRIMARY KEY REFERENCES stocks(ticker),
    revenue             REAL,
    revenue_prior       REAL,
    revenue_growth_pct  REAL,
    net_income          REAL,
    eps_diluted         REAL,
    eps_growth_pct      REAL,
    gross_profit        REAL,
    gross_margin_pct    REAL,
    operating_income    REAL,
    operating_margin_pct REAL,
    operating_cash_flow REAL,
    capex               REAL,
    free_cash_flow      REAL,
    fcf_margin_pct      REAL,
    roic_pct            REAL,
    total_debt          REAL,
    total_cash          REAL,
    stockholders_equity REAL,
    long_term_quality_score INTEGER,
    long_term_quality_breakdown TEXT,   -- JSON: per-criterion points + reason (transparency)
    fiscal_year         INTEGER,
    filed               TEXT,
    -- Which XBRL namespace the figures were read from (NOT which accounting standard the
    -- company uses — ASML files under IFRS but tags in us-gaap elements), and what currency
    -- they are in. Both
    -- used to be implicit assumptions ("US-GAAP, dollars") and both were wrong for the two 20-F
    -- filers in the universe, which returned no fundamentals at all as a result.
    taxonomy           TEXT,
    currency            TEXT,
    warnings_json       TEXT,
    source              TEXT,
    as_of               TEXT,
    fetched_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

-- MULTI-YEAR, POINT-IN-TIME FUNDAMENTALS (Build B).
--
-- WHY THIS EXISTS ALONGSIDE `fundamentals` RATHER THAN REPLACING IT. The table above is keyed on
-- ticker alone, so it holds exactly one fiscal year and every refresh overwrites the last. SEC's
-- companyfacts API returns the entire history on every call; the app was parsing all of it and
-- discarding everything but the newest year, which is why growth was limited to a single
-- year-over-year figure and every trend, CAGR and consistency measure was impossible.
--
-- THE THREE-PART KEY IS THE IMPORTANT PART. (ticker, period_end, filed) — not (ticker, period).
-- One fiscal year is reported more than once: in its own 10-K, again as a comparative in the
-- next one, and again if it is restated. Those versions differ. `filed` is the date the figure
-- became public and therefore the earliest date it may legitimately be used on. Scoring a past
-- date reads the newest row per period whose `filed` is on or before that date, so a 2026
-- restatement is structurally unreachable when scoring 2023. Keyed on (ticker, period) instead,
-- the newest version would always win and every backtest would quietly use the future.
--
-- `currency` IS NOT DECORATION. Two of the fifty companies file under IFRS in euros and kroner.
-- No FX conversion exists anywhere in this app. A euro revenue divided by a dollar market cap
-- gives a P/E wrong by the exchange rate and entirely plausible-looking, so anything combining
-- these values with a market price must check this column and report UNKNOWN when it is not USD.
--
-- Raw reported figures only — no margins, no growth rates, no ratios. Everything derived is
-- computed once in the shared scoring engine so the Dashboard and Signals pages cannot drift.
CREATE TABLE IF NOT EXISTS fundamentals_history (
    ticker              TEXT NOT NULL REFERENCES stocks(ticker),
    period_end          TEXT NOT NULL,      -- fiscal period end, ISO date
    filed               TEXT NOT NULL,      -- when THIS version became public
    fiscal_year         INTEGER,
    form                TEXT,               -- '10-K' | '20-F' | '40-F'
    taxonomy           TEXT,               -- 'us-gaap' | 'ifrs-full'
    currency            TEXT,               -- 'USD' | 'EUR' | 'DKK' | NULL if unknowable
    accn                TEXT,               -- SEC accession number, for traceability

    revenue                     REAL,
    gross_profit                REAL,
    operating_income            REAL,
    net_income                  REAL,
    rnd_expense                 REAL,
    interest_expense            REAL,
    depreciation_amortisation   REAL,
    eps_diluted                 REAL,
    eps_basic                   REAL,
    diluted_shares              REAL,
    basic_shares                REAL,
    shares_outstanding          REAL,   -- dei cover-page count: point-in-time, not weighted
    operating_cash_flow         REAL,
    capex                       REAL,
    buybacks                    REAL,
    dividends_paid              REAL,
    acquisitions                REAL,
    total_assets                REAL,
    current_assets              REAL,
    current_liabilities         REAL,
    total_liabilities           REAL,
    total_cash                  REAL,
    stockholders_equity         REAL,
    total_debt                  REAL,

    warnings_json       TEXT,
    source              TEXT,
    fetched_at          TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (ticker, period_end, filed)
);
-- The point-in-time read is "rows for this ticker filed on or before date X", so the index
-- follows that order rather than the primary key's.
CREATE INDEX IF NOT EXISTS idx_fundamentals_history_pit
    ON fundamentals_history(ticker, filed, period_end);

-- Build B2 data-validation runs. Fetching fifty companyfacts payloads from SEC takes minutes —
-- a synchronous request would be killed by the worker timeout — so it runs in the background
-- with visible progress, like every other long analysis in this app.
CREATE TABLE IF NOT EXISTS data_validation_runs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    config_json   TEXT,
    results_json  TEXT,
    status        TEXT NOT NULL DEFAULT 'running',
    error         TEXT,
    progress      TEXT
);

-- Earnings timing derived from SEC filing history. NOTE: `estimated_next_report` is an ESTIMATE
-- inferred from historical filing cadence, NOT a company-confirmed earnings date — the
-- confidence column and the UI both say so explicitly.
CREATE TABLE IF NOT EXISTS earnings_info (
    ticker              TEXT PRIMARY KEY REFERENCES stocks(ticker),
    last_period_end     TEXT,
    last_filed          TEXT,
    last_form           TEXT,
    median_days_between_reports REAL,
    estimated_next_report TEXT,
    estimate_confidence TEXT,
    warnings_json       TEXT,
    source              TEXT,
    fetched_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

-- FX rates used for the optional GBP display (Phase 5). Stored with an explicit source and
-- timestamp so a converted figure can always be traced to a real, dated rate — the app never
-- invents or assumes an exchange rate.
CREATE TABLE IF NOT EXISTS fx_rates (
    pair        TEXT PRIMARY KEY,       -- e.g. 'USDGBP'
    rate        REAL NOT NULL,
    source      TEXT NOT NULL,          -- 'manual' (user-entered) or a provider name
    as_of       TEXT NOT NULL,
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Forward-return tracking for past signals (Phase 6). One row per signal_history entry that has
-- been evaluated, so signal accuracy is measured against what actually happened afterwards.
CREATE TABLE IF NOT EXISTS signal_outcomes (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    signal_history_id   INTEGER NOT NULL REFERENCES signal_history(id),
    ticker              TEXT NOT NULL,
    signal_label        TEXT,
    score_total         REAL,
    signal_ts           TEXT NOT NULL,
    signal_price        REAL,
    horizon_days        INTEGER NOT NULL,
    evaluated_price     REAL,
    return_pct          REAL,
    evaluated_at        TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(signal_history_id, horizon_days)
);
CREATE INDEX IF NOT EXISTS idx_signal_outcomes_ticker ON signal_outcomes(ticker, horizon_days);

-- Market regime snapshots (SPY/QQQ/VIX + sector ETFs). Populated in Phase 2.
CREATE TABLE IF NOT EXISTS market_regime (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          TEXT NOT NULL DEFAULT (datetime('now')),
    spy_price REAL, spy_chg_pct REAL,
    qqq_price REAL, qqq_chg_pct REAL,
    vix_price REAL,             -- true CBOE VIX index; Alpaca does not provide this (see vix_status)
    vix_status TEXT,            -- 'UNAVAILABLE' (Alpaca only covers equities/ETFs, not CBOE indices)
    vix_proxy_ticker TEXT,      -- e.g. 'VIXY' — a real, Alpaca-tradable ETF proxy used instead
    vix_proxy_price REAL,
    vix_proxy_chg_5d_pct REAL,
    regime_score REAL,          -- raw weighted score behind the classification (transparency)
    regime      TEXT,       -- STRONG BULL / BULL / NEUTRAL / CAUTIOUS / BEAR
    detail_json TEXT        -- full component breakdown + sector ETF readings, JSON text
);

-- Backtest runs (Phase 7). Each row is one execution of the engine over a date range.
CREATE TABLE IF NOT EXISTS backtest_runs (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at          TEXT NOT NULL DEFAULT (datetime('now')),
    strategy_version    TEXT,
    tickers             TEXT,        -- JSON list actually tested
    start_date          TEXT,
    end_date            TEXT,
    config_json         TEXT,        -- entry/exit rules used, JSON
    results_json        TEXT,        -- full metrics + walk-forward segments, JSON
    total_trades        INTEGER,
    win_rate_pct        REAL,
    avg_return_pct      REAL,
    total_return_pct    REAL,
    max_drawdown_pct    REAL,
    limitations_json    TEXT,        -- what this run could NOT model, surfaced not hidden
    -- A full 5-year backtest takes ~1-2 minutes, far longer than gunicorn's 30s worker
    -- timeout, so runs execute in a background thread and the client polls this status.
    status              TEXT NOT NULL DEFAULT 'complete',   -- running / complete / failed
    error               TEXT,
    progress            TEXT         -- human-readable stage, so a long run is visibly alive
);

-- Individual simulated trades from a backtest run. Kept so any headline metric can be traced
-- back to the exact trades that produced it.
CREATE TABLE IF NOT EXISTS backtest_trades (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id              INTEGER NOT NULL REFERENCES backtest_runs(id),
    ticker              TEXT NOT NULL,
    signal_date         TEXT NOT NULL,   -- bar whose CLOSE produced the signal
    entry_date          TEXT NOT NULL,   -- next bar — fill is at ITS open, never the signal close
    entry_price         REAL NOT NULL,
    exit_date           TEXT,
    exit_price          REAL,
    exit_reason         TEXT,            -- TARGET / TIME_LIMIT / SIGNAL_EXIT / OPEN_AT_END
    score_at_entry      REAL,
    signal_label        TEXT,
    holding_days        INTEGER,
    return_pct          REAL,
    segment             TEXT             -- IN_SAMPLE / VALIDATION / OUT_OF_SAMPLE
);
CREATE INDEX IF NOT EXISTS idx_backtest_trades_run ON backtest_trades(run_id);

-- Strategy version registry — every signal row stores which version produced it.
CREATE TABLE IF NOT EXISTS strategy_versions (
    version         TEXT PRIMARY KEY,     -- e.g. 'v1.0'
    description     TEXT,
    weights_json    TEXT,                 -- 100-point scoring weights, JSON text
    params_json     TEXT,                 -- indicator parameters, JSON text
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Alerts (Phase 8). STRICTLY INFORMATIONAL: an alert never places, cancels or modifies an
-- order, and nothing in this app acts on one automatically. They exist to tell the human to go
-- and look at something.
CREATE TABLE IF NOT EXISTS alerts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT REFERENCES stocks(ticker),
    alert_type  TEXT NOT NULL,   -- BUY_SIGNAL / ENTER_BUY_ZONE / TARGET_REACHED / SIGNAL_LOST /
                                 -- EARNINGS_APPROACHING / THESIS_DETERIORATING / DATA_FEED_FAILURE
    severity    TEXT NOT NULL DEFAULT 'INFO',   -- INFO / IMPORTANT / URGENT
    message     TEXT NOT NULL,
    details_json TEXT,
    dedupe_key  TEXT,            -- stops the same live condition re-alerting on every refresh
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    acknowledged INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_alerts_dedupe ON alerts(dedupe_key, created_at);
CREATE INDEX IF NOT EXISTS idx_alerts_ack ON alerts(acknowledged, created_at);

-- Generated plain-English explanations (Phase 9). Stored so the exact wording shown to the user
-- at a point in time can be audited later, alongside which generator produced it.
CREATE TABLE IF NOT EXISTS explanations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT NOT NULL REFERENCES stocks(ticker),
    generator   TEXT NOT NULL,   -- 'rule-based' or an LLM model id — never ambiguous
    score_total REAL,
    signal_label TEXT,
    text        TEXT NOT NULL,
    source_facts_json TEXT,      -- the exact numbers the text was built from (auditability)
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(ticker, generator, score_total, signal_label)
);

-- Entry-quality experiment runs. Answers a question the backtest structurally cannot: whether a
-- BUY signal marks a better moment to buy something you then HOLD, versus buying on a schedule.
-- Same background-thread + polling shape as backtest_runs, for the same reason — the analysis
-- recomputes every signal across five years and takes far longer than a request may last.
CREATE TABLE IF NOT EXISTS entry_quality_runs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    config_json   TEXT,
    results_json  TEXT,
    status        TEXT NOT NULL DEFAULT 'running',   -- running / complete / failed
    error         TEXT,
    progress      TEXT          -- human-readable stage, so a long run is visibly alive
);

-- Selection-test runs: does the score help choose WHICH stock to buy, holding the buying date
-- constant? Same background-thread + polling shape as the other long-running analyses.
CREATE TABLE IF NOT EXISTS selection_runs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    config_json   TEXT,
    results_json  TEXT,
    status        TEXT NOT NULL DEFAULT 'running',
    error         TEXT,
    progress      TEXT          -- human-readable stage, so a long run is visibly alive
);

-- Editable strategies for the Strategy Lab. The baseline row is the control for every
-- comparison and is protected from edit and delete; every other row is one attempt at finding
-- something better, and the COUNT of them is what tells you how much multiple-testing luck is
-- baked into whichever looks best.
CREATE TABLE IF NOT EXISTS strategies (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    config_json  TEXT NOT NULL,
    is_baseline  INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 52-week / 200MA pattern test runs. Same background-thread + polling shape as the other
-- long-running analyses.
CREATE TABLE IF NOT EXISTS pattern_runs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    config_json   TEXT,
    results_json  TEXT,
    status        TEXT NOT NULL DEFAULT 'running',
    error         TEXT,
    progress      TEXT          -- human-readable stage, so a long run is visibly alive
);

-- Annual-reset backtest runs: every calendar year evaluated as an independent experiment.
CREATE TABLE IF NOT EXISTS annual_backtest_runs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    config_json   TEXT,
    results_json  TEXT,
    status        TEXT NOT NULL DEFAULT 'running',
    error         TEXT,
    progress      TEXT          -- human-readable stage, so a long run is visibly alive
);

-- Signal v2 readings, one row per ticker per computation, append-only.
--
-- WHY A SEPARATE TABLE RATHER THAN REUSING signal_history: the change detector compares the
-- FACTS behind a score (was the trend positive, was price above the 200 SMA, where was relative
-- strength) and not just the score itself. Two readings of 71 can mean completely different
-- things. signal_history has fixed v1.0 columns and no room for those facts, and widening it
-- would make one table answer two strategies' questions — which is the exact mistake v2 exists
-- to undo at the scoring level.
--
-- state_json holds the full snapshot build_state() produced. It is read back as the "previous"
-- reading on the next computation.
CREATE TABLE IF NOT EXISTS signal_v2_history (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker        TEXT NOT NULL REFERENCES stocks(ticker),
    ts            TEXT NOT NULL DEFAULT (datetime('now')),
    hold_quality  REAL,
    entry_quality REAL,
    hold_band     TEXT,
    entry_band    TEXT,
    action        TEXT,
    state_json    TEXT,          -- the full fact snapshot; the change detector's previous reading
    strategy_version TEXT
);
CREATE INDEX IF NOT EXISTS idx_signal_v2_history_ticker_ts ON signal_v2_history(ticker, ts);

-- The most recent v2 reading per ticker, overwritten on each computation.
--
-- SEPARATE FROM signal_v2_history ON PURPOSE, and the reason is not tidiness. The two answer
-- different questions and need different write rules:
--
--   signal_v2_latest  — what the page DISPLAYS. Must always be the newest thing computed, so it
--                       is overwritten every time. One row per ticker.
--   signal_v2_history — what the CHANGE DETECTOR compares against. Deliberately throttled to one
--                       snapshot every few hours, because a memory that records the same moment
--                       repeatedly remembers nothing.
--
-- Collapsing them would force one write rule onto both, and either the page shows six-hour-old
-- prices or the change detector compares 10:00:00 against 10:00:30 and reports that nothing ever
-- changes. This mirrors the v1 `signals` (overwritten) / `signal_history` (append-only) split.
CREATE TABLE IF NOT EXISTS signal_v2_latest (
    ticker        TEXT PRIMARY KEY REFERENCES stocks(ticker),
    computed_at   TEXT NOT NULL DEFAULT (datetime('now')),
    hold_quality  REAL,
    entry_quality REAL,
    action        TEXT,
    result_json   TEXT,          -- the full evaluate() payload the page renders
    strategy_version TEXT
);

-- One row per whole-universe v2 refresh, so the page can say "computing" instead of appearing
-- frozen, and so a crashed refresh is visible rather than leaving the page waiting forever.
CREATE TABLE IF NOT EXISTS signal_v2_runs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    finished_at   TEXT,
    status        TEXT NOT NULL DEFAULT 'running',
    progress      TEXT,
    error         TEXT
);
