"""
Build B2 — the data-validation run and its results.

Background-threaded for the same reason as every other long analysis here: fetching fifty SEC
companyfacts payloads takes minutes and a synchronous request would be killed by the worker
timeout, handing the page an HTML error where it expected JSON.

CONNECTION DISCIPLINE. Each ticker is one short cycle — fetch from SEC with NO database
connection held, then open a connection, write, validate, close. Neon closes idle connections
after a few minutes, and holding one open across fifty multi-megabyte downloads is precisely the
shape of the bug that lost two completed backtests at their final write.
"""
import json
import logging
import threading
import time

from flask import Blueprint, current_app, jsonify, request

from db import get_db
from providers.base import ProviderError
from services import data_validation_service as dv
from services import fundamentals_history_service as fh
from services.fundamentals_service import get_fundamentals_provider
from services.job_runner import (mark_complete, mark_failed, reap_stale_runs, short_lived_db,
                                 write_progress)
from services.signals_service import TICKERS

logger = logging.getLogger(__name__)
bp = Blueprint("api_validation", __name__, url_prefix="/api/data-validation")

TABLE = "data_validation_runs"

# SEC asks for no more than 10 requests a second. One ticker needs one companyfacts call, and
# each takes far longer than a tenth of a second to download anyway — this pause is here so the
# limit is respected by construction rather than by luck.
SEC_PAUSE_SECONDS = 0.3


def _last_close(db, ticker: str):
    """The most recent stored daily close.

    Deliberately read from the bars already in the database rather than fetched from Alpaca: it
    costs one row instead of a round trip per ticker, it works when the market is closed, and it
    makes this diagnostic independent of whether the data provider is reachable. It is the last
    stored close, and the page says so — it is not presented as a live price.
    """
    row = db.execute(
        "SELECT close, ts FROM market_bars WHERE ticker = ? AND timeframe = '1Day' "
        "ORDER BY ts DESC LIMIT 1", (ticker,)).fetchone()
    if row is None:
        return None, None
    d = dict(row)
    return d.get("close"), d.get("ts")


def _run_in_background(app, run_id: int, tickers: list, refresh: bool):
    with app.app_context():
        try:
            provider = get_fundamentals_provider()
            results, failures = [], []

            for i, ticker in enumerate(tickers, start=1):
                write_progress(TABLE, run_id, f"{i}/{len(tickers)} — {ticker}")

                # ---- SEC fetch, with NO database connection held ----
                records, fetch_error = None, None
                if refresh:
                    try:
                        records = provider.get_fundamentals_history(ticker)
                    except ProviderError as e:
                        fetch_error = str(e)
                    except Exception as e:  # noqa: BLE001 — one bad ticker must not end the run
                        fetch_error = f"Unexpected error reading SEC data: {e}"
                    time.sleep(SEC_PAUSE_SECONDS)

                # ---- short database cycle: store, price, validate ----
                try:
                    with short_lived_db() as db:
                        if records:
                            fh.store_history(db, ticker, records)
                        price, price_ts = _last_close(db, ticker)
                        result = dv.validate_ticker(db, ticker, price=price)
                    result["price_as_of"] = price_ts
                    if fetch_error:
                        result["notes"].append(
                            f"SEC refresh failed for this ticker ({fetch_error}). Any figures "
                            f"below come from previously stored filings, which are still valid — "
                            f"a filing does not expire — but nothing new was added.")
                        failures.append({"ticker": ticker, "error": fetch_error})
                    results.append(result)
                except Exception as e:  # noqa: BLE001
                    logger.exception("Validation failed for %s", ticker)
                    failures.append({"ticker": ticker, "error": str(e)})

            payload = {"summary": dv.summarise(results), "results": results,
                       "failures": failures,
                       "refreshed_from_sec": refresh,
                       "price_source": "last stored daily close from market_bars — not a live "
                                       "quote, and not fetched from Alpaca for this run"}
            mark_complete(TABLE, run_id, payload)
        except Exception as e:  # noqa: BLE001
            logger.exception("Data validation run %s failed", run_id)
            mark_failed(TABLE, run_id, str(e))


@bp.post("/runs")
def start_run():
    body = request.get_json(silent=True) or {}
    requested = [t.strip().upper() for t in (body.get("tickers") or []) if t.strip()]
    tickers = [t for t in requested if t in TICKERS] or sorted(TICKERS)
    refresh = bool(body.get("refresh", True))

    db = get_db()
    reap_stale_runs(db, TABLE)
    cur = db.execute(
        "INSERT INTO data_validation_runs (config_json, status, progress) VALUES (?, 'running', ?)",
        (json.dumps({"tickers": tickers, "refresh": refresh}), "Starting…"))
    db.commit()
    row = db.execute("SELECT MAX(id) AS id FROM data_validation_runs").fetchone()
    run_id = int(dict(row)["id"])

    threading.Thread(
        target=_run_in_background,
        args=(current_app._get_current_object(), run_id, tickers, refresh),
        daemon=True).start()
    return jsonify({"run_id": run_id, "tickers": len(tickers), "refresh": refresh,
                    "note": "Fetching fifty filings from SEC takes several minutes. Poll this "
                            "run for progress."}), 202


@bp.get("/runs")
def list_runs():
    db = get_db()
    reap_stale_runs(db, TABLE)
    rows = db.execute(
        "SELECT id, created_at, status, error, progress FROM data_validation_runs "
        "ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify({"runs": [dict(r) for r in rows]})


@bp.get("/runs/<int:run_id>")
def get_run(run_id):
    db = get_db()
    reap_stale_runs(db, TABLE)
    row = db.execute(
        "SELECT id, created_at, status, error, progress, config_json, results_json "
        "FROM data_validation_runs WHERE id = ?", (run_id,)).fetchone()
    if row is None:
        return jsonify({"error": f"No data-validation run with id {run_id}"}), 404
    d = dict(row)
    for key in ("config_json", "results_json"):
        try:
            d[key.replace("_json", "")] = json.loads(d.pop(key) or "null")
        except (TypeError, ValueError):
            d.pop(key, None)
            d[key.replace("_json", "")] = None
    return jsonify(d)
