// 52-week / 200MA pattern test. Background thread + polling, same as the other long analyses.

function tile(label, value, sub, cls) {
  return `<div class="stat-tile"><div class="st-label">${label}</div>
    <div class="st-value ${cls || ""}">${value}</div>
    ${sub ? `<div class="st-sub">${sub}</div>` : ""}</div>`;
}

function legRow(name, m) {
  if (!m || !m.trades) {
    return `<tr><td>${name}</td><td class="text-right">0</td><td colspan="5" class="text-dim">never triggered</td></tr>`;
  }
  return `<tr>
    <td>${name}</td>
    <td class="text-right">${m.trades}</td>
    <td class="text-right">${fmtNum(m.win_rate_pct, 1)}%</td>
    <td class="text-right ${pctClass(m.mean_pct)}">${fmtPct(m.mean_pct, 2)}</td>
    <td class="text-right ${pctClass(m.median_pct)}">${fmtPct(m.median_pct, 2)}</td>
    <td class="text-right">${fmtPct(m.best_pct, 1)} / ${fmtPct(m.worst_pct, 1)}</td>
    <td class="text-right">${fmtNum(m.avg_holding_days, 0)}d</td>
  </tr>`;
}

function renderPattern(r) {
  document.getElementById("pt-results").style.display = "";
  const ev = r.events || {};
  const c = r.clustering || {};
  const o = r.overall || {};

  document.getElementById("pt-events").innerHTML = [
    tile("52-week lows hit", ev.new_52w_low ?? "—", "days at a new yearly low"),
    tile("Times it could be acted on", ev.leg1_entries ?? "—", "step 1 entries — fewer, because a position may already be open"),
    tile("Total trades", o.trades ?? 0, "both legs"),
    // The clustering tile is amber whenever the entries are packed into a handful of months,
    // because that is the number that decides whether the rest of the page is meaningful.
    tile("Different months with entries", c.distinct_months ?? "—",
         c.first ? `${c.first} to ${c.last}` : "",
         (c.distinct_months !== undefined && c.distinct_months <= 6) ? "num-neg" : ""),
    tile("Busiest single month", c.busiest_month || "—",
         c.busiest_month_share_pct ? `${c.busiest_month_share_pct}% of all entries` : "",
         (c.busiest_month_share_pct >= 40) ? "num-neg" : ""),
    tile("Buy &amp; hold, same window", fmtPct((r.buy_and_hold_benchmark || {}).return_pct, 1),
         "own them and do nothing", pctClass((r.buy_and_hold_benchmark || {}).return_pct)),
  ].join("");

  document.getElementById("pt-warnings").innerHTML =
    (r.warnings || []).map((w) => `<div class="warn-banner">${w}</div>`).join("");

  document.getElementById("pt-legs").innerHTML =
    legRow("Leg 1 — bought the 52-week low", r.leg1) +
    legRow("Leg 2 — bought the break above the 200MA", r.leg2) +
    legRow("Both legs together", r.overall);

  const per = r.by_ticker || {};
  document.getElementById("pt-byticker").innerHTML = Object.keys(per)
    .sort((a, b) => (per[b].summary.mean_pct ?? -999) - (per[a].summary.mean_pct ?? -999))
    .map((t) => {
      const s = per[t].summary, e = per[t].events || {};
      return `<tr onclick="window.location.href='/stocks/${encodeURIComponent(t)}'">
        <td><span class="ticker-badge">${t}</span></td>
        <td class="text-right">${e.new_52w_low ?? 0}</td>
        <td class="text-right">${s.trades}</td>
        <td class="text-right">${s.win_rate_pct === null ? "—" : fmtNum(s.win_rate_pct, 1) + "%"}</td>
        <td class="text-right ${pctClass(s.mean_pct)}">${fmtPct(s.mean_pct, 2)}</td>
        <td class="text-right">${s.avg_holding_days === null ? "—" : fmtNum(s.avg_holding_days, 0) + "d"}</td>
      </tr>`;
    }).join("") || `<tr class="loading-row"><td colspan="6">No stock produced a trade.</td></tr>`;

  const trades = r.trades || [];
  document.getElementById("pt-trades").innerHTML = trades.length
    ? trades.map((t) => `<tr>
        <td><span class="ticker-badge">${t.ticker}</span></td>
        <td class="text-right">${t.leg}</td>
        <td>${t.entry_date}</td>
        <td class="text-right">${fmtPrice(t.entry_price)}</td>
        <td>${t.exit_date || "—"}</td>
        <td class="text-right">${fmtPrice(t.exit_price)}</td>
        <td style="font-size:11px;">${(t.exit_reason || "").replace(/_/g, " ").toLowerCase()}</td>
        <td class="text-right">${t.holding_days ?? "—"}</td>
        <td class="text-right ${pctClass(t.return_pct)}">${fmtPct(t.return_pct, 2)}</td>
      </tr>`).join("")
    : `<tr class="loading-row"><td colspan="9">The pattern never triggered.</td></tr>`;

  document.getElementById("pt-limitations").innerHTML =
    (r.limitations || []).map((l) => `<li>${l}</li>`).join("");
}

function syncRuleText() {
  document.getElementById("rule-2").textContent = document.getElementById("pt-sell200").value + "%";
  document.getElementById("rule-3").textContent = document.getElementById("pt-buy200").value + "%";
  document.getElementById("rule-4").textContent = document.getElementById("pt-sellhigh").value + "%";
}
["pt-sell200", "pt-buy200", "pt-sellhigh"].forEach((id) =>
  document.getElementById(id).addEventListener("input", syncRuleText));

document.getElementById("pt-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const btn = document.getElementById("pt-run-btn");
  const msg = document.getElementById("pt-message");
  btn.disabled = true;
  btn.textContent = "Running…";

  const started = Date.now();
  const tick = () => {
    const secs = Math.round((Date.now() - started) / 1000);
    msg.innerHTML = `<div class="warn-banner">Pattern test running — ${secs}s elapsed.</div>`;
  };
  tick();
  const ticker = setInterval(tick, 1000);

  try {
    const res = await fetch("/api/pattern-test/run", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        sell_pct_below_200ma: Number(document.getElementById("pt-sell200").value),
        buy_pct_above_200ma: Number(document.getElementById("pt-buy200").value),
        sell_pct_below_52w_high: Number(document.getElementById("pt-sellhigh").value),
      }),
    });
    const contentType = res.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      throw new Error(`Server returned ${res.status} instead of JSON — the request likely timed out at the gateway.`);
    }
    const startedRun = await res.json();
    if (startedRun.error) throw new Error(startedRun.error);
    const runId = startedRun.run_id;
    if (!runId) throw new Error("Server did not return a run id.");

    const deadline = Date.now() + 5 * 60 * 1000;
    let run = null;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 3000));
      const poll = await fetch(`/api/pattern-test/runs/${runId}`, { headers: { Accept: "application/json" } });
      if (!poll.ok) continue;
      run = await poll.json();
      if (run.status && run.status !== "running") break;
    }
    clearInterval(ticker);

    if (!run || run.status === "running") {
      throw new Error("Still running after 5 minutes. Reload shortly — the result is stored on the server.");
    }
    if (run.status === "failed") throw new Error(run.error || "The pattern test failed on the server.");

    msg.innerHTML = "";
    renderPattern(run.results || {});
  } catch (e) {
    clearInterval(ticker);
    msg.innerHTML = `<div class="error-banner">${e.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Run Pattern Test";
  }
});

(async function showLatest() {
  try {
    const list = await apiGet("/api/pattern-test/runs");
    const done = (list.runs || []).find((r) => r.status === "complete");
    if (!done) return;
    const run = await apiGet(`/api/pattern-test/runs/${done.id}`);
    if (run.results) renderPattern(run.results);
  } catch (e) {
    // Nothing stored yet is not an error worth showing.
  }
})();
