"""
Phase 7 backtest routes.

A full 5-year backtest recomputes indicators for every bar of every ticker — tens of thousands
of computations, taking one to two minutes. That is far longer than gunicorn's 30-second worker
timeout, which killed the request mid-run and returned an HTML error page (the frontend then
failed to parse it as JSON: "Unexpected token '<'").

So runs execute in a BACKGROUND THREAD: the POST returns a run_id immediately and the client
polls the run until its status leaves 'running'. The request itself finishes in milliseconds and
never trips any timeout.
"""
import json
import logging
import threading

from flask import Blueprint, jsonify, request

import database
from config import Config
from db import get_db
from services.backtest_service import persist_backtest, run_backtest
from services.bars_service import get_bars_df
from services.signals_service import TICKERS

logger = logging.getLogger(__name__)
bp = Blueprint("api_backtest", __name__, url_prefix="/api/backtest")


def _run_in_background(app, run_id: int, tickers: list, config: dict):
    """Executes the backtest on its own DB connection.

    A Flask `g`-scoped connection belongs to the request that created it and is closed when that
    request ends — which happens immediately here — so this thread must open its own.
    """
    with app.app_context():
        db = database.connect(Config.DATABASE_URL, Config.DATABASE_PATH)
        try:
            bars_by_ticker = {}
            needed = list(dict.fromkeys(
                tickers + (["SPY", "QQQ"] if config.get("use_regime", True) else [])))
            for t in needed:
                df, _meta = get_bars_df(db, t, "1Day")
                if not df.empty:
                    bars_by_ticker[t] = df.reset_index(drop=True)

            if not bars_by_ticker:
                raise RuntimeError("No historical bar data available to backtest.")

            result = run_backtest(db, tickers, bars_by_ticker, config)
            dates = sorted({t["entry_date"] for t in result.get("trades", [])})
            persist_backtest(db, result, dates[0] if dates else None,
                             dates[-1] if dates else None, run_id=run_id)
        except Exception as e:  # noqa: BLE001 — must be recorded, never lost silently
            logger.exception("Backtest run %s failed", run_id)
            try:
                db.rollback()
                db.execute("UPDATE backtest_runs SET status='failed', error=? WHERE id=?",
                           (str(e), run_id))
                db.commit()
            except Exception:  # noqa: BLE001
                pass
        finally:
            db.close()


@bp.get("/runs")
def list_runs():
    db = get_db()
    rows = db.execute(
        "SELECT id, created_at, strategy_version, tickers, start_date, end_date, total_trades, "
        "win_rate_pct, avg_return_pct, total_return_pct, max_drawdown_pct, status, error "
        "FROM backtest_runs ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify({"runs": [dict(r) for r in rows]})


@bp.get("/runs/<int:run_id>")
def get_run(run_id):
    db = get_db()
    row = db.execute("SELECT * FROM backtest_runs WHERE id = ?", (run_id,)).fetchone()
    if not row:
        return jsonify({"error": "Run not found"}), 404
    run = dict(row)
    try:
        run["results"] = json.loads(run.pop("results_json") or "{}")
    except (TypeError, ValueError):
        run["results"] = {}
    trades = db.execute(
        "SELECT * FROM backtest_trades WHERE run_id = ? ORDER BY entry_date DESC LIMIT 300",
        (run_id,)).fetchall()
    run["trades"] = [dict(t) for t in trades]
    return jsonify(run)


@bp.post("/run")
def run():
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca API credentials not configured — no historical bars "
                                 "available to backtest against."}), 200

    payload = request.get_json(silent=True) or {}
    tickers = [t for t in (payload.get("tickers") or TICKERS) if t in TICKERS]
    if not tickers:
        return jsonify({"error": "No valid tickers from the tracked universe were requested."}), 400

    config = {
        "max_holding_days": int(payload.get("max_holding_days", 40)),
        "slippage_pct": float(payload.get("slippage_pct", 0.0)),
        "commission_per_trade": float(payload.get("commission_per_trade", 0.0)),
        "min_score": float(payload.get("min_score", 0)),
        "exit_on_signal": bool(payload.get("exit_on_signal", True)),
        "use_regime": bool(payload.get("use_regime", True)),
    }

    db = get_db()
    run_id = db.insert_returning_id(
        "INSERT INTO backtest_runs (strategy_version, tickers, config_json, status) "
        "VALUES (?, ?, ?, 'running')",
        ("v1.0", json.dumps(tickers), json.dumps(config)))
    db.commit()

    from flask import current_app
    thread = threading.Thread(
        target=_run_in_background,
        args=(current_app._get_current_object(), run_id, tickers, config),
        daemon=True)
    thread.start()

    # Returns immediately — the client polls /runs/<id> until status != 'running'.
    return jsonify({"run_id": run_id, "status": "running",
                    "message": "Backtest started. This takes 1-2 minutes for 5 years of data."}), 202
