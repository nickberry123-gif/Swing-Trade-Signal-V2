"""
Phase 7: backtesting engine with strict look-ahead-bias prevention, plus walk-forward
segmentation.

=== THE LOOK-AHEAD RULES (the entire point of this module) ===

A backtest that peeks at the future produces beautiful, worthless numbers. Three rules are
enforced structurally here, not by convention:

1. **Signals see only the past.** At decision bar `i`, indicators are computed from
   `df.iloc[:i+1]` — a physical slice. Bar i+1 onward does not exist in that call, so no
   indicator can accidentally reference it. This is why the engine recomputes indicators per
   bar instead of computing them once over the full history and indexing backwards: the latter
   is far faster and is exactly how look-ahead silently creeps in.

2. **You cannot trade the close you just observed.** A signal generated from bar i's close is
   filled at bar **i+1's OPEN**. Filling at bar i's close would assume you knew the closing
   price before it printed.

3. **Exits are evaluated on bars strictly after entry**, using that bar's high/low. A target
   hit intrabar fills at the target price, not at a close you couldn't have known.

=== WHAT THIS ENGINE DELIBERATELY DOES NOT MODEL ===

Reported in `limitations` on every run rather than buried:
- No slippage or commission by default (configurable).
- Intrabar path is unknown: if a bar's range spans the target, the target is assumed filled.
- Survivorship: the 15-stock universe is today's list. Backtesting it over past years embeds
  hindsight about which companies did well — this flatters results and cannot be removed
  without a point-in-time universe.
- Market regime during backtest uses SPY/QQQ trend only (sector breadth and the VIXY volatility
  proxy are excluded for tractability), so backtest scores differ slightly from live scores.
- Fundamentals/news/earnings components are excluded entirely: point-in-time fundamentals and
  historical news are not available from the sources this app uses, and back-filling today's
  values into past dates would be textbook look-ahead.
"""
import json
from datetime import datetime, timezone

import pandas as pd

from services.indicators import (_last_or_none, classify_trend, classify_volume_trend,
                                 compute_adx, compute_all_indicators, compute_atr, compute_macd,
                                 compute_rsi, compute_support_resistance, find_swing_points)
from services.signal_engine import (STRATEGY_VERSION, classify_signal, classify_strategy_setup,
                                    compute_price_levels, score_long_term_trend,
                                    score_market_regime, score_momentum, score_relative_strength,
                                    score_rsi_pullback, score_short_term_trend,
                                    score_support_resistance, score_volume)

MIN_WARMUP_BARS = 210          # SMA200 + slope needs this much history before any signal is valid
DEFAULT_MAX_HOLDING_DAYS = 40  # swing trade, not buy-and-hold
ENTRY_LABELS = ("BUY", "STRONG BUY")
EXIT_LABELS = ("AVOID", "NO TRADE")

LIMITATIONS = [
    "No slippage or commission modelled unless configured — real fills are worse than these.",
    "Intrabar price path is unknown: when a bar's range spans a target, the target is assumed "
    "filled at its exact price.",
    "SURVIVORSHIP BIAS: the 15-stock universe is today's list of winners. Testing it on past "
    "years embeds hindsight about which companies succeeded and inflates results. This cannot "
    "be removed without a point-in-time universe, which this app does not have.",
    "Market regime uses SPY/QQQ trend only during backtests (sector breadth and the VIXY "
    "volatility proxy are excluded for speed), so backtest scores differ slightly from live.",
    "News, earnings-risk and fundamentals scoring are excluded: point-in-time versions of that "
    "data are not available, and using today's values on past dates would be look-ahead bias.",
    "Past performance does not predict future returns. A profitable backtest is a hypothesis, "
    "not evidence.",
]


def _score_from_indicators(ind: dict, regime: dict) -> dict:
    """Recreate the live scoring using only components computable from point-in-time price data.

    Relative strength, news, earnings and fundamentals are omitted — see LIMITATIONS. Because
    signal_engine derives the achievable maximum from what was actually scored, the resulting
    labels remain internally consistent rather than being penalised against an unreachable 100.
    """
    lt, _ = score_long_term_trend(ind)
    st, _ = score_short_term_trend(ind)
    mom, _ = score_momentum(ind)
    pull, _ = score_rsi_pullback(ind)
    vol, _ = score_volume(ind)
    sr, _ = score_support_resistance(ind)
    rs, _ = score_relative_strength({})          # no point-in-time benchmark series here
    reg, _ = score_market_regime(regime)

    components = {"long_trend": lt, "short_trend": st, "momentum": mom, "rsi_pullback": pull,
                  "volume": vol, "support_resistance": sr, "relative_strength": rs,
                  "market_regime": reg}
    weights = {"long_trend": 20, "short_trend": 10, "momentum": 15, "rsi_pullback": 10,
               "volume": 10, "support_resistance": 10, "relative_strength": 10,
               "market_regime": 5}

    total = round(sum(v for v in components.values() if v is not None), 2)
    max_available = sum(w for k, w in weights.items() if components.get(k) is not None)
    # Normalise to a 100-point scale so thresholds mean the same thing as they do live.
    normalised = round(total / max_available * 100, 2) if max_available else 0.0
    label, _ = classify_signal(normalised, (regime or {}).get("regime"))
    return {"score_raw": total, "score_max": max_available, "score": normalised, "label": label}


def _precompute(df: pd.DataFrame) -> dict:
    """Compute every scored indicator ONCE across the whole series.

    === WHY THIS IS STILL LOOK-AHEAD-FREE ===

    Recomputing from a slice on every bar is O(n²) and made a 5-year run take minutes. The fast
    path is safe because every indicator here is *inherently backward-looking*: pandas `rolling`
    and `ewm` at position i use only positions ≤ i. `close.rolling(200).mean()[i]` is identical
    whether it was computed over the full series or over `close[:i+1]` — the future rows simply
    do not participate in that cell's value.

    The ONE construct that is NOT naturally causal is swing-point detection, which needs bars on
    both sides to confirm a pivot. That is handled in `_indicators_at` by discarding any swing
    point that would not yet have been confirmed as of bar i — never here.

    `test_fast_path_matches_the_slow_slice_path` asserts cell-for-cell equality against the
    original per-bar slicing implementation, so this optimisation cannot silently drift.
    """
    close, high, low, volume = df["close"], df["high"], df["low"], df["volume"]
    rsi14 = compute_rsi(close, 14)
    macd, macd_signal, macd_hist = compute_macd(close)
    swing_high_mask, swing_low_mask = find_swing_points(high, low, window=2)

    return {
        "ema20": close.ewm(span=20, adjust=False).mean(),
        "ema50": close.ewm(span=50, adjust=False).mean(),
        "sma50": close.rolling(50).mean(),
        "sma200": close.rolling(200).mean(),
        "rsi14": rsi14,
        "macd": macd, "macd_signal": macd_signal, "macd_hist": macd_hist,
        "adx": compute_adx(high, low, close, 14),
        "roc": (close - close.shift(10)) / close.shift(10) * 100,
        "atr14": compute_atr(high, low, close, 14),
        "avg_vol20": volume.rolling(20).mean(),
        "avg_vol5": volume.rolling(5).mean(),
        "high_20d": high.rolling(20).max(), "low_20d": low.rolling(20).min(),
        "high_50d": high.rolling(50).max(), "low_50d": low.rolling(50).min(),
        "high_52w": high.rolling(252, min_periods=1).max(),
        "swing_high_mask": swing_high_mask, "swing_low_mask": swing_low_mask,
    }


def _v(series, i):
    """Scalar at position i, or None when absent/NaN — matches _last_or_none's contract."""
    import math
    if series is None:
        return None
    val = series.iloc[i]
    if val is None or (isinstance(val, float) and math.isnan(val)):
        return None
    return round(float(val), 6)


def _indicators_at(df: pd.DataFrame, pre: dict, i: int) -> dict:
    """Build the indicator dict as it would have looked at the close of bar i."""
    price = float(df["close"].iloc[i])
    sma50, sma200 = _v(pre["sma50"], i), _v(pre["sma200"], i)

    sma200_slope = None
    if i >= 210:
        prev, cur = pre["sma200"].iloc[i - 10], pre["sma200"].iloc[i]
        if prev and not pd.isna(prev) and prev != 0 and not pd.isna(cur):
            sma200_slope = round(float((cur - prev) / prev * 100), 4)

    # Swing points are only usable once confirmed by the bars that follow them. As of bar i, the
    # last confirmable pivot sits at i-2 (window=2), so anything later is discarded — this is the
    # single place the fast path must think about the future, and it refuses to look.
    window = df.iloc[:i + 1]
    sh = pre["swing_high_mask"].iloc[:i + 1].copy()
    sl = pre["swing_low_mask"].iloc[:i + 1].copy()
    if len(sh) > 2:
        sh.iloc[-2:] = False
        sl.iloc[-2:] = False

    atr14 = _v(pre["atr14"], i)
    support_low, support_high, resistance_low, resistance_high = compute_support_resistance(
        window, sh, sl, sma50, sma200,
        _v(pre["high_20d"], i), _v(pre["low_20d"], i),
        _v(pre["high_50d"], i), _v(pre["low_50d"], i),
        price, atr14,
    )

    avg20, avg5 = _v(pre["avg_vol20"], i), _v(pre["avg_vol5"], i)
    rel_vol = round(float(df["volume"].iloc[i]) / avg20, 4) if avg20 else None
    trend_label, _reasons = classify_trend(price, sma50, sma200, sma200_slope)

    return {
        "reference_price": price,
        "ema20": _v(pre["ema20"], i), "ema50": _v(pre["ema50"], i),
        "sma50": sma50, "sma200": sma200, "sma200_slope": sma200_slope,
        "rsi14": _v(pre["rsi14"], i),
        "macd": _v(pre["macd"], i), "macd_signal": _v(pre["macd_signal"], i),
        "macd_hist": _v(pre["macd_hist"], i),
        "adx": _v(pre["adx"], i), "roc": _v(pre["roc"], i), "atr14": atr14,
        "relative_volume": rel_vol,
        "volume_trend": classify_volume_trend(df["volume"], avg5, avg20),
        "high_20d": _v(pre["high_20d"], i), "high_52w": _v(pre["high_52w"], i),
        "swing_high": _last_or_none(df["high"].iloc[:i + 1][sh]),
        "support_low": round(support_low, 4) if support_low is not None else None,
        "support_high": round(support_high, 4) if support_high is not None else None,
        "resistance_low": round(resistance_low, 4) if resistance_low is not None else None,
        "resistance_high": round(resistance_high, 4) if resistance_high is not None else None,
        "trend_label": trend_label,
        "bars_used": i + 1,
    }


def _regime_by_date(bars_by_ticker: dict) -> dict:
    """Point-in-time market regime for every date, computed ONCE and shared across all tickers.

    Uses SPY/QQQ trend only (see LIMITATIONS). Each date's regime is computed from bars up to
    and including that date — same slicing discipline as the stock signals.
    """
    spy = bars_by_ticker.get("SPY")
    qqq = bars_by_ticker.get("QQQ")
    if spy is None or spy.empty:
        return {}

    # Rolling means are causal, so computing them once over the full series gives exactly the
    # same value at position i as slicing would — but in O(n) instead of O(n^2).
    spy_sma200 = spy["close"].rolling(200).mean()
    spy_sma50 = spy["close"].rolling(50).mean()
    qqq_sma200 = qqq["close"].rolling(200).mean() if qqq is not None and not qqq.empty else None
    qqq_index = {t: j for j, t in enumerate(qqq["ts"])} if qqq is not None and not qqq.empty else {}

    out = {}
    for i in range(MIN_WARMUP_BARS, len(spy)):
        date = spy["ts"].iloc[i]
        price = float(spy["close"].iloc[i])
        score = 0.0
        s200, s50 = spy_sma200.iloc[i], spy_sma50.iloc[i]
        if not pd.isna(s200):
            score += 3 if price > s200 else -3
        if not pd.isna(s50):
            score += 2 if price > s50 else -2

        j = qqq_index.get(date)
        if j is not None and qqq_sma200 is not None and j >= MIN_WARMUP_BARS:
            q200 = qqq_sma200.iloc[j]
            if not pd.isna(q200):
                score += 2 if float(qqq["close"].iloc[j]) > q200 else -2

        label = ("STRONG BULL" if score >= 6 else "BULL" if score >= 3 else
                 "NEUTRAL" if score >= -2 else "CAUTIOUS" if score >= -5 else "BEAR")
        out[date] = {"regime": label, "regime_score": score}
    return out


def _simulate_ticker(ticker: str, df: pd.DataFrame, regime_by_date: dict, config: dict) -> list:
    """Replay one ticker bar by bar. Returns a list of completed (or still-open) trades."""
    max_hold = config.get("max_holding_days", DEFAULT_MAX_HOLDING_DAYS)
    slippage = float(config.get("slippage_pct", 0.0)) / 100.0
    commission = float(config.get("commission_per_trade", 0.0))
    min_score = float(config.get("min_score", 0))

    trades = []
    open_trade = None
    n = len(df)
    pre = _precompute(df)   # one pass; see _precompute for why this stays look-ahead-free

    for i in range(MIN_WARMUP_BARS, n - 1):   # -1: an entry needs a NEXT bar to fill against
        bar_date = df["ts"].iloc[i]

        # ---- exit handling first, so a position is never double-entered ----
        if open_trade is not None:
            high = float(df["high"].iloc[i])
            low = float(df["low"].iloc[i])
            close = float(df["close"].iloc[i])
            held = i - open_trade["_entry_index"]
            target = open_trade["_target"]

            exit_price = exit_reason = None
            if target and high >= target:
                # Intrabar fill assumed at the target — flagged in LIMITATIONS.
                exit_price, exit_reason = target, "TARGET"
            elif held >= max_hold:
                exit_price, exit_reason = close, "TIME_LIMIT"

            if exit_price is None and config.get("exit_on_signal", True):
                ind_now = _indicators_at(df, pre, i)
                scored = _score_from_indicators(ind_now, regime_by_date.get(bar_date, {}))
                if scored["label"] in EXIT_LABELS:
                    exit_price, exit_reason = close, "SIGNAL_EXIT"

            if exit_price is not None:
                fill = exit_price * (1 - slippage)
                gross = (fill - open_trade["entry_price"]) * 1.0
                net_pct = ((fill - open_trade["entry_price"]) / open_trade["entry_price"] * 100
                           - (commission * 2 / open_trade["entry_price"] * 100))
                open_trade.update({
                    "exit_date": bar_date, "exit_price": round(fill, 4),
                    "exit_reason": exit_reason, "holding_days": held,
                    "return_pct": round(net_pct, 4),
                })
                open_trade.pop("_entry_index", None)
                open_trade.pop("_target", None)
                trades.append(open_trade)
                open_trade = None
            continue  # one action per bar; never exit and re-enter on the same bar

        # ---- entry decision, using ONLY bars up to and including i ----
        ind = _indicators_at(df, pre, i)
        if not ind.get("bars_used"):
            continue

        scored = _score_from_indicators(ind, regime_by_date.get(bar_date, {}))
        if scored["label"] not in ENTRY_LABELS or scored["score"] < min_score:
            continue

        levels = compute_price_levels(ind)
        max_entry = levels.get("max_entry")
        target = levels.get("primary_target")

        # Fill at the NEXT bar's open — you cannot trade the close you just watched print.
        next_open = float(df["open"].iloc[i + 1])
        if max_entry is not None and next_open > max_entry:
            continue  # gapped above the acceptable entry; skip rather than chase

        entry_price = next_open * (1 + slippage)
        open_trade = {
            "ticker": ticker,
            "signal_date": bar_date,
            "entry_date": df["ts"].iloc[i + 1],
            "entry_price": round(entry_price, 4),
            "score_at_entry": scored["score"],
            "signal_label": scored["label"],
            "strategy_setup": classify_strategy_setup(ind),
            "_entry_index": i + 1,
            "_target": target,
        }

    if open_trade is not None:
        last_close = float(df["close"].iloc[-1])
        open_trade.update({
            "exit_date": df["ts"].iloc[-1], "exit_price": round(last_close, 4),
            "exit_reason": "OPEN_AT_END",
            "holding_days": (len(df) - 1) - open_trade["_entry_index"],
            "return_pct": round((last_close - open_trade["entry_price"])
                                / open_trade["entry_price"] * 100, 4),
        })
        open_trade.pop("_entry_index", None)
        open_trade.pop("_target", None)
        trades.append(open_trade)

    return trades


def _metrics(trades: list) -> dict:
    if not trades:
        return {"trades": 0, "win_rate_pct": None, "avg_return_pct": None,
                "total_return_pct": None, "max_drawdown_pct": None, "profit_factor": None,
                "avg_holding_days": None, "best_pct": None, "worst_pct": None}

    returns = [t["return_pct"] for t in trades if t.get("return_pct") is not None]
    wins = [r for r in returns if r > 0]
    losses = [r for r in returns if r <= 0]

    # Equity curve from sequentially compounding each trade — treats the account as fully
    # allocated to one trade at a time, which is the simplest defensible assumption.
    equity, peak, max_dd = 1.0, 1.0, 0.0
    for r in sorted(trades, key=lambda t: t.get("entry_date") or ""):
        equity *= (1 + (r.get("return_pct") or 0) / 100)
        peak = max(peak, equity)
        max_dd = min(max_dd, (equity - peak) / peak * 100)

    gross_win = sum(wins)
    gross_loss = abs(sum(losses))
    holds = [t["holding_days"] for t in trades if t.get("holding_days") is not None]

    return {
        "trades": len(trades),
        "win_rate_pct": round(len(wins) / len(returns) * 100, 1) if returns else None,
        "avg_return_pct": round(sum(returns) / len(returns), 2) if returns else None,
        "total_return_pct": round((equity - 1) * 100, 2),
        "max_drawdown_pct": round(max_dd, 2),
        "profit_factor": round(gross_win / gross_loss, 2) if gross_loss else None,
        "avg_holding_days": round(sum(holds) / len(holds), 1) if holds else None,
        "best_pct": round(max(returns), 2) if returns else None,
        "worst_pct": round(min(returns), 2) if returns else None,
    }


def _assign_segments(trades: list, dates: list) -> list:
    """Walk-forward split: first 50% in-sample, next 25% validation, final 25% out-of-sample.

    IMPORTANT HONESTY NOTE: strategy v1.0's weights are FIXED, not fitted to this data. So these
    segments do not prove absence of overfitting the way they would for an optimised model —
    nothing was optimised. What they DO show is whether the strategy holds up across different
    market periods, which is the question that actually matters here. If a future phase starts
    tuning weights, the tuning must happen on in-sample only and the out-of-sample segment must
    stay untouched, or these labels become meaningless.
    """
    if not dates:
        return trades
    ordered = sorted(dates)
    i1 = ordered[int(len(ordered) * 0.50)]
    i2 = ordered[int(len(ordered) * 0.75)]
    for t in trades:
        d = t.get("entry_date") or ""
        t["segment"] = ("IN_SAMPLE" if d < i1 else "VALIDATION" if d < i2 else "OUT_OF_SAMPLE")
    return trades


def _buy_and_hold(bars_by_ticker: dict, tickers: list) -> dict:
    """Benchmark: equal-weight buy-and-hold over the same window. A strategy that cannot beat
    simply holding these companies is not worth the effort or the risk."""
    rets = []
    for t in tickers:
        df = bars_by_ticker.get(t)
        if df is None or len(df) <= MIN_WARMUP_BARS:
            continue
        start = float(df["close"].iloc[MIN_WARMUP_BARS])
        end = float(df["close"].iloc[-1])
        if start:
            rets.append((end - start) / start * 100)
    if not rets:
        return {"return_pct": None, "tickers": 0}
    return {"return_pct": round(sum(rets) / len(rets), 2), "tickers": len(rets)}


def run_backtest(db, tickers: list, bars_by_ticker: dict, config: dict | None = None) -> dict:
    """Main entry point. `bars_by_ticker` maps ticker -> ascending OHLCV DataFrame (including
    SPY/QQQ for the regime). Returns the full result dict; persistence is the caller's job."""
    config = config or {}
    regime_by_date = _regime_by_date(bars_by_ticker) if config.get("use_regime", True) else {}

    all_trades = []
    skipped = {}
    for ticker in tickers:
        df = bars_by_ticker.get(ticker)
        if df is None or len(df) < MIN_WARMUP_BARS + 5:
            skipped[ticker] = (f"needs at least {MIN_WARMUP_BARS + 5} daily bars, "
                               f"has {0 if df is None else len(df)}")
            continue
        all_trades.extend(_simulate_ticker(ticker, df.reset_index(drop=True), regime_by_date,
                                           config))

    dates = sorted({t["entry_date"] for t in all_trades}) if all_trades else []
    all_trades = _assign_segments(all_trades, dates)

    by_segment = {}
    for seg in ("IN_SAMPLE", "VALIDATION", "OUT_OF_SAMPLE"):
        by_segment[seg] = _metrics([t for t in all_trades if t.get("segment") == seg])

    tested = [t for t in tickers if t not in skipped]
    result = {
        "strategy_version": STRATEGY_VERSION,
        "tickers_tested": tested,
        "tickers_skipped": skipped,
        "config": {
            "max_holding_days": config.get("max_holding_days", DEFAULT_MAX_HOLDING_DAYS),
            "slippage_pct": config.get("slippage_pct", 0.0),
            "commission_per_trade": config.get("commission_per_trade", 0.0),
            "min_score": config.get("min_score", 0),
            "exit_on_signal": config.get("exit_on_signal", True),
            "entry_rule": "Fill at the NEXT bar's open after a BUY/STRONG BUY close.",
            "exit_rules": "Primary target hit, max holding days, or signal degrading to "
                          "NO TRADE/AVOID. THERE IS NO STOP-LOSS — by design.",
        },
        "overall": _metrics(all_trades),
        "by_segment": by_segment,
        "by_ticker": {t: _metrics([x for x in all_trades if x["ticker"] == t]) for t in tested},
        "buy_and_hold_benchmark": _buy_and_hold(bars_by_ticker, tested),
        "trades": all_trades,
        "limitations": LIMITATIONS,
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }

    overall = result["overall"]
    warnings = []
    if overall["trades"] < 30:
        warnings.append(
            f"Only {overall['trades']} simulated trades. Below ~30 the metrics are noise; do "
            f"not treat this as evidence the strategy works.")
    bh = result["buy_and_hold_benchmark"].get("return_pct")
    if bh is not None and overall.get("total_return_pct") is not None:
        if overall["total_return_pct"] < bh:
            warnings.append(
                f"The strategy returned {overall['total_return_pct']}% versus "
                f"{bh}% for simply buying and holding the same stocks — it UNDERPERFORMED "
                f"doing nothing, before tax and effort.")
    result["warnings"] = warnings
    return result


def persist_backtest(db, result: dict, start_date: str, end_date: str,
                     run_id: int | None = None) -> int:
    """Persist a completed run. When `run_id` is supplied the placeholder row created up-front
    by the async endpoint is filled in and marked complete; otherwise a new row is inserted."""
    overall = result.get("overall", {})
    payload = (result.get("strategy_version"), json.dumps(result.get("tickers_tested", [])),
               start_date, end_date, json.dumps(result.get("config", {})),
               json.dumps({k: v for k, v in result.items() if k != "trades"}),
               overall.get("trades"), overall.get("win_rate_pct"), overall.get("avg_return_pct"),
               overall.get("total_return_pct"), overall.get("max_drawdown_pct"),
               json.dumps(result.get("limitations", [])))

    if run_id is not None:
        db.execute(
            """
            UPDATE backtest_runs SET strategy_version=?, tickers=?, start_date=?, end_date=?,
                config_json=?, results_json=?, total_trades=?, win_rate_pct=?, avg_return_pct=?,
                total_return_pct=?, max_drawdown_pct=?, limitations_json=?,
                status='complete', error=NULL
            WHERE id=?
            """, payload + (run_id,))
    else:
        run_id = db.insert_returning_id(
            """
            INSERT INTO backtest_runs (strategy_version, tickers, start_date, end_date,
                                        config_json, results_json, total_trades, win_rate_pct,
                                        avg_return_pct, total_return_pct, max_drawdown_pct,
                                        limitations_json, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'complete')
            """, payload)
    for t in result.get("trades", []):
        db.execute(
            """
            INSERT INTO backtest_trades (run_id, ticker, signal_date, entry_date, entry_price,
                                          exit_date, exit_price, exit_reason, score_at_entry,
                                          signal_label, holding_days, return_pct, segment)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (run_id, t["ticker"], t["signal_date"], t["entry_date"], t["entry_price"],
             t.get("exit_date"), t.get("exit_price"), t.get("exit_reason"),
             t.get("score_at_entry"), t.get("signal_label"), t.get("holding_days"),
             t.get("return_pct"), t.get("segment")),
        )
    db.commit()
    return run_id
