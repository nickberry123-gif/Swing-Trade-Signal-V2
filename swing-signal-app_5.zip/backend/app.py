"""
Flask application entry point.

Run with:  python app.py
Serves both the JSON API (/api/...) and the frontend (server-rendered shell + static JS/CSS
that calls the API via fetch). No Node.js/build step required.
"""
from pathlib import Path

from flask import Flask, render_template

from config import Config, STOCK_UNIVERSE
import db as db_module
from routers.api_stocks import bp as stocks_bp, TICKERS
from routers.api_market import bp as market_bp
from routers.api_signals import bp as signals_bp

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(FRONTEND_DIR / "templates"),
        static_folder=str(FRONTEND_DIR / "static"),
        static_url_path="/static",
    )

    db_module.init_app(app)
    with app.app_context():
        db_module.init_db()

    app.register_blueprint(stocks_bp)
    app.register_blueprint(market_bp)
    app.register_blueprint(signals_bp)

    nav_items = [
        ("DASHBOARD", "/"),
        ("STOCKS", "/stocks"),
        ("PORTFOLIO", "/portfolio"),
        ("SIGNALS", "/signals"),
        ("TRADES", "/trades"),
        ("PERFORMANCE", "/performance"),
        ("BACKTEST", "/backtest"),
        ("SETTINGS", "/settings"),
    ]

    @app.context_processor
    def inject_nav():
        return {"nav_items": nav_items, "has_alpaca": Config.has_alpaca_credentials()}

    @app.get("/")
    def dashboard():
        return render_template("dashboard.html", active="DASHBOARD")

    @app.get("/stocks")
    def stocks_page():
        return render_template("stocks.html", active="STOCKS", stocks=STOCK_UNIVERSE)

    @app.get("/stocks/<ticker>")
    def stock_detail_page(ticker):
        ticker = ticker.upper()
        if ticker not in TICKERS:
            return render_template("not_found.html", active="STOCKS", ticker=ticker), 404
        stock = next(s for s in STOCK_UNIVERSE if s["ticker"] == ticker)
        return render_template("stock_detail.html", active="STOCKS", stock=stock)

    @app.get("/signals")
    def signals_page():
        return render_template("signals.html", active="SIGNALS", stocks=STOCK_UNIVERSE)

    placeholder_phases = {
        "portfolio": "Phase 5 — Manual Portfolio & Trades",
        "trades": "Phase 5 — Manual Portfolio & Trades",
        "performance": "Phase 6 — Signal & Trade Performance",
        "backtest": "Phase 7 — Backtesting Engine",
        "settings": "Phase 1+ — Settings",
    }
    for route_name, phase_label in placeholder_phases.items():
        def make_view(name=route_name, label=phase_label):
            def view():
                return render_template("coming_soon.html", active=name.upper(), phase_label=label, page_name=name.capitalize())
            return view
        app.add_url_rule(f"/{route_name}", endpoint=f"{route_name}_page", view_func=make_view())

    @app.get("/health")
    def health():
        return {"status": "ok", "alpaca_configured": Config.has_alpaca_credentials()}

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=Config.PORT, debug=True)
