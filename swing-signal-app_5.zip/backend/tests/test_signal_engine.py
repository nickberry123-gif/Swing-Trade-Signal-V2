"""
Unit tests for services/signal_engine.py — the Phase 3 100-point scoring engine.

Pure calculation, no I/O, so every test constructs synthetic indicator/relative-strength/
regime dicts directly (matching the shapes services.indicators.compute_all_indicators() and
services.relative_strength.compute_relative_strength() actually produce) rather than mocking
anything network-related.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import signal_engine as se


def strong_bull_indicators(price=150.0):
    """A textbook strong-uptrend, healthy-pullback setup: everything lines up bullish."""
    return {
        "reference_price": price,
        "sma50": price * 0.95, "sma200": price * 0.85, "sma200_slope": 1.2,
        "ema20": price * 0.98, "ema50": price * 0.95,
        "macd": 1.5, "macd_signal": 1.0, "macd_hist": 0.5,
        "rsi14": 60.0, "adx": 30.0, "roc": 5.0,
        "relative_volume": 1.8, "volume_trend": "Increasing",
        "support_low": price * 0.97, "support_high": price * 0.995,
        "resistance_low": price * 1.10, "resistance_high": price * 1.15,
        "swing_high": price * 1.12, "high_52w": price * 1.20,
        "high_20d": price * 1.01,
        "atr14": price * 0.02,
        "trend_label": "Strong Uptrend",
        "bars_used": 300, "data_status": "OK",
    }


def weak_bear_indicators(price=50.0):
    """Everything lines up bearish/oversold-in-a-downtrend (not a valid pullback)."""
    return {
        "reference_price": price,
        "sma50": price * 1.08, "sma200": price * 1.15, "sma200_slope": -1.0,
        "ema20": price * 1.05, "ema50": price * 1.08,
        "macd": -1.0, "macd_signal": -0.5, "macd_hist": -0.5,
        "rsi14": 22.0, "adx": 28.0, "roc": -8.0,
        "relative_volume": 0.6, "volume_trend": "Decreasing",
        "support_low": price * 0.90, "support_high": price * 0.94,
        "resistance_low": price * 1.02, "resistance_high": price * 1.05,
        "swing_high": price * 1.05, "high_52w": price * 1.40,
        "high_20d": price * 1.02,
        "atr14": price * 0.03,
        "trend_label": "Strong Downtrend",
        "bars_used": 300, "data_status": "OK",
    }


def empty_indicators():
    return {"reference_price": None, "bars_used": 0, "data_status": "UNAVAILABLE"}


def strong_rs():
    return {"labels": {5: "Strong", 20: "Strong", 50: "Strong", 200: "Strong"},
            "rs_spy_5d": 3.0, "rs_spy_20d": 6.0, "rs_spy_50d": 9.0, "rs_spy_200d": 15.0}


def weak_rs():
    return {"labels": {5: "Weak", 20: "Weak", 50: "Weak", 200: "Weak"},
            "rs_spy_5d": -3.0, "rs_spy_20d": -6.0, "rs_spy_50d": -9.0, "rs_spy_200d": -15.0}


def empty_rs():
    return {"labels": {}}


class TestScoreLongTermTrend(unittest.TestCase):
    def test_all_bullish_conditions_scores_max(self):
        score, reasons = se.score_long_term_trend(strong_bull_indicators())
        self.assertEqual(score, 20)
        self.assertEqual(len(reasons), 4)

    def test_all_bearish_conditions_scores_zero(self):
        score, _ = se.score_long_term_trend(weak_bear_indicators())
        self.assertEqual(score, 0)

    def test_missing_data_returns_none_not_zero(self):
        score, _ = se.score_long_term_trend(empty_indicators())
        self.assertIsNone(score)

    def test_mixed_conditions_not_binary_all_or_nothing(self):
        ind = strong_bull_indicators()
        ind["sma200_slope"] = -0.5  # one condition flips bearish
        score, _ = se.score_long_term_trend(ind)
        self.assertGreater(score, 0)
        self.assertLess(score, 20)


class TestScoreShortTermTrend(unittest.TestCase):
    def test_all_bullish_scores_max(self):
        score, _ = se.score_short_term_trend(strong_bull_indicators())
        self.assertEqual(score, 10)

    def test_all_bearish_scores_zero(self):
        score, _ = se.score_short_term_trend(weak_bear_indicators())
        self.assertEqual(score, 0)

    def test_missing_data_returns_none(self):
        score, _ = se.score_short_term_trend(empty_indicators())
        self.assertIsNone(score)


class TestScoreMomentum(unittest.TestCase):
    def test_healthy_bullish_momentum_scores_high(self):
        score, _ = se.score_momentum(strong_bull_indicators())
        self.assertGreaterEqual(score, 10)

    def test_bearish_momentum_scores_low(self):
        score, _ = se.score_momentum(weak_bear_indicators())
        self.assertLessEqual(score, 3)

    def test_overbought_rsi_does_not_score_max(self):
        ind = strong_bull_indicators()
        ind["rsi14"] = 85.0
        score, _ = se.score_momentum(ind)
        score_normal, _ = se.score_momentum(strong_bull_indicators())
        self.assertLess(score, score_normal)

    def test_extended_roc_scores_lower_than_healthy_roc(self):
        ind_extended = strong_bull_indicators()
        ind_extended["roc"] = 30.0
        ind_healthy = strong_bull_indicators()
        ind_healthy["roc"] = 6.0
        score_extended, _ = se.score_momentum(ind_extended)
        score_healthy, _ = se.score_momentum(ind_healthy)
        self.assertLess(score_extended, score_healthy)

    def test_missing_data_returns_none(self):
        score, _ = se.score_momentum(empty_indicators())
        self.assertIsNone(score)


class TestScoreRsiPullback(unittest.TestCase):
    def test_ideal_pullback_in_uptrend_scores_max(self):
        ind = {"rsi14": 45.0, "trend_label": "Uptrend"}
        score, _ = se.score_rsi_pullback(ind)
        self.assertEqual(score, 10)

    def test_oversold_in_downtrend_is_not_a_pullback(self):
        ind = {"rsi14": 22.0, "trend_label": "Strong Downtrend"}
        score, reasons = se.score_rsi_pullback(ind)
        self.assertEqual(score, 0)
        self.assertTrue(any("not a buyable pullback" in r for r in reasons))

    def test_overbought_in_uptrend_scores_low_not_zero(self):
        ind = {"rsi14": 85.0, "trend_label": "Strong Uptrend"}
        score, _ = se.score_rsi_pullback(ind)
        self.assertEqual(score, 1)

    def test_missing_data_returns_none(self):
        score, _ = se.score_rsi_pullback({"rsi14": None, "trend_label": None})
        self.assertIsNone(score)


class TestScoreVolume(unittest.TestCase):
    def test_strong_volume_scores_max(self):
        score, _ = se.score_volume(strong_bull_indicators())
        self.assertEqual(score, 10)

    def test_weak_volume_scores_zero(self):
        score, _ = se.score_volume(weak_bear_indicators())
        self.assertEqual(score, 0)

    def test_missing_data_returns_none(self):
        score, _ = se.score_volume({})
        self.assertIsNone(score)


class TestScoreSupportResistance(unittest.TestCase):
    def test_price_inside_support_zone_with_room_scores_high(self):
        ind = {"reference_price": 100.0, "support_low": 98.0, "support_high": 101.0,
               "resistance_low": 112.0}
        score, _ = se.score_support_resistance(ind)
        self.assertGreaterEqual(score, 9)

    def test_price_far_above_support_near_resistance_scores_low(self):
        ind = {"reference_price": 111.0, "support_low": 90.0, "support_high": 94.0,
               "resistance_low": 112.0}
        score, _ = se.score_support_resistance(ind)
        self.assertLessEqual(score, 3)

    def test_missing_data_returns_none(self):
        score, _ = se.score_support_resistance({"reference_price": 100.0})
        self.assertIsNone(score)


class TestScoreRelativeStrength(unittest.TestCase):
    def test_all_strong_scores_max(self):
        score, _ = se.score_relative_strength(strong_rs())
        self.assertEqual(score, 10)

    def test_all_weak_scores_zero(self):
        score, _ = se.score_relative_strength(weak_rs())
        self.assertEqual(score, 0)

    def test_missing_labels_returns_none(self):
        score, _ = se.score_relative_strength(empty_rs())
        self.assertIsNone(score)


class TestScoreMarketRegime(unittest.TestCase):
    def test_strong_bull_scores_max(self):
        score, _ = se.score_market_regime({"regime": "STRONG BULL"})
        self.assertEqual(score, 5.0)

    def test_bear_scores_zero(self):
        score, _ = se.score_market_regime({"regime": "BEAR"})
        self.assertEqual(score, 0.0)

    def test_unavailable_returns_none_not_fabricated(self):
        score, reasons = se.score_market_regime({"regime": "UNAVAILABLE"})
        self.assertIsNone(score)
        self.assertTrue(any("not guessed" in r for r in reasons))


class TestClassifyStrategySetup(unittest.TestCase):
    def test_pullback_detected(self):
        ind = {
            "trend_label": "Uptrend", "reference_price": 100.0,
            "support_low": 97.0, "support_high": 99.5, "rsi14": 50.0,
        }
        self.assertEqual(se.classify_strategy_setup(ind), "PULLBACK")

    def test_breakout_detected(self):
        ind = {
            "trend_label": "Strong Uptrend", "reference_price": 120.0,
            "high_20d": 120.5, "relative_volume": 1.6, "rsi14": 68.0,
            "support_low": None, "support_high": None,
        }
        self.assertEqual(se.classify_strategy_setup(ind), "BREAKOUT")

    def test_deep_correction_detected(self):
        ind = {
            "trend_label": "Downtrend", "reference_price": 80.0,
            "sma50": 100.0, "sma200": 90.0, "rsi14": 30.0,
            "support_low": None, "support_high": None,
        }
        self.assertEqual(se.classify_strategy_setup(ind), "DEEP_CORRECTION")

    def test_none_when_nothing_fits(self):
        ind = {"trend_label": "Neutral", "reference_price": 100.0, "rsi14": 50.0}
        self.assertEqual(se.classify_strategy_setup(ind), "NONE")


class TestClassifySignal(unittest.TestCase):
    def test_high_score_bull_market_is_strong_buy(self):
        label, notes = se.classify_signal(85, "BULL")
        self.assertEqual(label, "STRONG BUY")
        self.assertEqual(notes, [])

    def test_low_score_is_avoid(self):
        label, _ = se.classify_signal(10, "BULL")
        self.assertEqual(label, "AVOID")

    def test_bear_regime_caps_strong_buy_to_watch(self):
        label, notes = se.classify_signal(90, "BEAR")
        self.assertEqual(label, "WATCH")
        self.assertTrue(len(notes) > 0)

    def test_bear_regime_does_not_raise_a_weak_score(self):
        label, _ = se.classify_signal(10, "BEAR")
        self.assertEqual(label, "AVOID")


class TestComputePriceLevels(unittest.TestCase):
    def _assert_ordering(self, levels):
        self.assertLessEqual(levels["buy_zone_low"], levels["ideal_buy"] + 1e-6)
        self.assertLessEqual(levels["ideal_buy"], levels["buy_zone_high"] + 1e-6)
        self.assertLessEqual(levels["buy_zone_high"], levels["max_entry"] + 1e-6)
        self.assertLess(levels["max_entry"], levels["target1"])
        self.assertLessEqual(levels["target1"], levels["primary_target"] + 1e-6)
        self.assertLessEqual(levels["primary_target"], levels["target3"] + 1e-6)

    def test_ordering_with_full_zone_data(self):
        levels = se.compute_price_levels(strong_bull_indicators())
        self._assert_ordering(levels)
        self.assertIsNotNone(levels["expected_upside_pct"])

    def test_ordering_with_price_already_below_support(self):
        ind = strong_bull_indicators()
        ind["reference_price"] = ind["support_low"] - 1.0
        levels = se.compute_price_levels(ind)
        self._assert_ordering(levels)

    def test_ordering_with_no_zone_data_falls_back_to_atr(self):
        ind = {"reference_price": 100.0, "atr14": 2.0}
        levels = se.compute_price_levels(ind)
        self._assert_ordering(levels)

    def test_ordering_with_no_atr_or_zone_data(self):
        ind = {"reference_price": 100.0}
        levels = se.compute_price_levels(ind)
        self._assert_ordering(levels)

    def test_missing_price_returns_all_none(self):
        levels = se.compute_price_levels({"reference_price": None})
        self.assertTrue(all(v is None for v in levels.values()))

    def test_never_includes_a_stop_loss_field(self):
        levels = se.compute_price_levels(strong_bull_indicators())
        self.assertNotIn("stop_loss", levels)
        self.assertFalse(any("stop" in k.lower() for k in levels))


class TestComputeSignal(unittest.TestCase):
    def test_full_bullish_scenario(self):
        analysis = {"ticker": "NVDA", "bars_used": 300, "data_status": "OK",
                    "relative_strength": strong_rs(), "sector_etf": "SMH",
                    **strong_bull_indicators()}
        regime = {"regime": "BULL"}
        result = se.compute_signal(analysis, regime)

        self.assertEqual(result["ticker"], "NVDA")
        self.assertEqual(result["data_status"], "OK")
        self.assertGreater(result["score_total"], 60)
        self.assertIn(result["signal_label"], ("BUY", "STRONG BUY"))
        self.assertEqual(result["score_news"], 0.0)
        self.assertEqual(result["score_earnings_risk"], 0.0)
        self.assertIn("PENDING" if False else "Phase 4", result["explanation"])
        self.assertIsNotNone(result["ideal_buy"])
        self.assertLessEqual(result["ideal_buy"], result["max_entry"])
        self.assertNotIn("stop_loss", result)

    def test_full_bearish_scenario_scores_low(self):
        analysis = {"ticker": "XYZ", "bars_used": 300, "data_status": "OK",
                    "relative_strength": weak_rs(), "sector_etf": "XLK",
                    **weak_bear_indicators()}
        regime = {"regime": "BEAR"}
        result = se.compute_signal(analysis, regime)

        self.assertLess(result["score_total"], 30)
        self.assertIn(result["signal_label"], ("NO TRADE", "AVOID"))

    def test_no_data_returns_no_data_signal_not_a_crash(self):
        analysis = {"ticker": "AAPL", "bars_used": 0, "data_status": "UNAVAILABLE",
                    "data_error": "network error"}
        result = se.compute_signal(analysis, {"regime": "BULL"})
        self.assertEqual(result["signal_label"], "NO DATA")
        self.assertIsNone(result["score_total"])

    def test_bear_market_caps_a_strong_stock_signal(self):
        analysis = {"ticker": "NVDA", "bars_used": 300, "data_status": "OK",
                    "relative_strength": strong_rs(), "sector_etf": "SMH",
                    **strong_bull_indicators()}
        result_bull = se.compute_signal(analysis, {"regime": "BULL"})
        result_bear = se.compute_signal(analysis, {"regime": "BEAR"})
        # Same stock-level score inputs, but BEAR regime knocks 5 pts off score_market_regime
        # and can cap the label even though the stock-only score would justify BUY/STRONG BUY.
        self.assertLessEqual(result_bear["score_total"], result_bull["score_total"])
        if result_bull["signal_label"] in ("STRONG BUY", "BUY"):
            self.assertEqual(result_bear["signal_label"], "WATCH")


if __name__ == "__main__":
    unittest.main()
