"""
Unit tests for services/signals_service.py — the Phase 3 orchestration layer that ties
market_regime + stock_analysis + signal_engine together for one ticker or the full 15-stock
universe, and persists into the `signals` table.

get_bars_df is mocked at both places it's imported into (services.market_regime and
services.stock_analysis both do `from services.bars_service import get_bars_df`), matching the
pattern used in test_market_regime.py / test_stock_analysis.py. Persistence is checked against
a real in-memory SQLite DB built from schema.sql.
"""
import sqlite3
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import SECTOR_ETF_MAP, STOCK_UNIVERSE
from services import signals_service

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    """`signals.ticker` has a FOREIGN KEY REFERENCES stocks(ticker), so — unlike the other
    Phase 2 tables, which deliberately have no FK — this test DB must seed `stocks` the same
    way db.py's real init_db() does, or every signals insert fails FK enforcement."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]),
        )
    conn.commit()
    return conn


def trending_bars(n=250, start=100.0, daily_drift=0.15, noise=0.3, seed=0):
    rng = np.random.default_rng(seed)
    closes = start + np.cumsum(daily_drift + rng.normal(0, noise, n))
    closes = np.maximum(closes, 1.0)
    ts = [(datetime(2024, 1, 1) + timedelta(days=i)).isoformat() for i in range(n)]
    return pd.DataFrame({
        "ts": ts, "open": closes, "high": closes + 0.5, "low": closes - 0.5,
        "close": closes, "volume": [1_000_000.0] * n,
    })


def empty_bars():
    return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])


def all_bullish_side_effect(db, ticker, timeframe, force_refresh=False):
    # Falling VIXY = calming volatility = a bullish regime contribution, matches
    # test_market_regime.py's convention for a clean bullish scenario.
    if ticker == "VIXY":
        return trending_bars(daily_drift=-0.1, seed=1), {"source": "alpaca", "fresh": True, "stale_fallback": False, "error": None}
    return trending_bars(daily_drift=0.2, seed=hash(ticker) % 1000), {"source": "alpaca", "fresh": True, "stale_fallback": False, "error": None}


class TestComputeSignalForTicker(unittest.TestCase):
    @patch("services.stock_analysis.get_bars_df")
    @patch("services.market_regime.get_bars_df")
    def test_returns_full_signal_and_persists(self, mock_regime_bars, mock_stock_bars):
        mock_regime_bars.side_effect = all_bullish_side_effect
        mock_stock_bars.side_effect = all_bullish_side_effect
        db = make_db()

        signal = signals_service.compute_signal_for_ticker(db, "NVDA", persist=True)

        self.assertEqual(signal["ticker"], "NVDA")
        self.assertEqual(signal["data_status"], "OK")
        self.assertIsNotNone(signal["score_total"])
        self.assertIn(signal["signal_label"], ("STRONG BUY", "BUY", "WATCH", "NO TRADE", "AVOID"))

        row = db.execute("SELECT * FROM signals WHERE ticker='NVDA'").fetchone()
        self.assertIsNotNone(row)
        self.assertEqual(row["signal_label"], signal["signal_label"])
        self.assertEqual(row["strategy_version"], "v1.0")


class TestComputeAllSignals(unittest.TestCase):
    @patch("services.stock_analysis.get_bars_df")
    @patch("services.market_regime.get_bars_df")
    def test_returns_15_signals_ranked_and_persists_regime(self, mock_regime_bars, mock_stock_bars):
        mock_regime_bars.side_effect = all_bullish_side_effect
        mock_stock_bars.side_effect = all_bullish_side_effect
        db = make_db()

        signals = signals_service.compute_all_signals(db, persist=True)

        self.assertEqual(len(signals), len(signals_service.TICKERS))
        scores = [s["score_total"] for s in signals if s.get("score_total") is not None]
        self.assertEqual(scores, sorted(scores, reverse=True))  # ranked best-first

        regime_rows = db.execute("SELECT COUNT(*) FROM market_regime").fetchone()[0]
        self.assertEqual(regime_rows, 1)

        signal_rows = db.execute("SELECT COUNT(*) FROM signals").fetchone()[0]
        self.assertEqual(signal_rows, len(signals_service.TICKERS))

    @patch("services.stock_analysis.get_bars_df")
    @patch("services.market_regime.get_bars_df")
    def test_one_bad_ticker_does_not_break_the_batch(self, mock_regime_bars, mock_stock_bars):
        def stock_side_effect(db, ticker, timeframe, force_refresh=False):
            if ticker == "TSLA":
                return empty_bars(), {"source": "cache", "fresh": False, "stale_fallback": False, "error": "no data"}
            return all_bullish_side_effect(db, ticker, timeframe, force_refresh)

        mock_regime_bars.side_effect = all_bullish_side_effect
        mock_stock_bars.side_effect = stock_side_effect
        db = make_db()

        signals = signals_service.compute_all_signals(db, persist=True)

        self.assertEqual(len(signals), len(signals_service.TICKERS))
        tsla = next(s for s in signals if s["ticker"] == "TSLA")
        self.assertEqual(tsla["signal_label"], "NO DATA")
        self.assertIsNone(tsla["score_total"])
        # TSLA sorts to the end since it has no score
        self.assertEqual(signals[-1]["ticker"], "TSLA")

        # TSLA should NOT have been persisted (no data == nothing meaningful to store)
        row = db.execute("SELECT * FROM signals WHERE ticker='TSLA'").fetchone()
        self.assertIsNone(row)

    @patch("services.stock_analysis.get_bars_df")
    @patch("services.market_regime.get_bars_df")
    def test_shares_one_benchmark_fetch_across_all_15_stocks(self, mock_regime_bars, mock_stock_bars):
        mock_regime_bars.side_effect = all_bullish_side_effect
        mock_stock_bars.side_effect = all_bullish_side_effect
        db = make_db()

        signals_service.compute_all_signals(db, persist=False)

        # 15 stocks + the benchmark cache (SPY, QQQ, and the unique sector ETFs actually
        # referenced by SECTOR_ETF_MAP — built once and shared) = calls to
        # services.stock_analysis.get_bars_df, not 15 * (1 + N) if fetched per-stock instead.
        unique_sector_etfs = len(set(SECTOR_ETF_MAP.values()))
        self.assertEqual(mock_stock_bars.call_count, 15 + 2 + unique_sector_etfs)


if __name__ == "__main__":
    unittest.main()
