"""
Phase 3 orchestration: ties stock_analysis (Phase 2 indicators + relative strength) and
market_regime together with signal_engine to produce, and persist, a signal for one ticker or
the whole 15-stock universe. Routers call this module; they never touch signal_engine or
stock_analysis directly.
"""
from config import STOCK_UNIVERSE
from services.market_regime import compute_market_regime, store_market_regime
from services.signal_engine import compute_signal, persist_signal
from services.stock_analysis import analyze_stock, build_benchmark_cache

TICKERS = [s["ticker"] for s in STOCK_UNIVERSE]


def compute_signal_for_ticker(db, ticker: str, timeframe: str = "1Day", benchmark_cache=None,
                               regime: dict | None = None, persist: bool = True) -> dict:
    analysis = analyze_stock(db, ticker, timeframe=timeframe, benchmark_cache=benchmark_cache, persist=persist)
    if regime is None:
        regime = compute_market_regime(db)
    signal = compute_signal(analysis, regime)
    if persist:
        persist_signal(db, signal)
    return signal


def compute_all_signals(db, timeframe: str = "1Day", persist: bool = True) -> list:
    """Computes signals for all 15 tracked stocks, sharing one market-regime fetch and one
    benchmark-bar cache across all 15 (rather than 15x redundant SPY/QQQ/sector fetches).
    Returns them ranked best-score-first; tickers with no data sort to the end rather than
    being silently dropped."""
    regime = compute_market_regime(db)
    if persist and regime.get("regime") != "UNAVAILABLE":
        store_market_regime(db, regime)

    benchmark_cache = build_benchmark_cache(db, timeframe)

    signals = []
    for ticker in TICKERS:
        try:
            signal = compute_signal_for_ticker(
                db, ticker, timeframe=timeframe, benchmark_cache=benchmark_cache,
                regime=regime, persist=persist,
            )
        except Exception as e:  # noqa: BLE001 — one bad ticker must not take down the whole batch
            signal = {
                "ticker": ticker, "signal_label": "NO DATA", "score_total": None,
                "data_status": "UNAVAILABLE", "data_error": str(e),
            }
        signals.append(signal)

    signals.sort(key=lambda s: (s.get("score_total") is None, -(s.get("score_total") or 0)))
    return signals
