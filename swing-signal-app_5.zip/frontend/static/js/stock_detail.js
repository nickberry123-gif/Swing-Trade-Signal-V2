// TradingView is used strictly as the visual chart layer (official embedded widget).
// No data is scraped or read back out of it; nothing here feeds the signal engine.
let tvSymbol = `${window.STOCK_EXCHANGE || "NASDAQ"}:${window.STOCK_TICKER}`;

function renderChart(interval) {
  const container = document.getElementById("tv_chart_widget");
  // A failure here (e.g. TradingView's script blocked/unreachable) must never take down the
  // rest of the page — price, indicators, and everything else below are independent of the
  // chart and must keep working even if the chart itself can't load.
  try {
    if (typeof TradingView === "undefined") {
      container.innerHTML = `<div class="warn-banner" style="margin:16px;">Chart unavailable — TradingView's widget script did not load (network issue). This does not affect price, indicator, or signal data below, which come from Alpaca via this app's own backend.</div>`;
      return;
    }
    container.innerHTML = "";
    // eslint-disable-next-line no-undef
    new TradingView.widget({
      autosize: true,
      symbol: tvSymbol,
      interval: interval,
      timezone: "America/New_York",
      theme: "dark",
      style: "1",
      locale: "en",
      toolbar_bg: "#10151f",
      enable_publishing: false,
      allow_symbol_change: false,
      hide_side_toolbar: false,
      studies: ["MASimple@tv-basicstudies"],
      container_id: "tv_chart_widget",
    });
  } catch (e) {
    container.innerHTML = `<div class="warn-banner" style="margin:16px;">Chart failed to load: ${e.message}. This does not affect price, indicator, or signal data below.</div>`;
  }
}

document.querySelectorAll(".tf-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tf-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    renderChart(btn.dataset.interval);
  });
});

renderChart("D");

async function refreshSnapshot() {
  const ticker = window.STOCK_TICKER;
  const errBox = document.getElementById("snapshot-error");
  try {
    const snap = await apiGet(`/api/stocks/${encodeURIComponent(ticker)}/snapshot`);

    if (snap.data_status === "UNAVAILABLE" || snap.error) {
      errBox.innerHTML = `<div class="error-banner">DATA FEED ERROR — ${snap.error || "no data available"}. ${
        snap.last_known_price ? `Last known price from local database: $${Number(snap.last_known_price).toFixed(2)} (as of ${fmtTime(snap.as_of)}) — NOT live.` : ""
      }</div>`;
    } else {
      errBox.innerHTML = "";
    }

    document.getElementById("dp-price").textContent = fmtPrice(snap.last_price !== undefined ? snap.last_price : snap.last_known_price);
    document.getElementById("dp-change").innerHTML = snap.change !== undefined ? fmtChange(snap.change, snap.change_pct) : "—";
    document.getElementById("dp-status-pill").innerHTML = statusPillHtml(snap.data_status);

    document.getElementById("dp-open").textContent = fmtPrice(snap.daily_open);
    document.getElementById("dp-high").textContent = fmtPrice(snap.daily_high);
    document.getElementById("dp-low").textContent = fmtPrice(snap.daily_low);
    document.getElementById("dp-volume").textContent = fmtVolume(snap.daily_volume);
    document.getElementById("dp-prevclose").textContent = fmtPrice(snap.prev_close);
    document.getElementById("dp-bidask").textContent =
      snap.bid_price && snap.ask_price ? `${fmtPrice(snap.bid_price)} / ${fmtPrice(snap.ask_price)}` : "—";
    document.getElementById("dp-trade-ts").textContent = fmtTime(snap.last_trade_ts);
    document.getElementById("dp-fetched-ts").textContent = fmtTime(snap.fetched_at);
  } catch (e) {
    errBox.innerHTML = `<div class="error-banner">DATA FEED ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

refreshSnapshot();
setInterval(refreshSnapshot, 15000);

function fmtZone(low, high) {
  if (low === null || low === undefined || high === null || high === undefined) return "—";
  return `${fmtPrice(low)} – ${fmtPrice(high)}`;
}

function rsCellHtml(v) {
  if (v === null || v === undefined) return `<span class="text-dim">&mdash;</span>`;
  return `<span class="${pctClass(v)}">${fmtPct(v, 1)}</span>`;
}

async function refreshIndicators() {
  const ticker = window.STOCK_TICKER;
  const errBox = document.getElementById("indicators-error");
  try {
    const ind = await apiGet(`/api/stocks/${encodeURIComponent(ticker)}/indicators`);

    if (ind.data_status === "UNAVAILABLE" || ind.data_error) {
      errBox.innerHTML = `<div class="warn-banner">TECHNICAL INDICATORS UNAVAILABLE — ${ind.data_error || "no bar data available"}.</div>`;
    } else {
      errBox.innerHTML = "";
    }

    // Trend
    document.getElementById("ind-trend-label").textContent = ind.trend_label || "—";
    document.getElementById("ind-trend-label").className = "value " + trendClass(ind.trend_label);
    document.getElementById("ind-bars-used").textContent = ind.bars_used ? `based on ${ind.bars_used} bars` : "";
    const reasonsEl = document.getElementById("ind-trend-reasons");
    const reasons = Array.isArray(ind.trend_reasons) ? ind.trend_reasons : [];
    reasonsEl.innerHTML = reasons.length
      ? reasons.map((r) => `<li>${r}</li>`).join("")
      : `<li class="text-dim">${(ind.warnings && ind.warnings[0]) || "No trend data available."}</li>`;

    // Support / resistance
    document.getElementById("ind-resistance-zone").textContent = fmtZone(ind.resistance_low, ind.resistance_high);
    document.getElementById("ind-support-zone").textContent = fmtZone(ind.support_low, ind.support_high);

    // Indicator tiles
    document.getElementById("ind-rsi14").textContent = fmtNum(ind.rsi14, 1);
    document.getElementById("ind-rsi7").textContent = fmtNum(ind.rsi7, 1);
    document.getElementById("ind-stochrsi").textContent = fmtNum(ind.stoch_rsi, 1);
    document.getElementById("ind-macdhist").textContent = ind.macd_hist !== null && ind.macd_hist !== undefined ? Number(ind.macd_hist).toFixed(3) : "—";
    document.getElementById("ind-adx").textContent = fmtNum(ind.adx, 1);
    document.getElementById("ind-atr").textContent = ind.atr14 !== null && ind.atr14 !== undefined
      ? `${fmtPrice(ind.atr14)} (${fmtNum(ind.atr_pct, 1)}%)` : "—";
    document.getElementById("ind-sma50").textContent = fmtPrice(ind.sma50);
    document.getElementById("ind-sma200").textContent = fmtPrice(ind.sma200);
    document.getElementById("ind-bbwidth").textContent = ind.bb_width !== null && ind.bb_width !== undefined ? (Number(ind.bb_width) * 100).toFixed(2) + "%" : "—";
    document.getElementById("ind-histvol").textContent = ind.hist_volatility !== null && ind.hist_volatility !== undefined ? fmtNum(ind.hist_volatility, 1) + "%" : "—";
    document.getElementById("ind-voltrend").textContent = ind.volume_trend || "—";
    document.getElementById("ind-relvol").textContent = ind.relative_volume !== null && ind.relative_volume !== undefined ? Number(ind.relative_volume).toFixed(2) + "x" : "—";
    document.getElementById("ind-52wh").textContent = fmtPrice(ind.high_52w);
    document.getElementById("ind-52wl").textContent = fmtPrice(ind.low_52w);

    // Relative strength
    const rs = ind.relative_strength || {};
    document.getElementById("rs-spy-5").innerHTML = rsCellHtml(rs.rs_spy_5d);
    document.getElementById("rs-spy-20").innerHTML = rsCellHtml(rs.rs_spy_20d);
    document.getElementById("rs-spy-50").innerHTML = rsCellHtml(rs.rs_spy_50d);
    document.getElementById("rs-spy-200").innerHTML = rsCellHtml(rs.rs_spy_200d);
    document.getElementById("rs-qqq-5").innerHTML = rsCellHtml(rs.rs_qqq_5d);
    document.getElementById("rs-qqq-20").innerHTML = rsCellHtml(rs.rs_qqq_20d);
    document.getElementById("rs-qqq-50").innerHTML = rsCellHtml(rs.rs_qqq_50d);
    document.getElementById("rs-qqq-200").innerHTML = rsCellHtml(rs.rs_qqq_200d);
    document.getElementById("rs-sector-label").textContent = ind.sector_etf ? `Sector (${ind.sector_etf})` : "Sector ETF";
    document.getElementById("rs-sector-5").innerHTML = rsCellHtml(rs.rs_sector_5d);
    document.getElementById("rs-sector-20").innerHTML = rsCellHtml(rs.rs_sector_20d);
    document.getElementById("rs-sector-50").innerHTML = rsCellHtml(rs.rs_sector_50d);
    document.getElementById("rs-sector-200").innerHTML = rsCellHtml(rs.rs_sector_200d);
  } catch (e) {
    errBox.innerHTML = `<div class="error-banner">TECHNICAL INDICATORS ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

refreshIndicators();
setInterval(refreshIndicators, 60000);

const SIGNAL_COMPONENTS = [
  { key: "score_long_trend", label: "Long-Term Trend", max: 20 },
  { key: "score_short_trend", label: "Short-Term Trend", max: 10 },
  { key: "score_momentum", label: "Momentum", max: 15 },
  { key: "score_rsi_pullback", label: "RSI Pullback Quality", max: 10 },
  { key: "score_volume", label: "Volume", max: 10 },
  { key: "score_support_resistance", label: "Support / Resistance", max: 10 },
  { key: "score_relative_strength", label: "Relative Strength", max: 10 },
  { key: "score_market_regime", label: "Market Regime", max: 5 },
  { key: "score_news", label: "News (pending Phase 4)", max: 5 },
  { key: "score_earnings_risk", label: "Earnings Risk (pending Phase 4)", max: 5 },
];

function levelBoxHtml(label, value) {
  return `<div class="level-box"><div class="lk">${label}</div><div class="lv">${fmtPrice(value)}</div></div>`;
}

async function refreshSignal() {
  const ticker = window.STOCK_TICKER;
  const errBox = document.getElementById("signal-error");
  try {
    const sig = await apiGet(`/api/signals/${encodeURIComponent(ticker)}`);

    if (sig.signal_label === "NO DATA" || sig.data_status === "UNAVAILABLE" || sig.error) {
      errBox.innerHTML = `<div class="warn-banner">SIGNAL UNAVAILABLE — ${sig.data_error || sig.error || "no data available"}.</div>`;
      document.getElementById("sig-pill").innerHTML = signalPillHtml(sig.signal_label || "NO DATA");
      document.getElementById("sig-score").textContent = "—";
      document.getElementById("sig-score-max").textContent = "";
      document.getElementById("sig-breakdown").innerHTML = `<div class="text-dim">No component breakdown — no data available.</div>`;
      return;
    }
    errBox.innerHTML = "";

    document.getElementById("sig-pill").innerHTML = signalPillHtml(sig.signal_label);
    document.getElementById("sig-score").textContent = fmtNum(sig.score_total, 1);
    document.getElementById("sig-score").className = "score-value " + signalScoreClass(sig.signal_label);
    document.getElementById("sig-score-max").textContent = `/ ${sig.score_max_currently_available || 90} pts currently achievable (of 100 designed)`;
    document.getElementById("sig-setup").innerHTML = sig.strategy_setup && sig.strategy_setup !== "NONE"
      ? `<span class="setup-badge">${sig.strategy_setup.replace("_", " ")}</span>` : "";
    document.getElementById("sig-thesis").textContent = sig.long_term_thesis
      ? `Long-term thesis: ${sig.long_term_thesis}` : "";

    document.getElementById("sig-levels-grid").innerHTML = [
      levelBoxHtml("Ideal Buy", sig.ideal_buy),
      `<div class="level-box"><div class="lk">Buy Zone</div><div class="lv">${fmtZone(sig.buy_zone_low, sig.buy_zone_high)}</div></div>`,
      levelBoxHtml("Max Entry", sig.max_entry),
      `<div class="level-box"><div class="lk">Expected Upside</div><div class="lv ${pctClass(sig.expected_upside_pct)}">${fmtPct(sig.expected_upside_pct, 1)}</div></div>`,
      levelBoxHtml("Target 1", sig.target1),
      levelBoxHtml("Primary Target", sig.primary_target),
      levelBoxHtml("Target 3", sig.target3),
    ].join("");

    document.getElementById("sig-breakdown").innerHTML = SIGNAL_COMPONENTS.map((c) => {
      const val = sig[c.key];
      const pct = val !== null && val !== undefined ? Math.max(0, Math.min(100, (val / c.max) * 100)) : 0;
      const display = val !== null && val !== undefined ? `${fmtNum(val, 1)} / ${c.max}` : `— / ${c.max}`;
      return `
        <div class="score-breakdown-row">
          <div class="comp-name">${c.label}</div>
          <div class="comp-bar-wrap"><div class="comp-bar" style="width:${pct}%;"></div></div>
          <div class="comp-value">${display}</div>
        </div>
      `;
    }).join("");
  } catch (e) {
    errBox.innerHTML = `<div class="error-banner">SIGNAL ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

refreshSignal();
setInterval(refreshSignal, 60000);
