"""
Two bullish setups, long-only: the Retracement and the Base Breakout.

LONG-ONLY, STRUCTURALLY
-----------------------
There is no short branch in this module and no place to add one. A stock that fails every bullish
test produces NO SETUP, never a short signal. Entries buy, stops sit BELOW entry, targets sit
ABOVE it, and position size is always a positive share count of a long position.

THE TIMEFRAME SUBSTITUTION — READ THIS BEFORE TRUSTING ANY RESULT
-----------------------------------------------------------------
The strategy this implements is an INTRADAY one. It was described on 1/2/5/15-minute charts, with
pre-market gappers, a news catalyst, Level 2 depth and 9:30–11:30 / 14:00–16:00 windows.

This app has DAILY bars. The provider offers 15Min and up, but only ~15 days of 15-minute history
and ~60 days of hourly, and on the free tier those come from IEX — roughly 2% of consolidated
volume, so intraday volume and relative-volume figures would be measuring the wrong thing.

So every structural rule is implemented faithfully, one timeframe up:

    the video's execution chart (1-5 min)  ->  DAILY bars here
    the video's 1H higher timeframe        ->  UNAVAILABLE, reported UNKNOWN
    the video's 1D higher timeframe        ->  DAILY trend (50/200 SMA structure)
    a genuine higher timeframe             ->  WEEKLY, resampled from the same daily bars

That makes this a SWING-TRADING TRANSLATION of a DAY-TRADING strategy. The shapes are the same;
the holding periods, the noise and the catalysts are not. A good result here would not
demonstrate that the video's strategy works, and a poor one would not demonstrate that it fails.
The page says so, and so does `limitations` on every result.

WHAT CANNOT BE COMPUTED AT ALL, AND IS NEVER GUESSED
-----------------------------------------------------
Reported as UNKNOWN and EXCLUDED from the score's denominator, so a setup is neither punished for
missing data nor flattered by pretending the check was made:

  * News catalyst        — no point-in-time news source. A gap IS measurable and is scored.
  * Level 2              — not available on this data plan at any timeframe.
  * Pre-market activity  — the feed carries regular-hours bars.
  * Spread               — live snapshots only, no history.
  * Time of day          — a daily bar has no time of day.
  * 1H trend             — insufficient hourly history to backtest over years.

LOOK-AHEAD
----------
Every criterion at bar `i` reads `df.iloc[:i+1]` and nothing later. A setup detected on bar i is
entered at bar i+1's OPEN. Stops and targets are evaluated on bars strictly after entry. The
timestamp at which the setup became detectable is recorded separately from the entry timestamp.
"""
import logging
from datetime import datetime, timezone

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)

EMA_FAST = 9
SMA_MID = 20
SMA_SLOW = 200
MIN_WARMUP = 220          # SMA200 plus room for a slope

# Criteria that this data cannot answer. Reported on every setup, never scored either way.
UNAVAILABLE = {
    "catalyst": "No point-in-time news source. The GAP is measured; the reason for it is not.",
    "level_2": "Depth-of-book is not available on this data plan at any timeframe.",
    "premarket": "The feed carries regular-hours bars only.",
    "spread": "Live snapshots carry a spread; history does not.",
    "time_of_day": "A daily bar has no time of day, so the 09:30-11:30 and 14:00-16:00 "
                   "windows cannot be applied.",
    "one_hour_trend": "Hourly history does not reach far enough back to backtest.",
}

DEFAULTS = {
    # --- structure ---
    "ma_slope_lookback": 5,        # bars used to call an MA rising or flat
    "min_ma_slope_pct": 0.10,      # below this the MA counts as FLAT, a low-quality marker

    # --- retracement ---
    "impulse_lookback": 20,        # bars searched for the bullish move being retraced
    "min_impulse_pct": 5.0,        # a "bullish impulse" must be at least this big
    "min_red_candles": 3,          # the screenshot says 3 consecutive red bars
    "retrace_min_pct": 40.0,       # the screenshot says 40-60%
    "retrace_max_pct": 60.0,
    "ma_touch_pct": 2.0,           # how close to an MA counts as reaching the MA area
    "doji_body_pct": 30.0,         # body <= this % of range counts as indecision
    "tail_ratio": 1.5,             # lower wick >= this x body counts as a bottoming tail
    "narrow_range_ratio": 0.7,     # range <= this x recent average counts as narrow

    # --- base breakout ---
    "base_min_bars": 5,
    "base_max_bars": 20,
    "base_max_width_pct": 8.0,     # tight base: high-to-low span as % of its midpoint
    "base_near_ma_pct": 3.0,       # base midpoint within this % of the 9EMA or 20SMA

    # --- momentum / liquidity ---
    "min_rel_volume": 1.0,         # vs the 50-day average
    "min_gap_pct": 0.0,            # a gap up of at least this much scores the gap criterion
    "min_avg_volume": 3_000_000,   # the video prefers 3-10M+ shares a day

    # --- risk ---
    "min_rr": 2.0,                 # the screenshot's "at least 2:1"
    "max_dollar_risk": 100.0,      # position size = this / risk per share
    "stop_buffer_pct": 0.2,        # stop sits this far below the reversal low / base low
    "max_stop_pct": 8.0,           # wider than this is the screenshot's "unmanageable stop"
    "target_method": "rr",         # "rr" = 2R; "measured" = base height projected

    # --- quality bands, as a share of the AVAILABLE criteria ---
    "high_quality_pct": 85.0,
    "medium_quality_pct": 65.0,
}


# ---------------------------------------------------------------- indicators

def compute_levels(df: pd.DataFrame) -> pd.DataFrame:
    """9 EMA, 20 SMA, 200 SMA, ATR and volume averages — all strictly backward-looking.

    `ewm`, `rolling` and `shift` only ever read earlier rows, so a value at row i is what was
    knowable at row i. No value here is centred, interpolated or back-filled.
    """
    out = pd.DataFrame(index=df.index)
    close = df["close"].astype(float)
    high = df["high"].astype(float)
    low = df["low"].astype(float)

    out["close"], out["open"] = close, df["open"].astype(float)
    out["high"], out["low"] = high, low
    out["volume"] = df["volume"].astype(float)

    out["ema9"] = close.ewm(span=EMA_FAST, adjust=False).mean()
    out["sma20"] = close.rolling(SMA_MID).mean()
    out["sma200"] = close.rolling(SMA_SLOW).mean()
    out["sma50"] = close.rolling(50).mean()

    prev_close = close.shift(1)
    tr = pd.concat([high - low, (high - prev_close).abs(), (low - prev_close).abs()], axis=1)
    out["atr14"] = tr.max(axis=1).rolling(14).mean()

    out["avg_volume50"] = out["volume"].rolling(50).mean()
    out["avg_range10"] = (high - low).rolling(10).mean()
    out["prev_close"] = prev_close
    return out


def _slope_pct(series: pd.Series, i: int, lookback: int) -> float | None:
    """Percentage change of a moving average over the last `lookback` bars, as at bar i."""
    j = i - lookback
    if j < 0:
        return None
    a, b = series.iloc[j], series.iloc[i]
    if pd.isna(a) or pd.isna(b) or a == 0:
        return None
    return float((b - a) / abs(a) * 100.0)


def weekly_trend(df: pd.DataFrame, i: int) -> str:
    """Higher-timeframe read, resampled from the SAME daily bars up to and including bar i.

    Stands in for the video's higher-timeframe check. It is not the 1H chart the video uses —
    with daily execution bars the timeframe one step up is weekly, and hourly history does not
    reach back far enough to backtest. Reported under its own name so it is never mistaken for
    an hourly reading.
    """
    window = df.iloc[:i + 1]
    if len(window) < 60:
        return "UNKNOWN"
    ts = pd.to_datetime(window["ts"], format="mixed", utc=True)
    weekly = (pd.DataFrame({"close": window["close"].astype(float).values}, index=ts)
              .resample("W").last().dropna())
    if len(weekly) < 12:
        return "UNKNOWN"
    ma = weekly["close"].rolling(10).mean()
    if pd.isna(ma.iloc[-1]):
        return "UNKNOWN"
    rising = len(ma.dropna()) >= 3 and ma.iloc[-1] > ma.iloc[-3]
    above = float(weekly["close"].iloc[-1]) > float(ma.iloc[-1])
    return "BULLISH" if (rising and above) else "NOT_BULLISH"


def daily_trend(lv: pd.DataFrame, i: int, cfg: dict) -> str:
    """The slower read of the execution timeframe: price against a rising 200 SMA.

    Deliberately different information from the 9/20 structure the setup itself uses, so this is
    not a restatement of the entry condition under another name.
    """
    close, sma200 = lv["close"].iloc[i], lv["sma200"].iloc[i]
    if pd.isna(sma200):
        return "UNKNOWN"
    slope = _slope_pct(lv["sma200"], i, 20)
    if slope is None:
        return "UNKNOWN"
    return "BULLISH" if (close > sma200 and slope > 0) else "NOT_BULLISH"


# ---------------------------------------------------------------- candle shapes

def _candle_shape(lv: pd.DataFrame, i: int, cfg: dict) -> dict:
    """Is bar i a doji, a bottoming tail, or a narrow-range bar?

    The screenshot names exactly these three as the reversal/indecision candle at the moving
    averages, so exactly these three are detected — not a wider family chosen to fit results.
    """
    o, c = float(lv["open"].iloc[i]), float(lv["close"].iloc[i])
    h, l = float(lv["high"].iloc[i]), float(lv["low"].iloc[i])
    rng = h - l
    body = abs(c - o)
    lower_wick = min(o, c) - l
    avg_range = lv["avg_range10"].iloc[i]

    doji = bool(rng > 0 and (body / rng * 100.0) <= cfg["doji_body_pct"])
    tail = bool(body > 0 and lower_wick >= body * cfg["tail_ratio"] and lower_wick > 0)
    narrow = bool(not pd.isna(avg_range) and avg_range > 0
                  and rng <= avg_range * cfg["narrow_range_ratio"])

    kinds = [k for k, on in (("doji", doji), ("bottoming_tail", tail),
                             ("narrow_range", narrow)) if on]
    return {"is_reversal_candle": bool(kinds), "kinds": kinds,
            "body_pct_of_range": round(body / rng * 100.0, 1) if rng > 0 else None}


# ---------------------------------------------------------------- shared structure

def _structure(lv: pd.DataFrame, i: int, cfg: dict) -> dict:
    """The 9/20 structure both setups share, plus the low-quality markers."""
    ema9, sma20, sma200 = (lv["ema9"].iloc[i], lv["sma20"].iloc[i], lv["sma200"].iloc[i])
    close = float(lv["close"].iloc[i])
    lb = cfg["ma_slope_lookback"]
    ema_slope = _slope_pct(lv["ema9"], i, lb)
    sma_slope = _slope_pct(lv["sma20"], i, lb)

    flat = cfg["min_ma_slope_pct"]
    stacked = bool(not pd.isna(ema9) and not pd.isna(sma20) and ema9 > sma20)
    ema_rising = bool(ema_slope is not None and ema_slope > flat)
    sma_rising = bool(sma_slope is not None and sma_slope > flat)
    both_flat = bool(ema_slope is not None and sma_slope is not None
                     and abs(ema_slope) <= flat and abs(sma_slope) <= flat)

    # "Price trading below the moving averages without bullish structure" — a low-quality marker
    # from the screenshot, and a hard rejection for a long-only system.
    below_mas = bool(not pd.isna(sma20) and close < sma20 and not pd.isna(ema9) and close < ema9)

    # "Price overextended far away from the moving averages" — measured against ATR so it adapts
    # to how volatile the stock actually is rather than a fixed percentage.
    atr = lv["atr14"].iloc[i]
    extension_atr = (float((close - sma20) / atr) if not pd.isna(atr) and atr > 0
                     and not pd.isna(sma20) else None)

    return {
        "ema9": round(float(ema9), 4) if not pd.isna(ema9) else None,
        "sma20": round(float(sma20), 4) if not pd.isna(sma20) else None,
        "sma200": round(float(sma200), 4) if not pd.isna(sma200) else None,
        "ema9_direction": ("RISING" if ema_rising else "FALLING" if (ema_slope or 0) < -flat
                           else "FLAT"),
        "sma20_direction": ("RISING" if sma_rising else "FALLING" if (sma_slope or 0) < -flat
                            else "FLAT"),
        "ema9_slope_pct": round(ema_slope, 3) if ema_slope is not None else None,
        "sma20_slope_pct": round(sma_slope, 3) if sma_slope is not None else None,
        "stacked_9_over_20": stacked,
        "ema9_rising": ema_rising,
        "sma20_rising": sma_rising,
        "both_mas_flat": both_flat,
        "price_below_mas": below_mas,
        "price_vs_ema9": ("ABOVE" if not pd.isna(ema9) and close > ema9 else "BELOW"),
        "price_vs_sma20": ("ABOVE" if not pd.isna(sma20) and close > sma20 else "BELOW"),
        "price_vs_sma200": ("ABOVE" if not pd.isna(sma200) and close > sma200 else "BELOW"),
        "extension_atr": round(extension_atr, 2) if extension_atr is not None else None,
        "overextended": bool(extension_atr is not None and extension_atr > 4.0),
    }


def _momentum(lv: pd.DataFrame, i: int, cfg: dict) -> dict:
    """Gap, relative volume and liquidity. The CATALYST itself is not knowable here."""
    close = float(lv["close"].iloc[i])
    open_ = float(lv["open"].iloc[i])
    prev_close = lv["prev_close"].iloc[i]
    vol = float(lv["volume"].iloc[i])
    avg_vol = lv["avg_volume50"].iloc[i]

    gap_pct = (float((open_ - prev_close) / prev_close * 100.0)
               if not pd.isna(prev_close) and prev_close else None)
    rel_vol = float(vol / avg_vol) if not pd.isna(avg_vol) and avg_vol > 0 else None

    return {
        "gap_pct": round(gap_pct, 2) if gap_pct is not None else None,
        "gap_up": bool(gap_pct is not None and gap_pct > cfg["min_gap_pct"]),
        "volume": int(vol),
        "avg_volume50": int(avg_vol) if not pd.isna(avg_vol) else None,
        "relative_volume": round(rel_vol, 2) if rel_vol is not None else None,
        "strong_relative_volume": bool(rel_vol is not None and rel_vol >= cfg["min_rel_volume"]),
        "liquid_enough": (None if pd.isna(avg_vol)
                          else bool(avg_vol >= cfg["min_avg_volume"])),
        # Stated explicitly on every setup rather than left to be inferred from a missing field.
        "catalyst": "UNKNOWN",
        "catalyst_note": UNAVAILABLE["catalyst"],
        "premarket": "UNKNOWN",
        "premarket_note": UNAVAILABLE["premarket"],
        "spread": "UNKNOWN",
        "spread_note": UNAVAILABLE["spread"],
    }


# ---------------------------------------------------------------- scoring

def _score(criteria: list) -> dict:
    """Score over the criteria that could actually be MEASURED.

    Each entry is (key, state, detail) where state is True, False or None. None means the data
    cannot answer it, and it is removed from the denominator entirely — a setup is neither
    punished for a missing news feed nor flattered by pretending the check was made. The count of
    unknowns is reported so nobody reads "10 of 10" without noticing it was 10 of 12 criteria.
    """
    measured = [(k, s, d) for k, s, d in criteria if s is not None]
    unknown = [(k, d) for k, s, d in criteria if s is None]
    passed = [(k, d) for k, s, d in measured if s]
    failed = [(k, d) for k, s, d in measured if not s]
    pct = (len(passed) / len(measured) * 100.0) if measured else None
    return {
        "score": len(passed),
        "score_out_of": len(measured),
        "score_pct": round(pct, 1) if pct is not None else None,
        "criteria_total": len(criteria),
        "passed": [k for k, _ in passed],
        "failed": [k for k, _ in failed],
        "unknown": [k for k, _ in unknown],
        "reasons_passed": [d for _, d in passed],
        "reasons_failed": [d for _, d in failed],
        "reasons_unknown": [d for _, d in unknown],
    }


def _quality(scored: dict, rejections: list, cfg: dict) -> str:
    """High / Medium / Low / Invalid.

    Any rejection makes it INVALID regardless of score: the screenshot's low-quality column is a
    filter, not a deduction. A setup that fails 2:1 is not a slightly worse setup, it is one the
    strategy says not to take.
    """
    if rejections:
        return "INVALID"
    pct = scored.get("score_pct")
    if pct is None:
        return "INVALID"
    if pct >= cfg["high_quality_pct"]:
        return "HIGH"
    if pct >= cfg["medium_quality_pct"]:
        return "MEDIUM"
    return "LOW"


# ---------------------------------------------------------------- risk

def _risk_block(entry: float, stop: float, target: float | None, cfg: dict) -> dict:
    """Entry, stop, target, size and R:R for a LONG position.

    Stop is always below entry and target always above it. Position size follows the video's
    arithmetic exactly: max dollar risk divided by risk per share, so risk is capped by
    construction rather than by intention.
    """
    risk_per_share = entry - stop
    if risk_per_share <= 0:
        return {"valid": False, "reason": "stop is not below entry — not a long setup"}

    if target is None:
        target = entry + risk_per_share * cfg["min_rr"]
    reward_per_share = target - entry
    rr = reward_per_share / risk_per_share if risk_per_share else None
    shares = int(cfg["max_dollar_risk"] // risk_per_share)
    stop_pct = risk_per_share / entry * 100.0

    # Compare the ROUNDED ratio, which is also the one displayed.
    #
    # When the target is derived as entry + risk * min_rr, the ratio comes back as 1.9999999996
    # and a raw `>= 2.0` rejects it. The page then reads "Risk/reward 2.0 is below the 2.0:1
    # minimum" — a sentence that cannot be true, produced by correct arithmetic. Deciding on the
    # same number that is shown makes the message and the decision incapable of disagreeing.
    rr_shown = round(rr, 2) if rr is not None else None
    meets_rr = bool(rr_shown is not None and rr_shown >= cfg["min_rr"])

    return {
        "valid": True,
        "entry_price": round(entry, 4),
        "stop_price": round(stop, 4),
        "target_price": round(target, 4),
        "risk_per_share": round(risk_per_share, 4),
        "reward_per_share": round(reward_per_share, 4),
        "risk_reward": rr_shown,
        "stop_distance_pct": round(stop_pct, 2),
        "position_size_shares": shares,
        "max_dollar_loss": round(shares * risk_per_share, 2),
        "potential_dollar_gain": round(shares * reward_per_share, 2),
        "meets_min_rr": meets_rr,
        "stop_is_tight": bool(stop_pct <= cfg["max_stop_pct"]),
    }


# ---------------------------------------------------------------- setup 1: retracement

def detect_retracement(lv: pd.DataFrame, df: pd.DataFrame, i: int, cfg: dict) -> dict | None:
    """A bullish retracement, evaluated using bars 0..i only.

    "Clean pullback in rising 9 EMA / 20 SMA stacked under price", with three consecutive red
    bars, a 40-60% orderly retracement, and a reversal candle at the moving averages.
    """
    st = _structure(lv, i, cfg)
    mo = _momentum(lv, i, cfg)

    # --- the pullback itself: N consecutive lower closes ending at bar i ---
    reds = 0
    j = i
    while j > 0 and float(lv["close"].iloc[j]) < float(lv["close"].iloc[j - 1]):
        reds += 1
        j -= 1
    # Bar i may be the reversal candle rather than a red bar, so allow the red run to end at i-1.
    if reds == 0:
        k = i - 1
        while k > 0 and float(lv["close"].iloc[k]) < float(lv["close"].iloc[k - 1]):
            reds += 1
            k -= 1
        j = k
    pullback_start = j                                  # the swing high the pullback began from
    if pullback_start <= 0 or reds == 0:
        return None

    # --- the impulse being retraced: the low before that swing high ---
    lo_window = lv["low"].iloc[max(0, pullback_start - cfg["impulse_lookback"]):pullback_start + 1]
    if lo_window.empty:
        return None
    impulse_low = float(lo_window.min())
    impulse_high = float(lv["high"].iloc[pullback_start:i + 1].max())
    impulse_pct = ((impulse_high - impulse_low) / impulse_low * 100.0) if impulse_low else 0.0
    if impulse_high <= impulse_low:
        return None

    pullback_low = float(lv["low"].iloc[pullback_start:i + 1].min())
    retrace_pct = (impulse_high - pullback_low) / (impulse_high - impulse_low) * 100.0

    # --- did the pullback reach the moving-average area? ---
    ema9, sma20 = st["ema9"], st["sma20"]
    touch = cfg["ma_touch_pct"] / 100.0
    reached = bool(
        (ema9 is not None and pullback_low <= ema9 * (1 + touch)) or
        (sma20 is not None and pullback_low <= sma20 * (1 + touch)))

    shape = _candle_shape(lv, i, cfg)
    at_ma = bool(reached and shape["is_reversal_candle"])

    # --- risk: stop below the reversal candle's low, per the screenshot ---
    entry = float(lv["close"].iloc[i])         # provisional; the real fill is next bar's open
    stop = float(lv["low"].iloc[i]) * (1 - cfg["stop_buffer_pct"] / 100.0)
    target = impulse_high if impulse_high > entry else None
    risk = _risk_block(entry, stop, target, cfg)
    if not risk["valid"]:
        return None

    d_trend = daily_trend(lv, i, cfg)
    w_trend = weekly_trend(df, i)

    criteria = [
        ("ma_alignment", st["stacked_9_over_20"], "9 EMA above the 20 SMA"),
        ("ema9_rising", st["ema9_rising"], f"9 EMA rising ({st['ema9_slope_pct']}% over "
                                           f"{cfg['ma_slope_lookback']} bars)"),
        ("sma20_rising", st["sma20_rising"], f"20 SMA rising ({st['sma20_slope_pct']}%)"),
        ("strong_momentum", bool(impulse_pct >= cfg["min_impulse_pct"]
                                 and mo["strong_relative_volume"]),
         f"impulse of {impulse_pct:.1f}% on relative volume {mo['relative_volume']}"),
        ("gap_up", mo["gap_up"], f"gap of {mo['gap_pct']}%"),
        ("three_red_candles", bool(reds >= cfg["min_red_candles"]),
         f"{reds} consecutive lower closes"),
        ("retracement_40_60", bool(cfg["retrace_min_pct"] <= retrace_pct <= cfg["retrace_max_pct"]),
         f"retraced {retrace_pct:.1f}% of the move"),
        ("reached_ma_area", reached, "pullback reached the 9 EMA / 20 SMA area"),
        ("reversal_candle_at_ma", at_ma,
         f"reversal candle at the MAs ({', '.join(shape['kinds']) or 'none'})"),
        ("daily_trend_bullish", None if d_trend == "UNKNOWN" else d_trend == "BULLISH",
         f"daily trend {d_trend}"),
        ("higher_timeframe_bullish", None if w_trend == "UNKNOWN" else w_trend == "BULLISH",
         f"weekly trend {w_trend}"),
        ("risk_reward_2to1", risk["meets_min_rr"], f"R:R {risk['risk_reward']}"),
        # Never guessed. See UNAVAILABLE.
        ("one_hour_trend", None, UNAVAILABLE["one_hour_trend"]),
        ("catalyst_confirmed", None, UNAVAILABLE["catalyst"]),
        ("level_2_confirms", None, UNAVAILABLE["level_2"]),
        ("premarket_momentum", None, UNAVAILABLE["premarket"]),
        ("time_of_day_window", None, UNAVAILABLE["time_of_day"]),
    ]

    rejections = _rejections(st, mo, risk, cfg, chaotic=bool(retrace_pct > 90.0))
    scored = _score(criteria)
    return {
        "setup_type": "BULLISH_RETRACEMENT",
        "detected_index": i,
        "detected_date": str(df["ts"].iloc[i]),
        "quality": _quality(scored, rejections, cfg),
        "structure": st, "momentum": mo, "risk": risk,
        "daily_trend": d_trend, "weekly_trend": w_trend, "one_hour_trend": "UNKNOWN",
        "level_2": "UNKNOWN",
        "retracement": {
            "impulse_low": round(impulse_low, 4), "impulse_high": round(impulse_high, 4),
            "impulse_pct": round(impulse_pct, 2),
            "retracement_pct": round(retrace_pct, 1),
            "red_candles": reds,
            "pullback_low": round(pullback_low, 4),
            "reached_ma_area": reached,
            "reversal_candle": shape["kinds"] or None,
        },
        "scored": scored, "rejections": rejections,
    }


# ---------------------------------------------------------------- setup 2: base breakout

def detect_base_breakout(lv: pd.DataFrame, df: pd.DataFrame, i: int, cfg: dict) -> dict | None:
    """A bullish base breakout, evaluated using bars 0..i only.

    "Tight consolidation near 20 SMA & 9 EMA", broken to the upside. The breakout must come out
    of a base that was already there — a spike from nothing is not this setup.
    """
    st = _structure(lv, i, cfg)
    mo = _momentum(lv, i, cfg)
    close = float(lv["close"].iloc[i])

    # --- find the tightest qualifying base ENDING at bar i-1, so the breakout is bar i ---
    best = None
    for length in range(cfg["base_min_bars"], cfg["base_max_bars"] + 1):
        start = i - length
        if start < 1:
            break
        window = lv.iloc[start:i]                       # excludes the breakout bar itself
        if window.empty:
            continue
        b_high, b_low = float(window["high"].max()), float(window["low"].min())
        mid = (b_high + b_low) / 2.0
        if mid <= 0:
            continue
        width_pct = (b_high - b_low) / mid * 100.0
        if width_pct > cfg["base_max_width_pct"]:
            continue
        if best is None or width_pct < best["width_pct"]:
            best = {"start": start, "bars": length, "high": b_high, "low": b_low,
                    "mid": mid, "width_pct": width_pct}
    if best is None:
        return None

    # --- the breakout: bar i closes above the base high ---
    broke_out = bool(close > best["high"])
    if not broke_out:
        return None

    ema9, sma20 = st["ema9"], st["sma20"]
    near = cfg["base_near_ma_pct"] / 100.0
    base_near_ma = bool(
        (ema9 is not None and abs(best["mid"] - ema9) / ema9 <= near) or
        (sma20 is not None and abs(best["mid"] - sma20) / sma20 <= near))

    entry = close                                       # provisional; real fill is next open
    stop = best["low"] * (1 - cfg["stop_buffer_pct"] / 100.0)
    target = (entry + (best["high"] - best["low"]) if cfg["target_method"] == "measured"
              else None)
    risk = _risk_block(entry, stop, target, cfg)
    if not risk["valid"]:
        return None

    d_trend = daily_trend(lv, i, cfg)
    w_trend = weekly_trend(df, i)
    prior = lv["close"].iloc[max(0, best["start"] - cfg["impulse_lookback"]):best["start"] + 1]
    prior_pct = (((float(lv["close"].iloc[best["start"]]) - float(prior.min())) / float(prior.min())
                  * 100.0) if len(prior) and float(prior.min()) > 0 else 0.0)

    criteria = [
        ("ma_alignment", st["stacked_9_over_20"], "9 EMA above the 20 SMA"),
        ("ema9_rising", st["ema9_rising"], f"9 EMA rising ({st['ema9_slope_pct']}%)"),
        ("sma20_rising", st["sma20_rising"], f"20 SMA rising ({st['sma20_slope_pct']}%)"),
        ("strong_momentum", bool(prior_pct >= cfg["min_impulse_pct"]
                                 and mo["strong_relative_volume"]),
         f"prior advance {prior_pct:.1f}% on relative volume {mo['relative_volume']}"),
        ("gap_up", mo["gap_up"], f"gap of {mo['gap_pct']}%"),
        ("tight_consolidation", bool(best["width_pct"] <= cfg["base_max_width_pct"]),
         f"base {best['width_pct']:.1f}% wide over {best['bars']} bars"),
        ("base_near_mas", base_near_ma, "base formed at the 9 EMA / 20 SMA"),
        ("clear_breakout", broke_out,
         f"closed {close:.2f} above the base high {best['high']:.2f}"),
        ("daily_trend_bullish", None if d_trend == "UNKNOWN" else d_trend == "BULLISH",
         f"daily trend {d_trend}"),
        ("higher_timeframe_bullish", None if w_trend == "UNKNOWN" else w_trend == "BULLISH",
         f"weekly trend {w_trend}"),
        ("tight_stop", risk["stop_is_tight"], f"stop {risk['stop_distance_pct']}% away"),
        ("risk_reward_2to1", risk["meets_min_rr"], f"R:R {risk['risk_reward']}"),
        ("one_hour_trend", None, UNAVAILABLE["one_hour_trend"]),
        ("catalyst_confirmed", None, UNAVAILABLE["catalyst"]),
        ("level_2_confirms", None, UNAVAILABLE["level_2"]),
        ("premarket_momentum", None, UNAVAILABLE["premarket"]),
        ("time_of_day_window", None, UNAVAILABLE["time_of_day"]),
    ]

    rejections = _rejections(st, mo, risk, cfg,
                             chaotic=bool(best["width_pct"] > cfg["base_max_width_pct"]))
    scored = _score(criteria)
    return {
        "setup_type": "BULLISH_BASE_BREAKOUT",
        "detected_index": i,
        "detected_date": str(df["ts"].iloc[i]),
        "quality": _quality(scored, rejections, cfg),
        "structure": st, "momentum": mo, "risk": risk,
        "daily_trend": d_trend, "weekly_trend": w_trend, "one_hour_trend": "UNKNOWN",
        "level_2": "UNKNOWN",
        "base": {
            "base_high": round(best["high"], 4), "base_low": round(best["low"], 4),
            "base_bars": best["bars"], "base_width_pct": round(best["width_pct"], 2),
            "breakout_price": round(close, 4), "base_near_mas": base_near_ma,
        },
        "scored": scored, "rejections": rejections,
    }


def _rejections(st: dict, mo: dict, risk: dict, cfg: dict, chaotic: bool = False) -> list:
    """The screenshot's LOW-QUALITY column, applied as hard filters rather than deductions.

    Long-only means a bearish structure produces NO SETUP. It never produces a short.
    """
    out = []
    if st["both_mas_flat"]:
        out.append("Moving averages are flat — no established trend to pull back within.")
    if st["price_below_mas"]:
        out.append("Price is below both moving averages with no bullish structure. "
                   "NO LONG SETUP — this is not a short signal, it is an absence of one.")
    if not st["stacked_9_over_20"]:
        out.append("9 EMA is not above the 20 SMA — moving averages are crossed or inverted.")
    if st["overextended"]:
        out.append(f"Price is {st['extension_atr']} ATR above the 20 SMA — overextended, so a "
                   f"pullback here is not a low-risk entry.")
    if mo["relative_volume"] is not None and mo["relative_volume"] < 0.7:
        out.append(f"Relative volume {mo['relative_volume']} — weak participation.")
    if mo["liquid_enough"] is False:
        out.append(f"Average volume {mo['avg_volume50']:,} is below the "
                   f"{cfg['min_avg_volume']:,} liquidity floor.")
    if not risk["meets_min_rr"]:
        out.append(f"Risk/reward {risk['risk_reward']} is below the {cfg['min_rr']}:1 minimum.")
    if not risk["stop_is_tight"]:
        out.append(f"Stop is {risk['stop_distance_pct']}% away — wider than the "
                   f"{cfg['max_stop_pct']}% maximum.")
    if chaotic:
        out.append("Price action is too disorderly to call this a clean setup.")
    return out


# ---------------------------------------------------------------- simulation

def simulate_ticker(ticker: str, df: pd.DataFrame, config: dict | None = None) -> dict:
    """Walk one ticker bar by bar, detecting setups and following each trade to its result.

    THE FIVE STAGES ARE KEPT SEPARATE, as asked:
        1. setup detected   — bar i, using bars 0..i only
        2. entry triggered  — bar i+1's OPEN, never bar i's close
        3. stop hit         — bars strictly after entry
        4. target hit       — bars strictly after entry
        5. exited           — whichever came first, or the end of the data

    A setup that is INVALID is still recorded, with its rejection reasons, but never entered.
    Seeing what the filters threw away is how you tell a strict rule from a broken one.
    """
    cfg = {**DEFAULTS, **(config or {})}
    d = df.reset_index(drop=True)
    lv = compute_levels(d)
    n = len(d)

    setups, trades = [], []
    open_trade = None
    wanted = cfg.get("setup_types") or ["BULLISH_RETRACEMENT", "BULLISH_BASE_BREAKOUT"]

    for i in range(MIN_WARMUP, n - 1):          # -1: an entry needs a NEXT bar to fill against
        # ---- manage an open position first, so one is never double-entered ----
        if open_trade is not None:
            high, low = float(d["high"].iloc[i]), float(d["low"].iloc[i])
            exit_price = exit_reason = None
            # Stop checked before target: if a bar spans both, assume the worse fill rather than
            # the flattering one. The intrabar path is unknown and this is the honest assumption.
            if low <= open_trade["stop_price"]:
                exit_price, exit_reason = open_trade["stop_price"], "STOP_HIT"
            elif high >= open_trade["target_price"]:
                exit_price, exit_reason = open_trade["target_price"], "TARGET_HIT"
            elif (i - open_trade["entry_index"]) >= cfg.get("max_holding_days", 40):
                exit_price, exit_reason = float(d["close"].iloc[i]), "TIME_LIMIT"

            if exit_price is not None:
                shares = open_trade["position_size_shares"]
                open_trade.update({
                    "exit_date": str(d["ts"].iloc[i]), "exit_price": round(exit_price, 4),
                    "exit_reason": exit_reason,
                    "holding_days": i - open_trade["entry_index"],
                    "return_pct": round((exit_price - open_trade["entry_price"])
                                        / open_trade["entry_price"] * 100.0, 4),
                    "dollar_result": round((exit_price - open_trade["entry_price"]) * shares, 2),
                })
                trades.append(open_trade)
                open_trade = None
            continue

        # ---- look for a setup, using only bars up to and including i ----
        found = None
        if "BULLISH_RETRACEMENT" in wanted:
            found = detect_retracement(lv, d, i, cfg)
        if found is None and "BULLISH_BASE_BREAKOUT" in wanted:
            found = detect_base_breakout(lv, d, i, cfg)
        if found is None:
            continue

        setups.append({k: v for k, v in found.items() if k != "structure"} | {
            "ticker": ticker,
            "structure": found["structure"],
        })

        # ---- entry trigger: only a tradeable quality, filled at the NEXT bar's open ----
        min_quality = cfg.get("min_quality", "MEDIUM")
        rank = {"HIGH": 3, "MEDIUM": 2, "LOW": 1, "INVALID": 0}
        if rank[found["quality"]] < rank[min_quality]:
            continue

        fill = float(d["open"].iloc[i + 1])
        risk = found["risk"]
        # The stop and target were computed from the setup bar's close; re-derive the share count
        # against the ACTUAL fill so the dollar risk cap holds at the price really paid.
        stop = risk["stop_price"]
        if fill <= stop:
            continue                              # gapped through the stop — not a takeable trade
        refit = _risk_block(fill, stop, risk["target_price"], cfg)
        if not refit["valid"] or not refit["meets_min_rr"]:
            continue

        open_trade = {
            "ticker": ticker,
            "setup_type": found["setup_type"],
            "quality": found["quality"],
            "quality_score_pct": found["scored"]["score_pct"],
            "detected_date": found["detected_date"],
            "entry_date": str(d["ts"].iloc[i + 1]),
            "entry_index": i + 1,
            "entry_price": round(fill, 4),
            "stop_price": refit["stop_price"],
            "target_price": refit["target_price"],
            "risk_per_share": refit["risk_per_share"],
            "reward_per_share": refit["reward_per_share"],
            "risk_reward": refit["risk_reward"],
            "position_size_shares": refit["position_size_shares"],
            "max_dollar_loss": refit["max_dollar_loss"],
            "potential_dollar_gain": refit["potential_dollar_gain"],
        }

    # A position still open when the data ends is settled at the last close and reported, not
    # discarded — an unresolved trade is a real outcome.
    if open_trade is not None:
        last = float(d["close"].iloc[n - 1])
        shares = open_trade["position_size_shares"]
        open_trade.update({
            "exit_date": str(d["ts"].iloc[n - 1]), "exit_price": round(last, 4),
            "exit_reason": "STILL_OPEN_AT_END",
            "holding_days": (n - 1) - open_trade["entry_index"],
            "return_pct": round((last - open_trade["entry_price"])
                                / open_trade["entry_price"] * 100.0, 4),
            "dollar_result": round((last - open_trade["entry_price"]) * shares, 2),
        })
        trades.append(open_trade)

    return {"trades": trades, "setups": setups, "bars": n}


LIMITATIONS = [
    "THIS IS A DAILY-BAR TRANSLATION OF AN INTRADAY STRATEGY. The original is executed on 1-5 "
    "minute charts on pre-market gappers. The structural rules here are faithful; the timeframe "
    "is not. A good result would not show that the original strategy works, and a poor one would "
    "not show that it fails.",
    "NO CATALYST DATA. The strategy's first filter is a news catalyst. There is no point-in-time "
    "news source here, so every setup carries catalyst UNKNOWN. The GAP is measured; the reason "
    "for it is not.",
    "NO LEVEL 2. Depth-of-book is unavailable on this data plan, so the entry-confirmation step "
    "is never applied. Setups are detected without it and marked UNKNOWN.",
    "NO PRE-MARKET DATA, so the gapper screen that starts the original process cannot be run. "
    "The universe here is the fifty tracked stocks, not the day's movers — which is a materially "
    "different selection method.",
    "NO TIME-OF-DAY FILTER. A daily bar has no time of day, so the 09:30-11:30 and 14:00-16:00 "
    "windows are not applied.",
    "NO 1-HOUR TREND. Hourly history does not reach back far enough to backtest, so the "
    "higher-timeframe check uses WEEKLY bars resampled from the same daily series.",
    "Intrabar path is unknown. When one bar spans both stop and target, the STOP is assumed hit "
    "first — the pessimistic assumption, chosen deliberately.",
    "SURVIVORSHIP BIAS: these fifty companies were chosen knowing which ones did well. A rule "
    "that buys pullbacks in uptrends is flattered by a universe with no failures in it.",
    "Fills use the next bar's open. Slippage and commission are not modelled here.",
]


# ---------------------------------------------------------------- runner

def _summarise(trades: list) -> dict:
    rets = [t["return_pct"] for t in trades if t.get("return_pct") is not None]
    if not rets:
        return {"trades": 0, "mean_pct": None, "median_pct": None, "win_rate_pct": None,
                "best_pct": None, "worst_pct": None, "avg_holding_days": None,
                "total_dollar_result": 0.0, "expectancy_r": None}
    s = pd.Series(rets, dtype="float64")
    holds = [t["holding_days"] for t in trades if t.get("holding_days") is not None]
    # Expectancy in R is the number that matters for a fixed-risk system: every trade risks the
    # same dollar amount, so the average outcome expressed in units of that risk IS the edge.
    rs = [(t["dollar_result"] / t["max_dollar_loss"])
          for t in trades if t.get("max_dollar_loss")]
    return {
        "trades": len(rets),
        "mean_pct": round(float(s.mean()), 2),
        "median_pct": round(float(s.median()), 2),
        "win_rate_pct": round(float((s > 0).mean() * 100), 1),
        "best_pct": round(float(s.max()), 2),
        "worst_pct": round(float(s.min()), 2),
        "avg_holding_days": round(sum(holds) / len(holds), 1) if holds else None,
        "total_dollar_result": round(sum(t.get("dollar_result") or 0 for t in trades), 2),
        "expectancy_r": round(sum(rs) / len(rs), 3) if rs else None,
    }


def _by_key(items: list, key: str) -> dict:
    out = {}
    for it in items:
        out.setdefault(it.get(key) or "UNKNOWN", []).append(it)
    return out


def run_bullish_setup_test(bars_by_ticker: dict, tickers: list,
                           config: dict | None = None) -> dict:
    cfg = {**DEFAULTS, **(config or {})}
    per_ticker, all_trades, all_setups, skipped = {}, [], [], {}

    for t in tickers:
        df = bars_by_ticker.get(t)
        if df is None or len(df) < MIN_WARMUP + 30:
            skipped[t] = (f"needs more than {MIN_WARMUP + 30} daily bars, "
                          f"has {0 if df is None else len(df)}")
            continue
        out = simulate_ticker(t, df.reset_index(drop=True), cfg)
        per_ticker[t] = {"summary": _summarise(out["trades"]),
                         "setups_detected": len(out["setups"])}
        all_trades.extend(out["trades"])
        all_setups.extend(out["setups"])

    tested = [t for t in tickers if t not in skipped]
    by_quality = _by_key(all_setups, "quality")
    by_type = _by_key(all_trades, "setup_type")

    result = {
        "config": {**{k: v for k, v in cfg.items() if not callable(v)},
                   "long_only": True,
                   "rule": [
                       "LONG ONLY. A bearish stock produces NO SETUP, never a short.",
                       "Setup 1 — BULLISH RETRACEMENT: rising 9 EMA above a rising 20 SMA, both "
                       f"under price; {cfg['min_red_candles']} consecutive lower closes; "
                       f"{cfg['retrace_min_pct']:.0f}-{cfg['retrace_max_pct']:.0f}% retracement "
                       "into the MA area; a doji, bottoming tail or narrow-range bar at the MAs.",
                       "Setup 2 — BULLISH BASE BREAKOUT: same MA structure; a base no wider than "
                       f"{cfg['base_max_width_pct']:.0f}% over {cfg['base_min_bars']}-"
                       f"{cfg['base_max_bars']} bars formed at the MAs; a close above the base high.",
                       f"Both require at least {cfg['min_rr']}:1 reward-to-risk or they are "
                       "rejected as INVALID.",
                       f"Position size = ${cfg['max_dollar_risk']:.0f} risk / (entry - stop).",
                       "Entry fills at the NEXT bar's open after detection. Never that bar's close.",
                   ]},
        "setups_detected": len(all_setups),
        "setups_by_quality": {q: len(v) for q, v in by_quality.items()},
        "overall": _summarise(all_trades),
        "by_setup_type": {k: _summarise(v) for k, v in by_type.items()},
        "by_quality": {q: _summarise([t for t in all_trades if t.get("quality") == q])
                       for q in ("HIGH", "MEDIUM", "LOW")},
        "by_exit_reason": {k: _summarise(v)
                           for k, v in sorted(_by_key(all_trades, "exit_reason").items())},
        "by_ticker": per_ticker,
        "tickers_tested": tested,
        "tickers_skipped": skipped,
        "unavailable_criteria": UNAVAILABLE,
        "trades": sorted(all_trades, key=lambda t: str(t.get("entry_date"))),
        "setups": sorted(all_setups, key=lambda s: str(s.get("detected_date")))[:400],
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
    result["warnings"] = _warnings(result, cfg)
    result["limitations"] = LIMITATIONS
    return result


def _warnings(result: dict, cfg: dict) -> list:
    """Said before any return figure gets read."""
    out = ["Every setup on this page carries catalyst, Level 2, pre-market, spread and "
           "time-of-day as UNKNOWN. Those are five of the strategy's own criteria, and this data "
           "cannot answer any of them — the score is out of what remained."]
    n = result["overall"]["trades"]
    if n == 0:
        out.append("No setup passed the filters and produced a trade. That is a result, not a "
                   "failure: the rules as specified did not occur in this universe and period.")
        return out
    if n < 30:
        out.append(f"Only {n} trades. Below about 30 these numbers are noise — one good or bad "
                   f"trade moves the average materially.")
    invalid = result["setups_by_quality"].get("INVALID", 0)
    total = result["setups_detected"] or 1
    if invalid / total > 0.7:
        out.append(f"{invalid} of {total} detected setups were rejected as INVALID. The pattern "
                   f"appears often but rarely with acceptable risk/reward or structure.")
    exp = result["overall"].get("expectancy_r")
    if exp is not None:
        out.append(f"Expectancy is {exp}R per trade — with a fixed ${cfg['max_dollar_risk']:.0f} "
                   f"risk, that is ${exp * cfg['max_dollar_risk']:.2f} expected per trade before "
                   f"costs. Negative means the rule lost money at this risk level.")
    return out
