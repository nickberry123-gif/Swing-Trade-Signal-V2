// Signals page — strategy v2.0.
//
// Two scores, three gates, and a change log. The order on the page is deliberate: CHANGES first,
// then sell triggers, then the ranked list. A level-based table answers "what is it now"; the
// stated reason this page exists is not missing a change on something already owned, and that is
// a question about what MOVED.
//
// UNKNOWN is never rendered as a zero or a pass anywhere below.

const STOCKS_BY_TICKER = {};
(window.STOCK_UNIVERSE || []).forEach((s) => { STOCKS_BY_TICKER[s.ticker] = s; });

const ACTION_CLASS = {
  "BUY": "num-pos",
  "GOOD STOCK, POOR ENTRY": "",
  "WATCH": "",
  "AVOID": "num-neg",
  "UNAVAILABLE": "text-dim",
};

function scoreClass(score) {
  if (score === null || score === undefined) return "text-dim";
  if (score >= 75) return "num-pos";
  if (score >= 55) return "";
  return "num-neg";
}

function scoreBlock(label, score, band, unknownList, availableWeight) {
  const unknown = (unknownList || []).length;
  const outOf = availableWeight === undefined || availableWeight === null ? "" :
    `<div class="score-max">${unknown ? `${availableWeight} of 100 pts measurable` : "all 100 pts measurable"}</div>`;
  return `<div class="level-box">
    <div class="lk">${label}</div>
    <div class="lv ${scoreClass(score)}" style="font-size:20px;">${score === null || score === undefined ? "—" : fmtNum(score, 1)}</div>
    <div class="yc-sub text-dim">${band || ""}</div>
    ${outOf}
  </div>`;
}

function gateList(gates) {
  const checks = (gates || {}).checks || [];
  return checks.map((c) => `<div style="font-size:11.5px;" class="${c.passed ? "num-pos" : "num-neg"}">
      ${c.passed ? "PASS" : "BLOCKED"} — ${c.gate}
      <span class="text-dim">(${c.detail})</span>
    </div>`).join("");
}

function componentRows(block) {
  const comps = (block || {}).components || {};
  const rows = Object.keys(comps).map((k) => {
    const c = comps[k];
    return `<div style="font-size:11px;" class="text-dim">${k.replace(/_/g, " ")}
      — ${fmtNum(c.points, 1)} of ${c.weight}</div>`;
  });
  (block.unknown || []).forEach((k) => {
    rows.push(`<div style="font-size:11px;" class="text-dim">${k.replace(/_/g, " ")}
      — <strong>UNKNOWN</strong>, weight removed from the total</div>`);
  });
  return rows.join("");
}

function levelBox(label, value) {
  return `<div class="level-box"><div class="lk">${label}</div><div class="lv">${fmtPrice(value)}</div></div>`;
}

function renderCard(r, rank) {
  const stock = STOCKS_BY_TICKER[r.ticker] || {};
  if (r.data_status !== "OK") {
    return `<div class="signal-card" onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'">
      <div class="signal-card-header">
        <div><div class="rank">#${rank}</div><div class="ticker">${r.ticker}</div>
             <div class="company">${stock.name || ""}</div></div>
        <div class="score-box">${statusPillHtml("UNAVAILABLE")}</div>
      </div>
      <div class="footer-note" style="margin-top:10px; padding-top:0; border-top:none;">${r.reason || "No data for this stock right now."}</div>
    </div>`;
  }

  const levels = r.levels || {};
  const rr = r.risk_reward || {};
  const changes = (r.changes || {}).changes || [];
  const sells = (r.sell || {}).fired || [];

  return `<div class="signal-card" onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'">
    <div class="signal-card-header">
      <div><div class="rank">#${rank}</div><div class="ticker">${r.ticker}</div>
           <div class="company">${stock.name || ""}</div></div>
      <div class="score-box">
        <div class="score-value ${ACTION_CLASS[r.action] || ""}" style="font-size:15px;">${r.action}</div>
      </div>
    </div>

    <div class="thesis-line" style="margin-top:6px;">${r.reason || ""}</div>

    <div class="levels-grid" style="margin-top:8px;">
      ${scoreBlock("Hold Quality", r.hold_quality, r.hold_band, (r.hold || {}).unknown, (r.hold || {}).weight_available)}
      ${scoreBlock("Entry Quality", r.entry_quality, r.entry_band, (r.entry || {}).unknown, (r.entry || {}).weight_available)}
    </div>

    <div style="margin-top:8px;">${gateList(r.gatekeepers)}</div>

    ${sells.length ? `<div class="warn-banner" style="margin-top:8px;">
        SELL TRIGGER — ${sells.map((s) => `${s.trigger}: ${s.detail}`).join("; ")}</div>` : ""}

    ${(r.earnings || {}).status === "BLACKOUT" ? `<div class="warn-banner" style="margin-top:8px;">
        EARNINGS BLACKOUT — ${r.earnings.detail}</div>` : ""}

    ${changes.length ? `<div style="margin-top:8px;">${changes.map((c) =>
        `<div style="font-size:11.5px;" class="${c.severity === "HIGH" ? "num-neg" : "text-dim"}">
           ${c.severity === "HIGH" ? "!" : "·"} ${c.change} — ${c.detail}</div>`).join("")}</div>`
      : `<div style="font-size:11px;margin-top:8px;" class="text-dim">${(r.changes || {}).first_reading
          ? "First reading — changes appear from the next refresh onward."
          : "No material change since the last reading."}</div>`}

    <div class="levels-grid" style="margin-top:8px;">
      ${levelBox("Price", (r.state || {}).price)}
      ${levelBox("Buy Zone Low", levels.buy_zone_low)}
      ${levelBox("Buy Zone High", levels.buy_zone_high)}
      ${levelBox("Primary Target", levels.primary_target)}
    </div>

    <div class="footer-note" style="margin-top:8px;">
      Room above vs below: ${rr.ratio === null || rr.ratio === undefined ? "not measurable" : fmtNum(rr.ratio, 2) + " : 1"}
      <span class="text-dim">— ${rr.note || ""}</span><br>
      <span class="text-dim">${(r.notes || {}).volatility || ""}</span><br>
      <span class="text-dim">${(r.notes || {}).financial_quality || ""}</span>
    </div>

    <details style="margin-top:8px;">
      <summary style="font-size:11.5px;cursor:pointer;">Component breakdown</summary>
      <div style="margin-top:6px;"><strong style="font-size:11px;">HOLD</strong>${componentRows(r.hold || {})}</div>
      <div style="margin-top:6px;"><strong style="font-size:11px;">ENTRY</strong>${componentRows(r.entry || {})}</div>
    </details>
  </div>`;
}

function renderChanges(results) {
  const box = document.getElementById("v2-changes");
  const withChanges = results.filter((r) => ((r.changes || {}).changes || []).length);
  if (!withChanges.length) {
    const anyFirst = results.some((r) => (r.changes || {}).first_reading);
    box.innerHTML = `<div class="card card-pad text-dim">${anyFirst
      ? "No previous reading stored yet. Changes are reported from the next refresh onward — this is the first snapshot."
      : "Nothing moved materially since the last reading."}</div>`;
    return;
  }
  box.innerHTML = `<table class="data-table"><thead><tr>
      <th>Stock</th><th>What changed</th><th>Detail</th><th>Severity</th>
    </tr></thead><tbody>` +
    withChanges.flatMap((r) => (r.changes.changes || []).map((c) => `<tr>
      <td><span class="ticker-badge">${r.ticker}</span></td>
      <td style="font-size:11.5px;">${c.change}</td>
      <td style="font-size:11.5px;" class="text-dim">${c.detail}</td>
      <td class="${c.severity === "HIGH" ? "num-neg" : "text-dim"}" style="font-size:11.5px;">${c.severity}</td>
    </tr>`)).join("") + `</tbody></table>`;
}

function renderSells(results) {
  const box = document.getElementById("v2-sells");
  const firing = results.filter((r) => (r.sell || {}).any);
  if (!firing.length) {
    box.innerHTML = `<div class="card card-pad text-dim">No sell trigger is firing on any of them.</div>`;
    return;
  }
  box.innerHTML = firing.map((r) => `<div class="warn-banner">
    <strong>${r.ticker}</strong> — ${r.sell.fired.map((s) => `${s.trigger}: ${s.detail}`).join("; ")}
  </div>`).join("");
}

function renderSummary(summary) {
  const box = document.getElementById("v2-summary");
  const t = (label, value, sub, cls) => `<div class="stat-tile">
    <div class="st-label">${label}</div><div class="st-value ${cls || ""}">${value}</div>
    ${sub ? `<div class="st-sub">${sub}</div>` : ""}</div>`;
  box.innerHTML = [
    t("Buy", summary.buy ?? 0, "passed all three gates", "num-pos"),
    t("Good stock, poor entry", summary.good_stock_poor_entry ?? 0, "worth owning, not today"),
    t("Watch", summary.watch ?? 0, "blocked by a gate"),
    t("Avoid", summary.avoid ?? 0, null, "num-neg"),
    t("Material changes", summary.material_changes ?? 0, "since the last reading",
      (summary.material_changes ? "num-neg" : "")),
    t("Sell triggers firing", summary.sell_triggers ?? 0, null, (summary.sell_triggers ? "num-neg" : "")),
  ].join("");
}

function renderFreshness(data) {
  const box = document.getElementById("v2-freshness");
  if (!box) return;
  const age = data.age_minutes;
  const ageText = age === null || age === undefined ? "never computed"
    : age < 90 ? `computed ${Math.round(age)} minute(s) ago`
    : `computed ${(age / 60).toFixed(1)} hour(s) ago`;

  // The age shown is the OLDEST row in the table, not the newest. If 49 refreshed a minute ago
  // and one failed three days back, "1 minute ago" would be a lie about the table as a whole.
  const bits = [`Strategy ${data.strategy_version || "v2.0"} — ${ageText} (oldest of the 50).`];
  if (data.refreshing) {
    bits.push(`<strong>Recomputing now${data.progress ? ` — ${data.progress}` : ""}.</strong>`);
  } else if (data.stale) {
    bits.push("This reading is stale; a recompute has been started.");
  }
  if (data.note) bits.push(data.note);
  if (data.refresh_error) bits.push(`<span class="num-neg">${data.refresh_error}</span>`);
  box.innerHTML = bits.join("<br>");
}

async function refreshSignals() {
  const grid = document.getElementById("signals-grid");
  const errBox = document.getElementById("signals-error");
  if (!grid) return;
  try {
    const data = await apiGet("/api/signals/v2");
    errBox.innerHTML = data.error ? `<div class="warn-banner">SIGNALS UNAVAILABLE — ${data.error}</div>` : "";
    renderFreshness(data);
    const results = data.results || [];
    if (!results.length) {
      grid.innerHTML = `<div class="card card-pad text-dim">${data.note || "No readings stored yet."}</div>`;
      renderChanges([]);
      renderSells([]);
      renderSummary(data.summary || {});
      return;
    }
    renderChanges(results);
    renderSells(results);
    renderSummary(data.summary || {});
    grid.innerHTML = results.map((r, i) => renderCard(r, i + 1)).join("");
    const refreshedEl = document.getElementById("signals-last-refreshed");
    if (refreshedEl) refreshedEl.textContent = "page loaded " + new Date().toLocaleTimeString();
    return data;
  } catch (e) {
    grid.innerHTML = "";
    errBox.innerHTML = `<div class="error-banner">SIGNALS ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

// While a recompute is in flight, poll the SMALL summary endpoint rather than the full payload.
// The full one is ~150KB; the summary is a few hundred bytes and exists so that watching a run
// costs almost nothing — the last time a page polled a heavy endpoint during a long job it
// crossed gunicorn's request limit and killed the run it was watching.
let pollTimer = null;
async function watchRefresh() {
  if (pollTimer) return;
  pollTimer = setInterval(async () => {
    try {
      const s = await apiGet("/api/signals/v2/summary");
      renderFreshness(s);
      if (!s.refreshing) {
        clearInterval(pollTimer);
        pollTimer = null;
        await refreshSignals();
      }
    } catch (e) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }, 5000);
}

const refreshBtn = document.getElementById("v2-refresh-btn");
if (refreshBtn) {
  refreshBtn.addEventListener("click", async () => {
    refreshBtn.disabled = true;
    refreshBtn.textContent = "Recomputing…";
    try {
      const res = await fetch("/api/signals/v2/refresh", {
        method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" },
      });
      const out = await res.json();
      if (out.error) throw new Error(out.error);
      watchRefresh();
    } catch (e) {
      document.getElementById("signals-error").innerHTML =
        `<div class="error-banner">${e.message}</div>`;
    } finally {
      setTimeout(() => {
        refreshBtn.disabled = false;
        refreshBtn.textContent = "Recompute all 50";
      }, 3000);
    }
  });
}

// A read is one indexed SELECT, so this is cheap. It does NOT trigger a computation: the server
// starts one by itself only when the stored reading has gone stale.
(async function start() {
  const data = await refreshSignals();
  if (data && data.refreshing) watchRefresh();
})();
