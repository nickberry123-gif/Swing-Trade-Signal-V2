"""
Central configuration, loaded entirely from environment variables.

CRITICAL: API keys must never be hard-coded and must never be sent to the frontend.
This module is the ONLY place that reads ALPACA_API_KEY / ALPACA_SECRET_KEY from the
environment. Every other module receives what it needs via function calls, not by
reading os.environ directly, so a future audit only has one place to check.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent

# Load backend/.env explicitly (not just cwd's .env) so `python app.py` works
# regardless of the directory it's launched from.
load_dotenv(BACKEND_DIR / ".env")


class Config:
    ALPACA_API_KEY: str | None = os.environ.get("ALPACA_API_KEY")
    ALPACA_SECRET_KEY: str | None = os.environ.get("ALPACA_SECRET_KEY")
    ALPACA_ENV: str = os.environ.get("ALPACA_ENV", "paper").lower()

    # When DATABASE_URL points at Postgres the app uses it; otherwise it falls back to the
    # local SQLite file. Production needs Postgres because Render's free web-service tier has
    # no persistent disk — a SQLite file there is wiped on every deploy, which would silently
    # reset the accumulated signal history that Phase 6's analytics depend on.
    DATABASE_URL: str | None = os.environ.get("DATABASE_URL") or None

    DATABASE_PATH: str = os.environ.get("DATABASE_PATH", str(BACKEND_DIR / "swing_signals.db"))
    if not os.path.isabs(DATABASE_PATH):
        DATABASE_PATH = str(BACKEND_DIR / DATABASE_PATH)

    PORT: int = int(os.environ.get("PORT", "8000"))

    ALPACA_DATA_BASE_URL = "https://data.alpaca.markets"
    ALPACA_TRADING_BASE_URL = (
        "https://api.alpaca.markets" if ALPACA_ENV == "live" else "https://paper-api.alpaca.markets"
    )

    @classmethod
    def has_alpaca_credentials(cls) -> bool:
        return bool(cls.ALPACA_API_KEY and cls.ALPACA_SECRET_KEY)


# The tracked universe. Hard-coded on purpose: the app never discovers or adds tickers on its
# own, so what is tested is always exactly what is listed here.
#
# Expanded from 15 to 50 on 2026-08-14, at the user's request, because every analysis in this
# app had been sample-size limited — ranking 15 correlated mega-caps against each other is
# barely a cross-sectional test, and 52-week lows were too rare to judge a mean-reversion rule.
#
# SURVIVORSHIP BIAS GOT WORSE, NOT BETTER. These are today's winners, and the new names include
# some of the largest recoveries of the last three years (CVNA fell ~99% in 2022 and then rose
# roughly a hundredfold; APP, VRT, FIX and PLTR are all enormous winners). Any rule that buys
# weakness will look spectacular on this list precisely because every company that failed to
# recover is absent from it. More data has made the statistics better and the bias worse at the
# same time, and both need saying whenever a result is read.
STOCK_UNIVERSE = [
    {"ticker": "NVDA", "name": "NVIDIA Corporation", "sector": "Semiconductors", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "MU", "name": "Micron Technology, Inc.", "sector": "Semiconductors", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "AVGO", "name": "Broadcom Inc.", "sector": "Semiconductors", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "MRVL", "name": "Marvell Technology, Inc.", "sector": "Semiconductors", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "KLAC", "name": "KLA Corporation", "sector": "Semiconductors", "industry": "Semiconductor Equipment", "exchange": "NASDAQ"},
    {"ticker": "LRCX", "name": "Lam Research Corporation", "sector": "Semiconductors", "industry": "Semiconductor Equipment", "exchange": "NASDAQ"},
    {"ticker": "AMAT", "name": "Applied Materials, Inc.", "sector": "Semiconductors", "industry": "Semiconductor Equipment", "exchange": "NASDAQ"},
    {"ticker": "AMD", "name": "Advanced Micro Devices, Inc.", "sector": "Semiconductors", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "ASML", "name": "ASML Holding N.V.", "sector": "Semiconductors", "industry": "Semiconductor Equipment", "exchange": "NASDAQ"},
    {"ticker": "SNPS", "name": "Synopsys, Inc.", "sector": "Semiconductors", "industry": "EDA Software", "exchange": "NASDAQ"},
    {"ticker": "PLTR", "name": "Palantir Technologies Inc.", "sector": "Technology", "industry": "Software", "exchange": "NASDAQ"},
    {"ticker": "APP", "name": "AppLovin Corporation", "sector": "Technology", "industry": "Software", "exchange": "NASDAQ"},
    {"ticker": "ANET", "name": "Arista Networks, Inc.", "sector": "Technology", "industry": "Networking", "exchange": "NYSE"},
    {"ticker": "CRWD", "name": "CrowdStrike Holdings, Inc.", "sector": "Technology", "industry": "Cybersecurity", "exchange": "NASDAQ"},
    {"ticker": "NET", "name": "Cloudflare, Inc.", "sector": "Technology", "industry": "Cloud Infrastructure", "exchange": "NYSE"},
    {"ticker": "NOW", "name": "ServiceNow, Inc.", "sector": "Technology", "industry": "Software", "exchange": "NYSE"},
    {"ticker": "MSFT", "name": "Microsoft Corporation", "sector": "Technology", "industry": "Software", "exchange": "NASDAQ"},
    {"ticker": "GOOGL", "name": "Alphabet Inc.", "sector": "Technology", "industry": "Internet", "exchange": "NASDAQ"},
    {"ticker": "AMZN", "name": "Amazon.com, Inc.", "sector": "Technology", "industry": "Internet Retail", "exchange": "NASDAQ"},
    {"ticker": "AAPL", "name": "Apple Inc.", "sector": "Technology", "industry": "Consumer Electronics", "exchange": "NASDAQ"},
    {"ticker": "CVNA", "name": "Carvana Co.", "sector": "Consumer", "industry": "Internet Retail", "exchange": "NYSE"},
    {"ticker": "CELH", "name": "Celsius Holdings, Inc.", "sector": "Consumer", "industry": "Beverages", "exchange": "NASDAQ"},
    {"ticker": "DECK", "name": "Deckers Outdoor Corporation", "sector": "Consumer", "industry": "Footwear", "exchange": "NYSE"},
    {"ticker": "MELI", "name": "MercadoLibre, Inc.", "sector": "Consumer", "industry": "Internet Retail", "exchange": "NASDAQ"},
    {"ticker": "BKNG", "name": "Booking Holdings Inc.", "sector": "Consumer", "industry": "Travel", "exchange": "NASDAQ"},
    {"ticker": "UBER", "name": "Uber Technologies, Inc.", "sector": "Consumer", "industry": "Ride Sharing", "exchange": "NYSE"},
    {"ticker": "CMG", "name": "Chipotle Mexican Grill, Inc.", "sector": "Consumer", "industry": "Restaurants", "exchange": "NYSE"},
    {"ticker": "TSLA", "name": "Tesla, Inc.", "sector": "Consumer", "industry": "Automobiles", "exchange": "NASDAQ"},
    {"ticker": "COST", "name": "Costco Wholesale Corporation", "sector": "Consumer", "industry": "Discount Stores", "exchange": "NASDAQ"},
    {"ticker": "NFLX", "name": "Netflix, Inc.", "sector": "Consumer", "industry": "Streaming", "exchange": "NASDAQ"},
    {"ticker": "FIX", "name": "Comfort Systems USA, Inc.", "sector": "Industrials", "industry": "Building Services", "exchange": "NYSE"},
    {"ticker": "VRT", "name": "Vertiv Holdings Co", "sector": "Industrials", "industry": "Electrical Equipment", "exchange": "NYSE"},
    {"ticker": "PWR", "name": "Quanta Services, Inc.", "sector": "Industrials", "industry": "Engineering & Construction", "exchange": "NYSE"},
    {"ticker": "HWM", "name": "Howmet Aerospace Inc.", "sector": "Industrials", "industry": "Aerospace", "exchange": "NYSE"},
    {"ticker": "URI", "name": "United Rentals, Inc.", "sector": "Industrials", "industry": "Rental & Leasing", "exchange": "NYSE"},
    {"ticker": "CAT", "name": "Caterpillar Inc.", "sector": "Industrials", "industry": "Machinery", "exchange": "NYSE"},
    {"ticker": "GE", "name": "GE Aerospace", "sector": "Industrials", "industry": "Aerospace", "exchange": "NYSE"},
    {"ticker": "TT", "name": "Trane Technologies plc", "sector": "Industrials", "industry": "Building Products", "exchange": "NYSE"},
    {"ticker": "ETN", "name": "Eaton Corporation plc", "sector": "Industrials", "industry": "Electrical Equipment", "exchange": "NYSE"},
    {"ticker": "CTAS", "name": "Cintas Corporation", "sector": "Industrials", "industry": "Business Services", "exchange": "NASDAQ"},
    {"ticker": "LLY", "name": "Eli Lilly and Company", "sector": "Healthcare", "industry": "Pharmaceuticals", "exchange": "NYSE"},
    {"ticker": "ISRG", "name": "Intuitive Surgical, Inc.", "sector": "Healthcare", "industry": "Medical Devices", "exchange": "NASDAQ"},
    {"ticker": "VRTX", "name": "Vertex Pharmaceuticals Inc.", "sector": "Healthcare", "industry": "Biotechnology", "exchange": "NASDAQ"},
    {"ticker": "REGN", "name": "Regeneron Pharmaceuticals, Inc.", "sector": "Healthcare", "industry": "Biotechnology", "exchange": "NASDAQ"},
    {"ticker": "NVO", "name": "Novo Nordisk A/S", "sector": "Healthcare", "industry": "Pharmaceuticals", "exchange": "NYSE"},
    {"ticker": "HCA", "name": "HCA Healthcare, Inc.", "sector": "Healthcare", "industry": "Healthcare Facilities", "exchange": "NYSE"},
    {"ticker": "TMO", "name": "Thermo Fisher Scientific Inc.", "sector": "Healthcare", "industry": "Life Sciences Tools", "exchange": "NYSE"},
    {"ticker": "SYK", "name": "Stryker Corporation", "sector": "Healthcare", "industry": "Medical Devices", "exchange": "NYSE"},
    {"ticker": "ABBV", "name": "AbbVie Inc.", "sector": "Healthcare", "industry": "Pharmaceuticals", "exchange": "NYSE"},
    {"ticker": "DHR", "name": "Danaher Corporation", "sector": "Healthcare", "industry": "Life Sciences Tools", "exchange": "NYSE"},
]

# Alpaca's REST symbology and TradingView's widget symbology diverge for dual-class share
# tickers (Alpaca: "BRK.B" with a dot; TradingView: "BRK.B" with a dot too, but some vendors
# use "BRK-B" with a hyphen) — kept as an explicit map here rather than a string transform so
# any future divergence is a one-line fix, not a hunt through the codebase.
TRADINGVIEW_SYMBOL_OVERRIDES = {
    "BRK.B": "BRK.B",
}

# Market-regime / relative-strength reference symbols. NOTE: 'VIX' itself is a CBOE index,
# not an equity/ETF, and Alpaca's market data API (like all equities-only feeds) does not
# carry it — confirmed against Alpaca's own community docs, not assumed. VIXY (ProShares VIX
# Short-Term Futures ETF) is a real, Alpaca-tradable proxy used instead, and is always labeled
# as a proxy, never presented as the actual index value.
BROAD_MARKET_SYMBOLS = ["SPY", "QQQ"]
VIX_TRUE_TICKER = "VIX"          # kept for display/labeling only — never fetched, always UNAVAILABLE
VIX_PROXY_TICKER = "VIXY"        # what actually gets fetched from Alpaca
SECTOR_ETF_SYMBOLS = ["SMH", "SOXX", "XLK", "XLF", "XLV", "XLY", "XLP", "XLI"]
REGIME_SYMBOLS = BROAD_MARKET_SYMBOLS + [VIX_PROXY_TICKER] + SECTOR_ETF_SYMBOLS

BENCHMARK_SYMBOLS = (
    [{"ticker": t, "name": n, "category": "BROAD_MARKET"} for t, n in [
        ("SPY", "SPDR S&P 500 ETF Trust"), ("QQQ", "Invesco QQQ Trust (Nasdaq-100)"),
    ]]
    + [{"ticker": VIX_PROXY_TICKER, "name": "ProShares VIX Short-Term Futures ETF (VIX proxy)", "category": "VOLATILITY_PROXY"}]
    + [{"ticker": t, "name": n, "category": "SECTOR"} for t, n in [
        ("SMH", "VanEck Semiconductor ETF"), ("SOXX", "iShares Semiconductor ETF"),
        ("XLK", "Technology Select Sector SPDR"), ("XLF", "Financial Select Sector SPDR"),
        ("XLV", "Health Care Select Sector SPDR"), ("XLY", "Consumer Discretionary Select Sector SPDR"),
        ("XLP", "Consumer Staples Select Sector SPDR"),
        ("XLI", "Industrial Select Sector SPDR"),
    ]]
)

# ETFs watched alongside the 50 companies on the Yearly page.
#
# THESE ARE PROXIES, AND THE UI SAYS SO ON EVERY ROW. The funds actually of interest — VHYL,
# CNX1 and SMGB — are London-listed UCITS ETFs. Alpaca covers US-listed securities only, so it
# cannot price any of them, and inventing prices for them would break the project's first rule.
# What it CAN price is the US-listed fund tracking the same thing, which is what each row shows.
#
# The match quality is not the same in every case, so `match` records it honestly:
#   EXACT     — same index or same fund family strategy, different listing/domicile.
#               Prices, currency and fees differ; the underlying exposure does not.
#   APPROXIMATE — closest available, materially different coverage. Say so loudly.
#
# S&P 500 is an index rather than a tradeable instrument, so SPY is the tracker, exactly as
# VIXY stands in for the VIX above.
ETF_UNIVERSE = [
    {"ticker": "S&P500", "name": "S&P 500", "listing": "Index",
     "proxy": "SPY", "proxy_name": "SPDR S&P 500 ETF Trust", "match": "EXACT",
     "note": "The S&P 500 is an index, not something you can buy. SPY is the oldest and "
             "largest fund tracking it."},
    {"ticker": "CNX1", "name": "iShares NASDAQ 100 UCITS ETF (Acc)", "listing": "London",
     "proxy": "QQQ", "proxy_name": "Invesco QQQ Trust", "match": "EXACT",
     "note": "Both track the Nasdaq-100. CNX1 accumulates dividends and trades in USD on the "
             "LSE; QQQ distributes and trades in the US. Same index, so the yearly shape "
             "matches, but total return differs slightly through fees and withholding tax."},
    {"ticker": "SMGB", "name": "VanEck Semiconductor UCITS ETF", "listing": "London",
     "proxy": "SMH", "proxy_name": "VanEck Semiconductor ETF", "match": "EXACT",
     "note": "The same VanEck semiconductor strategy — SMH is the US-listed original and SMGB "
             "the UCITS version for European investors."},
    {"ticker": "VHYL", "name": "Vanguard FTSE All-World High Dividend Yield UCITS ETF",
     "listing": "London",
     "proxy": "VYM", "proxy_name": "Vanguard High Dividend Yield ETF (US only)",
     "match": "APPROXIMATE",
     "note": "NOT equivalent. VHYL holds high-dividend companies worldwide; VYM holds the US "
             "ones only, so roughly half the fund is missing and the currency exposure is "
             "different. Treat this row as an indication of direction, not a substitute. "
             "VYMI is the ex-US half if you want to look at both."},
]

ETF_PROXY_SYMBOLS = [e["proxy"] for e in ETF_UNIVERSE]

# Each of the 50 tracked stocks' most relevant sector ETF, drawn only from the ETF list the
# project spec provided (SMH/SOXX/XLK/XLF/XLV/XLY/XLP — there is no XLC "communication
# services" ETF in that list, so META and GOOGL are mapped to XLK as the closest available
# proxy; this simplification is surfaced in the UI, not hidden).
SECTOR_ETF_MAP = {
    "NVDA": "SMH",
    "MU": "SMH",
    "AVGO": "SMH",
    "MRVL": "SMH",
    "KLAC": "SMH",
    "LRCX": "SMH",
    "AMAT": "SMH",
    "AMD": "SMH",
    "ASML": "SMH",
    "SNPS": "SMH",
    "PLTR": "XLK",
    "APP": "XLK",
    "ANET": "XLK",
    "CRWD": "XLK",
    "NET": "XLK",
    "NOW": "XLK",
    "MSFT": "XLK",
    "GOOGL": "XLK",
    "AMZN": "XLK",
    "AAPL": "XLK",
    "CVNA": "XLY",
    "CELH": "XLP",
    "DECK": "XLY",
    "MELI": "XLY",
    "BKNG": "XLY",
    "UBER": "XLY",
    "CMG": "XLY",
    "TSLA": "XLY",
    "COST": "XLP",
    "NFLX": "XLY",
    "FIX": "XLI",
    "VRT": "XLI",
    "PWR": "XLI",
    "HWM": "XLI",
    "URI": "XLI",
    "CAT": "XLI",
    "GE": "XLI",
    "TT": "XLI",
    "ETN": "XLI",
    "CTAS": "XLI",
    "LLY": "XLV",
    "ISRG": "XLV",
    "VRTX": "XLV",
    "REGN": "XLV",
    "NVO": "XLV",
    "HCA": "XLV",
    "TMO": "XLV",
    "SYK": "XLV",
    "ABBV": "XLV",
    "DHR": "XLV",
}

# Canonical timeframe strings used throughout the app (must match TIMEFRAME_MAP in
# providers/alpaca_provider.py). Daily is primary for Phase 2 indicators/regime; the others
# are wired through the same code path for later use (intraday entry refinement, Phase 3+).
TIMEFRAMES = ["1Day", "4Hour", "1Hour", "30Min", "15Min"]
PRIMARY_TIMEFRAME = "1Day"
