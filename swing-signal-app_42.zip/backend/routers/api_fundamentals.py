from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services.fundamentals_service import get_earnings_info, get_fundamentals
from services.news_service import get_news_for_ticker, refresh_news
from services.signals_service import TICKERS

bp = Blueprint("api_fundamentals", __name__, url_prefix="/api")


@bp.get("/fundamentals/<ticker>")
def stock_fundamentals(ticker):
    """Audited financial-statement data from SEC EDGAR plus the derived long-term quality score.
    Requires no API key (EDGAR is public) and is independent of the Alpaca credentials."""
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404

    db = get_db()
    force = request.args.get("refresh") == "1"
    data = get_fundamentals(db, ticker, force_refresh=force)
    data["earnings"] = get_earnings_info(db, ticker, force_refresh=force)
    return jsonify(data)


@bp.get("/news/<ticker>")
def stock_news(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({"ticker": ticker, "data_status": "UNAVAILABLE",
                        "error": "Alpaca API credentials not configured", "items": []}), 200

    db = get_db()
    result = refresh_news(db, [ticker], force=request.args.get("refresh") == "1")
    items = get_news_for_ticker(db, ticker, limit=20)
    return jsonify({
        "ticker": ticker,
        "data_status": "UNAVAILABLE" if (result.get("error") and not items) else "OK",
        "error": result.get("error"),
        "sentiment_method": "keyword-based classifier (not NLP/AI sentiment analysis) — see "
                            "providers/news_provider.py for the exact keyword lists",
        "items": items,
    })
