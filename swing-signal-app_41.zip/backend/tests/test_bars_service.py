"""
Unit tests for services/bars_service.py: caching, freshness TTL, and graceful fallback to
cache on a provider failure. Uses a real temporary SQLite DB (not mocked — sqlite3 is stdlib
and fast) with the provider itself mocked out.
"""
import sqlite3
import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import database
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from providers.base import Bar, ProviderError, DataStatus
from services import bars_service

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    conn.commit()
    return conn


class CountingDB:
    """Wraps a connection and counts SELECTs.

    Needed because "did this read the database?" cannot be answered from a return value — a
    memoised read and a database read produce identical frames. Counting queries is the only way
    to assert that the transfer fix actually stops transfer.
    """

    def __init__(self, conn):
        self._conn = conn
        self.query_count = 0

    def execute(self, sql, params=None):
        if sql.strip().upper().startswith("SELECT"):
            self.query_count += 1
        return self._conn.execute(sql, params) if params is not None else self._conn.execute(sql)

    def __getattr__(self, name):
        return getattr(self._conn, name)


def make_provider_bars(n=5, start_price=100.0, span_days=None):
    """Bars ending today. `span_days` spreads them across a wider window.

    Defaults to spanning the full configured lookback, because bars_service now refetches any
    cached series that covers less history than LOOKBACK_DAYS asks for (see
    `_cache_covers_window`). A fixture bunched into the last few days would otherwise be treated
    as inadequate coverage and trigger a refetch, which is correct behaviour but not what most
    of these tests are exercising.
    """
    if span_days is None:
        span_days = bars_service.LOOKBACK_DAYS["1Day"]
    now = datetime.now(timezone.utc)
    step = max(1.0, span_days / max(n - 1, 1))
    bars = []
    for i in range(n):
        ts = now - timedelta(days=step * (n - 1 - i))
        px = start_price + i
        bars.append(Bar(ts=ts, open=px, high=px + 1, low=px - 1, close=px, volume=1000.0))
    return bars


class TestBarsServiceFetchesWhenEmpty(unittest.TestCase):

    def setUp(self):
        # The bar memo is module-level and survives between tests. Without this, one
        # test's cached frame answers the next test's question and the suite quietly
        # stops testing the database path at all.
        bars_service.clear_bar_memo()
    @patch("services.bars_service.get_provider")
    def test_empty_cache_triggers_fetch_and_stores(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(10)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")

        self.assertEqual(len(df), 10)
        self.assertEqual(meta["source"], "alpaca")
        self.assertTrue(meta["fresh"])
        self.assertFalse(meta["stale_fallback"])
        mock_provider.get_bars.assert_called_once()

        # Bars actually landed in the DB
        count = db.execute("SELECT COUNT(*) FROM market_bars WHERE ticker='AAPL'").fetchone()[0]
        self.assertEqual(count, 10)


class TestBarsServiceUsesFreshCache(unittest.TestCase):

    def setUp(self):
        # The bar memo is module-level and survives between tests. Without this, one
        # test's cached frame answers the next test's question and the suite quietly
        # stops testing the database path at all.
        bars_service.clear_bar_memo()

    @patch("services.bars_service.get_provider")
    def test_fresh_cache_skips_provider_call(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(10)

        # First call populates cache
        bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.reset_mock()
        bars_service.clear_bar_memo()   # exercise the DATABASE cache path, not the memo

        # Second call, immediately after, should use cache (well within TTL)
        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertEqual(meta["source"], "cache")
        self.assertFalse(meta["fresh"])
        mock_provider.get_bars.assert_not_called()
        self.assertEqual(len(df), 10)

    @patch("services.bars_service.get_provider")
    def test_force_refresh_bypasses_fresh_cache(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(10)
        bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.reset_mock()
        mock_provider.get_bars.return_value = make_provider_bars(11)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day", force_refresh=True)
        mock_provider.get_bars.assert_called_once()
        self.assertEqual(meta["source"], "alpaca")


class TestBarsServiceStaleCache(unittest.TestCase):

    def setUp(self):
        # The bar memo is module-level and survives between tests. Without this, one
        # test's cached frame answers the next test's question and the suite quietly
        # stops testing the database path at all.
        bars_service.clear_bar_memo()
    @patch("services.bars_service.get_provider")
    def test_stale_cache_triggers_refetch(self, mock_get_provider):
        db = make_db()
        # Manually insert a bar with an old fetched_at timestamp (outside TTL)
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
        db.execute(
            "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume, "
            "source, fetched_at) VALUES ('AAPL','1Day',?,100,101,99,100,1000,"
            f"'{bars_service.BAR_SOURCE_TAG}',?)",
            (old_ts, old_ts),
        )
        db.commit()

        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(20)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.assert_called_once()
        self.assertEqual(meta["source"], "alpaca")


class TestBarsServiceProviderFailure(unittest.TestCase):

    def setUp(self):
        # The bar memo is module-level and survives between tests. Without this, one
        # test's cached frame answers the next test's question and the suite quietly
        # stops testing the database path at all.
        bars_service.clear_bar_memo()
    @patch("services.bars_service.get_provider")
    def test_failure_with_no_cache_returns_empty_honestly(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.side_effect = ProviderError("boom", DataStatus.UNAVAILABLE)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertTrue(df.empty)
        self.assertIsNotNone(meta["error"])
        self.assertFalse(meta["stale_fallback"])

    @patch("services.bars_service.get_provider")
    def test_failure_with_stale_cache_falls_back_honestly(self, mock_get_provider):
        db = make_db()
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
        db.execute(
            "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume, "
            "source, fetched_at) VALUES ('AAPL','1Day',?,100,101,99,100,1000,"
            f"'{bars_service.BAR_SOURCE_TAG}',?)",
            (old_ts, old_ts),
        )
        db.commit()

        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.side_effect = ProviderError("boom", DataStatus.UNAVAILABLE)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertEqual(len(df), 1)
        self.assertTrue(meta["stale_fallback"])
        self.assertIsNotNone(meta["error"])



class TestCacheCoverageWindow(unittest.TestCase):
    """Freshness and coverage are different questions.

    When LOOKBACK_DAYS was extended from ~1.5 years to 5 years, every already-cached ticker was
    still inside its 6-hour freshness TTL, so a TTL-only check would have kept serving the short
    series and the longer window would silently never arrive.
    """

    def setUp(self):
        # The bar memo is module-level and survives between tests. Without this, one
        # test's cached frame answers the next test's question and the suite quietly
        # stops testing the database path at all.
        bars_service.clear_bar_memo()

    @patch("services.bars_service.get_provider")
    def test_short_but_fresh_cache_is_refetched(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        # Only ~30 days of history, far short of the 5-year lookback.
        mock_provider.get_bars.return_value = make_provider_bars(10, span_days=30)

        bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.reset_mock()

        _df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.assert_called_once()   # refetched despite being fresh
        self.assertEqual(meta["source"], "alpaca")

    @patch("services.bars_service.get_provider")
    def test_full_length_fresh_cache_is_reused(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(300)  # spans the full lookback

        bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.reset_mock()
        # Clear the in-memory memo so this exercises the DATABASE cache path, which is what this
        # test is about. The memo has its own tests below.
        bars_service.clear_bar_memo()

        _df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.assert_not_called()
        self.assertEqual(meta["source"], "cache")

    def test_coverage_helper_boundaries(self):
        import pandas as pd
        now = datetime.now(timezone.utc)

        def frame(span_days):
            return pd.DataFrame({"ts": [(now - timedelta(days=span_days)).isoformat(),
                                        now.isoformat()]})

        self.assertTrue(bars_service._cache_covers_window(frame(1800), 1825))
        self.assertFalse(bars_service._cache_covers_window(frame(400), 1825))
        self.assertFalse(bars_service._cache_covers_window(pd.DataFrame(), 1825))

    def test_backtest_lookback_is_five_years(self):
        # Deep history lives on its own constant, NOT on the live default — see
        # TestLiveVsBacktestLookback for why conflating them took the site down.
        self.assertGreaterEqual(bars_service.BACKTEST_LOOKBACK_DAYS, 1800)



class TestLiveVsBacktestLookback(unittest.TestCase):
    """Regression tests for an outage.

    Raising the shared LOOKBACK_DAYS to 5 years for the backtester's benefit made every LIVE
    endpoint refetch 5 years for 24 tickers inside a 30-second request budget. Workers hit
    WORKER TIMEOUT, were SIGKILLed, restarted, and retried — a crash loop that took the entire
    site down. Deep history must stay opt-in, requested only by the background backtester.
    """

    def setUp(self):
        # The bar memo is module-level and survives between tests. Without this, one
        # test's cached frame answers the next test's question and the suite quietly
        # stops testing the database path at all.
        bars_service.clear_bar_memo()

    def test_live_lookback_stays_small_enough_for_a_web_request(self):
        self.assertLessEqual(
            bars_service.LOOKBACK_DAYS["1Day"], 800,
            "the live lookback must stay modest — request-path code fetches this synchronously")

    def test_backtest_lookback_is_deep(self):
        self.assertGreaterEqual(bars_service.BACKTEST_LOOKBACK_DAYS, 1800)

    def test_backtest_lookback_is_not_the_live_default(self):
        self.assertNotEqual(bars_service.LOOKBACK_DAYS["1Day"],
                            bars_service.BACKTEST_LOOKBACK_DAYS,
                            "deep history must never become the default for live endpoints")

    @patch("services.bars_service.get_provider")
    def test_explicit_lookback_requests_the_deeper_window(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(50)

        bars_service.get_bars_df(db, "AAPL", "1Day",
                                 lookback_days=bars_service.BACKTEST_LOOKBACK_DAYS)

        _args, kwargs = mock_provider.get_bars.call_args
        start = kwargs.get("start") or _args[2]
        end = kwargs.get("end") or _args[3]
        self.assertGreaterEqual((end - start).days, 1800)

    @patch("services.bars_service.get_provider")
    def test_default_call_requests_only_the_live_window(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(50)

        bars_service.get_bars_df(db, "AAPL", "1Day")

        _args, kwargs = mock_provider.get_bars.call_args
        start = kwargs.get("start") or _args[2]
        end = kwargs.get("end") or _args[3]
        self.assertLessEqual((end - start).days, 800)

    @patch("services.bars_service.get_provider")
    def test_deep_cache_satisfies_a_live_request_without_refetching(self, mock_get_provider):
        """Once the backtester has pulled 5 years, live calls must reuse it, not shrink it."""
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(
            300, span_days=bars_service.BACKTEST_LOOKBACK_DAYS)

        bars_service.get_bars_df(db, "AAPL", "1Day",
                                 lookback_days=bars_service.BACKTEST_LOOKBACK_DAYS)
        mock_provider.get_bars.reset_mock()

        _df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.assert_not_called()
        self.assertEqual(meta["source"], "cache")


class TestGunicornConfig(unittest.TestCase):
    """The 30-second default timeout SIGKILLed workers mid-request and crash-looped the site."""

    def _config(self):
        cfg = {}
        path = Path(__file__).resolve().parent.parent / "gunicorn.conf.py"
        exec(compile(path.read_text(), str(path), "exec"), cfg)
        return cfg

    def test_timeout_is_generous(self):
        self.assertGreaterEqual(self._config()["timeout"], 120)

    def test_threaded_worker_so_background_work_cannot_starve_requests(self):
        cfg = self._config()
        self.assertEqual(cfg["worker_class"], "gthread")
        self.assertGreaterEqual(cfg["threads"], 2)

    def test_single_worker_to_protect_free_tier_memory(self):
        self.assertEqual(self._config()["workers"], 1)


class TestSplitAdjustment(unittest.TestCase):
    """Regression tests for the unadjusted-price bug.

    Alpaca was being asked for `adjustment=raw`, which reports the price actually printed on the
    day. NVDA's 10-for-1 split therefore appeared in production as a close of $1208.42 on
    2024-06-07 followed by $121.93 on 2024-06-10, and the backtester booked it as an 89.9% loss.
    AVGO, AMZN, GOOGL and TSLA all split inside the same 5-year window.
    """

    def setUp(self):
        # The bar memo is module-level and survives between tests. Without this, one
        # test's cached frame answers the next test's question and the suite quietly
        # stops testing the database path at all.
        bars_service.clear_bar_memo()

    def _insert_raw_bar(self, db, ticker="AAPL", source="alpaca"):
        ts = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        db.execute(
            "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume, "
            "source, fetched_at) VALUES (?, '1Day', ?, 1208, 1210, 1200, 1208.42, 1000, ?, ?)",
            (ticker, ts, source, ts),
        )
        db.commit()

    def test_provider_requests_adjusted_bars(self):
        from providers import alpaca_provider
        self.assertEqual(alpaca_provider.BAR_ADJUSTMENT, "all")
        self.assertNotEqual(alpaca_provider.BAR_ADJUSTMENT, "raw")

    def test_adjustment_is_sent_on_the_wire(self):
        """The constant is worthless if it never reaches the request params."""
        from providers.alpaca_provider import AlpacaProvider, BAR_ADJUSTMENT
        p = AlpacaProvider(api_key="k", secret_key="s",
                           trading_base_url="https://paper-api.alpaca.markets",
                           data_base_url="https://data.alpaca.markets")
        with patch.object(p, "_get", return_value={"bars": [], "next_page_token": None}) as m:
            p.get_bars("NVDA", "1Day", datetime.now(timezone.utc) - timedelta(days=30),
                       datetime.now(timezone.utc))
        self.assertEqual(m.call_args.kwargs["params"]["adjustment"], BAR_ADJUSTMENT)

    def test_stored_bars_are_tagged_with_the_adjustment_basis(self):
        db = make_db()
        with patch("services.bars_service.get_provider") as mock_get_provider:
            mock_get_provider.return_value.get_bars.return_value = make_provider_bars(10)
            bars_service.get_bars_df(db, "AAPL", "1Day")
        rows = db.execute(
            "SELECT DISTINCT source FROM market_bars WHERE ticker='AAPL'").fetchall()
        self.assertEqual([dict(r)["source"] for r in rows], [bars_service.BAR_SOURCE_TAG])

    def test_cache_written_under_old_basis_is_purged_and_refetched(self):
        db = make_db()
        self._insert_raw_bar(db, source="alpaca")   # the pre-fix tag
        with patch("services.bars_service.get_provider") as mock_get_provider:
            mock_get_provider.return_value.get_bars.return_value = make_provider_bars(10)
            df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertEqual(meta["cache_purged_rows"], 1)
        self.assertTrue(meta["fresh"])
        # The $1208.42 raw close must be gone, not merged in alongside adjusted bars.
        closes = db.execute("SELECT close FROM market_bars WHERE ticker='AAPL'").fetchall()
        self.assertNotIn(1208.42, [dict(r)["close"] for r in closes])

    def test_old_basis_cache_is_not_served_even_when_provider_is_down(self):
        """The stale-fallback path must not resurrect wrong prices.

        Falling back to cache is right when the cache is merely old. It is wrong when the cache
        is on the wrong adjustment basis, because those numbers are not a stale version of the
        truth — they are a different quantity. Returning nothing and reporting the error is the
        honest outcome; the project's no-fabrication rule covers this exactly.
        """
        db = make_db()
        self._insert_raw_bar(db, source="alpaca")
        with patch("services.bars_service.get_provider") as mock_get_provider:
            mock_get_provider.return_value.get_bars.side_effect = ProviderError(
                "down", DataStatus.UNAVAILABLE)
            df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertTrue(df.empty)
        self.assertFalse(meta["stale_fallback"])
        self.assertIsNotNone(meta["error"])

    def test_matching_basis_cache_is_left_alone(self):
        """Purging must be triggered by a basis mismatch only — not on every single call."""
        db = make_db()
        with patch("services.bars_service.get_provider") as mock_get_provider:
            mock_get_provider.return_value.get_bars.return_value = make_provider_bars(10)
            bars_service.get_bars_df(db, "AAPL", "1Day")
            before = db.execute("SELECT COUNT(*) AS n FROM market_bars").fetchone()
            _df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        after = db.execute("SELECT COUNT(*) AS n FROM market_bars").fetchone()
        self.assertNotIn("cache_purged_rows", meta)
        self.assertEqual(dict(before)["n"], dict(after)["n"])


if __name__ == "__main__":
    unittest.main()


class TestBarMemo(unittest.TestCase):
    """The in-process memo, and the transfer disaster it exists to prevent.

    The read query had no date filter and the dashboard polls every 60 seconds, so one open
    browser tab pulled roughly 75,000 bar rows a minute out of Postgres — about 600MB an hour
    against Neon's 5GB MONTHLY allowance. The database suspended, every page 500'd, and a deploy
    failed its health check. These tests are the guard on all four parts of that fix.
    """

    def setUp(self):
        bars_service.clear_bar_memo()

    @patch("services.bars_service.get_provider")
    def test_a_repeat_read_does_not_touch_the_database_at_all(self, mock_get_provider):
        """THE HEADLINE FIX. The dashboard polls every 60 seconds; daily bars change once a day."""
        db = CountingDB(make_db())
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(300)

        bars_service.get_bars_df(db, "AAPL", "1Day")
        queries_before = db.query_count
        _df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")

        self.assertEqual(meta["source"], "memory")
        self.assertEqual(db.query_count, queries_before,
                         "a memoised read still queried the database")

    @patch("services.bars_service.get_provider")
    def test_the_memo_returns_a_copy_so_a_caller_cannot_corrupt_it(self, mock_get_provider):
        """Callers mutate their frames — adding _year, _date columns. Handing out the cached
        object itself would let one page's bookkeeping columns appear in another's data."""
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(300)

        first, _ = bars_service.get_bars_df(db, "AAPL", "1Day")
        first["injected"] = 1
        second, _ = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertNotIn("injected", second.columns)

    @patch("services.bars_service.get_provider")
    def test_a_deep_request_is_never_served_the_shallow_frame(self, mock_get_provider):
        """The lookback is part of the key. A backtester asking for five years must not receive
        the dashboard's 560-day frame because the ticker matched — that would silently shorten
        the backtest's history and produce a plausible, wrong result."""
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(300)

        bars_service.get_bars_df(db, "AAPL", "1Day")           # live lookback
        mock_provider.get_bars.reset_mock()
        mock_provider.get_bars.return_value = make_provider_bars(
            300, span_days=bars_service.BACKTEST_LOOKBACK_DAYS)

        _df, meta = bars_service.get_bars_df(
            db, "AAPL", "1Day", lookback_days=bars_service.BACKTEST_LOOKBACK_DAYS)
        self.assertNotEqual(meta["source"], "memory")

    @patch("services.bars_service.get_provider")
    def test_an_expired_entry_is_not_served(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(300)
        bars_service.get_bars_df(db, "AAPL", "1Day")

        # Age every entry past the TTL rather than sleeping.
        aged = datetime.now(timezone.utc) - bars_service._MEMO_TTL - timedelta(minutes=1)
        for key in list(bars_service._memo):
            _stored_at, df = bars_service._memo[key]
            bars_service._memo[key] = (aged, df)

        _df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertNotEqual(meta["source"], "memory")

    @patch("services.bars_service.get_provider")
    def test_a_short_frame_is_not_memoised_so_the_retry_still_happens(self, mock_get_provider):
        """Caching an incomplete answer would suppress the very retry the coverage check exists
        to trigger, for the whole TTL."""
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(10, span_days=30)

        bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertEqual(bars_service._memo, {})

    @patch("services.bars_service.get_provider")
    def test_a_stale_fallback_is_never_memoised(self, mock_get_provider):
        """A stale fallback is a degraded answer served because the provider is down. Caching it
        would keep serving it after the provider recovered."""
        db = make_db()
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
        db.execute(
            "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume, "
            "source, fetched_at) VALUES ('AAPL','1Day',?,100,101,99,100,1000,"
            f"'{bars_service.BAR_SOURCE_TAG}',?)",
            (old_ts, old_ts),
        )
        db.commit()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.side_effect = ProviderError("boom", DataStatus.UNAVAILABLE)

        _df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertTrue(meta["stale_fallback"])
        self.assertEqual(bars_service._memo, {})

    def test_the_memo_is_bounded_so_a_long_lived_worker_cannot_leak(self):
        """An unbounded dict in a gunicorn worker that never restarts is a memory leak with a
        friendly name."""
        import pandas as pd
        frame = pd.DataFrame({"ts": ["2026-01-01"], "open": [1.0], "high": [1.0],
                              "low": [1.0], "close": [1.0], "volume": [1.0]})
        for i in range(bars_service._MEMO_MAX_ENTRIES + 50):
            bars_service._memo_put(f"T{i}", "1Day", 560, frame)
        self.assertLessEqual(len(bars_service._memo), bars_service._MEMO_MAX_ENTRIES)


class TestTransferReduction(unittest.TestCase):
    """What actually crosses the wire. These assert the SQL, because the cost was in the SQL."""

    def setUp(self):
        bars_service.clear_bar_memo()

    def test_the_read_is_limited_to_the_requested_window(self):
        """THE ORIGINAL BUG: no date filter, so every read returned every bar ever stored — about
        1,500 daily rows when an SMA200 needs 250."""
        db = make_db()
        now = datetime.now(timezone.utc)
        for days_ago in (30, 400, 2000):
            ts = (now - timedelta(days=days_ago)).isoformat()
            db.execute(
                "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, "
                "volume, source, fetched_at) VALUES ('AAPL','1Day',?,1,1,1,1,1,"
                f"'{bars_service.BAR_SOURCE_TAG}',?)", (ts, now.isoformat()))
        db.commit()

        df, _newest = bars_service._fetch_cached(db, "AAPL", "1Day", lookback_days=560)
        self.assertEqual(len(df), 2, "the 2000-day-old bar was read despite a 560-day window")

        everything, _ = bars_service._fetch_cached(db, "AAPL", "1Day")
        self.assertEqual(len(everything), 3)

    def test_unused_columns_are_not_transmitted(self):
        """`trade_count` and `vwap` were read on every query and are used by no calculation
        anywhere in the app."""
        self.assertNotIn("trade_count", bars_service._BAR_COLUMNS)
        self.assertNotIn("vwap", bars_service._BAR_COLUMNS)
        self.assertNotIn("fetched_at", bars_service._BAR_COLUMNS)

    def test_freshness_comes_from_one_scalar_not_a_column_on_every_row(self):
        """`fetched_at` used to ride along on all ~1,500 rows so the max could be taken. One
        value was needed; fifteen hundred copies were sent."""
        db = make_db()
        now = datetime.now(timezone.utc).isoformat()
        for i in range(6):   # _cache_is_fresh ignores a series shorter than 5 bars
            ts = (datetime.now(timezone.utc) - timedelta(days=i)).isoformat()
            db.execute(
                "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, "
                "volume, source, fetched_at) VALUES ('AAPL','1Day',?,1,1,1,1,1,"
                f"'{bars_service.BAR_SOURCE_TAG}',?)", (ts, now))
        db.commit()
        df, newest = bars_service._fetch_cached(db, "AAPL", "1Day")
        self.assertNotIn("fetched_at", df.columns)
        self.assertIsNotNone(newest)
        self.assertTrue(bars_service._cache_is_fresh(df, "1Day", newest))

    def test_freshness_without_a_timestamp_is_not_fresh(self):
        """An unknown fetch time must mean 'refetch', never 'assume current'."""
        import pandas as pd
        df = pd.DataFrame({"ts": ["2026-01-01"] * 10})
        self.assertFalse(bars_service._cache_is_fresh(df, "1Day", None))


class TestWriteCap(unittest.TestCase):
    """The write cap, and an honest statement of what it can and cannot protect against.

    This app has NO streaming ingestion — no WebSocket, no subscription, nothing that can push
    data at it. Every write is the direct consequence of a page asking for one ticker, and Alpaca
    is asked for at most 2000 bars. So the cap is not a defence against a firehose; it is a
    defence against a bug in THIS code, which is the thing that has actually gone wrong here
    before.
    """

    def setUp(self):
        bars_service.clear_bar_memo()

    def test_an_implausible_batch_is_refused_and_nothing_is_written(self):
        """A partial write that nothing complains about is worse than a visible failure: every
        number computed from the half-written history afterwards looks perfectly fine."""
        db = make_db()
        too_many = make_provider_bars(bars_service.MAX_ROWS_PER_STORE + 1)
        with self.assertRaises(bars_service.BarWriteCapExceeded):
            bars_service._store_bars(db, "AAPL", "1Day", too_many)
        rows = db.execute("SELECT COUNT(*) AS c FROM market_bars").fetchone()
        self.assertEqual(rows["c"], 0, "rows were written before the cap tripped")

    def test_a_normal_batch_is_written(self):
        db = make_db()
        bars_service._store_bars(db, "AAPL", "1Day", make_provider_bars(300))
        rows = db.execute("SELECT COUNT(*) AS c FROM market_bars").fetchone()
        self.assertEqual(rows["c"], 300)

    def test_writes_are_upserts_so_refetching_cannot_duplicate_history(self):
        """The property that keeps the database at ~10MB no matter how often it refreshes:
        re-fetching the same day OVERWRITES that row rather than appending a new one."""
        db = make_db()
        bars = make_provider_bars(50)
        bars_service._store_bars(db, "AAPL", "1Day", bars)
        bars_service._store_bars(db, "AAPL", "1Day", bars)
        bars_service._store_bars(db, "AAPL", "1Day", bars)
        rows = db.execute("SELECT COUNT(*) AS c FROM market_bars").fetchone()
        self.assertEqual(rows["c"], 50, "repeated fetches appended instead of overwriting")

    def test_an_upsert_updates_the_price_rather_than_keeping_the_stale_one(self):
        """Ignoring the conflict instead of updating would freeze a bar at its first value —
        which matters for today's bar, the one that changes all session."""
        db = make_db()
        first = make_provider_bars(5)
        bars_service._store_bars(db, "AAPL", "1Day", first)
        for b in first:
            b.close = 999.0
        bars_service._store_bars(db, "AAPL", "1Day", first)
        row = db.execute("SELECT close FROM market_bars LIMIT 1").fetchone()
        self.assertEqual(row["close"], 999.0)

    def test_the_app_has_no_streaming_ingestion_at_all(self):
        """A structural guard on the claim above. If a WebSocket is ever added, the write path's
        assumptions — that a batch is bounded by one REST response — stop holding, and this test
        is where that gets noticed."""
        import pathlib
        backend = pathlib.Path(__file__).resolve().parent.parent
        offenders = []
        for path in backend.rglob("*.py"):
            if "__pycache__" in str(path) or path.name.startswith("test_"):
                continue
            text = path.read_text()
            for token in ("websocket", "wss://", "websockets", "StreamConn", "stream.subscribe"):
                if token in text.lower():
                    offenders.append(f"{path.name}: {token}")
        self.assertEqual(offenders, [], f"streaming code appeared: {offenders}")
