"""
Database abstraction supporting BOTH SQLite and PostgreSQL from one codebase.

Why both: SQLite keeps local development and the whole test suite fast, dependency-free and
network-free (all 190+ tests run against in-memory SQLite). PostgreSQL is what production uses,
because Render's free web-service tier has no persistent disk — the SQLite file is wiped on
every deploy, which would silently reset the Phase 6 signal history that needs months of
accumulation to mean anything.

Selection is by the DATABASE_URL environment variable: set it to a postgres:// URL and the app
uses PostgreSQL; leave it unset and it uses the local SQLite file. Nothing else changes.

The wrapper presents the sqlite3 API the rest of the app already uses (`db.execute(sql, params)`
returning something with .fetchall()/.fetchone(), plus .commit()), and translates the handful of
genuine dialect differences rather than making every caller dialect-aware.
"""
import re
import sqlite3

# psycopg is only imported when a Postgres URL is actually configured, so local/test runs never
# need it installed.
_psycopg = None


def _load_psycopg():
    global _psycopg
    if _psycopg is None:
        import psycopg  # noqa: PLC0415 — deliberately lazy
        _psycopg = psycopg
    return _psycopg


def is_postgres_url(url: str | None) -> bool:
    return bool(url) and url.split("://", 1)[0] in ("postgres", "postgresql")


# ---------------------------------------------------------------- SQL translation

def translate_sql(sql: str) -> str:
    """Translate the SQLite-flavoured SQL used throughout this app into PostgreSQL.

    Only the constructs this codebase actually uses are handled — this is a targeted
    translation layer, not a general-purpose SQL dialect converter.
    """
    out = sql

    # Timestamps: SQLite's datetime('now') has no direct equivalent; columns here are TEXT, so
    # the Postgres value must be cast to text rather than left as a timestamptz.
    out = re.sub(r"datetime\(\s*'now'\s*\)", "(now() at time zone 'utc')::text", out,
                 flags=re.IGNORECASE)

    # Parameter style: named (:name) and positional (?) -> psycopg's %(name)s / %s.
    # The named substitution runs first and skips ::casts (e.g. `x::text`) by requiring the
    # colon not to be preceded by another colon.
    out = re.sub(r"(?<!:):([a-zA-Z_][a-zA-Z0-9_]*)", r"%(\1)s", out)
    out = re.sub(r"(?<![%\w]):", ":", out)  # no-op guard, keeps remaining colons intact

    # Positional placeholders. Avoid touching '?' inside string literals — this codebase has
    # none, but the check keeps the transformation honest if one is added later.
    if "'" not in out:
        out = out.replace("?", "%s")
    else:
        pieces = out.split("'")
        for i in range(0, len(pieces), 2):        # even indices are outside quotes
            pieces[i] = pieces[i].replace("?", "%s")
        out = "'".join(pieces)

    return out


def translate_schema(sql: str) -> str:
    """Translate the SQLite DDL in schema.sql into PostgreSQL DDL."""
    out = sql

    # PRAGMA has no Postgres equivalent (FK enforcement is always on).
    out = re.sub(r"^\s*PRAGMA[^;]*;\s*$", "", out, flags=re.MULTILINE | re.IGNORECASE)

    # Auto-incrementing primary keys.
    out = re.sub(r"INTEGER\s+PRIMARY\s+KEY\s+AUTOINCREMENT", "SERIAL PRIMARY KEY", out,
                 flags=re.IGNORECASE)

    # SQLite REAL is 8-byte; Postgres REAL is 4-byte and would silently lose precision on
    # prices and P&L, so map it to DOUBLE PRECISION.
    out = re.sub(r"\bREAL\b", "DOUBLE PRECISION", out, flags=re.IGNORECASE)

    out = re.sub(r"datetime\(\s*'now'\s*\)", "(now() at time zone 'utc')::text", out,
                 flags=re.IGNORECASE)
    return out


# ---------------------------------------------------------------- rows

class Row(dict):
    """Mimics sqlite3.Row: supports both row["column"] and row[0], and dict(row).

    Needed because this codebase uses both access styles, and psycopg's built-in row factories
    support one or the other but not both.
    """

    __slots__ = ("_values",)

    def __init__(self, columns, values):
        super().__init__(zip(columns, values))
        self._values = list(values)

    def __getitem__(self, key):
        if isinstance(key, int):
            return self._values[key]
        return super().__getitem__(key)


def _row_factory(cursor):
    columns = [d.name for d in (cursor.description or [])]

    def make(values):
        return Row(columns, values)
    return make


# ---------------------------------------------------------------- connections

class PostgresConnection:
    """Adapts a psycopg connection to the sqlite3-style interface used across this app."""

    def __init__(self, dsn: str):
        psycopg = _load_psycopg()
        # prepare_threshold=None DISABLES psycopg's automatic prepared statements.
        #
        # WHY, AND WHY IT IS WORTH THE COST. psycopg3 silently promotes a query to a server-side
        # prepared statement after it has been run a few times. Prepared statements live in a
        # database SESSION. Every hosted Postgres worth using — Neon, Supabase — puts a
        # connection pooler in front, and in TRANSACTION mode a pooler hands your next query to a
        # different backend session, where that prepared statement does not exist.
        #
        # The failure that produces is the worst kind: intermittent. It works in testing, works
        # for a while in production, then throws "prepared statement does not exist" under
        # concurrency, on whichever page happened to be unlucky.
        #
        # The cost is losing a query-plan cache. This app runs a handful of queries at low
        # frequency on a personal dashboard; that cache buys nothing measurable. Working against
        # any connection string the provider hands out is worth far more, and it means switching
        # database projects or vendors is a URL change rather than a debugging session.
        self._conn = psycopg.connect(dsn, row_factory=_row_factory, autocommit=False,
                                     prepare_threshold=None)

    def execute(self, sql: str, params=None):
        cur = self._conn.cursor()
        cur.execute(translate_sql(sql), params or None)
        return cur

    def executescript(self, sql: str):
        cur = self._conn.cursor()
        cur.execute(translate_schema(sql))
        self._conn.commit()
        return cur

    def insert_returning_id(self, sql: str, params=None) -> int:
        """Postgres has no lastrowid; RETURNING is the correct equivalent."""
        cur = self._conn.cursor()
        cur.execute(translate_sql(sql.rstrip().rstrip(";")) + " RETURNING id", params or None)
        row = cur.fetchone()
        return row[0] if row else None

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._conn.close()

    @property
    def dialect(self):
        return "postgres"


class SqliteConnection:
    """Thin passthrough so both backends expose an identical interface."""

    def __init__(self, path: str):
        self._conn = sqlite3.connect(path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")

    def execute(self, sql: str, params=None):
        return self._conn.execute(sql, params or ())

    def executescript(self, sql: str):
        return self._conn.executescript(sql)

    def insert_returning_id(self, sql: str, params=None) -> int:
        cur = self._conn.execute(sql, params or ())
        return cur.lastrowid

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._conn.close()

    @property
    def dialect(self):
        return "sqlite"


def connect(database_url: str | None, sqlite_path: str):
    if is_postgres_url(database_url):
        return PostgresConnection(database_url)
    return SqliteConnection(sqlite_path)
