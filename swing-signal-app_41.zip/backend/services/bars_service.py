"""
Bar caching/fetch layer sitting between the indicator engine and MarketDataProvider.

Responsibilities:
- Decide whether cached bars in `market_bars` are fresh enough to reuse, or need refetching
  from the provider (daily bars only need to update once a session has closed; there's no
  reason to hit Alpaca on every dashboard poll for data that only changes once a day).
- On a provider failure, fall back to whatever is cached rather than crashing the whole
  request — but always report that honestly (`from_cache_stale=True`), never pretend a
  cached bar set is fresh live data.
- Hand back a plain pandas DataFrame so services/indicators.py never has to know this table
  or the provider abstraction exist.
"""
import logging
from datetime import datetime, timedelta, timezone

import pandas as pd

log = logging.getLogger(__name__)

from providers import ProviderError
from providers.alpaca_provider import BAR_SOURCE_TAG
from services.market_service import get_provider

# How long cached bars are considered fresh before we bother refetching, per timeframe.
# Daily bars only change once a session closes, so a multi-hour TTL is entirely reasonable
# for a swing-trading app (see project spec: "signal stability", "data delay" sections —
# this is explicitly NOT a scalping system).
FRESHNESS_TTL = {
    "1Day": timedelta(hours=6),
    "4Hour": timedelta(hours=2),
    "1Hour": timedelta(hours=1),
    "30Min": timedelta(minutes=20),
    "15Min": timedelta(minutes=10),
}

# How far back to request bars, per timeframe — enough for SMA200 + slope + 52-week hi/lo
# with comfortable buffer (holidays/weekends already thin out calendar days vs trading days).
# Lookback for the LIVE endpoints (dashboard, signals, indicators). These run inside a normal
# web request, so the window must stay small enough to fetch and compute within the worker
# timeout. ~1.5 years comfortably covers SMA200 + slope, which is all live scoring needs.
#
# HISTORY: this was briefly raised to 1825 days for the backtester, which took the whole site
# down — every dashboard poll started refetching 5 years for 24 tickers inside a 30-second
# request budget, timed out, and the worker was SIGKILLed in a crash loop. Deep history is now
# requested explicitly by the backtester alone (see BACKTEST_LOOKBACK_DAYS) and must never
# become the default for request-path code.
LOOKBACK_DAYS = {
    "1Day": 560,
    "4Hour": 120,
    "1Hour": 60,
    "30Min": 30,
    "15Min": 15,
}

# Deep history, used ONLY by the backtester, which runs in a background thread with no request
# timeout. 5 years spans more than one market regime — including the 2022 drawdown, the most
# informative period for a strategy that holds through losses without a stop.
BACKTEST_LOOKBACK_DAYS = 1825

# Below this fraction of the requested window, a cached series is treated as too short and
# refetched even if it is still within its freshness TTL. Without this, extending LOOKBACK_DAYS
# would have no effect until every cached ticker's TTL happened to expire.
MIN_CACHE_COVERAGE = 0.8

MIN_BARS_FOR_FULL_INDICATORS = 210


# ---------------------------------------------------------------------------------------------
# IN-PROCESS BAR MEMO
# ---------------------------------------------------------------------------------------------
# Daily bars do not change during a trading day, but the dashboard polls for analytics every 60
# seconds and every poll walked all fifty tickers back to the database. The same rows, over the
# network, again and again, to produce the same numbers.
#
# On Neon's free plan that arithmetic is brutal: ~75,000 rows a minute, roughly 600MB an hour,
# against a 5GB MONTHLY allowance. One browser tab left open for a working day exhausted the
# month, suspended the database and took the site down.
#
# So bars are held in the worker's memory for a short TTL. This is a CACHE OF A CACHE and that is
# deliberate: `market_bars` protects Alpaca's rate limit, this protects the database's transfer
# allowance. They are different scarce resources.
#
# Bounded, because an unbounded dict in a long-lived worker is a memory leak with a friendly
# name. Fifty tickers plus benchmarks across a couple of timeframes fits comfortably.
_MEMO_MAX_ENTRIES = 200

# Deliberately shorter than FRESHNESS_TTL. This must never be the reason a genuinely stale cache
# is served: the database check still runs, just not every sixty seconds.
_MEMO_TTL = timedelta(minutes=10)

_memo: dict = {}


def _memo_key(ticker, timeframe, lookback):
    # Lookback is part of the key. A backtester asking for five years must never be handed the
    # dashboard's 560-day frame just because the ticker matches — that would silently shorten a
    # backtest's history and produce a plausible, wrong result.
    return (ticker, timeframe, int(lookback))


def _memo_get(ticker, timeframe, lookback):
    entry = _memo.get(_memo_key(ticker, timeframe, lookback))
    if not entry:
        return None
    stored_at, df = entry
    if datetime.now(timezone.utc) - stored_at > _MEMO_TTL:
        _memo.pop(_memo_key(ticker, timeframe, lookback), None)
        return None
    return df


def _memo_put(ticker, timeframe, lookback, df):
    if len(_memo) >= _MEMO_MAX_ENTRIES:
        # Evict the oldest. Crude, and correct for a map this size.
        oldest = min(_memo, key=lambda k: _memo[k][0])
        _memo.pop(oldest, None)
    _memo[_memo_key(ticker, timeframe, lookback)] = (datetime.now(timezone.utc), df.copy())


def clear_bar_memo():
    """Drop everything held in memory. Used by tests, and by any code that has just written new
    bars and must not read its own stale copy back."""
    _memo.clear()



def _purge_wrong_adjustment(db, ticker: str, timeframe: str) -> int:
    """Delete cached bars written under a different corporate-action adjustment basis.

    Adjusted and unadjusted bars are not interchangeable: NVDA's 2024-06-07 close is $1208.42
    raw and $120.84 split-adjusted, for the same row key. The upsert in _store_bars would only
    correct the bars inside the refetched window, leaving anything older sitting at the old
    basis — a series with a 10x discontinuity in the middle, which is worse than either basis
    consistently applied. So when the tag doesn't match, the whole series goes and is refetched.

    Returns the number of rows removed, for logging and for the tests to assert on.
    """
    row = db.execute(
        "SELECT COUNT(*) AS n FROM market_bars "
        "WHERE ticker = ? AND timeframe = ? AND (source IS NULL OR source != ?)",
        (ticker, timeframe, BAR_SOURCE_TAG),
    ).fetchone()
    stale = int(dict(row)["n"]) if row else 0
    if not stale:
        return 0
    db.execute(
        "DELETE FROM market_bars WHERE ticker = ? AND timeframe = ?", (ticker, timeframe)
    )
    db.commit()
    log.warning(
        "Purged %d cached %s %s bars written under a stale adjustment basis; refetching as %s",
        stale, ticker, timeframe, BAR_SOURCE_TAG,
    )
    return stale


# Columns actually used by every calculation downstream. `trade_count` and `vwap` are stored
# and were being read on every query, and are used by NO computation anywhere in the app —
# grep for them: the only reader is the raw /api/stocks/bars endpoint, which takes them from the
# provider response. Shipping them across the network on every read was pure waste.
_BAR_COLUMNS = "ts, open, high, low, close, volume"


def _fetch_cached(db, ticker: str, timeframe: str, lookback_days: int | None = None):
    """Cached bars for one ticker, LIMITED TO THE WINDOW ASKED FOR.

    THE BUG THIS FIXES, AND WHAT IT COST
    ------------------------------------
    This query had no date filter. It read every bar ever stored for the ticker — about 1,500
    daily bars back to Alpaca's 2020 boundary — even when the caller wanted 250 for an SMA200.

    The dashboard polls for analytics every 60 seconds, and that walks all fifty tickers. So a
    single open browser tab pulled roughly 75,000 rows a minute out of Postgres, forever. On
    Neon's free plan that is about 600MB an hour against a 5GB MONTHLY allowance: one tab left
    open for a working day exhausted the month and suspended the database, which took the whole
    site down and made a deploy fail its health check.

    Returns (df, max_fetched_at). Freshness needs only the newest fetched_at, so that comes back
    as one scalar from a separate tiny query rather than as a column repeated on every row.
    """
    params = [ticker, timeframe]
    where = "ticker = ? AND timeframe = ?"
    if lookback_days:
        # A small margin over the requested window: callers ask in calendar days and bars are
        # trading days, and _cache_covers_window compares spans. Trimming to exactly the window
        # would make a cache look permanently one weekend too short and refetch forever.
        cutoff = (datetime.now(timezone.utc) - timedelta(days=int(lookback_days * 1.15))).isoformat()
        where += " AND ts >= ?"
        params.append(cutoff)

    rows = db.execute(
        f"SELECT {_BAR_COLUMNS} FROM market_bars WHERE {where} ORDER BY ts ASC",
        tuple(params),
    ).fetchall()

    freshness_row = db.execute(
        "SELECT MAX(fetched_at) AS newest FROM market_bars WHERE ticker = ? AND timeframe = ?",
        (ticker, timeframe),
    ).fetchone()
    newest = freshness_row["newest"] if freshness_row else None

    if not rows:
        return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"]), newest
    return pd.DataFrame([dict(r) for r in rows]), newest


def _cache_is_fresh(cached: pd.DataFrame, timeframe: str, newest_fetched_at=None) -> bool:
    """Freshness from a single scalar rather than a per-row column.

    `fetched_at` used to ride along on every one of ~1,500 rows so that this function could take
    the maximum of them. One value was needed; fifteen hundred copies were transmitted.
    """
    if cached.empty or len(cached) < 5:
        return False
    if newest_fetched_at is None:
        return False
    last_fetched = pd.to_datetime(newest_fetched_at)
    if last_fetched.tzinfo is None:
        last_fetched = last_fetched.tz_localize("UTC")
    ttl = FRESHNESS_TTL.get(timeframe, timedelta(hours=6))
    return (datetime.now(timezone.utc) - last_fetched) < ttl


def _cache_covers_window(cached: pd.DataFrame, lookback_days: int) -> bool:
    """True when the cached series spans enough history for the currently-configured lookback.

    Freshness and coverage are different questions: a cache fetched an hour ago is fresh, but if
    it only holds 18 months of bars and the app now wants 5 years, it is still inadequate.
    Checking only the TTL would silently ignore any increase to LOOKBACK_DAYS.
    """
    if cached.empty:
        return False
    try:
        earliest = pd.to_datetime(cached["ts"], format="mixed", utc=True).min()
        latest = pd.to_datetime(cached["ts"], format="mixed", utc=True).max()
    except (TypeError, ValueError):
        return True  # unparseable timestamps: don't force an endless refetch loop
    span_days = (latest - earliest).days
    return span_days >= lookback_days * MIN_CACHE_COVERAGE


# ---------------------------------------------------------------------------------------------
# WRITE CAP
# ---------------------------------------------------------------------------------------------
# A single fetch should never write more rows than a single fetch can legitimately contain.
# Alpaca is asked for at most 2000 bars, so anything beyond this ceiling means something has gone
# wrong — a malformed response, a retry loop, a provider returning a different symbol's history —
# and the right response is to stop, not to keep writing.
#
# This app has no streaming ingestion and cannot receive an unsolicited flood: every write is the
# direct result of a page asking for a ticker. The cap therefore is not protecting against a
# firehose. It is protecting against a bug in THIS code, which is the thing that has actually
# gone wrong before.
MAX_ROWS_PER_STORE = 2500


class BarWriteCapExceeded(RuntimeError):
    """Raised instead of writing an implausible number of rows. Deliberately an exception rather
    than a silent truncation: half-written history that nothing complains about is worse than a
    visible failure, because every number computed from it afterwards looks fine."""


def _store_bars(db, ticker: str, timeframe: str, bars):
    if len(bars) > MAX_ROWS_PER_STORE:
        raise BarWriteCapExceeded(
            f"Refusing to write {len(bars)} bars for {ticker} {timeframe} in one operation; "
            f"the cap is {MAX_ROWS_PER_STORE} and Alpaca is only ever asked for 2000. "
            f"Something upstream is wrong — no rows were written.")
    now = datetime.now(timezone.utc).isoformat()
    for b in bars:
        db.execute(
            """
            INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume,
                                      trade_count, vwap, source, fetched_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(ticker, timeframe, ts) DO UPDATE SET
                open=excluded.open, high=excluded.high, low=excluded.low, close=excluded.close,
                volume=excluded.volume, trade_count=excluded.trade_count, vwap=excluded.vwap,
                source=excluded.source, fetched_at=excluded.fetched_at
            """,
            (ticker, timeframe, b.ts.isoformat(), b.open, b.high, b.low, b.close, b.volume,
             b.trade_count, b.vwap, BAR_SOURCE_TAG, now),
        )
    db.commit()


def get_bars_df(db, ticker: str, timeframe: str = "1Day", force_refresh: bool = False,
                 lookback_days: int | None = None):
    """
    Returns (df, meta). `df` has columns [ts, open, high, low, close, volume] sorted
    ascending. `meta` describes provenance honestly:
        {
          "source": "alpaca" | "cache",
          "fresh": bool,           # was a live fetch performed (vs serving cache as-is)?
          "stale_fallback": bool,  # provider failed and we fell back to (possibly old) cache
          "error": str | None,
        }
    """
    # Runs before the cache is read, so a series stored under the old (unadjusted) basis can
    # never be served — not even as the stale fallback when the provider is down. Wrong prices
    # presented as usable data is exactly the failure mode the project's no-fabrication rule
    # exists to prevent; an empty result labelled UNAVAILABLE is the honest outcome instead.
    # `lookback_days` lets a caller ask for deeper history than the live default. Only the
    # backtester does; request-path code must leave it None or it will time out the worker.
    lookback = lookback_days or LOOKBACK_DAYS.get(timeframe, 400)

    memo = _memo_get(ticker, timeframe, lookback)
    if memo is not None and not force_refresh:
        return memo.copy(), {"source": "memory", "fresh": False, "stale_fallback": False,
                             "error": None}

    purged = _purge_wrong_adjustment(db, ticker, timeframe)
    cached, newest = _fetch_cached(db, ticker, timeframe, lookback)
    meta = {"source": "cache", "fresh": False, "stale_fallback": False, "error": None}
    if purged:
        meta["cache_purged_rows"] = purged

    cols = ["ts", "open", "high", "low", "close", "volume"]

    if not force_refresh and _cache_is_fresh(cached, timeframe, newest) and \
            _cache_covers_window(cached, lookback):
        out = cached[cols].reset_index(drop=True)
        _memo_put(ticker, timeframe, lookback, out)
        return out.copy(), meta
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=lookback)

    try:
        provider = get_provider()
        bars = provider.get_bars(ticker, timeframe, start, end, limit=2000)
        if bars:
            _store_bars(db, ticker, timeframe, bars)
        refreshed, _ = _fetch_cached(db, ticker, timeframe, lookback)
        meta.update(source="alpaca", fresh=True)
        out = refreshed[cols].reset_index(drop=True)
        # ONLY MEMOISE A FRAME THAT ACTUALLY COVERS THE WINDOW. If the provider could not supply
        # the full history — a stock that listed recently, a partial response — caching the short
        # frame would keep serving it for the whole TTL and silently suppress the retry that the
        # coverage check exists to trigger. A short answer is not one worth remembering.
        if _cache_covers_window(out, lookback):
            _memo_put(ticker, timeframe, lookback, out)
        return out.copy(), meta
    except ProviderError as e:
        meta.update(error=str(e))
        if not cached.empty:
            meta["stale_fallback"] = True
            # NOT memoised. A stale fallback is a degraded answer served because the provider is
            # down; caching it would keep serving it after the provider recovers.
            return cached[cols].reset_index(drop=True), meta
        return pd.DataFrame(columns=cols), meta
