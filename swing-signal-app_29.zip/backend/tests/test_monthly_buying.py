"""
Tests for the monthly-buying (pound-cost-averaging) page and the backtest benchmark built on it.

The property that makes this page useful is also the one most likely to be mistaken for a bug:
a monthly buyer earns roughly HALF a steadily-rising stock's calendar-year move, because
January's money is invested for twelve months and December's for days. Several tests below pin
that down against hand-computable fixtures, so nobody "fixes" it later into agreeing with the
price change.
"""
import re
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import monthly_buying_service as mb


def calendar_bars(start: date, end: date, price_fn):
    """Weekday bars between two dates, with New Year's Day and Christmas removed.

    Holidays matter here: without them the fixture's "first trading day of January" would be
    1 January, which no market has, and a test asserting the first-trading-day rule would be
    asserting a property of the fixture instead of of the code.
    """
    ts, closes, d = [], [], start
    while d <= end:
        if d.weekday() < 5 and (d.month, d.day) not in {(1, 1), (12, 25)}:
            ts.append(d.isoformat())
            closes.append(float(price_fn(d)))
        d += timedelta(days=1)
    return pd.DataFrame({"ts": ts, "open": closes, "high": closes,
                         "low": closes, "close": closes,
                         "volume": [1_000_000.0] * len(ts)})


class FirstTradingDayRule(unittest.TestCase):

    def test_twelve_contributions_in_a_full_year(self):
        df = mb._prepare(calendar_bars(date(2023, 1, 1), date(2023, 12, 31), lambda d: 100.0))
        row = mb.contributions_for_year(df, 2023, today=date(2026, 8, 14))
        self.assertEqual(row["months"], 12)
        self.assertFalse(row["partial"])

    def test_january_buy_is_not_the_first_of_january(self):
        """1 January is a holiday in the fixture and shut in reality."""
        df = mb._prepare(calendar_bars(date(2023, 1, 1), date(2023, 12, 31), lambda d: 100.0))
        row = mb.contributions_for_year(df, 2023, today=date(2026, 8, 14))
        self.assertNotEqual(row["first_buy"], "2023-01-01")
        self.assertEqual(row["first_buy"], "2023-01-02")

    def test_the_fixture_really_would_have_offered_january_first(self):
        """Proves the test above is not vacuous: 2023-01-01 exists as a date, just not as a bar."""
        self.assertEqual(date(2023, 1, 1).weekday(), 6)   # a Sunday, and a market holiday anyway

    def test_buys_land_in_twelve_distinct_months(self):
        df = mb._prepare(calendar_bars(date(2024, 1, 1), date(2024, 12, 31), lambda d: 50.0))
        idxs = mb._first_trading_day_indices(df, 2024)
        months = [str(df["_month"].iloc[i]) for i in idxs]
        self.assertEqual(len(months), 12)
        self.assertEqual(len(set(months)), 12)


class ReturnOnMoneyInvested(unittest.TestCase):

    def test_a_flat_stock_returns_zero(self):
        df = mb._prepare(calendar_bars(date(2023, 1, 1), date(2023, 12, 31), lambda d: 100.0))
        row = mb.contributions_for_year(df, 2023, today=date(2026, 8, 14))
        self.assertEqual(row["return_pct"], 0.0)
        self.assertEqual(row["invested"], 1200.0)

    def test_a_steadily_rising_stock_returns_far_less_than_its_price_move(self):
        """The headline property. A 50% year is NOT a 50% return for a monthly buyer."""
        start, end = date(2023, 1, 1), date(2023, 12, 31)
        span = (end - start).days

        def price(d):
            return 100.0 * (1 + 0.5 * (d - start).days / span)   # +50% linearly over the year

        df = mb._prepare(calendar_bars(start, end, price))
        row = mb.contributions_for_year(df, 2023, today=date(2026, 8, 14))

        self.assertEqual(row["months"], 12)
        # Price moved ~+50%; the monthly buyer should land near half that.
        self.assertLess(row["return_pct"], 30.0)
        self.assertGreater(row["return_pct"], 15.0)

    def test_return_matches_a_hand_computation(self):
        """Two contributions, prices 100 then 200, valued at 200. Independently checkable."""
        # Jan and Feb only, so the year is deliberately partial — this tests the arithmetic.
        df = mb._prepare(calendar_bars(date(2023, 1, 1), date(2023, 2, 28),
                                       lambda d: 100.0 if d.month == 1 else 200.0))
        row = mb.contributions_for_year(df, 2023, today=date(2026, 8, 14), contribution=100.0)
        # 100 at 100 -> 1 share. 100 at 200 -> 0.5 shares. 1.5 shares at 200 = 300. Paid in 200.
        self.assertEqual(row["months"], 2)
        self.assertAlmostEqual(row["shares"], 1.5, places=6)
        self.assertEqual(row["invested"], 200.0)
        self.assertEqual(row["value"], 300.0)
        self.assertEqual(row["return_pct"], 50.0)

    def test_a_falling_stock_loses_less_than_its_price_move(self):
        """The mirror image, and the reason people contribute monthly in the first place."""
        start, end = date(2023, 1, 1), date(2023, 12, 31)
        span = (end - start).days

        def price(d):
            return 100.0 * (1 - 0.5 * (d - start).days / span)   # halves over the year

        df = mb._prepare(calendar_bars(start, end, price))
        row = mb.contributions_for_year(df, 2023, today=date(2026, 8, 14))
        self.assertLess(row["return_pct"], 0)
        self.assertGreater(row["return_pct"], -50.0)


class PartialYears(unittest.TestCase):

    def test_the_current_year_is_partial_even_with_twelve_months(self):
        df = mb._prepare(calendar_bars(date(2026, 1, 1), date(2026, 12, 31), lambda d: 100.0))
        row = mb.contributions_for_year(df, 2026, today=date(2026, 8, 14))
        self.assertTrue(row["partial"])
        self.assertTrue(row["year_in_progress"])

    def test_a_short_year_is_partial_and_says_why(self):
        """2020 on Alpaca's free tier: data starts 27 July, so five contribution months."""
        df = mb._prepare(calendar_bars(date(2020, 7, 27), date(2020, 12, 31), lambda d: 100.0))
        row = mb.contributions_for_year(df, 2020, today=date(2026, 8, 14))
        self.assertEqual(row["months"], 6)     # Jul(part), Aug, Sep, Oct, Nov, Dec
        self.assertTrue(row["partial"])
        self.assertIn("contribution months", row["reason"])

    def test_partial_years_are_excluded_from_the_average(self):
        """A seven-month year averaged in with full ones understates every stock."""
        rows = [
            {"year": 2021, "return_pct": 10.0, "partial": False},
            {"year": 2022, "return_pct": 20.0, "partial": False},
            {"year": 2026, "return_pct": -90.0, "partial": True},    # would wreck a naive mean
        ]
        full = [r["return_pct"] for r in rows if not r["partial"]]
        self.assertEqual(round(sum(full) / len(full), 2), 15.0)

    def test_a_year_with_no_bars_is_unavailable_not_zero(self):
        df = mb._prepare(calendar_bars(date(2023, 1, 1), date(2023, 12, 31), lambda d: 100.0))
        row = mb.contributions_for_year(df, 2019, today=date(2026, 8, 14))
        self.assertIsNone(row["return_pct"])
        self.assertEqual(row["months"], 0)
        self.assertEqual(row["reason"], "no bars for this year")


class PortfolioTotals(unittest.TestCase):

    def test_total_pools_money_rather_than_averaging_percentages(self):
        """Stocks with different contribution counts must not be weighted equally."""
        rows = [
            {"years": [{"year": 2023, "invested": 1200.0, "value": 1800.0,
                        "return_pct": 50.0, "partial": False}]},
            # Only two months of contributions, and a terrible return.
            {"years": [{"year": 2023, "invested": 200.0, "value": 100.0,
                        "return_pct": -50.0, "partial": True}]},
        ]
        totals = mb._totals(rows, [2023])
        self.assertEqual(totals[0]["invested"], 1400.0)
        self.assertEqual(totals[0]["value"], 1900.0)
        # Pooled: (1900-1400)/1400 = +35.71%. A naive average of the percentages gives 0%.
        self.assertEqual(totals[0]["return_pct"], 35.71)
        self.assertNotEqual(totals[0]["return_pct"], 0.0)

    def test_total_flags_partial_when_any_constituent_is_partial(self):
        rows = [{"years": [{"year": 2026, "invested": 800.0, "value": 900.0,
                            "return_pct": 12.5, "partial": True}]}]
        self.assertTrue(mb._totals(rows, [2026])[0]["partial"])

    def test_a_year_nobody_contributed_in_is_unavailable(self):
        totals = mb._totals([{"years": []}], [2019])
        self.assertIsNone(totals[0]["return_pct"])
        self.assertEqual(totals[0]["stocks"], 0)


class BacktestBenchmark(unittest.TestCase):
    """period_return_pct — the single line that replaced lump-sum buy-and-hold."""

    def test_flat_prices_give_zero(self):
        bars = {"AAA": calendar_bars(date(2022, 1, 1), date(2023, 12, 31), lambda d: 100.0)}
        out = mb.period_return_pct(bars, ["AAA"])
        self.assertEqual(out["return_pct"], 0.0)
        self.assertEqual(out["tickers"], 1)

    def test_it_does_not_reset_each_year(self):
        """The backtest is one continuous experiment, so contributions run the whole window."""
        bars = {"AAA": calendar_bars(date(2022, 1, 1), date(2023, 12, 31), lambda d: 100.0)}
        out = mb.period_return_pct(bars, ["AAA"], contribution=100.0)
        self.assertEqual(out["invested"], 2400.0)     # 24 months, not 12

    def test_it_reads_lower_than_lump_sum_on_a_rising_series(self):
        """The comparison that motivated the change, asserted rather than assumed."""
        start, end = date(2022, 1, 1), date(2023, 12, 31)
        span = (end - start).days

        def price(d):
            return 100.0 * (1 + 1.0 * (d - start).days / span)   # doubles over the window

        df = calendar_bars(start, end, price)
        monthly = mb.period_return_pct({"AAA": df}, ["AAA"])["return_pct"]
        lump = (float(df["close"].iloc[-1]) - float(df["close"].iloc[0])) \
            / float(df["close"].iloc[0]) * 100
        self.assertGreater(lump, 95.0)                 # the price really did roughly double
        self.assertLess(monthly, lump)                 # and monthly buying earns materially less
        self.assertGreater(monthly, 0)

    def test_no_usable_history_is_reported_not_invented(self):
        out = mb.period_return_pct({}, [])
        self.assertIsNone(out["return_pct"])
        self.assertEqual(out["tickers"], 0)
        self.assertIn("No usable price history", out["note"])


class BacktestWiring(unittest.TestCase):

    def test_run_backtest_reports_the_monthly_benchmark(self):
        from services import backtest_service as bt
        from tests.test_annual_backtest import bars, make_db
        bars_by = {"AAA": bars(700, seed=1), "SPY": bars(700, seed=4), "QQQ": bars(700, seed=5)}
        result = bt.run_backtest(make_db(), ["AAA"], bars_by, {"use_regime": True})
        self.assertIn("monthly_contributions_benchmark", result)
        self.assertNotIn("buy_and_hold_benchmark", result,
                         "the lump-sum benchmark was supposed to be replaced, not kept")
        self.assertIsNotNone(result["monthly_contributions_benchmark"]["return_pct"])


if __name__ == "__main__":
    unittest.main()


class PageWiring(unittest.TestCase):
    """The failure mode this catches: a page that loads but whose script never ran.

    A previous build shipped a picker that the API accepted and no page ever sent. These assert
    the route, the template, the script and the element ids all line up.
    """

    def setUp(self):
        import app as app_module
        self.client = app_module.create_app().test_client()
        self.frontend = Path(__file__).resolve().parent.parent.parent / "frontend"

    def test_page_renders_and_is_in_the_nav(self):
        self.assertEqual(self.client.get("/monthly-buying").status_code, 200)
        self.assertIn(b'href="/monthly-buying"', self.client.get("/").data)

    def test_script_exists_and_is_referenced(self):
        html = (self.frontend / "templates" / "monthly_buying.html").read_text()
        self.assertIn("js/monthly_buying.js", html)
        self.assertTrue((self.frontend / "static" / "js" / "monthly_buying.js").exists())

    def test_every_element_the_script_writes_to_exists_in_the_template(self):
        html = (self.frontend / "templates" / "monthly_buying.html").read_text()
        js = (self.frontend / "static" / "js" / "monthly_buying.js").read_text()
        for element_id in re.findall(r'getElementById\("([^"]+)"\)', js):
            self.assertIn(f'id="{element_id}"', html,
                          f"{element_id} is written to by the script but absent from the page")

    def test_the_endpoint_the_script_calls_is_registered(self):
        import app as app_module
        js = (self.frontend / "static" / "js" / "monthly_buying.js").read_text()
        self.assertIn("/api/stocks/monthly-buying", js)
        rules = {str(r.rule) for r in app_module.create_app().url_map.iter_rules()}
        self.assertIn("/api/stocks/monthly-buying", rules)

    def test_the_yearly_page_was_left_alone(self):
        """Explicitly requested: the original Yearly page must be untouched."""
        self.assertEqual(self.client.get("/yearly").status_code, 200)
        self.assertIn(b'href="/yearly"', self.client.get("/").data)
        yearly_js = (self.frontend / "static" / "js" / "yearly.js").read_text()
        self.assertNotIn("monthly-buying", yearly_js)
