"""
What is in the menu, what is deliberately not, and the guarantee that "not in the menu" never
quietly became "broken".

Removing a page from the nav is a judgement about attention, not about performance: an unvisited
Flask route is never rendered and costs nothing at runtime. So the rule enforced here is that
every retired page STILL RESPONDS. If one ever starts 404ing, that is a real regression hiding
behind a cosmetic decision.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app as app_module

IN_THE_MENU = ["/", "/yearly", "/monthly-buying", "/signals", "/strategy-lab", "/backtest",
               "/annual-backtest", "/pattern-test", "/alerts", "/settings"]

RETIRED_BUT_WORKING = {
    "/stocks": "identical to the dashboard's table, from the same script",
    "/portfolio": "a manual journal, blank unless trades are typed in by hand",
    "/trades": "the same, and /performance reads from it",
    "/performance": "therefore also blank without a hand-kept journal",
    "/entry-test": "a diagnostic that answered no",
    "/selection-test": "a second diagnostic that answered no by another method",
}


class Menu(unittest.TestCase):

    def setUp(self):
        self.client = app_module.create_app().test_client()
        self.home = self.client.get("/").data

    def test_every_menu_entry_is_present_and_renders(self):
        for route in IN_THE_MENU:
            with self.subTest(route=route):
                self.assertEqual(self.client.get(route).status_code, 200)
                if route != "/":
                    self.assertIn(f'href="{route}"'.encode(), self.home)

    def test_retired_pages_are_not_in_the_menu(self):
        for route, why in RETIRED_BUT_WORKING.items():
            with self.subTest(route=route, reason=why):
                self.assertNotIn(f'href="{route}"'.encode(), self.home)

    def test_retired_pages_still_respond(self):
        """Retired means out of sight, not deleted. A 404 here is a real break."""
        for route, why in RETIRED_BUT_WORKING.items():
            with self.subTest(route=route, reason=why):
                self.assertEqual(self.client.get(route).status_code, 200,
                                 f"{route} was retired from the menu and is now broken")

    def test_the_per_company_detail_pages_survived_the_stocks_removal(self):
        """The only part of /stocks worth keeping, and it is a different route."""
        from routers.api_stocks import TICKERS
        ticker = sorted(TICKERS)[0]
        self.assertEqual(self.client.get(f"/stocks/{ticker}").status_code, 200)

    def test_a_dashboard_row_links_to_a_detail_page(self):
        """Those detail pages have to stay REACHABLE, not merely exist."""
        dashboard_js = (Path(__file__).resolve().parent.parent.parent
                        / "frontend" / "static" / "js" / "dashboard.js").read_text()
        self.assertIn("'/stocks/", dashboard_js)

    def test_an_unknown_ticker_is_still_a_clean_404(self):
        self.assertEqual(self.client.get("/stocks/NOTATICKER").status_code, 404)

    def test_the_menu_has_no_duplicates(self):
        import re
        hrefs = re.findall(rb'<a href="([^"]+)" class=', self.home)
        self.assertEqual(len(hrefs), len(set(hrefs)), "the same page appears twice in the menu")
