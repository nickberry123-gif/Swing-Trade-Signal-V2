"""
What buying the same amount every month would have returned, calendar year by calendar year.

THE RULE
--------
On the first TRADING day of each month, buy a fixed amount of money's worth of the stock. At the
end of the year, compare what the holding is worth with what was paid in. Each calendar year
starts from nothing.

WHY "FIRST TRADING DAY" AND NOT "THE 1ST"
-----------------------------------------
Markets are shut on 1 January every year, and the 1st falls at a weekend a third of the time.
Taking the rule literally would silently skip roughly four months a year and the figures would
be built on eight contributions while claiming twelve.

WHY THE PERCENTAGES LOOK LOW, AND WHY THAT IS CORRECT
-----------------------------------------------------
This is a return on money invested, not a price change. January's contribution is exposed for
twelve months; December's for days. If a stock climbs 50% smoothly through a year, the monthly
buyer earns roughly half that, because the average pound was only in the market for about half
the year. A number here that MATCHED the stock's calendar-year price move would mean something
had gone wrong.

That property is the entire point. It is what a person actually experiences when they contribute
monthly, and it is the honest benchmark to judge a timing strategy against — unlike lump-sum
buy-and-hold, which assumes a pile of cash on day one that nobody has.

WHAT IT IS NOT
--------------
No dividends beyond what the adjusted price series already carries, no fees, no commission, no
stamp duty, no FX. Fractional shares are assumed; without them the first contribution into a
four-figure share price would behave very differently.
"""
import logging
from datetime import date, datetime, timezone

import pandas as pd

from services.bars_service import get_bars_df

log = logging.getLogger(__name__)

YEARS_SHOWN = 6                 # five prior years plus the current year to date
MONTHLY_CONTRIBUTION = 100.0    # the unit is arbitrary; every figure reported is a percentage

# Alpaca's free tier begins 2020-07-27. A "year" holding five months of data would produce a
# figure that looks like a yearly return and is not one, so such years are reported as partial
# and excluded from any total.
MIN_MONTHS_FOR_A_FULL_YEAR = 12


def _first_trading_day_indices(df: pd.DataFrame, year: int) -> list:
    """Row index of the first available bar in each month of `year`, in month order."""
    rows = df[df["_year"] == year]
    if rows.empty:
        return []
    # groupby preserves the first occurrence within each month because the frame is sorted
    # ascending by date, which bars_service guarantees.
    return [int(idx) for idx in rows.groupby(rows["_month"]).head(1).index]


def contributions_for_year(df: pd.DataFrame, year: int, today: date,
                           contribution: float = MONTHLY_CONTRIBUTION) -> dict:
    """One calendar year of monthly buying, measured at the year's last available bar."""
    idxs = _first_trading_day_indices(df, year)
    if not idxs:
        return {"year": year, "months": 0, "invested": None, "value": None, "return_pct": None,
                "partial": False, "first_buy": None, "last_buy": None, "valued_at": None,
                "reason": "no bars for this year"}

    shares = 0.0
    invested = 0.0
    buys = []
    for i in idxs:
        price = float(df["close"].iloc[i])
        if price <= 0:
            continue
        shares += contribution / price
        invested += contribution
        buys.append({"date": df["_date"].iloc[i].isoformat(), "price": round(price, 2)})

    if not buys:
        return {"year": year, "months": 0, "invested": None, "value": None, "return_pct": None,
                "partial": False, "first_buy": None, "last_buy": None, "valued_at": None,
                "reason": "no usable prices for this year"}

    year_rows = df[df["_year"] == year]
    last_i = int(year_rows.index[-1])
    valuation_price = float(df["close"].iloc[last_i])
    value = shares * valuation_price

    year_in_progress = year == today.year
    partial = year_in_progress or len(buys) < MIN_MONTHS_FOR_A_FULL_YEAR

    return {
        "year": year,
        "months": len(buys),
        "invested": round(invested, 2),
        "value": round(value, 2),
        # Return ON MONEY INVESTED. See the module docstring for why this reads lower than the
        # stock's price change over the same year.
        "return_pct": round((value - invested) / invested * 100, 2) if invested else None,
        "shares": round(shares, 6),
        "partial": bool(partial),
        "year_in_progress": bool(year_in_progress),
        "first_buy": buys[0]["date"],
        "last_buy": buys[-1]["date"],
        "valued_at": df["_date"].iloc[last_i].isoformat(),
        "valuation_price": round(valuation_price, 2),
        "reason": ("year still in progress" if year_in_progress else
                   f"only {len(buys)} contribution months available"
                   if len(buys) < MIN_MONTHS_FOR_A_FULL_YEAR else None),
    }


def _prepare(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy().reset_index(drop=True)
    ts = pd.to_datetime(out["ts"], format="mixed", utc=True)
    out["_date"] = ts.dt.date
    out["_year"] = ts.dt.year
    # Formatted rather than converted to a Period: to_period() drops the timezone and warns on
    # every call, and all this needs is a stable per-month grouping key.
    out["_month"] = ts.dt.strftime("%Y-%m")
    return out


def compute_for_ticker(db, ticker: str, today: date | None = None,
                       contribution: float = MONTHLY_CONTRIBUTION) -> dict:
    today = today or datetime.now(timezone.utc).date()
    years = [today.year - i for i in range(YEARS_SHOWN - 1, -1, -1)]
    lookback = (today - date(years[0], 1, 1)).days + 30

    df, meta = get_bars_df(db, ticker, "1Day", lookback_days=lookback)
    if df.empty:
        return {"ticker": ticker,
                "years": [{"year": y, "months": 0, "invested": None, "value": None,
                           "return_pct": None, "partial": False, "reason": "no price history"}
                          for y in years],
                "avg_year_pct": None, "avg_year_pct_basis": 0,
                "data_status": "UNAVAILABLE",
                "error": meta.get("error") or "No cached or live bars for this ticker."}

    prepared = _prepare(df)
    year_rows = [contributions_for_year(prepared, y, today, contribution) for y in years]

    # The average deliberately uses COMPLETE years only. Averaging a seven-month year in with
    # full ones understates every stock by an amount that varies with how much history exists.
    full = [r["return_pct"] for r in year_rows
            if r["return_pct"] is not None and not r["partial"]]
    return {
        "ticker": ticker,
        "years": year_rows,
        "avg_year_pct": round(sum(full) / len(full), 2) if full else None,
        "avg_year_pct_basis": len(full),
        "latest_close": round(float(prepared["close"].iloc[-1]), 2),
        "latest_close_date": prepared["_date"].iloc[-1].isoformat(),
        "data_status": "STALE" if meta.get("stale_fallback") else "OK",
        "error": meta.get("error"),
    }


def _totals(rows: list, years: list) -> list:
    """The portfolio line: the same contribution into EVERY stock, every month.

    Computed from pooled money in and money out rather than by averaging the per-stock
    percentages. Those differ whenever stocks have different numbers of contribution months, and
    the pooled version is the one that corresponds to an actual bank transfer.
    """
    out = []
    for year in years:
        invested = value = 0.0
        contributing = 0
        partial = False
        for row in rows:
            match = next((y for y in row.get("years", []) if y.get("year") == year), None)
            if not match or match.get("invested") is None:
                continue
            invested += match["invested"]
            value += match["value"]
            contributing += 1
            partial = partial or bool(match.get("partial"))
        out.append({
            "year": year,
            "stocks": contributing,
            "invested": round(invested, 2) if contributing else None,
            "value": round(value, 2) if contributing else None,
            "return_pct": (round((value - invested) / invested * 100, 2)
                           if invested else None),
            "partial": partial,
        })
    return out


def compute_monthly_buying(db, tickers: list, today: date | None = None,
                           etfs: list | None = None,
                           contribution: float = MONTHLY_CONTRIBUTION) -> dict:
    today = today or datetime.now(timezone.utc).date()
    years = [today.year - i for i in range(YEARS_SHOWN - 1, -1, -1)]

    results = []
    for t in tickers:
        try:
            results.append(compute_for_ticker(db, t, today, contribution))
        except Exception as e:  # noqa: BLE001
            # One bad ticker must not blank the page. Roll back first: on Postgres a failed
            # statement aborts the transaction and every later query in the request would die.
            try:
                db.rollback()
            except Exception:  # noqa: BLE001
                pass
            log.warning("Monthly-buying computation failed for %s: %s", t, e)
            results.append({"ticker": t, "years": [], "avg_year_pct": None,
                            "data_status": "UNAVAILABLE", "error": str(e)})

    etf_rows = []
    for etf in (etfs or []):
        try:
            data = compute_for_ticker(db, etf["proxy"], today, contribution)
        except Exception as e:  # noqa: BLE001
            try:
                db.rollback()
            except Exception:  # noqa: BLE001
                pass
            log.warning("Monthly-buying failed for ETF proxy %s: %s", etf["proxy"], e)
            data = {"years": [], "avg_year_pct": None, "data_status": "UNAVAILABLE",
                    "error": str(e)}
        data = dict(data)
        data.update({
            "ticker": etf["ticker"],            # the ticker actually followed
            "name": etf.get("name"),
            "listing": etf.get("listing"),
            "priced_via": etf["proxy"],         # where the numbers really came from
            "priced_via_name": etf.get("proxy_name"),
            "match": etf.get("match"),
            "proxy_note": etf.get("note"),
            "is_etf": True,
        })
        etf_rows.append(data)

    return {
        "years_shown": years,
        "current_year": today.year,
        "monthly_contribution": contribution,
        "results": results,
        "etfs": etf_rows,
        "totals": _totals(results, years),
        "computed_at": datetime.now(timezone.utc).isoformat(),
        "basis": (f"Buys {contribution:.0f} of each stock at the CLOSE of the first trading day "
                  f"of every month, using split- and dividend-adjusted prices. The percentage is "
                  f"the return on money invested, measured at the last bar of the year."),
        "why_lower": ("These percentages read lower than a stock's price change for the same "
                      "year, and that is correct: January's contribution is invested for twelve "
                      "months and December's for days, so the average pound is only exposed for "
                      "about half the year."),
    }


def period_return_pct(bars_by_ticker: dict, tickers: list,
                      contribution: float = MONTHLY_CONTRIBUTION) -> dict:
    """The same rule applied to one continuous window — the backtest's benchmark.

    Used in place of lump-sum buy-and-hold, which assumed all the money existed on day one.
    Contributions run from the first bar to the last across the WHOLE window, without resetting
    at each year, because the backtest is a single continuous experiment.
    """
    invested = value = 0.0
    used, first_buy, last_buy = [], None, None

    for t in tickers:
        df = bars_by_ticker.get(t)
        if df is None or len(df) == 0:
            continue
        prepared = _prepare(df)
        idxs = [int(i) for i in prepared.groupby(prepared["_month"]).head(1).index]
        if not idxs:
            continue
        shares = t_invested = 0.0
        for i in idxs:
            price = float(prepared["close"].iloc[i])
            if price <= 0:
                continue
            shares += contribution / price
            t_invested += contribution
        if t_invested <= 0:
            continue
        invested += t_invested
        value += shares * float(prepared["close"].iloc[-1])
        used.append(t)
        d0 = prepared["_date"].iloc[idxs[0]].isoformat()
        d1 = prepared["_date"].iloc[idxs[-1]].isoformat()
        first_buy = d0 if first_buy is None or d0 < first_buy else first_buy
        last_buy = d1 if last_buy is None or d1 > last_buy else last_buy

    if not used or invested <= 0:
        return {"return_pct": None, "tickers": 0, "months": 0, "note":
                "No usable price history for a monthly-contribution comparison."}

    months = len({m for t in used
                  for m in _prepare(bars_by_ticker[t])["_month"].unique()})
    return {
        "return_pct": round((value - invested) / invested * 100, 2),
        "tickers": len(used),
        "months": months,
        "invested": round(invested, 2),
        "value": round(value, 2),
        "first_buy": first_buy,
        "last_buy": last_buy,
        "note": ("Buys the same amount of every tested stock on the first trading day of each "
                 "month across the whole window, and never sells. This is a return on money "
                 "invested, so it is not comparable with a lump-sum figure — money paid in "
                 "later was exposed for less time."),
    }
