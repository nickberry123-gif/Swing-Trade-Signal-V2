function statTile(label, value, sub, cls) {
  return `<div class="stat-tile"><div class="st-label">${label}</div>
    <div class="st-value ${cls || ""}">${value}</div>
    ${sub ? `<div class="st-sub">${sub}</div>` : ""}</div>`;
}

function num(v, digits, suffix) {
  if (v === null || v === undefined) return "—";
  return fmtNum(v, digits === undefined ? 2 : digits) + (suffix || "");
}

function segRow(name, m) {
  return `<tr>
    <td>${name.replace(/_/g, " ")}</td>
    <td class="text-right">${m.trades}</td>
    <td class="text-right">${num(m.win_rate_pct, 1, "%")}</td>
    <td class="text-right ${pctClass(m.avg_return_pct)}">${fmtPct(m.avg_return_pct, 2)}</td>
    <td class="text-right ${pctClass(m.total_return_pct)}">${fmtPct(m.total_return_pct, 2)}</td>
    <td class="text-right num-neg">${fmtPct(m.max_drawdown_pct, 2)}</td>
  </tr>`;
}

function renderResults(r) {
  document.getElementById("bt-results").style.display = "";
  const o = r.overall || {};

  document.getElementById("bt-overall").innerHTML = [
    statTile("Total Return", fmtPct(o.total_return_pct, 2), "one account, one slot per tracked stock", pctClass(o.total_return_pct)),
    statTile("Trades", o.trades ?? "—", "simulated"),
    statTile("Win Rate", num(o.win_rate_pct, 1, "%")),
    statTile("Avg Return / Trade", fmtPct(o.avg_return_pct, 2), null, pctClass(o.avg_return_pct)),
    statTile("Max Drawdown", fmtPct(o.max_drawdown_pct, 2), "peak to trough, realised", "num-neg"),
    statTile("Profit Factor", num(o.profit_factor, 2), "gross win / gross loss"),
    statTile("Avg Hold", num(o.avg_holding_days, 1) + " days"),
    statTile("Best / Worst", `${fmtPct(o.best_pct, 1)} / ${fmtPct(o.worst_pct, 1)}`),
  ].join("");

  // Show what the filter actually did, not just what was typed. Requesting a minimum below the
  // BUY threshold silently changes nothing, which previously read as "the setting is broken".
  const cfg = r.config || {};
  const cfgNote = document.getElementById("bt-config-note");
  if (cfgNote) {
    const requested = cfg.min_score;
    const applied = cfg.min_score_effective;
    cfgNote.innerHTML = applied !== undefined && applied !== null
      ? `Run with max hold <strong>${cfg.max_holding_days}</strong> days, slippage <strong>${cfg.slippage_pct}%</strong>, ` +
        `minimum score <strong>${applied}</strong>` +
        (requested !== undefined && Number(requested) < Number(applied)
          ? ` <span class="text-dim">(you asked for ${requested}; ${cfg.min_score_note})</span>` : "") + "."
      : "";
  }

  const mc = r.monthly_contributions_benchmark || {};
  const beat = o.total_return_pct !== null && mc.return_pct !== null &&
               o.total_return_pct !== undefined && mc.return_pct !== undefined
               ? o.total_return_pct - mc.return_pct : null;
  document.getElementById("bt-benchmark").innerHTML = `
    <div class="stat-grid">
      ${statTile("Strategy", fmtPct(o.total_return_pct, 2), null, pctClass(o.total_return_pct))}
      ${statTile("Monthly buying", fmtPct(mc.return_pct, 2), `same amount into ${mc.tickers || 0} stocks each month`, pctClass(mc.return_pct))}
      ${statTile("Difference", fmtPct(beat, 2), beat !== null && beat < 0 ? "strategy underperformed just contributing" : "strategy added value", pctClass(beat))}
    </div>
    <p class="inline-note">The benchmark is paying the same amount into the same stocks on the first trading day of every month and never selling &mdash; the thing you would actually do instead of timing entries. It is a return on money invested, so it reads lower than a price change: money paid in later was exposed for less time.</p>`;

  const segs = r.by_segment || {};
  document.getElementById("bt-segments").innerHTML =
    ["IN_SAMPLE", "VALIDATION", "OUT_OF_SAMPLE"]
      .filter((s) => segs[s]).map((s) => segRow(s, segs[s])).join("") ||
    `<tr class="loading-row"><td colspan="6">No trades to segment.</td></tr>`;

  document.getElementById("bt-wf-note").innerHTML =
    `Strategy v1.0's weights are <strong>fixed, not fitted to this data</strong> — nothing was optimised. ` +
    `So these segments do not prove absence of overfitting the way they would for a tuned model; ` +
    `what they show is whether the strategy holds up across <em>different market periods</em>. ` +
    `If a future version starts tuning weights, that tuning must happen on in-sample data only, ` +
    `or the out-of-sample column stops meaning anything.`;

  const byTicker = r.by_ticker || {};
  document.getElementById("bt-byticker").innerHTML = Object.keys(byTicker)
    .sort((a, b) => (byTicker[b].total_return_pct || -999) - (byTicker[a].total_return_pct || -999))
    .map((t) => {
      const m = byTicker[t];
      return `<tr onclick="window.location.href='/stocks/${encodeURIComponent(t)}'">
        <td><span class="ticker-badge">${t}</span></td>
        <td class="text-right">${m.trades}</td>
        <td class="text-right">${num(m.win_rate_pct, 1, "%")}</td>
        <td class="text-right ${pctClass(m.avg_return_pct)}">${fmtPct(m.avg_return_pct, 2)}</td>
        <td class="text-right ${pctClass(m.total_return_pct)}">${fmtPct(m.total_return_pct, 2)}</td>
        <td class="text-right">${num(m.avg_holding_days, 1)}</td>
      </tr>`;
    }).join("") || `<tr class="loading-row"><td colspan="6">No trades.</td></tr>`;

  const trades = r.trades || [];
  document.getElementById("bt-trades").innerHTML = trades.length
    ? trades.slice(0, 100).map((t) => `
        <tr>
          <td><span class="ticker-badge">${t.ticker}</span></td>
          <td>${t.signal_date}</td>
          <td>${t.entry_date}</td>
          <td class="text-right">${fmtPrice(t.entry_price)}</td>
          <td>${t.exit_date || "—"}</td>
          <td class="text-right">${fmtPrice(t.exit_price)}</td>
          <td>${(t.exit_reason || "").replace(/_/g, " ")}</td>
          <td class="text-right">${t.holding_days ?? "—"}</td>
          <td class="text-right ${pctClass(t.return_pct)}">${fmtPct(t.return_pct, 2)}</td>
          <td class="text-dim" style="font-size:11px;">${(t.segment || "").replace(/_/g, " ")}</td>
        </tr>`).join("")
    : `<tr class="loading-row"><td colspan="10">No trades were generated. In a relentless uptrend this is expected: the strategy refuses to buy above its maximum entry price rather than chase.</td></tr>`;

  document.getElementById("bt-limitations").innerHTML =
    (r.limitations || []).map((l) => `<li>${l}</li>`).join("");

  document.getElementById("bt-message").innerHTML =
    (r.warnings || []).map((w) => `<div class="warn-banner">${w}</div>`).join("");
}

async function loadRuns() {
  try {
    const data = await apiGet("/api/backtest/runs");
    const runs = data.runs || [];
    document.getElementById("bt-runs").innerHTML = runs.length
      ? runs.map((r) => `
          <tr>
            <td>#${r.id}</td>
            <td>${fmtTime(r.created_at)}</td>
            <td class="text-right">${r.total_trades ?? "—"}</td>
            <td class="text-right">${num(r.win_rate_pct, 1, "%")}</td>
            <td class="text-right ${pctClass(r.avg_return_pct)}">${fmtPct(r.avg_return_pct, 2)}</td>
            <td class="text-right ${pctClass(r.total_return_pct)}">${fmtPct(r.total_return_pct, 2)}</td>
            <td class="text-right num-neg">${fmtPct(r.max_drawdown_pct, 2)}</td>
          </tr>`).join("")
      : `<tr class="loading-row"><td colspan="7">No backtests run yet.</td></tr>`;
  } catch (e) {
    document.getElementById("bt-runs").innerHTML =
      `<tr class="loading-row"><td colspan="7">Could not load runs: ${e.message}</td></tr>`;
  }
}

document.getElementById("bt-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const btn = document.getElementById("bt-run-btn");
  btn.disabled = true;
  btn.textContent = "Running…";

  const started = Date.now();
  // Server-reported stage. Without it a long run looks identical to a hung one.
  let stage = "";
  const tick = () => {
    const secs = Math.round((Date.now() - started) / 1000);
    document.getElementById("bt-message").innerHTML =
      `<div class="warn-banner">Backtest running — ${secs}s elapsed. Indicators are recomputed for every historical bar to guarantee no look-ahead, so 5 years across 15 stocks takes 1–2 minutes. You can leave this page open; the run continues on the server either way.${stage ? `<br><strong>${stage}</strong>` : ""}</div>`;
  };
  tick();
  const ticker = setInterval(tick, 1000);

  try {
    // The server starts the run in a background thread and returns immediately — a synchronous
    // request would exceed gunicorn's 30s worker timeout and come back as an HTML error page.
    const res = await fetch("/api/backtest/run", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        max_holding_days: Number(document.getElementById("bt-hold").value),
        min_score: Number(document.getElementById("bt-minscore").value),
        slippage_pct: Number(document.getElementById("bt-slip").value),
        commission_per_trade: Number(document.getElementById("bt-comm").value),
        exit_on_signal: document.getElementById("bt-exit").value === "true",
        strategy_id: selectedStrategyId("bt-strategy"),
      }),
    });

    const contentType = res.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      throw new Error(`Server returned ${res.status} (${contentType || "no content-type"}) instead of JSON — the request likely timed out at the gateway.`);
    }
    const started_run = await res.json();
    if (started_run.error) throw new Error(started_run.error);

    const runId = started_run.run_id;
    if (!runId) throw new Error("Server did not return a run id.");

    // Poll until the run leaves 'running'. 4 minute ceiling so a stuck run can't spin forever.
    const deadline = Date.now() + 40 * 60 * 1000;
    let run = null;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 3000));
      const pollRes = await fetch(`/api/backtest/runs/${runId}`, { headers: { Accept: "application/json" } });
      if (!pollRes.ok) continue;
      run = await pollRes.json();
      if (run.progress) stage = run.progress;
      if (run.status && run.status !== "running") break;
    }

    clearInterval(ticker);

    if (!run || run.status === "running") {
      throw new Error("Backtest is still running after 15 minutes. Reload the page shortly and check Previous Runs — the result will appear there when it finishes.");
    }
    if (run.status === "failed") {
      throw new Error(run.error || "The backtest failed on the server.");
    }

    // The stored results payload omits the trade list; the run endpoint returns it separately.
    const results = run.results || {};
    results.trades = run.trades || [];
    renderResults(results);
    loadRuns();
  } catch (e) {
    clearInterval(ticker);
    document.getElementById("bt-message").innerHTML =
      `<div class="error-banner">Backtest failed: ${e.message}</div>`;
  } finally {
    clearInterval(ticker);
    btn.disabled = false;
    btn.textContent = "Run Backtest";
  }
});

loadRuns();

populateStrategySelect("bt-strategy");
