// Selection test. Background thread + polling, same reason as the other long analyses.

const SEL_HORIZONS = ["1 month", "3 months", "6 months", "12 months", "24 months"];

function corrCell(v) {
  if (v === null || v === undefined) return `<td class="text-right text-dim">&mdash;</td>`;
  // Signed to three places and colour-coded, but the sign is in the text either way.
  const cls = v > 0.05 ? "num-pos" : v < -0.05 ? "num-neg" : "text-dim";
  const sign = v >= 0 ? "+" : "";
  return `<td class="text-right ${cls}" style="font-weight:600;">${sign}${v.toFixed(3)}</td>`;
}

function pickCell(p) {
  if (!p || p.mean_pct === null || p.mean_pct === undefined) {
    return `<td class="text-right text-dim">&mdash;</td>`;
  }
  return `<td class="text-right ${pctClass(p.mean_pct)}">${fmtPct(p.mean_pct, 1)}</td>`;
}

function renderCorrelation(results) {
  const rows = SEL_HORIZONS.filter((h) => results.horizons && results.horizons[h]);
  const tbody = document.getElementById("st-correlation");
  if (!rows.length) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="5">Nothing could be measured.</td></tr>`;
    return;
  }
  tbody.innerHTML = rows.map((h) => {
    const rc = results.horizons[h].rank_correlation || {};
    // A t-statistic on overlapping windows is inflated, so it is withheld rather than shown
    // with a caveat nobody reads.
    let sig;
    if (!rc.t_stat_available) {
      sig = `<span class="text-dim" title="${rc.t_stat_note || ""}">not testable &mdash; windows overlap</span>`;
    } else if (rc.t_stat === null || rc.t_stat === undefined) {
      sig = `<span class="text-dim">&mdash;</span>`;
    } else {
      const strong = Math.abs(rc.t_stat) >= 2;
      sig = `<span class="${strong ? "num-pos" : "text-dim"}">t = ${fmtNum(rc.t_stat, 2)} &mdash; ${strong ? "yes" : "no"}</span>`;
    }
    return `<tr>
      <td>${h}</td>
      ${corrCell(rc.mean)}
      <td class="text-right">${rc.months_positive_pct === null || rc.months_positive_pct === undefined
        ? "&mdash;" : fmtNum(rc.months_positive_pct, 1) + "%"}</td>
      <td class="text-right">${rc.n ?? "&mdash;"}</td>
      <td class="text-right">${sig}</td>
    </tr>`;
  }).join("");
}

function renderPicks(results) {
  const rows = SEL_HORIZONS.filter((h) => results.horizons && results.horizons[h]);
  const tbody = document.getElementById("st-picks");
  if (!rows.length) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="6">Nothing could be measured.</td></tr>`;
    return;
  }
  tbody.innerHTML = rows.map((h) => {
    const d = results.horizons[h];
    const p = d.picks || {};
    const tmb = d.top_minus_bottom_pct;
    return `<tr>
      <td>${h}</td>
      ${pickCell(p.TOP_1)}
      ${pickCell(p.TOP_3)}
      ${pickCell(p.EQUAL_WEIGHT)}
      ${pickCell(p.BOTTOM_1)}
      <td class="text-right ${pctClass(tmb)}" style="font-weight:600;">${
        tmb === null || tmb === undefined ? "&mdash;" : fmtPct(tmb, 1)}</td>
    </tr>`;
  }).join("");
}

function renderSelection(results) {
  document.getElementById("st-results").style.display = "";
  const v = results.verdict || {};
  const headline = document.getElementById("st-verdict-headline");
  headline.textContent = v.headline || "—";
  headline.className = "quality-score-big " +
    (v.headline === "SOME SELECTION SKILL" ? "num-pos"
      : v.headline === "NO SELECTION SKILL" ? "num-neg" : "text-dim");
  document.getElementById("st-verdict-detail").textContent = v.detail || "";
  document.getElementById("st-window").textContent =
    results.decision_dates
      ? `${results.decision_dates} monthly decisions, ${results.first_date} to ${results.last_date}, across ${(results.tickers || []).length} stocks.`
      : "";
  renderCorrelation(results);
  renderPicks(results);
  document.getElementById("st-limitations").innerHTML =
    (results.limitations || []).map((l) => `<li>${l}</li>`).join("");
}

document.getElementById("st-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const btn = document.getElementById("st-run-btn");
  const msg = document.getElementById("st-message");
  btn.disabled = true;
  btn.textContent = "Running…";

  const started = Date.now();
  // Server-reported stage. Without it a long run looks identical to a hung one.
  let stage = "";
  const tick = () => {
    const secs = Math.round((Date.now() - started) / 1000);
    msg.innerHTML = `<div class="warn-banner">Selection test running — ${secs}s elapsed. All 15 stocks are scored on every month-start from a truncated slice of history, so this takes 1–2 minutes. The run continues on the server whether or not you stay here.${stage ? `<br><strong>${stage}</strong>` : ""}</div>`;
  };
  tick();
  const ticker = setInterval(tick, 1000);

  try {
    const res = await fetch("/api/selection-test/run", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ strategy_id: selectedStrategyId("st-strategy") }),
    });
    const contentType = res.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      throw new Error(`Server returned ${res.status} (${contentType || "no content-type"}) instead of JSON — the request likely timed out at the gateway.`);
    }
    const startedRun = await res.json();
    if (startedRun.error) throw new Error(startedRun.error);
    const runId = startedRun.run_id;
    if (!runId) throw new Error("Server did not return a run id.");

    const deadline = Date.now() + 40 * 60 * 1000;
    let run = null;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 3000));
      const poll = await fetch(`/api/selection-test/runs/${runId}`, { headers: { Accept: "application/json" } });
      if (!poll.ok) continue;
      run = await poll.json();
      if (run.progress) stage = run.progress;
      if (run.status && run.status !== "running") break;
    }
    clearInterval(ticker);

    if (!run || run.status === "running") {
      throw new Error("Still running after 40 minutes. Reload shortly — the result is stored on the server when it finishes.");
    }
    if (run.status === "failed") throw new Error(run.error || "The selection test failed on the server.");

    msg.innerHTML = "";
    renderSelection(run.results || {});
  } catch (e) {
    clearInterval(ticker);
    msg.innerHTML = `<div class="error-banner">${e.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Run Selection Test";
  }
});

populateStrategySelect("st-strategy");

(async function showLatest() {
  try {
    const list = await apiGet("/api/selection-test/runs");
    const done = (list.runs || []).find((r) => r.status === "complete");
    if (!done) return;
    const run = await apiGet(`/api/selection-test/runs/${done.id}`);
    if (run.results) renderSelection(run.results);
  } catch (e) {
    // Nothing stored yet is not an error worth showing.
  }
})();
