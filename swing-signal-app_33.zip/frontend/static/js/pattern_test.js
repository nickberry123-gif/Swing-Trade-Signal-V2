// Bullish setups — long only. Renders the two setups, their quality scores, and every criterion
// the data could not answer.
//
// UNKNOWN is shown as its own state everywhere, never folded into a pass or a fail: five of the
// strategy's criteria cannot be computed from daily bars and the page must not imply otherwise.

function tile(label, value, sub, cls) {
  return `<div class="stat-tile"><div class="st-label">${label}</div>
    <div class="st-value ${cls || ""}">${value}</div>
    ${sub ? `<div class="st-sub">${sub}</div>` : ""}</div>`;
}

function setupLabel(t) {
  return (t || "").replace("BULLISH_", "").replace(/_/g, " ").toLowerCase();
}

function qualityClass(q) {
  return q === "HIGH" ? "num-pos" : q === "INVALID" ? "num-neg" : "";
}

function statRow(label, m, extra) {
  if (!m) return "";
  return `<tr>
    <td>${label}</td>
    <td class="text-right">${m.trades}</td>
    <td class="text-right">${m.win_rate_pct === null ? "—" : fmtNum(m.win_rate_pct, 1) + "%"}</td>
    <td class="text-right ${pctClass(m.mean_pct)}">${fmtPct(m.mean_pct, 2)}</td>
    ${extra ? extra(m) : ""}
  </tr>`;
}

function renderPattern(r) {
  document.getElementById("pt-results").style.display = "";
  const o = r.overall || {};
  const byQ = r.setups_by_quality || {};

  document.getElementById("pt-events").innerHTML = [
    tile("Setups detected", r.setups_detected ?? 0, "before any quality filter"),
    tile("High quality", byQ.HIGH ?? 0, "met the criteria that could be measured", "num-pos"),
    tile("Medium", byQ.MEDIUM ?? 0),
    tile("Rejected as invalid", byQ.INVALID ?? 0, "failed a hard filter", "num-neg"),
    tile("Trades taken", o.trades ?? 0, "setups that passed and were entered"),
    tile("Win rate", o.win_rate_pct === null || o.win_rate_pct === undefined ? "—" : fmtNum(o.win_rate_pct, 1) + "%"),
    tile("Average / trade", fmtPct(o.mean_pct, 2), null, pctClass(o.mean_pct)),
    // Expectancy in R is the honest headline for a fixed-risk system: every trade risks the same
    // amount, so the average result in units of that risk IS the edge.
    tile("Expectancy", o.expectancy_r === null || o.expectancy_r === undefined ? "—" : fmtNum(o.expectancy_r, 3) + "R",
         "per trade, in units of risk", pctClass(o.expectancy_r)),
  ].join("");

  document.getElementById("pt-unavailable").innerHTML =
    Object.entries(r.unavailable_criteria || {}).map(([k, why]) => `<tr>
      <td><span class="ticker-badge">${k.replace(/_/g, " ")}</span></td>
      <td style="font-size:11.5px;" class="text-dim">${why}</td>
    </tr>`).join("") || `<tr class="loading-row"><td colspan="2">—</td></tr>`;

  const byType = r.by_setup_type || {};
  document.getElementById("pt-bytype").innerHTML = Object.keys(byType).map((k) => {
    const m = byType[k];
    return `<tr>
      <td>${setupLabel(k)}</td>
      <td class="text-right">${m.trades}</td>
      <td class="text-right">${m.win_rate_pct === null ? "—" : fmtNum(m.win_rate_pct, 1) + "%"}</td>
      <td class="text-right ${pctClass(m.mean_pct)}">${fmtPct(m.mean_pct, 2)}</td>
      <td class="text-right ${pctClass(m.median_pct)}">${fmtPct(m.median_pct, 2)}</td>
      <td class="text-right">${fmtPct(m.best_pct, 1)} / ${fmtPct(m.worst_pct, 1)}</td>
      <td class="text-right">${fmtNum(m.avg_holding_days, 1)}d</td>
      <td class="text-right ${pctClass(m.expectancy_r)}">${m.expectancy_r === null ? "—" : fmtNum(m.expectancy_r, 3) + "R"}</td>
      <td class="text-right ${pctClass(m.total_dollar_result)}">${m.total_dollar_result === null ? "—" : fmtNum(m.total_dollar_result, 0)}</td>
    </tr>`;
  }).join("") || `<tr class="loading-row"><td colspan="9">No trades.</td></tr>`;

  const byQual = r.by_quality || {};
  document.getElementById("pt-byquality").innerHTML = ["HIGH", "MEDIUM", "LOW"]
    .filter((q) => byQual[q]).map((q) => statRow(q, byQual[q],
      (m) => `<td class="text-right ${pctClass(m.expectancy_r)}">${m.expectancy_r === null ? "—" : fmtNum(m.expectancy_r, 3) + "R"}</td>`))
    .join("") || `<tr class="loading-row"><td colspan="5">No trades.</td></tr>`;

  const byExit = r.by_exit_reason || {};
  document.getElementById("pt-exitreasons").innerHTML = Object.keys(byExit).map((k) =>
    statRow(k.replace(/_/g, " ").toLowerCase(), byExit[k],
            (m) => `<td class="text-right">${fmtNum(m.avg_holding_days, 1)}d</td>`))
    .join("") || `<tr class="loading-row"><td colspan="5">No trades.</td></tr>`;

  const trades = r.trades || [];
  document.getElementById("pt-trades").innerHTML = trades.length
    ? trades.slice(0, 300).map((t) => `<tr>
        <td><span class="ticker-badge">${t.ticker}</span></td>
        <td style="font-size:11.5px;">${setupLabel(t.setup_type)}</td>
        <td class="${qualityClass(t.quality)}" style="font-size:11.5px;">${t.quality}</td>
        <td style="font-size:11.5px;">${t.detected_date}</td>
        <td style="font-size:11.5px;">${t.entry_date}</td>
        <td class="text-right">${fmtPrice(t.entry_price)}</td>
        <td class="text-right">${fmtPrice(t.stop_price)}</td>
        <td class="text-right">${fmtPrice(t.target_price)}</td>
        <td class="text-right">${fmtNum(t.risk_reward, 2)}</td>
        <td class="text-right">${t.position_size_shares}</td>
        <td style="font-size:11px;">${(t.exit_reason || "").replace(/_/g, " ").toLowerCase()}</td>
        <td class="text-right ${pctClass(t.return_pct)}">${fmtPct(t.return_pct, 2)}</td>
        <td class="text-right ${pctClass(t.dollar_result)}">${fmtNum(t.dollar_result, 0)}</td>
      </tr>`).join("")
    : `<tr class="loading-row"><td colspan="13">No setup passed the quality filter and produced a trade. That is a result, not a failure.</td></tr>`;

  document.getElementById("pt-setups").innerHTML = (r.setups || []).slice(0, 300).map((s) => {
    const sc = s.scored || {};
    const why = (s.rejections || []).concat(sc.reasons_failed || []);
    return `<tr>
      <td><span class="ticker-badge">${s.ticker}</span></td>
      <td style="font-size:11.5px;">${setupLabel(s.setup_type)}</td>
      <td style="font-size:11.5px;">${s.detected_date}</td>
      <td class="${qualityClass(s.quality)}" style="font-size:11.5px;">${s.quality}</td>
      <td class="text-right">${sc.score ?? "—"}/${sc.score_out_of ?? "—"}
        <div class="yc-sub text-dim">${(sc.unknown || []).length} unknown</div></td>
      <td style="font-size:11px;" class="text-dim">${why.slice(0, 2).join(" &middot; ") || "—"}</td>
    </tr>`;
  }).join("") || `<tr class="loading-row"><td colspan="6">No setups detected.</td></tr>`;

  document.getElementById("pt-warnings").innerHTML =
    (r.warnings || []).map((w) => `<div class="warn-banner">${w}</div>`).join("");
  document.getElementById("pt-limitations").innerHTML =
    (r.limitations || []).map((l) => `<li>${l}</li>`).join("");
}

document.getElementById("pt-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const btn = document.getElementById("pt-run-btn");
  const msg = document.getElementById("pt-message");
  btn.disabled = true;
  btn.textContent = "Running…";

  const started = Date.now();
  // Server-reported stage. Without it a long run looks identical to a hung one.
  let stage = "";
  const tick = () => {
    const secs = Math.round((Date.now() - started) / 1000);
    msg.innerHTML = `<div class="warn-banner">Pattern test running — ${secs}s elapsed.${stage ? `<br><strong>${stage}</strong>` : ""}</div>`;
  };
  tick();
  const ticker = setInterval(tick, 1000);

  try {
    const res = await fetch("/api/pattern-test/run", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        setup_types: document.getElementById("pt-setup").value === "both"
          ? ["BULLISH_RETRACEMENT", "BULLISH_BASE_BREAKOUT"]
          : [document.getElementById("pt-setup").value],
        min_quality: document.getElementById("pt-quality").value,
        min_rr: Number(document.getElementById("pt-rr").value),
        max_dollar_risk: Number(document.getElementById("pt-risk").value),
        retrace_min_pct: Number(document.getElementById("pt-retmin").value),
        retrace_max_pct: Number(document.getElementById("pt-retmax").value),
        min_red_candles: Number(document.getElementById("pt-reds").value),
        base_max_width_pct: Number(document.getElementById("pt-basewidth").value),
        max_stop_pct: Number(document.getElementById("pt-stop").value),
        min_avg_volume: Number(document.getElementById("pt-vol").value),
      }),
    });
    const contentType = res.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      throw new Error(`Server returned ${res.status} instead of JSON — the request likely timed out at the gateway.`);
    }
    const startedRun = await res.json();
    if (startedRun.error) throw new Error(startedRun.error);
    const runId = startedRun.run_id;
    if (!runId) throw new Error("Server did not return a run id.");

    const deadline = Date.now() + 40 * 60 * 1000;
    let run = null;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 3000));
      const poll = await fetch(`/api/pattern-test/runs/${runId}`, { headers: { Accept: "application/json" } });
      if (!poll.ok) continue;
      run = await poll.json();
      if (run.progress) stage = run.progress;
      if (run.status && run.status !== "running") break;
    }
    clearInterval(ticker);

    if (!run || run.status === "running") {
      throw new Error("Still running after 40 minutes. Reload shortly — the result is stored on the server.");
    }
    if (run.status === "failed") throw new Error(run.error || "The pattern test failed on the server.");

    msg.innerHTML = "";
    renderPattern(run.results || {});
  } catch (e) {
    clearInterval(ticker);
    msg.innerHTML = `<div class="error-banner">${e.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Run Setup Test";
  }
});

(async function showLatest() {
  try {
    const list = await apiGet("/api/pattern-test/runs");
    const done = (list.runs || []).find((r) => r.status === "complete");
    if (!done) return;
    const run = await apiGet(`/api/pattern-test/runs/${done.id}`);
    if (run.results) renderPattern(run.results);
  } catch (e) {
    // Nothing stored yet is not an error worth showing.
  }
})();
