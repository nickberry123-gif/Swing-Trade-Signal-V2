// Minimal fetch helper shared by all pages. No API keys ever touch this file or any
// other frontend code — the browser only ever talks to this app's own /api/* routes,
// which proxy to Alpaca server-side.
async function apiGet(path) {
  const res = await fetch(path, { headers: { Accept: "application/json" } });
  if (!res.ok) {
    throw new Error(`Request to ${path} failed: ${res.status}`);
  }
  return res.json();
}

function fmtPrice(v) {
  if (v === null || v === undefined) return "—";
  return "$" + Number(v).toFixed(2);
}

function fmtChange(change, changePct) {
  if (change === null || change === undefined) return "—";
  const sign = change >= 0 ? "+" : "";
  const cls = change >= 0 ? "num-pos" : "num-neg";
  const pct = changePct !== null && changePct !== undefined ? ` (${sign}${changePct.toFixed(2)}%)` : "";
  return `<span class="${cls}">${sign}${change.toFixed(2)}${pct}</span>`;
}

function fmtVolume(v) {
  if (v === null || v === undefined) return "—";
  v = Number(v);
  if (v >= 1e9) return (v / 1e9).toFixed(2) + "B";
  if (v >= 1e6) return (v / 1e6).toFixed(2) + "M";
  if (v >= 1e3) return (v / 1e3).toFixed(1) + "K";
  return String(v);
}

function fmtTime(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString(undefined, {
    month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
}

// Maps a DataStatus string to a { pillClass, dotClass, label } triple. Text is ALWAYS
// shown alongside color — never color alone — per the project's status-display rule.
function dataStatusMeta(status) {
  switch (status) {
    case "LIVE": return { pill: "pill-live", dot: "ok", label: "LIVE" };
    case "DELAYED": return { pill: "pill-delayed", dot: "warn", label: "DELAYED" };
    case "MARKET_CLOSED": return { pill: "pill-closed", dot: "neutral", label: "MARKET CLOSED" };
    case "STALE": return { pill: "pill-stale", dot: "warn", label: "STALE" };
    case "UNAVAILABLE": return { pill: "pill-unavailable", dot: "bad", label: "UNAVAILABLE" };
    default: return { pill: "pill-closed", dot: "neutral", label: status || "UNKNOWN" };
  }
}

function statusPillHtml(status) {
  const meta = dataStatusMeta(status);
  return `<span class="pill ${meta.pill}"><span class="dot ${meta.dot}"></span>${meta.label}</span>`;
}
