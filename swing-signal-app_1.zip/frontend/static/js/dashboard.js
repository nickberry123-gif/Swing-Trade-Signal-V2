function renderStocksTable(results) {
  const tbody = document.getElementById("stocks-tbody");
  if (!tbody) return;
  if (!results || results.length === 0) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="6">No data.</td></tr>`;
    return;
  }
  tbody.innerHTML = results.map((r) => {
    const price = fmtPrice(r.last_price !== undefined ? r.last_price : r.last_known_price);
    const change = r.change !== undefined ? fmtChange(r.change, r.change_pct) : "—";
    const statusStr = r.data_status || "UNAVAILABLE";
    return `
      <tr onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'">
        <td><span class="ticker-badge">${r.ticker}</span></td>
        <td class="name-cell">${r.name || ""} <div class="company-name">${r.industry || ""}</div></td>
        <td class="text-right">${price}</td>
        <td class="text-right">${change}</td>
        <td>${r.sector || "—"}</td>
        <td>${statusPillHtml(statusStr)}</td>
      </tr>
    `;
  }).join("");
}

function updateMarketStrip(status) {
  const sessionEl = document.getElementById("mkt-session");
  if (!sessionEl) return; // not on dashboard page
  const subEl = document.getElementById("mkt-session-sub");
  const statusEl = document.getElementById("mkt-data-status");
  const nextOpenEl = document.getElementById("mkt-next-open");
  const nextCloseEl = document.getElementById("mkt-next-close");

  if (status.is_open === true) {
    sessionEl.textContent = "OPEN";
    sessionEl.style.color = "var(--green)";
  } else if (status.session) {
    sessionEl.textContent = status.session.replace("_", " ");
    sessionEl.style.color = "var(--amber)";
  } else {
    sessionEl.textContent = "UNKNOWN";
    sessionEl.style.color = "var(--text-1)";
  }
  subEl.textContent = status.timestamp ? `as of ${fmtTime(status.timestamp)}` : (status.error || "");
  statusEl.innerHTML = statusPillHtml(status.data_status);
  nextOpenEl.textContent = status.next_open ? fmtTime(status.next_open) : "—";
  nextCloseEl.textContent = status.next_close ? fmtTime(status.next_close) : "—";
}

async function refreshAll() {
  try {
    const marketStatus = await apiGet("/api/market/status");
    updateMarketStrip(marketStatus);
  } catch (e) {
    // topbar.js already surfaces this; dashboard tiles just stay at last-known state
  }

  try {
    const snap = await apiGet("/api/stocks/snapshots");
    renderStocksTable(snap.results);
    const refreshedEl = document.getElementById("last-refreshed");
    if (refreshedEl) refreshedEl.textContent = "last refreshed " + new Date().toLocaleTimeString();
    if (snap.feed_error) {
      console.warn("Alpaca feed error:", snap.feed_error);
    }
  } catch (e) {
    const tbody = document.getElementById("stocks-tbody");
    if (tbody) tbody.innerHTML = `<tr class="loading-row"><td colspan="6">Failed to load data: ${e.message}</td></tr>`;
  }
}

refreshAll();
setInterval(refreshAll, 15000);
