// TradingView is used strictly as the visual chart layer (official embedded widget).
// No data is scraped or read back out of it; nothing here feeds the signal engine.
let tvSymbol = `${window.STOCK_EXCHANGE || "NASDAQ"}:${window.STOCK_TICKER}`;

function renderChart(interval) {
  const container = document.getElementById("tv_chart_widget");
  container.innerHTML = "";
  // eslint-disable-next-line no-undef
  new TradingView.widget({
    autosize: true,
    symbol: tvSymbol,
    interval: interval,
    timezone: "America/New_York",
    theme: "dark",
    style: "1",
    locale: "en",
    toolbar_bg: "#10151f",
    enable_publishing: false,
    allow_symbol_change: false,
    hide_side_toolbar: false,
    studies: ["MASimple@tv-basicstudies"],
    container_id: "tv_chart_widget",
  });
}

document.querySelectorAll(".tf-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tf-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    renderChart(btn.dataset.interval);
  });
});

renderChart("D");

async function refreshSnapshot() {
  const ticker = window.STOCK_TICKER;
  const errBox = document.getElementById("snapshot-error");
  try {
    const snap = await apiGet(`/api/stocks/${encodeURIComponent(ticker)}/snapshot`);

    if (snap.data_status === "UNAVAILABLE" || snap.error) {
      errBox.innerHTML = `<div class="error-banner">DATA FEED ERROR — ${snap.error || "no data available"}. ${
        snap.last_known_price ? `Last known price from local database: $${Number(snap.last_known_price).toFixed(2)} (as of ${fmtTime(snap.as_of)}) — NOT live.` : ""
      }</div>`;
    } else {
      errBox.innerHTML = "";
    }

    document.getElementById("dp-price").textContent = fmtPrice(snap.last_price !== undefined ? snap.last_price : snap.last_known_price);
    document.getElementById("dp-change").innerHTML = snap.change !== undefined ? fmtChange(snap.change, snap.change_pct) : "—";
    document.getElementById("dp-status-pill").innerHTML = statusPillHtml(snap.data_status);

    document.getElementById("dp-open").textContent = fmtPrice(snap.daily_open);
    document.getElementById("dp-high").textContent = fmtPrice(snap.daily_high);
    document.getElementById("dp-low").textContent = fmtPrice(snap.daily_low);
    document.getElementById("dp-volume").textContent = fmtVolume(snap.daily_volume);
    document.getElementById("dp-prevclose").textContent = fmtPrice(snap.prev_close);
    document.getElementById("dp-bidask").textContent =
      snap.bid_price && snap.ask_price ? `${fmtPrice(snap.bid_price)} / ${fmtPrice(snap.ask_price)}` : "—";
    document.getElementById("dp-trade-ts").textContent = fmtTime(snap.last_trade_ts);
    document.getElementById("dp-fetched-ts").textContent = fmtTime(snap.fetched_at);
  } catch (e) {
    errBox.innerHTML = `<div class="error-banner">DATA FEED ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

refreshSnapshot();
setInterval(refreshSnapshot, 15000);
