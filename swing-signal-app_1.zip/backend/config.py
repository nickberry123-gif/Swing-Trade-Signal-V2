"""
Central configuration, loaded entirely from environment variables.

CRITICAL: API keys must never be hard-coded and must never be sent to the frontend.
This module is the ONLY place that reads ALPACA_API_KEY / ALPACA_SECRET_KEY from the
environment. Every other module receives what it needs via function calls, not by
reading os.environ directly, so a future audit only has one place to check.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent

# Load backend/.env explicitly (not just cwd's .env) so `python app.py` works
# regardless of the directory it's launched from.
load_dotenv(BACKEND_DIR / ".env")


class Config:
    ALPACA_API_KEY: str | None = os.environ.get("ALPACA_API_KEY")
    ALPACA_SECRET_KEY: str | None = os.environ.get("ALPACA_SECRET_KEY")
    ALPACA_ENV: str = os.environ.get("ALPACA_ENV", "paper").lower()

    DATABASE_PATH: str = os.environ.get("DATABASE_PATH", str(BACKEND_DIR / "swing_signals.db"))
    if not os.path.isabs(DATABASE_PATH):
        DATABASE_PATH = str(BACKEND_DIR / DATABASE_PATH)

    PORT: int = int(os.environ.get("PORT", "8000"))

    ALPACA_DATA_BASE_URL = "https://data.alpaca.markets"
    ALPACA_TRADING_BASE_URL = (
        "https://api.alpaca.markets" if ALPACA_ENV == "live" else "https://paper-api.alpaca.markets"
    )

    @classmethod
    def has_alpaca_credentials(cls) -> bool:
        return bool(cls.ALPACA_API_KEY and cls.ALPACA_SECRET_KEY)


# The 15-company universe. This list is intentionally hard-coded per the project spec:
# "Track exactly these 15 companies ... Do not add additional stocks unless I specifically request them."
STOCK_UNIVERSE = [
    {"ticker": "NVDA", "name": "NVIDIA Corporation", "sector": "Technology", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "AVGO", "name": "Broadcom Inc.", "sector": "Technology", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "MU", "name": "Micron Technology, Inc.", "sector": "Technology", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "AMD", "name": "Advanced Micro Devices, Inc.", "sector": "Technology", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "AAPL", "name": "Apple Inc.", "sector": "Technology", "industry": "Consumer Electronics", "exchange": "NASDAQ"},
    {"ticker": "MSFT", "name": "Microsoft Corporation", "sector": "Technology", "industry": "Software", "exchange": "NASDAQ"},
    {"ticker": "GOOGL", "name": "Alphabet Inc. Class A", "sector": "Communication Services", "industry": "Internet", "exchange": "NASDAQ"},
    {"ticker": "AMZN", "name": "Amazon.com, Inc.", "sector": "Consumer Discretionary", "industry": "E-Commerce", "exchange": "NASDAQ"},
    {"ticker": "META", "name": "Meta Platforms, Inc.", "sector": "Communication Services", "industry": "Internet", "exchange": "NASDAQ"},
    {"ticker": "TSLA", "name": "Tesla, Inc.", "sector": "Consumer Discretionary", "industry": "Automobiles", "exchange": "NASDAQ"},
    {"ticker": "PLTR", "name": "Palantir Technologies Inc.", "sector": "Technology", "industry": "Software", "exchange": "NASDAQ"},
    {"ticker": "LLY", "name": "Eli Lilly and Company", "sector": "Healthcare", "industry": "Pharmaceuticals", "exchange": "NYSE"},
    {"ticker": "JPM", "name": "JPMorgan Chase & Co.", "sector": "Financials", "industry": "Banking", "exchange": "NYSE"},
    {"ticker": "BRK.B", "name": "Berkshire Hathaway Inc. Class B", "sector": "Financials", "industry": "Diversified Holdings", "exchange": "NYSE"},
    {"ticker": "COST", "name": "Costco Wholesale Corporation", "sector": "Consumer Staples", "industry": "Retail", "exchange": "NASDAQ"},
]

# Alpaca's REST symbology and TradingView's widget symbology diverge for dual-class share
# tickers (Alpaca: "BRK.B" with a dot; TradingView: "BRK.B" with a dot too, but some vendors
# use "BRK-B" with a hyphen) — kept as an explicit map here rather than a string transform so
# any future divergence is a one-line fix, not a hunt through the codebase.
TRADINGVIEW_SYMBOL_OVERRIDES = {
    "BRK.B": "BRK.B",
}

# Market-regime reference symbols (Phase 2, defined here now since the DB schema references them)
REGIME_SYMBOLS = ["SPY", "QQQ", "VIX", "SMH", "SOXX", "XLK", "XLF", "XLV", "XLY", "XLP"]
