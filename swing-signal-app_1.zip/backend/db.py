"""
Thin SQLite data-access layer (stdlib sqlite3 — no ORM dependency required).

Design notes:
- One connection per request (Flask g-scoped), row_factory=sqlite3.Row so callers
  can access columns by name.
- init_db() applies schema.sql and is idempotent (CREATE TABLE IF NOT EXISTS everywhere).
- seed_stocks() upserts the fixed 15-stock universe from config.STOCK_UNIVERSE.
"""
import sqlite3
from pathlib import Path

from flask import g

from config import Config, STOCK_UNIVERSE

SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(Config.DATABASE_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables if they don't exist, and seed the fixed stock universe."""
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    try:
        with open(SCHEMA_PATH, "r") as f:
            conn.executescript(f.read())
        conn.commit()
        _seed_stocks(conn)
        _seed_strategy_version(conn)
    finally:
        conn.close()


def _seed_stocks(conn: sqlite3.Connection):
    for s in STOCK_UNIVERSE:
        conn.execute(
            """
            INSERT INTO stocks (ticker, name, sector, industry, exchange)
            VALUES (:ticker, :name, :sector, :industry, :exchange)
            ON CONFLICT(ticker) DO UPDATE SET
                name = excluded.name,
                sector = excluded.sector,
                industry = excluded.industry,
                exchange = excluded.exchange
            """,
            s,
        )
    conn.commit()


def _seed_strategy_version(conn: sqlite3.Connection):
    """Register strategy v1.0 so later phases have a version to attach signals to."""
    import json

    weights = {
        "long_term_trend": 20, "short_term_trend": 10, "momentum": 15,
        "rsi_pullback": 10, "volume": 10, "support_resistance": 10,
        "relative_strength": 10, "market_regime": 5, "news": 5, "earnings_risk": 5,
    }
    conn.execute(
        """
        INSERT INTO strategy_versions (version, description, weights_json, params_json)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(version) DO NOTHING
        """,
        (
            "v1.0",
            "Initial 100-point long-only swing signal engine per project spec.",
            json.dumps(weights),
            json.dumps({}),
        ),
    )
    conn.commit()


def init_app(app):
    app.teardown_appcontext(close_db)
