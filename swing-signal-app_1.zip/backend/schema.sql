-- LONG-ONLY SWING TRADING SIGNAL SYSTEM
-- Relational schema (SQLite). Phase 1 populates/uses: stocks, quotes, market_bars (partial),
-- strategy_versions, alerts (schema only). Remaining tables are created now so later phases
-- (2-9) don't require migrations, but stay empty until their phase is implemented.

PRAGMA foreign_keys = ON;

-- Static reference: the fixed 15-stock universe.
CREATE TABLE IF NOT EXISTS stocks (
    ticker      TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    sector      TEXT,
    industry    TEXT,
    exchange    TEXT,
    active      INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- OHLCV bars across timeframes (daily, 4h, 1h, 30m, 15m). Populated in Phase 2.
CREATE TABLE IF NOT EXISTS market_bars (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT NOT NULL REFERENCES stocks(ticker),
    timeframe   TEXT NOT NULL,          -- '1Day','4Hour','1Hour','30Min','15Min'
    ts          TEXT NOT NULL,          -- bar timestamp, ISO 8601 UTC
    open        REAL NOT NULL,
    high        REAL NOT NULL,
    low         REAL NOT NULL,
    close       REAL NOT NULL,
    volume      REAL NOT NULL,
    trade_count INTEGER,
    vwap        REAL,
    source      TEXT NOT NULL DEFAULT 'alpaca',
    fetched_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(ticker, timeframe, ts)
);
CREATE INDEX IF NOT EXISTS idx_market_bars_ticker_tf_ts ON market_bars(ticker, timeframe, ts);

-- Latest trade/quote snapshots — one row per ticker, overwritten on each refresh, so the
-- dashboard always reflects the most recent poll. Historical snapshots aren't needed; signal
-- history (Phase 6) is what stores time-series of decisions.
CREATE TABLE IF NOT EXISTS quotes (
    ticker          TEXT PRIMARY KEY REFERENCES stocks(ticker),
    last_trade_px   REAL,
    last_trade_ts   TEXT,
    bid_px          REAL,
    bid_size        REAL,
    ask_px          REAL,
    ask_size        REAL,
    quote_ts        TEXT,
    daily_open      REAL,
    daily_high      REAL,
    daily_low       REAL,
    daily_close     REAL,
    daily_volume    REAL,
    prev_close      REAL,
    data_source     TEXT NOT NULL DEFAULT 'alpaca',
    data_status     TEXT NOT NULL,      -- LIVE / DELAYED / MARKET_CLOSED / STALE / UNAVAILABLE
    fetched_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Computed technical indicators per ticker/timeframe/timestamp. Populated in Phase 2.
CREATE TABLE IF NOT EXISTS technical_indicators (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT NOT NULL REFERENCES stocks(ticker),
    timeframe   TEXT NOT NULL,
    ts          TEXT NOT NULL,
    ema20 REAL, ema50 REAL, sma20 REAL, sma50 REAL, sma100 REAL, sma200 REAL,
    rsi14 REAL, rsi7 REAL,
    macd REAL, macd_signal REAL, macd_hist REAL,
    adx REAL, roc REAL, stoch_rsi REAL,
    atr14 REAL, atr_pct REAL,
    bb_upper REAL, bb_middle REAL, bb_lower REAL, bb_width REAL,
    hist_volatility REAL,
    volume REAL, avg_volume_20d REAL, relative_volume REAL,
    swing_high REAL, swing_low REAL,
    high_20d REAL, low_20d REAL, high_50d REAL, low_50d REAL,
    high_52w REAL, low_52w REAL,
    computed_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(ticker, timeframe, ts)
);

-- Current live signal per ticker (one row each, overwritten). Populated in Phase 3.
CREATE TABLE IF NOT EXISTS signals (
    ticker              TEXT PRIMARY KEY REFERENCES stocks(ticker),
    score_total         INTEGER,
    score_long_trend    INTEGER,
    score_short_trend   INTEGER,
    score_momentum      INTEGER,
    score_rsi_pullback  INTEGER,
    score_volume        INTEGER,
    score_support_resistance INTEGER,
    score_relative_strength  INTEGER,
    score_market_regime INTEGER,
    score_news          INTEGER,
    score_earnings_risk INTEGER,
    signal_label        TEXT,          -- STRONG BUY / BUY / BUY ZONE-WATCH / WATCH / NO TRADE / AVOID
    strategy_setup      TEXT,          -- PULLBACK / BREAKOUT / DEEP_CORRECTION / NONE
    current_price       REAL,
    ideal_buy           REAL,
    buy_zone_low        REAL,
    buy_zone_high       REAL,
    max_entry           REAL,
    target1             REAL,
    primary_target      REAL,
    target3             REAL,
    expected_upside_pct REAL,
    long_term_quality   INTEGER,
    long_term_thesis    TEXT,          -- STRONG / HEALTHY / WATCH / DETERIORATING / BROKEN
    market_regime       TEXT,
    earnings_blackout   INTEGER NOT NULL DEFAULT 0,
    explanation         TEXT,
    strategy_version     TEXT,
    computed_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Append-only signal history — never overwritten. Populated in Phase 6.
CREATE TABLE IF NOT EXISTS signal_history (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker              TEXT NOT NULL REFERENCES stocks(ticker),
    ts                  TEXT NOT NULL DEFAULT (datetime('now')),
    score_total         INTEGER,
    signal_label        TEXT,
    current_price       REAL,
    ideal_buy           REAL,
    buy_zone_low        REAL,
    buy_zone_high       REAL,
    max_entry           REAL,
    target1             REAL,
    primary_target       REAL,
    target3              REAL,
    market_regime        TEXT,
    long_term_quality    INTEGER,
    long_term_thesis     TEXT,
    strategy_version     TEXT
);
CREATE INDEX IF NOT EXISTS idx_signal_history_ticker_ts ON signal_history(ticker, ts);

-- News items. Populated in Phase 4, only if a legitimate free source is wired up.
CREATE TABLE IF NOT EXISTS news (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT REFERENCES stocks(ticker),
    headline    TEXT NOT NULL,
    source      TEXT,
    url         TEXT,
    published_at TEXT,
    sentiment   TEXT,
    impact_score INTEGER,
    fetched_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Manual trade journal entries (buys and sells). Populated in Phase 5.
CREATE TABLE IF NOT EXISTS trades (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT NOT NULL REFERENCES stocks(ticker),
    side        TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
    trade_date  TEXT NOT NULL,
    quantity    REAL NOT NULL,
    price       REAL NOT NULL,
    fees        REAL NOT NULL DEFAULT 0,
    notes       TEXT,
    linked_signal_id INTEGER REFERENCES signal_history(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Derived current holdings (could also be computed on the fly from trades; stored for speed
-- in later phases once partial-sale lot accounting is implemented).
CREATE TABLE IF NOT EXISTS portfolio_positions (
    ticker          TEXT PRIMARY KEY REFERENCES stocks(ticker),
    quantity        REAL NOT NULL DEFAULT 0,
    avg_entry_price REAL,
    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Fundamental data snapshots, sourced from a FundamentalDataProvider (Phase 4). Never fabricated.
CREATE TABLE IF NOT EXISTS fundamentals (
    ticker              TEXT PRIMARY KEY REFERENCES stocks(ticker),
    revenue_growth_pct  REAL,
    eps_growth_pct      REAL,
    free_cash_flow      REAL,
    fcf_margin_pct      REAL,
    gross_margin_pct    REAL,
    operating_margin_pct REAL,
    roic_pct            REAL,
    total_debt          REAL,
    total_cash          REAL,
    long_term_quality_score INTEGER,
    source              TEXT,
    as_of               TEXT,
    fetched_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Market regime snapshots (SPY/QQQ/VIX + sector ETFs). Populated in Phase 2.
CREATE TABLE IF NOT EXISTS market_regime (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          TEXT NOT NULL DEFAULT (datetime('now')),
    spy_price REAL, spy_chg_pct REAL,
    qqq_price REAL, qqq_chg_pct REAL,
    vix_price REAL,
    regime      TEXT,       -- STRONG BULL / BULL / NEUTRAL / CAUTIOUS / BEAR
    detail_json TEXT        -- sector ETF readings etc, stored as JSON text
);

-- Strategy version registry — every signal row stores which version produced it.
CREATE TABLE IF NOT EXISTS strategy_versions (
    version         TEXT PRIMARY KEY,     -- e.g. 'v1.0'
    description     TEXT,
    weights_json    TEXT,                 -- 100-point scoring weights, JSON text
    params_json     TEXT,                 -- indicator parameters, JSON text
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Alerts (informational only — never trigger trades). Populated in Phase 8.
CREATE TABLE IF NOT EXISTS alerts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker      TEXT REFERENCES stocks(ticker),
    alert_type  TEXT NOT NULL,   -- ENTER_BUY_ZONE / BUY_SIGNAL / TARGET1_REACHED / ... / DATA_FEED_FAILURE
    message     TEXT NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    acknowledged INTEGER NOT NULL DEFAULT 0
);
