# Swing Signal — Long-Only Swing Trading Signal System

**Phase 1 of 9.** A personal market-analysis / signal-generation / portfolio-journal dashboard
for a fixed 15-stock universe. This application does not and will never place, modify, or
cancel trades. No shorting. No leverage. No options. No stop losses. No automated buying or
selling. You execute every trade manually in a separate brokerage app — this is the analysis
layer only.

## What Phase 1 delivers

- **Application shell** — dark, professional trading-dashboard UI with the full 8-tab
  navigation (Dashboard, Stocks, Portfolio, Signals, Trades, Performance, Backtest, Settings).
  Only Dashboard and Stocks/[ticker] are functional; the rest are clearly labeled "coming in
  Phase N" placeholders rather than fake/empty pages.
- **Relational database** (SQLite) with the full schema described in the project spec —
  `stocks`, `market_bars`, `quotes`, `technical_indicators`, `signals`, `signal_history`,
  `news`, `trades`, `portfolio_positions`, `fundamentals`, `market_regime`,
  `strategy_versions`, `alerts`. Only `stocks`, `quotes`, and `strategy_versions` are populated
  in Phase 1; the rest are ready for Phases 2–8 with no migration needed later.
- **The fixed 15-stock universe**, seeded automatically on first run.
- **MarketDataProvider abstraction** — the app never talks to Alpaca directly outside of
  `providers/alpaca_provider.py`. Swapping vendors later means writing one new class.
- **AlpacaProvider** — calls Alpaca's official documented REST endpoints (`/v2/clock`,
  `/v2/stocks/{symbol}/snapshot`, `/v2/stocks/snapshots`, `/v2/stocks/{symbol}/bars`) directly
  over HTTPS with `requests`. Credentials live only in `backend/.env`, read only by
  `config.py`, and are never sent to the frontend.
- **Honest data-status labeling** — every price on screen is tagged `LIVE`, `DELAYED`,
  `MARKET_CLOSED`, `STALE`, or `UNAVAILABLE`, never silently presented as something it isn't.
  If Alpaca is unreachable or credentials are missing, the app says so explicitly instead of
  freezing on old numbers or inventing data.
- **TradingView charts** on every stock detail page (official embedded widget only —
  15m/30m/1H/4H/1D/1W), used purely for visual charting. Nothing on the page reads data back
  out of the widget; all calculated figures come from Alpaca via this app's own backend.

## Stack (and why it differs slightly from the original FastAPI/React plan)

The sandbox this was built in has locked-down network egress at the org level — it cannot
reach `pypi.org`, the npm registry, or Alpaca's API domains directly, so `pip install
fastapi`/`alpaca-py` and `npm install` weren't possible *inside that sandbox*, and a live
Alpaca call couldn't be tested from there either. Rather than hand you FastAPI/React code that
had never actually been run, the stack was adapted to what's provable right now:

- **Backend:** Flask + Python's built-in `sqlite3` + `requests` — all runnable and testable
  without any package installs.
- **Frontend:** plain HTML/CSS/JS (Jinja2 templates + `fetch`) — no Node.js, no build step.

None of this changes the architecture (same provider abstraction, same DB schema, same API
shape) — just the framework names. On your own machine, with normal internet access,
`pip install -r requirements.txt` pulls everything and live Alpaca calls will work immediately.

## Setup

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env and paste your ALPACA_API_KEY / ALPACA_SECRET_KEY
# (free paper-trading keys from https://app.alpaca.markets are fine — Alpaca's free
#  market-data plan serves the real-time IEX feed, not simulated/paid data)

python3 scripts/check_alpaca_connection.py   # confirms your keys + network actually work
python3 app.py                               # starts the app on http://localhost:8000
```

Open `http://localhost:8000` in a browser. The dashboard polls `/api/stocks/snapshots` and
`/api/market/status` every 15 seconds.

## Running the tests

```bash
cd backend
python3 -m unittest discover -s tests -v
```

16 unit tests cover: timestamp parsing (including Alpaca's nanosecond-precision timestamps),
missing-credentials handling, market-session classification (regular/pre-market/after-hours/
closed/weekend), snapshot parsing against Alpaca's real documented response schema, LIVE vs
MARKET_CLOSED vs STALE vs UNAVAILABLE classification, and HTTP error handling (401, network
failure, partial batch responses). These use mocked HTTP responses shaped exactly like
Alpaca's real API — they don't depend on network access, which is what let them run and pass
inside the sandbox where this was built.

**What was and wasn't tested where this was built:** every Flask route, the database schema,
seeding, HTML rendering of all 8 nav pages (verified visually via Playwright screenshots), and
the full data-unavailable/error-handling path were tested live in-sandbox. The one thing that
*couldn't* be tested there was an actual successful Alpaca API call, purely because that
sandbox's network policy blocks `alpaca.markets` and `tradingview.com` outbound — the app
correctly detected this and displayed `DATA STATUS: UNAVAILABLE` with a clear error message
rather than failing silently or faking data, which is itself a real (and correct) test of that
code path. Run `scripts/check_alpaca_connection.py` on your machine to confirm the live path.

## Project layout

```
backend/
  app.py                    Flask app factory + routes
  config.py                 env-var config, the 15-stock universe, TradingView symbol map
  db.py / schema.sql        SQLite data-access layer + full relational schema
  providers/
    base.py                 MarketDataProvider abstract interface (vendor-agnostic)
    alpaca_provider.py       AlpacaProvider implementation
  services/market_service.py  provider singleton + short-TTL cache, used by routes
  routers/
    api_stocks.py            /api/stocks, /api/stocks/snapshots, /api/stocks/<t>/snapshot, /bars
    api_market.py             /api/market/status
  scripts/check_alpaca_connection.py   standalone live connectivity check
  tests/test_alpaca_provider.py        16 unit tests (mocked HTTP)
frontend/
  templates/                 Jinja2 pages (dashboard, stocks, stock_detail, coming_soon, ...)
  static/css/style.css       dark trading-dashboard theme
  static/js/                 api.js (fetch helpers), topbar.js, dashboard.js, stock_detail.js
```

## Roadmap (Phases 2–9, not yet built)

2. Historical bars ingestion, technical indicators (EMA/SMA/RSI/MACD/ADX/ATR/Bollinger),
   support/resistance zones, market regime (SPY/QQQ/VIX + sector ETFs), relative strength.
3. 100-point signal engine, ideal buy price/zone/max entry, sell targets, ranking, "why this
   score?" transparency.
4. Fundamentals (via a separate FundamentalDataProvider, only real data, never fabricated),
   news, earnings/earnings-blackout, long-term quality score.
5. Manual portfolio & trade journal, partial sales, P/L, GBP conversion.
6. Signal history (append-only) & performance tracking, trade analytics.
7. Backtesting engine with strict look-ahead-bias prevention and walk-forward
   in-sample/validation/out-of-sample splits.
8. Alerts (informational only — never trigger trades).
9. AI-generated plain-English signal explanations, built strictly from the engine's own
   calculated numbers.

## Security notes

- `ALPACA_API_KEY` / `ALPACA_SECRET_KEY` are read only in `config.py` from `backend/.env` and
  never appear in any frontend file, any API response, or any log statement.
- `.gitignore` excludes `backend/.env` and the SQLite database file.
- The app makes zero outbound calls to any trade-execution endpoint. There is no order,
  cancel-order, or modify-order code anywhere in this codebase.
