// Yearly page: average traded price per calendar year, plus today's price.
//
// This endpoint is NOT polled. On a cache that does not already hold five full years it
// triggers one deep provider fetch per ticker, which takes minutes; a timer would stack those
// calls on top of each other. It loads once, with an explicit Refresh button.

let latestPrices = {};   // ticker -> live price from the snapshots endpoint
let yearlyData = null;
// ticker -> { year -> monthly-contribution row }. Merged in from a second endpoint rather than
// shown on its own page: the two answer different questions about the same year, and reading
// them side by side is the only way to see that a stock whose average price rose 40% returned
// half that to somebody actually paying in month by month.
let monthlyByTicker = {};
let monthlySummary = {};   // ticker -> { avg_year_pct, avg_year_pct_basis }
let monthlyTotals = [];

function cellPrice(v) {
  return v === null || v === undefined ? `<span class="text-dim">&mdash;</span>` : fmtPrice(v);
}

/**
 * One year's cell: the average price, with that year's step underneath.
 *
 * Both readings of "show me the years" are covered in one cell — the average price you asked
 * for, and the percentage move that produced it — so neither has to be inferred by comparing
 * columns by eye.
 */
function yearCell(stat, step, monthly) {
  if (!stat || stat.avg_price === null || stat.avg_price === undefined) {
    return `<td class="text-right"><span class="pill pill-unavailable"><span class="dot bad"></span>UNAVAILABLE</span></td>`;
  }
  const stepHtml = step && step.pct !== null && step.pct !== undefined
    ? `<div class="yc-sub ${pctClass(step.pct)}">${fmtPct(step.pct, 1)}</div>`
    : `<div class="yc-sub text-dim">&mdash;</div>`;

  // High and low of the year, from intraday extremes. The range percentage is the point of it
  // for a swing trader: it is how much the price actually swung within the year, which the
  // average on its own says nothing about.
  const hasRange = stat.high !== null && stat.high !== undefined
                   && stat.low !== null && stat.low !== undefined;
  const rangeTitle = hasRange
    ? `High ${fmtPrice(stat.high)} on ${stat.high_date}, low ${fmtPrice(stat.low)} on ${stat.low_date}`
    : "";
  const rangeHtml = hasRange
    ? `<div class="yc-range" title="${rangeTitle}">
         <span class="yc-hi">H ${fmtPrice(stat.high)}</span>
         <span class="yc-lo">L ${fmtPrice(stat.low)}</span>
         ${stat.range_pct !== null && stat.range_pct !== undefined
            ? `<span class="yc-rangepct">${fmtNum(stat.range_pct, 0)}% range</span>` : ""}
       </div>`
    : "";
  // A partial year's average is a real number over a shorter window, so it is shown rather than
  // hidden — but it is not comparable to a full year, and an unmarked one reads as a genuine
  // fall in the average price.
  const flag = stat.partial
    ? `<span class="yc-flag" title="${stat.reason || "incomplete year"}: ${stat.first_date} to ${stat.last_date}">partial</span>`
    : stat.year_in_progress
      ? `<span class="yc-flag" title="Year to date, ${stat.first_date} to ${stat.last_date}">YTD</span>`
      : "";
  return `<td class="text-right">${fmtPrice(stat.avg_price)}${flag}${stepHtml}${rangeHtml}${monthlyHtml(monthly)}</td>`;
}

/**
 * The monthly-contribution return for the same year, shown inside the same cell.
 *
 * Deliberately labelled every time rather than left as a bare number: it is a return on money
 * invested, not a price change, and the two sit one line apart. Somebody scanning the column
 * quickly must not be able to mistake one for the other.
 */
function monthlyHtml(m) {
  if (!m || m.return_pct === null || m.return_pct === undefined) {
    return `<div class="yc-monthly text-dim">monthly &mdash;</div>`;
  }
  const part = m.partial ? ` <span class="yc-flag">${m.months}m</span>` : "";
  return `<div class="yc-monthly">
            <span class="text-dim">monthly</span>
            <span class="${pctClass(m.return_pct)}">${fmtPct(m.return_pct, 1)}</span>${part}
          </div>`;
}

function renderTable(data, rowsIn, headId, bodyId, firstColLabel) {
  const years = data.years_shown || [];
  const head = document.getElementById(headId);
  head.innerHTML = [
    `<th>${firstColLabel}</th>`,
    ...years.map((y) => `<th class="text-right">${y}${y === data.current_year ? " <span class='yc-flag'>YTD</span>" : ""}</th>`),
    `<th class="text-right">Current Price</th>`,
    `<th class="text-right">Avg Year %<div class="yc-sub text-dim">by price</div></th>`,
    `<th class="text-right">Avg Year %<div class="yc-sub text-dim">buying monthly</div></th>`,
  ].join("");

  const colCount = years.length + 4;
  const rows = (rowsIn || []).slice().sort(
    (a, b) => (b.avg_year_pct ?? -9999) - (a.avg_year_pct ?? -9999));

  const tbody = document.getElementById(bodyId);
  if (!rows.length) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="${colCount}">No data.</td></tr>`;
    return;
  }

  tbody.innerHTML = rows.map((r) => {
    const byYear = {};
    (r.years || []).forEach((s) => { byYear[s.year] = s; });
    const stepTo = {};
    (r.yoy_pct || []).forEach((s) => { stepTo[s.to] = s; });

    // Live prices are keyed by the symbol Alpaca actually quotes, which for an ETF row is the
    // proxy, not the UCITS ticker shown in the first column.
    const priceKey = r.priced_via || r.ticker;
    const live = latestPrices[priceKey];
    const current = live !== undefined && live !== null ? live : r.latest_close;
    const currentIsLive = live !== undefined && live !== null;

    const nameCell = r.is_etf
      ? `<td>
           <span class="ticker-badge">${r.ticker}</span>
           <div class="company-name">${r.name || ""}${r.listing ? " &middot; " + r.listing : ""}</div>
           <div class="yc-proxy" title="${(r.proxy_note || "").replace(/"/g, "&quot;")}">
             priced via <strong>${r.priced_via}</strong>
             <span class="yc-match ${r.match === "EXACT" ? "yc-match-exact" : "yc-match-approx"}">${
               r.match === "EXACT" ? "same index" : "approximate"}</span>
           </div>
         </td>`
      : `<td><span class="ticker-badge">${r.ticker}</span></td>`;

    const click = r.is_etf ? "" : ` onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'"`;
    const mSummary = monthlySummary[r.priced_via || r.ticker] || {};
    const mAvg = mSummary.avg_year_pct;
    const mBasis = mSummary.avg_year_pct_basis;

    return `<tr${click}>
      ${nameCell}
      ${years.map((y) => yearCell(byYear[y], stepTo[y], (monthlyByTicker[r.priced_via || r.ticker] || {})[y])).join("")}
      <td class="text-right">${cellPrice(current)}${
        currentIsLive ? "" : `<div class="yc-sub text-dim">last close${r.latest_close_date ? " " + r.latest_close_date : ""}</div>`}</td>
      <td class="text-right ${pctClass(r.avg_year_pct)}" style="font-weight:600;">${
        r.avg_year_pct === null || r.avg_year_pct === undefined
          ? `<span class="text-dim">&mdash;</span>`
          : fmtPct(r.avg_year_pct, 1)}</td>
      <td class="text-right ${pctClass(mAvg)}" style="font-weight:600;">${
        mAvg === null || mAvg === undefined
          ? `<span class="text-dim">&mdash;</span>`
          : fmtPct(mAvg, 1)}${
        mBasis ? `<div class="yc-sub text-dim">${mBasis} full year${mBasis === 1 ? "" : "s"}</div>` : ""}</td>
    </tr>`;
  }).join("");
}

function renderYearlyTable(data) {
  renderTable(data, data.results, "yearly-head", "yearly-tbody", "Stock");
  renderTable(data, data.etfs, "etf-head", "etf-tbody", "ETF");
  document.getElementById("yearly-basis").textContent =
    `${data.basis} The last column averages each company's year-on-year steps; the current year is ` +
    `still in progress, so its step compares a full year against a part year.`;
}

function renderMonthlyTotals() {
  const tbody = document.getElementById("yearly-totals");
  if (!tbody) return;
  tbody.innerHTML = monthlyTotals.length
    ? monthlyTotals.map((t) => `<tr>
        <td>${t.year}${t.partial ? ` <span class="yc-flag">partial</span>` : ""}</td>
        <td class="text-right">${t.stocks || 0}</td>
        <td class="text-right">${t.invested === null || t.invested === undefined ? "&mdash;"
          : Number(t.invested).toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
        <td class="text-right">${t.value === null || t.value === undefined ? "&mdash;"
          : Number(t.value).toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
        <td class="text-right ${pctClass(t.return_pct)}" style="font-weight:600;">${
          t.return_pct === null || t.return_pct === undefined ? "&mdash;" : fmtPct(t.return_pct, 1)}</td>
      </tr>`).join("")
    : `<tr class="loading-row"><td colspan="5">Monthly-contribution figures unavailable.</td></tr>`;
}

function renderAll() {
  if (!yearlyData) return;
  renderYearlyTable(yearlyData);
  renderMonthlyTotals();
}

async function loadYearly() {
  const msg = document.getElementById("yearly-message");
  const btn = document.getElementById("yearly-refresh");
  btn.disabled = true;
  msg.innerHTML = `<div class="warn-banner">Loading daily history for every tracked stock, on two bases &mdash; average traded price, and what buying monthly would have returned. If this is the first time, the history has to be fetched from Alpaca and this can take a couple of minutes.</div>`;

  // Live prices are a separate, cheap call. If it fails the table still renders using each
  // stock's last close, clearly labelled as such rather than passed off as a current price.
  try {
    const snap = await apiGet("/api/stocks/snapshots");
    const next = {};
    (snap.results || []).forEach((r) => {
      const p = r.last_price !== undefined && r.last_price !== null ? r.last_price : r.last_known_price;
      if (p !== undefined && p !== null) next[r.ticker] = p;
    });
    latestPrices = next;
  } catch (e) {
    console.warn("Live prices unavailable, falling back to last close:", e.message);
  }

  // Monthly-contribution figures, merged into the same table. Fetched separately and treated as
  // optional on purpose: it reads the SAME cached bars the yearly call just warmed, so it is
  // cheap, and if it fails the price table still renders in full rather than the page dying for
  // want of a secondary column.
  try {
    const m = await apiGet("/api/stocks/monthly-buying");
    const index = {}, summary = {};
    [...(m.results || []), ...(m.etfs || [])].forEach((row) => {
      const key = row.priced_via || row.ticker;
      const byYear = {};
      (row.years || []).forEach((y) => { byYear[y.year] = y; });
      index[key] = byYear;
      summary[key] = { avg_year_pct: row.avg_year_pct,
                       avg_year_pct_basis: row.avg_year_pct_basis };
    });
    monthlyByTicker = index;
    monthlySummary = summary;
    monthlyTotals = m.totals || [];
  } catch (e) {
    console.warn("Monthly-contribution figures unavailable:", e.message);
  }

  try {
    const data = await apiGet("/api/stocks/yearly");
    if (data.error) {
      msg.innerHTML = `<div class="error-banner">${data.error}</div>`;
      btn.disabled = false;
      return;
    }
    yearlyData = data;
    msg.innerHTML = "";
    renderAll();
  } catch (e) {
    msg.innerHTML = `<div class="error-banner">Could not load yearly prices: ${e.message}</div>`;
    document.getElementById("yearly-tbody").innerHTML =
      `<tr class="loading-row"><td colspan="9">No data.</td></tr>`;
  } finally {
    btn.disabled = false;
  }
}

document.getElementById("yearly-refresh").addEventListener("click", loadYearly);
loadYearly();
