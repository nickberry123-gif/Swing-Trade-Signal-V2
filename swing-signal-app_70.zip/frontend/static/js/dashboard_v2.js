(function () {
  const $ = (id) => document.getElementById(id);
  /* A missing verdict shows its REASON on hover, so "no historical average" is never read as
     "fairly valued". The two are different statements and the page must not blur them. */
  function valuationCell(v) {
    const colour = { CHEAP: '#2e7d32', EXPENSIVE: '#c62828', FAIR: '' }[v.status] || '';
    /* An implausible multiple must never appear as a green CHEAP. It is shown, loudly, with the
       inputs that produced it — a P/E of 1.24 on this app's own screen is what this prevents. */
    if (v.status === 'CHECK THIS') {
      return `<td style="color:#b26a00;font-weight:600" title="${M.esc(v.reason || '')}">` +
             `CHECK THIS <span style="font-size:10px;">&#9432;</span></td>`;
    }
    if (v.status === 'NOT APPLICABLE') {
      return `<td class="text-dim" title="${M.esc(v.reason || '')}">N/A</td>`;
    }
    if (v.status === 'MISSING DATA' || !v.status) {
      return `<td class="text-dim" title="${M.esc(v.reason || '')}">MISSING</td>`;
    }
    return `<td style="${colour ? 'color:' + colour + ';font-weight:600' : ''}">${M.esc(v.status)}</td>`;
  }

  /* A company's P/E is only as current as the annual report behind it. Showing the bare multiple
     would invite it to be compared with a website's trailing-twelve-month figure, which is a
     different calculation on newer earnings. The provenance travels with the number. */
  function peCell(v) {
    if (v.pe === null || v.pe === undefined) {
      return `<td class="text-dim" title="${M.esc(v.reason || v.hist_reason || '')}">&mdash;</td>`;
    }
    const bits = [];
    if (v.eps !== null && v.eps !== undefined) bits.push(`EPS ${v.eps} (${v.eps_basis || ''})`);
    if (v.eps_fiscal_year) bits.push(`fiscal year ${v.eps_fiscal_year}, period ending ${v.eps_period_end}`);
    if (v.eps_filed) bits.push(`filed ${v.eps_filed}`);
    if (v.eps_age_days !== null && v.eps_age_days !== undefined) {
      bits.push(`earnings are ${v.eps_age_days} days old at the price date`);
    }
    if (v.price_used) bits.push(`price ${v.price_used} on ${v.price_date} (${v.price_basis || ''})`);
    if (v.basis) bits.push(v.basis);
    const stale = (v.eps_age_days || 0) > 450;   /* a year late means a year of missing filings */
    return `<td class="mono${stale ? ' text-dim' : ''}" title="${M.esc(bits.join(' · '))}">` +
           `${M.num(v.pe, 1)}${bits.length ? ' <span style="font-size:10px;">&#9432;</span>' : ''}</td>`;
  }

  function histPeCell(v) {
    if (v.hist_avg_pe === null || v.hist_avg_pe === undefined) {
      return `<td class="text-dim" title="${M.esc(v.hist_reason || v.reason || '')}">&mdash;</td>`;
    }
    const w = v.hist_window ? `${v.hist_window[0]} to ${v.hist_window[1]}` : '';
    const t = [`mean of ${v.hist_months_used} month-end observations`, w,
               v.hist_months_loss_making
                 ? `${v.hist_months_loss_making} loss-making months excluded` : '']
      .filter(Boolean).join(' · ');
    return `<td class="mono" title="${M.esc(t)}">${M.num(v.hist_avg_pe, 1)}` +
           `${t ? ' <span style="font-size:10px;">&#9432;</span>' : ''}</td>`;
  }

  function render(data) {
    const rows = data.results || [];
    const withData = rows.filter((r) => r.months > 0);
    $('m-summary').innerHTML = `
      <div><strong>${withData.length}</strong> of <strong>${rows.length}</strong> securities have
        price history · as of ${M.esc(data.as_of)}</div>
      <div class="text-dim" style="margin-top:6px">${M.esc(data.note)}</div>`;
    const order = { 'SYNTHETIC INDEX': 0, STOCK: 1, ETF: 2 };
    rows.sort((a, b) => (order[a.type] - order[b.type]) || a.ticker.localeCompare(b.ticker));
    $('m-tbody').innerHTML = rows.map((r) => `<tr>
        <td><strong>${M.esc(r.ticker)}</strong></td>
        <td>${M.esc(r.name)}</td>
        ${M.typeBadge(r.type)}
        <td>${M.esc(r.currency)}</td>
        ${M.cell(M.num(r.current_price))}
        ${M.signed(r.cagr)}
        ${M.signed(r.dca_annualised)}
        ${M.cell(M.num(r.high_52w))}
        ${M.cell(M.num(r.low_52w))}
        ${M.cell(M.pct(r.range_position, 0))}
        ${M.signed(r.drawdown_from_high)}
        ${M.signed(r.vs_ma12)}
        ${M.cell(r.trend)}
        ${peCell(r.valuation || {})}
        ${histPeCell(r.valuation || {})}
        ${M.signed((r.valuation || {}).pe_vs_avg)}
        ${valuationCell(r.valuation || {})}
        ${M.cell(M.pct(r.ter, 2))}
        ${M.cell(M.pct(r.yield, 2))}
        ${M.cell(M.pct(r.top10, 1))}
        ${M.cell(r.months == null ? null : String(r.months))}
        <td class="text-dim" style="max-width:260px">${M.esc(r.data_status)}</td>
      </tr>`).join('');
  }
  async function refresh() {
    const b = $('m-refresh'); b.disabled = true; b.textContent = 'Fetching…';
    try {
      const res = await fetch('/api/monthly/refresh', { method: 'POST' });
      const body = await res.json();
      /* SHOW EVERY REASON. "0 of 7" once hid seven identical 401s from an expired Alpaca key and
         took a log dig to diagnose. A count without a cause is not a status. */
      const failed = (body.results || []).filter((r) => r.status !== 'OK');
      $('m-message').innerHTML = `<div class="card card-pad">
        Fetched ${body.ok} of ${body.requested} stocks.
        ${failed.length ? '<br><strong>Failures:</strong><br>' + failed.map((r) =>
          `${M.esc(r.ticker)}: ${M.esc(r.error || r.status)}`).join('<br>') : ''}
        <br><span class="text-dim">${M.esc(body.note)}</span></div>`;
      M.load(render);
    } catch (e) {
      $('m-message').innerHTML = `<div class="card card-pad">Fetch failed: ${M.esc(e.message)}</div>`;
    } finally { b.disabled = false; b.textContent = 'Fetch Stock Price History'; }
  }
  document.addEventListener('DOMContentLoaded', () => {
    $('m-reload').addEventListener('click', () => M.load(render));
    $('m-refresh').addEventListener('click', refresh);
    M.load(render);
  });
})();
