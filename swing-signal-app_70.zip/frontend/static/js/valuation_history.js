/* Valuation History — rendering only. Every number arrives computed from the server; nothing is
   derived, rounded into a different meaning, or re-ordered into a ranking here.

   The one rule this file enforces on itself: a figure is never shown without its sample size.
   Section 3's whole honesty rests on the reader seeing that a median came from four observations
   rather than four hundred, so `n` is rendered in its own column and is never dropped for space. */
(function () {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s === null || s === undefined ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  const dash = '<span class="text-dim">&mdash;</span>';
  const num = (v, dp) => (v === null || v === undefined) ? dash : Number(v).toFixed(dp);
  const pct = (v, dp) => (v === null || v === undefined) ? dash
    : `<span class="${v > 0 ? "pos" : v < 0 ? "neg" : ""}">${(v * 100).toFixed(dp)}%</span>`;

  const ARM_LABELS = {
    every_month: "Bought every month, regardless",
    only_cheap: "Bought only when CHEAP",
    cheap_or_fair: "Bought when CHEAP or FAIR",
    skip_expensive: "Bought unless EXPENSIVE",
  };
  const VERDICTS = ["CHEAP", "FAIR", "EXPENSIVE"];
  const VERDICT_COLOUR = { CHEAP: "#2e7d32", EXPENSIVE: "#c62828", FAIR: "" };

  function renderLimits(l) {
    if (!l) return;
    /* Printed, not summarised. This is the part that must survive being read six months from now
       by somebody who has forgotten the conversation that produced the page. */
    $("vh-limits").innerHTML = `
      <strong>Read this before the numbers.</strong> ${esc(l.statement)}
      <br><br>
      <span class="mono">${esc(l.months_of_price_history)}</span> months of price history &middot;
      <span class="mono">${esc(l.months_consumed_building_the_first_average)}</span> consumed
      building the first average &middot;
      <span class="mono">${esc(l.months_carrying_a_verdict)}</span> months carry a verdict &middot;
      <span class="mono">${esc(l.decisions_usable_at_the_longest_horizon)}</span> usable at 12
      months &middot; only
      <span class="mono">${esc(l.non_overlapping_windows)}</span> non-overlapping windows.
      <br><br>
      <span class="text-dim">${esc(l.why_history_starts_in_2020)}</span>`;
  }

  function renderCensus(rows) {
    $("vh-census").innerHTML = rows.map((r) => {
      const c = r.census || {};
      const counts = c.counts || {};
      return `<tr>
        <td><strong>${esc(r.ticker)}</strong></td>
        <td>${esc(r.name)}</td>
        <td class="text-right mono">${esc(c.months_total)}</td>
        <td class="text-right mono">${esc(c.months_with_a_verdict)}</td>
        <td class="text-right mono text-dim">${esc(c.months_without)}</td>
        <td class="text-right mono" style="color:${VERDICT_COLOUR.CHEAP}">${esc(counts.CHEAP)}</td>
        <td class="text-right mono">${esc(counts.FAIR)}</td>
        <td class="text-right mono" style="color:${VERDICT_COLOUR.EXPENSIVE}">${esc(counts.EXPENSIVE)}</td>
        <td class="mono">${c.first_verdict_month ? esc(c.first_verdict_month) : dash}</td>
      </tr>`;
    }).join("");
  }

  function renderWaiting(rows) {
    $("vh-waiting").innerHTML = rows.map((r) => {
      const w = r.waiting || {};
      /* "Never cheap" is the single most useful thing this page can say, so it is stated in
         words rather than left as a zero the eye slides over. */
      const ever = w.never_cheap === null || w.never_cheap === undefined ? dash
        : w.never_cheap
          ? `<strong style="color:#b26a00">Never went cheap</strong>`
          : `<span style="color:${VERDICT_COLOUR.CHEAP}">Yes, ${esc(w.cheap_months)}&times;</span>`;
      return `<tr>
        <td><strong>${esc(r.ticker)}</strong></td>
        <td class="text-right mono">${esc(w.months_eligible)}</td>
        <td class="text-right mono">${esc(w.cheap_months)}</td>
        <td class="text-right mono">${esc(w.months_waiting)}</td>
        <td class="text-right mono">${w.longest_wait_months === null ? dash : esc(w.longest_wait_months)}</td>
        <td class="text-right mono">${esc(w.still_waiting_months)}</td>
        <td>${ever}</td>
      </tr>`;
    }).join("");
  }

  function renderForward(rows) {
    const out = [];
    rows.forEach((r) => {
      const fwd = r.forward_returns || {};
      Object.keys(fwd).forEach((horizon) => {
        VERDICTS.forEach((v) => {
          const b = fwd[horizon][v] || {};
          /* A bucket with nothing in it is shown as an empty bucket, not hidden. A verdict that
             never occurred is a finding; a row silently missing from a table is not. */
          const thin = b.n > 0 && b.n < 10;
          out.push(`<tr${b.n ? "" : ' class="text-dim"'}>
            <td><strong>${esc(r.ticker)}</strong></td>
            <td class="mono">${esc(horizon)}</td>
            <td style="color:${VERDICT_COLOUR[v]};font-weight:600">${esc(v)}</td>
            <td class="text-right mono"${thin ? ' style="color:#b26a00;font-weight:600" title="too few observations to read anything into"' : ""}>${esc(b.n)}</td>
            <td class="text-right mono">${pct(b.median, 1)}</td>
            <td class="text-right mono">${pct(b.min, 1)}</td>
            <td class="text-right mono">${pct(b.max, 1)}</td>
            <td class="text-right mono">${b.positive_share === null || b.positive_share === undefined ? dash : (b.positive_share * 100).toFixed(0) + "%"}</td>
          </tr>`);
        });
      });
    });
    $("vh-forward").innerHTML = out.join("");
  }

  function renderArms(rows) {
    const out = [];
    rows.forEach((r) => {
      const arms = (r.purchases || {}).arms || {};
      Object.keys(ARM_LABELS).forEach((k) => {
        const a = arms[k];
        if (!a) return;
        out.push(`<tr>
          <td><strong>${esc(r.ticker)}</strong></td>
          <td>${esc(ARM_LABELS[k])}</td>
          <td class="text-right mono">${esc(a.months_bought)}</td>
          <td class="text-right mono">${esc(a.months_in_cash)}</td>
          <td class="text-right mono">${num(a.total_contributed, 0)}</td>
          <td class="text-right mono">${num(a.final_value, 2)}</td>
          <td class="text-right mono">${pct(a.total_return, 1)}</td>
        </tr>`);
      });
    });
    $("vh-arms").innerHTML = out.join("");
  }

  function renderExcluded(items) {
    $("vh-excluded").innerHTML = (items || []).length
      ? (items || []).map((e) =>
        `<div style="margin-bottom:6px"><strong>${esc(e.ticker)}</strong> &mdash;
          ${esc(e.name)}<br><span class="text-dim">${esc(e.reason)}</span></div>`).join("")
      : "Nothing excluded.";
  }

  async function load() {
    const b = $("vh-reload");
    if (b) { b.disabled = true; b.textContent = "Loading…"; }
    try {
      const res = await fetch("/api/valuation-history/universe");
      if (!res.ok) throw new Error(`server returned ${res.status}`);
      const data = await res.json();
      const rows = data.results || [];
      renderLimits(data.limits);
      renderCensus(rows);
      renderWaiting(rows);
      renderForward(rows);
      renderArms(rows);
      renderExcluded(data.excluded);
      $("vh-message").innerHTML = "";
    } catch (e) {
      /* The failure is shown rather than left as a permanent "Loading…", which is
         indistinguishable from a slow server and cost a long diagnosis once already. */
      $("vh-message").innerHTML =
        `<div class="card card-pad">Could not load the study: ${esc(e.message)}</div>`;
    } finally {
      if (b) { b.disabled = false; b.textContent = "Reload"; }
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    const b = $("vh-reload");
    if (b) b.addEventListener("click", load);
    load();
  });
})();
