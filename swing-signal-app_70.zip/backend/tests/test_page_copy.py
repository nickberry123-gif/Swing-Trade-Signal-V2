"""
PAGE COPY AND LAYOUT — statements that describe features which no longer exist.

Every assertion here corresponds to something that was on screen and wrong. Copy rots more quietly
than code: removing a section removes the feature but leaves the paragraph explaining it, and the
paragraph is what a reader believes. Three separate stale claims survived the last two builds —
a tagline for a signal system with no signals, a subtitle pointing at deleted tabs, and a note
explaining a volatility proxy for a strip that had been taken off the page.

The layout test is here for the same reason: the gap on the dashboard was an orphaned closing
</div> and an empty paragraph left behind when the sector strip was removed, not a styling problem.
"""
import re
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app as app_module

_FRONTEND = Path(__file__).resolve().parent.parent.parent / "frontend"
TEMPLATES = _FRONTEND / "templates"
JS = _FRONTEND / "static" / "js"
CSS = _FRONTEND / "static" / "css"

# The pages a menu actually reaches. Hidden pages are not audited for copy: they are out of sight
# by decision, and holding them to the same standard would block a build over a paragraph nobody
# can read.
VISIBLE = ("/", "/yearly", "/monthly")


class NoStaleClaims(unittest.TestCase):

    def setUp(self):
        self.client = app_module.create_app().test_client()
        self.pages = {p: self.client.get(p).data.decode("utf-8", "replace") for p in VISIBLE}

    def test_every_visible_page_loads(self):
        for p in VISIBLE:
            self.assertEqual(self.client.get(p).status_code, 200, p)

    def test_no_page_still_explains_the_vix_proxy(self):
        """The volatility proxy note outlived the strip it described by two builds."""
        for p, html in self.pages.items():
            self.assertNotIn("CBOE VIX", html, f"{p} still explains the VIX proxy")
            self.assertNotIn("VIXY", html, f"{p} still mentions VIXY")

    def test_no_page_points_at_the_signals_tab(self):
        """It is hidden. Sending a reader to a tab that is not in the menu is worse than silence."""
        for p, html in self.pages.items():
            self.assertNotIn("Signals tab", html, p)
            self.assertNotIn("the test pages", html, p)

    def test_no_page_claims_a_ranked_signal(self):
        """Nothing on any visible page ranks or scores a stock any more."""
        for p, html in self.pages.items():
            self.assertNotIn("ranked signal", html, p)
            self.assertNotIn("buy/sell levels", html, p)

    def test_the_tagline_no_longer_describes_a_trading_signal_system(self):
        html = self.pages["/"]
        self.assertNotIn("long-only", html)
        self.assertNotIn("no shorting", html)

    def test_the_hard_constraints_still_appear_somewhere_on_every_page(self):
        """Rewriting the tagline must not quietly delete the promises it carried. They moved to
        the footer; this proves they moved rather than vanished."""
        for p, html in self.pages.items():
            self.assertIn("never shorts", html, p)
            self.assertIn("never calculates a stop loss", html, p)
            self.assertIn("never buys or sells automatically", html, p)

    def test_no_page_claims_every_figure_comes_from_alpaca(self):
        """Held funds come from the workbook and fundamentals from SEC EDGAR."""
        for p, html in self.pages.items():
            self.assertNotIn("All figures are generated from Alpaca", html, p)

    def test_the_sources_actually_used_are_all_named(self):
        html = self.pages["/"]
        for source in ("Alpaca Markets", "workbook", "SEC EDGAR"):
            self.assertIn(source, html)

    def test_the_monthly_page_no_longer_says_the_universe_is_eleven(self):
        """Sixteen rows are rendered. A count in prose is the easiest thing to leave behind."""
        self.assertNotIn("Eleven securities", self.pages["/monthly"])

    def test_the_monthly_page_no_longer_claims_companies_have_no_earnings_data(self):
        """It was true when written. It stopped being true when Build B started storing filings,
        and the sentence stayed for three builds after that."""
        html = self.pages["/monthly"]
        self.assertNotIn("no earnings data is stored", html)

    def test_the_monthly_page_warns_that_its_pe_is_not_the_website_figure(self):
        """An annual-EPS multiple against a trailing-twelve-month one is a real difference and
        will be noticed. Saying so first is the difference between a caveat and a discrepancy."""
        html = self.pages["/monthly"]
        self.assertIn("not a trailing twelve months", html)

    def test_the_yearly_page_no_longer_calls_every_etf_row_a_proxy(self):
        """Four of the eight rows are the US funds themselves, priced directly."""
        html = self.pages["/yearly"]
        self.assertNotIn("These are <strong>proxies</strong>", html)
        self.assertIn("QQQ", html)


class DashboardLayout(unittest.TestCase):
    """The gap. Removing the sector section left the markup around it behind."""

    def setUp(self):
        self.client = app_module.create_app().test_client()
        self.html = self.client.get("/").data.decode("utf-8", "replace")
        self.src = (TEMPLATES / "dashboard.html").read_text()

    def test_the_dead_regime_error_paragraph_is_gone(self):
        """Nothing writes to it — the only function that did returns early when the sector strip
        is absent — but it still occupied a paragraph's worth of vertical space."""
        self.assertNotIn('id="regime-error"', self.html)

    def test_the_divs_in_the_dashboard_template_balance(self):
        """The orphaned </div> closed <main> early, which is what actually moved the page around.
        Counting tags is crude but it is exactly the defect that occurred."""
        opens = len(re.findall(r"<div\b", self.src))
        closes = len(re.findall(r"</div>", self.src))
        self.assertEqual(opens, closes,
                         f"dashboard.html has {opens} <div> and {closes} </div>")

    def test_the_whole_rendered_page_balances_too(self):
        opens = len(re.findall(r"<div\b", self.html))
        closes = len(re.findall(r"</div>", self.html))
        self.assertEqual(opens, closes)

    def test_every_empty_paragraph_is_one_that_javascript_actually_fills(self):
        """An empty <p> is only legitimate if something writes to it.

        The first version of this test banned empty paragraphs outright and failed on
        `#mag6-note`, which is a real placeholder that mag6.js populates. Banning the shape was
        wrong; what matters is whether anything reaches the element. An empty paragraph no code
        mentions is dead markup taking up a line — which is exactly what `#regime-error` was.
        """
        js = "\n".join(p.read_text() for p in JS.glob("*.js"))
        for tag in re.findall(r"<p[^>]*>\s*</p>", self.html):
            ident = re.search(r'id="([^"]+)"', tag)
            self.assertIsNotNone(ident, f"empty paragraph with no id: {tag}")
            self.assertIn(ident.group(1), js,
                          f"nothing writes to #{ident.group(1)} — dead markup taking up space")

    def test_empty_paragraphs_are_collapsed_by_the_stylesheet(self):
        """Belt and braces for the placeholders that ARE legitimate: until their data arrives
        they should occupy no height at all."""
        self.assertIn("p:empty", (CSS / "style.css").read_text())

    def test_no_id_appears_twice_on_any_visible_page(self):
        """Moving the filings button under a different heading nearly left two elements sharing
        `funds-message`. getElementById returns the first, so the second silently never updates —
        a defect that looks like 'the button does nothing' and reads as a server problem."""
        for p in VISIBLE:
            page = self.client.get(p).data.decode("utf-8", "replace")
            # Comments are not markup. The note explaining the id collision quoted the id, and
            # scanning raw HTML made the explanation itself look like a second occurrence.
            page = re.sub(r"<!--.*?-->", "", page, flags=re.S)
            ids = re.findall(r'id="([^"]+)"', page)
            dupes = sorted({i for i in ids if ids.count(i) > 1})
            self.assertEqual(dupes, [], f"{p} has duplicate ids: {dupes}")

    def test_the_filings_button_is_beside_the_column_it_fills(self):
        """It used to sit under the Funds heading, where the thing it fetches does not exist.
        A fund has no filings; a company's Health and P/E both come from them."""
        # Anchor on the SECTION HEADING, not the first occurrence of the words: "Magnificent 7"
        # also appears in the page title, and splitting on that put the whole page in the tail.
        stocks = self.html.split("<h2>Magnificent 7")[1].split("<h2>Funds")[0]
        self.assertIn("Fetch Company Filings", stocks)
        funds = self.html.split("<h2>Funds")[1]
        self.assertNotIn("Fetch Company Filings", funds)

    def test_the_button_and_its_message_target_are_both_present(self):
        js = (JS / "funds.js").read_text()
        html = self.html
        for ident in re.findall(r'\$\("([a-z-]+)"\)', js):
            self.assertIn(f'id="{ident}"', html,
                          f"funds.js writes to #{ident}, which is not on the page")

    def test_the_sections_that_should_be_there_still_are(self):
        """The counterweight: proving something is gone is only half of it."""
        for heading in ("Market Status", "Magnificent 7", "Funds", "MAG 6"):
            self.assertIn(heading, self.html)


if __name__ == "__main__":
    unittest.main()
