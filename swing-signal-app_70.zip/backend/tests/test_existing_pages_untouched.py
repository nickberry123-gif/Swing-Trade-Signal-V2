"""
A LOCK ON THE PAGES THAT ARE ALREADY WORKING.

This file exists because of a specific incident. A build that was asked only to change a list of
tickers also rewrote the Dashboard and the Yearly page, and the loss of data was noticed by the
person using the app rather than by any test. Everything was restored, but nothing structural
stopped it happening again — the pages were protected by intention, and intention is not a
control.

So the working pages are pinned by content hash. Any edit to any file below fails the suite
immediately and by name. That is the whole point: the failure is not an accusation, it is a
question. If the change was deliberate, the hash is updated in the same commit and the reason is
written next to it. If it was not, the test just caught a page being rewritten by accident.

WHAT IS DELIBERATELY NOT PINNED. `app.py` is not here, because the nav list lives in it and new
pages have to be able to appear. `base.html` is not here for the same reason — the header is
shared, so a fourth tab necessarily touches every page's chrome. Those two are the sanctioned
route for additive change; everything else is closed.

This is not a substitute for the behavioural tests. A file can be byte-identical and still be
wrong. It answers a narrower question — "did this build touch something it was not asked to
touch" — which is the question nobody thought to ask last time.
"""
import hashlib
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

ROOT = Path(__file__).resolve().parent.parent.parent

# Captured at the start of the valuation-history build, from the deployed and verified state of
# BUILD_ID 2026-08-28-stock-pe-and-copy-audit.
PINNED = {
    "frontend/templates/dashboard.html":
        "3affaeaf07ce9bb30e4a2287019851ec0ed0f4724860b93d83df26e7718dc311",
    "frontend/templates/yearly.html":
        "451e52d1f6300405c9b500ace64dc65c0168fe559d46d700941791b29286b93a",
    "frontend/templates/monthly.html":
        "cecc44d7dc127d7c5d0cb764cb6fbf63da5e89cbbba9c64c300eea6576af3e84",
    "frontend/static/js/dashboard.js":
        "479a1aee3be9c4c093a74e20db682bc990733587981f9d3e962fcd8e591e75e3",
    "frontend/static/js/funds.js":
        "922ecabcdcdd90e969e78a4af0bb26c6f23a22036473aaa71b1fc8538a454039",
    "frontend/static/js/mag6.js":
        "569755caddef01caed0f08e062848d9ef1fc8f19196ba8e4eb0e7df4a30fd2fd",
    "frontend/static/js/yearly.js":
        "368c57ec15aae49eb83f0de461ab8ed38485cbfad34a8c26a0557fd86a25aad2",
    "frontend/static/js/dashboard_v2.js":
        "cd646c7a7e3c9a3db8fe3e796617afd76dce863b5fd18efd95a0f28b53931578",
    "frontend/static/js/yearly_v2.js":
        "0066424b413ff62ddc48eab018e057e560bbdaa5336823b13f95c53773b2e37f",
    "frontend/static/js/monthly_common.js":
        "25a67068fa701e1d4e91b45a41048efc564b0199d8155f681c382c128fa292e3",
    "backend/routers/api_monthly.py":
        "36d751bf4d93fb521ff3008276e4e390833a1429eb66a80374bf4687da7ef8f1",
    "backend/routers/api_funds.py":
        "7acbb555da82b54e76287ffa7d0a6f79c468807b4b87cfc544724c7d061eab0f",
    "backend/routers/api_health_news.py":
        "63cfc31698bc7c0aa5a131e7db323f8a3ab573bed44eac740f96d4df54c670de",
    "backend/services/monthly_engine.py":
        "e037e57be86b55fe53eacc9df6406b68a80c3e7ce0da05df61aac81db8abd532",
    "backend/services/stock_pe_service.py":
        "ddda32f1125e187b3ef7731d2af389e1a2660da5ff44b8db33536dcea6f70e14",
}


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class WorkingPagesAreLocked(unittest.TestCase):

    def test_no_pinned_file_has_changed(self):
        changed = []
        for rel, expected in sorted(PINNED.items()):
            path = ROOT / rel
            self.assertTrue(path.exists(), f"{rel} has been DELETED")
            if _sha(path) != expected:
                changed.append(rel)
        self.assertEqual(changed, [], (
            "These already-working files were modified:\n  " + "\n  ".join(changed) +
            "\n\nIf that was deliberate, update the hash in this file and say why. "
            "If it was not, the build has touched something it was not asked to."))

    def test_the_pin_list_itself_is_not_quietly_emptied(self):
        """Deleting entries would make this test pass while protecting nothing — the easiest way
        to 'fix' a failure here is to remove the file that failed, so the count is asserted."""
        self.assertGreaterEqual(len(PINNED), 15)

    def test_every_pinned_path_actually_exists(self):
        for rel in PINNED:
            self.assertTrue((ROOT / rel).exists(), rel)


if __name__ == "__main__":
    unittest.main()
