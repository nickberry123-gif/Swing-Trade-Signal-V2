"""
Valuation history — the ways a descriptive study quietly becomes a fabricated edge.

The headline risk in this module is not an arithmetic error. It is that the expanding window
leaks: one off-by-one in `expanding_verdicts` and every verdict is computed against an average
that already contains the months it is about to be measured against, which would make the whole
study look far more decisive than it is. Several tests below exist for that single line.

The second risk is the study growing a verdict. It was commissioned explicitly as a description,
because the sample cannot support inference, and "no significance test" is asserted rather than
assumed — a p-value appearing here later would be that decision reversed silently.
"""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app as app_module
from db import get_db
from services import valuation_history_service as vh

TICKER = "NVDA"


def _executable_source(module) -> str:
    """The module's CODE, with every docstring and string literal blanked out.

    Contract tests below forbid certain words. Scanning the raw file makes the module's own
    explanation of what it does NOT do read as evidence that it does it — "computes no
    significance test" contains "significan", and "filings whose filed date had already passed"
    contains "passed". A test that cannot tell a promise from a breach of it is worse than none.
    """
    import ast
    tree = ast.parse(Path(module.__file__).read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            node.value = ""
    return ast.unparse(tree).lower()


def _bars(start, months, raw_fn, adj_fn=None):
    """Daily rows spanning `months` calendar months, in the shape value_raw_bars returns."""
    out, d = [], date.fromisoformat(start)
    for _ in range(months * 31):
        iso = d.isoformat()
        out.append({"ts": iso, "close_raw": raw_fn(iso),
                    "close_adj": (adj_fn or raw_fn)(iso)})
        d += timedelta(days=1)
    return out


class Base(unittest.TestCase):

    def setUp(self):
        self.app = app_module.create_app()
        self.ctx = self.app.app_context()
        self.ctx.push()
        self.db = get_db()
        self.db.execute("DELETE FROM fundamentals_history WHERE ticker = ?", (TICKER,))
        self.db.commit()

    def tearDown(self):
        self.db.execute("DELETE FROM fundamentals_history WHERE ticker = ?", (TICKER,))
        self.db.commit()
        self.ctx.pop()

    def _file(self, period_end, filed, eps, currency="USD"):
        self.db.execute(
            """INSERT INTO fundamentals_history
               (ticker, period_end, filed, fiscal_year, form, taxonomy, currency, eps_diluted)
               VALUES (?, ?, ?, ?, '10-K', 'us-gaap', ?, ?)
               ON CONFLICT(ticker, period_end, filed) DO UPDATE SET
                   eps_diluted = excluded.eps_diluted""",
            (TICKER, period_end, filed, int(period_end[:4]), currency, eps))
        self.db.commit()


class TestNoLookAhead(Base):
    """The line the whole study rests on."""

    def test_appending_later_months_cannot_change_an_earlier_verdict(self):
        """The property statement. If this fails, every result in the study is contaminated."""
        self._file("2019-12-31", "2020-02-01", 4.0)
        short = _bars("2020-07-01", 50, lambda d: 100.0 if d < "2024-01-01" else 400.0)
        long = _bars("2020-07-01", 74, lambda d: 100.0 if d < "2024-01-01" else 400.0)
        a = vh.expanding_verdicts(self.db, TICKER, short)
        b = vh.expanding_verdicts(self.db, TICKER, long)
        self.assertEqual([r["verdict"] for r in a], [r["verdict"] for r in b[:len(a)]])
        self.assertEqual([r["avg_pe_so_far"] for r in a],
                         [r["avg_pe_so_far"] for r in b[:len(a)]])

    def test_a_month_is_never_part_of_the_average_it_is_judged_against(self):
        """The off-by-one. Appending this month's multiple before averaging would let a month help
        set the benchmark it is then measured against, which flatters every verdict."""
        self._file("2019-12-31", "2020-02-01", 4.0)
        rows = vh.expanding_verdicts(self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0))
        for i, r in enumerate(rows):
            if r["avg_pe_so_far"] is not None:
                self.assertEqual(r["months_in_average"], i,
                                 "the average at month i must be built from exactly i months")

    def test_no_verdict_exists_before_the_minimum_history(self):
        self._file("2019-12-31", "2020-02-01", 4.0)
        rows = vh.expanding_verdicts(self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0))
        for r in rows[:vh.MIN_MONTHS_FOR_HISTORY]:
            self.assertEqual(r["verdict"], vh.NO_VERDICT)

    def test_a_filing_published_later_cannot_reach_an_earlier_month(self):
        self._file("2019-12-31", "2020-02-01", 4.0)
        bars = _bars("2020-07-01", 74, lambda d: 100.0)
        before = vh.expanding_verdicts(self.db, TICKER, bars)
        self._file("2019-12-31", "2026-06-01", 1.0)          # restated at the very end
        after = vh.expanding_verdicts(self.db, TICKER, bars)
        early = [i for i, r in enumerate(after) if r["date"] < "2026-06-01"]
        for i in early:
            self.assertEqual(before[i]["pe"], after[i]["pe"])

    def test_the_purchase_is_the_month_after_the_verdict(self):
        """Buying at the close that produced the verdict is buying on that close's own
        information. Asserted against the source so it cannot be quietly relaxed."""
        src = Path(vh.__file__).read_text()
        self.assertIn("entry_i, exit_i = i + 1, i + 1 + h", src)
        self.assertIn("rows[i + 1][\"price_adj\"]", src)

    def test_a_verdict_in_the_final_months_yields_no_forward_return(self):
        """There is no future to measure. Those months must drop out rather than be measured over
        a shorter window and pooled with the rest."""
        self._file("2019-12-31", "2020-02-01", 4.0)
        rows = vh.expanding_verdicts(self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0))
        fwd = vh.forward_returns_by_verdict(rows, horizons=(12,))
        scored = sum(1 for r in rows if r["verdict"] != vh.NO_VERDICT)
        self.assertLessEqual(sum(b["n"] for b in fwd["12m"].values()), scored - 12)


class TestVerdicts(Base):

    def test_a_flat_price_and_flat_eps_is_always_fair(self):
        """Nothing moved, so nothing can be cheap or expensive. A study that finds signal in a
        flat series is measuring its own machinery."""
        self._file("2019-12-31", "2020-02-01", 4.0)
        rows = vh.expanding_verdicts(self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0))
        scored = [r for r in rows if r["verdict"] != vh.NO_VERDICT]
        self.assertTrue(scored)
        self.assertTrue(all(r["verdict"] == vh.FAIR for r in scored))

    def test_a_large_fall_against_a_settled_average_reads_cheap(self):
        self._file("2019-12-31", "2020-02-01", 4.0)
        rows = vh.expanding_verdicts(
            self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0 if d < "2025-06-01" else 50.0))
        self.assertEqual(rows[-1]["verdict"], vh.CHEAP)

    def test_a_large_rise_against_a_settled_average_reads_expensive(self):
        self._file("2019-12-31", "2020-02-01", 4.0)
        rows = vh.expanding_verdicts(
            self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0 if d < "2025-06-01" else 200.0))
        self.assertEqual(rows[-1]["verdict"], vh.EXPENSIVE)

    def test_a_loss_making_month_carries_no_verdict_rather_than_a_cheap_one(self):
        self._file("2019-12-31", "2020-02-01", -4.0)
        rows = vh.expanding_verdicts(self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0))
        self.assertTrue(all(r["verdict"] == vh.NO_VERDICT for r in rows))

    def test_the_bands_are_the_ones_already_in_use_and_are_not_redefined_here(self):
        """A second set of thresholds living in the study would let the study be tuned without
        the live page changing, which is the quietest possible form of optimisation."""
        from services import monthly_engine as me
        src = Path(vh.__file__).read_text()
        self.assertIn("me.CHEAP_THRESHOLD", src)
        self.assertIn("me.EXPENSIVE_THRESHOLD", src)
        self.assertEqual((me.CHEAP_THRESHOLD, me.EXPENSIVE_THRESHOLD), (-0.15, 0.20))


class TestCensusAndWaiting(Base):

    def _flat(self):
        self._file("2019-12-31", "2020-02-01", 4.0)
        return vh.expanding_verdicts(self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0))

    def test_the_census_accounts_for_every_month(self):
        rows = self._flat()
        c = vh.verdict_census(rows)
        self.assertEqual(c["months_with_a_verdict"] + c["months_without"], c["months_total"])
        self.assertEqual(sum(c["counts"].values()), c["months_with_a_verdict"])

    def test_never_going_cheap_is_reported_as_a_fact_not_a_blank(self):
        """If CHEAP never occurred then 'wait for cheap' was never an available strategy, and that
        is the single most useful thing this study can say."""
        w = vh.waiting_cost(self._flat())
        self.assertTrue(w["never_cheap"])
        self.assertEqual(w["cheap_months"], 0)

    def test_the_longest_wait_counts_a_run_that_never_ends(self):
        w = vh.waiting_cost(self._flat())
        self.assertEqual(w["longest_wait_months"], w["months_eligible"])
        self.assertEqual(w["still_waiting_months"], w["months_eligible"])

    def test_no_verdict_months_are_excluded_from_the_wait(self):
        """Months before any verdict existed were not a wait — there was nothing to wait for."""
        rows = self._flat()
        w = vh.waiting_cost(rows)
        self.assertEqual(w["months_eligible"],
                         sum(1 for r in rows if r["verdict"] != vh.NO_VERDICT))

    def test_an_empty_study_says_so_rather_than_dividing_by_zero(self):
        for fn in (vh.waiting_cost, vh.purchase_histories):
            self.assertIn("reason", fn([]))


class TestPurchaseHistories(Base):

    def _rising(self):
        self._file("2019-12-31", "2020-02-01", 4.0)
        bars = _bars("2020-07-01", 74, lambda d: 100.0 + 2.0 * int(d[:4]) - 4000.0)
        return vh.expanding_verdicts(self.db, TICKER, bars)

    def test_skipped_money_sits_in_cash_and_is_counted(self):
        """The arithmetic that decides whether this comparison is honest. If declined months were
        redeployed later, every arm would be fully invested and the difference would not be
        timing at all."""
        rows = self._rising()
        arms = vh.purchase_histories(rows)["arms"]
        for name, a in arms.items():
            self.assertEqual(a["months_bought"] + a["months_in_cash"], a["months_contributed"])
            self.assertEqual(a["cash_never_invested"], float(a["months_in_cash"]))

    def test_every_arm_contributes_the_same_money(self):
        """Otherwise the arms are not comparable — a strategy could 'win' by investing more."""
        arms = vh.purchase_histories(self._rising())["arms"]
        totals = {a["total_contributed"] for a in arms.values()}
        self.assertEqual(len(totals), 1)

    def test_buying_every_month_buys_every_eligible_month(self):
        arms = vh.purchase_histories(self._rising())["arms"]
        self.assertEqual(arms["every_month"]["months_in_cash"], 0)

    def test_an_arm_that_never_buys_returns_exactly_its_money(self):
        """A strategy that sits in cash the whole time must return 0%, not a loss and not a gain.
        Any other answer means cash is being valued at a price."""
        rows = self._rising()
        arms = vh.purchase_histories(rows)["arms"]
        if arms["only_cheap"]["months_bought"] == 0:
            self.assertEqual(arms["only_cheap"]["total_return"], 0.0)

    def test_the_four_arms_are_the_agreed_four(self):
        arms = vh.purchase_histories(self._rising())["arms"]
        self.assertEqual(set(arms), {"every_month", "only_cheap", "cheap_or_fair",
                                     "skip_expensive"})


class TestRefusesToConclude(Base):
    """Commissioned as a description. These assert it stays one."""

    def test_no_significance_test_is_computed_anywhere(self):
        src = _executable_source(vh)
        for forbidden in ("p_value", "pvalue", "p-value", "ttest", "t_test", "spearman",
                          "pearson", "significan", "confidence_interval"):
            self.assertNotIn(forbidden, src, f"this study must not compute {forbidden}")

    def test_no_pass_fail_verdict_is_produced(self):
        src = _executable_source(vh)
        for forbidden in ("passed", "failed", "pass_threshold", "recommend", "best_arm",
                          "winner"):
            self.assertNotIn(forbidden, src)

    def test_every_distribution_carries_its_own_sample_size(self):
        """A median of two must never be presentable as a median of fifty."""
        self._file("2019-12-31", "2020-02-01", 4.0)
        rows = vh.expanding_verdicts(self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0))
        for horizon in vh.forward_returns_by_verdict(rows).values():
            for bucket in horizon.values():
                self.assertIn("n", bucket)

    def test_the_limits_block_is_computed_from_the_data_not_asserted(self):
        self._file("2019-12-31", "2020-02-01", 4.0)
        rows = vh.expanding_verdicts(self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0))
        c = vh.cannot_conclude(rows)
        self.assertEqual(c["months_of_price_history"], len(rows))
        self.assertEqual(c["months_carrying_a_verdict"],
                         sum(1 for r in rows if r["verdict"] != vh.NO_VERDICT))
        self.assertIn("cannot support a rule", c["statement"])

    def test_the_horizons_stop_where_the_data_stops(self):
        """Three and five years would yield two observations and zero. They are absent by
        decision, not by oversight."""
        self.assertEqual(vh.FORWARD_HORIZONS, (3, 6, 12))
        self.assertNotIn(36, vh.FORWARD_HORIZONS)
        self.assertNotIn(60, vh.FORWARD_HORIZONS)


class TestPriceBases(Base):

    def test_the_verdict_uses_raw_and_the_return_uses_adjusted(self):
        """The two bases must not be swapped. With a 10:1 split the raw and adjusted series differ
        tenfold, so a swap would be silent and enormous."""
        self._file("2019-12-31", "2020-02-01", 4.0)
        bars = _bars("2020-07-01", 74, lambda d: 100.0, adj_fn=lambda d: 10.0)
        rows = vh.expanding_verdicts(self.db, TICKER, bars)
        self.assertTrue(all(r["price_raw"] == 100.0 for r in rows))
        self.assertTrue(all(r["price_adj"] == 10.0 for r in rows))
        self.assertEqual(rows[-1]["pe"], 25.0)          # 100 / 4, not 10 / 4

    def test_both_bases_are_named_on_the_result(self):
        self._file("2019-12-31", "2020-02-01", 4.0)
        out = vh.study_for(self.db, TICKER, _bars("2020-07-01", 74, lambda d: 100.0))
        self.assertIn("raw", out["verdict_basis"])
        self.assertIn("adjusted", out["return_basis"])

    def test_a_month_missing_from_either_basis_is_not_used(self):
        """Pairing a verdict from one date with a return from another puts a silent offset into
        every observation."""
        self._file("2019-12-31", "2020-02-01", 4.0)
        raw = _bars("2020-07-01", 74, lambda d: 100.0)
        adj = [b for b in raw if b["ts"][:7] != "2023-05"]
        rows = vh.expanding_verdicts(self.db, TICKER, raw, adj)
        self.assertNotIn("2023-05", [r["date"][:7] for r in rows])


if __name__ == "__main__":
    unittest.main()


class TestPageAndApi(Base):
    """The page exists, loads, prints its limits, and adds nothing to the pages already working."""

    def setUp(self):
        super().setUp()
        self.client = self.app.test_client()

    def test_the_page_renders(self):
        self.assertEqual(self.client.get("/valuation-history").status_code, 200)

    def test_the_page_is_in_the_menu(self):
        """Unlike Value and Entry, this one IS listed — it makes no claim to predict anything, so
        a menu entry is not an implicit recommendation."""
        self.assertIn(b'href="/valuation-history"', self.client.get("/").data)

    def test_the_limits_are_printed_on_the_page_not_only_in_the_api(self):
        """A caveat that lives only in a conversation is gone by the time anybody acts on the
        number. The container must be there for the JS to fill."""
        import re
        raw = self.client.get("/valuation-history").data.decode()
        self.assertIn('id="vh-limits"', raw)
        # Strip the markup before searching. The sentence is emphasised as "<strong>not</strong> a
        # rule", so a search of the raw bytes looks for text that is never contiguous in the file.
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", raw))
        self.assertIn("not a rule", text)
        self.assertIn("description of the past", text)

    def test_the_page_warns_that_the_period_went_mostly_up(self):
        html = self.client.get("/valuation-history").data
        self.assertIn(b"six years that went mostly up", html)

    def test_the_universe_endpoint_returns_the_agreed_shape(self):
        body = self.client.get("/api/valuation-history/universe").get_json()
        for key in ("as_of", "securities", "results", "excluded", "limits", "bands"):
            self.assertIn(key, body)

    def test_the_held_london_funds_are_excluded_with_a_stated_reason(self):
        """Blank cells would read as 'valuation unknown'. The truth is that the question does not
        apply to them, which is a different statement."""
        body = self.client.get("/api/valuation-history/universe").get_json()
        excluded = {e["ticker"] for e in body["excluded"]}
        self.assertEqual(excluded, {"VHYL", "CNX1", "IITU", "SMGB"})
        for e in body["excluded"]:
            self.assertTrue(e["reason"])

    def test_an_excluded_fund_says_not_applicable_rather_than_404(self):
        body = self.client.get("/api/valuation-history/VHYL").get_json()
        self.assertEqual(body["status"], "NOT APPLICABLE")
        self.assertIn("no filings", body["reason"])

    def test_an_unknown_ticker_is_a_clean_404(self):
        self.assertEqual(self.client.get("/api/valuation-history/NOTATICKER").status_code, 404)

    def test_the_bands_reported_are_the_live_ones(self):
        from services import monthly_engine as me
        b = self.client.get("/api/valuation-history/universe").get_json()["bands"]
        self.assertEqual(b["cheap_at_or_below"], me.CHEAP_THRESHOLD)
        self.assertEqual(b["expensive_at_or_above"], me.EXPENSIVE_THRESHOLD)

    def test_no_stored_bars_gives_an_empty_study_rather_than_an_error(self):
        body = self.client.get("/api/valuation-history/universe").get_json()
        self.assertEqual(body["securities"], len(body["results"]))

    def test_this_feature_adds_nothing_to_the_pages_already_working(self):
        """The commitment made before this was built: new files only. Content hashes enforce the
        files; this enforces the rendered result."""
        for path in ("/", "/yearly", "/monthly"):
            html = self.client.get(path).data
            self.assertNotIn(b"vh-limits", html)
            self.assertNotIn(b"valuation_history.js", html)
