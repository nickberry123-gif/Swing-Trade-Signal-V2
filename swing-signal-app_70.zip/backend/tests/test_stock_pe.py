"""
Stock P/E — the ways a price/earnings ratio built from filings goes quietly wrong.

Every test here corresponds to a specific way this number could look plausible and be false: a
split-adjusted price against as-reported earnings, a restatement leaking backwards into an older
month, a loss reported as a cheap multiple, a currency mismatch dividing dollars by euros, and an
"average" taken over four observations.
"""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app as app_module
from db import get_db
from services import stock_pe_service as spe

TICKER = "NVDA"


def _bars(start, n, price_fn):
    """Daily rows in the shape value_raw_bars returns them."""
    out, d = [], date.fromisoformat(start)
    for i in range(n):
        out.append({"ts": d.isoformat(), "close_raw": price_fn(d.isoformat()),
                    "close_adj": price_fn(d.isoformat())})
        d += timedelta(days=1)
    return out


class PeBase(unittest.TestCase):

    def setUp(self):
        self.app = app_module.create_app()
        self.ctx = self.app.app_context()
        self.ctx.push()
        self.db = get_db()
        self.db.execute("DELETE FROM fundamentals_history WHERE ticker = ?", (TICKER,))
        self.db.commit()

    def tearDown(self):
        self.db.execute("DELETE FROM fundamentals_history WHERE ticker = ?", (TICKER,))
        self.db.commit()
        self.ctx.pop()

    def _file(self, period_end, filed, eps=None, net_income=None, diluted_shares=None,
              currency="USD", fiscal_year=None):
        self.db.execute(
            """INSERT INTO fundamentals_history
               (ticker, period_end, filed, fiscal_year, form, taxonomy, currency,
                eps_diluted, net_income, diluted_shares)
               VALUES (?, ?, ?, ?, '10-K', 'us-gaap', ?, ?, ?, ?)
               ON CONFLICT(ticker, period_end, filed) DO UPDATE SET
                   eps_diluted = excluded.eps_diluted""",
            (TICKER, period_end, filed, fiscal_year or int(period_end[:4]), currency,
             eps, net_income, diluted_shares))
        self.db.commit()


class TestEpsSelection(PeBase):

    def test_a_filing_published_after_the_date_is_not_visible(self):
        """The whole point of the point-in-time read. A 2024 filing cannot inform a 2022 month."""
        self._file("2021-12-31", "2022-02-01", eps=2.0)
        self._file("2023-12-31", "2024-02-01", eps=8.0)
        tl = spe.eps_timeline(self.db, TICKER)
        self.assertEqual(spe.known_at(tl, "2022-06-30")["eps"], 2.0)
        self.assertEqual(spe.known_at(tl, "2024-06-30")["eps"], 8.0)

    def test_nothing_is_visible_before_the_first_filing(self):
        self._file("2021-12-31", "2022-02-01", eps=2.0)
        self.assertIsNone(spe.known_at(spe.eps_timeline(self.db, TICKER), "2021-06-30"))

    def test_a_restatement_of_an_older_year_does_not_displace_the_newest_year(self):
        """The ordering trap. A 2025 restatement of 2022 is newer BY FILING but older BY PERIOD,
        and 'most recent annual report' means the most recent period, not the most recent
        paperwork. Getting this backwards would quote a three-year-old EPS as current."""
        self._file("2022-12-31", "2023-02-01", eps=2.0)
        self._file("2024-12-31", "2025-02-01", eps=9.0)
        self._file("2022-12-31", "2025-06-01", eps=2.5)      # restatement, filed last
        row = spe.known_at(spe.eps_timeline(self.db, TICKER), "2025-12-31")
        self.assertEqual(row["period_end"], "2024-12-31")
        self.assertEqual(row["eps"], 9.0)

    def test_the_newest_version_of_the_same_period_wins(self):
        self._file("2022-12-31", "2023-02-01", eps=2.0)
        self._file("2022-12-31", "2023-08-01", eps=2.4)
        row = spe.known_at(spe.eps_timeline(self.db, TICKER), "2024-01-01")
        self.assertEqual(row["eps"], 2.4)
        self.assertEqual(row["filed"], "2023-08-01")

    def test_eps_is_derived_only_when_it_was_not_reported_and_is_labelled(self):
        self._file("2022-12-31", "2023-02-01", net_income=1000.0, diluted_shares=250.0)
        row = spe.known_at(spe.eps_timeline(self.db, TICKER), "2024-01-01")
        self.assertEqual(row["eps"], 4.0)
        self.assertEqual(row["basis"], spe.DERIVED)

    def test_a_reported_eps_is_never_overridden_by_a_derived_one(self):
        self._file("2022-12-31", "2023-02-01", eps=3.0, net_income=1000.0, diluted_shares=250.0)
        row = spe.known_at(spe.eps_timeline(self.db, TICKER), "2024-01-01")
        self.assertEqual(row["eps"], 3.0)
        self.assertEqual(row["basis"], spe.AS_REPORTED)

    def test_a_filing_with_neither_eps_nor_both_components_is_skipped_not_zeroed(self):
        self._file("2022-12-31", "2023-02-01", net_income=1000.0)      # no share count
        self.assertEqual(spe.eps_timeline(self.db, TICKER), [])

    def test_a_zero_share_count_does_not_divide_by_zero(self):
        self._file("2022-12-31", "2023-02-01", net_income=1000.0, diluted_shares=0.0)
        self.assertEqual(spe.eps_timeline(self.db, TICKER), [])


class TestCurrentPe(PeBase):

    def test_a_known_multiple_is_computed_exactly(self):
        self._file("2024-12-31", "2025-02-01", eps=4.0)
        bars = _bars("2025-06-01", 30, lambda d: 100.0)
        out = spe.current_pe(self.db, TICKER, bars)
        self.assertEqual(out["status"], "OK")
        self.assertEqual(out["pe"], 25.0)

    def test_a_loss_is_not_applicable_and_never_a_number(self):
        """A negative P/E is not a cheap one. Printing -12 in this column would read as cheap to
        anybody scanning the table, which is the opposite of what a loss means."""
        self._file("2024-12-31", "2025-02-01", eps=-4.0)
        out = spe.current_pe(self.db, TICKER, _bars("2025-06-01", 30, lambda d: 100.0))
        self.assertEqual(out["status"], spe.NOT_APPLICABLE)
        self.assertIsNone(out["pe"])
        self.assertIn("loss", out["reason"])

    def test_zero_earnings_is_not_applicable_rather_than_infinity(self):
        self._file("2024-12-31", "2025-02-01", eps=0.0)
        out = spe.current_pe(self.db, TICKER, _bars("2025-06-01", 30, lambda d: 100.0))
        self.assertEqual(out["status"], spe.NOT_APPLICABLE)
        self.assertIsNone(out["pe"])

    def test_non_usd_earnings_are_refused_rather_than_divided_into_a_usd_price(self):
        self._file("2024-12-31", "2025-02-01", eps=4.0, currency="EUR")
        out = spe.current_pe(self.db, TICKER, _bars("2025-06-01", 30, lambda d: 100.0))
        self.assertEqual(out["status"], spe.NOT_APPLICABLE)
        self.assertIn("EUR", out["reason"])

    def test_no_filings_says_so_and_names_the_next_action(self):
        """The reason has to name the button and the page. 'Fetch fundamentals' sent someone
        looking round the app for a control that was under a heading called Funds."""
        out = spe.current_pe(self.db, TICKER, _bars("2025-06-01", 30, lambda d: 100.0))
        self.assertEqual(out["status"], spe.MISSING)
        self.assertIn("Fetch Company Filings", out["reason"])
        self.assertIn("Dashboard", out["reason"])

    def test_no_price_history_says_so(self):
        self._file("2024-12-31", "2025-02-01", eps=4.0)
        out = spe.current_pe(self.db, TICKER, [])
        self.assertEqual(out["status"], spe.MISSING)
        self.assertIn("no raw price history", out["reason"])

    def test_the_age_of_the_earnings_is_reported(self):
        self._file("2024-12-31", "2025-02-01", eps=4.0)
        out = spe.current_pe(self.db, TICKER, _bars("2025-06-01", 30, lambda d: 100.0))
        self.assertEqual(out["eps_age_days"], (date(2025, 6, 30) - date(2024, 12, 31)).days)

    def test_the_raw_close_is_used_and_the_adjusted_one_is_not(self):
        """The defect this design exists to prevent. A 10:1 split makes the adjusted price a tenth
        of the raw one; against as-reported pre-split earnings that is a P/E ten times too small."""
        self._file("2024-12-31", "2025-02-01", eps=4.0)
        bars = [{"ts": "2025-06-30", "close_raw": 100.0, "close_adj": 10.0}]
        self.assertEqual(spe.current_pe(self.db, TICKER, bars)["pe"], 25.0)


class TestHistoricalAverage(PeBase):

    def _six_years(self, eps=4.0, price=100.0):
        self._file("2019-12-31", "2020-02-01", eps=eps)
        return _bars("2020-07-27", 2200, lambda d: price)

    def test_a_flat_price_and_flat_eps_average_to_that_multiple(self):
        out = spe.historical_avg_pe(self.db, TICKER, self._six_years())
        self.assertEqual(out["hist_avg_pe"], 25.0)
        self.assertGreaterEqual(out["months_used"], spe.MIN_MONTHS_FOR_HISTORY)

    def test_too_few_months_gives_no_average_rather_than_a_thin_one(self):
        self._file("2019-12-31", "2020-02-01", eps=4.0)
        short = _bars("2024-01-01", 300, lambda d: 100.0)        # about ten months
        out = spe.historical_avg_pe(self.db, TICKER, short)
        self.assertIsNone(out["hist_avg_pe"])
        self.assertIn(str(spe.MIN_MONTHS_FOR_HISTORY), out["reason"])

    def test_loss_making_months_are_excluded_and_counted_not_averaged_in(self):
        """Averaging a negative multiple in would drag the benchmark towards zero and make every
        later month look expensive against it."""
        self._file("2019-12-31", "2020-02-01", eps=-2.0)
        self._file("2021-12-31", "2022-02-01", eps=4.0)
        out = spe.historical_avg_pe(self.db, TICKER, _bars("2020-07-27", 2200, lambda d: 100.0))
        self.assertGreater(out["months_loss_making"], 0)
        self.assertEqual(out["hist_avg_pe"], 25.0)

    def test_months_before_any_filing_are_counted_separately_not_scored(self):
        self._file("2023-12-31", "2024-02-01", eps=4.0)
        out = spe.historical_avg_pe(self.db, TICKER, _bars("2020-07-27", 2200, lambda d: 100.0))
        self.assertGreater(out["months_no_filing"], 0)

    def test_appending_later_bars_cannot_change_an_earlier_observation(self):
        """The look-ahead check stated as a property rather than an intention: the mean over the
        first N months must not move when more months are added after them."""
        self._file("2019-12-31", "2020-02-01", eps=4.0)
        early = _bars("2020-07-27", 1500, lambda d: 100.0 if d < "2024-01-01" else 300.0)
        late = _bars("2020-07-27", 2200, lambda d: 100.0 if d < "2024-01-01" else 300.0)
        a = spe.historical_avg_pe(self.db, TICKER, early)
        b = spe.historical_avg_pe(self.db, TICKER, late[:len(early)])
        self.assertEqual(a["hist_avg_pe"], b["hist_avg_pe"])

    def test_a_restatement_filed_later_does_not_change_earlier_months(self):
        self._file("2019-12-31", "2020-02-01", eps=4.0)
        bars = _bars("2020-07-27", 2200, lambda d: 100.0)
        before = spe.historical_avg_pe(self.db, TICKER, bars)["hist_avg_pe"]
        self._file("2019-12-31", "2026-01-01", eps=1.0)          # restated years afterwards
        after = spe.historical_avg_pe(self.db, TICKER, bars)
        # Only months from 2026-01-01 onwards may see the restated figure.
        self.assertNotEqual(after["hist_avg_pe"], 100.0)
        self.assertLess(abs(after["hist_avg_pe"] - before), before * 0.35)


class TestValuationBlock(PeBase):

    def test_the_bands_are_the_same_ones_the_funds_use(self):
        from services import monthly_engine as me
        self.assertEqual((me.CHEAP_THRESHOLD, me.EXPENSIVE_THRESHOLD), (-0.15, 0.20))

    def test_a_price_well_below_its_own_average_multiple_reads_cheap(self):
        self._file("2019-12-31", "2020-02-01", eps=4.0)
        bars = _bars("2020-07-27", 2200, lambda d: 100.0 if d < "2026-01-01" else 60.0)
        out = spe.valuation_for_stock(self.db, TICKER, bars)
        self.assertEqual(out["status"], "CHEAP")

    def test_a_price_well_above_its_own_average_multiple_reads_expensive(self):
        self._file("2019-12-31", "2020-02-01", eps=4.0)
        bars = _bars("2020-07-27", 2200, lambda d: 100.0 if d < "2026-01-01" else 200.0)
        self.assertEqual(spe.valuation_for_stock(self.db, TICKER, bars)["status"], "EXPENSIVE")

    def test_a_loss_making_company_stays_not_applicable_through_the_block(self):
        self._file("2019-12-31", "2020-02-01", eps=-4.0)
        out = spe.valuation_for_stock(self.db, TICKER, _bars("2020-07-27", 2200, lambda d: 100.0))
        self.assertEqual(out["status"], spe.NOT_APPLICABLE)

    def test_a_missing_verdict_always_carries_a_reason(self):
        out = spe.valuation_for_stock(self.db, TICKER, _bars("2025-01-01", 60, lambda d: 100.0))
        self.assertEqual(out["status"], spe.MISSING)
        self.assertTrue(out["reason"])

    def test_the_basis_is_stated_and_does_not_claim_trailing_twelve_months(self):
        self._file("2019-12-31", "2020-02-01", eps=4.0)
        out = spe.valuation_for_stock(self.db, TICKER, _bars("2020-07-27", 2200, lambda d: 100.0))
        self.assertIn("ANNUAL", out["basis"])
        self.assertIn("not a trailing twelve months", out["basis"])

    def test_the_provenance_of_the_number_travels_with_it(self):
        self._file("2019-12-31", "2020-02-01", eps=4.0)
        out = spe.valuation_for_stock(self.db, TICKER, _bars("2020-07-27", 2200, lambda d: 100.0))
        for key in ("eps", "eps_basis", "eps_fiscal_year", "eps_period_end", "eps_filed",
                    "eps_age_days", "price_used", "price_date", "price_basis",
                    "hist_months_used", "hist_window"):
            self.assertIn(key, out)


class TestImplausibilityRail(PeBase):
    """The Booking Holdings failure, encoded. A perfect calculation on a broken input."""

    def test_an_absurdly_low_multiple_is_flagged_rather_than_called_cheap(self):
        self._file("2019-12-31", "2020-02-01", eps=100.0)          # e.g. a stale pre-split EPS
        bars = _bars("2020-07-27", 2200, lambda d: 120.0)
        out = spe.valuation_for_stock(self.db, TICKER, bars)
        self.assertTrue(out["implausible"])
        self.assertEqual(out["status"], "CHECK THIS")
        self.assertNotEqual(out["status"], "CHEAP")

    def test_an_absurdly_high_multiple_is_flagged_too(self):
        self._file("2019-12-31", "2020-02-01", eps=0.01)
        out = spe.valuation_for_stock(
            self.db, TICKER, _bars("2020-07-27", 2200, lambda d: 100.0))
        self.assertTrue(out["implausible"])
        self.assertEqual(out["status"], "CHECK THIS")

    def test_the_flag_names_the_actual_inputs_so_it_can_be_investigated(self):
        self._file("2019-12-31", "2020-02-01", eps=100.0)
        out = spe.valuation_for_stock(
            self.db, TICKER, _bars("2020-07-27", 2200, lambda d: 120.0))
        self.assertIn("120", out["reason"])
        self.assertIn("100", out["reason"])
        self.assertIn("2020-02-01", out["reason"])

    def test_an_ordinary_multiple_is_not_flagged(self):
        self._file("2019-12-31", "2020-02-01", eps=4.0)
        out = spe.valuation_for_stock(
            self.db, TICKER, _bars("2020-07-27", 2200, lambda d: 100.0))
        self.assertNotEqual(out["status"], "CHECK THIS")
        self.assertFalse(out.get("implausible"))

    def test_the_number_is_still_shown_not_hidden(self):
        """Dropping it would hide the bug; the point is to surface it."""
        self._file("2019-12-31", "2020-02-01", eps=100.0)
        out = spe.valuation_for_stock(
            self.db, TICKER, _bars("2020-07-27", 2200, lambda d: 120.0))
        self.assertIsNotNone(out["pe"])


class TestFrozenContract(unittest.TestCase):
    """Things that must not drift silently."""

    def test_no_forward_or_estimated_earnings_crept_in(self):
        """Scans the CODE, not the prose.

        The first version of this test failed on the module's own docstring, which says in words
        that analyst estimates are not used. A contract test that cannot tell a promise from a
        breach of it is worse than none, so comments, docstrings and string literals are stripped
        before the scan and only executable tokens are checked.
        """
        import ast
        tree = ast.parse(Path(spe.__file__).read_text())
        for node in ast.walk(tree):          # remove every docstring and string constant
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                node.value = ""
        code = ast.unparse(tree).lower()
        for forbidden in ("analyst", "forward_eps", "forward_pe", "estimate", "consensus",
                          "normalis", "normaliz"):
            self.assertNotIn(forbidden, code, f"P/E must not use {forbidden}")

    def test_the_history_minimum_is_three_years(self):
        self.assertEqual(spe.MIN_MONTHS_FOR_HISTORY, 36)

    def test_the_price_field_is_raw_everywhere_in_this_module(self):
        src = Path(spe.__file__).read_text()
        self.assertIn('field="close_raw"', src)
        self.assertNotIn('field="close_adj"', src)

    def test_this_module_reads_nothing_from_the_other_pillars(self):
        src = Path(spe.__file__).read_text()
        for forbidden in ("company_health", "value_service", "entry_service", "signal"):
            self.assertNotIn(forbidden, src)


if __name__ == "__main__":
    unittest.main()
