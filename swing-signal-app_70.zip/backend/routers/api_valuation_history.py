"""VALUATION HISTORY — read-only. Nothing here trades, ranks, recommends or scores.

Additive by construction: this blueprint imports the study service and the bar store and nothing
else. It does not touch the Dashboard, Yearly or Mag 7 & ETFs data paths, which are pinned by
content hash in tests/test_existing_pages_untouched.py.
"""
from datetime import datetime, timezone

from flask import Blueprint, jsonify, request

from config import ETF_UNIVERSE, STOCK_UNIVERSE, US_ETF_UNIVERSE
from db import get_db
from services import monthly_engine as me
from services import valuation_history_service as vh
from services import value_bars_service as vb

bp = Blueprint("api_valuation_history", __name__, url_prefix="/api/valuation-history")

_HELD_ETF = set(me.SEED_ETFS)


def _studiable() -> list:
    """Securities this study can actually cover.

    The seven companies, plus the four US trackers — those price from Alpaca, so their forward
    returns are real. Your four London funds are EXCLUDED and the page says why: their price
    series is the workbook's month-end snapshot, and they have no filings, so neither half of a
    verdict exists for them. Showing them with empty cells would invite the reading that their
    valuation is unknown, when in fact the question does not apply.
    """
    rows = [{"ticker": s["ticker"], "name": s["name"], "kind": "COMPANY"}
            for s in STOCK_UNIVERSE]
    rows += [{"ticker": e["ticker"], "name": e["name"], "kind": "US TRACKER"}
             for e in US_ETF_UNIVERSE]
    return rows


def _excluded() -> list:
    return [{"ticker": e["ticker"], "name": e["name"],
             "reason": ("a fund has no filings, so there is no earnings figure to divide a price "
                        "by; and its price here is the workbook's month-end series rather than "
                        "traded bars")}
            for e in ETF_UNIVERSE if e["ticker"] in _HELD_ETF]


@bp.get("/universe")
def universe():
    db = get_db()
    out, all_rows = [], []
    for s in _studiable():
        bars = vb.bars(db, s["ticker"])
        study = vh.study_for(db, s["ticker"], bars)
        study.pop("series", None)                 # the per-month detail has its own endpoint
        study["name"], study["kind"] = s["name"], s["kind"]
        out.append(study)
        all_rows.append(vh.expanding_verdicts(db, s["ticker"], bars))

    longest = max((r for r in all_rows), key=len, default=[])
    return jsonify({
        "as_of": datetime.now(timezone.utc).date().isoformat(),
        "securities": len(out),
        "results": out,
        "excluded": _excluded(),
        # Printed on the page, not summarised. A caveat that lives only in a conversation is gone
        # by the time anybody acts on the number.
        "limits": vh.cannot_conclude(longest),
        "bands": {"cheap_at_or_below": me.CHEAP_THRESHOLD,
                  "expensive_at_or_above": me.EXPENSIVE_THRESHOLD,
                  "note": "The same bands the Mag 7 & ETFs page uses. Not re-tuned for this study."},
    })


@bp.get("/<ticker>")
def one(ticker):
    """The month-by-month series behind every figure, so a number can be read rather than trusted."""
    ticker = ticker.upper()
    known = {s["ticker"] for s in _studiable()}
    if ticker not in known:
        excluded = {e["ticker"]: e["reason"] for e in _excluded()}
        if ticker in excluded:
            return jsonify({"ticker": ticker, "status": "NOT APPLICABLE",
                            "reason": excluded[ticker]}), 200
        return jsonify({"error": f"{ticker} is not covered by this study"}), 404
    db = get_db()
    out = vh.study_for(db, ticker, vb.bars(db, ticker))
    out["limits"] = vh.cannot_conclude(out["series"])
    if request.args.get("series") == "0":
        out.pop("series", None)
    return jsonify(out)
