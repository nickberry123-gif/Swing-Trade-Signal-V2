"""HEALTH AND NEWS FOR THE DASHBOARD — both surfaced as they are, neither reinvented.

HEALTH is the frozen C1 Company Health score, computed by the existing validation pipeline. It is
fundamentals only: no price, no P/E, no technicals. Nothing here changes it — this endpoint reads
it so the dashboard can show it beside the price.

NEWS is the existing keyword-classified feed. It is deliberately reported as a COUNT and a most
recent headline, not as a judgement. A keyword classifier cannot tell you whether an investment
case broke; it can tell you something happened worth reading, and that is what is shown.
"""
from flask import Blueprint, jsonify, request

from providers.base import ProviderError
from services import fundamentals_history_service as fh

from config import Config
from db import get_db
from services.data_validation_service import validate_ticker
from services.news_service import get_news_for_ticker
from services.signals_service import TICKERS

bp = Blueprint("api_health_news", __name__, url_prefix="/api/overview")

NEWS_LIMIT = 5


def _missing_reason(db, ticker, v) -> str:
    """The specific reason THIS company has no health score, in words that name the next action.

    Ordered from the most basic cause outwards, because a company with no filings at all cannot
    also have a coverage problem, and reporting the second when the first is true would send you
    looking in the wrong place.
    """
    if not v.get("periods"):
        stored = fh.count(db, ticker)
        if not stored:
            return ("no annual filings are stored for this company. Press Fetch Fundamentals; if "
                    "it still fails, the SEC EDGAR response for this ticker is the thing to read.")
        return (f"{stored} filing rows are stored but none survived the point-in-time read — the "
                "filing dates on them are the thing to check.")
    if v.get("company_health_coverage_pct") is not None:
        return (f"filings are stored ({v.get('periods')} periods) but only "
                f"{v['company_health_coverage_pct']}% of the inputs the score needs were reported, "
                "which is below the 75% gate. The missing inputs are listed in "
                "company_health_categories.")
    notes = v.get("notes") or []
    return notes[0] if notes else "the validator returned no verdict and gave no reason."


@bp.get("")
def overview():
    """One row per tracked company: health verdict, coverage, and recent news."""
    db = get_db()
    only = (request.args.get("tickers") or "").upper()
    wanted = ([t for t in sorted(TICKERS) if t in {x.strip() for x in only.split(",")}]
              if only else sorted(TICKERS))
    out = []
    for t in wanted:
        row = {"ticker": t}
        try:
            v = validate_ticker(db, t)
            row["health_score"] = v.get("company_health_score")
            row["health_verdict"] = v.get("company_health_verdict") or "MISSING DATA"
            row["health_coverage_pct"] = v.get("company_health_coverage_pct")
            # WHY a row is blank, on the row itself. A bare "MISSING DATA" beside six scored
            # companies is the least useful thing this endpoint could say: it cannot be told
            # apart from a company whose filings simply have not been fetched yet, and the fix
            # for each is different. The validator already knows which it is — it just was not
            # being asked.
            if row["health_verdict"] == "MISSING DATA":
                row["health_missing_reason"] = _missing_reason(db, t, v)
                row["health_periods_stored"] = fh.count(db, t)
        except Exception as e:                      # a broken row must not blank the whole table
            row["health_score"] = None
            row["health_verdict"] = "MISSING DATA"
            row["health_error"] = str(e)
            row["health_missing_reason"] = f"the health calculation raised an error: {e}"
        items = get_news_for_ticker(db, t, limit=NEWS_LIMIT) or []
        row["news_count"] = len(items)
        row["news_latest"] = (items[0].get("headline") or items[0].get("title")) if items else None
        row["news_latest_at"] = items[0].get("published_at") if items else None
        out.append(row)
    return jsonify({
        "tickers": len(out),
        "news_note": ("News is counted and linked, not interpreted. The classifier is keyword-based "
                      "and cannot tell you whether an investment case has changed."),
        "alpaca_configured": Config.has_alpaca_credentials(),
        "results": out,
    })


@bp.post("/fundamentals/refresh")
def refresh_fundamentals():
    """Pull filings from SEC EDGAR for the tracked companies.

    FREE AND KEYLESS — EDGAR is public, so this needs no Alpaca credentials and no paid provider.

    This is the one action that fixes BOTH the missing P/E and the missing Health score, because
    C1 and the price/earnings ratio read the same filings. Reporting them as two separate problems
    would have sent you looking for two separate fixes.
    """
    db = get_db()
    only = (request.args.get("tickers") or "").upper()
    wanted = ([t for t in sorted(TICKERS) if t in {x.strip() for x in only.split(",")}]
              if only else sorted(TICKERS))
    out = []
    for t in wanted:
        try:
            written = fh.refresh(db, t, force=True)
            cov = fh.coverage(db, t)
            out.append({"ticker": t, "status": "OK", "written": written,
                        "periods": cov.get("periods") if isinstance(cov, dict) else None})
        except ProviderError as e:
            out.append({"ticker": t, "status": "UNAVAILABLE", "error": str(e)})
        except Exception as e:                 # one bad filer must not abandon the rest
            out.append({"ticker": t, "status": "ERROR", "error": str(e)})
    ok = [r for r in out if r["status"] == "OK"]
    return jsonify({
        "requested": len(wanted), "ok": len(ok), "failed": len(out) - len(ok),
        "source": "SEC EDGAR (public, no API key required)",
        "note": "Fills both the P/E and the Company Health columns — they read the same filings.",
        "results": out,
    })
