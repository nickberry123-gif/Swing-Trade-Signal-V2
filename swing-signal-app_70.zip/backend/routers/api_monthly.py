"""MONTHLY ANALYSIS — the Excel workbook's methodology for the eleven tracked securities.

Read-only. Nothing here trades, recommends or ranks by anything other than the numbers requested.
"""
from datetime import datetime, timedelta, timezone

from flask import Blueprint, jsonify, request

from config import Config, ETF_UNIVERSE, STOCK_UNIVERSE, US_ETF_UNIVERSE
from db import get_db
from providers.base import ProviderError
from services import monthly_engine as me
from services import stock_pe_service as spe
from services import value_bars_service as vb

bp = Blueprint("api_monthly", __name__, url_prefix="/api/monthly")

_ETF = set(me.SEED_ETFS)
_US_TRACKERS = {e["ticker"] for e in US_ETF_UNIVERSE}


# Stocks and funds now live in separate lists, so this page assembles both. MAG6 is skipped here
# because it is GENERATED further down rather than read from anywhere — including it twice would
# show the index beside a hollow copy of itself.
def _tracked() -> list:
    rows = [{"ticker": s["ticker"], "name": s["name"], "sector": s["sector"]}
            for s in STOCK_UNIVERSE]
    rows += [{"ticker": e["ticker"], "name": e["name"], "sector": "ETF (held)"}
             for e in ETF_UNIVERSE if e["ticker"] != me.SYNTHETIC]
    rows += [{"ticker": e["ticker"], "name": e["name"] + " — tracks " + e["tracks"],
              "sector": "ETF (US tracker)"} for e in US_ETF_UNIVERSE]
    return rows


_META = {r["ticker"]: r for r in _tracked()}


def _currency(t):
    return "GBP" if t in _ETF else "USD"


def _series_for(db, ticker, seed, raw=None):
    """ETFs come from the verified workbook seed; stocks from stored ADJUSTED daily bars.

    `raw` lets a caller that has already loaded the bars hand them in rather than causing a second
    read of the same six years.
    """
    if ticker in _ETF:
        return seed.get(ticker, []), "Workbook monthly adjusted close (GBp converted to GBP)"
    bars = vb.bars(db, ticker) if raw is None else raw
    return (me.month_end_samples(bars),
            "Month-end sample of stored adjusted daily bars")


def _build(db):
    seed = me.etf_seed()
    rows, members = [], {}
    for s in _tracked():
        t = s["ticker"]
        # Loaded once and passed down. The P/E history walks the same bars the price series uses,
        # and reading six years of daily rows twice per company is the kind of doubled query that
        # exhausted the Neon transfer allowance once already.
        raw = [] if t in _ETF else vb.bars(db, t)
        series, src = _series_for(db, t, seed, raw=raw)
        # A US tracker is a fund, not a company. It was typed STOCK because the only funds in this
        # universe used to be the London ones, and the badge has said the wrong thing since the
        # four trackers were added — a row labelled STOCK invites a P/E to be read as a company's.
        kind = "ETF" if (t in _ETF or t in _US_TRACKERS) else "STOCK"
        m = me.metrics(t, s["name"], kind, _currency(t), series)
        m["sector"] = s["sector"]
        m["source"] = src
        fund = me.ETF_FUNDAMENTALS.get(t)
        if fund:
            m.update({k: fund[k] for k in ("pb", "ter", "yield", "holdings", "top10", "beta")})
            m["fundamentals_source"] = fund["source"]
            m["valuation"] = me.valuation_vs_history(fund["pe"], fund["hist_avg_pe"])
        elif t in _ETF or t in _US_TRACKERS:
            # A fund whose fact-sheet figures nobody has entered. It is not a company, so there is
            # nothing in the filings to fall back on — the honest answer is what is missing and
            # where it would come from, not a plausible-looking number.
            m["valuation"] = me.valuation_vs_history(None, None)
            m["valuation"]["reason"] = (
                "no fact-sheet figures have been entered for this fund. A fund's P/E, TER and "
                "yield are published by its provider and are not derivable from price history or "
                "from company filings, so they are shown as missing rather than estimated.")
        else:
            # A company. Its P/E is computable from the annual filings this app already stores,
            # against the raw (unadjusted) close — see services/stock_pe_service.py for why the
            # price basis matters and how look-ahead is excluded.
            m["valuation"] = spe.valuation_for_stock(db, t, raw)
            m["pe_diagnostic"] = spe.diagnose(db, t, raw)
        rows.append(m)
        if t in me.SYNTHETIC_MEMBERS:
            members[t] = series

    syn = me.synthetic_series(members)
    present = sorted(members)
    smetrics = me.metrics(
        me.SYNTHETIC,
        "Magnificent 7 excluding Tesla — equal weight, rebalanced monthly",
        "SYNTHETIC INDEX", "USD", [(d, lvl) for d, lvl, _ in syn])
    smetrics["sector"] = "Home-made index"
    smetrics["source"] = ("Built here, not traded. Each month's return is the plain average of its "
                          "constituents' returns, which is what monthly rebalancing means.")
    # An index of six companies has no single P/E, and averaging seven of them would be a number
    # with no meaning. NOT APPLICABLE is the honest answer, and it is not the same as MISSING.
    smetrics["valuation"] = {"pe": None, "hist_avg_pe": None, "pe_vs_avg": None,
                             "status": "NOT APPLICABLE",
                             "reason": "a synthetic index has no single price/earnings ratio"}
    smetrics["constituents"] = list(me.SYNTHETIC_MEMBERS)
    smetrics["constituents_with_data"] = present
    smetrics["missing_constituents"] = [t for t in me.SYNTHETIC_MEMBERS if t not in present]
    if smetrics["missing_constituents"]:
        smetrics["data_status"] = ("PARTIAL — no price history for "
                                   + ", ".join(smetrics["missing_constituents"]))
    rows.append(smetrics)
    return rows


@bp.get("/universe")
def universe():
    rows = _build(get_db())
    years = sorted({y for r in rows for y in r.get("annual", {})})
    return jsonify({
        "as_of": datetime.now(timezone.utc).date().isoformat(),
        "securities": len(rows), "years": years,
        "note": ("ETFs are GBP and stocks USD. Returns are not currency-converted, so figures are "
                 "comparable within a currency, not across the two."),
        "results": rows,
    })


@bp.get("/<ticker>")
def one(ticker):
    ticker = ticker.upper()
    rows = {r["ticker"]: r for r in _build(get_db())}
    if ticker not in rows:
        return jsonify({"error": f"{ticker} is not tracked"}), 404
    return jsonify(rows[ticker])


@bp.get("/<ticker>/series")
def series(ticker):
    """The monthly series behind every figure — so a number can be read rather than trusted."""
    ticker = ticker.upper()
    db = get_db()
    if ticker == me.SYNTHETIC:
        seed = me.etf_seed()
        members = {t: _series_for(db, t, seed)[0] for t in me.SYNTHETIC_MEMBERS}
        rows = [{"date": d, "level": lvl, "constituents_used": n}
                for d, lvl, n in me.synthetic_series(members)]
        return jsonify({"ticker": ticker, "observations": len(rows), "series": rows})
    if ticker not in _META:
        return jsonify({"error": f"{ticker} is not tracked"}), 404
    s, src = _series_for(db, ticker, me.etf_seed())
    return jsonify({"ticker": ticker, "source": src, "observations": len(s),
                    "series": [{"date": d, "price": p} for d, p in s]})


@bp.post("/refresh")
def refresh():
    """Fetch adjusted daily bars for the tracked STOCKS. ETFs use the embedded workbook series."""
    db = get_db()
    wanted = [s["ticker"] for s in _tracked() if s["ticker"] not in _ETF]
    only = (request.args.get("tickers") or "").upper()
    if only:
        wanted = [t for t in wanted if t in {x.strip() for x in only.split(",")}]
    out = []
    for t in wanted:
        try:
            out.append(vb.refresh(db, t))
        except ProviderError as e:                      # never let one failure hide the rest
            out.append({"ticker": t, "status": "UNAVAILABLE", "error": str(e), "rows": 0})
    ok = [r for r in out if r.get("status") == "OK"]
    return jsonify({"requested": len(wanted), "ok": len(ok),
                    "failed": len(out) - len(ok), "results": out,
                    "note": "ETFs are not fetched — their history is the verified workbook series."})
