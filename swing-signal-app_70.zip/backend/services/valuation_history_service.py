"""
WHAT VALUATION ACTUALLY LOOKED LIKE — a description of the past, not a rule for the future.

THE QUESTION ASKED: "do I wait for it to say cheap or fair before buying, or when it says
expensive do I just buy and forget?"

THE HONEST ANSWER FIRST: this data cannot settle that. Price history begins 27 July 2020 — a
measured limit of the Alpaca account, confirmed by empty responses for 2016, 2017, 2018 and 2019
— which gives 74 month-ends. Thirty-six are consumed building the first historical average, so
verdicts can only exist for the last ~38 months. Against a one-year forward horizon that leaves
26 decisions per company. Seven companies multiply that to 182, which sounds like a sample and is
not one: consecutive months share eleven twelfths of their forward window, and seven mega-cap US
technology companies are not seven independent bets — they rose together and they fell together
in 2022. Strip the overlap and the correlation out and roughly FOUR independent observations
remain, all inside a single market regime.

So this module deliberately computes NO significance test, NO ranking, and NO pass/fail verdict.
It reports what happened. Every figure it returns carries its own observation count, and the
caller is given a `cannot_conclude` block it is expected to print rather than summarise.

WHY THAT IS NOT A COP-OUT. A statistic that cannot distinguish skill from luck still produces a
number, and the number is persuasive precisely because it is specific. This project has already
shipped a mathematically perfect +88,446% return. Two pre-registered studies — Value V1 and Entry
V1 — were run properly and both failed, and the temptation after two failures is to keep testing
until something finally reads well. Refusing to produce a verdict here is the control on that.

THE LOOK-AHEAD FIX THAT MADE THIS POSSIBLE
------------------------------------------
`stock_pe_service.historical_avg_pe` averages the WHOLE stored window. For the live page that is
correct: comparing today against all history up to today uses nothing that had not happened,
because today is the end of it. The moment a PAST month is judged, the same function becomes
look-ahead — a 2023 verdict computed against an average containing 2025 and 2026 knows how the
story ended.

So this module rebuilds the average as an EXPANDING WINDOW: the verdict at month *t* is computed
only from months strictly before *t*, using only filings whose `filed` date had already passed.
The two functions are kept separate rather than one being made to serve both, because a single
function with an `as_of` argument is one forgotten parameter away from silently leaking.

TWO PRICE BASES, ON PURPOSE
---------------------------
Verdicts use RAW closes, because they are divided into as-reported earnings and the two must sit
on the same side of any split. Forward returns use ADJUSTED closes, because a return needs a
continuous series across splits and dividends. Mixing them the other way round would be wrong in
both directions, so both are named on every result.

EXECUTION
---------
A verdict is produced at a month-end close. Buying at that same close would be buying on
information the close itself carries. Every purchase here happens at the NEXT available bar.
"""
from services import monthly_engine as me
from services import stock_pe_service as spe

CHEAP, FAIR, EXPENSIVE = "CHEAP", "FAIR", "EXPENSIVE"
NO_VERDICT = "NO VERDICT"

VERDICTS = (CHEAP, FAIR, EXPENSIVE)

# Identical to the live page's requirement, and identical for the same reason: fewer than three
# years of observations is an anecdote wearing a percentage sign. Not a tunable — moving it would
# change every result in this module, which is exactly why it is stated once and left alone.
MIN_MONTHS_FOR_HISTORY = spe.MIN_MONTHS_FOR_HISTORY

# Horizons the data can actually carry. Three and five years are absent because at 38 verdict
# months they would yield two observations and zero respectively — reporting them would be
# printing a number with no content behind it.
FORWARD_HORIZONS = (3, 6, 12)


def _month_ends(raw_bars, adj_bars):
    """Month-end dates common to both bases, with both prices. Ascending.

    Both are required on the same day: a verdict needs the raw close and the forward return needs
    the adjusted one, and pairing a verdict from one date with a return from another would put a
    silent offset into every observation.
    """
    raw = dict(me.month_end_samples(raw_bars, field="close_raw"))
    adj = dict(me.month_end_samples(adj_bars, field="close_adj"))
    return [(d, raw[d], adj[d]) for d in sorted(set(raw) & set(adj))]


def expanding_verdicts(db, ticker, raw_bars, adj_bars=None) -> list:
    """One row per month-end: the verdict as it could have been known THAT month.

    The average at month *t* is the mean of the multiples at months strictly before *t*. Nothing
    at or after *t* is visible. The first ~36 months therefore carry no verdict at all, and that
    is reported as NO VERDICT rather than filled in.
    """
    adj_bars = raw_bars if adj_bars is None else adj_bars
    timeline = spe.eps_timeline(db, ticker)
    rows, history = [], []

    for date, raw_close, adj_close in _month_ends(raw_bars, adj_bars):
        filing = spe.known_at(timeline, date)
        pe = None
        if (filing is not None and filing["eps"] > 0
                and (not filing["currency"] or filing["currency"] == "USD")):
            pe = raw_close / filing["eps"]

        # The average is taken BEFORE this month's multiple joins the history. One line, and the
        # whole no-look-ahead claim rests on it: appending first would let a month help set the
        # benchmark it is then measured against.
        avg = sum(history) / len(history) if len(history) >= MIN_MONTHS_FOR_HISTORY else None
        verdict, deviation = NO_VERDICT, None
        if pe is not None and avg:
            deviation = pe / avg - 1.0
            verdict = (CHEAP if deviation <= me.CHEAP_THRESHOLD
                       else EXPENSIVE if deviation >= me.EXPENSIVE_THRESHOLD else FAIR)

        rows.append({
            "date": date, "pe": round(pe, 4) if pe is not None else None,
            "avg_pe_so_far": round(avg, 4) if avg else None,
            "months_in_average": len(history),
            "deviation": round(deviation, 6) if deviation is not None else None,
            "verdict": verdict,
            "price_raw": round(raw_close, 4), "price_adj": round(adj_close, 4),
            "eps": filing["eps"] if filing else None,
            "eps_filed": filing["filed"] if filing else None,
        })
        if pe is not None:
            history.append(pe)
    return rows


def verdict_census(rows) -> dict:
    """How often each verdict appeared at all.

    The first thing worth knowing, and the cheapest: if CHEAP almost never occurs, then "wait for
    cheap" is not a strategy that was ever available, whatever its returns would have been.
    """
    counted = {v: 0 for v in VERDICTS}
    counted[NO_VERDICT] = 0
    for r in rows:
        counted[r["verdict"]] += 1
    scored = sum(counted[v] for v in VERDICTS)
    return {
        "months_total": len(rows),
        "months_with_a_verdict": scored,
        "months_without": counted[NO_VERDICT],
        "counts": {v: counted[v] for v in VERDICTS},
        "share": {v: (round(counted[v] / scored, 4) if scored else None) for v in VERDICTS},
        "first_verdict_month": next((r["date"] for r in rows if r["verdict"] != NO_VERDICT), None),
    }


def waiting_cost(rows) -> dict:
    """How long you would have sat out waiting for CHEAP, in months.

    Time, not money — deliberately. What a wait cost in return depends on what the money did
    meanwhile, and that is a separate question answered further down. How LONG you would have
    waited is a fact about the past with no assumptions in it at all.
    """
    scored = [r for r in rows if r["verdict"] != NO_VERDICT]
    if not scored:
        return {"months_eligible": 0, "cheap_months": 0, "longest_wait_months": None,
                "never_cheap": None, "reason": "no month carried a verdict"}

    longest, current, waits = 0, 0, []
    for r in scored:
        if r["verdict"] == CHEAP:
            if current:
                waits.append(current)
            longest, current = max(longest, current), 0
        else:
            current += 1
    longest = max(longest, current)
    cheap = sum(1 for r in scored if r["verdict"] == CHEAP)
    return {
        "months_eligible": len(scored),
        "cheap_months": cheap,
        "months_waiting": len(scored) - cheap,
        "longest_wait_months": longest,
        "still_waiting_months": current,      # an unbroken wait running to the last month
        "never_cheap": cheap == 0,
        "completed_waits": waits,
    }


def forward_returns_by_verdict(rows, horizons=FORWARD_HORIZONS) -> dict:
    """What followed each verdict, on adjusted prices, bought the month AFTER the verdict.

    Median and range rather than a mean: with counts this small one 2022 observation moves a mean
    a long way, and a mean invites a comparison the sample cannot support. The count sits beside
    every figure so a median of two is never mistaken for a median of fifty.
    """
    out = {}
    for h in horizons:
        buckets = {v: [] for v in VERDICTS}
        for i, r in enumerate(rows):
            if r["verdict"] == NO_VERDICT:
                continue
            entry_i, exit_i = i + 1, i + 1 + h        # buy the month AFTER the verdict
            if exit_i >= len(rows):
                continue
            entry, exit_ = rows[entry_i]["price_adj"], rows[exit_i]["price_adj"]
            if entry > 0:
                buckets[r["verdict"]].append(exit_ / entry - 1.0)
        out[f"{h}m"] = {v: _describe(vals) for v, vals in buckets.items()}
    return out


def _median(vals):
    s = sorted(vals)
    n = len(s)
    if not n:
        return None
    mid = n // 2
    return s[mid] if n % 2 else (s[mid - 1] + s[mid]) / 2.0


def _describe(vals) -> dict:
    """A distribution reported with its own sample size attached, always."""
    if not vals:
        return {"n": 0, "median": None, "min": None, "max": None, "positive_share": None}
    return {
        "n": len(vals),
        "median": round(_median(vals), 6),
        "min": round(min(vals), 6),
        "max": round(max(vals), 6),
        "positive_share": round(sum(1 for v in vals if v > 0) / len(vals), 4),
    }


def purchase_histories(rows) -> dict:
    """Three ways of spending the same money, over the same months.

    One unit of money is committed every eligible month. Under a rule that skips some months the
    money is NOT redirected into a bigger purchase later — it sits in cash earning nothing, and it
    is counted. Quietly reinvesting skipped contributions would compare a fully-invested strategy
    against another fully-invested strategy and call the difference timing.

    Every arm is money-weighted the same way, so the comparison is like for like: total value at
    the end against total money put in.
    """
    scored = [(i, r) for i, r in enumerate(rows) if r["verdict"] != NO_VERDICT]
    if not scored or len(rows) < 2:
        return {"arms": {}, "reason": "no month carried a verdict"}

    final = rows[-1]["price_adj"]
    arms = {
        "every_month": lambda v: True,
        "only_cheap": lambda v: v == CHEAP,
        "cheap_or_fair": lambda v: v in (CHEAP, FAIR),
        "skip_expensive": lambda v: v != EXPENSIVE,
    }

    out = {}
    for name, accepts in arms.items():
        units, contributed, cash, bought = 0.0, 0.0, 0.0, 0
        for i, r in scored:
            if i + 1 >= len(rows):
                continue                       # no next bar to buy on; month not counted at all
            contributed += 1.0
            if accepts(r["verdict"]):
                units += 1.0 / rows[i + 1]["price_adj"]
                bought += 1
            else:
                cash += 1.0                    # never redeployed, never silently reinvested
        value = units * final + cash
        out[name] = {
            "months_contributed": int(contributed),
            "months_bought": bought,
            "months_in_cash": int(contributed) - bought,
            "cash_never_invested": round(cash, 4),
            "final_value": round(value, 6),
            "total_contributed": round(contributed, 4),
            "total_return": round(value / contributed - 1.0, 6) if contributed else None,
        }
    return {"arms": out,
            "note": ("One unit of money per eligible month. Money a rule declines to invest sits "
                     "in cash earning nothing and is counted in the final value — it is not "
                     "quietly redeployed later.")}


def cannot_conclude(rows, horizons=FORWARD_HORIZONS) -> dict:
    """The limits of this study, computed from the data rather than asserted.

    Returned so the page PRINTS it. A caveat that lives only in a conversation is gone by the time
    anybody acts on the number.
    """
    scored = sum(1 for r in rows if r["verdict"] != NO_VERDICT)
    longest = max(horizons)
    usable = max(0, scored - longest)
    return {
        "months_of_price_history": len(rows),
        "months_consumed_building_the_first_average": MIN_MONTHS_FOR_HISTORY,
        "months_carrying_a_verdict": scored,
        "decisions_usable_at_the_longest_horizon": usable,
        "non_overlapping_windows": round(usable / longest, 2) if longest else None,
        "statement": (
            "This describes what happened to these securities between 2020 and 2026. It cannot "
            "support a rule about what to do next. Consecutive months share almost all of their "
            "forward window, and these companies rose and fell together rather than "
            "independently, so the effective number of independent observations is a handful — "
            "not the hundreds the row counts suggest. The whole period is one market regime. No "
            "significance test is computed here, and none would be meaningful at this size."),
        "why_history_starts_in_2020": (
            "27 July 2020 is the earliest date this Alpaca account serves bars for. It was "
            "measured, not assumed: 2016, 2017, 2018 and 2019 all returned nothing."),
    }


def study_for(db, ticker, raw_bars, adj_bars=None) -> dict:
    """Everything above for one security, with its price bases named on the result."""
    rows = expanding_verdicts(db, ticker, raw_bars, adj_bars)
    return {
        "ticker": ticker.upper(),
        "census": verdict_census(rows),
        "waiting": waiting_cost(rows),
        "forward_returns": forward_returns_by_verdict(rows),
        "purchases": purchase_histories(rows),
        "months": len(rows),
        "verdict_basis": ("raw (unadjusted) close divided by as-reported diluted EPS from the "
                          "most recent annual report public that month"),
        "return_basis": "split- and dividend-adjusted close, bought the month AFTER the verdict",
        "series": rows,
    }
