"""
TRAILING PRICE/EARNINGS FOR A COMPANY, BUILT FROM ITS OWN FILINGS.

WHY THIS EXISTS. The monthly page has always shown a P/E for the four London funds, taken from
their published fact sheets, and MISSING for all seven companies. The reason given on screen was
"no earnings data is stored for this company". That was true when the page was written and is not
true now: Build B stores the annual filings, and `eps_diluted` is one of the fields it stores. The
column was blank because nothing ever read it, not because the number was unavailable.

WHAT THIS IS, EXACTLY. Last quoted price divided by the DILUTED EARNINGS PER SHARE FROM THE MOST
RECENT ANNUAL REPORT THAT WAS PUBLIC ON THAT DATE. It is a full-year figure, not a trailing-twelve-
month figure, so it will not match the P/E quoted on a financial website, which rolls four
quarters. The difference is real and can be large — for a company growing quickly, an annual EPS
eight months old understates earnings and so overstates the P/E. Every response therefore carries
the fiscal year, the filing date and how stale the figure is, so the number can be judged rather
than trusted.

WHY RAW PRICES. A P/E is a price paid for a share against the earnings that share reported. The
as-reported EPS in a 2021 10-K is a pre-split figure for a company that split in 2024, and the
matching price is the pre-split price actually quoted in 2021 — the raw close. Pairing an adjusted
price with an as-reported EPS would divide a post-split price by pre-split earnings and produce a
P/E ten times too small. This is the same rule the Value pillar follows, for the same reason.

NO LOOK-AHEAD. The historical average is a month-by-month series, and each month uses only filings
whose `filed` date had already passed. A restatement published in 2025 cannot enter a 2021
observation, because it is excluded by the query rather than by a promise not to use it.

WHAT IS NOT DONE HERE. No forward estimates, no analyst figures, no normalised or adjusted
earnings, no substitution of one company's multiple for another's. A company that reported a loss
has no meaningful P/E and is reported as NOT APPLICABLE, which is a different statement from
MISSING and must not be shown as a blank.
"""
from services import fundamentals_history_service as fh
from services import monthly_engine as me

# Below this many monthly observations there is no "own history" worth averaging. Three years
# matches the minimum the Value pillar already uses; a mean of five months is not a history and
# calling it one would put a confident-looking number next to a verdict it cannot support.
MIN_MONTHS_FOR_HISTORY = 36

AS_REPORTED = "as-reported diluted EPS"
DERIVED = "derived: net income / diluted shares"

NOT_APPLICABLE = "NOT APPLICABLE"
MISSING = "MISSING DATA"

# A LOUD RAIL, NOT A FILTER. Booking Holdings once valued an $8.8bn-profit company at $6.5bn on
# this app's own screen, at a price/earnings ratio of 1.24, because a February share count met an
# August price across a split. The arithmetic was perfect. Numbers outside this band are almost
# always a broken input — a stale share count, a split, a wrong unit — rather than a real bargain,
# so they are still SHOWN, and shown with the warning attached. Silently dropping them would hide
# the bug; showing them bare would repeat it.
IMPLAUSIBLE_BELOW, IMPLAUSIBLE_ABOVE = 3.0, 400.0


def _eps_of(row):
    """Diluted EPS for one filing, and how it was obtained. Never invented, never estimated.

    Some filers tag the earnings-per-share element and some do not, while still tagging both net
    income and the diluted share count. Dividing one by the other is arithmetic on two published
    figures, not an estimate, so it is allowed — but it is a different basis from the number the
    company printed, so it is labelled and never silently mixed in.
    """
    eps = me._v(row.get("eps_diluted"))
    if eps is not None:
        return eps, AS_REPORTED
    ni, sh = me._v(row.get("net_income")), me._v(row.get("diluted_shares"))
    if ni is not None and sh is not None and sh > 0:
        return ni / sh, DERIVED
    return None, None


def eps_timeline(db, ticker: str) -> list:
    """Every (filing, fiscal period, EPS) this app holds, ascending by filing date.

    Built once per ticker and resolved in memory afterwards. The point-in-time question is asked
    around seventy times when the historical average is computed, and asking the database seventy
    times per company would spend the Neon transfer allowance to re-read rows already in hand.
    """
    out = []
    for r in fh.history_all_vintages(db, ticker, limit=200):
        eps, basis = _eps_of(r)
        if eps is None or not r.get("filed") or not r.get("period_end"):
            continue
        out.append({"filed": r["filed"][:10], "period_end": r["period_end"][:10],
                    "eps": eps, "basis": basis, "fiscal_year": r.get("fiscal_year"),
                    "form": r.get("form"), "currency": r.get("currency"),
                    "accn": r.get("accn")})
    out.sort(key=lambda d: (d["filed"], d["period_end"]))
    return out


def known_at(timeline: list, on_date: str):
    """The latest annual report that had been PUBLISHED on `on_date` — nothing filed after it.

    Among filings already public, the newest fiscal period wins; where the same period has been
    filed more than once, the newest version of it wins. That ordering matters: a restatement of
    2022 published in 2024 must not displace the 2023 report as the most recent year.
    """
    best = None
    for r in timeline:
        if r["filed"] > on_date:
            continue
        key = (r["period_end"], r["filed"])
        if best is None or key > (best["period_end"], best["filed"]):
            best = r
    return best


def _stale_days(price_date: str, period_end: str) -> int:
    from datetime import date
    try:
        return (date.fromisoformat(price_date) - date.fromisoformat(period_end)).days
    except (TypeError, ValueError):
        return None


def current_pe(db, ticker: str, raw_bars: list) -> dict:
    """Today's P/E on the last published annual EPS, or an explicit reason why there is none."""
    out = {"pe": None, "status": MISSING, "reason": None, "eps": None, "eps_basis": None,
           "fiscal_year": None, "period_end": None, "filed": None, "price": None,
           "price_date": None, "eps_age_days": None, "currency": None}

    months = me.month_end_samples(raw_bars, field="close_raw")
    if not months:
        out["reason"] = "no raw price history stored for this company"
        return out
    price_date, price = months[-1]
    out["price"], out["price_date"] = round(price, 4), price_date

    timeline = eps_timeline(db, ticker)
    if not timeline:
        out["reason"] = ("no annual filing stored for this company. Press 'Fetch Company Filings "
                         "(P/E & Health)' on the Dashboard — it pulls them from SEC EDGAR, which "
                         "is free and needs no API key.")
        return out

    row = known_at(timeline, price_date)
    if row is None:
        out["reason"] = "no annual filing had been published by the date of the latest price"
        return out

    out.update({"eps": round(row["eps"], 6), "eps_basis": row["basis"],
                "fiscal_year": row["fiscal_year"], "period_end": row["period_end"],
                "filed": row["filed"], "currency": row["currency"],
                "eps_age_days": _stale_days(price_date, row["period_end"])})

    # A currency mismatch would divide dollars by euros. Nothing here converts currencies, so the
    # honest answer is no number rather than a number in no currency at all.
    if row["currency"] and row["currency"] != "USD":
        out["status"] = NOT_APPLICABLE
        out["reason"] = (f"earnings are reported in {row['currency']} and the price is in USD; "
                         "nothing here converts currencies")
        return out

    if row["eps"] <= 0:
        out["status"] = NOT_APPLICABLE
        out["reason"] = (f"the company reported a loss in {row['fiscal_year'] or row['period_end']}"
                         " — a price/earnings ratio has no meaning against negative earnings")
        return out

    out["pe"] = round(price / row["eps"], 4)
    out["status"] = "OK"
    out["implausible"] = not (IMPLAUSIBLE_BELOW <= out["pe"] <= IMPLAUSIBLE_ABOVE)
    if out["implausible"]:
        out["reason"] = (
            f"a price/earnings ratio of {out['pe']:.2f} is outside the range this app treats as "
            f"credible for a large listed company ({IMPLAUSIBLE_BELOW:g}–{IMPLAUSIBLE_ABOVE:g}). "
            f"The inputs were a raw close of {price} on {price_date} and diluted EPS of "
            f"{row['eps']} for the year to {row['period_end']}, filed {row['filed']}. Check the "
            "filing for a split, a restatement or a units error before believing this number.")
    return out


def historical_avg_pe(db, ticker: str, raw_bars: list) -> dict:
    """The company's own average P/E, month by month, using only what was public each month.

    Each month-end pairs that month's raw close with the last annual EPS published by then. Months
    where the company had reported a loss are excluded from the mean and counted separately: a
    negative P/E is not a cheap one, and averaging it in would drag the benchmark towards zero and
    make everything afterwards look expensive.
    """
    out = {"hist_avg_pe": None, "months_used": 0, "months_loss_making": 0,
           "months_no_filing": 0, "first": None, "last": None, "reason": None}
    timeline = eps_timeline(db, ticker)
    if not timeline:
        out["reason"] = "no annual filings stored, so no history of the multiple can be built"
        return out

    vals = []
    for ts, price in me.month_end_samples(raw_bars, field="close_raw"):
        row = known_at(timeline, ts)
        if row is None:
            out["months_no_filing"] += 1
            continue
        if row["currency"] and row["currency"] != "USD":
            out["months_no_filing"] += 1
            continue
        if row["eps"] <= 0:
            out["months_loss_making"] += 1
            continue
        vals.append((ts, price / row["eps"]))

    out["months_used"] = len(vals)
    if len(vals) < MIN_MONTHS_FOR_HISTORY:
        out["reason"] = (f"only {len(vals)} months of comparable history — at least "
                         f"{MIN_MONTHS_FOR_HISTORY} are required before an average is quoted")
        return out
    out["first"], out["last"] = vals[0][0], vals[-1][0]
    out["hist_avg_pe"] = round(sum(v for _, v in vals) / len(vals), 6)
    return out


def valuation_for_stock(db, ticker: str, raw_bars: list) -> dict:
    """The P/E block the monthly page renders, on the SAME bands the funds already use.

    The bands are the workbook's, unchanged. Nothing is re-tuned here because a company is being
    measured instead of a fund — a threshold moved to make the output look better would be exactly
    the optimisation this project does not do.
    """
    cur = current_pe(db, ticker, raw_bars)
    hist = historical_avg_pe(db, ticker, raw_bars)

    block = me.valuation_vs_history(cur["pe"], hist["hist_avg_pe"])

    # A loss-making company is NOT APPLICABLE, not MISSING, and that distinction survives here.
    if cur["status"] == NOT_APPLICABLE:
        block["status"] = NOT_APPLICABLE
    if block["status"] in (MISSING, NOT_APPLICABLE) and not block.get("reason"):
        block["reason"] = cur["reason"] or hist["reason"]
    elif block["status"] == MISSING:
        block["reason"] = cur["reason"] or hist["reason"] or block["reason"]

    block["basis"] = ("Last quoted price divided by diluted earnings per share from the most "
                      "recent ANNUAL report — a full-year figure, not a trailing twelve months, "
                      "so it will differ from the P/E quoted on financial websites.")
    block["eps"] = cur["eps"]
    block["eps_basis"] = cur["eps_basis"]
    block["eps_fiscal_year"] = cur["fiscal_year"]
    block["eps_period_end"] = cur["period_end"]
    block["eps_filed"] = cur["filed"]
    block["eps_age_days"] = cur["eps_age_days"]
    block["price_used"] = cur["price"]
    block["price_date"] = cur["price_date"]
    block["price_basis"] = "raw (unadjusted) close, to match as-reported earnings"
    block["hist_months_used"] = hist["months_used"]
    block["hist_window"] = ([hist["first"], hist["last"]]
                            if hist["first"] and hist["last"] else None)
    block["hist_months_loss_making"] = hist["months_loss_making"]
    block["hist_reason"] = hist["reason"]

    # The warning outranks the verdict. A P/E of 1.24 would otherwise be scored CHEAP in green,
    # which is the exact shape of the mistake this rail exists to catch.
    if cur.get("implausible"):
        block["implausible"] = True
        block["status"] = "CHECK THIS"
        block["reason"] = cur["reason"]
    return block


def diagnose(db, ticker: str, raw_bars: list) -> dict:
    """Why a row is blank, in one place, so the answer is on screen rather than guessed at."""
    tl = eps_timeline(db, ticker)
    months = me.month_end_samples(raw_bars, field="close_raw")
    return {
        "ticker": ticker.upper(),
        "annual_filings_stored": fh.count(db, ticker),
        "filings_with_usable_eps": len(tl),
        "newest_filing": tl[-1]["filed"] if tl else None,
        "newest_fiscal_period": max((r["period_end"] for r in tl), default=None),
        "raw_price_months": len(months),
        "raw_price_first": months[0][0] if months else None,
        "raw_price_last": months[-1][0] if months else None,
    }
