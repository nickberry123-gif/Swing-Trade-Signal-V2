"""
52-week / 200MA pattern-test routes.

Same background-thread + polling shape as the backtest, and for the same reason: the analysis
scores all 15 tickers on every month-start across five years, which takes minutes. A
synchronous request would be killed by the worker timeout and the client would get an HTML error
page where it expected JSON.
"""
import json
import logging
import threading

from flask import Blueprint, jsonify, request

import database
from config import Config
from db import get_db
from services.bars_service import BACKTEST_LOOKBACK_DAYS, get_bars_df
from services.pattern_service import run_pattern_test
from services.signals_service import TICKERS

logger = logging.getLogger(__name__)
bp = Blueprint("api_pattern", __name__, url_prefix="/api/pattern-test")


def _run_in_background(app, run_id: int, tickers: list, config: dict):
    with app.app_context():
        # A g-scoped connection belongs to the request that opened it and is closed the moment
        # that request returns — which is immediately here — so this thread opens its own.
        db = database.connect(Config.DATABASE_URL, Config.DATABASE_PATH)
        try:
            bars_by_ticker = {}
            needed = list(dict.fromkeys(
                tickers + (["SPY", "QQQ"] if config.get("use_regime", True) else [])))
            for t in needed:
                df, _meta = get_bars_df(db, t, "1Day", lookback_days=BACKTEST_LOOKBACK_DAYS)
                if not df.empty:
                    bars_by_ticker[t] = df.reset_index(drop=True)
            if not bars_by_ticker:
                raise RuntimeError("No historical bar data available to analyse.")

            result = run_pattern_test(bars_by_ticker, tickers, config)
            db.execute(
                "UPDATE pattern_runs SET results_json=?, status='complete' WHERE id=?",
                (json.dumps(result), run_id))
            db.commit()
        except Exception as e:  # noqa: BLE001 — must be recorded, never lost silently
            logger.exception("Pattern run %s failed", run_id)
            try:
                db.rollback()
                db.execute("UPDATE pattern_runs SET status='failed', error=? WHERE id=?",
                           (str(e), run_id))
                db.commit()
            except Exception:  # noqa: BLE001
                pass
        finally:
            db.close()


@bp.get("/runs")
def list_runs():
    rows = get_db().execute(
        "SELECT id, created_at, status, error FROM pattern_runs "
        "ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify({"runs": [dict(r) for r in rows]})


@bp.get("/runs/<int:run_id>")
def get_run(run_id):
    row = get_db().execute(
        "SELECT id, created_at, status, error, config_json, results_json "
        "FROM pattern_runs WHERE id = ?", (run_id,)).fetchone()
    if row is None:
        return jsonify({"error": f"No pattern run with id {run_id}"}), 404
    run = dict(row)
    for key in ("config_json", "results_json"):
        if run.get(key):
            try:
                run[key.replace("_json", "")] = json.loads(run[key])
            except (TypeError, ValueError):
                pass
        run.pop(key, None)
    return jsonify(run)


@bp.post("/run")
def run():
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca API credentials not configured — no historical bars "
                                 "available to analyse."}), 200

    payload = request.get_json(silent=True) or {}
    tickers = [t for t in (payload.get("tickers") or TICKERS) if t in TICKERS]
    if not tickers:
        return jsonify({"error": "No valid tickers from the tracked universe were requested."}), 400

    config = {
        "use_regime": bool(payload.get("use_regime", True)),
        "sell_pct_below_200ma": float(payload.get("sell_pct_below_200ma", 5.0)),
        "buy_pct_above_200ma": float(payload.get("buy_pct_above_200ma", 5.0)),
        "sell_pct_below_52w_high": float(payload.get("sell_pct_below_52w_high", 5.0)),
        "cash_rate_pct": float(payload.get("cash_rate_pct", 0.0)),
    }

    db = get_db()
    run_id = db.insert_returning_id(
        "INSERT INTO pattern_runs (config_json, status) VALUES (?, 'running')",
        (json.dumps(config),))
    db.commit()

    from flask import current_app
    threading.Thread(target=_run_in_background,
                     args=(current_app._get_current_object(), run_id, tickers, config),
                     daemon=True).start()

    return jsonify({"run_id": run_id, "status": "running",
                    "note": "Poll /api/pattern-test/runs/<id> until status is no longer 'running'."}), 202
