"""
Phase 8 + 9 routes: alerts (informational only) and plain-English explanations.

There is deliberately no endpoint here that acts on an alert. Alerts are read, acknowledged,
and nothing else.
"""
from flask import Blueprint, jsonify, request

from db import get_db
from services.alert_service import (acknowledge, acknowledge_all, evaluate_all, get_alerts,
                                    unacknowledged_count)
from services.explanation_service import generate_explanation
from services.fundamentals_service import get_earnings_info
from services.portfolio_service import get_position_quantity
from services.signals_service import TICKERS, compute_all_signals, compute_signal_for_ticker

bp = Blueprint("api_alerts", __name__, url_prefix="/api")


@bp.get("/alerts")
def list_alerts():
    db = get_db()
    return jsonify({
        "alerts": get_alerts(db, unacknowledged_only=request.args.get("unread") == "1",
                             limit=int(request.args.get("limit", 100))),
        "unacknowledged": unacknowledged_count(db),
    })


@bp.post("/alerts/evaluate")
def run_evaluation():
    """Recompute signals and raise any alerts they trigger. Explicitly user/schedule-triggered
    rather than running on page load, so alert generation is never a surprise side effect."""
    db = get_db()
    signals = compute_all_signals(db, persist=True)
    holdings, earnings = {}, {}
    for s in signals:
        t = s.get("ticker")
        # Each of these rolls back on failure: PostgreSQL aborts the whole transaction on the
        # first failed statement, so swallowing an error without rolling back would break every
        # subsequent ticker in this loop.
        try:
            holdings[t] = get_position_quantity(db, t)
        except Exception:  # noqa: BLE001
            db.rollback()
            holdings[t] = 0.0
        if holdings[t] > 0:
            try:
                earnings[t] = get_earnings_info(db, t)
            except Exception:  # noqa: BLE001
                db.rollback()
                earnings[t] = None
    result = evaluate_all(db, signals, holdings, earnings)
    result["unacknowledged"] = unacknowledged_count(db)
    return jsonify(result)


@bp.post("/alerts/<int:alert_id>/acknowledge")
def ack(alert_id):
    db = get_db()
    if not acknowledge(db, alert_id):
        return jsonify({"error": "Alert not found"}), 404
    return jsonify({"acknowledged": alert_id})


@bp.post("/alerts/acknowledge-all")
def ack_all():
    return jsonify({"acknowledged": acknowledge_all(get_db())})


@bp.get("/explain/<ticker>")
def explain(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked 15-stock universe"}), 404
    db = get_db()
    signal = compute_signal_for_ticker(db, ticker)
    prefer_llm = request.args.get("llm") == "1"
    return jsonify(generate_explanation(db, signal, prefer_llm=prefer_llm))
