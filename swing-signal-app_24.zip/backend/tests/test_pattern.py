"""
Tests for services/pattern_service.py — the 52-week / 200MA rule.

This pattern is unusually easy to test dishonestly. It was first described as "if the 200MA
holds, price returns to the high", and "it held" is only knowable afterwards. A single careless
line — using the series maximum instead of a trailing window, or filling at the signal bar's
close — turns it into a rule that reads the future and prints a spectacular result. Most of these
tests exist to prove that has not happened.
"""
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import pattern_service as ps


def frame(closes, highs=None, lows=None, opens=None):
    n = len(closes)
    closes = np.asarray(closes, dtype="float64")
    ts = [(datetime(2020, 1, 1) + timedelta(days=i)).date().isoformat() for i in range(n)]
    return pd.DataFrame({
        "ts": ts,
        "open": np.asarray(opens if opens is not None else closes, dtype="float64"),
        "high": np.asarray(highs if highs is not None else closes, dtype="float64"),
        "low": np.asarray(lows if lows is not None else closes, dtype="float64"),
        "close": closes,
        "volume": np.full(n, 1_000_000.0),
    })


def v_shape(n=900, start=100.0, bottom_at=400, low=40.0, top=200.0):
    """Falls to a low, then recovers past the old level — the pattern's ideal case."""
    down = np.linspace(start, low, bottom_at)
    up = np.linspace(low, top, n - bottom_at)
    return np.concatenate([down, up])


class TestCausality(unittest.TestCase):
    """If any of these fail, every number the page produces is void."""

    def test_52_week_low_uses_a_trailing_window_not_the_whole_series(self):
        """The classic version of this bug: `df.low.min()` instead of a rolling minimum. It makes
        the 52-week low the low of ALL history including the future, so nothing ever triggers
        until the exact global bottom — which looks like uncanny timing."""
        df = frame(v_shape())
        lv = ps._levels(df)
        # Sampled BEFORE the bottom, so the trailing window cannot contain the global minimum.
        # The first version sampled after it, where the two coincide and the test proved nothing.
        mid = 350
        expected = float(df["low"].iloc[mid - ps.LOOKBACK_52W + 1:mid + 1].min())
        self.assertAlmostEqual(float(lv["low_52w"].iloc[mid]), expected, places=9)
        self.assertGreater(float(lv["low_52w"].iloc[mid]), float(df["low"].min()),
                           "the trailing low equals the all-time low — window is not trailing")

    def test_levels_at_bar_i_are_unchanged_by_later_bars(self):
        base = frame(v_shape())
        tampered = base.copy()
        tampered.loc[tampered.index[-100:], ["open", "high", "low", "close"]] *= 7.0
        a, b = ps._levels(base), ps._levels(tampered)
        cutoff = len(base) - 120
        for col in ("sma200", "low_52w", "high_52w"):
            pd.testing.assert_series_equal(a[col].iloc[:cutoff], b[col].iloc[:cutoff],
                                           check_names=False)

    def test_future_bars_cannot_change_earlier_trades(self):
        base = frame(v_shape())
        tampered = base.copy()
        tampered.loc[tampered.index[-80:], ["open", "high", "low", "close"]] *= 5.0
        a = ps.simulate_ticker("X", base)["trades"]
        b = ps.simulate_ticker("X", tampered)["trades"]
        cutoff = str(base["ts"].iloc[-120])
        early_a = [t for t in a if t["entry_date"] < cutoff]
        early_b = [t for t in b if t["entry_date"] < cutoff]
        self.assertEqual([t["entry_date"] for t in early_a], [t["entry_date"] for t in early_b])
        for x, y in zip(early_a, early_b):
            self.assertAlmostEqual(x["entry_price"], y["entry_price"], places=9)

    def test_every_fill_is_the_bar_after_the_signal(self):
        df = frame(v_shape())
        out = ps.simulate_ticker("X", df)
        ts = list(df["ts"].astype(str))
        for t in out["trades"]:
            self.assertEqual(ts.index(t["entry_date"]), ts.index(t["signal_date"]) + 1)

    def test_no_signal_before_a_full_year_of_history(self):
        df = frame(v_shape())
        ts = list(df["ts"].astype(str))
        for t in ps.simulate_ticker("X", df)["trades"]:
            self.assertGreaterEqual(ts.index(t["signal_date"]), ps.MIN_WARMUP)

    def test_a_52_week_low_needs_a_full_year_of_bars_to_be_defined(self):
        """min_periods must equal the window, or the first weeks of data would each declare a
        '52-week low' computed from a fortnight."""
        lv = ps._levels(frame(v_shape(n=400)))
        self.assertTrue(lv["low_52w"].iloc[:ps.LOOKBACK_52W - 1].isna().all())
        self.assertFalse(pd.isna(lv["low_52w"].iloc[ps.LOOKBACK_52W]))


class TestStateMachine(unittest.TestCase):
    def test_the_four_steps_happen_in_order(self):
        out = ps.simulate_ticker("X", frame(v_shape()))
        legs = [t["leg"] for t in out["trades"]]
        self.assertIn(1, legs, "leg 1 never triggered on a fixture designed to trigger it")
        for a, b in zip(out["trades"], out["trades"][1:]):
            self.assertLessEqual(a["exit_date"], b["entry_date"],
                                 "two positions were open at the same time")

    def test_leg1_sells_when_price_reaches_the_band_below_the_200ma(self):
        out = ps.simulate_ticker("X", frame(v_shape()),
                                 {"sell_pct_below_200ma": 5.0})
        leg1 = [t for t in out["trades"] if t["leg"] == 1 and "200MA" in t["exit_reason"]]
        self.assertTrue(leg1, "leg 1 never sold into the 200MA")

    def test_leg2_only_exists_after_leg1_has_closed(self):
        out = ps.simulate_ticker("X", frame(v_shape()))
        for t in out["trades"]:
            if t["leg"] == 2:
                earlier = [x for x in out["trades"]
                           if x["leg"] == 1 and x["exit_date"] <= t["entry_date"]]
                self.assertTrue(earlier, "a leg-2 entry happened with no completed leg 1")

    def test_every_52_week_low_is_counted_even_while_already_holding(self):
        """The event counter answers 'how often did this setup occur', not 'how often did we
        act on it'. A stock making lower lows while the rule already holds it must still be
        counted, or the page's '52-week lows hit' figure is not what it says it is."""
        falling = np.concatenate([np.linspace(100, 60, 300), np.linspace(60, 5, 600)])
        out = ps.simulate_ticker("X", frame(falling))
        self.assertGreater(out["events"]["new_52w_low"], 10)
        self.assertEqual(out["events"]["leg1_entries"], 1)   # only one could be acted on

    def test_a_fresh_low_while_waiting_restarts_the_sequence(self):
        """Price bounces, fails before the 200MA break, and makes a lower low. The rule must
        re-enter at the new low rather than sit in ARMED forever."""
        down = np.linspace(100, 50, 400)
        bounce = np.linspace(50, 62, 60)
        lower = np.linspace(62, 30, 200)
        recover = np.linspace(30, 150, 300)
        out = ps.simulate_ticker("X", frame(np.concatenate([down, bounce, lower, recover])))
        self.assertGreaterEqual(out["events"]["new_52w_low"], 2)

    def test_a_position_with_no_trigger_left_is_reported_open_not_dropped(self):
        """There is no stop-loss. A stock that keeps falling must show as an open-ended hold
        rather than silently vanishing from the results."""
        falling = np.concatenate([np.linspace(100, 60, 300), np.linspace(60, 5, 600)])
        out = ps.simulate_ticker("X", frame(falling))
        self.assertTrue(any(t["exit_reason"] == "STILL_OPEN_AT_END" for t in out["trades"]))

    def test_a_stock_that_only_rises_never_triggers(self):
        out = ps.simulate_ticker("X", frame(np.linspace(50, 400, 900)))
        self.assertEqual(out["events"]["new_52w_low"], 0)
        self.assertEqual(out["trades"], [])


class TestThresholdsMatter(unittest.TestCase):
    def test_a_wider_sell_band_exits_earlier(self):
        df = frame(v_shape())
        tight = ps.simulate_ticker("X", df, {"sell_pct_below_200ma": 0.5})["trades"]
        wide = ps.simulate_ticker("X", df, {"sell_pct_below_200ma": 20.0})["trades"]
        t1 = next(t for t in tight if t["leg"] == 1)
        w1 = next(t for t in wide if t["leg"] == 1)
        self.assertLessEqual(w1["exit_date"], t1["exit_date"])

    def test_a_higher_break_level_delays_the_second_entry(self):
        df = frame(v_shape())
        low = ps.simulate_ticker("X", df, {"buy_pct_above_200ma": 1.0})["trades"]
        high = ps.simulate_ticker("X", df, {"buy_pct_above_200ma": 25.0})["trades"]
        l2 = [t for t in low if t["leg"] == 2]
        h2 = [t for t in high if t["leg"] == 2]
        if l2 and h2:
            self.assertGreaterEqual(h2[0]["entry_date"], l2[0]["entry_date"])


class TestHonestReporting(unittest.TestCase):
    def test_clustered_entries_produce_a_warning(self):
        result = {
            "clustering": {"entries": 15, "distinct_months": 2, "busiest_month": "2022-10",
                           "busiest_month_share_pct": 80.0, "first": "2022-09", "last": "2022-10"},
            "overall": {"trades": 15, "mean_pct": 40.0},
            "trades": [], "buy_and_hold_benchmark": {"return_pct": 100.0},
        }
        warnings = " ".join(ps._warnings(result)).lower()
        self.assertIn("not independent", warnings)
        self.assertIn("2022-10", warnings)

    def test_a_small_sample_produces_a_warning(self):
        result = {"clustering": {"entries": 8, "distinct_months": 8, "busiest_month": "2022-10",
                                 "busiest_month_share_pct": 12.5, "first": "a", "last": "b"},
                  "overall": {"trades": 8, "mean_pct": 30.0},
                  "trades": [], "buy_and_hold_benchmark": {"return_pct": 100.0}}
        self.assertTrue(any("noise" in w.lower() for w in ps._warnings(result)))

    def test_no_trades_says_so_rather_than_showing_zeros(self):
        result = {"clustering": {"entries": 0, "distinct_months": 0, "busiest_month": None,
                                 "busiest_month_share_pct": None, "first": None, "last": None},
                  "overall": {"trades": 0, "mean_pct": None},
                  "trades": [], "buy_and_hold_benchmark": {"return_pct": 10.0}}
        self.assertIn("never triggered", ps._warnings(result)[0])

    def test_clustering_counts_distinct_months(self):
        trades = [{"entry_date": "2022-10-05"}, {"entry_date": "2022-10-20"},
                  {"entry_date": "2023-04-01"}]
        c = ps._clustering(trades)
        self.assertEqual(c["distinct_months"], 2)
        self.assertEqual(c["busiest_month"], "2022-10")
        self.assertAlmostEqual(c["busiest_month_share_pct"], 66.7, places=1)

    def test_survivorship_warning_is_first(self):
        self.assertIn("SURVIVORSHIP", ps.LIMITATIONS[0])

    def test_no_stop_loss_is_stated(self):
        self.assertTrue(any("STOP-LOSS" in l for l in ps.LIMITATIONS))


class TestRunPatternTest(unittest.TestCase):
    def test_end_to_end(self):
        bars = {"AAA": frame(v_shape(seed_shift := 0) if False else v_shape()),
                "BBB": frame(np.linspace(50, 400, 900))}
        out = ps.run_pattern_test(bars, ["AAA", "BBB"])
        self.assertIn("events", out)
        self.assertIn("clustering", out)
        self.assertIn("warnings", out)
        self.assertIn("AAA", out["by_ticker"])
        self.assertIsNotNone(out["buy_and_hold_benchmark"]["return_pct"])

    def test_short_history_is_skipped_not_guessed_at(self):
        out = ps.run_pattern_test({"AAA": frame(np.linspace(100, 50, 100))}, ["AAA"])
        self.assertIn("AAA", out["tickers_skipped"])

    def test_the_rule_is_stated_in_the_result(self):
        out = ps.run_pattern_test({"AAA": frame(v_shape())}, ["AAA"])
        self.assertEqual(len(out["config"]["rule"]), 5)
        self.assertIn("52-week low", out["config"]["rule"][0])


class TestPageWiring(unittest.TestCase):
    def setUp(self):
        import app as app_module
        self.client = app_module.create_app().test_client()

    def test_page_renders_and_is_in_the_nav(self):
        self.assertEqual(self.client.get("/pattern-test").status_code, 200)
        self.assertIn(b'href="/pattern-test"', self.client.get("/").data)

    def test_script_exists(self):
        frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
        self.assertIn("js/pattern_test.js",
                      (frontend / "templates" / "pattern_test.html").read_text())
        self.assertTrue((frontend / "static" / "js" / "pattern_test.js").exists())

    def test_unknown_run_is_404(self):
        self.assertEqual(self.client.get("/api/pattern-test/runs/999999").status_code, 404)


class TestMatchedEntryComparison(unittest.TestCase):
    """The comparison that answers "should I have just held?".

    The fixed-date buy-and-hold benchmark answers a portfolio question and the rule loses it
    automatically, because it is only invested part of the time. This one starts BOTH arms on
    the same day with the same money, so the only difference left is the decision to sell.
    """

    def test_both_arms_start_on_the_same_day_and_price(self):
        df = frame(v_shape())
        trades = ps.simulate_ticker("X", df)["trades"]
        m = ps._matched_comparison(trades, df)
        first = sorted(trades, key=lambda t: t["entry_index"])[0]
        self.assertEqual(m["from_date"], str(df["ts"].iloc[first["entry_index"]]))
        # The hold arm must use the rule's own fill, not some other price on that day.
        last = float(df["close"].iloc[-1])
        # places=2 because the reported figure is rounded for display; the point of the test is
        # that the hold arm uses the RULE'S OWN FILL, not a different price on the same day.
        self.assertAlmostEqual(m["hold_pct"],
                               (last - first["entry_price"]) / first["entry_price"] * 100,
                               places=2)

    def test_both_arms_end_on_the_same_day(self):
        df = frame(v_shape())
        m = ps._matched_comparison(ps.simulate_ticker("X", df)["trades"], df)
        self.assertEqual(m["to_date"], str(df["ts"].iloc[-1]))

    def test_a_single_trade_held_to_the_end_ties_with_holding(self):
        """If the rule buys once and never sells, it IS holding, so the difference must be zero.
        Any other answer means the two arms are not being measured the same way."""
        falling = np.concatenate([np.linspace(100, 60, 300), np.linspace(60, 5, 600)])
        df = frame(falling)
        trades = ps.simulate_ticker("X", df)["trades"]
        self.assertEqual(len(trades), 1)
        self.assertEqual(trades[0]["exit_reason"], "STILL_OPEN_AT_END")
        m = ps._matched_comparison(trades, df)
        self.assertAlmostEqual(m["difference_pct"], 0.0, places=4)

    def test_idle_cash_rate_only_helps_the_rule(self):
        df = frame(v_shape())
        trades = ps.simulate_ticker("X", df)["trades"]
        zero = ps._matched_comparison(trades, df, 0.0)
        paid = ps._matched_comparison(trades, df, 5.0)
        self.assertGreaterEqual(paid["strategy_pct"], zero["strategy_pct"])
        self.assertEqual(paid["hold_pct"], zero["hold_pct"])   # holding has no idle cash

    def test_time_in_market_is_between_zero_and_one_hundred(self):
        df = frame(v_shape())
        m = ps._matched_comparison(ps.simulate_ticker("X", df)["trades"], df)
        self.assertGreaterEqual(m["time_in_market_pct"], 0)
        self.assertLessEqual(m["time_in_market_pct"], 100.5)

    def test_no_trades_gives_none_rather_than_a_fake_tie(self):
        self.assertIsNone(ps._matched_comparison([], frame(v_shape())))

    def test_aggregate_is_equal_weight_across_stocks(self):
        per = {
            "LOUD": {"matched": {"strategy_pct": 10.0, "hold_pct": 0.0, "difference_pct": 10.0,
                                 "time_in_market_pct": 50.0}},
            "QUIET": {"matched": {"strategy_pct": 0.0, "hold_pct": 100.0, "difference_pct": -100.0,
                                  "time_in_market_pct": 10.0}},
        }
        agg = ps._aggregate_matched(per)
        self.assertEqual(agg["difference_pct"], -45.0)     # (10 + -100) / 2
        self.assertEqual(agg["stocks_where_rule_won"], 1)
        self.assertEqual(agg["stocks"], 2)

    def test_benchmark_reports_its_start_date(self):
        """A benchmark whose start date is hidden looks rigged even when it is not."""
        out = ps.run_pattern_test({"AAA": frame(v_shape())}, ["AAA"])
        bh = out["buy_and_hold_benchmark"]
        self.assertIsNotNone(bh["start_date"])
        self.assertIn("one fixed date", bh["note"])

    def test_run_includes_the_matched_comparison(self):
        out = ps.run_pattern_test({"AAA": frame(v_shape())}, ["AAA"])
        self.assertIsNotNone(out["matched_entry_comparison"])
        self.assertIn("matched", out["by_ticker"]["AAA"])
        self.assertIn("per_trade_vs_hold", out["by_ticker"]["AAA"])


class TestPerTradeVsHold(unittest.TestCase):
    def test_counts_how_often_the_sell_beat_holding(self):
        df = frame(v_shape())
        trades = ps.simulate_ticker("X", df)["trades"]
        v = ps._per_trade_vs_hold(trades, df)
        self.assertEqual(v["n"], len([t for t in trades if t.get("return_pct") is not None]))
        self.assertGreaterEqual(v["rule_better_pct"], 0)
        self.assertLessEqual(v["rule_better_pct"], 100)

    def test_empty_is_zero_not_a_crash(self):
        self.assertEqual(ps._per_trade_vs_hold([], frame(v_shape()))["n"], 0)


if __name__ == "__main__":
    unittest.main()
