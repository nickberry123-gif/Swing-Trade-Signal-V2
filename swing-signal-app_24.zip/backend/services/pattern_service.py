"""
The 52-week / 200-day-average pattern, tested exactly as described.

THE RULE
--------
  1. New 52-week low            -> BUY
  2. Price reaches 5% BELOW the 200MA (rising into it)   -> SELL   (take the bounce)
  3. Price reaches 5% ABOVE the 200MA (break confirmed)  -> BUY
  4. Price reaches 5% BELOW the 52-week high             -> SELL   (out before resistance)

Every threshold is adjustable. The sequence is a state machine per ticker: a 52-week low arms
it, and it walks forward through the four steps. Two positions are never open at once.

WHY THIS IS TESTABLE AND "IF IT HOLDS" WAS NOT
----------------------------------------------
The idea was first described as "if the 200MA holds, price goes back to the high". You only know
it held afterwards, so coding that literally would peek at the future and produce a beautiful,
worthless result. Every trigger here is instead a price LEVEL that is either reached on a given
day or not — knowable at that day's close, acted on at the next day's open. The question "did it
hold?" is answered by the forward return, never by the entry rule.

THE THREE CAUSALITY GUARANTEES
------------------------------
1. `rolling(252).min()` at row i uses rows i-251..i only. Pandas rolling windows are
   backward-looking by construction, so the 52-week low on a given day is the low as it was
   known that day, not the low of the whole series.
2. A trigger detected on bar i is FILLED at bar i+1's open. You cannot trade a close you have
   just watched print.
3. The state machine only ever reads the current bar. It has no access to later rows.

WHAT THIS TEST WILL PROBABLY SAY, AND WHY THE COUNTS COME FIRST
---------------------------------------------------------------
All 15 of these companies fell in 2022 and have mostly risen since, so 52-week lows are likely
to be clustered in a single stretch of months. Fifteen trades all entered within one quarter of
each other are not fifteen independent observations — they are one observation about one market
event, wearing a sample size. The result therefore reports the event count and the clustering
BEFORE any return figure, because if the pattern only fires eleven times no return number on the
page means anything.
"""
import logging
from datetime import datetime, timezone

import pandas as pd

log = logging.getLogger(__name__)

LOOKBACK_52W = 252          # trading days in a year
MA_PERIOD = 200
MIN_WARMUP = 252            # need a full year before a "52-week low" means anything

DEFAULTS = {
    "cash_rate_pct": 0.0,           # what idle cash earns between trades, annualised

    "sell_pct_below_200ma": 5.0,     # step 2: sell when price rises to within this of the 200MA
    "buy_pct_above_200ma": 5.0,      # step 3: buy when price gets this far above the 200MA
    "sell_pct_below_52w_high": 5.0,  # step 4: sell when price gets this close to the 52-week high
}


def _levels(df: pd.DataFrame) -> pd.DataFrame:
    """200-day average and trailing 52-week high/low, all strictly backward-looking."""
    out = pd.DataFrame(index=df.index)
    out["close"] = df["close"].astype(float)
    out["open"] = df["open"].astype(float)
    out["sma200"] = out["close"].rolling(MA_PERIOD).mean()
    # min_periods equal to the window: a "52-week low" computed from 30 bars is not one.
    out["low_52w"] = df["low"].astype(float).rolling(LOOKBACK_52W, min_periods=LOOKBACK_52W).min()
    out["high_52w"] = df["high"].astype(float).rolling(LOOKBACK_52W, min_periods=LOOKBACK_52W).max()
    return out


def simulate_ticker(ticker: str, df: pd.DataFrame, config: dict | None = None) -> dict:
    """Walk the state machine over one ticker. Returns trades plus why it did what it did."""
    cfg = {**DEFAULTS, **(config or {})}
    lv = _levels(df.reset_index(drop=True))
    ts = df["ts"].reset_index(drop=True)

    sell_below = cfg["sell_pct_below_200ma"] / 100.0
    buy_above = cfg["buy_pct_above_200ma"] / 100.0
    sell_near_high = cfg["sell_pct_below_52w_high"] / 100.0

    trades = []
    events = {"new_52w_low": 0, "leg1_entries": 0, "leg1_exits": 0,
              "leg2_entries": 0, "leg2_exits": 0}
    state = "FLAT"          # FLAT -> LONG_1 -> ARMED (waiting for the break) -> LONG_2 -> FLAT
    open_trade = None

    n = len(lv)
    for i in range(MIN_WARMUP, n - 1):      # -1: every fill needs a NEXT bar
        close = lv["close"].iloc[i]
        sma200 = lv["sma200"].iloc[i]
        low52 = lv["low_52w"].iloc[i]
        high52 = lv["high_52w"].iloc[i]
        if pd.isna(sma200) or pd.isna(low52) or pd.isna(high52):
            continue

        next_open = float(lv["open"].iloc[i + 1])
        date, next_date = str(ts.iloc[i]), str(ts.iloc[i + 1])

        # A new 52-week low means today's low IS the trailing 252-day low.
        at_new_low = float(df["low"].iloc[i]) <= low52 * 1.0000001
        # Counted here, ONCE, regardless of state. The first version incremented this only when
        # a low produced an entry, so a stock that kept making lower lows while already held
        # reported "1 new 52-week low" for a year of them — and the page labelled that number
        # "52-week lows hit". How often the setup OCCURS and how often it can be ACTED ON are
        # different questions, and the second one is not an honest answer to the first.
        if at_new_low:
            events["new_52w_low"] += 1

        if state == "FLAT":
            if at_new_low:
                events["leg1_entries"] += 1
                open_trade = {"ticker": ticker, "leg": 1, "signal_date": date,
                              "entry_date": next_date, "entry_price": round(next_open, 4),
                              "entry_reason": "NEW_52W_LOW", "entry_index": i + 1}
                state = "LONG_1"
            continue

        if state == "LONG_1":
            # Step 2: price has risen back to within `sell_below` of the 200MA.
            if close >= sma200 * (1 - sell_below):
                events["leg1_exits"] += 1
                open_trade.update({
                    "exit_date": next_date, "exit_price": round(next_open, 4),
                    "exit_reason": f"REACHED_{cfg['sell_pct_below_200ma']}PCT_BELOW_200MA",
                    "return_pct": round((next_open - open_trade["entry_price"])
                                        / open_trade["entry_price"] * 100, 4),
                    "holding_days": i + 1 - open_trade["entry_index"], "exit_index": i + 1,
                })
                trades.append(open_trade)
                open_trade = None
                state = "ARMED"
            continue

        if state == "ARMED":
            # Step 3: the break. Price is now `buy_above` clear of the 200MA.
            if close >= sma200 * (1 + buy_above):
                events["leg2_entries"] += 1
                open_trade = {"ticker": ticker, "leg": 2, "signal_date": date,
                              "entry_date": next_date, "entry_price": round(next_open, 4),
                              "entry_reason": f"BROKE_{cfg['buy_pct_above_200ma']}PCT_ABOVE_200MA",
                              "entry_index": i + 1}
                state = "LONG_2"
            # If it makes a fresh 52-week low instead, the sequence has failed and restarts.
            elif at_new_low:
                events["leg1_entries"] += 1
                open_trade = {"ticker": ticker, "leg": 1, "signal_date": date,
                              "entry_date": next_date, "entry_price": round(next_open, 4),
                              "entry_reason": "NEW_52W_LOW", "entry_index": i + 1}
                state = "LONG_1"
            continue

        if state == "LONG_2":
            # Step 4: within `sell_near_high` of the 52-week high.
            if close >= high52 * (1 - sell_near_high):
                events["leg2_exits"] += 1
                open_trade.update({
                    "exit_date": next_date, "exit_price": round(next_open, 4),
                    "exit_reason": f"REACHED_{cfg['sell_pct_below_52w_high']}PCT_BELOW_52W_HIGH",
                    "return_pct": round((next_open - open_trade["entry_price"])
                                        / open_trade["entry_price"] * 100, 4),
                    "holding_days": i + 1 - open_trade["entry_index"], "exit_index": i + 1,
                })
                trades.append(open_trade)
                open_trade = None
                state = "FLAT"
            continue

    # A position with no trigger left is held to the end — there is no stop in this rule, so
    # this is a real outcome and is reported rather than quietly discarded.
    if open_trade is not None:
        last_close = float(lv["close"].iloc[-1])
        open_trade.update({
            "exit_date": str(ts.iloc[-1]), "exit_price": round(last_close, 4),
            "exit_reason": "STILL_OPEN_AT_END",
            "return_pct": round((last_close - open_trade["entry_price"])
                                / open_trade["entry_price"] * 100, 4),
            "holding_days": (n - 1) - open_trade["entry_index"], "exit_index": n - 1,
        })
        trades.append(open_trade)

    return {"trades": trades, "events": events, "bars": n}


def _index_of(ts: pd.Series, date_str: str) -> int:
    hits = ts.index[ts.astype(str) == date_str]
    return int(hits[0]) if len(hits) else 0


def _summarise(trades: list) -> dict:
    rets = [t["return_pct"] for t in trades if t.get("return_pct") is not None]
    if not rets:
        return {"trades": 0, "mean_pct": None, "median_pct": None, "win_rate_pct": None,
                "best_pct": None, "worst_pct": None, "avg_holding_days": None}
    s = pd.Series(rets, dtype="float64")
    holds = [t["holding_days"] for t in trades if t.get("holding_days") is not None]
    return {
        "trades": len(rets),
        "mean_pct": round(float(s.mean()), 2),
        "median_pct": round(float(s.median()), 2),
        "win_rate_pct": round(float((s > 0).mean() * 100), 1),
        "best_pct": round(float(s.max()), 2),
        "worst_pct": round(float(s.min()), 2),
        "avg_holding_days": round(sum(holds) / len(holds), 1) if holds else None,
    }


def _clustering(trades: list) -> dict:
    """How concentrated in time the entries are.

    This is the number that decides whether the rest of the page means anything. Fifteen trades
    all opened in the same quarter are one observation about one market event, not fifteen
    independent tests of a rule — and a win rate computed across them describes that quarter.
    """
    dates = sorted(str(t["entry_date"])[:7] for t in trades if t.get("entry_date"))
    if not dates:
        return {"entries": 0, "distinct_months": 0, "busiest_month": None,
                "busiest_month_share_pct": None, "first": None, "last": None}
    counts = {}
    for m in dates:
        counts[m] = counts.get(m, 0) + 1
    busiest = max(counts, key=counts.get)
    return {
        "entries": len(dates),
        "distinct_months": len(counts),
        "busiest_month": busiest,
        "busiest_month_share_pct": round(counts[busiest] / len(dates) * 100, 1),
        "first": dates[0],
        "last": dates[-1],
    }


def _matched_comparison(trades: list, df: pd.DataFrame, cash_rate_pct: float = 0.0) -> dict:
    """The comparison that actually answers "should I have just held?"

    The buy-and-hold benchmark elsewhere on this page buys on one fixed date and holds. That
    answers a portfolio question — is trading this rule better than owning these companies over
    this period — and the rule loses that automatically, because it is only invested about a
    fifth of the time. It is not the question a person asks about their own strategy.

    This is: starting on the SAME DAY the rule first bought this stock, and ending on the SAME
    DAY, does the rule's chain of buys and sells beat doing nothing? Same entry, same stock,
    same money. The only difference is whether you sold.

    Idle cash between trades earns `cash_rate_pct` a year, which is 0 by default. Zero is the
    conservative choice and it understates the rule — in reality money out of the market earns
    something — so the rate is exposed rather than assumed.
    """
    if not trades or df is None or len(df) == 0:
        return None

    ordered = sorted(trades, key=lambda t: t.get("entry_index", 0))
    first_i = ordered[0]["entry_index"]
    last_i = len(df) - 1
    last_close = float(df["close"].iloc[last_i])

    # Doing nothing: buy at the same fill the rule used for its first entry, never sell.
    hold_entry = float(ordered[0]["entry_price"])
    hold_return = (last_close - hold_entry) / hold_entry * 100 if hold_entry else None

    # The rule: compound each trade in sequence, with cash earning the given rate in the gaps.
    daily_cash = (1 + cash_rate_pct / 100.0) ** (1 / 252) - 1
    equity = 1.0
    cursor = first_i
    for t in ordered:
        gap = max(0, t["entry_index"] - cursor)
        equity *= (1 + daily_cash) ** gap
        equity *= (1 + (t.get("return_pct") or 0) / 100)
        cursor = t.get("exit_index", t["entry_index"])
    equity *= (1 + daily_cash) ** max(0, last_i - cursor)     # cash from the last exit to today
    strategy_return = (equity - 1) * 100

    return {
        "from_date": str(df["ts"].iloc[first_i]),
        "to_date": str(df["ts"].iloc[last_i]),
        "days": last_i - first_i,
        "trades": len(ordered),
        "strategy_pct": round(strategy_return, 2),
        "hold_pct": round(hold_return, 2) if hold_return is not None else None,
        "difference_pct": (round(strategy_return - hold_return, 2)
                           if hold_return is not None else None),
        "days_invested": sum(t.get("holding_days") or 0 for t in ordered),
        "time_in_market_pct": (round(sum(t.get("holding_days") or 0 for t in ordered)
                                     / max(1, last_i - first_i) * 100, 1)),
    }


def _per_trade_vs_hold(trades: list, df: pd.DataFrame) -> dict:
    """Trade by trade: what the rule made, versus buying that same day and never selling.

    A different slice of the same question. The sequence version above can be dominated by one
    stock's chain; this one asks how often an individual sell decision was the right call.
    """
    if not trades or df is None or len(df) == 0:
        return {"n": 0, "rule_better_pct": None, "mean_difference_pct": None}
    last_close = float(df["close"].iloc[len(df) - 1])
    diffs = []
    for t in trades:
        entry = float(t.get("entry_price") or 0)
        if entry <= 0 or t.get("return_pct") is None:
            continue
        held = (last_close - entry) / entry * 100
        diffs.append(t["return_pct"] - held)
    if not diffs:
        return {"n": 0, "rule_better_pct": None, "mean_difference_pct": None}
    s = pd.Series(diffs, dtype="float64")
    return {
        "n": len(diffs),
        "rule_better_pct": round(float((s > 0).mean() * 100), 1),
        "mean_difference_pct": round(float(s.mean()), 2),
        "median_difference_pct": round(float(s.median()), 2),
    }


def _buy_and_hold(bars_by_ticker: dict, tickers: list) -> dict:
    """The control: own the same stocks over the same window and do nothing."""
    rets = []
    for t in tickers:
        df = bars_by_ticker.get(t)
        if df is None or len(df) <= MIN_WARMUP:
            continue
        start = float(df["close"].iloc[MIN_WARMUP])
        end = float(df["close"].iloc[-1])
        if start:
            rets.append((end - start) / start * 100)
    start_date = None
    for t in tickers:
        df = bars_by_ticker.get(t)
        if df is not None and len(df) > MIN_WARMUP:
            start_date = str(df["ts"].iloc[MIN_WARMUP])
            break
    return {"return_pct": round(sum(rets) / len(rets), 2) if rets else None,
            "tickers": len(rets), "start_date": start_date,
            "note": ("Buys on one fixed date — the first day the rule was eligible to trade — "
                     "and never sells. It does no timing at all.")}


def _aggregate_matched(per_ticker: dict) -> dict:
    """Equal-weight across stocks — one number per company, then averaged.

    Pooling every trade instead would let whichever stock traded most often decide the answer,
    and that is a fact about trade frequency rather than about the rule.
    """
    rows = [v["matched"] for v in per_ticker.values() if v.get("matched")]
    if not rows:
        return None
    strat = [r["strategy_pct"] for r in rows if r["strategy_pct"] is not None]
    hold = [r["hold_pct"] for r in rows if r["hold_pct"] is not None]
    diffs = [r["difference_pct"] for r in rows if r["difference_pct"] is not None]
    tim = [r["time_in_market_pct"] for r in rows if r["time_in_market_pct"] is not None]
    beat = [d for d in diffs if d > 0]
    return {
        "stocks": len(rows),
        "strategy_pct": round(sum(strat) / len(strat), 2) if strat else None,
        "hold_pct": round(sum(hold) / len(hold), 2) if hold else None,
        "difference_pct": round(sum(diffs) / len(diffs), 2) if diffs else None,
        "stocks_where_rule_won": len(beat),
        "time_in_market_pct": round(sum(tim) / len(tim), 1) if tim else None,
        "note": ("Each stock is measured from the day the rule FIRST bought it to the last bar. "
                 "Same entry date, same stock, same end date — the only difference is whether "
                 "you sold."),
    }


def run_pattern_test(bars_by_ticker: dict, tickers: list, config: dict | None = None) -> dict:
    cfg = {**DEFAULTS, **(config or {})}
    per_ticker, all_trades, skipped = {}, [], {}
    totals = {"new_52w_low": 0, "leg1_entries": 0, "leg1_exits": 0,
              "leg2_entries": 0, "leg2_exits": 0}

    for t in tickers:
        df = bars_by_ticker.get(t)
        if df is None or len(df) < MIN_WARMUP + 30:
            skipped[t] = f"needs more than {MIN_WARMUP + 30} daily bars, has {0 if df is None else len(df)}"
            continue
        d = df.reset_index(drop=True)
        out = simulate_ticker(t, d, cfg)
        per_ticker[t] = {
            "summary": _summarise(out["trades"]),
            "events": out["events"],
            "matched": _matched_comparison(out["trades"], d, cfg.get("cash_rate_pct", 0.0)),
            "per_trade_vs_hold": _per_trade_vs_hold(out["trades"], d),
        }
        all_trades.extend(out["trades"])
        for k in totals:
            totals[k] += out["events"][k]

    leg1 = [t for t in all_trades if t["leg"] == 1]
    leg2 = [t for t in all_trades if t["leg"] == 2]
    tested = [t for t in tickers if t not in skipped]

    result = {
        "config": {**cfg, "rule": [
            "1. New 52-week low -> BUY (fill next open)",
            f"2. Price reaches {cfg['sell_pct_below_200ma']}% below the 200MA -> SELL",
            f"3. Price reaches {cfg['buy_pct_above_200ma']}% above the 200MA -> BUY",
            f"4. Price reaches {cfg['sell_pct_below_52w_high']}% below the 52-week high -> SELL",
            "No stop-loss: a position with no trigger left is held to the end of the data.",
        ]},
        "events": totals,
        "clustering": _clustering(all_trades),
        "overall": _summarise(all_trades),
        "leg1": _summarise(leg1),
        "leg2": _summarise(leg2),
        "by_ticker": per_ticker,
        "tickers_tested": tested,
        "tickers_skipped": skipped,
        "buy_and_hold_benchmark": _buy_and_hold(bars_by_ticker, tested),
        "matched_entry_comparison": _aggregate_matched(per_ticker),
        "trades": sorted(all_trades, key=lambda t: str(t.get("entry_date"))),
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
    result["warnings"] = _warnings(result)
    result["limitations"] = LIMITATIONS
    return result


def _warnings(result: dict) -> list:
    """Said loudly, at the top, before any return figure gets read."""
    out = []
    c = result["clustering"]
    n = result["overall"]["trades"]

    if n == 0:
        return ["The pattern never triggered. Nothing on this page can tell you anything about it."]
    if n < 30:
        out.append(f"Only {n} trades. Below about 30 these numbers are noise — a single good or "
                   f"bad trade moves the average materially.")
    if c["distinct_months"] and c["distinct_months"] <= 6:
        out.append(f"Every entry falls in just {c['distinct_months']} different months "
                   f"({c['first']} to {c['last']}). These are not independent observations: they "
                   f"describe one or two market events, not a repeatable rule.")
    if c["busiest_month_share_pct"] and c["busiest_month_share_pct"] >= 40:
        out.append(f"{c['busiest_month_share_pct']}% of all entries happened in the single month "
                   f"of {c['busiest_month']}. The result is largely a statement about what "
                   f"happened next after that one month.")

    still_open = [t for t in result["trades"] if t.get("exit_reason") == "STILL_OPEN_AT_END"]
    if still_open:
        out.append(f"{len(still_open)} position(s) never hit a sell trigger and are valued at the "
                   f"last close. With no stop-loss in this rule, those are open-ended holds.")

    bh = result["buy_and_hold_benchmark"].get("return_pct")
    mean = result["overall"]["mean_pct"]
    if bh is not None and mean is not None:
        out.append(f"Average per trade is {mean}%. Simply owning the same stocks over the whole "
                   f"window returned {bh}%. Those are not directly comparable — one is per trade, "
                   f"the other is the whole period — which is exactly why the trade count and the "
                   f"time in market matter more than the headline.")
    return out


LIMITATIONS = [
    "SURVIVORSHIP BIAS: every company here recovered. A rule that buys 52-week lows is "
    "flattered enormously by a universe containing no company that kept falling — and the "
    "expanded list makes this WORSE, not better: it includes several of the largest "
    "recoveries of the last three years and none of the failures alongside them.",
    "52-week lows in this universe cluster around one market episode. Clustered trades are not "
    "independent evidence, however many rows they produce.",
    "There is NO STOP-LOSS. A stock that keeps making lower lows is held indefinitely, and the "
    "test shows that as an open position rather than a loss.",
    "Fills use the next bar's open with no slippage, spread, commission or tax.",
    "Intrabar path is unknown: a trigger is judged on the day's close, so a level touched and "
    "reversed within a day may be missed, and a gap through a level fills at the gapped price.",
    "One market period. A rule built around 'it bounces back' has never been tested here on a "
    "decade where it did not.",
]
