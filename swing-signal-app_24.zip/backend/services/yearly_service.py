"""
Per-calendar-year average price for the tracked universe.

Answers one question: how has each company's typical trading price moved year by year, and
what is the average yearly step. That is deliberately NOT the same as an annualised return —
it compares the average price during one year with the average price during the next, which
smooths out where a year happened to open and close.

Everything here reads the same split- and dividend-adjusted bars the rest of the app uses.
Before that fix, a yearly average spanning a stock split was meaningless: NVDA's 2024 average
would have mixed pre-split four-figure prices with post-split three-figure ones and produced a
number that matched no price the stock ever traded at.

Two honesty rules, both load-bearing:

- A year with no bars is NOT zero and NOT skipped silently — it comes back as None and the page
  shows UNAVAILABLE.
- A year the cached history only partly covers is flagged `partial`, with the dates actually
  used. The five-year window starts mid-year on a fresh cache, so 2021 is routinely partial
  until the deeper history has been fetched, and an unflagged partial year would read as a real
  drop in the average price.
"""
import logging
from datetime import date, datetime, timedelta, timezone

import pandas as pd

from services.bars_service import get_bars_df

log = logging.getLogger(__name__)

YEARS_SHOWN = 6          # five full prior years + the current year-to-date
COVERAGE_SLACK_DAYS = 45  # a year missing more than this at its start counts as partial

# Tickers whose history has already been force-refreshed in this process. The cache-coverage
# rule in bars_service is a percentage of the requested window, so a cache holding 5 years is
# "adequate" for a 5.6-year request and the extra months are never fetched. This page needs a
# specific START DATE rather than a span, so it asks once per ticker per process and then stops
# — without the guard, a ticker whose history simply does not reach that far back would trigger
# a slow provider round-trip on every single page load, forever.
_deep_fetch_attempted = set()


def _required_start(today: date) -> date:
    """1 January of the earliest year shown."""
    return date(today.year - (YEARS_SHOWN - 1), 1, 1)


def _lookback_days(today: date) -> int:
    return (today - _required_start(today)).days + 30


def _year_stats(df: pd.DataFrame, year: int, today: date) -> dict:
    """Average close across one calendar year, with an honest coverage flag."""
    rows = df[df["_year"] == year]
    if rows.empty:
        return {"year": year, "avg_price": None, "high": None, "low": None,
                "high_date": None, "low_date": None, "range_pct": None,
                "bars": 0, "partial": False,
                "first_date": None, "last_date": None, "reason": "no bars for this year"}

    first = rows["_date"].min()
    last = rows["_date"].max()
    # The current year is partial by definition, not by data loss — say which it is, because
    # "we only have half the data" and "the year isn't over" are different caveats.
    year_end = date(year, 12, 31)
    expected_start = date(year, 1, 1)
    incomplete_start = (first - expected_start).days > COVERAGE_SLACK_DAYS
    year_in_progress = year == today.year
    missing_end = (not year_in_progress) and (year_end - last).days > COVERAGE_SLACK_DAYS

    # The year's true extremes come from the intraday high and low columns, not from the highest
    # and lowest CLOSE. A stock that spiked to 140 and closed at 128 did trade at 140, and the
    # closing-price version would understate the range it actually swung through — which is the
    # thing a swing trader is looking at this column to judge.
    high_idx = rows["high"].idxmax()
    low_idx = rows["low"].idxmin()
    high = float(rows["high"].max())
    low = float(rows["low"].min())

    return {
        "year": year,
        "avg_price": round(float(rows["close"].mean()), 2),
        "high": round(high, 2),
        "low": round(low, 2),
        "high_date": rows["_date"].loc[high_idx].isoformat(),
        "low_date": rows["_date"].loc[low_idx].isoformat(),
        # How wide the year was, as a percentage of its low: the swing available to trade.
        "range_pct": round((high - low) / low * 100, 1) if low else None,
        "bars": int(len(rows)),
        "partial": bool(incomplete_start or missing_end),
        "year_in_progress": bool(year_in_progress),
        "first_date": first.isoformat(),
        "last_date": last.isoformat(),
        "reason": ("history starts mid-year" if incomplete_start else
                   "history ends before year end" if missing_end else None),
    }


def _pct_change(a, b):
    if a is None or b is None or a == 0:
        return None
    return round((b - a) / a * 100, 2)


def compute_yearly_for_ticker(db, ticker: str, today: date | None = None) -> dict:
    today = today or datetime.now(timezone.utc).date()
    years = [today.year - i for i in range(YEARS_SHOWN - 1, -1, -1)]

    df, meta = get_bars_df(db, ticker, "1Day", lookback_days=_lookback_days(today))

    # Ask the provider for genuinely deeper history if the cache starts after the first year we
    # intend to display — but only once per ticker per process. See _deep_fetch_attempted.
    if not df.empty and ticker not in _deep_fetch_attempted:
        earliest = pd.to_datetime(df["ts"], format="mixed", utc=True).min().date()
        if (earliest - _required_start(today)).days > COVERAGE_SLACK_DAYS:
            _deep_fetch_attempted.add(ticker)
            log.info("Yearly page: %s cache starts %s, need %s — fetching deeper history once",
                     ticker, earliest, _required_start(today))
            df, meta = get_bars_df(db, ticker, "1Day", force_refresh=True,
                                   lookback_days=_lookback_days(today))

    if df.empty:
        # Same key set as the populated path. A shorter dict here would make the frontend's
        # optional-chaining silently differ between "no history at all" and "one missing year",
        # which is how a missing field becomes a blank cell nobody can explain.
        return {"ticker": ticker, "years": [{"year": y, "avg_price": None, "high": None,
                                             "low": None, "high_date": None, "low_date": None,
                                             "range_pct": None, "bars": 0, "partial": False,
                                             "reason": "no price history"}
                                            for y in years],
                "latest_close": None, "latest_close_date": None,
                "avg_year_pct": None, "yoy_pct": [],
                "data_status": "UNAVAILABLE",
                "error": meta.get("error") or "No cached or live bars for this ticker."}

    df = df.copy()
    ts = pd.to_datetime(df["ts"], format="mixed", utc=True)
    df["_date"] = ts.dt.date
    df["_year"] = ts.dt.year

    year_stats = [_year_stats(df, y, today) for y in years]

    # Year-on-year steps between consecutive averages. A gap on either side yields None rather
    # than bridging across the hole, which would silently invent a multi-year change and label
    # it as a single year's move.
    yoy = []
    for prev, cur in zip(year_stats, year_stats[1:]):
        yoy.append({"from": prev["year"], "to": cur["year"],
                    "pct": _pct_change(prev["avg_price"], cur["avg_price"]),
                    "partial": bool(prev.get("partial") or cur.get("partial")
                                    or cur.get("year_in_progress"))})

    usable = [s["pct"] for s in yoy if s["pct"] is not None]
    avg_year_pct = round(sum(usable) / len(usable), 2) if usable else None

    return {
        "ticker": ticker,
        "years": year_stats,
        "yoy_pct": yoy,
        "avg_year_pct": avg_year_pct,
        "avg_year_pct_basis": len(usable),
        "latest_close": round(float(df["close"].iloc[-1]), 2),
        "latest_close_date": df["_date"].iloc[-1].isoformat(),
        "data_status": "STALE" if meta.get("stale_fallback") else "OK",
        "error": meta.get("error"),
    }


def compute_yearly_for_etfs(db, etfs: list, today: date | None = None) -> list:
    """Yearly figures for the watched ETFs, priced through their US-listed proxies.

    The row keeps the ticker the user actually follows (VHYL, CNX1, SMGB) and carries the proxy
    alongside it, rather than quietly relabelling QQQ as CNX1. The proxy is a different fund in
    a different currency with different fees; presenting its prices under the UCITS ticker
    without saying so would be exactly the kind of plausible-looking wrong number this project
    keeps getting caught by.
    """
    today = today or datetime.now(timezone.utc).date()
    out = []
    for etf in etfs:
        try:
            data = compute_yearly_for_ticker(db, etf["proxy"], today)
        except Exception as e:                                  # noqa: BLE001
            try:
                db.rollback()
            except Exception:                                   # noqa: BLE001
                pass
            log.warning("Yearly computation failed for ETF proxy %s: %s", etf["proxy"], e)
            data = {"years": [], "yoy_pct": [], "avg_year_pct": None, "latest_close": None,
                    "data_status": "UNAVAILABLE", "error": str(e)}
        data = dict(data)
        data.update({
            "ticker": etf["ticker"],           # what the user follows
            "name": etf.get("name"),
            "listing": etf.get("listing"),
            "priced_via": etf["proxy"],        # what the numbers actually came from
            "priced_via_name": etf.get("proxy_name"),
            "match": etf.get("match"),
            "proxy_note": etf.get("note"),
            "is_etf": True,
        })
        out.append(data)
    return out


def compute_yearly(db, tickers: list, today: date | None = None, etfs: list | None = None) -> dict:
    today = today or datetime.now(timezone.utc).date()
    results = []
    for t in tickers:
        try:
            results.append(compute_yearly_for_ticker(db, t, today))
        except Exception as e:                                  # noqa: BLE001
            # One bad ticker must not blank the whole page. Roll back first: on Postgres a
            # failed statement aborts the transaction, and every later query in this request
            # would die with "current transaction is aborted" if we simply swallowed this.
            try:
                db.rollback()
            except Exception:                                   # noqa: BLE001
                pass
            log.warning("Yearly computation failed for %s: %s", t, e)
            results.append({"ticker": t, "years": [], "yoy_pct": [], "avg_year_pct": None,
                            "latest_close": None, "data_status": "UNAVAILABLE", "error": str(e)})
    return {
        "years_shown": [today.year - i for i in range(YEARS_SHOWN - 1, -1, -1)],
        "current_year": today.year,
        "results": results,
        "etfs": compute_yearly_for_etfs(db, etfs or [], today),
        "computed_at": datetime.now(timezone.utc).isoformat(),
        "basis": ("Average of every daily CLOSE in the calendar year, using split- and "
                  "dividend-adjusted prices."),
    }
