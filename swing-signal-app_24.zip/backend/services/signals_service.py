"""
Orchestration: ties market regime, Phase 2 stock analysis, Phase 4 fundamentals/news/earnings,
and the signal engine together for one ticker or the whole 15-stock universe. Routers call this
module; they never touch signal_engine or the providers directly.

Failure isolation is deliberate throughout: fundamentals, news and earnings are each optional
enrichments. If SEC EDGAR is down or the news endpoint isn't on the user's Alpaca plan, the
price-based signal still computes — those components simply report as unavailable and drop out
of the achievable maximum, rather than taking the whole signal down with them.
"""
import logging

from config import STOCK_UNIVERSE
from services.fundamentals_service import get_earnings_info, get_fundamentals
from services.market_regime import compute_market_regime, store_market_regime
from services.news_service import refresh_news, score_earnings_risk, score_news
from services.signal_engine import compute_signal, persist_signal
from services.stock_analysis import analyze_stock, build_benchmark_cache

logger = logging.getLogger(__name__)

TICKERS = [s["ticker"] for s in STOCK_UNIVERSE]


def _safe(db, fn, *args, **kwargs):
    """Phase 4 enrichments must never be able to break the core price-based signal.

    TWO THINGS THIS MUST DO BEYOND SWALLOWING THE ERROR:

    1. ROLL BACK. PostgreSQL aborts the entire transaction on the first failed statement and
       rejects everything afterwards with "current transaction is aborted". Swallowing an error
       without rolling back therefore poisons the rest of the request — every later query fails,
       including the ones that had nothing to do with the original problem. SQLite has no such
       behaviour, which is exactly why this only showed up in production.

    2. LOG. A silently swallowed exception is invisible, so a feature can quietly stop working
       with no trace anywhere. The failure is non-fatal, not uninteresting.
    """
    try:
        return fn(*args, **kwargs)
    except Exception as e:  # noqa: BLE001 — deliberately broad; an enrichment failure is not fatal
        logger.warning("Non-fatal enrichment failure in %s: %s", getattr(fn, "__name__", fn), e)
        try:
            db.rollback()
        except Exception:  # noqa: BLE001 — rollback itself failing must not mask the original
            pass
        return None


def compute_signal_for_ticker(db, ticker: str, timeframe: str = "1Day", benchmark_cache=None,
                               regime: dict | None = None, persist: bool = True,
                               include_fundamentals: bool = True) -> dict:
    analysis = analyze_stock(db, ticker, timeframe=timeframe, benchmark_cache=benchmark_cache,
                             persist=persist)
    if regime is None:
        regime = compute_market_regime(db)

    quality = earnings_info = None
    news_tuple = earnings_tuple = None

    if include_fundamentals:
        quality = _safe(db, get_fundamentals, db, ticker)
        earnings_info = _safe(db, get_earnings_info, db, ticker)
        _safe(db, refresh_news, db, [ticker])
        news_tuple = _safe(db, score_news, db, ticker)
        earnings_tuple = _safe(db, score_earnings_risk, earnings_info) if earnings_info else None

    signal = compute_signal(analysis, regime, news=news_tuple, earnings=earnings_tuple,
                            quality=quality, earnings_info=earnings_info)
    if persist:
        persist_signal(db, signal)
    return signal


def compute_all_signals(db, timeframe: str = "1Day", persist: bool = True,
                        include_fundamentals: bool = True) -> list:
    """Computes signals for all 15 tracked stocks, sharing one market-regime fetch, one
    benchmark-bar cache, and ONE batched news call across all 15 (rather than 15x redundant
    SPY/QQQ/sector fetches and 15 separate news requests).

    Returns them ranked best-score-first; tickers with no data sort to the end rather than being
    silently dropped."""
    regime = compute_market_regime(db)
    if persist and regime.get("regime") != "UNAVAILABLE":
        store_market_regime(db, regime)

    benchmark_cache = build_benchmark_cache(db, timeframe)

    # One batched news request for the whole universe — Alpaca's endpoint takes a symbol list.
    if include_fundamentals:
        _safe(db, refresh_news, db, TICKERS)

    signals = []
    for ticker in TICKERS:
        try:
            quality = earnings_info = None
            news_tuple = earnings_tuple = None
            if include_fundamentals:
                quality = _safe(db, get_fundamentals, db, ticker)
                earnings_info = _safe(db, get_earnings_info, db, ticker)
                news_tuple = _safe(db, score_news, db, ticker)
                earnings_tuple = _safe(db, score_earnings_risk, earnings_info) if earnings_info else None

            analysis = analyze_stock(db, ticker, timeframe=timeframe,
                                     benchmark_cache=benchmark_cache, persist=persist)
            signal = compute_signal(analysis, regime, news=news_tuple, earnings=earnings_tuple,
                                    quality=quality, earnings_info=earnings_info)
            if persist:
                persist_signal(db, signal)
        except Exception as e:  # noqa: BLE001 — one bad ticker must not take down the whole batch
            # Roll back before continuing: on PostgreSQL a failed statement aborts the whole
            # transaction, so without this a single bad ticker would cascade into every
            # remaining ticker in the loop failing too.
            logger.warning("Signal computation failed for %s: %s", ticker, e)
            try:
                db.rollback()
            except Exception:  # noqa: BLE001
                pass
            signal = {
                "ticker": ticker, "signal_label": "NO DATA", "score_total": None,
                "data_status": "UNAVAILABLE", "data_error": str(e),
            }
        signals.append(signal)

    signals.sort(key=lambda s: (s.get("score_total") is None, -(s.get("score_total") or 0)))
    return signals
