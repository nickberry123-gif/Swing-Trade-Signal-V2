"""
Bar caching/fetch layer sitting between the indicator engine and MarketDataProvider.

Responsibilities:
- Decide whether cached bars in `market_bars` are fresh enough to reuse, or need refetching
  from the provider (daily bars only need to update once a session has closed; there's no
  reason to hit Alpaca on every dashboard poll for data that only changes once a day).
- On a provider failure, fall back to whatever is cached rather than crashing the whole
  request — but always report that honestly (`from_cache_stale=True`), never pretend a
  cached bar set is fresh live data.
- Hand back a plain pandas DataFrame so services/indicators.py never has to know this table
  or the provider abstraction exist.
"""
import logging
from datetime import datetime, timedelta, timezone

import pandas as pd

log = logging.getLogger(__name__)

from providers import ProviderError
from providers.alpaca_provider import BAR_SOURCE_TAG
from services.market_service import get_provider

# How long cached bars are considered fresh before we bother refetching, per timeframe.
# Daily bars only change once a session closes, so a multi-hour TTL is entirely reasonable
# for a swing-trading app (see project spec: "signal stability", "data delay" sections —
# this is explicitly NOT a scalping system).
FRESHNESS_TTL = {
    "1Day": timedelta(hours=6),
    "4Hour": timedelta(hours=2),
    "1Hour": timedelta(hours=1),
    "30Min": timedelta(minutes=20),
    "15Min": timedelta(minutes=10),
}

# How far back to request bars, per timeframe — enough for SMA200 + slope + 52-week hi/lo
# with comfortable buffer (holidays/weekends already thin out calendar days vs trading days).
# Lookback for the LIVE endpoints (dashboard, signals, indicators). These run inside a normal
# web request, so the window must stay small enough to fetch and compute within the worker
# timeout. ~1.5 years comfortably covers SMA200 + slope, which is all live scoring needs.
#
# HISTORY: this was briefly raised to 1825 days for the backtester, which took the whole site
# down — every dashboard poll started refetching 5 years for 24 tickers inside a 30-second
# request budget, timed out, and the worker was SIGKILLed in a crash loop. Deep history is now
# requested explicitly by the backtester alone (see BACKTEST_LOOKBACK_DAYS) and must never
# become the default for request-path code.
LOOKBACK_DAYS = {
    "1Day": 560,
    "4Hour": 120,
    "1Hour": 60,
    "30Min": 30,
    "15Min": 15,
}

# Deep history, used ONLY by the backtester, which runs in a background thread with no request
# timeout. 5 years spans more than one market regime — including the 2022 drawdown, the most
# informative period for a strategy that holds through losses without a stop.
BACKTEST_LOOKBACK_DAYS = 1825

# Below this fraction of the requested window, a cached series is treated as too short and
# refetched even if it is still within its freshness TTL. Without this, extending LOOKBACK_DAYS
# would have no effect until every cached ticker's TTL happened to expire.
MIN_CACHE_COVERAGE = 0.8

MIN_BARS_FOR_FULL_INDICATORS = 210


def _purge_wrong_adjustment(db, ticker: str, timeframe: str) -> int:
    """Delete cached bars written under a different corporate-action adjustment basis.

    Adjusted and unadjusted bars are not interchangeable: NVDA's 2024-06-07 close is $1208.42
    raw and $120.84 split-adjusted, for the same row key. The upsert in _store_bars would only
    correct the bars inside the refetched window, leaving anything older sitting at the old
    basis — a series with a 10x discontinuity in the middle, which is worse than either basis
    consistently applied. So when the tag doesn't match, the whole series goes and is refetched.

    Returns the number of rows removed, for logging and for the tests to assert on.
    """
    row = db.execute(
        "SELECT COUNT(*) AS n FROM market_bars "
        "WHERE ticker = ? AND timeframe = ? AND (source IS NULL OR source != ?)",
        (ticker, timeframe, BAR_SOURCE_TAG),
    ).fetchone()
    stale = int(dict(row)["n"]) if row else 0
    if not stale:
        return 0
    db.execute(
        "DELETE FROM market_bars WHERE ticker = ? AND timeframe = ?", (ticker, timeframe)
    )
    db.commit()
    log.warning(
        "Purged %d cached %s %s bars written under a stale adjustment basis; refetching as %s",
        stale, ticker, timeframe, BAR_SOURCE_TAG,
    )
    return stale


def _fetch_cached(db, ticker: str, timeframe: str) -> pd.DataFrame:
    rows = db.execute(
        "SELECT ts, open, high, low, close, volume, trade_count, vwap, fetched_at "
        "FROM market_bars WHERE ticker = ? AND timeframe = ? ORDER BY ts ASC",
        (ticker, timeframe),
    ).fetchall()
    if not rows:
        return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])
    return pd.DataFrame([dict(r) for r in rows])


def _cache_is_fresh(cached: pd.DataFrame, timeframe: str) -> bool:
    if cached.empty or len(cached) < 5:
        return False
    last_fetched = pd.to_datetime(cached["fetched_at"]).max()
    if last_fetched.tzinfo is None:
        last_fetched = last_fetched.tz_localize("UTC")
    ttl = FRESHNESS_TTL.get(timeframe, timedelta(hours=6))
    return (datetime.now(timezone.utc) - last_fetched) < ttl


def _cache_covers_window(cached: pd.DataFrame, lookback_days: int) -> bool:
    """True when the cached series spans enough history for the currently-configured lookback.

    Freshness and coverage are different questions: a cache fetched an hour ago is fresh, but if
    it only holds 18 months of bars and the app now wants 5 years, it is still inadequate.
    Checking only the TTL would silently ignore any increase to LOOKBACK_DAYS.
    """
    if cached.empty:
        return False
    try:
        earliest = pd.to_datetime(cached["ts"], format="mixed", utc=True).min()
        latest = pd.to_datetime(cached["ts"], format="mixed", utc=True).max()
    except (TypeError, ValueError):
        return True  # unparseable timestamps: don't force an endless refetch loop
    span_days = (latest - earliest).days
    return span_days >= lookback_days * MIN_CACHE_COVERAGE


def _store_bars(db, ticker: str, timeframe: str, bars):
    now = datetime.now(timezone.utc).isoformat()
    for b in bars:
        db.execute(
            """
            INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume,
                                      trade_count, vwap, source, fetched_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(ticker, timeframe, ts) DO UPDATE SET
                open=excluded.open, high=excluded.high, low=excluded.low, close=excluded.close,
                volume=excluded.volume, trade_count=excluded.trade_count, vwap=excluded.vwap,
                source=excluded.source, fetched_at=excluded.fetched_at
            """,
            (ticker, timeframe, b.ts.isoformat(), b.open, b.high, b.low, b.close, b.volume,
             b.trade_count, b.vwap, BAR_SOURCE_TAG, now),
        )
    db.commit()


def get_bars_df(db, ticker: str, timeframe: str = "1Day", force_refresh: bool = False,
                 lookback_days: int | None = None):
    """
    Returns (df, meta). `df` has columns [ts, open, high, low, close, volume] sorted
    ascending. `meta` describes provenance honestly:
        {
          "source": "alpaca" | "cache",
          "fresh": bool,           # was a live fetch performed (vs serving cache as-is)?
          "stale_fallback": bool,  # provider failed and we fell back to (possibly old) cache
          "error": str | None,
        }
    """
    # Runs before the cache is read, so a series stored under the old (unadjusted) basis can
    # never be served — not even as the stale fallback when the provider is down. Wrong prices
    # presented as usable data is exactly the failure mode the project's no-fabrication rule
    # exists to prevent; an empty result labelled UNAVAILABLE is the honest outcome instead.
    purged = _purge_wrong_adjustment(db, ticker, timeframe)
    cached = _fetch_cached(db, ticker, timeframe)
    meta = {"source": "cache", "fresh": False, "stale_fallback": False, "error": None}
    if purged:
        meta["cache_purged_rows"] = purged
    # `lookback_days` lets a caller ask for deeper history than the live default. Only the
    # backtester does; request-path code must leave it None or it will time out the worker.
    lookback = lookback_days or LOOKBACK_DAYS.get(timeframe, 400)

    if not force_refresh and _cache_is_fresh(cached, timeframe) and \
            _cache_covers_window(cached, lookback):
        cols = ["ts", "open", "high", "low", "close", "volume"]
        return cached[cols].reset_index(drop=True), meta
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=lookback)

    try:
        provider = get_provider()
        bars = provider.get_bars(ticker, timeframe, start, end, limit=2000)
        if bars:
            _store_bars(db, ticker, timeframe, bars)
        refreshed = _fetch_cached(db, ticker, timeframe)
        cols = ["ts", "open", "high", "low", "close", "volume"]
        meta.update(source="alpaca", fresh=True)
        return refreshed[cols].reset_index(drop=True), meta
    except ProviderError as e:
        meta.update(error=str(e))
        if not cached.empty:
            meta["stale_fallback"] = True
            cols = ["ts", "open", "high", "low", "close", "volume"]
            return cached[cols].reset_index(drop=True), meta
        cols = ["ts", "open", "high", "low", "close", "volume"]
        return pd.DataFrame(columns=cols), meta
