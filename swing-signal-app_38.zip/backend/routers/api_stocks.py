import json
from datetime import datetime, timezone, timedelta

from flask import Blueprint, jsonify, request

from config import Config, ETF_UNIVERSE, STOCK_UNIVERSE
from db import get_db
from providers import ProviderError, DataStatus
from services.market_service import get_snapshots_cached, get_provider
from services.stock_analysis import analyze_stock, build_benchmark_cache
from services.yearly_service import compute_yearly, compute_yearly_combined
from services.monthly_buying_service import compute_monthly_buying

bp = Blueprint("api_stocks", __name__, url_prefix="/api/stocks")

TICKERS = [s["ticker"] for s in STOCK_UNIVERSE]


def _stock_rows():
    db = get_db()
    rows = db.execute("SELECT ticker, name, sector, industry, exchange FROM stocks ORDER BY ticker").fetchall()
    return [dict(r) for r in rows]


def _persist_quote(db, snap):
    db.execute(
        """
        INSERT INTO quotes (ticker, last_trade_px, last_trade_ts, bid_px, bid_size, ask_px, ask_size,
                             quote_ts, daily_open, daily_high, daily_low, daily_close, daily_volume,
                             prev_close, data_source, data_status, fetched_at)
        VALUES (:ticker, :last_trade_px, :last_trade_ts, :bid_px, :bid_size, :ask_px, :ask_size,
                :quote_ts, :daily_open, :daily_high, :daily_low, :daily_close, :daily_volume,
                :prev_close, :data_source, :data_status, :fetched_at)
        ON CONFLICT(ticker) DO UPDATE SET
            last_trade_px=excluded.last_trade_px, last_trade_ts=excluded.last_trade_ts,
            bid_px=excluded.bid_px, bid_size=excluded.bid_size, ask_px=excluded.ask_px,
            ask_size=excluded.ask_size, quote_ts=excluded.quote_ts, daily_open=excluded.daily_open,
            daily_high=excluded.daily_high, daily_low=excluded.daily_low, daily_close=excluded.daily_close,
            daily_volume=excluded.daily_volume, prev_close=excluded.prev_close,
            data_source=excluded.data_source, data_status=excluded.data_status,
            fetched_at=excluded.fetched_at
        """,
        {
            "ticker": snap.ticker,
            "last_trade_px": snap.last_price,
            "last_trade_ts": snap.last_trade_ts.isoformat() if snap.last_trade_ts else None,
            "bid_px": snap.bid_price, "bid_size": snap.bid_size,
            "ask_px": snap.ask_price, "ask_size": snap.ask_size,
            "quote_ts": snap.quote_ts.isoformat() if snap.quote_ts else None,
            "daily_open": snap.daily_open, "daily_high": snap.daily_high,
            "daily_low": snap.daily_low, "daily_close": snap.daily_close,
            "daily_volume": snap.daily_volume, "prev_close": snap.prev_close,
            "data_source": snap.data_source, "data_status": snap.data_status.value,
            "fetched_at": snap.fetched_at.isoformat(),
        },
    )
    db.commit()


def _snapshot_to_json(snap):
    return {
        "ticker": snap.ticker,
        "last_price": snap.last_price,
        "last_trade_ts": snap.last_trade_ts.isoformat() if snap.last_trade_ts else None,
        "bid_price": snap.bid_price,
        "ask_price": snap.ask_price,
        "daily_open": snap.daily_open,
        "daily_high": snap.daily_high,
        "daily_low": snap.daily_low,
        "daily_close": snap.daily_close,
        "daily_volume": snap.daily_volume,
        "prev_close": snap.prev_close,
        "change": (snap.last_price - snap.prev_close) if (snap.last_price is not None and snap.prev_close) else None,
        "change_pct": (
            round(((snap.last_price - snap.prev_close) / snap.prev_close) * 100, 2)
            if (snap.last_price is not None and snap.prev_close)
            else None
        ),
        "data_source": snap.data_source,
        "data_status": snap.data_status.value,
        "fetched_at": snap.fetched_at.isoformat(),
    }


def _last_known_from_db(db, ticker):
    row = db.execute("SELECT last_trade_px, fetched_at FROM quotes WHERE ticker = ?", (ticker,)).fetchone()
    if not row or row["last_trade_px"] is None:
        return None
    return {"last_known_price": row["last_trade_px"], "as_of": row["fetched_at"]}


@bp.get("")
def list_stocks():
    return jsonify(_stock_rows())


@bp.get("/snapshots")
def all_snapshots():
    """Batch snapshot for the full 15-stock universe — powers the dashboard table."""
    db = get_db()
    stocks_by_ticker = {s["ticker"]: s for s in _stock_rows()}

    if not Config.has_alpaca_credentials():
        out = []
        for t in TICKERS:
            row = {"ticker": t, **stocks_by_ticker.get(t, {}),
                   "data_source": "alpaca", "data_status": DataStatus.UNAVAILABLE.value,
                   "error": "Alpaca API credentials not configured"}
            row.update(_last_known_from_db(db, t) or {})
            out.append(row)
        return jsonify({"data_source": "alpaca", "results": out}), 200

    try:
        snapshots = get_snapshots_cached(TICKERS)
    except ProviderError as e:
        out = []
        for t in TICKERS:
            row = {"ticker": t, **stocks_by_ticker.get(t, {}),
                   "data_source": "alpaca", "data_status": e.status.value, "error": str(e)}
            row.update(_last_known_from_db(db, t) or {})
            out.append(row)
        return jsonify({"data_source": "alpaca", "results": out, "feed_error": str(e)}), 200

    out = []
    for t in TICKERS:
        snap = snapshots.get(t)
        if snap is None:
            row = {"ticker": t, **stocks_by_ticker.get(t, {}),
                   "data_source": "alpaca", "data_status": DataStatus.UNAVAILABLE.value}
        else:
            _persist_quote(db, snap)
            row = {**stocks_by_ticker.get(t, {}), **_snapshot_to_json(snap)}
        out.append(row)

    return jsonify({"data_source": "alpaca", "results": out})


@bp.get("/<ticker>")
def stock_detail(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked 15-stock universe"}), 404
    stocks_by_ticker = {s["ticker"]: s for s in _stock_rows()}
    return jsonify(stocks_by_ticker.get(ticker))


@bp.get("/<ticker>/snapshot")
def stock_snapshot(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked 15-stock universe"}), 404

    db = get_db()
    if not Config.has_alpaca_credentials():
        payload = {"ticker": ticker, "data_source": "alpaca", "data_status": DataStatus.UNAVAILABLE.value,
                   "error": "Alpaca API credentials not configured"}
        payload.update(_last_known_from_db(db, ticker) or {})
        return jsonify(payload), 200

    try:
        snap = get_provider().get_snapshot(ticker)
    except ProviderError as e:
        payload = {"ticker": ticker, "data_source": "alpaca", "data_status": e.status.value, "error": str(e)}
        payload.update(_last_known_from_db(db, ticker) or {})
        return jsonify(payload), 200

    _persist_quote(db, snap)
    return jsonify(_snapshot_to_json(snap))


@bp.get("/<ticker>/bars")
def stock_bars(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked 15-stock universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca API credentials not configured", "data_status": "UNAVAILABLE"}), 200

    timeframe = request.args.get("timeframe", "1Day")
    limit = min(int(request.args.get("limit", 200)), 2000)
    days_back = int(request.args.get("days_back", 400))
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=days_back)

    try:
        bars = get_provider().get_bars(ticker, timeframe, start, end, limit=limit)
    except ProviderError as e:
        return jsonify({"error": str(e), "data_status": e.status.value}), 200

    return jsonify({
        "ticker": ticker,
        "timeframe": timeframe,
        "data_source": "alpaca",
        "data_status": "HISTORICAL",  # backward-looking bars, not a live/delayed/stale claim
        "bars": [
            {"t": b.ts.isoformat(), "o": b.open, "h": b.high, "l": b.low, "c": b.close,
             "v": b.volume, "n": b.trade_count, "vw": b.vwap}
            for b in bars
        ],
    })


def _indicator_result_to_json(result: dict) -> dict:
    """analyze_stock() returns trend_reasons as a JSON-encoded string (that's the storage
    shape for the DB column) — decode it back to a list for the API response."""
    out = dict(result)
    reasons = out.get("trend_reasons")
    if isinstance(reasons, str):
        try:
            out["trend_reasons"] = json.loads(reasons)
        except (TypeError, ValueError):
            pass
    return out


@bp.get("/<ticker>/indicators")
def stock_indicators(ticker):
    """Technical indicators, support/resistance zone, trend classification, and relative
    strength for one stock. Computes fresh (fetching/caching bars as needed via bars_service)
    rather than only reading whatever was last persisted, so this always reflects the latest
    available data."""
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked 15-stock universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({
            "ticker": ticker, "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured",
        }), 200

    timeframe = request.args.get("timeframe", "1Day")
    db = get_db()
    result = analyze_stock(db, ticker, timeframe=timeframe)
    return jsonify(_indicator_result_to_json(result))


@bp.get("/yearly")
def bulk_yearly():
    """Average price per calendar year for all 15 stocks — powers the Yearly page.

    Deliberately NOT polled by the frontend. On a cache that does not already reach back five
    full years this triggers one deep provider fetch per ticker, which takes a couple of
    minutes; a poller would stack those requests on top of each other. The page loads it once
    and offers a manual refresh.
    """
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured", "results": [],
        }), 200
    return jsonify(compute_yearly(get_db(), TICKERS, etfs=ETF_UNIVERSE))


@bp.get("/yearly-combined")
def bulk_yearly_combined():
    """Both yearly views from ONE pass over the bars — what the Yearly page calls.

    Replaces two separate calls to /yearly and /monthly-buying. Those loaded the same six years of
    daily history for the same fifty stocks twice, and on one worker with 0.15 of a CPU the second
    queued behind the first: the page showed a spinner for minutes with nothing in the request log,
    because gunicorn only logs a request when it finishes.
    """
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured", "results": [],
        }), 200
    return jsonify(compute_yearly_combined(get_db(), TICKERS, etfs=ETF_UNIVERSE))


@bp.get("/monthly-buying")
def bulk_monthly_buying():
    """What buying the same amount every month would have returned, year by year.

    Same caching caveat as /yearly: not polled, loaded once, manual refresh. It reads the same
    cached bars that page already warms, so in practice it is fast after Yearly has been opened.
    """
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured", "results": [],
        }), 200
    return jsonify(compute_monthly_buying(get_db(), TICKERS, etfs=ETF_UNIVERSE))


@bp.get("/indicators")
def bulk_indicators():
    """Technical indicators for all 15 stocks in one call — powers the dashboard table's
    RSI/Trend/Relative-Strength columns without 15 separate round trips. Benchmark bars
    (SPY/QQQ/sector ETFs) are fetched once and shared across all 15 analyses."""
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured", "results": [],
        }), 200

    timeframe = request.args.get("timeframe", "1Day")
    db = get_db()
    benchmark_cache = build_benchmark_cache(db, timeframe)

    results = []
    for ticker in TICKERS:
        try:
            result = analyze_stock(db, ticker, timeframe=timeframe, benchmark_cache=benchmark_cache)
        except Exception as e:  # noqa: BLE001 — one bad ticker must not take down the whole batch
            result = {"ticker": ticker, "data_status": "UNAVAILABLE", "data_error": str(e), "bars_used": 0}
        results.append(_indicator_result_to_json(result))

    return jsonify({"data_source": "alpaca", "timeframe": timeframe, "results": results})


@bp.get("/sector-baskets")
def sector_baskets():
    """The 50 as five home-made equal-weight funds, each against its real sector ETF, plus all
    four weighting schemes judged out of sample.

    ONE PASS over the bars feeds both halves. Loading them per scheme would walk six years of
    daily history for fifty stocks five times over, which is exactly how this page previously
    became indistinguishable from a hung server.
    """
    from services.sector_basket_service import (compute_scheme_comparison,
                                                compute_sector_baskets, load_universe)
    if not Config.has_alpaca_credentials():
        return jsonify({"data_status": "UNAVAILABLE",
                        "error": "Alpaca API credentials not configured"}), 200

    scheme = request.args.get("scheme", "equal")
    db = get_db()
    loaded = load_universe(db)
    return jsonify({
        "baskets": compute_sector_baskets(db, scheme=scheme, loaded=loaded),
        "schemes": compute_scheme_comparison(db, loaded=loaded),
    })
