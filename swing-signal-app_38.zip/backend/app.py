"""
Flask application entry point.

Run with:  python app.py
Serves both the JSON API (/api/...) and the frontend (server-rendered shell + static JS/CSS
that calls the API via fetch). No Node.js/build step required.
"""
from pathlib import Path

from flask import Flask, render_template

from config import Config, STOCK_UNIVERSE
from providers.alpaca_provider import BAR_ADJUSTMENT
import db as db_module
from routers.api_stocks import bp as stocks_bp, TICKERS
from routers.api_market import bp as market_bp
from routers.api_signals import bp as signals_bp
from routers.api_fundamentals import bp as fundamentals_bp
from routers.api_portfolio import bp as portfolio_bp
from routers.api_backtest import bp as backtest_bp
from routers.api_alerts import bp as alerts_bp
from routers.api_entry_quality import bp as entry_quality_bp
from routers.api_selection import bp as selection_bp
from routers.api_strategies import bp as strategies_bp
from routers.api_pattern import bp as pattern_bp
from routers.api_annual import bp as annual_bp

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"

# Identifies the archive this code came from. Change it whenever a new zip is built, and check
# it on /health after deploying. See the health endpoint for why this exists.
BUILD_ID = "2026-08-15-sector-baskets"


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(FRONTEND_DIR / "templates"),
        static_folder=str(FRONTEND_DIR / "static"),
        static_url_path="/static",
    )

    db_module.init_app(app)
    with app.app_context():
        db_module.init_db()

    app.register_blueprint(stocks_bp)
    app.register_blueprint(market_bp)
    app.register_blueprint(signals_bp)
    app.register_blueprint(fundamentals_bp)
    app.register_blueprint(portfolio_bp)
    app.register_blueprint(backtest_bp)
    app.register_blueprint(alerts_bp)
    app.register_blueprint(entry_quality_bp)
    app.register_blueprint(selection_bp)
    app.register_blueprint(strategies_bp)
    app.register_blueprint(pattern_bp)
    app.register_blueprint(annual_bp)

    nav_items = [
        ("DASHBOARD", "/"),
        ("YEARLY", "/yearly"),
        ("SIGNALS", "/signals"),
        ("STRATEGY LAB", "/strategy-lab"),
        ("BACKTEST", "/backtest"),
        ("ANNUAL BACKTEST", "/annual-backtest"),
        ("BULLISH SETUPS", "/pattern-test"),
        ("ALERTS", "/alerts"),
    ]
    # SIX PAGES ARE DELIBERATELY ABSENT FROM THE MENU. Every route below still works and every
    # line of their code is untouched — restoring any of them is one tuple in the list above.
    # Removing them does NOT make the app faster: an unvisited page is never rendered, and none
    # of them is called by any other page. This is about what is worth a person's attention.
    #
    #   /stocks          — was not a page so much as a copy. Identical ten columns to the
    #                      dashboard's table, the same `stocks-tbody` element, and it loaded the
    #                      SAME script (js/dashboard.js). The two drifted apart once and the
    #                      headers ended up above the wrong columns. The per-ticker detail pages
    #                      at /stocks/<ticker> are the part with value and are reached by
    #                      clicking any dashboard row; they are unaffected.
    #   /portfolio       — a manual journal. Blank unless trades are typed in by hand.
    #   /trades          — the same, and /performance reads from it.
    #   /performance     — therefore also blank without a hand-kept journal.
    #   /entry-test      — a diagnostic asking whether the signal score predicts anything.
    #   /selection-test  — a second diagnostic asking the same by a different method.
    #   /monthly-buying  — its figures now sit INSIDE the Yearly table, one line under each
    #                      year's price data, which is where they are actually useful: the whole
    #                      value of the comparison is seeing both numbers for the same year
    #                      without changing pages. The standalone version still works.
    #   /settings        — a placeholder that has never contained a setting.
    #
    # The two diagnostics both answered no. Leaving them one click away invites re-running until
    # one finally reads well, which is how a person talks themselves into a strategy.

    @app.context_processor
    def inject_nav():
        return {"nav_items": nav_items, "has_alpaca": Config.has_alpaca_credentials()}

    @app.get("/")
    def dashboard():
        return render_template("dashboard.html", active="DASHBOARD", stocks=STOCK_UNIVERSE)

    @app.get("/stocks")
    def stocks_page():
        return render_template("stocks.html", active="STOCKS", stocks=STOCK_UNIVERSE)

    @app.get("/stocks/<ticker>")
    def stock_detail_page(ticker):
        ticker = ticker.upper()
        if ticker not in TICKERS:
            return render_template("not_found.html", active="STOCKS", ticker=ticker), 404
        stock = next(s for s in STOCK_UNIVERSE if s["ticker"] == ticker)
        return render_template("stock_detail.html", active="STOCKS", stock=stock)

    @app.get("/yearly")
    def yearly_page():
        return render_template("yearly.html", active="YEARLY", stocks=STOCK_UNIVERSE)

    @app.get("/monthly-buying")
    def monthly_buying_page():
        return render_template("monthly_buying.html", active="MONTHLY BUYING",
                               stocks=STOCK_UNIVERSE)

    @app.get("/signals")
    def signals_page():
        return render_template("signals.html", active="SIGNALS", stocks=STOCK_UNIVERSE)

    @app.get("/portfolio")
    def portfolio_page():
        return render_template("portfolio.html", active="PORTFOLIO", stocks=STOCK_UNIVERSE)

    @app.get("/trades")
    def trades_page():
        return render_template("trades.html", active="TRADES", stocks=STOCK_UNIVERSE)

    @app.get("/performance")
    def performance_page():
        return render_template("performance.html", active="PERFORMANCE")

    @app.get("/strategy-lab")
    def strategy_lab_page():
        return render_template("strategy_lab.html", active="STRATEGY LAB", stocks=STOCK_UNIVERSE)

    @app.get("/backtest")
    def backtest_page():
        return render_template("backtest.html", active="BACKTEST", stocks=STOCK_UNIVERSE)

    @app.get("/annual-backtest")
    def annual_backtest_page():
        return render_template("annual_backtest.html", active="ANNUAL BACKTEST", stocks=STOCK_UNIVERSE)

    @app.get("/entry-test")
    def entry_test_page():
        return render_template("entry_test.html", active="ENTRY TEST", stocks=STOCK_UNIVERSE)

    @app.get("/selection-test")
    def selection_test_page():
        return render_template("selection_test.html", active="SELECTION TEST", stocks=STOCK_UNIVERSE)

    @app.get("/pattern-test")
    def pattern_test_page():
        return render_template("pattern_test.html", active="PATTERN TEST", stocks=STOCK_UNIVERSE)

    @app.get("/alerts")
    def alerts_page():
        return render_template("alerts.html", active="ALERTS")

    placeholder_phases = {
        "settings": "Phase 1+ — Settings",
    }
    for route_name, phase_label in placeholder_phases.items():
        def make_view(name=route_name, label=phase_label):
            def view():
                return render_template("coming_soon.html", active=name.upper(), phase_label=label, page_name=name.capitalize())
            return view
        app.add_url_rule(f"/{route_name}", endpoint=f"{route_name}_page", view_func=make_view())

    @app.get("/health")
    def health():
        # BUILD_ID is here so "did my change actually deploy?" is a single request rather than a
        # guess. It is not cosmetic: a deploy once reported "live" while Render had extracted a
        # stale zip left in the repo, and the only way to notice was to spot that a price bug was
        # still present. Bump BUILD_ID in every zip; if /health disagrees with what was sent,
        # the build picked up the wrong archive.
        return {
            "status": "ok",
            "alpaca_configured": Config.has_alpaca_credentials(),
            "build_id": BUILD_ID,
            "bar_adjustment": BAR_ADJUSTMENT,
        }

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=Config.PORT, debug=True)
