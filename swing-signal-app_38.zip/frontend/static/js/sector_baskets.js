// Your 50 as five home-made sector funds, against the real ETFs — plus four fixed weightings
// judged out of sample.
//
// THE ONE THING THIS FILE MUST NOT DO is present the totals as an achievement. The holdings were
// picked in 2026 knowing which had gone up, so every basket wins and the size of the win is
// mostly the size of the hindsight. So: years-beaten is rendered prominently, totals are rendered
// plainly, and the hindsight warning is not a footnote the layout can push off-screen.

function sbPct(v, dp) {
  return v === null || v === undefined ? "—" : fmtPct(v, dp === undefined ? 1 : dp);
}

function sbYearsHead(years, extra) {
  return `<th>${extra || ""}</th>` + years.map((y) => `<th class="text-right">${y}</th>`).join("");
}

function renderBaskets(data) {
  const box = document.getElementById("sb-baskets");
  const years = data.years || [];
  const all = (data.sectors || []).concat(data.whole_universe ? [data.whole_universe] : []);
  if (!all.length) {
    box.innerHTML = `<div class="card card-pad text-dim">No baskets could be built.</div>`;
    return;
  }

  box.innerHTML = all.map((b) => {
    const rows = (b.per_year || []).map((g) => `<tr>
      <td>${g.year}</td>
      <td class="text-right ${pctClass(g.basket_pct)}">${sbPct(g.basket_pct)}</td>
      <td class="text-right ${pctClass(g.benchmark_pct)}">${sbPct(g.benchmark_pct)}</td>
      <td class="text-right ${pctClass(g.gap_pct)}">${sbPct(g.gap_pct)}</td>
    </tr>`).join("");

    // Years beaten is the headline, not the total. One enormous year can carry a total; winning
    // most years is the harder thing to fake, and it is what "is this basket actually better"
    // means.
    const beaten = b.years_scored
      ? `${b.years_beaten} of ${b.years_scored} years`
      : "no scored years";

    const partials = (b.years || []).filter((y) => y.partial);

    return `<div class="card card-pad" style="margin-bottom:10px;">
      <div class="section-header" style="margin-bottom:6px;">
        <h3 style="margin:0;font-size:14px;">${b.name}
          <span class="text-dim" style="font-weight:400;">— ${b.member_count} holdings,
          ${b.scheme_label.toLowerCase()}, vs ${b.benchmark || "no benchmark"}</span></h3>
        <span class="${b.years_beaten > (b.years_scored - b.years_beaten) ? "num-pos" : "text-dim"}"
              style="font-size:12px;">beat ${b.benchmark || "benchmark"} in <strong>${beaten}</strong></span>
      </div>

      <table>
        <thead><tr>
          <th>Year</th><th class="text-right">Basket</th>
          <th class="text-right">${b.benchmark || "—"}</th><th class="text-right">Difference</th>
        </tr></thead>
        <tbody>${rows}
          <tr style="border-top:1px solid var(--border, #333);">
            <td><strong>Total (chained)</strong></td>
            <td class="text-right ${pctClass(b.total_pct)}"><strong>${sbPct(b.total_pct)}</strong></td>
            <td class="text-right ${pctClass(b.benchmark_total_pct)}">${sbPct(b.benchmark_total_pct)}</td>
            <td class="text-right ${pctClass(b.total_gap_pct)}">${sbPct(b.total_gap_pct)}</td>
          </tr>
        </tbody>
      </table>

      <div class="footer-note" style="margin-top:6px;">
        ${b.hindsight_note}
        ${partials.length ? `<br><span class="text-dim">Incomplete years: ` +
          partials.map((y) => `${y.year} (${y.reason})`).join("; ") + `</span>` : ""}
      </div>
    </div>`;
  }).join("");
}

function renderSchemes(data) {
  const head = document.getElementById("sb-scheme-head");
  const body = document.getElementById("sb-schemes");
  const verdict = document.getElementById("sb-verdict");

  if (data.error) {
    verdict.innerHTML = `<div class="warn-banner">${data.error}</div>`;
    body.innerHTML = `<tr class="loading-row"><td colspan="5">—</td></tr>`;
    return;
  }

  const chosen = data.chosen_on || [];
  const measured = data.measured_on || [];

  // The verdict is a sentence, not a colour. A table of four totals invites picking the biggest,
  // which is the exact mistake the split exists to prevent.
  verdict.innerHTML = `<div class="${data.held_up ? "warn-banner" : "error-banner"}">
    <strong>${data.held_up ? "The winner held up across the split." : "The winner CHANGED across the split."}</strong><br>
    ${data.verdict}
  </div>
  <div class="footer-note" style="margin-bottom:8px;">${data.hindsight_note}</div>`;

  head.innerHTML = `<th>Weighting</th>
    <th class="text-right">Chosen on ${chosen[0]}–${chosen[chosen.length - 1]}</th>
    <th class="text-right">Measured on ${measured[0]}–${measured[measured.length - 1]}</th>
    <th class="text-right">Whole period</th>
    <th>What it does</th>`;

  const rows = (data.schemes || []).map((s) => `<tr>
    <td><strong>${s.label}</strong>
      ${s.scheme === data.best_on_measured_years
        ? `<div class="yc-sub num-pos">best out of sample</div>` : ""}
      ${s.scheme === data.best_on_chosen_years && s.scheme !== data.best_on_measured_years
        ? `<div class="yc-sub text-dim">best in sample only</div>` : ""}</td>
    <td class="text-right ${pctClass(s.early_total_pct)}">${sbPct(s.early_total_pct)}</td>
    <td class="text-right ${pctClass(s.late_total_pct)}">${sbPct(s.late_total_pct)}</td>
    <td class="text-right ${pctClass(s.total_pct)}">${sbPct(s.total_pct)}</td>
    <td style="font-size:11.5px;" class="text-dim">${s.description}</td>
  </tr>`).join("");

  const b = data.benchmark || {};
  const benchRow = `<tr style="border-top:1px solid var(--border, #333);">
    <td><strong>${b.symbol || "SPY"}</strong>
      <div class="yc-sub text-dim">nobody picked its holdings</div></td>
    <td class="text-right ${pctClass(b.early_total_pct)}">${sbPct(b.early_total_pct)}</td>
    <td class="text-right ${pctClass(b.late_total_pct)}">${sbPct(b.late_total_pct)}</td>
    <td class="text-right ${pctClass(b.total_pct)}">${sbPct(b.total_pct)}</td>
    <td style="font-size:11.5px;" class="text-dim">The index, for scale.</td>
  </tr>`;

  body.innerHTML = rows + benchRow;
}

async function loadSectorBaskets() {
  const scheme = document.getElementById("sb-scheme").value;
  document.getElementById("sb-baskets").innerHTML =
    `<div class="card card-pad text-dim">Building baskets&hellip;</div>`;
  try {
    const data = await apiGet(`/api/stocks/sector-baskets?scheme=${encodeURIComponent(scheme)}`);
    if (data.error) {
      document.getElementById("sb-baskets").innerHTML =
        `<div class="error-banner">${data.error}</div>`;
      return;
    }
    renderBaskets(data.baskets || {});
    renderSchemes(data.schemes || {});

    // A symbol that could not be loaded is named, not quietly dropped. A basket missing two of
    // its ten holdings is a different basket, and the page must not present it as the same one.
    const failures = (data.baskets || {}).failures || {};
    const keys = Object.keys(failures);
    document.getElementById("sb-failures").innerHTML = keys.length
      ? `<strong>Not loaded:</strong> ` + keys.map((k) => `${k} (${failures[k]})`).join("; ") +
        `. Those holdings are excluded from every basket above, not counted as flat.`
      : "";
  } catch (e) {
    document.getElementById("sb-baskets").innerHTML =
      `<div class="error-banner">Could not build the baskets: ${e.message}</div>`;
  }
}

document.getElementById("sb-scheme").addEventListener("change", loadSectorBaskets);
loadSectorBaskets();
