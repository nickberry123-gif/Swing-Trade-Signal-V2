"""
MONTHLY PRICE ENGINE — the Excel workbook's methodology, running server-side.

WHAT THIS IS. The uploaded workbook analysed four ETFs from monthly adjusted closes: calendar-year
returns, price CAGR, a pound-a-month DCA return, 52-week and 5-year ranges, and drawdown. Every one
of those calculations is reproduced here and was checked against the workbook's own figures — all
24 of its annual return numbers match to zero difference.

TWO PRICE SOURCES, KEPT DISTINCT AND LABELLED.

    ETFs   — the workbook's own monthly series (Digrin adjusted closes, GBp converted to GBP),
             embedded because Alpaca does not serve London-listed UCITS ETFs on this account.
    STOCKS — month-end samples of the ADJUSTED daily bars already stored by this app.

Both are total-return adjusted series, which is what a return calculation requires. They are NOT
the raw series the Value pillar needs, and the two must never be swapped.

CURRENCY IS NOT CONVERTED, AND THAT MATTERS. The ETFs are quoted in GBP and the stocks in USD.
A percentage return in one currency is not directly comparable with one in another, so every row
carries its currency and nothing is silently blended across the two.

THE SYNTHETIC INDEX. MAG6 is not a traded instrument. It is the Magnificent 7 excluding Tesla,
equally weighted and REBALANCED EVERY MONTH — each month's index return is the plain average of
that month's six constituent returns, which is what "equal split" means and how equal-weight funds
actually behave. Buy-and-hold would drift into being mostly NVIDIA and would stop describing an
equal split at all. A month is skipped for a constituent that has no data, and the count of
constituents actually used is reported so a thin month is visible rather than hidden.
"""
import json
from datetime import date, datetime, timezone
from pathlib import Path

SEED_PATH = Path(__file__).resolve().parent / "etf_seed_data.json"

SEED_ETFS = ("VHYL", "CNX1", "IITU", "SMGB")

# The synthetic equal-weight index: the Magnificent 7 with Tesla removed.
SYNTHETIC = "MAG6"
SYNTHETIC_MEMBERS = ("AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META")
SYNTHETIC_BASE = 100.0

# Calendar years the yearly view reports. 2020 is the baseline, never shown as a return.
BASE_YEAR = 2020

# ETF VALUATION, TAKEN FROM THE WORKBOOK'S OWN "ETF Inputs" SHEET — not recomputed and not
# estimated. An ETF's P/E is the weighted P/E of its holdings as the provider publishes it, so
# there is no way to derive it from price data and no honest alternative to carrying the figure.
#
# `hist_avg_pe` is None for VHYL and SMGB ON PURPOSE. The workbook's Methodology sheet records
# that no consistent multi-year trailing series was found for either, and it chose to show N/A
# rather than invent an average. That decision is preserved here rather than quietly filled in.
ETF_FUNDAMENTALS = {
    "VHYL": {"pe": 17.20, "pb": 2.20, "ter": 0.0029, "yield": 0.0267, "holdings": 2362,
             "top10": 0.1135, "beta": 1.0, "hist_avg_pe": None,
             "source": "Vanguard product page, 31-Jul-2026"},
    "CNX1": {"pe": 39.38, "pb": 9.64, "ter": 0.0030, "yield": 0.0, "holdings": 102,
             "top10": 0.4577, "beta": 1.0, "hist_avg_pe": 30.3181818182,
             "source": "iShares product page, Aug-2026; historical P/E from Trendonify"},
    "IITU": {"pe": 42.13, "pb": 14.10, "ter": 0.0015, "yield": 0.0, "holdings": 73,
             "top10": 0.7496, "beta": 1.0, "hist_avg_pe": 29.0506818182,
             "source": "iShares product page, 19-Aug-2026; historical P/E from Trendonify"},
    "SMGB": {"pe": 50.92, "pb": 13.99, "ter": 0.0035, "yield": 0.0, "holdings": 25,
             "top10": 0.8321, "beta": None, "hist_avg_pe": None,
             "source": "VanEck fact sheet, 31-Jul-2026"},
}

# The workbook's own bands, read from its Methodology sheet rows 12 and 24. Not redesigned.
CHEAP_THRESHOLD, EXPENSIVE_THRESHOLD = -0.15, 0.20


def valuation_vs_history(pe, hist_avg_pe) -> dict:
    """Current P/E against the fund's own historical average, on the workbook's boundaries.

    Returns an explicit reason whenever a verdict cannot be reached, so a blank is never mistaken
    for FAIR. "No historical average" and "expensive" are different statements.
    """
    out = {"pe": pe, "hist_avg_pe": hist_avg_pe, "pe_vs_avg": None,
           "status": "MISSING DATA", "reason": None}
    if pe is None:
        out["reason"] = "no current P/E published for this security"
        return out
    if hist_avg_pe is None:
        out["reason"] = "no historical average P/E exists to compare against"
        return out
    dev = pe / hist_avg_pe - 1.0
    out["pe_vs_avg"] = round(dev, 6)
    out["status"] = ("CHEAP" if dev <= CHEAP_THRESHOLD
                     else "EXPENSIVE" if dev >= EXPENSIVE_THRESHOLD else "FAIR")
    return out


def _v(x):
    if x is None or isinstance(x, bool):
        return None
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    return None if f != f or f in (float("inf"), float("-inf")) else f


# --------------------------------------------------------------------------------------------
# Sources
# --------------------------------------------------------------------------------------------
def etf_seed() -> dict:
    """{ticker: [(month_end, adj_close)]} from the verified workbook series."""
    rows = json.loads(SEED_PATH.read_text())
    out = {t: [] for t in SEED_ETFS}
    for r in rows:
        for t in SEED_ETFS:
            if _v(r.get(t)) is not None:
                out[t].append((r["date"], float(r[t])))
    return out


def month_end_samples(bars: list, field: str = "close_adj") -> list:
    """The LAST available adjusted close of each calendar month.

    Last rather than nearest-to-month-end: a month's closing observation is the last day it
    actually traded, and using it means a short month or a holiday does not silently borrow a
    price from the following month.
    """
    by_month = {}
    for b in bars:
        ts = (b.get("ts") or "")[:10]
        c = _v(b.get(field))
        if len(ts) == 10 and c and c > 0:
            key = ts[:7]
            if key not in by_month or ts > by_month[key][0]:
                by_month[key] = (ts, c)
    return [by_month[k] for k in sorted(by_month)]


# --------------------------------------------------------------------------------------------
# The synthetic index
# --------------------------------------------------------------------------------------------
def synthetic_series(members: dict) -> list:
    """Equal-weight, monthly-rebalanced index level from constituent monthly series.

    `members` is {ticker: [(month_end, price)]}. Each month's index return is the unweighted mean
    of the constituent returns available that month — which IS monthly rebalancing, because every
    constituent re-enters the next month at the same weight regardless of how it just performed.
    """
    if not members:
        return []
    lookup = {t: dict(rows) for t, rows in members.items() if rows}
    months = sorted({m for rows in lookup.values() for m in rows})
    if len(months) < 2:
        return []
    level, out = SYNTHETIC_BASE, [(months[0], SYNTHETIC_BASE, len(lookup))]
    for prev, cur in zip(months, months[1:]):
        rets = []
        for t, rows in lookup.items():
            p0, p1 = rows.get(prev), rows.get(cur)
            if p0 and p1 and p0 > 0:
                rets.append(p1 / p0 - 1.0)
        if rets:
            level *= (1.0 + sum(rets) / len(rets))
        out.append((cur, round(level, 6), len(rets)))
    return out


# --------------------------------------------------------------------------------------------
# Metrics — the workbook's definitions, verified against its own numbers
# --------------------------------------------------------------------------------------------
def annual_returns(series: list) -> dict:
    """Calendar-year return = last price of the year / last price of the prior year - 1.

    Exactly the workbook's definition, including its use of the December 2020 close as the 2021
    baseline. A year with no prior-year close reports None rather than a return measured from an
    arbitrary starting month.
    """
    year_end = {}
    for d, p in series:
        y = int(d[:4])
        if y not in year_end or d >= year_end[y][0]:
            year_end[y] = (d, p)
    out = {}
    for y in sorted(year_end):
        prev = year_end.get(y - 1)
        out[y] = (round(year_end[y][1] / prev[1] - 1.0, 6)
                  if prev and prev[1] else None)
    return out


def dca_annualised(series: list):
    """Money-weighted return on one unit invested at every month-end.

    Solved as the periodic rate that turns n payments of 1 into the terminal value, which is the
    XIRR of equally spaced equal payments. The workbook used XIRR over a fixed per-ticker column
    range; that range was one of the things that stopped it scaling. This is the same measure with
    no per-ticker plumbing, and it reproduced the workbook's XIRR to within 0.05 of a percentage
    point on all four ETFs.
    """
    prices = [p for _, p in series if p and p > 0]
    n = len(prices)
    if n < 12:
        return None, None, None
    units = sum(1.0 / p for p in prices)
    terminal = prices[-1] * units
    total = terminal / n - 1.0
    lo, hi = -0.9999, 10.0                       # monthly rate bracket
    for _ in range(200):                         # bisection: no external solver needed
        mid = (lo + hi) / 2.0
        fv = sum((1.0 + mid) ** (n - 1 - i) for i in range(n))
        if fv < terminal:
            lo = mid
        else:
            hi = mid
    monthly = (lo + hi) / 2.0
    return round(total, 6), round((1.0 + monthly) ** 12 - 1.0, 6), n


def metrics(ticker: str, name: str, kind: str, currency: str, series: list) -> dict:
    """Every figure the dashboard shows for one security, plus an explicit data status."""
    out = {"ticker": ticker, "name": name, "type": kind, "currency": currency,
           "months": len(series), "annual": {}, "data_status": "NO DATA"}
    if not series:
        out["data_status"] = "MISSING DATA — no monthly price history stored"
        return out

    dates = [d for d, _ in series]
    prices = [p for _, p in series]
    first_d, last_d, first_p, last_p = dates[0], dates[-1], prices[0], prices[-1]
    years = (date.fromisoformat(last_d) - date.fromisoformat(first_d)).days / 365.0

    out.update({
        "first_date": first_d, "last_date": last_d,
        "first_price": round(first_p, 4), "current_price": round(last_p, 4),
        "years": round(years, 2),
        "cagr": round((last_p / first_p) ** (1 / years) - 1.0, 6) if years > 0 and first_p else None,
    })

    w12 = prices[-12:]
    out["high_52w"], out["low_52w"] = round(max(w12), 4), round(min(w12), 4)
    span = out["high_52w"] - out["low_52w"]
    out["range_position"] = round((last_p - out["low_52w"]) / span, 6) if span else None
    out["drawdown_52w"] = round(last_p / out["high_52w"] - 1.0, 6)

    w60 = prices[-60:]
    out["high_5y"], out["low_5y"] = round(max(w60), 4), round(min(w60), 4)
    out["high_all"], out["low_all"] = round(max(prices), 4), round(min(prices), 4)
    out["drawdown_from_high"] = round(last_p / out["high_all"] - 1.0, 6)

    ma12 = sum(prices[-12:]) / len(prices[-12:])
    out["ma12"] = round(ma12, 4)
    out["vs_ma12"] = round(last_p / ma12 - 1.0, 6) if ma12 else None
    out["trend"] = ("ABOVE TREND" if out["vs_ma12"] is not None and out["vs_ma12"] >= 0.05
                    else "BELOW TREND" if out["vs_ma12"] is not None and out["vs_ma12"] <= -0.05
                    else "AT TREND")

    total, ann, n = dca_annualised(series)
    out["dca_total_return"], out["dca_annualised"], out["dca_months"] = total, ann, n

    out["annual"] = {str(y): r for y, r in annual_returns(series).items() if y > BASE_YEAR}
    out["data_status"] = ("COMPLETE — %d months" % len(series) if len(series) >= 12
                          else "PARTIAL — %d months" % len(series))
    return out
