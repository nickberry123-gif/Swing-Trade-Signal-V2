"""
Central configuration, loaded entirely from environment variables.

CRITICAL: API keys must never be hard-coded and must never be sent to the frontend.
This module is the ONLY place that reads ALPACA_API_KEY / ALPACA_SECRET_KEY from the
environment. Every other module receives what it needs via function calls, not by
reading os.environ directly, so a future audit only has one place to check.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent

# Load backend/.env explicitly (not just cwd's .env) so `python app.py` works
# regardless of the directory it's launched from.
load_dotenv(BACKEND_DIR / ".env")


class Config:
    ALPACA_API_KEY: str | None = os.environ.get("ALPACA_API_KEY")
    ALPACA_SECRET_KEY: str | None = os.environ.get("ALPACA_SECRET_KEY")
    ALPACA_ENV: str = os.environ.get("ALPACA_ENV", "paper").lower()

    # Read but NOT YET USED for any score. Finnhub is a candidate source for the two things SEC
    # EDGAR genuinely cannot provide — forward estimates and estimate revisions — and nothing
    # will consume it until a diagnostic has established what this specific free account is
    # actually entitled to. The key itself is never returned by any endpoint; `has_finnhub_key`
    # answers "is it configured?" with a boolean, which is the only question worth asking from
    # outside the server.
    FINNHUB_API_KEY: str | None = os.environ.get("FINNHUB_API_KEY") or None

    # When DATABASE_URL points at Postgres the app uses it; otherwise it falls back to the
    # local SQLite file. Production needs Postgres because Render's free web-service tier has
    # no persistent disk — a SQLite file there is wiped on every deploy, which would silently
    # reset the accumulated signal history that Phase 6's analytics depend on.
    DATABASE_URL: str | None = os.environ.get("DATABASE_URL") or None

    DATABASE_PATH: str = os.environ.get("DATABASE_PATH", str(BACKEND_DIR / "swing_signals.db"))
    if not os.path.isabs(DATABASE_PATH):
        DATABASE_PATH = str(BACKEND_DIR / DATABASE_PATH)

    PORT: int = int(os.environ.get("PORT", "8000"))

    ALPACA_DATA_BASE_URL = "https://data.alpaca.markets"
    ALPACA_TRADING_BASE_URL = (
        "https://api.alpaca.markets" if ALPACA_ENV == "live" else "https://paper-api.alpaca.markets"
    )

    @classmethod
    def has_alpaca_credentials(cls) -> bool:
        return bool(cls.ALPACA_API_KEY and cls.ALPACA_SECRET_KEY)

    @classmethod
    def has_finnhub_key(cls) -> bool:
        """Presence only. Never returns, logs or exposes the key itself."""
        return bool(cls.FINNHUB_API_KEY)


# The tracked universe. Hard-coded on purpose: the app never discovers or adds tickers on its
# own, so what is tested is always exactly what is listed here.
#
# Expanded from 15 to 50 on 2026-08-14, at the user's request, because every analysis in this
# app had been sample-size limited — ranking 15 correlated mega-caps against each other is
# barely a cross-sectional test, and 52-week lows were too rare to judge a mean-reversion rule.
#
# SURVIVORSHIP BIAS GOT WORSE, NOT BETTER. These are today's winners, and the new names include
# some of the largest recoveries of the last three years (CVNA fell ~99% in 2022 and then rose
# roughly a hundredfold; APP, VRT, FIX and PLTR are all enormous winners). Any rule that buys
# weakness will look spectacular on this list precisely because every company that failed to
# recover is absent from it. More data has made the statistics better and the bias worse at the
# same time, and both need saying whenever a result is read.
STOCK_UNIVERSE = [
    # THE MAGNIFICENT 7, AND NOTHING ELSE. Every fund lives in ETF_UNIVERSE below. A fund is not a
    # company: it has no earnings, no sector and no fundamentals, and mixing the two made the
    # stock tables count four things they could never score.
    {"ticker": "AAPL", "name": "Apple Inc.", "sector": "Magnificent 7", "industry": "Consumer Electronics", "exchange": "NASDAQ"},
    {"ticker": "MSFT", "name": "Microsoft Corporation", "sector": "Magnificent 7", "industry": "Software", "exchange": "NASDAQ"},
    {"ticker": "GOOGL", "name": "Alphabet Inc.", "sector": "Magnificent 7", "industry": "Interactive Media", "exchange": "NASDAQ"},
    {"ticker": "AMZN", "name": "Amazon.com, Inc.", "sector": "Magnificent 7", "industry": "Internet Retail", "exchange": "NASDAQ"},
    {"ticker": "NVDA", "name": "NVIDIA Corporation", "sector": "Magnificent 7", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "META", "name": "Meta Platforms, Inc.", "sector": "Magnificent 7", "industry": "Interactive Media", "exchange": "NASDAQ"},
    {"ticker": "TSLA", "name": "Tesla, Inc.", "sector": "Magnificent 7", "industry": "Auto Manufacturers", "exchange": "NASDAQ"},
]

# Alpaca's REST symbology and TradingView's widget symbology diverge for dual-class share
# tickers (Alpaca: "BRK.B" with a dot; TradingView: "BRK.B" with a dot too, but some vendors
# use "BRK-B" with a hyphen) — kept as an explicit map here rather than a string transform so
# any future divergence is a one-line fix, not a hunt through the codebase.
TRADINGVIEW_SYMBOL_OVERRIDES = {
    "BRK.B": "BRK.B",
}

# Market-regime / relative-strength reference symbols. NOTE: 'VIX' itself is a CBOE index,
# not an equity/ETF, and Alpaca's market data API (like all equities-only feeds) does not
# carry it — confirmed against Alpaca's own community docs, not assumed. VIXY (ProShares VIX
# Short-Term Futures ETF) is a real, Alpaca-tradable proxy used instead, and is always labeled
# as a proxy, never presented as the actual index value.
BROAD_MARKET_SYMBOLS = ["SPY", "QQQ"]
VIX_TRUE_TICKER = "VIX"          # kept for display/labeling only — never fetched, always UNAVAILABLE
VIX_PROXY_TICKER = "VIXY"        # what actually gets fetched from Alpaca
SECTOR_ETF_SYMBOLS = ["SMH", "SOXX", "XLK", "XLF", "XLV", "XLY", "XLP", "XLI"]
REGIME_SYMBOLS = BROAD_MARKET_SYMBOLS + [VIX_PROXY_TICKER] + SECTOR_ETF_SYMBOLS

BENCHMARK_SYMBOLS = (
    [{"ticker": t, "name": n, "category": "BROAD_MARKET"} for t, n in [
        ("SPY", "SPDR S&P 500 ETF Trust"), ("QQQ", "Invesco QQQ Trust (Nasdaq-100)"),
    ]]
    + [{"ticker": VIX_PROXY_TICKER, "name": "ProShares VIX Short-Term Futures ETF (VIX proxy)", "category": "VOLATILITY_PROXY"}]
    + [{"ticker": t, "name": n, "category": "SECTOR"} for t, n in [
        ("SMH", "VanEck Semiconductor ETF"), ("SOXX", "iShares Semiconductor ETF"),
        ("XLK", "Technology Select Sector SPDR"), ("XLF", "Financial Select Sector SPDR"),
        ("XLV", "Health Care Select Sector SPDR"), ("XLY", "Consumer Discretionary Select Sector SPDR"),
        ("XLP", "Consumer Staples Select Sector SPDR"),
        ("XLI", "Industrial Select Sector SPDR"),
    ]]
)

# ETFs watched alongside the 50 companies on the Yearly page.
#
# THESE ARE PROXIES, AND THE UI SAYS SO ON EVERY ROW. The funds actually of interest — VHYL,
# CNX1 and SMGB — are London-listed UCITS ETFs. Alpaca covers US-listed securities only, so it
# cannot price any of them, and inventing prices for them would break the project's first rule.
# What it CAN price is the US-listed fund tracking the same thing, which is what each row shows.
#
# The match quality is not the same in every case, so `match` records it honestly:
#   EXACT     — same index or same fund family strategy, different listing/domicile.
#               Prices, currency and fees differ; the underlying exposure does not.
#   APPROXIMATE — closest available, materially different coverage. Say so loudly.
#
# S&P 500 is an index rather than a tradeable instrument, so SPY is the tracker, exactly as
# VIXY stands in for the VIX above.
ETF_UNIVERSE = [
    # The four London-listed funds, plus MAG6 — the home-made one.
    #
    # MAG6 IS NOT TRADEABLE and deliberately has no proxy. It is generated by this app from the
    # Magnificent 7 minus Tesla, equally weighted and rebalanced every month. It sits here because
    # it behaves like a fund, not because you can buy one.
    {"ticker": "VHYL", "name": "Vanguard FTSE All-World High Dividend Yield UCITS ETF",
     "listing": "London", "proxy": "VYM",
     "proxy_name": "Vanguard High Dividend Yield ETF", "match": "APPROXIMATE",
     "note": "Global high-dividend equities, priced in GBP. VYM holds US names only, so this "
             "is a shape comparison and not the same basket."},
    {"ticker": "CNX1", "name": "iShares NASDAQ 100 UCITS ETF (Acc)", "listing": "London",
     "proxy": "QQQ", "proxy_name": "Invesco QQQ Trust", "match": "EXACT",
     "note": "Both track the Nasdaq-100. CNX1 accumulates dividends and trades on the LSE; QQQ "
             "distributes and trades in the US. Same index, so the yearly shape matches, but "
             "total return differs through fees and withholding tax."},
    {"ticker": "IITU", "name": "iShares S&P 500 Information Technology Sector UCITS ETF",
     "listing": "London", "proxy": "XLK", "proxy_name": "Technology Select Sector SPDR Fund",
     "match": "APPROXIMATE",
     "note": "US information technology. Semiconductors are a large share of both."},
    {"ticker": "SMGB", "name": "VanEck Semiconductor UCITS ETF", "listing": "London",
     "proxy": "SMH", "proxy_name": "VanEck Semiconductor ETF", "match": "EXACT",
     "note": "Same index and same manager; the London share class is priced in GBP."},
    {"ticker": "MAG6", "name": "Magnificent 7 excluding Tesla — equal weight, monthly rebalanced",
     "listing": "Home-made", "proxy": None, "proxy_name": None, "match": "NOT TRADEABLE",
     "note": "Built here from AAPL, MSFT, GOOGL, AMZN, NVDA and META. Each month's return is the "
             "plain average of its six constituents, which is what an equal split means. There is "
             "no fund to buy and no proxy that would be honest to show."},
]

# MAG6 has no proxy and never will — it is generated here, not tracked by any fund. Filtering
# None out keeps a null from reaching a price request as if it were a ticker.
# THE US-LISTED EQUIVALENTS, TRACKED ALONGSIDE — NOT INSTEAD OF — THE FUNDS ACTUALLY HELD.
#
# Alpaca prices US securities only, so the London UCITS funds above can never update live; their
# history is the embedded workbook series. These four DO update, so they show today's movement for
# the same underlying exposure. They are a window on the same market, not a substitute: currency,
# fees, dividend treatment and withholding tax all differ, so returns diverge.
#
# `tracks` names the held fund each one shadows. VYM is the weakest link and is labelled as such:
# VHYL is FTSE All-World (US and international), while VYM holds US names only. No single US fund
# matches it, so this is a shape comparison rather than an equivalent.
US_ETF_UNIVERSE = [
    {"ticker": "QQQ", "name": "Invesco QQQ Trust", "tracks": "CNX1",
     "match": "EXACT", "note": "Same index — Nasdaq-100. CNX1 accumulates dividends; QQQ pays them out."},
    {"ticker": "XLK", "name": "Technology Select Sector SPDR Fund", "tracks": "IITU",
     "match": "EXACT", "note": "Same index — S&P 500 Information Technology."},
    {"ticker": "SMH", "name": "VanEck Semiconductor ETF", "tracks": "SMGB",
     "match": "EXACT", "note": "Same index and same manager as the London share class."},
    {"ticker": "VYM", "name": "Vanguard High Dividend Yield ETF", "tracks": "VHYL",
     "match": "APPROXIMATE", "note": "VHYL is global; VYM is US-only. The closest single US fund, "
                                     "but not the same basket — treat as shape, not equivalence."},
]

US_ETF_SYMBOLS = [e["ticker"] for e in US_ETF_UNIVERSE]


ETF_PROXY_SYMBOLS = [e["proxy"] for e in ETF_UNIVERSE if e["proxy"]]

# Each of the 50 tracked stocks' most relevant sector ETF, drawn only from the ETF list the
# project spec provided (SMH/SOXX/XLK/XLF/XLV/XLY/XLP — there is no XLC "communication
# services" ETF in that list, so META and GOOGL are mapped to XLK as the closest available
# proxy; this simplification is surfaced in the UI, not hidden).
SECTOR_ETF_MAP = {
    "NVDA": "SMH",
    "MU": "SMH",
    "AVGO": "SMH",
    "MRVL": "SMH",
    "KLAC": "SMH",
    "LRCX": "SMH",
    "AMAT": "SMH",
    "AMD": "SMH",
    "ASML": "SMH",
    "SNPS": "SMH",
    "PLTR": "XLK",
    "APP": "XLK",
    "ANET": "XLK",
    "CRWD": "XLK",
    "NET": "XLK",
    "NOW": "XLK",
    "MSFT": "XLK",
    "GOOGL": "XLK",
    "AMZN": "XLK",
    "AAPL": "XLK",
    "CVNA": "XLY",
    "CELH": "XLP",
    "DECK": "XLY",
    "MELI": "XLY",
    "BKNG": "XLY",
    "UBER": "XLY",
    "CMG": "XLY",
    "TSLA": "XLY",
    "COST": "XLP",
    "NFLX": "XLY",
    "FIX": "XLI",
    "VRT": "XLI",
    "PWR": "XLI",
    "HWM": "XLI",
    "URI": "XLI",
    "CAT": "XLI",
    "GE": "XLI",
    "TT": "XLI",
    "ETN": "XLI",
    "CTAS": "XLI",
    "LLY": "XLV",
    "ISRG": "XLV",
    "VRTX": "XLV",
    "REGN": "XLV",
    "NVO": "XLV",
    "HCA": "XLV",
    "TMO": "XLV",
    "SYK": "XLV",
    "ABBV": "XLV",
    "DHR": "XLV",
}

# Canonical timeframe strings used throughout the app (must match TIMEFRAME_MAP in
# providers/alpaca_provider.py). Daily is primary for Phase 2 indicators/regime; the others
# are wired through the same code path for later use (intraday entry refinement, Phase 3+).
TIMEFRAMES = ["1Day", "4Hour", "1Hour", "30Min", "15Min"]
PRIMARY_TIMEFRAME = "1Day"
