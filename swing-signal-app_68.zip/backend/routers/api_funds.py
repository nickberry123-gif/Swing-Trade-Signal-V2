"""FUNDS ON THE DASHBOARD — what you hold, and the US listings that move in real time.

TWO GROUPS, NEVER MIXED INTO ONE PRICE COLUMN.

    HELD    — the London UCITS funds you actually own. Alpaca does not price London listings, so
              their price is the last MONTH-END from the workbook series and is labelled as such.
              It is a snapshot, not a live quote, and the difference is stated on every row.
    TRACKER — the US-listed equivalents. These do price live, so they show today's movement for
              the same underlying exposure. They are a window on the same market, not a
              substitute: currency, fees and dividend treatment all differ.

Your average price and gain/loss work on either, because that is arithmetic on whatever price the
row carries. What it must never do is compare a GBP cost against a USD price, so the currency is
shown beside every figure.
"""
from flask import Blueprint, jsonify

from config import ETF_UNIVERSE, US_ETF_UNIVERSE
from db import get_db
from services import monthly_engine as me
from services import value_bars_service as vb
from services.market_service import get_snapshots_cached

bp = Blueprint("api_funds", __name__, url_prefix="/api/funds")

HELD, TRACKER = "HELD", "US TRACKER"


def _positions(db) -> dict:
    return {r["ticker"]: r["avg_price"]
            for r in db.execute("SELECT ticker, avg_price FROM my_positions").fetchall()}


def _row(ticker, name, group, currency, price, price_basis, series, extra=None):
    m = me.metrics(ticker, name, "ETF", currency, series)
    out = {"ticker": ticker, "name": name, "group": group, "currency": currency,
           "price": price, "price_basis": price_basis,
           "trend": m.get("trend"), "vs_ma12": m.get("vs_ma12"),
           "drawdown_from_high": m.get("drawdown_from_high"),
           "range_position": m.get("range_position"),
           "months": m.get("months"), "data_status": m.get("data_status"),
           # A fund has no earnings, no balance sheet and nothing for a company-health model to
           # read. NOT APPLICABLE is the truthful answer and is not the same as MISSING.
           "health_verdict": "NOT APPLICABLE — a fund has no company fundamentals"}
    out.update(extra or {})
    return out


@bp.get("")
def funds():
    db = get_db()
    seed = me.etf_seed()
    pos = _positions(db)
    rows = []

    for e in ETF_UNIVERSE:
        if e["ticker"] == me.SYNTHETIC:
            continue
        series = seed.get(e["ticker"], [])
        last = series[-1] if series else (None, None)
        rows.append(_row(e["ticker"], e["name"], HELD, "GBP", last[1],
                         f"month-end {last[0]} — workbook series, not a live quote" if last[0]
                         else "no stored price",
                         series,
                         {"tracked_by": next((u["ticker"] for u in US_ETF_UNIVERSE
                                              if u["tracks"] == e["ticker"]), None)}))

    quotes, quote_error = {}, None
    try:
        quotes = get_snapshots_cached([u["ticker"] for u in US_ETF_UNIVERSE]) or {}
    except Exception as e:                    # a quote failure must not blank the held rows
        quote_error = str(e)
    for u in US_ETF_UNIVERSE:
        q = quotes.get(u["ticker"])
        live = getattr(q, "last_price", None)
        prev = getattr(q, "prev_close", None) or getattr(q, "daily_open", None)
        series = me.month_end_samples(vb.bars(db, u["ticker"]))
        rows.append(_row(u["ticker"], u["name"], TRACKER, "USD",
                         live if live else (series[-1][1] if series else None),
                         "live quote" if live else
                         (f"month-end {series[-1][0]} — no live quote available" if series
                          else "no price available"),
                         series,
                         {"tracks": u["tracks"], "match": u["match"], "note": u["note"],
                          "change_pct": ((live / prev - 1.0)
                                         if (live and prev and prev > 0) else None)}))

    for r in rows:
        avg = pos.get(r["ticker"])
        r["avg_price"] = avg
        r["gain_pct"] = ((r["price"] / avg - 1.0) if (avg and avg > 0 and r["price"]) else None)

    return jsonify({
        "held": [r for r in rows if r["group"] == HELD],
        "trackers": [r for r in rows if r["group"] == TRACKER],
        "note": ("Held funds are London-listed and priced in GBP from the workbook's month-end "
                 "series — Alpaca does not quote them. The US trackers price live in USD. The two "
                 "are never combined, and a GBP cost basis is never compared with a USD price."),
        "quote_error": quote_error,
    })
