"""HEALTH AND NEWS FOR THE DASHBOARD — both surfaced as they are, neither reinvented.

HEALTH is the frozen C1 Company Health score, computed by the existing validation pipeline. It is
fundamentals only: no price, no P/E, no technicals. Nothing here changes it — this endpoint reads
it so the dashboard can show it beside the price.

NEWS is the existing keyword-classified feed. It is deliberately reported as a COUNT and a most
recent headline, not as a judgement. A keyword classifier cannot tell you whether an investment
case broke; it can tell you something happened worth reading, and that is what is shown.
"""
from flask import Blueprint, jsonify, request

from providers.base import ProviderError
from services import fundamentals_history_service as fh

from config import Config
from db import get_db
from services.data_validation_service import validate_ticker
from services.news_service import get_news_for_ticker
from services.signals_service import TICKERS

bp = Blueprint("api_health_news", __name__, url_prefix="/api/overview")

NEWS_LIMIT = 5


@bp.get("")
def overview():
    """One row per tracked company: health verdict, coverage, and recent news."""
    db = get_db()
    only = (request.args.get("tickers") or "").upper()
    wanted = ([t for t in sorted(TICKERS) if t in {x.strip() for x in only.split(",")}]
              if only else sorted(TICKERS))
    out = []
    for t in wanted:
        row = {"ticker": t}
        try:
            v = validate_ticker(db, t)
            row["health_score"] = v.get("company_health_score")
            row["health_verdict"] = v.get("company_health_verdict") or "MISSING DATA"
            row["health_coverage_pct"] = v.get("company_health_coverage_pct")
        except Exception as e:                      # a broken row must not blank the whole table
            row["health_score"] = None
            row["health_verdict"] = "MISSING DATA"
            row["health_error"] = str(e)
        items = get_news_for_ticker(db, t, limit=NEWS_LIMIT) or []
        row["news_count"] = len(items)
        row["news_latest"] = (items[0].get("headline") or items[0].get("title")) if items else None
        row["news_latest_at"] = items[0].get("published_at") if items else None
        out.append(row)
    return jsonify({
        "tickers": len(out),
        "news_note": ("News is counted and linked, not interpreted. The classifier is keyword-based "
                      "and cannot tell you whether an investment case has changed."),
        "alpaca_configured": Config.has_alpaca_credentials(),
        "results": out,
    })


@bp.post("/fundamentals/refresh")
def refresh_fundamentals():
    """Pull filings from SEC EDGAR for the tracked companies.

    FREE AND KEYLESS — EDGAR is public, so this needs no Alpaca credentials and no paid provider.

    This is the one action that fixes BOTH the missing P/E and the missing Health score, because
    C1 and the price/earnings ratio read the same filings. Reporting them as two separate problems
    would have sent you looking for two separate fixes.
    """
    db = get_db()
    only = (request.args.get("tickers") or "").upper()
    wanted = ([t for t in sorted(TICKERS) if t in {x.strip() for x in only.split(",")}]
              if only else sorted(TICKERS))
    out = []
    for t in wanted:
        try:
            written = fh.refresh(db, t, force=True)
            cov = fh.coverage(db, t)
            out.append({"ticker": t, "status": "OK", "written": written,
                        "periods": cov.get("periods") if isinstance(cov, dict) else None})
        except ProviderError as e:
            out.append({"ticker": t, "status": "UNAVAILABLE", "error": str(e)})
        except Exception as e:                 # one bad filer must not abandon the rest
            out.append({"ticker": t, "status": "ERROR", "error": str(e)})
    ok = [r for r in out if r["status"] == "OK"]
    return jsonify({
        "requested": len(wanted), "ok": len(ok), "failed": len(out) - len(ok),
        "source": "SEC EDGAR (public, no API key required)",
        "note": "Fills both the P/E and the Company Health columns — they read the same filings.",
        "results": out,
    })
