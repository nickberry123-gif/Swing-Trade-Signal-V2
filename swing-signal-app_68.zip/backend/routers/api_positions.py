"""YOUR AVERAGE PRICE — hand-entered, stored, never computed.

The only writable user data in the application. It records what you actually paid, which no market
data feed can know, and nothing else in the app may overwrite it.
"""
from datetime import datetime, timezone

from flask import Blueprint, jsonify, request

from db import get_db
from config import ETF_UNIVERSE, STOCK_UNIVERSE, US_ETF_UNIVERSE

# Every security you can see, not just the companies. You hold funds too, and a cost basis is
# yours to record whatever the instrument is.
TRACKED = ({s["ticker"] for s in STOCK_UNIVERSE}
           | {e["ticker"] for e in ETF_UNIVERSE}
           | {e["ticker"] for e in US_ETF_UNIVERSE})

bp = Blueprint("api_positions", __name__, url_prefix="/api/positions")


def _rows(db) -> dict:
    return {r["ticker"]: r["avg_price"]
            for r in db.execute("SELECT ticker, avg_price FROM my_positions").fetchall()}


@bp.get("")
def all_positions():
    return jsonify({"positions": _rows(get_db())})


@bp.put("/<ticker>")
def set_position(ticker):
    """Save (or clear) the average price for one ticker.

    An empty value CLEARS the entry rather than storing zero. Zero is a real price and would show
    as an infinite gain; "not entered" is a different statement and is stored as NULL.
    """
    ticker = ticker.upper()
    if ticker not in TRACKED:
        return jsonify({"error": f"{ticker} is not tracked"}), 404
    raw = (request.get_json(silent=True) or {}).get("avg_price")
    if raw in (None, "", "null"):
        price = None
    else:
        try:
            price = float(raw)
        except (TypeError, ValueError):
            return jsonify({"error": "avg_price must be a number, or empty to clear"}), 400
        if price <= 0:
            return jsonify({"error": "avg_price must be greater than zero"}), 400
    db = get_db()
    db.execute(
        """INSERT INTO my_positions (ticker, avg_price, updated_at) VALUES (?, ?, ?)
           ON CONFLICT(ticker) DO UPDATE SET
               avg_price = excluded.avg_price, updated_at = excluded.updated_at""",
        (ticker, price, datetime.now(timezone.utc).isoformat()))
    db.commit()
    return jsonify({"ticker": ticker, "avg_price": price})
