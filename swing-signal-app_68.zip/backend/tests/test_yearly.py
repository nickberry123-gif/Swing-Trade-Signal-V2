"""
Tests for services/yearly_service.py — average price per calendar year.

The arithmetic is simple, so the tests concentrate on the ways it can quietly mislead: a year
the data only partly covers averaging out lower than a full one, a missing year turning into a
zero, and a gap being bridged so a two-year move gets labelled as one year's change.
"""
import sys
import unittest
from datetime import date, datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import database
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import yearly_service as ys

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"
TODAY = date(2026, 8, 14)


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    conn.commit()
    return conn


def frame(rows):
    """rows: list of (iso_date, close)."""
    return pd.DataFrame({
        "ts": [r[0] for r in rows],
        "open": [r[1] for r in rows],
        "high": [r[1] for r in rows],
        "low": [r[1] for r in rows],
        "close": [r[1] for r in rows],
        "volume": [1_000_000.0] * len(rows),
    })


def full_year(year, price, start_month=1, days=None):
    """One bar a week through a calendar year at a constant price."""
    rows = []
    d = date(year, start_month, 1)
    end = date(year, 12, 31) if days is None else d + timedelta(days=days)
    while d <= end:
        rows.append((d.isoformat(), float(price)))
        d += timedelta(days=7)
    return rows


def ohlc_frame(rows):
    """rows: list of (iso_date, low, high, close) — distinct values so high/low tests are real."""
    return pd.DataFrame({
        "ts": [r[0] for r in rows],
        "open": [r[3] for r in rows],
        "high": [r[2] for r in rows],
        "low": [r[1] for r in rows],
        "close": [r[3] for r in rows],
        "volume": [1_000_000.0] * len(rows),
    })


def patched(df, meta=None):
    return patch.object(ys, "get_bars_df", return_value=(df, meta or {"error": None}))


class TestYearlyAverages(unittest.TestCase):
    def test_average_is_the_mean_of_that_years_closes(self):
        rows = [("2025-03-03", 100.0), ("2025-06-02", 200.0), ("2025-09-01", 300.0)]
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y2025 = next(y for y in out["years"] if y["year"] == 2025)
        self.assertEqual(y2025["avg_price"], 200.0)
        self.assertEqual(y2025["bars"], 3)

    def test_years_are_separated_not_pooled(self):
        rows = full_year(2024, 100.0) + full_year(2025, 150.0)
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        by_year = {y["year"]: y["avg_price"] for y in out["years"]}
        self.assertEqual(by_year[2024], 100.0)
        self.assertEqual(by_year[2025], 150.0)

    def test_six_years_are_returned_oldest_first(self):
        with patched(frame(full_year(2025, 10.0))):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertEqual([y["year"] for y in out["years"]], [2021, 2022, 2023, 2024, 2025, 2026])


class TestMissingDataIsNeverFabricated(unittest.TestCase):
    def test_year_with_no_bars_is_none_not_zero(self):
        with patched(frame(full_year(2025, 100.0))):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y2022 = next(y for y in out["years"] if y["year"] == 2022)
        self.assertIsNone(y2022["avg_price"])
        self.assertNotEqual(y2022["avg_price"], 0)
        self.assertEqual(y2022["bars"], 0)

    def test_empty_history_returns_unavailable_not_an_empty_table(self):
        with patched(frame([]), {"error": "provider down"}):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertEqual(out["data_status"], "UNAVAILABLE")
        self.assertIsNone(out["latest_close"])
        self.assertTrue(all(y["avg_price"] is None for y in out["years"]))

    def test_a_gap_is_not_bridged_into_a_fake_one_year_move(self):
        """2023 missing entirely: the 2022->2023 and 2023->2024 steps must both be None rather
        than quietly reporting the two-year move as a single year's change."""
        rows = full_year(2022, 100.0) + full_year(2024, 400.0)
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        steps = {(s["from"], s["to"]): s["pct"] for s in out["yoy_pct"]}
        self.assertIsNone(steps[(2022, 2023)])
        self.assertIsNone(steps[(2023, 2024)])

    def test_avg_year_pct_ignores_missing_steps_rather_than_treating_them_as_zero(self):
        rows = full_year(2022, 100.0) + full_year(2024, 400.0) + full_year(2025, 800.0)
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        # The only computable step is 2024->2025 (+100%). Counting the None steps as 0 would
        # dilute it to +20%.
        self.assertEqual(out["avg_year_pct"], 100.0)
        self.assertEqual(out["avg_year_pct_basis"], 1)

    def test_no_computable_steps_gives_none_not_zero(self):
        with patched(frame(full_year(2025, 100.0))):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertIsNone(out["avg_year_pct"])


class TestPartialYearsAreFlagged(unittest.TestCase):
    """A part-year average is a real number over a shorter window. Shown unmarked next to full
    years it reads as a genuine move in the price, which is exactly the wrong conclusion."""

    def test_year_starting_mid_year_is_marked_partial(self):
        rows = full_year(2021, 100.0, start_month=8) + full_year(2022, 100.0)
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y2021 = next(y for y in out["years"] if y["year"] == 2021)
        self.assertTrue(y2021["partial"])
        self.assertEqual(y2021["reason"], "history starts mid-year")

    def test_complete_year_is_not_marked_partial(self):
        with patched(frame(full_year(2024, 100.0))):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y2024 = next(y for y in out["years"] if y["year"] == 2024)
        self.assertFalse(y2024["partial"])

    def test_current_year_is_in_progress_not_partial(self):
        """The current year being incomplete is the calendar, not a data problem — the two get
        different labels because they warrant different conclusions."""
        rows = full_year(2026, 100.0, start_month=1, days=200)
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y2026 = next(y for y in out["years"] if y["year"] == 2026)
        self.assertTrue(y2026["year_in_progress"])
        self.assertFalse(y2026["partial"])

    def test_step_into_a_partial_year_is_flagged(self):
        rows = full_year(2021, 100.0, start_month=8) + full_year(2022, 120.0)
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        step = next(s for s in out["yoy_pct"] if s["to"] == 2022)
        self.assertTrue(step["partial"])


class TestYearOnYearMaths(unittest.TestCase):
    def test_step_is_percent_change_between_consecutive_averages(self):
        rows = full_year(2024, 100.0) + full_year(2025, 125.0)
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        step = next(s for s in out["yoy_pct"] if s["from"] == 2024 and s["to"] == 2025)
        self.assertEqual(step["pct"], 25.0)

    def test_a_fall_is_negative(self):
        rows = full_year(2024, 200.0) + full_year(2025, 150.0)
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        step = next(s for s in out["yoy_pct"] if s["to"] == 2025)
        self.assertEqual(step["pct"], -25.0)

    def test_avg_year_pct_against_a_hand_computed_reference(self):
        """100 -> 110 -> 121 -> 121 is +10%, +10%, 0% — an average of 6.67%."""
        rows = (full_year(2023, 100.0) + full_year(2024, 110.0)
                + full_year(2025, 121.0) + full_year(2026, 121.0, days=200))
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertEqual(out["avg_year_pct"], 6.67)

    def test_zero_previous_average_does_not_divide_by_zero(self):
        rows = full_year(2024, 0.0) + full_year(2025, 50.0)
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        step = next(s for s in out["yoy_pct"] if s["to"] == 2025)
        self.assertIsNone(step["pct"])


class TestLatestClose(unittest.TestCase):
    def test_latest_close_is_the_final_bar(self):
        rows = full_year(2025, 100.0) + [("2026-08-13", 321.0)]
        with patched(frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertEqual(out["latest_close"], 321.0)
        self.assertEqual(out["latest_close_date"], "2026-08-13")

    def test_stale_fallback_is_reported_not_hidden(self):
        with patched(frame(full_year(2025, 100.0)), {"stale_fallback": True, "error": "down"}):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertEqual(out["data_status"], "STALE")


class TestBatch(unittest.TestCase):
    def test_one_failing_ticker_does_not_blank_the_others(self):
        calls = {"n": 0}

        def flaky(db, ticker, today=None):
            calls["n"] += 1
            if ticker == "MU":
                raise ValueError("boom")
            return {"ticker": ticker, "years": [], "avg_year_pct": 5.0}

        with patch.object(ys, "compute_yearly_for_ticker", side_effect=flaky):
            out = ys.compute_yearly(make_db(), ["AAPL", "MU", "NVDA"], TODAY)

        self.assertEqual(len(out["results"]), 3)
        bad = next(r for r in out["results"] if r["ticker"] == "MU")
        self.assertEqual(bad["data_status"], "UNAVAILABLE")
        self.assertIn("boom", bad["error"])
        self.assertEqual(next(r for r in out["results"] if r["ticker"] == "NVDA")["avg_year_pct"], 5.0)

    def test_years_shown_is_oldest_first_and_matches_today(self):
        with patch.object(ys, "compute_yearly_for_ticker", return_value={"ticker": "AAPL"}):
            out = ys.compute_yearly(make_db(), ["AAPL"], TODAY)
        self.assertEqual(out["years_shown"], [2021, 2022, 2023, 2024, 2025, 2026])
        self.assertEqual(out["current_year"], 2026)


class TestDeepHistoryFetch(unittest.TestCase):
    """The cache-coverage rule in bars_service is a percentage of the requested span, so a cache
    holding five years satisfies a 5.6-year request and the earliest months are never fetched.
    This page needs a specific start date, so it asks once — and only once, or a ticker whose
    history genuinely does not reach that far would re-fetch on every page load forever."""

    def setUp(self):
        ys._deep_fetch_attempted.clear()

    def tearDown(self):
        ys._deep_fetch_attempted.clear()

    def test_short_history_triggers_one_forced_refresh(self):
        short = frame(full_year(2024, 100.0) + full_year(2025, 100.0))
        with patch.object(ys, "get_bars_df", return_value=(short, {"error": None})) as m:
            ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertEqual(m.call_count, 2)
        self.assertTrue(m.call_args.kwargs["force_refresh"])

    def test_the_forced_refresh_is_not_repeated_on_later_loads(self):
        short = frame(full_year(2024, 100.0) + full_year(2025, 100.0))
        with patch.object(ys, "get_bars_df", return_value=(short, {"error": None})) as m:
            ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
            m.reset_mock()
            ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertEqual(m.call_count, 1)
        self.assertNotIn("force_refresh", m.call_args.kwargs)

    def test_history_already_deep_enough_is_not_refetched(self):
        deep = frame(full_year(2021, 100.0) + full_year(2025, 100.0))
        with patch.object(ys, "get_bars_df", return_value=(deep, {"error": None})) as m:
            ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertEqual(m.call_count, 1)

    def test_lookback_reaches_1_january_of_the_earliest_year(self):
        self.assertEqual(ys._required_start(TODAY), date(2021, 1, 1))
        self.assertGreaterEqual(ys._lookback_days(TODAY), (TODAY - date(2021, 1, 1)).days)


class TestYearlyPageWiring(unittest.TestCase):
    """The page is only useful if it is reachable and its script actually exists. A template
    referencing a missing JS file renders a permanently empty table with no error anywhere."""

    def setUp(self):
        import app as app_module
        self.app_module = app_module
        self.client = app_module.create_app().test_client()

    def test_page_route_renders(self):
        """Yearly is the ORIGINAL page. The Mag 7 / ETF work was added alongside it at
        /monthly and must never displace it again."""
        resp = self.client.get("/yearly")
        self.assertEqual(resp.status_code, 200)
        self.assertIn(b"Yearly Prices", resp.data)
        for section in (b"Year by Year", b"Index Trackers"):
            self.assertIn(section, resp.data, "a Yearly section went missing")
        self.assertIn(b"Returns by calendar year", self.client.get("/monthly").data)

    def test_page_is_in_the_navigation(self):
        self.assertIn(b'href="/yearly"', self.client.get("/").data)

    def test_template_loads_a_script_that_exists(self):
        frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
        html = (frontend / "templates" / "yearly.html").read_text()
        self.assertIn("js/yearly.js", html)
        self.assertTrue((frontend / "static" / "js" / "yearly.js").exists())

    def test_api_returns_unavailable_without_credentials_rather_than_erroring(self):
        from config import Config
        with patch.object(Config, "has_alpaca_credentials", staticmethod(lambda: False)):
            resp = self.client.get("/api/stocks/yearly")
        self.assertEqual(resp.status_code, 200)
        body = resp.get_json()
        self.assertEqual(body["data_status"], "UNAVAILABLE")
        self.assertEqual(body["results"], [])

    def test_the_page_does_not_poll_the_expensive_endpoint(self):
        """A timer on this endpoint would stack multi-minute provider fetches on top of each
        other — the same pile-up that took the site down once already."""
        js = (Path(__file__).resolve().parent.parent.parent
              / "frontend" / "static" / "js" / "yearly.js").read_text()
        self.assertNotIn("setInterval", js)
        self.assertNotIn("startPolling", js)


class TestEtfProxies(unittest.TestCase):
    """The ETFs the user follows are London-listed UCITS funds that Alpaca cannot price. Each
    row is priced through a US-listed proxy, and the row must never lose track of that."""

    def test_universe_entries_are_complete(self):
        from routers.api_stocks import ETF_PROXIED as ETF_UNIVERSE
        self.assertTrue(ETF_UNIVERSE)
        for e in ETF_UNIVERSE:
            for key in ("ticker", "name", "proxy", "proxy_name", "match", "note"):
                self.assertIn(key, e, f"{e.get('ticker')} is missing {key}")
            self.assertIn(e["match"], ("EXACT", "APPROXIMATE"))
            self.assertTrue(e["note"].strip(), "every proxy must carry an explanation")

    def test_the_requested_tickers_are_all_present(self):
        from routers.api_stocks import ETF_PROXIED as ETF_UNIVERSE
        self.assertEqual({e["ticker"] for e in ETF_UNIVERSE},
                         {"VHYL", "CNX1", "IITU", "SMGB"})

    def test_imperfect_match_is_labelled_approximate_not_exact(self):
        """VHYL is worldwide, VYM is US-only. Labelling that EXACT would be the lie."""
        from routers.api_stocks import ETF_PROXIED as ETF_UNIVERSE
        vhyl = next(e for e in ETF_UNIVERSE if e["ticker"] == "VHYL")
        self.assertEqual(vhyl["match"], "APPROXIMATE")
        self.assertEqual(vhyl["proxy"], "VYM")

    def test_row_keeps_the_users_ticker_and_names_the_proxy(self):
        etfs = [{"ticker": "CNX1", "name": "iShares NASDAQ 100 UCITS ETF", "listing": "London",
                 "proxy": "QQQ", "proxy_name": "Invesco QQQ Trust", "match": "EXACT",
                 "note": "same index"}]
        with patched(frame(full_year(2024, 100.0) + full_year(2025, 120.0))):
            out = ys.compute_yearly_for_etfs(make_db(), etfs, TODAY)
        row = out[0]
        self.assertEqual(row["ticker"], "CNX1")          # what the user follows
        self.assertEqual(row["priced_via"], "QQQ")       # where the numbers came from
        self.assertEqual(row["match"], "EXACT")
        self.assertTrue(row["is_etf"])
        self.assertEqual(row["proxy_note"], "same index")

    def test_prices_are_fetched_for_the_proxy_not_the_uncoverable_ticker(self):
        """Requesting CNX1 from Alpaca returns nothing — the fetch must use QQQ."""
        etfs = [{"ticker": "CNX1", "proxy": "QQQ", "name": "x", "proxy_name": "y",
                 "match": "EXACT", "note": "z"}]
        with patch.object(ys, "compute_yearly_for_ticker", return_value={}) as m:
            ys.compute_yearly_for_etfs(make_db(), etfs, TODAY)
        self.assertEqual(m.call_args.args[1], "QQQ")

    def test_a_failing_etf_does_not_break_the_others(self):
        etfs = [{"ticker": "CNX1", "proxy": "QQQ", "name": "x", "proxy_name": "y",
                 "match": "EXACT", "note": "z"},
                {"ticker": "SMGB", "proxy": "SMH", "name": "x", "proxy_name": "y",
                 "match": "EXACT", "note": "z"}]

        def flaky(db, ticker, today=None):
            if ticker == "QQQ":
                raise ValueError("boom")
            return {"avg_year_pct": 12.0}

        with patch.object(ys, "compute_yearly_for_ticker", side_effect=flaky):
            out = ys.compute_yearly_for_etfs(make_db(), etfs, TODAY)
        self.assertEqual(out[0]["data_status"], "UNAVAILABLE")
        self.assertEqual(out[0]["ticker"], "CNX1")
        self.assertEqual(out[1]["avg_year_pct"], 12.0)

    def test_compute_yearly_includes_an_etf_section(self):
        with patch.object(ys, "compute_yearly_for_ticker", return_value={"avg_year_pct": 1.0}):
            out = ys.compute_yearly(make_db(), ["AAPL"], TODAY,
                                    etfs=[{"ticker": "CNX1", "proxy": "QQQ", "name": "x",
                                           "proxy_name": "y", "match": "EXACT", "note": "z"}])
        self.assertEqual(len(out["etfs"]), 1)
        self.assertEqual(out["etfs"][0]["ticker"], "CNX1")
        self.assertEqual(len(out["results"]), 1)

    def test_no_etfs_requested_gives_an_empty_list_not_a_crash(self):
        with patch.object(ys, "compute_yearly_for_ticker", return_value={"avg_year_pct": 1.0}):
            out = ys.compute_yearly(make_db(), ["AAPL"], TODAY)
        self.assertEqual(out["etfs"], [])

    def test_etfs_are_not_in_the_tradeable_universe(self):
        """SUPERSEDED BY INSTRUCTION. The universe was cut to eleven securities and the four
        London ETFs are now tracked in their own right, so the old separation no longer holds.
        What still must hold is that each is typed correctly and that no ETF is treated as a
        Magnificent 7 constituent."""
        from routers.api_stocks import ETF_PROXIED as ETF_UNIVERSE, STOCK_UNIVERSE
        stock_tickers = {s["ticker"] for s in STOCK_UNIVERSE}
        self.assertEqual(stock_tickers,
                         {"AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META", "TSLA"})
        for e in ETF_UNIVERSE:
            self.assertNotIn(e["ticker"], stock_tickers,
                             f"{e['ticker']} is a fund and must not sit in the stock list")


class TestYearHighAndLow(unittest.TestCase):
    """The year's range is what a swing trader is actually looking for here — the average alone
    says nothing about how far the price travelled to get there."""

    def test_high_and_low_come_from_intraday_extremes_not_closes(self):
        """A stock that spiked to 140 intraday and closed at 128 did trade at 140. Reporting the
        highest CLOSE would understate the range that was actually available."""
        rows = [("2025-03-03", 95.0, 140.0, 128.0),
                ("2025-06-02", 80.0, 130.0, 120.0),
                ("2025-09-01", 110.0, 125.0, 118.0)]
        with patched(ohlc_frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y = next(y for y in out["years"] if y["year"] == 2025)
        self.assertEqual(y["high"], 140.0)
        self.assertEqual(y["low"], 80.0)
        self.assertNotEqual(y["high"], 128.0)   # the highest close
        self.assertNotEqual(y["low"], 118.0)    # the lowest close

    def test_high_and_low_dates_point_at_the_right_bars(self):
        rows = [("2025-03-03", 95.0, 140.0, 128.0),
                ("2025-06-02", 80.0, 130.0, 120.0)]
        with patched(ohlc_frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y = next(y for y in out["years"] if y["year"] == 2025)
        self.assertEqual(y["high_date"], "2025-03-03")
        self.assertEqual(y["low_date"], "2025-06-02")

    def test_range_pct_is_measured_from_the_low(self):
        rows = [("2025-03-03", 100.0, 150.0, 120.0)]
        with patched(ohlc_frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y = next(y for y in out["years"] if y["year"] == 2025)
        self.assertEqual(y["range_pct"], 50.0)   # 100 -> 150

    def test_high_and_low_do_not_leak_between_years(self):
        rows = ([("2024-05-01", 10.0, 20.0, 15.0)]
                + [("2025-05-01", 200.0, 300.0, 250.0)])
        with patched(ohlc_frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        by_year = {y["year"]: y for y in out["years"]}
        self.assertEqual(by_year[2024]["high"], 20.0)
        self.assertEqual(by_year[2024]["low"], 10.0)
        self.assertEqual(by_year[2025]["high"], 300.0)
        self.assertEqual(by_year[2025]["low"], 200.0)

    def test_missing_year_has_no_fabricated_range(self):
        with patched(ohlc_frame([("2025-05-01", 10.0, 20.0, 15.0)])):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y2022 = next(y for y in out["years"] if y["year"] == 2022)
        self.assertIsNone(y2022["high"])
        self.assertIsNone(y2022["low"])
        self.assertIsNone(y2022["range_pct"])
        self.assertNotEqual(y2022["high"], 0)

    def test_empty_history_returns_no_range(self):
        with patched(frame([]), {"error": "down"}):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        self.assertTrue(all(y["high"] is None and y["low"] is None for y in out["years"]))

    def test_zero_low_does_not_divide_by_zero(self):
        with patched(ohlc_frame([("2025-05-01", 0.0, 20.0, 15.0)])):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y = next(y for y in out["years"] if y["year"] == 2025)
        self.assertIsNone(y["range_pct"])

    def test_average_sits_inside_the_high_low_range(self):
        """A sanity invariant: if the average ever fell outside the range, the columns would be
        computed off different data."""
        rows = [("2025-03-03", 95.0, 140.0, 128.0),
                ("2025-06-02", 80.0, 130.0, 120.0),
                ("2025-09-01", 110.0, 125.0, 118.0)]
        with patched(ohlc_frame(rows)):
            out = ys.compute_yearly_for_ticker(make_db(), "AAPL", TODAY)
        y = next(y for y in out["years"] if y["year"] == 2025)
        self.assertGreaterEqual(y["avg_price"], y["low"])
        self.assertLessEqual(y["avg_price"], y["high"])


if __name__ == "__main__":
    unittest.main()
