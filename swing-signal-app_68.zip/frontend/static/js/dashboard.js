/* Your average price is typed in, stored server-side, and never computed. A blank box means
   "not entered" — it is NOT zero, because a zero cost basis would render an infinite gain. */
let myPositions = {};
let overviewByTicker = {};

/* These helpers return CELL CONTENT ONLY. The <td> stays in the row template so that the
   headers-match-cells test keeps working — it is what caught RSI appearing under "Sector". */
function avgPriceInputHtml(ticker) {
  const v = myPositions[ticker];
  return `<input type="number" step="0.01" min="0" class="avg-price-input" data-ticker="${ticker}"
           value="${v === null || v === undefined ? "" : v}" placeholder="—"
           onclick="event.stopPropagation()"
           style="width:88px;text-align:right;background:transparent;color:inherit;
                  border:1px solid rgba(255,255,255,0.18);border-radius:4px;padding:3px 6px;">`;
}

function gainHtml(ticker, price) {
  const avg = myPositions[ticker];
  if (avg === null || avg === undefined || !(avg > 0)) {
    return `<span class="text-dim" title="Enter your average price to see this">—</span>`;
  }
  if (price === null || price === undefined || !(price > 0)) {
    return `<span class="text-dim" title="No current price stored">—</span>`;
  }
  const g = price / avg - 1;
  return `<span class="${pctClass(g)}">${fmtPct(g, 1)}</span>`;
}

function healthHtml(ticker) {
  const o = overviewByTicker[ticker] || {};
  const v = o.health_verdict;
  if (!v || v === "MISSING DATA") {
    return `<span class="text-dim" title="No stored fundamentals for this company yet">MISSING DATA</span>`;
  }
  const colour = { STRONG: "#2e7d32", SOLID: "#2e7d32", ADEQUATE: "#b26a00", WEAK: "#c62828" }[v] || "";
  const score = (o.health_score === null || o.health_score === undefined)
    ? "" : ` <span class="text-dim mono" style="font-size:11px;">${fmtNum(o.health_score, 0)}</span>`;
  return `<span style="${colour ? "color:" + colour + ";font-weight:600" : ""}">${v}</span>${score}`;
}

function newsHtml(ticker) {
  const o = overviewByTicker[ticker] || {};
  if (!o.news_count) return `<span class="text-dim">—</span>`;
  const title = (o.news_latest || "").replace(/"/g, "&quot;");
  return `<span title="${title}">${o.news_count} recent</span>`;
}

async function saveAvgPrice(ticker, raw) {
  const body = { avg_price: raw === "" ? null : raw };
  const res = await fetch(`/api/positions/${encodeURIComponent(ticker)}`, {
    method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  const out = await res.json();
  if (!res.ok) { alert(out.error || "Could not save"); return; }
  myPositions[ticker] = out.avg_price;
  if (lastSnapshotResults) renderStocksTable(lastSnapshotResults, indicatorsByTicker, signalsByTicker);
}

document.addEventListener("change", (e) => {
  if (e.target && e.target.classList && e.target.classList.contains("avg-price-input")) {
    saveAvgPrice(e.target.dataset.ticker, e.target.value);
  }
});

function renderStocksTable(results, indicatorsByTicker, signalsByTicker) {
  const tbody = document.getElementById("stocks-tbody");
  if (!tbody) return;
  if (!results || results.length === 0) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="10">No data.</td></tr>`;
    return;
  }
  indicatorsByTicker = indicatorsByTicker || {};
  signalsByTicker = signalsByTicker || {};
  tbody.innerHTML = results.map((r) => {
    const price = fmtPrice(r.last_price !== undefined ? r.last_price : r.last_known_price);
    const change = r.change !== undefined ? fmtChange(r.change, r.change_pct) : "—";
    const statusStr = r.data_status || "UNAVAILABLE";
    const ind = indicatorsByTicker[r.ticker] || {};
    const sig = signalsByTicker[r.ticker] || {};

    const rsi = ind.rsi14 !== undefined ? fmtNum(ind.rsi14, 1) : "—";
    // The label alone cannot tell a 50-day wobble from the 200-day rolling over, and only one of
    // those is worth acting on. So the two clocks are shown under it.
    const trendLabel = ind.trend_label || null;
    const td = ind.trend_detail || null;
    const statusDot = (s) => s === "INTACT" ? "num-pos" : s === "BROKEN" ? "num-neg"
                           : s === "UNCONFIRMED" ? "text-dim" : "";
    const trendHtml = trendLabel
      ? `<span class="${trendClass(trendLabel)}">${trendLabel}</span>` +
        (td ? `<div class="yc-sub" style="font-size:10.5px;">
                 <span class="${statusDot(td.long_term.status)}">LT ${td.long_term.status}</span>
                 &middot;
                 <span class="${statusDot(td.short_term.status)}">ST ${td.short_term.status}</span>
               </div>` : "")
      : `<span class="text-dim">—</span>`;

    // 50 DAYS, NOT 20. The 20-day reading flips Strong/Weak/Strong several times a year on noise
    // alone; for monthly investing the 50-day is the one that describes something. Both are
    // computed — this is a choice about which to put in front of you, not a change of maths.
    const rs = ind.relative_strength || {};
    const rsExcess = rs.rs_spy_50d;
    const rsLabel = rs.labels ? rs.labels[50] : null;
    const relStrengthHtml = rsExcess !== undefined && rsExcess !== null
      ? `<span class="${pctClass(rsExcess)}">${fmtPct(rsExcess, 1)}</span>${rsLabel ? ` <span class="${rsLabelClass(rsLabel)}" style="font-size:11px;">(${rsLabel})</span>` : ""}`
      : `<span class="text-dim">—</span>`;

    const signalHtml = sig.signal_label
      ? `${signalPillHtml(sig.signal_label)} <span class="text-dim mono" style="font-size:11px;">${sig.score_total !== null && sig.score_total !== undefined ? fmtNum(sig.score_total, 0) + "/" + (sig.score_max_currently_available || 90) : ""}</span>`
      : `<span class="text-dim">—</span>`;

    return `
      <tr onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'">
        <td><span class="ticker-badge">${r.ticker}</span></td>
        <td class="name-cell">${r.name || ""} <div class="company-name">${r.industry || ""}</div></td>
        <td class="text-right">${price}</td>
        <td class="text-right">${change}</td>
        <td class="text-right">${avgPriceInputHtml(r.ticker)}</td>
        <td class="text-right">${gainHtml(r.ticker, r.price)}</td>
        <td>${trendHtml}</td>
        <td>${healthHtml(r.ticker)}</td>
        <td>${newsHtml(r.ticker)}</td>
        <td>${r.sector || "—"}</td>
        <td>${statusPillHtml(statusStr)}</td>
      </tr>
    `;
  }).join("");
}

function updateMarketStrip(status) {
  const sessionEl = document.getElementById("mkt-session");
  if (!sessionEl) return; // not on dashboard page
  const subEl = document.getElementById("mkt-session-sub");
  const statusEl = document.getElementById("mkt-data-status");
  const nextOpenEl = document.getElementById("mkt-next-open");
  const nextCloseEl = document.getElementById("mkt-next-close");

  if (status.is_open === true) {
    sessionEl.textContent = "OPEN";
    sessionEl.style.color = "var(--green)";
  } else if (status.session) {
    sessionEl.textContent = status.session.replace("_", " ");
    sessionEl.style.color = "var(--amber)";
  } else {
    sessionEl.textContent = "UNKNOWN";
    sessionEl.style.color = "var(--text-1)";
  }
  subEl.textContent = status.timestamp ? `as of ${fmtTime(status.timestamp)}` : (status.error || "");
  statusEl.innerHTML = statusPillHtml(status.data_status);
  nextOpenEl.textContent = status.next_open ? fmtTime(status.next_open) : "—";
  nextCloseEl.textContent = status.next_close ? fmtTime(status.next_close) : "—";
}

function updateRegimeStrip(regime) {
  const strip = document.getElementById("sector-strip");
  if (!strip) return;                       // not on the dashboard page
  const summary = document.getElementById("regime-summary");
  const errEl = document.getElementById("regime-error");

  if (!regime || regime.regime === "UNAVAILABLE") {
    strip.innerHTML = `<div class="regime-tile"><div class="label">Sectors</div>
      <div class="value text-dim">UNAVAILABLE</div></div>`;
    if (summary) summary.textContent = "";
    if (errEl) errEl.textContent = (regime && regime.error) ? regime.error : "";
    return;
  }
  if (errEl) errEl.textContent = "";

  // One tile per sector the tracked universe actually contains, ordered by how many companies
  // sit in it. The list comes from the server, derived from the universe — so adding or removing
  // stocks changes what is shown here automatically rather than leaving a stale sector on screen.
  const sectors = regime.sector_view || [];
  strip.innerHTML = sectors.length
    ? sectors.map((s) => `
        <div class="regime-tile" title="${s.sector}: ${s.stocks} tracked ${s.stocks === 1 ? "company" : "companies"}, proxied by ${s.etf}">
          <div class="label">${s.sector}</div>
          <div class="value ${trendClass(s.trend_label)}" style="font-size:14px;">${s.trend_label || "&mdash;"}</div>
          <div class="sub">${s.chg_pct !== null && s.chg_pct !== undefined
              ? `<span class="${pctClass(s.chg_pct)}">${fmtPct(s.chg_pct, 1)}</span> 10d &middot; ` : ""}${s.stocks} stocks &middot; ${s.etf}</div>
        </div>`).join("")
    : `<div class="regime-tile"><div class="label">Sectors</div><div class="value text-dim">&mdash;</div></div>`;

  // The overall regime still feeds 5 points of every stock's score, so it stays visible — as a
  // line of text rather than a tile, since it is context for the sectors above rather than the
  // headline. Hiding it entirely would make those 5 points unexplainable.
  if (summary) {
    const vix = regime.vix_proxy_roc_10d;
    summary.innerHTML =
      `Overall market regime: <strong class="${regimeClass(regime.regime)}">${regime.regime}</strong>` +
      (regime.regime_score !== null && regime.regime_score !== undefined
        ? ` (score ${regime.regime_score > 0 ? "+" : ""}${regime.regime_score})` : "") +
      ` &mdash; SPY ${regime.spy_trend_label || "?"}, QQQ ${regime.qqq_trend_label || "?"}` +
      (vix !== null && vix !== undefined
        ? `, volatility proxy ${fmtPct(vix, 1)} over 10 days` : "") +
      `. This contributes 5 of the 100 points in every stock's signal score.`;
  }
}

// Cached across the fast/slow split so the table can re-render on every price tick without
// re-requesting the expensive analytics.
let indicatorsByTicker = {};
let signalsByTicker = {};
let lastSnapshotResults = null;

/**
 * Fast poll — prices only. Cheap, and the only thing that genuinely changes minute to minute.
 */
async function refreshPrices() {
  try {
    const marketStatus = await apiGet("/api/market/status");
    updateMarketStrip(marketStatus);
  } catch (e) {
    // topbar.js already surfaces this; dashboard tiles just stay at last-known state
  }

  try {
    const snap = await apiGet("/api/stocks/snapshots");
    lastSnapshotResults = snap.results;
    // Your typed-in average prices. Fetched with the prices so the boxes are never blank on load
    // when a value is stored.
    try {
      myPositions = (await apiGet("/api/positions")).positions || {};
    } catch (e) { /* leave boxes empty rather than guessing a cost basis */ }
    renderStocksTable(snap.results, indicatorsByTicker, signalsByTicker);
    const refreshedEl = document.getElementById("last-refreshed");
    if (refreshedEl) refreshedEl.textContent = "last refreshed " + new Date().toLocaleTimeString();
    if (snap.feed_error) console.warn("Alpaca feed error:", snap.feed_error);
  } catch (e) {
    const tbody = document.getElementById("stocks-tbody");
    if (tbody && !tbody.querySelector("tr:not(.loading-row)")) {
      tbody.innerHTML = `<tr class="loading-row"><td colspan="11">Failed to load data: ${e.message}</td></tr>`;
    }
  }
}

/**
 * Slow poll — the expensive analytics.
 *
 * Regime, indicators and signals each recompute across all 50 stocks server-side. Requesting
 * them every 15 seconds alongside prices put the backend under constant heavy load for data
 * that barely moves within a day: a stock's 200-day trend does not change between ticks. At 60
 * seconds the numbers are just as current in practice and the server does a quarter of the work.
 */
async function refreshAnalytics() {
  // Health (frozen C1, fundamentals only) and the existing news feed. Grouped with the slow poll
  // because both are expensive and neither changes minute to minute.
  try {
    const ov = await apiGet("/api/overview");
    overviewByTicker = {};
    (ov.results || []).forEach((r) => { overviewByTicker[r.ticker] = r; });
    if (lastSnapshotResults) {
      renderStocksTable(lastSnapshotResults, indicatorsByTicker, signalsByTicker);
    }
  } catch (e) {
    // health and news columns stay as MISSING DATA rather than showing a stale or invented value
  }

  try {
    updateRegimeStrip(await apiGet("/api/market/regime"));
  } catch (e) {
    updateRegimeStrip(null);
  }

  try {
    const ind = await apiGet("/api/stocks/indicators");
    const next = {};
    (ind.results || []).forEach((r) => { next[r.ticker] = r; });
    indicatorsByTicker = next;
  } catch (e) {
    console.warn("Failed to load indicators:", e.message);
  }

  try {
    const sigs = await apiGet("/api/signals");
    const next = {};
    (sigs.results || []).forEach((r) => { next[r.ticker] = r; });
    signalsByTicker = next;
  } catch (e) {
    console.warn("Failed to load signals:", e.message);
  }

  // The two polls run on different clocks, so redraw immediately once the analytics land —
  // otherwise the RSI/Trend/Signal columns would sit blank until the next price tick.
  if (lastSnapshotResults) {
    renderStocksTable(lastSnapshotResults, indicatorsByTicker, signalsByTicker);
  }
}

// startPolling guards against overlap: a slow backend now means "updates less often" rather
// than a pile-up of stacked requests the server can never drain.
startPolling(refreshPrices, 15000);
startPolling(refreshAnalytics, 60000);
