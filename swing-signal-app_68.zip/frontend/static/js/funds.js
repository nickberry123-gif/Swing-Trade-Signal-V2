/* FUNDS ON THE DASHBOARD — held (GBP, month-end snapshot) and US trackers (USD, live).
   The two groups share a table but never a basis: currency and price basis are on every row, so a
   snapshot can never be mistaken for a live quote. */
(function () {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const pct = (v, dp) => (v == null || Number.isNaN(v)) ? null : (v * 100).toFixed(dp == null ? 1 : dp) + "%";
  const num = (v) => (v == null || Number.isNaN(v)) ? null
    : Number(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const cell = (t) => t == null ? '<td class="text-dim">—</td>' : `<td>${esc(t)}</td>`;
  const rcell = (t) => t == null ? '<td class="text-right text-dim">—</td>'
    : `<td class="text-right">${esc(t)}</td>`;
  function signed(v) {
    if (v == null) return '<td class="text-right text-dim">—</td>';
    const c = v > 0.0001 ? "#2e7d32" : (v < -0.0001 ? "#c62828" : "");
    return `<td class="text-right" style="${c ? "color:" + c + ";font-weight:600" : ""}">${pct(v)}</td>`;
  }
  function avgInput(t, v) {
    return `<td class="text-right"><input type="number" step="0.01" min="0" class="fund-avg"
      data-ticker="${t}" value="${v == null ? "" : v}" placeholder="—" onclick="event.stopPropagation()"
      style="width:88px;text-align:right;background:transparent;color:inherit;
             border:1px solid rgba(255,255,255,0.18);border-radius:4px;padding:3px 6px;"></td>`;
  }
  function row(r) {
    const badge = r.group === "HELD"
      ? '<span style="color:#1565c0;font-weight:600">HELD</span>'
      : `<span style="color:#6a1b9a;font-weight:600">TRACKS ${esc(r.tracks || "")}</span>`;
    return `<tr>
      <td><span class="ticker-badge">${esc(r.ticker)}</span></td>
      <td class="name-cell">${esc(r.name)}</td>
      <td>${badge}</td>
      <td>${esc(r.currency)}</td>
      ${rcell(num(r.price))}
      ${signed(r.change_pct)}
      ${avgInput(r.ticker, r.avg_price)}
      ${signed(r.gain_pct)}
      ${cell(r.trend)}
      ${signed(r.drawdown_from_high)}
      <td class="text-dim" style="max-width:280px">${esc(r.price_basis)}</td>
    </tr>`;
  }
  async function load() {
    try {
      const b = await (await fetch("/api/funds")).json();
      $("funds-tbody").innerHTML = [...(b.held || []), ...(b.trackers || [])].map(row).join("");
      if (b.quote_error) {
        $("funds-message").innerHTML =
          `<div class="card card-pad">Live quotes unavailable: ${esc(b.quote_error)}</div>`;
      }
    } catch (e) {
      $("funds-tbody").innerHTML =
        `<tr><td colspan="11">Could not load funds: ${esc(e.message)}</td></tr>`;
    }
  }
  document.addEventListener("change", async (e) => {
    if (!e.target.classList || !e.target.classList.contains("fund-avg")) return;
    const res = await fetch(`/api/positions/${encodeURIComponent(e.target.dataset.ticker)}`, {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ avg_price: e.target.value === "" ? null : e.target.value }),
    });
    if (!res.ok) { alert((await res.json()).error || "Could not save"); return; }
    load();
  });
  async function fetchFundamentals() {
    const b = $("fund-fetch");
    b.disabled = true; b.textContent = "Fetching from SEC…";
    try {
      const r = await (await fetch("/api/overview/fundamentals/refresh", { method: "POST" })).json();
      /* Every failure reason is shown. A bare "0 of 7" once hid seven identical 401s and cost a
         long diagnosis that one visible message would have ended. */
      const failed = (r.results || []).filter((x) => x.status !== "OK");
      $("funds-message").innerHTML = `<div class="card card-pad">
        Fetched ${r.ok} of ${r.requested} from ${esc(r.source)}.
        ${failed.length ? "<br><strong>Failures:</strong><br>" + failed.map((x) =>
          `${esc(x.ticker)}: ${esc(x.error || x.status)}`).join("<br>") : ""}
        <br><span class="text-dim">${esc(r.note)}</span></div>`;
      if (typeof refreshAnalytics === "function") refreshAnalytics();
    } catch (e) {
      $("funds-message").innerHTML = `<div class="card card-pad">Fetch failed: ${esc(e.message)}</div>`;
    } finally { b.disabled = false; b.textContent = "Fetch Fundamentals (P/E & Health)"; }
  }
  document.addEventListener("DOMContentLoaded", () => {
    $("funds-reload").addEventListener("click", load);
    $("fund-fetch").addEventListener("click", fetchFundamentals);
    load();
  });
})();
