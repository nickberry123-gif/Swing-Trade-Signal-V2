/* MAG 6 — the six Magnificent 7 stocks minus Tesla as a single combined series.
   Equal weight, rebalanced monthly: each month's return is the plain average of its constituents.
   Not tradeable, and labelled so on the page rather than only in a tooltip. */
(function () {
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const pct = (v) => v == null ? null : (v * 100).toFixed(1) + "%";
  function signed(v) {
    if (v == null) return '<td class="text-right text-dim">—</td>';
    const c = v > 0.0001 ? "#2e7d32" : (v < -0.0001 ? "#c62828" : "");
    return `<td class="text-right" style="${c ? "color:" + c + ";font-weight:600" : ""}">${pct(v)}</td>`;
  }
  async function load() {
    const head = document.getElementById("mag6-head");
    const body = document.getElementById("mag6-tbody");
    if (!head || !body) return;                       // not on a page that shows it
    try {
      const r = await (await fetch("/api/monthly/MAG6")).json();
      const years = Object.keys(r.annual || {}).sort();
      head.innerHTML = "<th>Index</th><th>Constituents</th>"
        + years.map((y) => `<th class="text-right">${esc(y)}${y === "2026" ? " YTD" : ""}</th>`).join("")
        + '<th class="text-right">CAGR</th><th class="text-right">Buying Monthly</th>'
        + '<th class="text-right">Drawdown vs High</th><th>Trend</th>';
      body.innerHTML = `<tr>
        <td><span class="ticker-badge">MAG6</span></td>
        <td class="text-dim">${esc((r.constituents_with_data || []).join(", "))}</td>
        ${years.map((y) => signed(r.annual[y])).join("")}
        ${signed(r.cagr)}${signed(r.dca_annualised)}${signed(r.drawdown_from_high)}
        <td>${esc(r.trend || "—")}</td></tr>`;
      const missing = r.missing_constituents || [];
      document.getElementById("mag6-note").textContent = missing.length
        ? `INCOMPLETE — no price history for ${missing.join(", ")}. `
          + `Built from ${(r.constituents_with_data || []).length} of 6.`
        : `Built from all six constituents · ${r.months} months from ${r.first_date} · `
          + `index starts at 100, now ${Number(r.current_price).toFixed(1)}.`;
    } catch (e) {
      body.innerHTML = `<tr><td colspan="10">Could not load MAG 6: ${esc(e.message)}</td></tr>`;
    }
  }
  document.addEventListener("DOMContentLoaded", load);
})();
