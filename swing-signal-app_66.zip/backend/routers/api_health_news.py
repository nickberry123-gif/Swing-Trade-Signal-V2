"""HEALTH AND NEWS FOR THE DASHBOARD — both surfaced as they are, neither reinvented.

HEALTH is the frozen C1 Company Health score, computed by the existing validation pipeline. It is
fundamentals only: no price, no P/E, no technicals. Nothing here changes it — this endpoint reads
it so the dashboard can show it beside the price.

NEWS is the existing keyword-classified feed. It is deliberately reported as a COUNT and a most
recent headline, not as a judgement. A keyword classifier cannot tell you whether an investment
case broke; it can tell you something happened worth reading, and that is what is shown.
"""
from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services.data_validation_service import validate_ticker
from services.news_service import get_news_for_ticker
from services.signals_service import TICKERS

bp = Blueprint("api_health_news", __name__, url_prefix="/api/overview")

NEWS_LIMIT = 5


@bp.get("")
def overview():
    """One row per tracked company: health verdict, coverage, and recent news."""
    db = get_db()
    only = (request.args.get("tickers") or "").upper()
    wanted = ([t for t in sorted(TICKERS) if t in {x.strip() for x in only.split(",")}]
              if only else sorted(TICKERS))
    out = []
    for t in wanted:
        row = {"ticker": t}
        try:
            v = validate_ticker(db, t)
            row["health_score"] = v.get("company_health_score")
            row["health_verdict"] = v.get("company_health_verdict") or "MISSING DATA"
            row["health_coverage_pct"] = v.get("company_health_coverage_pct")
        except Exception as e:                      # a broken row must not blank the whole table
            row["health_score"] = None
            row["health_verdict"] = "MISSING DATA"
            row["health_error"] = str(e)
        items = get_news_for_ticker(db, t, limit=NEWS_LIMIT) or []
        row["news_count"] = len(items)
        row["news_latest"] = (items[0].get("headline") or items[0].get("title")) if items else None
        row["news_latest_at"] = items[0].get("published_at") if items else None
        out.append(row)
    return jsonify({
        "tickers": len(out),
        "news_note": ("News is counted and linked, not interpreted. The classifier is keyword-based "
                      "and cannot tell you whether an investment case has changed."),
        "alpaca_configured": Config.has_alpaca_credentials(),
        "results": out,
    })
