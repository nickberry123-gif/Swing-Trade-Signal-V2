(function () {
  const $ = (id) => document.getElementById(id);
  function render(data) {
    const rows = (data.results || []).slice();
    const years = data.years || [];
    const order = { 'SYNTHETIC INDEX': 0, STOCK: 1, ETF: 2 };
    rows.sort((a, b) => (order[a.type] - order[b.type]) || a.ticker.localeCompare(b.ticker));
    $('y-head').innerHTML = '<th>Ticker</th><th>Name</th><th>Type</th><th>Ccy</th>'
      + years.map((y) => `<th>${M.esc(y)}${y === '2026' ? ' YTD' : ''}</th>`).join('')
      + '<th>Best</th><th>Worst</th><th>Average</th>';
    $('y-tbody').innerHTML = rows.map((r) => {
      const vals = years.map((y) => (r.annual || {})[y]).filter((v) => v != null);
      return `<tr>
        <td><strong>${M.esc(r.ticker)}</strong></td>
        <td>${M.esc(r.name)}</td>
        ${M.typeBadge(r.type)}
        <td>${M.esc(r.currency)}</td>
        ${years.map((y) => M.signed((r.annual || {})[y])).join('')}
        ${M.signed(vals.length ? Math.max(...vals) : null)}
        ${M.signed(vals.length ? Math.min(...vals) : null)}
        ${M.signed(vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null)}
      </tr>`;
    }).join('');
    $('l-tbody').innerHTML = rows.map((r) => `<tr>
        <td><strong>${M.esc(r.ticker)}</strong></td>
        ${M.typeBadge(r.type)}
        <td>${M.esc(r.currency)}</td>
        ${M.cell(r.first_date)}${M.cell(r.last_date)}
        ${M.cell(r.years == null ? null : r.years.toFixed(1))}
        ${M.signed(r.cagr)}${M.signed(r.dca_total_return)}${M.signed(r.dca_annualised)}
        ${M.cell(M.num(r.high_5y))}${M.cell(M.num(r.low_5y))}${M.cell(M.num(r.high_all))}
        ${M.signed(r.drawdown_from_high)}
        <td class="text-dim" style="max-width:240px">${M.esc(r.data_status)}</td>
      </tr>`).join('');
  }
  document.addEventListener('DOMContentLoaded', () => {
    $('m-reload').addEventListener('click', () => M.load(render));
    M.load(render);
  });
})();
