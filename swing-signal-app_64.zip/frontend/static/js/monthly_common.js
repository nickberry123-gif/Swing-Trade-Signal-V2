/* Shared rendering for the monthly-analysis pages.
 * MISSING DATA is always rendered as the words, never as a blank cell or a dash that could be
 * read as zero. A missing return is not a flat year. */
window.M = (function () {
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const pct = (v, dp) => (v == null || Number.isNaN(v)) ? null : (v * 100).toFixed(dp == null ? 1 : dp) + '%';
  const num = (v, dp) => (v == null || Number.isNaN(v)) ? null
    : Number(v).toLocaleString(undefined, { minimumFractionDigits: dp == null ? 2 : dp,
                                            maximumFractionDigits: dp == null ? 2 : dp });
  function cell(text, colour) {
    if (text == null) return '<td class="text-dim">MISSING</td>';
    return `<td style="${colour ? 'color:' + colour + ';font-weight:600' : ''}">${esc(text)}</td>`;
  }
  const signed = (v, dp) => v == null ? cell(null)
    : cell(pct(v, dp), v > 0.0001 ? '#2e7d32' : (v < -0.0001 ? '#c62828' : ''));
  function typeBadge(t) {
    const c = { 'SYNTHETIC INDEX': '#6a1b9a', ETF: '#1565c0', STOCK: '' }[t] || '';
    return cell(t, c);
  }
  async function load(cb) {
    try {
      const res = await fetch('/api/monthly/universe');
      const body = await res.json();
      cb(body);
    } catch (e) {
      document.getElementById('m-message').innerHTML =
        `<div class="card card-pad">Could not load: ${esc(e.message)}</div>`;
    }
  }
  return { esc, pct, num, cell, signed, typeBadge, load };
})();
