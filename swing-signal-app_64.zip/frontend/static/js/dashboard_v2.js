(function () {
  const $ = (id) => document.getElementById(id);
  function render(data) {
    const rows = data.results || [];
    const withData = rows.filter((r) => r.months > 0);
    $('m-summary').innerHTML = `
      <div><strong>${withData.length}</strong> of <strong>${rows.length}</strong> securities have
        price history · as of ${M.esc(data.as_of)}</div>
      <div class="text-dim" style="margin-top:6px">${M.esc(data.note)}</div>`;
    const order = { 'SYNTHETIC INDEX': 0, STOCK: 1, ETF: 2 };
    rows.sort((a, b) => (order[a.type] - order[b.type]) || a.ticker.localeCompare(b.ticker));
    $('m-tbody').innerHTML = rows.map((r) => `<tr>
        <td><strong>${M.esc(r.ticker)}</strong></td>
        <td>${M.esc(r.name)}</td>
        ${M.typeBadge(r.type)}
        <td>${M.esc(r.currency)}</td>
        ${M.cell(M.num(r.current_price))}
        ${M.signed(r.cagr)}
        ${M.signed(r.dca_annualised)}
        ${M.cell(M.num(r.high_52w))}
        ${M.cell(M.num(r.low_52w))}
        ${M.cell(M.pct(r.range_position, 0))}
        ${M.signed(r.drawdown_from_high)}
        ${M.signed(r.vs_ma12)}
        ${M.cell(r.trend)}
        ${M.cell(r.months == null ? null : String(r.months))}
        <td class="text-dim" style="max-width:260px">${M.esc(r.data_status)}</td>
      </tr>`).join('');
  }
  async function refresh() {
    const b = $('m-refresh'); b.disabled = true; b.textContent = 'Fetching…';
    try {
      const res = await fetch('/api/monthly/refresh', { method: 'POST' });
      const body = await res.json();
      $('m-message').innerHTML = `<div class="card card-pad">Fetched ${body.ok} of ${body.requested}
        stocks. ${M.esc(body.note)}</div>`;
      M.load(render);
    } catch (e) {
      $('m-message').innerHTML = `<div class="card card-pad">Fetch failed: ${M.esc(e.message)}</div>`;
    } finally { b.disabled = false; b.textContent = 'Fetch Stock Price History'; }
  }
  document.addEventListener('DOMContentLoaded', () => {
    $('m-reload').addEventListener('click', () => M.load(render));
    $('m-refresh').addEventListener('click', refresh);
    M.load(render);
  });
})();
