"""
Value — storage and endpoint integration.

The unit tests prove the arithmetic. These prove the arithmetic is reached through real SQL and a
real request, which is where the last two production defects actually lived: a migration that only
ran on a fresh database, and a point-in-time cutoff applied by the caller rather than in the query.
"""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app as app_module
from db import get_db
from services import value_bars_service as vb
from services import value_service as vs

TICKER = "NVDA"


def _days(start, n):
    d = date.fromisoformat(start)
    for _ in range(n):
        yield d.isoformat()
        d += timedelta(days=1)


class ValueStorage(unittest.TestCase):

    def setUp(self):
        self.app = app_module.create_app()
        self.client = self.app.test_client()
        self.ctx = self.app.app_context()
        self.ctx.push()
        self.db = get_db()
        self.db.execute("DELETE FROM value_raw_bars WHERE ticker = ?", (TICKER,))
        self.db.commit()

    def tearDown(self):
        self.db.execute("DELETE FROM value_raw_bars WHERE ticker = ?", (TICKER,))
        self.db.commit()
        self.ctx.pop()

    def _seed(self, start="2020-07-27", n=1600, factor_before=None, split_on=None):
        rows = []
        for i, d in enumerate(_days(start, n)):
            adj = 100.0 + 0.01 * i
            raw = adj * (factor_before if (split_on and d < split_on) else 1.0)
            rows.append((TICKER, d, round(raw, 4), round(adj, 4), "2026-08-19"))
        self.db.executemany(
            """INSERT INTO value_raw_bars (ticker, ts, close_raw, close_adj, fetched_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(ticker, ts) DO UPDATE SET close_raw = excluded.close_raw""", rows)
        self.db.commit()

    # ---- the migration that only ran on a fresh database ----
    def test_the_table_exists_on_this_database(self):
        self.db.execute("SELECT ticker, ts, close_raw, close_adj FROM value_raw_bars LIMIT 1")

    def test_both_bases_are_stored_for_the_same_day(self):
        self._seed(n=5)
        row = self.db.execute(
            "SELECT close_raw, close_adj FROM value_raw_bars WHERE ticker = ? AND ts = ?",
            (TICKER, "2020-07-27")).fetchone()
        self.assertIsNotNone(row["close_raw"])
        self.assertIsNotNone(row["close_adj"])

    def test_a_second_write_updates_rather_than_duplicates(self):
        self._seed(n=10)
        self._seed(n=10)
        n = self.db.execute("SELECT COUNT(*) AS n FROM value_raw_bars WHERE ticker = ?",
                            (TICKER,)).fetchone()["n"]
        self.assertEqual(n, 10)

    # ---- the cutoff applied in SQL, not by the caller ----
    def test_the_as_of_cutoff_is_enforced_by_the_query(self):
        self._seed(n=1600)
        rows = vb.bars(self.db, TICKER, as_of="2021-01-01")
        self.assertTrue(rows)
        self.assertLessEqual(max(r["ts"] for r in rows), "2021-01-01")

    def test_bars_come_back_ascending(self):
        self._seed(n=50)
        rows = vb.bars(self.db, TICKER)
        self.assertEqual([r["ts"] for r in rows], sorted(r["ts"] for r in rows))

    def test_stored_summary_reports_the_observed_floor(self):
        self._seed(start="2020-07-27", n=30)
        self.assertEqual(vb.stored_summary(self.db, TICKER)["first"], "2020-07-27")


class ValueEndpoints(ValueStorage):

    def test_unknown_ticker_is_a_clean_404(self):
        self.assertEqual(self.client.get("/api/value/NOTATICKER").status_code, 404)

    def test_value_endpoint_returns_the_pillar_shape(self):
        self._seed(n=1600)
        body = self.client.get(f"/api/value/{TICKER}").get_json()
        for key in ("ticker", "value", "verdict", "metrics", "coverage", "history", "basis"):
            self.assertIn(key, body)
        self.assertEqual(body["ticker"], TICKER)

    def test_the_basis_wording_is_returned_and_does_not_overclaim(self):
        self._seed(n=1600)
        body = self.client.get(f"/api/value/{TICKER}").get_json()
        self.assertEqual(body["basis"],
                         "Relative to available valuation history since July 2020.")

    def test_a_verdict_is_always_one_of_the_four(self):
        self._seed(n=1600)
        body = self.client.get(f"/api/value/{TICKER}").get_json()
        self.assertIn(body["verdict"], ("CHEAP", "FAIR", "EXPENSIVE", vs.UNKNOWN))

    def test_no_stored_bars_gives_unknown_rather_than_an_error(self):
        body = self.client.get(f"/api/value/{TICKER}").get_json()
        self.assertEqual(body["verdict"], vs.UNKNOWN)
        self.assertIsNone(body["value"])

    def test_the_series_endpoint_exposes_detected_splits(self):
        self._seed(n=1600, factor_before=10.0, split_on="2024-06-10")
        body = self.client.get(f"/api/value/{TICKER}/series?limit=5").get_json()
        self.assertTrue(body["splits_detected"])
        self.assertEqual(body["splits_detected"][0]["date"], "2024-06-10")

    def test_the_series_endpoint_respects_as_of(self):
        self._seed(n=1600)
        body = self.client.get(f"/api/value/{TICKER}/series?as_of=2022-01-01").get_json()
        self.assertLessEqual(max(r["date"] for r in body["series"]), "2022-01-01")

    def test_the_universe_endpoint_covers_every_tracked_ticker(self):
        from routers.api_stocks import TICKERS
        body = self.client.get("/api/value/universe/all").get_json()
        self.assertEqual(body["tickers"], len(TICKERS))
        self.assertEqual(len(body["results"]), len(TICKERS))

    def test_the_universe_endpoint_reports_coverage_and_floor(self):
        body = self.client.get("/api/value/universe/all").get_json()
        for key in ("scored", "unknown", "verdicts", "metric_coverage",
                    "data_floor_observed", "substitutions", "split_withheld"):
            self.assertIn(key, body)
        self.assertEqual(body["data_floor_observed"], "2020-07-27")

    def test_scored_plus_unknown_equals_the_universe(self):
        body = self.client.get("/api/value/universe/all").get_json()
        self.assertEqual(body["scored"] + body["unknown"], body["tickers"])

    def test_the_page_renders(self):
        self.assertEqual(self.client.get("/value").status_code, 200)

    def test_value_is_in_the_menu(self):
        """Hidden from the menu by request, but the route must still work. Hidden means out of sight, not deleted."""
        self.assertNotIn(b'href="/value"', self.client.get("/").data)
        self.assertEqual(self.client.get("/value").status_code, 200)


class FrozenContract(unittest.TestCase):
    """Things that must not drift without a decision. Each has a stated reason."""

    def test_the_metric_set_is_the_approved_three(self):
        self.assertEqual(vs.METRICS, ("fcf_yield_pct", "ev_to_ebit", "pe_ratio"))

    def test_weights_are_equal_by_construction(self):
        """There is no weight table at all — the score is a plain mean.

        Study 2 found C1's weighted categories added close to nothing over an equally weighted
        average, and inventing weights before any validation exists is optimising a calculation
        that is not yet trusted. A weight table appearing here later would be that change made
        silently, so its absence is asserted rather than assumed.
        """
        self.assertFalse(any(n.upper().startswith("WEIGHT") or n.upper().endswith("WEIGHTS")
                             for n in dir(vs)))
        src = Path(vs.__file__).read_text()
        for assignment in ("WEIGHTS =", "WEIGHT =", "WEIGHTING ="):
            self.assertNotIn(assignment, src)

    def test_the_bands_are_frozen(self):
        self.assertEqual(vs.BANDS, ((75.0, "CHEAP"), (25.0, "FAIR"), (0.0, "EXPENSIVE")))

    def test_two_metrics_minimum(self):
        self.assertEqual(vs.MIN_METRICS_FOR_VALUE, 2)

    def test_three_years_minimum_history(self):
        self.assertEqual(vs.MIN_HISTORY_YEARS, 3.0)

    def test_value_imports_nothing_from_the_other_pillars(self):
        src = Path(vs.__file__).read_text()
        for forbidden in ("company_health", "quality_score", "signal_engine", "indicators",
                          "entry_quality", "health_backtest"):
            self.assertNotIn(forbidden, src, f"Value must not depend on {forbidden}")

    def test_no_dcf_or_forward_estimates_crept_in(self):
        src = Path(vs.__file__).read_text().lower()
        for forbidden in ("discounted", "intrinsic_value", "forward_pe", "analyst"):
            self.assertNotIn(forbidden, src)

    def test_company_health_is_untouched(self):
        from services import company_health as ch
        self.assertEqual(ch.COVERAGE_GATE_PCT, 75.0)
        self.assertEqual(ch.CAP_AT_N_RED_FLAGS, 2)

    def test_the_adjusted_basis_of_every_other_path_is_unchanged(self):
        from providers.alpaca_provider import BAR_ADJUSTMENT
        self.assertEqual(BAR_ADJUSTMENT, "all")

    def test_raw_is_used_for_valuation_and_adjusted_is_not(self):
        src = Path(vs.__file__).read_text()
        self.assertIn("close_raw", src)
        # close_adj appears only in the corporate-action detector, never in a multiple.
        detector_only = src.split("def metrics_for")[1].split("def build_series")[0]
        self.assertNotIn("close_adj", detector_only)


if __name__ == "__main__":
    unittest.main()
