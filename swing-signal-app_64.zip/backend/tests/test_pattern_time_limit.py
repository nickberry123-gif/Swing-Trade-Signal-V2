"""
Tests for the pattern strategy's time limit, and for the warmup-aware partial-year flag.

WHAT THE TIME LIMIT IS FOR
--------------------------
Leg 2 buys just above the 200MA and sells near the 52-week high. Its exit level sits ABOVE its
entry level by construction, so a leg-2 trade that closes on its own trigger is close to
guaranteed to be a winner. Before the time limit, a leg that never reached its trigger simply
never closed — and the ticker's state machine froze, so that stock produced no further trades for
the rest of the test. The sample therefore filled up with the stocks that kept completing the
cycle, and leg 2's win rate measured the shape of the rule rather than the quality of the idea.

The tests below check the mechanism AND that it actually bites: a rule that times nothing out
would pass a shape-only test while changing nothing.
"""
import re
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import annual_backtest_service as ab
from services import pattern_service as ps


def bars_from(closes, start=date(2020, 1, 1), highs=None, lows=None):
    ts, d = [], start
    while len(ts) < len(closes):
        if d.weekday() < 5 and (d.month, d.day) not in {(1, 1), (12, 25)}:
            ts.append(d.isoformat())
        d += timedelta(days=1)
    closes = np.asarray(closes, dtype="float64")
    return pd.DataFrame({
        "ts": ts, "open": closes, "close": closes,
        "high": closes * 1.001 if highs is None else np.asarray(highs, dtype="float64"),
        "low": closes * 0.999 if lows is None else np.asarray(lows, dtype="float64"),
        "volume": [1_000_000.0] * len(closes)})


def stalling_series(n=1400):
    """Falls to a 52-week low, recovers past the 200MA, then goes flat forever.

    Flat is the case that matters: the price never reaches the 52-week high, so leg 2 has no
    trigger and, without a time limit, never closes.
    """
    warm = np.linspace(100, 100, 300)                 # flat, builds the 200MA
    fall = np.linspace(100, 55, 260)                  # drives a 52-week low
    recover = np.linspace(55, 115, 120)               # back up through the 200MA
    remainder = n - (len(warm) + len(fall) + len(recover))
    flat = np.full(max(remainder, 1), 115.0)          # stalls here, well below the 52w high
    return np.concatenate([warm, fall, recover, flat])


class TimeLimitMechanics(unittest.TestCase):

    def setUp(self):
        self.df = bars_from(stalling_series())

    def test_without_a_limit_a_stalled_leg_never_closes_on_a_trigger(self):
        """The behaviour being fixed. If this stops holding, the fixture stopped stalling."""
        out = ps.simulate_ticker("AAA", self.df, {"max_holding_days": 0})
        reasons = [t["exit_reason"] for t in out["trades"]]
        self.assertIn("STILL_OPEN_AT_END", reasons,
                      "fixture no longer stalls — the tests below would prove nothing")
        self.assertEqual(out["events"]["leg1_timeouts"] + out["events"]["leg2_timeouts"], 0)

    def test_with_a_limit_the_stalled_leg_is_closed_on_time(self):
        out = ps.simulate_ticker("AAA", self.df, {"max_holding_days": 60})
        timed = [t for t in out["trades"] if t["exit_reason"] == "TIME_LIMIT"]
        self.assertTrue(timed, "the time limit never fired on a deliberately stalling series")
        self.assertTrue(all(t["timed_out"] for t in timed))

    def test_no_trade_is_held_longer_than_the_limit(self):
        limit = 60
        out = ps.simulate_ticker("AAA", self.df, {"max_holding_days": limit})
        for t in out["trades"]:
            if t["exit_reason"] == "STILL_OPEN_AT_END":
                # Only a trade opened within `limit` bars of the final bar can survive.
                self.assertLessEqual(t["holding_days"], limit)
            else:
                self.assertLessEqual(t["holding_days"], limit)

    def test_a_shorter_limit_closes_trades_sooner(self):
        long_hold = ps.simulate_ticker("AAA", self.df, {"max_holding_days": 120})
        short_hold = ps.simulate_ticker("AAA", self.df, {"max_holding_days": 20})
        longest_long = max(t["holding_days"] for t in long_hold["trades"])
        longest_short = max(t["holding_days"] for t in short_hold["trades"])
        self.assertLess(longest_short, longest_long)

    def test_the_ticker_keeps_trading_after_a_timeout(self):
        """The real damage was the frozen state machine, not the hidden loss."""
        frozen = ps.simulate_ticker("AAA", self.df, {"max_holding_days": 0})
        released = ps.simulate_ticker("AAA", self.df, {"max_holding_days": 60})
        self.assertGreater(len(released["trades"]), len(frozen["trades"]),
                           "timing out did not return the ticker to trading")

    def test_the_rules_own_trigger_wins_a_tie(self):
        """A trade that reaches its target ON the limit day is a target hit, not a timeout."""
        # Rises straight into the 200MA so leg 1 exits early and cleanly.
        closes = np.concatenate([np.linspace(100, 100, 300), np.linspace(100, 60, 260),
                                 np.linspace(60, 200, 400), np.full(440, 200.0)])
        out = ps.simulate_ticker("AAA", bars_from(closes), {"max_holding_days": 60})
        for t in out["trades"]:
            if t["exit_reason"] == "TIME_LIMIT":
                continue
            self.assertFalse(t["timed_out"])

    def test_a_time_limited_trade_can_lose_money(self):
        """The whole point: losses must now be recordable on leg 2."""
        # Breaks above the 200MA and then sags, without ever making a new 52-week low.
        closes = np.concatenate([np.full(300, 100.0), np.linspace(100, 55, 260),
                                 np.linspace(55, 120, 120), np.linspace(120, 96, 700)])
        out = ps.simulate_ticker("AAA", bars_from(closes), {"max_holding_days": 60})
        timed = [t for t in out["trades"] if t["exit_reason"] == "TIME_LIMIT"]
        self.assertTrue(timed)
        self.assertTrue(any(t["return_pct"] < 0 for t in timed),
                        "no timed-out trade recorded a loss on a deliberately sagging series")


class ResultShape(unittest.TestCase):

    def setUp(self):
        self.bars = {"AAA": bars_from(stalling_series()), "BBB": bars_from(stalling_series())}
        self.result = ps.run_pattern_test(self.bars, ["AAA", "BBB"], {"max_holding_days": 60})

    def test_versus_holding_comparisons_are_gone(self):
        for key in ("buy_and_hold_benchmark", "matched_entry_comparison"):
            self.assertNotIn(key, self.result)
        for row in self.result["by_ticker"].values():
            self.assertNotIn("matched", row)
            self.assertNotIn("per_trade_vs_hold", row)

    def test_exit_reasons_are_broken_out(self):
        self.assertIn("by_exit_reason", self.result)
        self.assertIn("Time limit", self.result["by_exit_reason"])

    def test_timeout_counts_are_reported(self):
        self.assertIn("leg1_timeouts", self.result["events"])
        self.assertIn("leg2_timeouts", self.result["events"])

    def test_a_warning_names_the_share_closed_on_time(self):
        self.assertTrue(any("time limit" in w for w in self.result["warnings"]),
                        self.result["warnings"])

    def test_the_rule_text_says_it_is_not_a_stop_loss(self):
        rule = " ".join(self.result["config"]["rule"])
        self.assertIn("not a stop-loss", rule)


class WarmupAwarePartialYears(unittest.TestCase):
    """2021 was reported as a complete year when signals could not fire until May."""

    def test_a_year_is_partial_when_indicators_were_still_warming_up(self):
        bounds = {2021: {"first_trading_day": "2021-01-04", "last_trading_day": "2021-12-31"},
                  2023: {"first_trading_day": "2023-01-03", "last_trading_day": "2023-12-29"}}
        partial = ab._partial_years(bounds, first_tradeable="2021-05-03")
        self.assertIn(2021, partial)
        self.assertNotIn(2023, partial)

    def test_without_the_warmup_date_the_old_answer_is_unchanged(self):
        """Proves the flag comes from warmup and not from the bar dates."""
        bounds = {2021: {"first_trading_day": "2021-01-04", "last_trading_day": "2021-12-31"}}
        self.assertNotIn(2021, ab._partial_years(bounds))

    def test_first_tradeable_day_skips_the_warmup_window(self):
        df = bars_from(np.full(600, 100.0), start=date(2020, 7, 27))
        first = ab._first_tradeable_day({"AAA": df})
        self.assertIsNotNone(first)
        # 210 bars after 2020-07-27 lands in 2021, not in 2020.
        self.assertGreater(first, "2021-01-01")
        self.assertEqual(first, str(df["ts"].iloc[210]))

    def test_a_ticker_too_short_to_warm_up_contributes_nothing(self):
        self.assertIsNone(ab._first_tradeable_day({"AAA": bars_from(np.full(50, 100.0))}))


if __name__ == "__main__":
    unittest.main()


class PageWiring(unittest.TestCase):
    """The control must reach the simulator. A field the API accepts and no page sends, or a page
    that sends a field the API drops, is a bug this project has already shipped once."""

    def setUp(self):
        import app as app_module
        self.client = app_module.create_app().test_client()
        self.frontend = Path(__file__).resolve().parent.parent.parent / "frontend"

    def test_the_service_still_honours_the_time_limit(self):
        """The PAGE moved on; the 52-week/200MA engine did not.

        That page now runs the two bullish setups, so its "days to close" field is gone. The
        state machine, its time limit and every test above are untouched in
        services/pattern_service.py — pointing the router back at run_pattern_test restores it
        whole. Deleting the mechanism because a page stopped calling it would throw away the
        measurement that justified adding it.
        """
        out = ps.simulate_ticker("AAA", self.df if hasattr(self, "df") else bars_from(
            stalling_series()), {"max_holding_days": 60})
        self.assertTrue(any(t["exit_reason"] == "TIME_LIMIT" for t in out["trades"]))

    def test_the_router_no_longer_points_at_the_old_engine(self):
        router = (Path(__file__).resolve().parent.parent / "routers" / "api_pattern.py").read_text()
        self.assertIn("run_bullish_setup_test", router)
        self.assertIn("services/pattern_service.py", router,
                      "the comment recording where the old engine went should stay")

    def test_the_router_reads_it(self):
        router = (Path(__file__).resolve().parent.parent / "routers" / "api_pattern.py").read_text()
        self.assertIn('payload.get("max_holding_days"', router)

    def test_every_element_the_script_writes_to_exists(self):
        html = (self.frontend / "templates" / "pattern_test.html").read_text()
        js = (self.frontend / "static" / "js" / "pattern_test.js").read_text()
        for element_id in re.findall(r'getElementById\("([^"]+)"\)', js):
            self.assertIn(f'id="{element_id}"', html,
                          f"{element_id} is written to by the script but absent from the page")

    def test_the_pattern_page_is_still_in_the_nav(self):
        """It is the only home of the second strategy, so it stays when the diagnostics go."""
        """Hidden from the menu by request, but the route must still work. Hidden means out of sight, not deleted."""
        self.assertNotIn(b'href="/pattern-test"', self.client.get("/").data)
        self.assertEqual(self.client.get("/pattern-test").status_code, 200)
