"""
Entry V1 — signal, backtest and frozen-contract tests.

Aimed at the ways a timing study fabricates an edge: a one-day look-ahead at execution, a
percentile that sees the future, a wait window that quietly shortens, and a placebo that was never
built so that drift could be mistaken for skill.
"""
import sys
import unittest
from datetime import date, timedelta
from math import sqrt
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from services import entry_service as es
from services import entry_validation as ev


def _bars(n=1200, start="2020-07-27", fn=None):
    out, d = [], date.fromisoformat(start)
    for i in range(n):
        while d.weekday() >= 5:
            d += timedelta(days=1)
        out.append({"ts": d.isoformat(), "close_adj": (fn(i) if fn else 100.0 + 0.05 * i)})
        d += timedelta(days=1)
    return out


class TestStretch:
    def test_price_on_its_own_average_is_zero_stretch(self):
        closes = [100.0] * 300
        assert es.stretch_at(closes, 299) is None      # zero volatility -> no opinion, not zero

    def test_below_the_average_is_negative(self):
        closes = [100.0 + (i % 7) for i in range(300)]
        closes[299] = 80.0
        assert es.stretch_at(closes, 299) < 0

    def test_above_the_average_is_positive(self):
        closes = [100.0 + (i % 7) for i in range(300)]
        closes[299] = 130.0
        assert es.stretch_at(closes, 299) > 0

    def test_volatility_scaling_makes_two_stocks_comparable(self):
        """The same percentage gap on a violent stock must read as a smaller stretch than on a
        quiet one. Without this the signal would simply rank stocks by volatility."""
        quiet = [100.0 + (i % 3) * 0.2 for i in range(300)]
        wild = [100.0 + (i % 3) * 6.0 for i in range(300)]
        quiet[299] = quiet[298] * 0.92
        wild[299] = wild[298] * 0.92
        assert abs(es.stretch_at(quiet, 299)) > abs(es.stretch_at(wild, 299))

    def test_insufficient_history_is_none(self):
        assert es.stretch_at([100.0] * 10, 9) is None


class TestTrend:
    def test_rising_series_is_an_uptrend(self):
        closes = [100.0 + 0.5 * i for i in range(300)]
        assert es.trend_at(closes, 299) == es.UPTREND

    def test_falling_series_is_not_an_uptrend(self):
        closes = [500.0 - 0.5 * i for i in range(300)]
        assert es.trend_at(closes, 299) == es.NOT_UPTREND

    def test_price_above_a_rolling_over_average_is_not_an_uptrend(self):
        """Both conditions are required. A bounce inside a decline must not read as an uptrend."""
        closes = [100.0 + 0.5 * i for i in range(250)] + [225.0 - 1.5 * i for i in range(60)]
        closes.append(closes[-1] * 1.30)
        assert es.trend_at(closes, len(closes) - 1) == es.NOT_UPTREND

    def test_insufficient_history_is_none(self):
        assert es.trend_at([100.0] * 50, 49) is None


class TestVerdict:
    @pytest.mark.parametrize("pct,expected", [
        (100.0, es.FAVOURABLE), (66.7, es.FAVOURABLE), (66.0, es.NEUTRAL),
        (50.0, es.NEUTRAL), (33.4, es.NEUTRAL), (33.0, es.UNFAVOURABLE), (0.0, es.UNFAVOURABLE)])
    def test_tercile_boundaries(self, pct, expected):
        assert es.verdict_from(pct, es.UPTREND) == expected

    def test_a_falling_stock_is_never_favourable(self):
        """A stated prior, fixed before any result: a large decline in a falling stock is not a
        discount, and this pillar will not call it one."""
        for pct in (0.0, 50.0, 99.9, 100.0):
            assert es.verdict_from(pct, es.NOT_UPTREND) == es.NEUTRAL

    def test_missing_inputs_are_unknown_not_neutral(self):
        assert es.verdict_from(None, es.UPTREND) == es.UNKNOWN
        assert es.verdict_from(50.0, None) == es.UNKNOWN

    def test_the_cuts_are_the_approved_terciles(self):
        assert es.FAVOURABLE_PCT == pytest.approx(66.667, abs=0.01)
        assert es.UNFAVOURABLE_PCT == pytest.approx(33.333, abs=0.01)


class TestNoLookAhead:
    def test_the_percentile_uses_only_earlier_observations(self):
        """The design's own trap. Ranking a 2021 stretch inside the full six-year distribution
        would let 2025 inform a 2021 decision."""
        rows = es.series(_bars(900))
        truncated = es.series(_bars(900)[:600])
        assert rows[599]["stretch_percentile"] == truncated[599]["stretch_percentile"]

    def test_appending_future_bars_cannot_change_an_earlier_verdict(self):
        short = es.series(_bars(700))
        long = es.series(_bars(1100))
        assert [r["verdict"] for r in short] == [r["verdict"] for r in long[:700]]

    def test_no_opinion_before_the_minimum_history(self):
        rows = es.series(_bars(400))
        early = [r for r in rows if r["stretch_percentile"] is not None]
        assert all(r["date"] >= rows[es.MIN_PERCENTILE_HISTORY]["date"] for r in early)

    def test_evaluate_respects_as_of(self):
        bars = _bars(900)
        cut = bars[600]["ts"]
        assert es.evaluate("T", bars, as_of=cut)["as_of"] == cut

    def test_purchase_happens_the_day_after_the_decision(self):
        """A one-day look-ahead at execution is the easiest way to fabricate a timing edge."""
        src = Path(ev.__file__).read_text()
        assert "baseline_i = m + 1" in src
        assert "entry_i, waited = k + 1, k - m" in src


class TestBacktestMechanics:
    def test_month_starts_are_one_per_calendar_month(self):
        rows = es.series(_bars(600))
        starts = ev.month_start_indices(rows)
        months = [rows[i]["date"][:7] for i in starts]
        assert len(months) == len(set(months))

    def test_a_month_without_a_full_wait_window_is_excluded(self):
        """Measuring one month over a shorter window would produce a number that is not
        comparable with the others — worse than producing none."""
        bars = _bars(700)
        obs = ev.observations_for_ticker("T", bars)
        rows = es.series(bars)
        for o in obs:
            i = next(k for k, r in enumerate(rows) if r["date"] == o["decision_date"])
            assert i + ev.WAIT_DAYS + 1 < len(rows)

    def test_entry_never_waits_when_the_signal_is_not_unfavourable(self):
        obs = ev.observations_for_ticker("T", _bars(1200))
        for o in obs:
            if o["verdict"] != es.UNFAVOURABLE:
                assert o["waited_days"] == 0
                assert o["entry_price"] == o["baseline_price"]

    def test_entry_never_waits_longer_than_the_frozen_window(self):
        for o in ev.observations_for_ticker("T", _bars(1200)):
            assert 0 <= o["waited_days"] <= ev.WAIT_DAYS

    def test_untriggered_months_contribute_exactly_zero_difference(self):
        for o in ev.observations_for_ticker("T", _bars(1200)):
            if o["state"] == ev.IMMEDIATE:
                assert o["entry_vs_baseline_pct"] == 0

    def test_the_wait_window_is_the_frozen_ten_days(self):
        assert ev.WAIT_DAYS == 10

    def test_the_pass_bar_is_the_friction_bar(self):
        assert ev.PASS_THRESHOLD_PCT == 0.25


class TestPlaceboArm:
    def test_the_always_wait_arm_exists(self):
        """Without it, drift in a rising market is indistinguishable from timing skill."""
        obs = ev.observations_for_ticker("T", _bars(1200))
        assert obs and all("always_wait_vs_window_pct" in o for o in obs)

    def test_in_a_rising_market_waiting_costs_money(self):
        """A sanity check on the placebo itself: if it did not show a cost in a monotonically
        rising series, the arm would not be measuring what it claims to."""
        obs = ev.observations_for_ticker("T", _bars(1200, fn=lambda i: 100.0 + 0.05 * i))
        assert ev._mean([o["always_wait_vs_window_pct"] for o in obs]) < 0

    def test_beating_the_placebo_is_required_to_pass(self):
        src = Path(ev.__file__).read_text()
        assert "b <= placebo" in src


class TestIndependence:
    def test_entry_reads_nothing_from_the_other_pillars(self):
        src = Path(es.__file__).read_text()
        for forbidden in ("company_health", "value_service", "quality_score", "fundamentals",
                          "eps", "pe_ratio"):
            assert forbidden not in src, f"Entry must not depend on {forbidden}"

    def test_entry_uses_adjusted_closes_not_raw(self):
        """The mirror of Value's rule. A technical signal needs a continuous series."""
        assert es.PRICE_FIELD == "close_adj"
        assert "close_raw" not in Path(es.__file__).read_text()

    def test_no_combination_with_health_or_value_was_built(self):
        src = Path(ev.__file__).read_text()
        assert "company_health" not in src and "value_service" not in src

    def test_nothing_is_tunable_from_a_query_string(self):
        assert "request.args" not in Path(ev.__file__).read_text()

    def test_every_response_carries_the_unvalidated_flag(self):
        out = es.evaluate("T", _bars(1200))
        assert out["not_validated"] is True

    def test_entry_is_not_in_the_menu(self):
        """Not validated, so not recommended. A menu entry is an implicit recommendation."""
        import app as app_module
        assert b'href="/entry"' not in app_module.create_app().test_client().get("/").data


class TestOtherPillarsUntouched:
    def test_value_v1_is_frozen(self):
        from services import value_service as vs
        assert vs.METRICS == ("fcf_yield_pct", "ev_to_ebit", "pe_ratio")
        assert vs.BANDS == ((75.0, "CHEAP"), (25.0, "FAIR"), (0.0, "EXPENSIVE"))

    def test_company_health_is_frozen(self):
        from services import company_health as ch
        assert ch.COVERAGE_GATE_PCT == 75.0 and ch.CAP_AT_N_RED_FLAGS == 2

    def test_the_value_validation_is_unchanged(self):
        from services import value_validation as vv
        assert vv.FORWARD_DAYS == 365 and vv.FIRST_COHORT == "2023-07-27"


if __name__ == "__main__":
    unittest.main()
