"""
Monthly engine — verified against the source workbook's own published figures.

The workbook is the reference. If these numbers drift from it, the rebuild has broken something
that used to be right.
"""
import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import pytest
from services import monthly_engine as me

# Taken from the uploaded workbook's own calculated cells, not recomputed here.
WORKBOOK_ANNUAL = {
    "VHYL": {"2021": 0.19236, "2022": 0.05940, "2023": 0.05261, "2024": 0.11223, "2025": 0.18210},
    "CNX1": {"2021": 0.29496, "2022": -0.25528, "2023": 0.47706, "2024": 0.28511, "2025": 0.11566},
    "IITU": {"2021": 0.35673, "2022": -0.20628, "2023": 0.50698, "2024": 0.40849, "2025": 0.14437},
    "SMGB": {"2021": 0.44393, "2022": -0.27501, "2023": 0.66163, "2024": 0.26318, "2025": 0.38787},
}


class TestAgainstWorkbook:
    @pytest.mark.parametrize("ticker", sorted(WORKBOOK_ANNUAL))
    def test_annual_returns_match_the_workbook(self, ticker):
        m = me.metrics(ticker, ticker, "ETF", "GBP", me.etf_seed()[ticker])
        for year, expected in WORKBOOK_ANNUAL[ticker].items():
            assert m["annual"][year] == pytest.approx(expected, abs=1e-5), f"{ticker} {year}"

    def test_the_seed_carries_the_december_2020_baseline(self):
        """2021's return is measured from Dec-2020, exactly as the workbook does it."""
        assert me.etf_seed()["VHYL"][0] == ("2020-12-31", 34.31)

    def test_every_etf_has_the_full_history(self):
        for t, rows in me.etf_seed().items():
            assert len(rows) == 69, t


class TestMetrics:
    def _flat(self, n=40, p=100.0):
        return [(f"20{20+i//12:02d}-{i%12+1:02d}-28", p) for i in range(n)]

    def test_a_flat_series_has_zero_cagr_and_zero_drawdown(self):
        m = me.metrics("T", "T", "STOCK", "USD", self._flat())
        assert m["cagr"] == pytest.approx(0, abs=1e-9)
        assert m["drawdown_from_high"] == pytest.approx(0, abs=1e-9)

    def test_a_doubling_over_one_year_reads_one_hundred_percent(self):
        s = [("2021-12-31", 100.0), ("2022-12-31", 200.0)]
        assert me.metrics("T","T","STOCK","USD",s)["annual"]["2022"] == pytest.approx(1.0)

    def test_drawdown_is_measured_from_the_all_time_high(self):
        s = [(f"2021-{i+1:02d}-28", p) for i, p in enumerate([100, 150, 75])]
        assert me.metrics("T","T","STOCK","USD",s)["drawdown_from_high"] == pytest.approx(-0.5)

    def test_a_missing_prior_year_gives_no_return_rather_than_zero(self):
        """The year is reported as explicitly unavailable. It must never read as a flat year,
        which is what a 0 would look like on the page."""
        s = [("2023-06-30", 100.0), ("2023-12-31", 120.0)]
        assert me.metrics("T","T","STOCK","USD",s)["annual"]["2023"] is None

    def test_no_history_is_missing_data_not_an_exception(self):
        m = me.metrics("T","T","STOCK","USD",[])
        assert m["months"] == 0 and "MISSING DATA" in m["data_status"]

    def test_dca_needs_a_year_before_it_reports(self):
        assert me.dca_annualised(self._flat(6))[1] is None

    def test_dca_on_a_flat_series_is_zero(self):
        assert me.dca_annualised(self._flat(36))[1] == pytest.approx(0, abs=1e-4)

    def test_dca_reproduces_the_workbook_xirr_closely(self):
        """The workbook used XIRR over a fixed column range; this solves the same rate without
        the per-ticker plumbing that stopped it scaling."""
        m = me.metrics("SMGB","SMGB","ETF","GBP", me.etf_seed()["SMGB"])
        assert m["dca_annualised"] == pytest.approx(0.4225, abs=0.01)


class TestMonthEndSampling:
    def test_takes_the_last_trading_day_of_each_month(self):
        bars = [{"ts": "2021-01-28", "close_adj": 10.0}, {"ts": "2021-01-29", "close_adj": 11.0},
                {"ts": "2021-02-26", "close_adj": 12.0}]
        assert me.month_end_samples(bars) == [("2021-01-29", 11.0), ("2021-02-26", 12.0)]

    def test_uses_adjusted_not_raw_closes(self):
        """A return needs the adjusted series. Raw is for valuation and must never be used here."""
        bars = [{"ts": "2021-01-29", "close_adj": 11.0, "close_raw": 110.0}]
        assert me.month_end_samples(bars)[0][1] == 11.0

    def test_blank_and_zero_prices_are_skipped_not_treated_as_zero(self):
        bars = [{"ts": "2021-01-29", "close_adj": None}, {"ts": "2021-02-26", "close_adj": 0}]
        assert me.month_end_samples(bars) == []


class TestSyntheticIndex:
    def _s(self, vals):
        return [(f"2021-{i+1:02d}-28", v) for i, v in enumerate(vals)]

    def test_excludes_tesla_by_construction(self):
        assert "TSLA" not in me.SYNTHETIC_MEMBERS
        assert set(me.SYNTHETIC_MEMBERS) == {"AAPL","MSFT","GOOGL","AMZN","NVDA","META"}

    def test_identical_constituents_give_the_same_return(self):
        s = me.synthetic_series({"A": self._s([100,110]), "B": self._s([50,55])})
        assert s[-1][1] == pytest.approx(110.0)

    def test_equal_weighting_averages_the_returns(self):
        """+20% and 0% must give +10%, not a value-weighted result."""
        s = me.synthetic_series({"A": self._s([100,120]), "B": self._s([100,100])})
        assert s[-1][1] == pytest.approx(110.0)

    def test_rebalancing_means_a_winner_does_not_take_over(self):
        """Buy-and-hold would let the winner dominate; monthly rebalancing must not."""
        a, b = self._s([100,200,200]), self._s([100,100,50])
        s = me.synthetic_series({"A": a, "B": b})
        assert s[-1][1] == pytest.approx(150.0 * 0.75)      # +50% then -25%

    def test_a_constituent_with_no_data_is_skipped_and_counted(self):
        s = me.synthetic_series({"A": self._s([100,110]), "B": [("2021-01-28",100.0)]})
        assert s[-1][2] == 1

    def test_no_constituents_gives_an_empty_series(self):
        assert me.synthetic_series({}) == []


class TestUniverse:
    def test_the_universe_is_the_eleven_agreed_securities(self):
        from config import STOCK_UNIVERSE
        t = {s["ticker"] for s in STOCK_UNIVERSE}
        assert t == {"AAPL","MSFT","GOOGL","AMZN","NVDA","META","TSLA","VHYL","CNX1","IITU","SMGB"}

    def test_meta_was_added(self):
        from config import STOCK_UNIVERSE
        assert "META" in {s["ticker"] for s in STOCK_UNIVERSE}

    def test_the_synthetic_index_is_not_in_the_traded_universe(self):
        from config import STOCK_UNIVERSE
        assert me.SYNTHETIC not in {s["ticker"] for s in STOCK_UNIVERSE}


class TestNavigation:
    def setup_method(self):
        import app as app_module
        self.client = app_module.create_app().test_client()
        self.home = self.client.get("/").data

    @pytest.mark.parametrize("href", ["/signals","/strategy-lab","/backtest","/pattern-test",
                                      "/alerts","/value","/data-validation","/annual-backtest"])
    def test_hidden_pages_are_not_in_the_menu(self, href):
        assert f'href="{href}"'.encode() not in self.home

    @pytest.mark.parametrize("href", ["/signals","/strategy-lab","/backtest","/pattern-test",
                                      "/alerts","/value","/data-validation","/annual-backtest"])
    def test_hidden_pages_still_respond(self, href):
        """Hidden means out of sight, not deleted. A 404 here is a real break."""
        assert self.client.get(href).status_code == 200

    def test_only_dashboard_and_yearly_are_in_the_menu(self):
        assert b'href="/yearly"' in self.home
        assert self.home.count(b'nav-link') <= 4

    def test_the_previous_dashboard_is_still_reachable(self):
        assert self.client.get("/dashboard-legacy").status_code == 200
        assert self.client.get("/yearly-legacy").status_code == 200

    def test_the_monthly_api_serves_every_security_plus_the_index(self):
        body = self.client.get("/api/monthly/universe").get_json()
        assert body["securities"] == 12
        assert any(r["ticker"] == "MAG6" for r in body["results"])

    def test_the_etfs_report_real_numbers_through_the_api(self):
        rows = {r["ticker"]: r for r in self.client.get("/api/monthly/universe").get_json()["results"]}
        assert rows["VHYL"]["annual"]["2021"] == pytest.approx(0.19236, abs=1e-5)
        assert rows["CNX1"]["current_price"] == pytest.approx(1235.5)


if __name__ == "__main__":
    unittest.main()
