"""MONTHLY ANALYSIS — the Excel workbook's methodology for the eleven tracked securities.

Read-only. Nothing here trades, recommends or ranks by anything other than the numbers requested.
"""
from datetime import datetime, timedelta, timezone

from flask import Blueprint, jsonify, request

from config import Config, STOCK_UNIVERSE
from db import get_db
from providers.base import ProviderError
from services import monthly_engine as me
from services import value_bars_service as vb

bp = Blueprint("api_monthly", __name__, url_prefix="/api/monthly")

_META = {s["ticker"]: s for s in STOCK_UNIVERSE}
_ETF = set(me.SEED_ETFS)


def _currency(t):
    return "GBP" if t in _ETF else "USD"


def _series_for(db, ticker, seed):
    """ETFs come from the verified workbook seed; stocks from stored ADJUSTED daily bars."""
    if ticker in _ETF:
        return seed.get(ticker, []), "Workbook monthly adjusted close (GBp converted to GBP)"
    return (me.month_end_samples(vb.bars(db, ticker)),
            "Month-end sample of stored adjusted daily bars")


def _build(db):
    seed = me.etf_seed()
    rows, members = [], {}
    for s in STOCK_UNIVERSE:
        t = s["ticker"]
        series, src = _series_for(db, t, seed)
        m = me.metrics(t, s["name"], "ETF" if t in _ETF else "STOCK", _currency(t), series)
        m["sector"] = s["sector"]
        m["source"] = src
        rows.append(m)
        if t in me.SYNTHETIC_MEMBERS:
            members[t] = series

    syn = me.synthetic_series(members)
    present = sorted(members)
    smetrics = me.metrics(
        me.SYNTHETIC,
        "Magnificent 7 excluding Tesla — equal weight, rebalanced monthly",
        "SYNTHETIC INDEX", "USD", [(d, lvl) for d, lvl, _ in syn])
    smetrics["sector"] = "Home-made index"
    smetrics["source"] = ("Built here, not traded. Each month's return is the plain average of its "
                          "constituents' returns, which is what monthly rebalancing means.")
    smetrics["constituents"] = list(me.SYNTHETIC_MEMBERS)
    smetrics["constituents_with_data"] = present
    smetrics["missing_constituents"] = [t for t in me.SYNTHETIC_MEMBERS if t not in present]
    if smetrics["missing_constituents"]:
        smetrics["data_status"] = ("PARTIAL — no price history for "
                                   + ", ".join(smetrics["missing_constituents"]))
    rows.append(smetrics)
    return rows


@bp.get("/universe")
def universe():
    rows = _build(get_db())
    years = sorted({y for r in rows for y in r.get("annual", {})})
    return jsonify({
        "as_of": datetime.now(timezone.utc).date().isoformat(),
        "securities": len(rows), "years": years,
        "note": ("ETFs are GBP and stocks USD. Returns are not currency-converted, so figures are "
                 "comparable within a currency, not across the two."),
        "results": rows,
    })


@bp.get("/<ticker>")
def one(ticker):
    ticker = ticker.upper()
    rows = {r["ticker"]: r for r in _build(get_db())}
    if ticker not in rows:
        return jsonify({"error": f"{ticker} is not tracked"}), 404
    return jsonify(rows[ticker])


@bp.get("/<ticker>/series")
def series(ticker):
    """The monthly series behind every figure — so a number can be read rather than trusted."""
    ticker = ticker.upper()
    db = get_db()
    if ticker == me.SYNTHETIC:
        seed = me.etf_seed()
        members = {t: _series_for(db, t, seed)[0] for t in me.SYNTHETIC_MEMBERS}
        rows = [{"date": d, "level": lvl, "constituents_used": n}
                for d, lvl, n in me.synthetic_series(members)]
        return jsonify({"ticker": ticker, "observations": len(rows), "series": rows})
    if ticker not in _META:
        return jsonify({"error": f"{ticker} is not tracked"}), 404
    s, src = _series_for(db, ticker, me.etf_seed())
    return jsonify({"ticker": ticker, "source": src, "observations": len(s),
                    "series": [{"date": d, "price": p} for d, p in s]})


@bp.post("/refresh")
def refresh():
    """Fetch adjusted daily bars for the tracked STOCKS. ETFs use the embedded workbook series."""
    db = get_db()
    wanted = [s["ticker"] for s in STOCK_UNIVERSE if s["ticker"] not in _ETF]
    only = (request.args.get("tickers") or "").upper()
    if only:
        wanted = [t for t in wanted if t in {x.strip() for x in only.split(",")}]
    out = []
    for t in wanted:
        try:
            out.append(vb.refresh(db, t))
        except ProviderError as e:                      # never let one failure hide the rest
            out.append({"ticker": t, "status": "UNAVAILABLE", "error": str(e), "rows": 0})
    ok = [r for r in out if r.get("status") == "OK"]
    return jsonify({"requested": len(wanted), "ok": len(ok),
                    "failed": len(out) - len(ok), "results": out,
                    "note": "ETFs are not fetched — their history is the verified workbook series."})
