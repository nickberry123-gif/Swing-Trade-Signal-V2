"""ENTRY — the third pillar. Read-only, unvalidated, and deliberately absent from the menu.

Not in the navigation on purpose: Entry V1 has not been shown to improve anything, and a page in
the menu is an implicit recommendation. It is surfaced only once the pre-registered validation
supports the distinction it draws.
"""
from flask import Blueprint, jsonify, request

from db import get_db
from services import entry_service as en
from services import entry_validation as ev
from services import value_bars_service as vb
from services.signals_service import TICKERS

bp = Blueprint("api_entry", __name__, url_prefix="/api/entry")


@bp.get("/<ticker>")
def entry_for(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    db = get_db()
    return jsonify(en.evaluate(ticker, vb.bars(db, ticker), as_of=request.args.get("as_of")))


@bp.get("/<ticker>/series")
def entry_series(ticker):
    """The daily signal series — the audit trail behind a verdict. `?limit=` takes the last N."""
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    rows = en.series(vb.bars(get_db(), ticker, as_of=request.args.get("as_of")))
    limit = max(1, min(int(request.args.get("limit", 120)), 3000))
    return jsonify({"ticker": ticker, "observations": len(rows), "not_validated": True,
                    "series": rows[-limit:]})


@bp.get("/universe/all")
def entry_universe():
    db = get_db()
    rows = [en.evaluate(t, vb.bars(db, t), as_of=request.args.get("as_of"))
            for t in sorted(TICKERS)]
    counts = {}
    for r in rows:
        counts[r["verdict"]] = counts.get(r["verdict"], 0) + 1
    return jsonify({"tickers": len(rows), "verdicts": counts, "not_validated": True,
                    "results": rows})


@bp.get("/validation/run")
def entry_validation_run():
    """The pre-registered Entry validation. Read-only; stores nothing; nothing is tunable here.

    The wait window, the tercile cuts and the pass mark are constants in the service module, not
    query parameters, because a knob is an invitation to turn it until the result reads well.
    """
    return jsonify(ev.run(get_db(), sorted(TICKERS)))
