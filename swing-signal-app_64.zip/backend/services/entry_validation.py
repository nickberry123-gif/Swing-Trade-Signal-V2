"""
ENTRY V1 — the pre-registered validation. Written before the model produced a single number.

THE QUESTION, IN THE FORM THAT MATCHES THE ACTUAL OBJECTIVE:

    I am a long-term investor buying regularly. Instead of investing on the same date every month
    regardless of conditions, can Entry identify whether buying now or waiting briefly produces a
    measurably better purchase?

This is NOT "which stock returns most". Entry never chooses the company. Every arm below buys the
SAME company in the SAME month; only the day differs.

WHY THAT PAIRING IS THE IMPORTANT DESIGN CHOICE. The Value validation was dominated by an average
forward return of +43% a year — the signature of fifty companies chosen in 2026 with hindsight.
Here that drift is common to every arm and very largely cancels, because all arms hold the same
stock over the same period. What survives the subtraction is the entry day alone. This is a
materially better-posed question than Value's, and it is why ~3,100 non-overlapping paired
observations are available where Value had 293 overlapping ones.

THREE ARMS, AND WHY THE THIRD EXISTS:

    BASELINE      buy on the first trading day of every month, always.
    ENTRY         wait up to 10 trading days only when the signal says UNFAVOURABLE.
    ALWAYS-WAIT   wait the full 10 trading days every month, ignoring the signal.

ALWAYS-WAIT is the placebo, and without it the study is uninterpretable. In a rising market simply
buying earlier wins, so BASELINE gets a free advantage over anything that waits, and any waiting
rule gets a free penalty. ALWAYS-WAIT measures the size of that penalty with no signal involved.
Entry has to beat the placebo, not merely lose to the baseline by less than the placebo does.

WHAT IS FIXED AND MAY NOT MOVE. The 10-day window, the tercile cuts, the T+1 execution convention,
the outcome measures and the pass mark were all set at approval. Trying 5, 10 and 20 days and
reporting the best is precisely how a result gets manufactured, and there is deliberately no way to
vary any of them from a query string.
"""
from datetime import date

from services import entry_service as es
from services import value_bars_service as vb

# ---- FROZEN AT APPROVAL ----------------------------------------------------------------------
WAIT_DAYS = 10                  # maximum trading days Entry may wait
FORWARD_HORIZONS = (21, 63, 126, 252)      # ~1, 3, 6, 12 months, in trading days
MAE_DAYS = 21                   # immediate drawdown window after purchase
PASS_THRESHOLD_PCT = 0.25       # set by real-world friction, not by any observed effect size
MIN_TRIGGERED = 100             # below this the study is reported as underpowered

TRIGGERED, IMMEDIATE = "TRIGGERED", "IMMEDIATE"


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return round(sum(xs) / len(xs), 4) if xs else None


def _median(xs):
    xs = sorted(x for x in xs if x is not None)
    if not xs:
        return None
    m = len(xs) // 2
    return round(xs[m] if len(xs) % 2 else (xs[m - 1] + xs[m]) / 2.0, 4)


def month_start_indices(rows: list) -> list:
    """Index of the FIRST trading day of each calendar month present in the series.

    A fixed calendar date is what a regular investor actually does, and the first trading day is
    the unambiguous version of it — no decision, no discretion, nothing to tune.
    """
    out, seen = [], set()
    for i, r in enumerate(rows):
        d = r.get("date") or ""
        if len(d) < 7:
            continue
        key = d[:7]
        if key not in seen:
            seen.add(key)
            out.append(i)
    return out


def _forward(rows: list, buy_i: int) -> dict:
    """Return from the purchase price at each pre-registered horizon, plus worst close after it."""
    buy = rows[buy_i]["close"]
    out = {}
    for h in FORWARD_HORIZONS:
        j = buy_i + h
        out[f"return_{h}d_pct"] = (round((rows[j]["close"] / buy - 1.0) * 100.0, 4)
                                   if j < len(rows) and buy and rows[j]["close"] else None)
    window = [r["close"] for r in rows[buy_i + 1:buy_i + 1 + MAE_DAYS] if r["close"]]
    out["mae_21d_pct"] = (round((min(window) / buy - 1.0) * 100.0, 4)
                          if window and buy else None)
    return out


def observations_for_ticker(ticker: str, bars: list) -> list:
    """One row per month: what each of the three arms paid, and what happened afterwards."""
    rows = es.series(bars)
    obs = []
    for m in month_start_indices(rows):
        last_purchase = m + WAIT_DAYS + 1
        if last_purchase >= len(rows):
            continue                       # no full wait window; excluded rather than shortened
        v0 = rows[m]["verdict"]
        if v0 == es.UNKNOWN:
            continue                       # no opinion, so nothing to test
        prices = [rows[k]["close"] for k in range(m + 1, last_purchase + 1)]
        if not all(prices):
            continue

        # DECISION at the close of day d, PURCHASE at the close of day d+1. Never the same close
        # the decision was made on — that would be a look-ahead of exactly one day, which is the
        # easiest and most common way to fabricate a timing edge.
        baseline_i = m + 1
        if v0 != es.UNFAVOURABLE:
            entry_i, waited = baseline_i, 0
        else:
            entry_i, waited = last_purchase, WAIT_DAYS
            for k in range(m + 1, m + WAIT_DAYS + 1):
                if rows[k]["verdict"] not in (es.UNFAVOURABLE, es.UNKNOWN):
                    entry_i, waited = k + 1, k - m
                    break

        baseline_p, entry_p = rows[baseline_i]["close"], rows[entry_i]["close"]
        wait_p = rows[last_purchase]["close"]
        window_mean = sum(prices) / len(prices)

        obs.append({
            "ticker": ticker, "month": rows[m]["date"][:7], "decision_date": rows[m]["date"],
            "verdict": v0, "trend": rows[m]["trend"],
            "stretch_percentile": rows[m]["stretch_percentile"],
            "state": TRIGGERED if v0 == es.UNFAVOURABLE else IMMEDIATE,
            "waited_days": waited,
            "baseline_price": round(baseline_p, 4), "entry_price": round(entry_p, 4),
            "always_wait_price": round(wait_p, 4), "window_mean": round(window_mean, 4),
            # CO-PRIMARY (a) — the question actually asked. Positive = Entry paid less.
            "entry_vs_baseline_pct": round((baseline_p - entry_p) / baseline_p * 100.0, 4),
            # CO-PRIMARY (b) — versus a random day in the same window. Positive = Entry beat
            # chance at a matched opportunity set.
            "entry_vs_window_pct": round((window_mean - entry_p) / window_mean * 100.0, 4),
            # PLACEBO — what waiting costs with no signal at all.
            "always_wait_vs_window_pct": round((window_mean - wait_p) / window_mean * 100.0, 4),
            "baseline_vs_window_pct": round((window_mean - baseline_p) / window_mean * 100.0, 4),
            "forward_entry": _forward(rows, entry_i),
            "forward_baseline": _forward(rows, baseline_i),
        })
    return obs


def _summarise(obs: list) -> dict:
    if not obs:
        return {"n": 0}
    out = {
        "n": len(obs),
        "entry_vs_baseline_pct": {"mean": _mean([o["entry_vs_baseline_pct"] for o in obs]),
                                  "median": _median([o["entry_vs_baseline_pct"] for o in obs])},
        "entry_vs_window_pct": {"mean": _mean([o["entry_vs_window_pct"] for o in obs]),
                                "median": _median([o["entry_vs_window_pct"] for o in obs])},
        "always_wait_vs_window_pct": {
            "mean": _mean([o["always_wait_vs_window_pct"] for o in obs]),
            "median": _median([o["always_wait_vs_window_pct"] for o in obs])},
        "baseline_vs_window_pct": {"mean": _mean([o["baseline_vs_window_pct"] for o in obs])},
        "mean_waited_days": _mean([o["waited_days"] for o in obs]),
        "months_entry_beat_baseline": sum(1 for o in obs if o["entry_vs_baseline_pct"] > 0),
        "months_entry_lost_to_baseline": sum(1 for o in obs if o["entry_vs_baseline_pct"] < 0),
        "months_identical": sum(1 for o in obs if o["entry_vs_baseline_pct"] == 0),
    }
    for h in FORWARD_HORIZONS:
        k = f"return_{h}d_pct"
        diffs = [o["forward_entry"][k] - o["forward_baseline"][k] for o in obs
                 if o["forward_entry"][k] is not None and o["forward_baseline"][k] is not None]
        out[f"forward_{h}d_diff_pct"] = {"n": len(diffs), "mean": _mean(diffs),
                                         "median": _median(diffs)}
    out["mae_21d_pct"] = {
        "entry": _mean([o["forward_entry"]["mae_21d_pct"] for o in obs]),
        "baseline": _mean([o["forward_baseline"]["mae_21d_pct"] for o in obs]),
    }
    return out


def run(db, tickers: list) -> dict:
    """The whole pre-registered study. One call, one result, reported as produced."""
    all_obs = []
    for t in sorted(tickers):
        bars = vb.bars(db, t)
        if len(bars) >= es.WARMUP_BARS:
            all_obs.extend(observations_for_ticker(t, bars))

    triggered = [o for o in all_obs if o["state"] == TRIGGERED]
    months = sorted({o["month"] for o in all_obs})
    midpoint = months[len(months) // 2] if months else None
    first_half = [o for o in triggered if midpoint and o["month"] < midpoint]
    second_half = [o for o in triggered if midpoint and o["month"] >= midpoint]

    per_ticker = {}
    for t in sorted({o["ticker"] for o in triggered}):
        rows = [o for o in triggered if o["ticker"] == t]
        per_ticker[t] = {"n": len(rows),
                         "entry_vs_window_pct": _mean([o["entry_vs_window_pct"] for o in rows])}
    positive_tickers = sum(1 for v in per_ticker.values()
                           if v["entry_vs_window_pct"] is not None
                           and v["entry_vs_window_pct"] > 0)

    overall = _summarise(all_obs)
    trig = _summarise(triggered)
    h1, h2 = _summarise(first_half), _summarise(second_half)

    # ---- PASS / FAIL / INCONCLUSIVE, exactly as fixed at approval ----
    b = (trig.get("entry_vs_window_pct") or {}).get("mean")
    placebo = (trig.get("always_wait_vs_window_pct") or {}).get("mean")
    h1b = (h1.get("entry_vs_window_pct") or {}).get("mean")
    h2b = (h2.get("entry_vs_window_pct") or {}).get("mean")

    if len(triggered) < MIN_TRIGGERED or b is None:
        outcome, why = "INCONCLUSIVE", (
            f"only {len(triggered)} triggered months; {MIN_TRIGGERED} were required before the "
            f"result could be interpreted.")
    elif b <= 0 or (h1b is not None and h2b is not None and (h1b > 0) != (h2b > 0)):
        outcome, why = "FAIL", (
            "the drift-controlled co-primary is not positive, or its sign is not stable between "
            "the two halves of the period.")
    elif b < PASS_THRESHOLD_PCT:
        outcome, why = "INCONCLUSIVE", (
            f"positive but {b:.3f}% is below the {PASS_THRESHOLD_PCT}% friction bar, so the "
            f"effect is smaller than the cost of acting on it.")
    elif placebo is not None and b <= placebo:
        outcome, why = "FAIL", (
            "Entry did not beat the ALWAYS-WAIT placebo, so what looks like timing is the effect "
            "of waiting rather than of the signal.")
    elif positive_tickers <= len(per_ticker) / 2:
        outcome, why = "FAIL", (
            f"positive in only {positive_tickers} of {len(per_ticker)} companies — not a clear "
            f"majority.")
    else:
        outcome, why = "PASS", (
            "positive beyond the friction bar, stable across both halves, ahead of the placebo, "
            "and positive in a clear majority of companies.")

    return {
        "outcome": outcome, "outcome_reason": why,
        "pass_threshold_pct": PASS_THRESHOLD_PCT, "wait_days": WAIT_DAYS,
        "observations": len(all_obs), "triggered": len(triggered),
        "trigger_rate_pct": round(len(triggered) / len(all_obs) * 100.0, 1) if all_obs else None,
        "companies": len({o["ticker"] for o in all_obs}),
        "months": len(months), "first_month": months[0] if months else None,
        "last_month": months[-1] if months else None, "half_split_at": midpoint,
        "verdict_counts": {v: sum(1 for o in all_obs if o["verdict"] == v)
                           for v in (es.FAVOURABLE, es.NEUTRAL, es.UNFAVOURABLE)},
        "all_months": overall,
        "triggered_months": trig,
        "first_half": h1, "second_half": h2,
        "companies_positive_on_co_primary_b": positive_tickers,
        "companies_measured": len(per_ticker),
        "per_ticker_entry_vs_window_pct": per_ticker,
        "arms": {
            "BASELINE": "buy at the close after the first trading day of each month, always",
            "ENTRY": f"wait up to {WAIT_DAYS} trading days only when the signal is UNFAVOURABLE",
            "ALWAYS_WAIT": f"wait the full {WAIT_DAYS} trading days every month — the placebo",
        },
        "limitations": [
            "Adjusted daily closes begin 2020-07-27 and a 220-bar warm-up is needed, so monthly "
            "decisions start around mid-2021 — roughly five years.",
            "Fifty companies selected in 2026, none of which failed. The paired design cancels "
            "much of this but does not remove it.",
            "The period rose strongly, which penalises any rule that waits. ALWAYS-WAIT measures "
            "that penalty; it is the reason co-primary (b) rather than (a) decides the outcome.",
            "Forward returns at 63, 126 and 252 trading days overlap between months and are NOT "
            "independent. The co-primaries do not overlap.",
            "Closes only — no intraday data, so every decision and purchase is at a close.",
            "No p-values. This sample cannot support a significance claim.",
        ],
    }
