"""
ENTRY — "Given that I already want to own this company, is now a relatively favourable, neutral or
unfavourable time to make this month's purchase?"

The third pillar. Independent of Company Health and Value by construction: nothing here reads a
filing, a multiple or a quality score, and nothing there reads this. Entry does not choose WHICH
company to buy — that decision is already made — it only comments on WHEN within a month.

TWO SIGNALS, NOT FIVE, AND THE REASON MATTERS. The Value phase ended with the finding that its
three multiples were one price series read three ways: between filings all three were monotone
functions of the same price, so they produced identical rankings and carried no independent
information. The identical trap is waiting here. RSI, distance-from-moving-average,
drawdown-from-recent-high and short-horizon momentum are all functions of the same recent price
path; stacking them would produce a five-component score that measures one thing and looks like it
measures five.

A daily close series supports exactly two genuinely different questions for this purpose:

    DISPLACEMENT — how far from its own recent path is the price today?   -> stretch
    DIRECTION    — which way is that path going?                          -> trend

Volatility is not a third signal. It is the denominator of the first: an 8% fall in a quiet
industrial and an 8% fall in a semiconductor are not the same event, and dividing by realised
volatility is what makes them comparable.

WHAT IS DELIBERATELY ABSENT: relative strength (a benchmark-relative restatement of the same two
things), RSI, drawdown-from-high, MACD, volume, and any indicator whose value is a transformation
of stretch. Each was considered and excluded as duplicative, not overlooked.

THRESHOLDS ARE SET BY THE DISTRIBUTION, NEVER BY THE OUTCOME. The cut points are terciles of the
stock's OWN expanding stretch history. They are defined by the shape of that distribution before
any performance number exists. Choosing a cut because it produced a better backtest is the failure
mode this project exists to prevent.

NOT VALIDATED. Entry V1 has not been shown to improve anything. It is deliberately not surfaced in
the app's menu, and it must not be treated as a buy signal unless and until the pre-registered
validation in entry_validation.py supports the distinction.
"""
from bisect import bisect_left, bisect_right, insort
from math import sqrt

# ---- FROZEN AT APPROVAL. Varying these and reporting the best is manufacturing a result. -------
SMA_FAST = 50            # the "recent path" the price is measured against
SMA_SLOW = 200           # the longer path whose direction defines the trend
SLOPE_LOOKBACK = 20      # trading days over which SMA200 must have risen
VOL_WINDOW = 50          # realised-volatility window, matched to SMA_FAST
MIN_PERCENTILE_HISTORY = 250   # ~1 trading year before any opinion is offered

# Terciles of the stock's own stretch history. Fixed now, before any performance result exists.
FAVOURABLE_PCT = 100.0 * 2.0 / 3.0     # 66.67 and above
UNFAVOURABLE_PCT = 100.0 / 3.0         # below 33.33

FAVOURABLE, NEUTRAL, UNFAVOURABLE, UNKNOWN = (
    "FAVOURABLE", "NEUTRAL", "UNFAVOURABLE", "UNKNOWN")

UPTREND, NOT_UPTREND = "UPTREND", "NOT_UPTREND"

# Entry uses ADJUSTED closes. A technical signal needs a continuous series, and the adjusted series
# is exactly that — splits and dividends already removed. This is the opposite of Value, which
# needs RAW prices because a multiple must share a share basis with its filing. The two pillars
# use different bases for good reasons and neither may borrow the other's.
PRICE_FIELD = "close_adj"

WARMUP_BARS = SMA_SLOW + SLOPE_LOOKBACK


def _v(x):
    if x is None or isinstance(x, bool):
        return None
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    return None if f != f or f in (float("inf"), float("-inf")) else f


def _sma(closes: list, i: int, window: int):
    """Simple mean of the `window` closes ending at and INCLUDING index i.

    Including i is correct and is not look-ahead: the close of day i is known at the close of
    day i, which is when the decision is made. The purchase happens the following day.
    """
    if i + 1 < window:
        return None
    chunk = closes[i + 1 - window:i + 1]
    return sum(chunk) / window


def _realised_vol(closes: list, i: int, window: int = VOL_WINDOW):
    """Standard deviation of daily simple returns over `window` days ending at i.

    Simple rather than log returns because the stretch it scales is itself a simple price
    difference; mixing the two would put numerator and denominator on different footings.
    """
    if i < window:
        return None
    rets = []
    for k in range(i - window + 1, i + 1):
        prev = closes[k - 1]
        if not prev:
            return None
        rets.append(closes[k] / prev - 1.0)
    n = len(rets)
    if n < 2:
        return None
    mean = sum(rets) / n
    var = sum((r - mean) ** 2 for r in rets) / (n - 1)
    return sqrt(var)


def stretch_at(closes: list, i: int):
    """SIGNAL A — how unusually far below or above its own recent path the price sits.

        stretch = (close - SMA50) / (daily volatility * sqrt(50))

    Negative means below the recent path — the direction a buyer wants. Dividing by volatility
    scaled to the same 50-day horizon expresses the gap in units of "normal movement for THIS
    stock", so a quiet company and a violent one are on one scale.

    This single number deliberately stands in for distance-from-MA, RSI, drawdown-from-high and
    short-horizon momentum, which are near-substitutes for one another.
    """
    if i < 0 or i >= len(closes):
        return None
    close = _v(closes[i])
    sma = _sma(closes, i, SMA_FAST)
    vol = _realised_vol(closes, i)
    if not close or not sma or not vol or vol <= 0:
        return None
    return (close - sma) / (vol * sqrt(SMA_FAST) * sma) if sma else None


def trend_at(closes: list, i: int):
    """SIGNAL B — direction. Binary on purpose.

    UPTREND requires the price above its 200-day mean AND that mean higher than it was 20 trading
    days ago. Both conditions, because a price can sit above a mean that is rolling over.

    Binary rather than graded to keep it genuinely separate from stretch: a graded trend score
    would be another function of recent price distance and would re-introduce the correlation this
    design exists to avoid. Stretch answers "how far"; trend answers "which way".
    """
    slow = _sma(closes, i, SMA_SLOW)
    prior = _sma(closes, i - SLOPE_LOOKBACK, SMA_SLOW)
    close = _v(closes[i]) if 0 <= i < len(closes) else None
    if slow is None or prior is None or close is None:
        return None
    return UPTREND if (close > slow and slow > prior) else NOT_UPTREND


def verdict_from(percentile, trend):
    """Map stretch percentile and trend to the three states.

    100 = most stretched DOWNWARD, which is the direction a buyer wants.

    A stock that is not in an uptrend is never FAVOURABLE, however far it has fallen. That is a
    stated prior, fixed before any result: a large decline in a falling stock is not a discount,
    and this pillar will not describe it as one. It costs the model its most extreme signals in
    exactly the cases where they would be most tempting.
    """
    if percentile is None or trend is None:
        return UNKNOWN
    if trend == NOT_UPTREND:
        return NEUTRAL
    if percentile >= FAVOURABLE_PCT:
        return FAVOURABLE
    if percentile < UNFAVOURABLE_PCT:
        return UNFAVOURABLE
    return NEUTRAL


def series(bars: list) -> list:
    """One row per bar: stretch, its EXPANDING-window percentile, trend, and the verdict.

    THE EXPANDING WINDOW IS THE WHOLE POINT AND IS THIS MODULE'S ONE LOOK-AHEAD TRAP. The
    percentile at day i is computed against days strictly BEFORE i. Ranking a 2021 stretch inside
    the full six-year distribution would let 2025 inform a 2021 decision, and the backtest would
    look excellent for a purely mechanical reason.

    Implemented with a sorted list and binary search rather than by rescanning history each day —
    the same answer, but O(n log n) instead of O(n squared), which is the difference between a
    request that returns and one that times out.
    """
    closes = [_v(b.get(PRICE_FIELD)) for b in bars]
    out, history = [], []
    for i, bar in enumerate(bars):
        s = stretch_at(closes, i) if closes[i] else None
        t = trend_at(closes, i)
        pct = None
        if s is not None and len(history) >= MIN_PERCENTILE_HISTORY:
            # Higher percentile = more stretched DOWN = more favourable. Count how many past
            # observations were LESS stretched down (i.e. greater), ties at mid-rank.
            n = len(history)
            greater = n - bisect_right(history, s)
            ties = bisect_right(history, s) - bisect_left(history, s)
            pct = round((greater + 0.5 * ties) / n * 100.0, 1)
        out.append({
            "date": (bar.get("ts") or "")[:10],
            "close": closes[i],
            "stretch": round(s, 4) if s is not None else None,
            "stretch_percentile": pct,
            "trend": t,
            "verdict": verdict_from(pct, t),
        })
        if s is not None:
            insort(history, s)
    return out


def evaluate(ticker: str, bars: list, as_of: str | None = None) -> dict:
    """Entry for one company on one date. Pure — no database, no network."""
    ticker = (ticker or "").upper()
    rows = [b for b in (bars or []) if not as_of or (b.get("ts") or "")[:10] <= as_of[:10]]
    if len(rows) < WARMUP_BARS:
        return {"ticker": ticker, "as_of": (as_of or None), "verdict": UNKNOWN,
                "stretch": None, "stretch_percentile": None, "trend": None,
                "observations": len(rows),
                "reason": (f"needs {WARMUP_BARS} daily bars before a trend can be established; "
                           f"{len(rows)} stored"),
                "not_validated": True}
    last = series(rows)[-1]
    return {
        "ticker": ticker, "as_of": last["date"], "verdict": last["verdict"],
        "stretch": last["stretch"], "stretch_percentile": last["stretch_percentile"],
        "trend": last["trend"], "observations": len(rows),
        "reason": None if last["verdict"] != UNKNOWN else (
            f"fewer than {MIN_PERCENTILE_HISTORY} prior stretch observations, so no percentile"),
        # Carried in every response so it cannot be read as a recommendation by accident.
        "not_validated": True,
        "note": ("Entry V1 is UNVALIDATED. It comments on timing within a month for a company you "
                 "have already decided to own. It is not a buy signal and says nothing about "
                 "whether the company is worth owning."),
    }
