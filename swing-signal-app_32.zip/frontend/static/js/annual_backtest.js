// Annual-reset backtest. Background thread + polling, like the other long analyses.

function abTile(label, value, sub, cls) {
  return `<div class="stat-tile"><div class="st-label">${label}</div>
    <div class="st-value ${cls || ""}">${value}</div>
    ${sub ? `<div class="st-sub">${sub}</div>` : ""}</div>`;
}

function days(v) {
  return v === null || v === undefined ? "—" : fmtNum(v, 1) + "d";
}

function pct(v) {
  return v === null || v === undefined ? "—" : fmtNum(v, 1) + "%";
}

function renderValidation(v) {
  const tbody = document.getElementById("ab-validation");
  tbody.innerHTML = (v.checks || []).map((c) => `
    <tr>
      <td>${c.check}</td>
      <td class="text-right ${c.passed ? "num-pos" : "num-neg"}" style="font-weight:600;">
        ${c.passed ? "PASS" : "FAIL"}</td>
      <td style="font-size:11.5px;" class="text-dim">${
        c.note ? c.note
        : c.passed ? "&mdash;"
        : `${c.count} failure(s), e.g. ${JSON.stringify((c.failures || [])[0] || {})}`}</td>
    </tr>`).join("");
}

function renderAnnual(r) {
  const a = r.annual || r;                     // tolerate either payload shape
  document.getElementById("ab-results").style.display = "";

  renderValidation(a.validation || { checks: [] });

  const o = a.overall || {};
  document.getElementById("ab-overall").innerHTML = [
    abTile("Annual test periods", o.annual_test_periods ?? "—",
           `${o.complete_years ?? 0} complete${(o.partial_years || []).length
             ? `, ${(o.partial_years || []).join(", ")} partial` : ""}`),
    abTile("Total trades", o.trades ?? 0, "across all years"),
    abTile("Target hits", o.target_hits ?? 0, "reached target inside the year", "num-pos"),
    abTile("Year-end exits", o.year_end_exits ?? 0, "ran out of calendar", "num-neg"),
    abTile("Target hit rate", pct(o.target_hit_rate_pct), "of completed trades"),
    abTile("Avg return / trade", fmtPct(o.avg_return_pct, 2), null, pctClass(o.avg_return_pct)),
    abTile("Median return", fmtPct(o.median_return_pct, 2), null, pctClass(o.median_return_pct)),
    abTile("Best / worst", `${fmtPct(o.best_pct, 1)} / ${fmtPct(o.worst_pct, 1)}`),
    // Portfolio figures come from chaining the independent years, NOT from pooling every trade
    // into one account — pooling is the continuous backtest this page exists to be measured
    // against, and it once put -0.1% here against a true figure near +25%.
    abTile("Total return", fmtPct(o.total_return_pct, 2), "years chained together",
           pctClass(o.total_return_pct)),
    abTile("Annualised", fmtPct(o.annualised_return_pct, 2),
           `over ${(o.yearly_chain || []).length} year(s)`, pctClass(o.annualised_return_pct)),
    abTile("Max drawdown", fmtPct(o.max_drawdown_pct, 2), "measured year-end to year-end",
           "num-neg"),
  ].join("");

  const chain = o.yearly_chain || [];
  document.getElementById("ab-chain").innerHTML = chain.length
    ? chain.map((c) => `<tr>
        <td>${c.year}${c.partial_year ? ` <span class="yc-flag">partial</span>` : ""}</td>
        <td class="text-right ${pctClass(c.year_return_pct)}">${fmtPct(c.year_return_pct, 2)}</td>
        <td class="text-right ${pctClass(c.cumulative_pct)}" style="font-weight:600;">${fmtPct(c.cumulative_pct, 2)}</td>
      </tr>`).join("")
    : `<tr class="loading-row"><td colspan="3">No year produced a completed trade.</td></tr>`;

  const t = o.time_to_target || {};
  document.getElementById("ab-ttt").innerHTML = t.n
    ? [abTile("Trades reaching target", t.n),
       abTile("Median", days(t.median)), abTile("Average", days(t.mean)),
       abTile("25th percentile", days(t.p25)), abTile("75th percentile", days(t.p75)),
       abTile("90th percentile", days(t.p90)),
       abTile("Fastest / slowest", `${t.min ?? "—"}d / ${t.max ?? "—"}d`)].join("")
    : `<div class="text-dim" style="font-size:12.5px;">No trade reached its target inside a calendar year.</div>`;

  const y = o.year_end_analysis || {};
  document.getElementById("ab-yearend").innerHTML = y.n
    ? [abTile("Year-end exits", y.n),
       abTile("Average return", fmtPct(y.mean_pct, 2), null, pctClass(y.mean_pct)),
       abTile("Median return", fmtPct(y.median_pct, 2), null, pctClass(y.median_pct)),
       abTile("Best", fmtPct(y.best_pct, 1), null, pctClass(y.best_pct)),
       abTile("Worst", fmtPct(y.worst_pct, 1), null, pctClass(y.worst_pct)),
       abTile("Profitable", y.profitable ?? 0, "in profit when the year ended", "num-pos"),
       abTile("Unprofitable", y.unprofitable ?? 0, "in loss when the year ended", "num-neg")].join("")
    : `<div class="text-dim" style="font-size:12.5px;">No year-end exits.</div>`;

  const byYear = a.by_year || {};
  document.getElementById("ab-byyear").innerHTML = Object.keys(byYear).sort().map((yr) => {
    const d = byYear[yr], tt = d.time_to_target || {};
    return `<tr>
      <td>${yr}${d.partial_year ? ` <span class="yc-flag">partial</span>` : ""}</td>
      <td class="text-right">${d.trades}</td>
      <td class="text-right num-pos">${d.target_hits}</td>
      <td class="text-right num-neg">${d.year_end_exits}</td>
      <td class="text-right">${pct(d.target_hit_rate_pct)}</td>
      <td class="text-right">${days(tt.mean)}</td>
      <td class="text-right">${days(tt.median)}</td>
      <td class="text-right ${pctClass(d.avg_return_pct)}">${fmtPct(d.avg_return_pct, 2)}</td>
      <td class="text-right ${pctClass(d.total_return_pct)}">${fmtPct(d.total_return_pct, 1)}</td>
      <td class="text-right num-neg">${fmtPct(d.max_drawdown_pct, 1)}</td>
    </tr>`;
  }).join("") || `<tr class="loading-row"><td colspan="10">No years produced trades.</td></tr>`;

  const c = r.difference || {};
  document.getElementById("ab-compare").innerHTML = [
    abTile("Trades — continuous", c.trades_continuous ?? "—"),
    abTile("Trades — annual reset", c.trades_annual ?? "—"),
    abTile("Avg return — continuous", fmtPct(c.avg_return_continuous_pct, 2), null,
           pctClass(c.avg_return_continuous_pct)),
    abTile("Avg return — annual", fmtPct(c.avg_return_annual_pct, 2), null,
           pctClass(c.avg_return_annual_pct)),
    abTile("Win rate — continuous", pct(c.win_rate_continuous_pct)),
    abTile("Win rate — annual", pct(c.win_rate_annual_pct)),
    // The number that quantifies exactly what the annual rule takes away.
    abTile("Continuous trades that crossed a year", c.continuous_trades_crossing_a_year ?? "—",
           c.continuous_cross_year_share_pct !== null && c.continuous_cross_year_share_pct !== undefined
             ? `${c.continuous_cross_year_share_pct}% of them` : ""),
  ].join("");

  document.getElementById("ab-byyearstock").innerHTML = (a.by_year_stock || []).map((row) => {
    const tt = row.time_to_target || {};
    return `<tr onclick="window.location.href='/stocks/${encodeURIComponent(row.stock)}'">
      <td>${row.year}${row.partial_year ? ` <span class="yc-flag">partial</span>` : ""}</td>
      <td><span class="ticker-badge">${row.stock}</span></td>
      <td style="font-size:11.5px;">${row.strategy}</td>
      <td class="text-right">${row.trades}</td>
      <td class="text-right num-pos">${row.target_hits}</td>
      <td class="text-right num-neg">${row.year_end_exits}</td>
      <td class="text-right">${pct(row.target_hit_rate_pct)}</td>
      <td class="text-right">${days(tt.mean)}</td>
      <td class="text-right">${days(tt.median)}</td>
      <td class="text-right ${pctClass(row.avg_return_pct)}">${fmtPct(row.avg_return_pct, 2)}</td>
    </tr>`;
  }).join("") || `<tr class="loading-row"><td colspan="10">No rows.</td></tr>`;

  const trades = a.trades || [];
  document.getElementById("ab-trades").innerHTML = trades.length
    ? trades.slice(0, 400).map((t) => `<tr>
        <td class="text-right">${t.calendar_year ?? "—"}</td>
        <td><span class="ticker-badge">${t.ticker}</span></td>
        <td>${t.entry_date}</td>
        <td class="text-right">${fmtPrice(t.entry_price)}</td>
        <td>${t.exit_date || "—"}</td>
        <td class="text-right">${fmtPrice(t.exit_price)}</td>
        <td style="font-size:11px;">${(t.exit_reason || "").replace(/_/g, " ").toLowerCase()}</td>
        <td class="text-right ${t.target_reached ? "num-pos" : "text-dim"}">${t.target_reached ? "yes" : "no"}</td>
        <td class="text-right">${t.holding_days ?? "—"}</td>
        <td class="text-right ${pctClass(t.return_pct)}">${fmtPct(t.return_pct, 2)}</td>
      </tr>`).join("")
    : `<tr class="loading-row"><td colspan="10">No trades.</td></tr>`;

  document.getElementById("ab-limitations").innerHTML =
    (a.limitations || []).map((l) => `<li>${l}</li>`).join("");
}

document.getElementById("ab-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const btn = document.getElementById("ab-run-btn");
  const msg = document.getElementById("ab-message");
  btn.disabled = true;
  btn.textContent = "Running…";

  const started = Date.now();
  // Server-reported stage. Without it a long run looks identical to a hung one.
  let stage = "";
  const tick = () => {
    const secs = Math.round((Date.now() - started) / 1000);
    msg.innerHTML = `<div class="warn-banner">Running both frameworks — ${secs}s elapsed. Indicators are recomputed for every bar of every stock, twice, so this takes several minutes. The run continues on the server whether or not you stay here.${stage ? `<br><strong>${stage}</strong>` : ""}</div>`;
  };
  tick();
  const ticker = setInterval(tick, 1000);

  try {
    const res = await fetch("/api/annual-backtest/run", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        max_holding_days: Number(document.getElementById("ab-hold").value),
        slippage_pct: Number(document.getElementById("ab-slip").value),
        max_positions: Number(document.getElementById("ab-positions").value),
        strategy_id: selectedStrategyId("ab-strategy"),
      }),
    });
    const contentType = res.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      throw new Error(`Server returned ${res.status} instead of JSON — the request likely timed out at the gateway.`);
    }
    const startedRun = await res.json();
    if (startedRun.error) throw new Error(startedRun.error);
    const runId = startedRun.run_id;
    if (!runId) throw new Error("Server did not return a run id.");

    const deadline = Date.now() + 40 * 60 * 1000;
    let run = null;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 4000));
      const poll = await fetch(`/api/annual-backtest/runs/${runId}`, { headers: { Accept: "application/json" } });
      if (!poll.ok) continue;
      run = await poll.json();
      if (run.progress) stage = run.progress;
      if (run.status && run.status !== "running") break;
    }
    clearInterval(ticker);

    if (!run || run.status === "running") {
      throw new Error("Still running after 40 minutes. Reload shortly — the result is stored on the server.");
    }
    if (run.status === "failed") throw new Error(run.error || "The annual backtest failed on the server.");

    msg.innerHTML = "";
    renderAnnual(run.results || {});
  } catch (e) {
    clearInterval(ticker);
    msg.innerHTML = `<div class="error-banner">${e.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Run Annual Backtest";
  }
});

populateStrategySelect("ab-strategy");

(async function showLatest() {
  try {
    const list = await apiGet("/api/annual-backtest/runs");
    const done = (list.runs || []).find((r) => r.status === "complete");
    if (!done) return;
    const run = await apiGet(`/api/annual-backtest/runs/${done.id}`);
    if (run.results) renderAnnual(run.results);
  } catch (e) {
    // Nothing stored yet is not an error worth showing.
  }
})();
