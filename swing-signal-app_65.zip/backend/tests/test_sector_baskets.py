"""
Sector baskets: look-ahead, missing data, chaining, and the labels that stop the numbers lying.

WHAT THESE ARE FOR. Not "does it return a percentage". Every number this page produces will be
large and positive, because the fifty holdings were chosen in 2026 by someone who knew which had
gone up. The tests therefore guard the things that would make a plausible number a false one:
weights peeking at the year they are weighting, a missing stock counted as a zero, yearly
figures added instead of compounded, and the hindsight warning going missing.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd  # noqa: E402

from services import sector_basket_service as sb  # noqa: E402

YEARS = [2021, 2022, 2023, 2024]


def _loaded(returns_by_ticker, vols_by_ticker=None, years=None):
    years = years or YEARS
    return {
        "years": years,
        "today": None,
        "failures": {},
        "data": {
            t: {"returns": {y: returns_by_ticker[t].get(y) for y in years},
                "bars": {y: 250 for y in years},
                "volatility": {y: (vols_by_ticker or {}).get(t, {}).get(y) for y in years}}
            for t in returns_by_ticker
        },
    }


class LookAhead(unittest.TestCase):
    """The failure that would make every data-driven scheme perfect and fictional."""

    def test_inverse_volatility_reads_last_year_never_this_year(self):
        # AAA is calm in 2022 and wild in 2023; BBB is the reverse. Weighting 2023 must follow
        # 2022's volatilities, so AAA — calm LAST year — must get the larger weight in 2023.
        vols = {"AAA": {2022: 1.0, 2023: 9.0}, "BBB": {2022: 9.0, 2023: 1.0}}
        loaded = _loaded({"AAA": {}, "BBB": {}}, vols)
        w = sb.weights_inverse_volatility(["AAA", "BBB"], loaded, 2023)
        self.assertGreater(w["AAA"], w["BBB"],
                           "inverse volatility used the year it was weighting, not the prior one")

    def test_momentum_ranks_on_last_year_never_this_year(self):
        # AAA won 2022 and lost 2023. Weighting 2023 must pick AAA.
        loaded = _loaded({"AAA": {2022: 90.0, 2023: -50.0},
                          "BBB": {2022: -40.0, 2023: 80.0}})
        w = sb.weights_momentum_tilt(["AAA", "BBB"], loaded, 2023)
        self.assertEqual(w["AAA"], 1.0)
        self.assertEqual(w["BBB"], 0.0)

    def test_prior_year_inputs_is_handed_the_year_before_and_only_that(self):
        """The single chokepoint where weights meet history. Asserted directly so a future edit
        that passes `year` instead of `year - 1` fails loudly rather than producing a flawless
        backtest."""
        loaded = _loaded({"AAA": {2022: 11.0, 2023: 22.0}})
        got = sb._prior_year_inputs(loaded, ["AAA"], 2023)
        self.assertEqual(got["AAA"]["return"], 11.0)
        self.assertNotEqual(got["AAA"]["return"], 22.0)

    def test_the_first_year_has_no_prior_and_falls_back_to_equal_not_a_guess(self):
        loaded = _loaded({"AAA": {2021: 10.0}, "BBB": {2021: 20.0}}, years=[2021])
        w = sb.weights_momentum_tilt(["AAA", "BBB"], loaded, 2021)
        self.assertEqual(w, {"AAA": 1.0, "BBB": 1.0})


class MissingData(unittest.TestCase):

    def test_a_stock_with_no_data_that_year_is_excluded_not_scored_as_zero(self):
        """A company that had not listed did not return 0%. It returned nothing, and averaging a
        zero in drags the basket toward a number no investor could have experienced."""
        loaded = _loaded({"AAA": {2022: 20.0}, "BBB": {2022: None}})
        out = sb.basket_year_return(loaded, ["AAA", "BBB"], 2022, sb.weights_equal)
        self.assertEqual(out["return_pct"], 20.0)      # not 10.0
        self.assertEqual(out["holdings"], 1)
        self.assertEqual(out["missing"], ["BBB"])
        self.assertTrue(out["partial"])

    def test_a_year_nobody_could_be_scored_on_is_none_not_zero(self):
        loaded = _loaded({"AAA": {2022: None}, "BBB": {2022: None}})
        out = sb.basket_year_return(loaded, ["AAA", "BBB"], 2022, sb.weights_equal)
        self.assertIsNone(out["return_pct"])
        self.assertIn("no member", out["reason"])

    def test_a_thin_year_is_not_scored_at_all(self):
        """A company that listed in October has a 'year return' covering two months. Averaging it
        beside eleven full years would silently overweight a partial one."""
        df = pd.DataFrame({
            "ts": pd.date_range("2022-10-01", periods=40, freq="B", tz="UTC"),
            "close": [100.0 + i for i in range(40)],
        })
        d = sb._prepare(df)
        value, bars = sb._year_return(d, 2022)
        self.assertIsNone(value)
        self.assertEqual(bars, 40)
        self.assertLess(bars, sb.MIN_BARS_FOR_YEAR)

    def test_a_missing_prior_volatility_gets_the_median_not_zero_and_not_dropped(self):
        """Zero would claim infinite volatility; dropping would silently change who is in the
        basket. Neither is true — 'we don't know' is."""
        vols = {"AAA": {2022: 2.0}, "BBB": {2022: 4.0}, "CCC": {2022: None}}
        loaded = _loaded({"AAA": {}, "BBB": {}, "CCC": {}}, vols)
        w = sb.weights_inverse_volatility(["AAA", "BBB", "CCC"], loaded, 2023)
        self.assertIn("CCC", w)
        self.assertGreater(w["CCC"], 0)
        self.assertLessEqual(w["CCC"], max(w["AAA"], w["BBB"]))


class Arithmetic(unittest.TestCase):

    def test_yearly_returns_are_compounded_not_added(self):
        """Three years of +10% is +33.1%, not +30%. A page that added them would understate a
        good run and flatter a bad one, and the gap grows every year."""
        total = sb._chain([{"return_pct": 10.0}, {"return_pct": 10.0}, {"return_pct": 10.0}])
        self.assertAlmostEqual(total, 33.1, places=1)
        self.assertNotEqual(total, 30.0)

    def test_a_loss_then_an_equal_gain_does_not_get_back_to_even(self):
        """The arithmetic everyone gets wrong: -50% then +50% is -25%, not 0%."""
        self.assertAlmostEqual(sb._chain([{"return_pct": -50.0}, {"return_pct": 50.0}]),
                               -25.0, places=1)

    def test_unscoreable_years_are_skipped_not_treated_as_flat(self):
        self.assertAlmostEqual(sb._chain([{"return_pct": 10.0}, {"return_pct": None},
                                          {"return_pct": 10.0}]), 21.0, places=1)

    def test_weights_are_normalised_so_a_scheme_cannot_inflate_a_basket(self):
        """Momentum gives half the universe a weight of zero. If the divisor were the number of
        members rather than the weight actually deployed, the basket's return would be halved by
        a bookkeeping error rather than by anything that happened."""
        loaded = _loaded({"AAA": {2022: 30.0, 2021: 50.0}, "BBB": {2022: 30.0, 2021: -50.0}})
        out = sb.basket_year_return(loaded, ["AAA", "BBB"], 2022, sb.weights_momentum_tilt)
        self.assertEqual(out["return_pct"], 30.0)


class Schemes(unittest.TestCase):

    def test_equal_weight_is_the_plain_average(self):
        loaded = _loaded({"AAA": {2022: 10.0}, "BBB": {2022: 30.0}})
        out = sb.basket_year_return(loaded, ["AAA", "BBB"], 2022, sb.weights_equal)
        self.assertEqual(out["return_pct"], 20.0)

    def test_inverse_volatility_actually_tilts_the_result(self):
        """The calmer stock earns more weight, so the basket sits nearer its return."""
        vols = {"CALM": {2022: 1.0}, "WILD": {2022: 10.0}}
        loaded = _loaded({"CALM": {2023: 10.0}, "WILD": {2023: 30.0}}, vols)
        out = sb.basket_year_return(loaded, ["CALM", "WILD"], 2023, sb.weights_inverse_volatility)
        self.assertLess(out["return_pct"], 20.0)   # equal weight would be exactly 20

    def test_every_scheme_is_registered_with_a_label_and_a_description(self):
        for key, meta in sb.SCHEMES.items():
            self.assertTrue(meta["label"], key)
            self.assertTrue(meta["description"], key)
            self.assertTrue(callable(meta["fn"]), key)

    def test_the_momentum_cut_off_is_a_fixed_fraction_not_a_tuned_one(self):
        """If this ever becomes a range that gets searched, the page stops measuring anything.
        Zero-edge strategies returned +15.2% a year when the best of 100 tries was kept."""
        self.assertEqual(sb.MOMENTUM_KEEP_FRACTION, 0.5)

    def test_momentum_keeps_half_of_a_ten_stock_sector_not_all_of_it(self):
        """THE BUG THIS CAUGHT. The cut-off was a flat count of 25, so every sector basket — ten
        stocks — kept all ten, and the scheme was equal weight wearing a momentum label. A test
        against the fifty-stock universe would never have noticed."""
        members = [f"T{i}" for i in range(10)]
        loaded = _loaded({t: {2022: float(i)} for i, t in enumerate(members)})
        w = sb.weights_momentum_tilt(members, loaded, 2023)
        self.assertEqual(sum(1 for v in w.values() if v > 0), 5)
        self.assertEqual(w["T9"], 1.0)   # best last year
        self.assertEqual(w["T0"], 0.0)   # worst last year


class HonestyLabels(unittest.TestCase):

    def test_every_basket_carries_the_hindsight_warning(self):
        """Without it, 'the semis basket beat SMH by 400%' reads as skill. It is the answer being
        known before the question was asked."""
        loaded = _loaded({"AAA": {2022: 10.0}, "SMH": {2022: 5.0}})
        b = sb.build_basket(loaded, "Test", ["AAA"], "SMH")
        self.assertTrue(b["hindsight_selected"])
        self.assertIn("hindsight", b["hindsight_note"].lower())
        self.assertIn("ETF", b["hindsight_note"])

    def test_a_basket_reports_how_many_years_it_actually_beat_the_benchmark(self):
        """One huge year can carry a total. The count of years won is the harder number to
        flatter."""
        loaded = _loaded({"AAA": {2021: 50.0, 2022: -10.0, 2023: 5.0, 2024: 5.0},
                          "SMH": {2021: 10.0, 2022: 10.0, 2023: 10.0, 2024: 10.0}})
        b = sb.build_basket(loaded, "Test", ["AAA"], "SMH")
        self.assertEqual(b["years_scored"], 4)
        self.assertEqual(b["years_beaten"], 1)
        self.assertGreater(b["total_pct"], 0)

    def test_the_scheme_comparison_reports_whether_the_winner_survived_the_split(self):
        """The only question the comparison can honestly answer. If the winner changes between
        halves, the first result was noise."""
        loaded = _loaded({t: {y: 10.0 for y in YEARS} for t in ("AAA", "BBB")})
        loaded["data"]["SPY"] = {"returns": {y: 8.0 for y in YEARS},
                                 "bars": {y: 250 for y in YEARS},
                                 "volatility": {y: 1.0 for y in YEARS}}
        out = sb.compute_scheme_comparison(db=None, loaded=loaded)
        self.assertEqual(out["chosen_on"], YEARS[:2])
        self.assertEqual(out["measured_on"], YEARS[2:])
        self.assertIn("held_up", out)
        self.assertIn("hindsight", out["hindsight_note"].lower())

    def test_the_comparison_refuses_to_split_too_little_history(self):
        loaded = _loaded({"AAA": {2021: 1.0}}, years=[2021, 2022])
        out = sb.compute_scheme_comparison(db=None, loaded=loaded)
        self.assertIn("error", out)

    def test_the_verdict_names_the_risk_when_the_winner_changes(self):
        """Half the universe storms the early years then collapses; the other half is the mirror.
        Momentum chases the early winners into the late losses, so the winner must change — and
        when it does, the page has to say so in words rather than leave a table to be misread.

        Built on the REAL universe tickers, because compute_scheme_comparison weights the actual
        fifty. An earlier version of this test used made-up tickers, matched nothing, and passed
        a "not enough data" message off as a verdict.
        """
        from config import STOCK_UNIVERSE
        tickers = [s["ticker"] for s in STOCK_UNIVERSE]
        hot, cold = tickers[:len(tickers) // 2], tickers[len(tickers) // 2:]
        returns = {}
        for t in hot:
            returns[t] = {2021: 90.0, 2022: 90.0, 2023: -40.0, 2024: -40.0}
        for t in cold:
            returns[t] = {2021: 1.0, 2022: 1.0, 2023: 25.0, 2024: 25.0}
        loaded = _loaded(returns)
        loaded["data"]["SPY"] = {"returns": {y: 8.0 for y in YEARS},
                                 "bars": {y: 250 for y in YEARS},
                                 "volatility": {y: 1.0 for y in YEARS}}
        out = sb.compute_scheme_comparison(db=None, loaded=loaded)
        self.assertIsNotNone(out["best_on_chosen_years"])
        self.assertIsNotNone(out["best_on_measured_years"])
        self.assertNotIn("Not enough", out["verdict"])
        self.assertEqual(out["best_on_chosen_years"], "momentum_tilt")
        self.assertFalse(out["held_up"])
        self.assertIn("CHANGED", out["verdict"])
        self.assertIn("noise", out["verdict"].lower())


class Universe(unittest.TestCase):

    def test_the_five_sectors_each_have_a_real_benchmark_etf(self):
        """After the universe was cut to the Magnificent 7 plus four ETFs, neither remaining
        sector has a sector-benchmark ETF, and inventing one would be worse than having none.
        What must stay true is that a missing benchmark is passed through as None rather than
        quietly substituted, so a basket is never measured against the wrong thing."""
        for sector in sb._sectors():
            bench = sb.SECTOR_BENCHMARK.get(sector)
            self.assertIsNone(bench, f"{sector} unexpectedly gained a benchmark") if \
                sector not in sb.SECTOR_BENCHMARK else self.assertTrue(bench)

    def test_sector_equal_and_equal_agree_only_because_the_sectors_are_the_same_size(self):
        """This test used to prove the two weighting schemes coincided because every sector held
        the same number of stocks. After the universe was cut to the Magnificent 7 plus four ETFs
        the sectors are 7 and 4, so they must now DISAGREE — and that difference being visible is
        the whole point of having asserted it in the first place."""
        sizes = {k: len(v) for k, v in sb._sectors().items()}
        self.assertGreater(len(set(sizes.values())), 1,
                           f"sectors are the same size again ({sizes}) — re-check this test")


class PageWiring(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        import app as app_module
        frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
        cls.template = (frontend / "templates" / "yearly.html").read_text()
        cls.script = (frontend / "static" / "js" / "sector_baskets.js").read_text()
        cls.app = app_module.create_app()
        cls.client = cls.app.test_client()

    def test_every_element_the_script_writes_to_exists_in_the_template(self):
        import re
        needed = set(re.findall(r'getElementById\("([^"]+)"\)', self.script))
        present = set(re.findall(r'id="([^"]+)"', self.template))
        self.assertEqual(needed - present, set())

    def test_the_script_is_loaded_by_the_page(self):
        self.assertIn("js/sector_baskets.js", self.template)

    def test_the_endpoint_is_registered(self):
        rules = {str(r) for r in self.app.url_map.iter_rules()}
        self.assertIn("/api/stocks/sector-baskets", rules)

    def test_the_hindsight_warning_is_on_the_page_itself_not_only_in_the_data(self):
        """A caveat that lives only in a JSON field is a caveat nobody reads. It has to be above
        the numbers, in the markup, where the layout cannot push it off-screen."""
        html = self.client.get("/yearly").data.decode()
        self.assertIn("chosen in 2026", html)
        self.assertIn("years beaten", html.lower())

    def test_the_page_states_that_no_weighting_search_happens(self):
        html = self.client.get("/yearly").data.decode().lower()
        self.assertIn("no search", html)
        self.assertIn("+15.2%", html)

    def test_every_scheme_in_the_dropdown_exists_in_the_service(self):
        """A dropdown option with no scheme behind it would 500 the endpoint on selection."""
        import re
        options = set(re.findall(r'<option value="([a-z_]+)"', self.template))
        self.assertTrue(options)
        for opt in options:
            self.assertIn(opt, sb.SCHEMES)

    def test_years_beaten_is_rendered_and_not_just_the_totals(self):
        """One enormous year can carry a total. Years-beaten is the number that is hard to
        flatter, so it must actually appear."""
        self.assertIn("years_beaten", self.script)
        self.assertIn("years_scored", self.script)


class DoesNotAutoLoad(unittest.TestCase):
    """The Yearly page must not fire two whole-universe walks at once.

    THE BUG THIS PREVENTS, AND IT SHIPPED. sector_baskets.js called loadSectorBaskets() on page
    load, which fired /api/stocks/sector-baskets at the same moment yearly.js fired
    /api/stocks/yearly-combined. Both walk six years of daily bars for fifty-odd symbols, on one
    worker with a fraction of a CPU.

    yearly_service.compute_yearly_combined exists BECAUSE of this exact failure and its docstring
    describes the symptom precisely: "the second request queued behind the first and neither
    finished for minutes. From the browser it was indistinguishable from the site being down: a
    spinner, and no logged request, because gunicorn only logs a request once it completes."

    The server logs confirmed it: /yearly returned 200, every static file returned 200, and there
    was no log line for either heavy endpoint — because neither had finished.
    """

    @classmethod
    def setUpClass(cls):
        frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
        cls.script = (frontend / "static" / "js" / "sector_baskets.js").read_text()
        cls.template = (frontend / "templates" / "yearly.html").read_text()
        cls.yearly_js = (frontend / "static" / "js" / "yearly.js").read_text()

    def test_the_script_does_not_call_the_loader_at_top_level(self):
        """A bare `loadSectorBaskets();` at module scope is the whole bug in one line."""
        for line in self.script.split("\n"):
            stripped = line.strip()
            if stripped.startswith("//"):
                continue
            self.assertNotEqual(stripped, "loadSectorBaskets();",
                                "sector baskets load automatically again")

    def test_there_is_an_explicit_build_control(self):
        self.assertIn('id="sb-build"', self.template)
        self.assertIn('getElementById("sb-build")', self.script)

    def test_the_page_explains_why_it_is_not_automatic(self):
        """A blank panel with a button and no reason reads as broken."""
        self.assertIn("not run automatically", self.template)

    def test_changing_the_weighting_does_not_trigger_the_first_load(self):
        """Otherwise picking from the dropdown quietly fires the very request being deferred."""
        self.assertIn("basketsBuilt", self.script)
        block = self.script[self.script.index('schemeSelect.addEventListener'):]
        self.assertIn("if (basketsBuilt)", block)

    def test_only_one_whole_universe_endpoint_is_called_on_page_load(self):
        """The structural guard. Counts the heavy endpoints reachable without a user action."""
        heavy = ["/api/stocks/yearly-combined", "/api/stocks/sector-baskets"]
        auto = [h for h in heavy if h in self.yearly_js]
        self.assertEqual(auto, ["/api/stocks/yearly-combined"],
                         f"more than one heavy endpoint loads automatically: {auto}")
