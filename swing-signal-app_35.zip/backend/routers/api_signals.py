from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services.signal_v2_service import STRATEGY_VERSION as V2_VERSION
from services.signal_v2_service import compute_all_v2, compute_v2_for_ticker
from services.signals_service import TICKERS, compute_all_signals, compute_signal_for_ticker

bp = Blueprint("api_signals", __name__, url_prefix="/api/signals")


@bp.get("")
def all_signals():
    """The Phase 3 100-point signal for all 15 tracked stocks, ranked best-score-first.
    Powers the Signals page and the dashboard's Score/Signal column."""
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured", "results": [],
        }), 200

    timeframe = request.args.get("timeframe", "1Day")
    db = get_db()
    signals = compute_all_signals(db, timeframe=timeframe)
    return jsonify({"data_source": "alpaca", "timeframe": timeframe, "results": signals})


@bp.get("/<ticker>")
def stock_signal(ticker):
    """Single-stock signal with the full component-score breakdown — powers the stock detail
    page's 'WHY THIS SCORE?' panel."""
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked 15-stock universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({
            "ticker": ticker, "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured",
        }), 200

    timeframe = request.args.get("timeframe", "1Day")
    db = get_db()
    signal = compute_signal_for_ticker(db, ticker, timeframe=timeframe)
    return jsonify(signal)


@bp.get("/v2")
def all_signals_v2():
    """Signal v2 for all 15 stocks: two scores, three gates, what changed, and sell triggers.

    Ranked by HOLD quality, not by a blended number. The page's job is "am I still happy owning
    these, and has anything changed" — entry quality is a separate column because it answers a
    separate question.
    """
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured", "results": [],
        }), 200

    timeframe = request.args.get("timeframe", "1Day")
    db = get_db()
    results = compute_all_v2(db, timeframe=timeframe)
    material = [r for r in results if (r.get("changes") or {}).get("material")]
    selling = [r for r in results if (r.get("sell") or {}).get("any")]
    return jsonify({
        "data_source": "alpaca", "timeframe": timeframe,
        "strategy_version": V2_VERSION,
        "results": results,
        "summary": {
            "buy": sum(1 for r in results if r.get("action") == "BUY"),
            "good_stock_poor_entry": sum(1 for r in results
                                         if r.get("action") == "GOOD STOCK, POOR ENTRY"),
            "watch": sum(1 for r in results if r.get("action") == "WATCH"),
            "avoid": sum(1 for r in results if r.get("action") == "AVOID"),
            "unavailable": sum(1 for r in results if r.get("action") == "UNAVAILABLE"),
            "material_changes": len(material),
            "sell_triggers": len(selling),
        },
    })


@bp.get("/v2/<ticker>")
def stock_signal_v2(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked 15-stock universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({"ticker": ticker, "data_status": "UNAVAILABLE",
                        "error": "Alpaca API credentials not configured"}), 200
    db = get_db()
    return jsonify(compute_v2_for_ticker(db, ticker,
                                         timeframe=request.args.get("timeframe", "1Day")))
