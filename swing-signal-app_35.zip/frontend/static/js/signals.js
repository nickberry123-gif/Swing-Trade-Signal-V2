// Signals page — strategy v2.0.
//
// Two scores, three gates, and a change log. The order on the page is deliberate: CHANGES first,
// then sell triggers, then the ranked list. A level-based table answers "what is it now"; the
// stated reason this page exists is not missing a change on something already owned, and that is
// a question about what MOVED.
//
// UNKNOWN is never rendered as a zero or a pass anywhere below.

const STOCKS_BY_TICKER = {};
(window.STOCK_UNIVERSE || []).forEach((s) => { STOCKS_BY_TICKER[s.ticker] = s; });

const ACTION_CLASS = {
  "BUY": "num-pos",
  "GOOD STOCK, POOR ENTRY": "",
  "WATCH": "",
  "AVOID": "num-neg",
  "UNAVAILABLE": "text-dim",
};

function scoreClass(score) {
  if (score === null || score === undefined) return "text-dim";
  if (score >= 75) return "num-pos";
  if (score >= 55) return "";
  return "num-neg";
}

function scoreBlock(label, score, band, unknownList, availableWeight) {
  const unknown = (unknownList || []).length;
  const outOf = availableWeight === undefined || availableWeight === null ? "" :
    `<div class="score-max">${unknown ? `${availableWeight} of 100 pts measurable` : "all 100 pts measurable"}</div>`;
  return `<div class="level-box">
    <div class="lk">${label}</div>
    <div class="lv ${scoreClass(score)}" style="font-size:20px;">${score === null || score === undefined ? "—" : fmtNum(score, 1)}</div>
    <div class="yc-sub text-dim">${band || ""}</div>
    ${outOf}
  </div>`;
}

function gateList(gates) {
  const checks = (gates || {}).checks || [];
  return checks.map((c) => `<div style="font-size:11.5px;" class="${c.passed ? "num-pos" : "num-neg"}">
      ${c.passed ? "PASS" : "BLOCKED"} — ${c.gate}
      <span class="text-dim">(${c.detail})</span>
    </div>`).join("");
}

function componentRows(block) {
  const comps = (block || {}).components || {};
  const rows = Object.keys(comps).map((k) => {
    const c = comps[k];
    return `<div style="font-size:11px;" class="text-dim">${k.replace(/_/g, " ")}
      — ${fmtNum(c.points, 1)} of ${c.weight}</div>`;
  });
  (block.unknown || []).forEach((k) => {
    rows.push(`<div style="font-size:11px;" class="text-dim">${k.replace(/_/g, " ")}
      — <strong>UNKNOWN</strong>, weight removed from the total</div>`);
  });
  return rows.join("");
}

function levelBox(label, value) {
  return `<div class="level-box"><div class="lk">${label}</div><div class="lv">${fmtPrice(value)}</div></div>`;
}

function renderCard(r, rank) {
  const stock = STOCKS_BY_TICKER[r.ticker] || {};
  if (r.data_status !== "OK") {
    return `<div class="signal-card" onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'">
      <div class="signal-card-header">
        <div><div class="rank">#${rank}</div><div class="ticker">${r.ticker}</div>
             <div class="company">${stock.name || ""}</div></div>
        <div class="score-box">${statusPillHtml("UNAVAILABLE")}</div>
      </div>
      <div class="footer-note" style="margin-top:10px; padding-top:0; border-top:none;">${r.reason || "No data for this stock right now."}</div>
    </div>`;
  }

  const levels = r.levels || {};
  const rr = r.risk_reward || {};
  const changes = (r.changes || {}).changes || [];
  const sells = (r.sell || {}).fired || [];

  return `<div class="signal-card" onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'">
    <div class="signal-card-header">
      <div><div class="rank">#${rank}</div><div class="ticker">${r.ticker}</div>
           <div class="company">${stock.name || ""}</div></div>
      <div class="score-box">
        <div class="score-value ${ACTION_CLASS[r.action] || ""}" style="font-size:15px;">${r.action}</div>
      </div>
    </div>

    <div class="thesis-line" style="margin-top:6px;">${r.reason || ""}</div>

    <div class="levels-grid" style="margin-top:8px;">
      ${scoreBlock("Hold Quality", r.hold_quality, r.hold_band, (r.hold || {}).unknown, (r.hold || {}).weight_available)}
      ${scoreBlock("Entry Quality", r.entry_quality, r.entry_band, (r.entry || {}).unknown, (r.entry || {}).weight_available)}
    </div>

    <div style="margin-top:8px;">${gateList(r.gatekeepers)}</div>

    ${sells.length ? `<div class="warn-banner" style="margin-top:8px;">
        SELL TRIGGER — ${sells.map((s) => `${s.trigger}: ${s.detail}`).join("; ")}</div>` : ""}

    ${(r.earnings || {}).status === "BLACKOUT" ? `<div class="warn-banner" style="margin-top:8px;">
        EARNINGS BLACKOUT — ${r.earnings.detail}</div>` : ""}

    ${changes.length ? `<div style="margin-top:8px;">${changes.map((c) =>
        `<div style="font-size:11.5px;" class="${c.severity === "HIGH" ? "num-neg" : "text-dim"}">
           ${c.severity === "HIGH" ? "!" : "·"} ${c.change} — ${c.detail}</div>`).join("")}</div>`
      : `<div style="font-size:11px;margin-top:8px;" class="text-dim">${(r.changes || {}).first_reading
          ? "First reading — changes appear from the next refresh onward."
          : "No material change since the last reading."}</div>`}

    <div class="levels-grid" style="margin-top:8px;">
      ${levelBox("Price", (r.state || {}).price)}
      ${levelBox("Buy Zone Low", levels.buy_zone_low)}
      ${levelBox("Buy Zone High", levels.buy_zone_high)}
      ${levelBox("Primary Target", levels.primary_target)}
    </div>

    <div class="footer-note" style="margin-top:8px;">
      Room above vs below: ${rr.ratio === null || rr.ratio === undefined ? "not measurable" : fmtNum(rr.ratio, 2) + " : 1"}
      <span class="text-dim">— ${rr.note || ""}</span><br>
      <span class="text-dim">${(r.notes || {}).volatility || ""}</span><br>
      <span class="text-dim">${(r.notes || {}).financial_quality || ""}</span>
    </div>

    <details style="margin-top:8px;">
      <summary style="font-size:11.5px;cursor:pointer;">Component breakdown</summary>
      <div style="margin-top:6px;"><strong style="font-size:11px;">HOLD</strong>${componentRows(r.hold || {})}</div>
      <div style="margin-top:6px;"><strong style="font-size:11px;">ENTRY</strong>${componentRows(r.entry || {})}</div>
    </details>
  </div>`;
}

function renderChanges(results) {
  const box = document.getElementById("v2-changes");
  const withChanges = results.filter((r) => ((r.changes || {}).changes || []).length);
  if (!withChanges.length) {
    const anyFirst = results.some((r) => (r.changes || {}).first_reading);
    box.innerHTML = `<div class="card card-pad text-dim">${anyFirst
      ? "No previous reading stored yet. Changes are reported from the next refresh onward — this is the first snapshot."
      : "Nothing moved materially since the last reading."}</div>`;
    return;
  }
  box.innerHTML = `<table class="data-table"><thead><tr>
      <th>Stock</th><th>What changed</th><th>Detail</th><th>Severity</th>
    </tr></thead><tbody>` +
    withChanges.flatMap((r) => (r.changes.changes || []).map((c) => `<tr>
      <td><span class="ticker-badge">${r.ticker}</span></td>
      <td style="font-size:11.5px;">${c.change}</td>
      <td style="font-size:11.5px;" class="text-dim">${c.detail}</td>
      <td class="${c.severity === "HIGH" ? "num-neg" : "text-dim"}" style="font-size:11.5px;">${c.severity}</td>
    </tr>`)).join("") + `</tbody></table>`;
}

function renderSells(results) {
  const box = document.getElementById("v2-sells");
  const firing = results.filter((r) => (r.sell || {}).any);
  if (!firing.length) {
    box.innerHTML = `<div class="card card-pad text-dim">No sell trigger is firing on any of the 15.</div>`;
    return;
  }
  box.innerHTML = firing.map((r) => `<div class="warn-banner">
    <strong>${r.ticker}</strong> — ${r.sell.fired.map((s) => `${s.trigger}: ${s.detail}`).join("; ")}
  </div>`).join("");
}

function renderSummary(summary) {
  const box = document.getElementById("v2-summary");
  const t = (label, value, sub, cls) => `<div class="stat-tile">
    <div class="st-label">${label}</div><div class="st-value ${cls || ""}">${value}</div>
    ${sub ? `<div class="st-sub">${sub}</div>` : ""}</div>`;
  box.innerHTML = [
    t("Buy", summary.buy ?? 0, "passed all three gates", "num-pos"),
    t("Good stock, poor entry", summary.good_stock_poor_entry ?? 0, "worth owning, not today"),
    t("Watch", summary.watch ?? 0, "blocked by a gate"),
    t("Avoid", summary.avoid ?? 0, null, "num-neg"),
    t("Material changes", summary.material_changes ?? 0, "since the last reading",
      (summary.material_changes ? "num-neg" : "")),
    t("Sell triggers firing", summary.sell_triggers ?? 0, null, (summary.sell_triggers ? "num-neg" : "")),
  ].join("");
}

async function refreshSignals() {
  const grid = document.getElementById("signals-grid");
  const errBox = document.getElementById("signals-error");
  if (!grid) return;
  try {
    const data = await apiGet("/api/signals/v2");
    errBox.innerHTML = data.error ? `<div class="warn-banner">SIGNALS UNAVAILABLE — ${data.error}</div>` : "";
    const results = data.results || [];
    if (!results.length) {
      grid.innerHTML = `<div class="card card-pad text-dim">No signals available.</div>`;
      return;
    }
    renderChanges(results);
    renderSells(results);
    renderSummary(data.summary || {});
    grid.innerHTML = results.map((r, i) => renderCard(r, i + 1)).join("");
    const refreshedEl = document.getElementById("signals-last-refreshed");
    if (refreshedEl) refreshedEl.textContent = "last refreshed " + new Date().toLocaleTimeString();
  } catch (e) {
    grid.innerHTML = "";
    errBox.innerHTML = `<div class="error-banner">SIGNALS ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

// Each refresh recomputes all 15 from cached bars — cheap, but not free, and the numbers move on
// daily bars. Five minutes is current enough. (Storing a new snapshot is throttled separately in
// the service by MIN_SNAPSHOT_GAP_HOURS, so refreshing does not erase the change detector's
// memory of what the last session looked like.)
startPolling(refreshSignals, 300000);
