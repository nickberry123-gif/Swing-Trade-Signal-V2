"""
Build B2 — the data-validation run and its results.

THE FAILURE THIS FILE WAS REWRITTEN AROUND. The first whole-universe run stopped at ticker
fifteen and never moved again: no error, no crash, no log line. The download for one company
never ended, and because the result only existed in memory until all fifty finished, forty-nine
companies' worth of completed work was thrown away.

Three separate things had to be true for that to happen, and all three are now false:

  1. The SEC request had no total time limit (fixed in the provider — a streamed read with a
     wall-clock deadline, bounded inside the calling thread, so nothing is ever left running).
  2. One ticker could block the other forty-nine (fixed here — every ticker is isolated and its
     result is written the moment it finishes).
  3. A stopped run had to be started again from zero (fixed here — runs resume).

NOT USED, DELIBERATELY: a watchdog thread that abandons a blocked call. Abandoning a blocked
thread does not stop it. The socket stays open, the memory stays held, and a run that "recovered"
fifty times is a process with fifty orphaned downloads still going. The bound belongs inside the
request, which is where it now is.

CONNECTION DISCIPLINE, unchanged and still load-bearing: each ticker is one short cycle — fetch
from SEC with NO database connection held, then open a connection, write, validate, close. Neon
closes idle connections after a few minutes.
"""
import json
import logging
import threading
import time

from flask import Blueprint, current_app, jsonify, request

from db import get_db
from providers.base import ProviderError
from services import data_validation_service as dv
from services import fundamentals_history_service as fh
from services.fundamentals_service import get_fundamentals_provider
from services.job_runner import (mark_complete, mark_failed, reap_stale_runs, short_lived_db,
                                 write_progress)
from services.signals_service import TICKERS

logger = logging.getLogger(__name__)
bp = Blueprint("api_validation", __name__, url_prefix="/api/data-validation")

TABLE = "data_validation_runs"
TICKER_TABLE = "data_validation_ticker_results"

# SEC asks for no more than 10 requests a second. One ticker needs one companyfacts call, and each
# takes far longer than a tenth of a second anyway — this pause makes the limit hold by
# construction rather than by luck.
SEC_PAUSE_SECONDS = 0.3

# How many times a ticker is retried WITHIN a run, on top of the provider's own transport-level
# retries. Deliberately small: a company that fails three separate fetches is telling us
# something, and hammering it is neither polite nor informative.
MAX_TICKER_ATTEMPTS = 2


def _last_close(db, ticker: str):
    """The most recent stored daily close.

    Read from bars already in the database rather than fetched from Alpaca: one row instead of a
    round trip per ticker, it works when the market is closed, and it keeps this diagnostic
    independent of whether the price provider is reachable. It is the last stored close, and the
    page says so — it is not presented as a live price.
    """
    row = db.execute(
        "SELECT close, ts FROM market_bars WHERE ticker = ? AND timeframe = '1Day' "
        "ORDER BY ts DESC LIMIT 1", (ticker,)).fetchone()
    if row is None:
        return None, None
    d = dict(row)
    return d.get("close"), d.get("ts")


def _save_ticker(run_id: int, ticker: str, status: str, error, attempts: int, seconds: float,
                 result) -> None:
    """Persist one ticker's outcome immediately, on its own connection.

    Best-effort by design: failing to record one company's result must not end a run that is
    otherwise working. It will simply be retried on resume, which is the correct fallback.
    """
    try:
        with short_lived_db() as db:
            db.execute(
                f"""
                INSERT INTO {TICKER_TABLE} (run_id, ticker, status, error, attempts, seconds,
                                            result_json, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
                ON CONFLICT(run_id, ticker) DO UPDATE SET
                    status=excluded.status, error=excluded.error, attempts=excluded.attempts,
                    seconds=excluded.seconds, result_json=excluded.result_json,
                    updated_at=excluded.updated_at
                """,
                (run_id, ticker, status, (str(error)[:1000] if error else None), attempts,
                 round(seconds, 2), json.dumps(result) if result is not None else None))
            db.commit()
    except Exception:  # noqa: BLE001
        logger.warning("Could not record %s for run %s", ticker, run_id, exc_info=True)


def _completed_tickers(db, run_id: int) -> set:
    rows = db.execute(
        f"SELECT ticker FROM {TICKER_TABLE} WHERE run_id = ? AND status = 'complete'",
        (run_id,)).fetchall()
    return {dict(r)["ticker"] for r in rows}


def _collect(db, run_id: int) -> dict:
    rows = db.execute(
        f"SELECT ticker, status, error, attempts, seconds, result_json FROM {TICKER_TABLE} "
        f"WHERE run_id = ? ORDER BY ticker", (run_id,)).fetchall()
    results, failures = [], []
    for row in rows:
        d = dict(row)
        if d["status"] == "complete" and d.get("result_json"):
            try:
                results.append(json.loads(d["result_json"]))
                continue
            except (TypeError, ValueError):
                d["error"] = "stored result could not be read back"
        failures.append({"ticker": d["ticker"], "error": d.get("error"),
                         "attempts": d.get("attempts"), "seconds": d.get("seconds")})
    return {
        "summary": dv.summarise(results),
        "results": results,
        "failures": failures,
        "price_source": "last stored daily close from market_bars — not a live quote, and not "
                        "fetched from Alpaca for this run",
    }


def _process_one(provider, run_id: int, ticker: str, refresh: bool) -> bool:
    """One ticker, start to finish, isolated. Returns True when it completed.

    Every failure mode ends the same way: recorded against this ticker and the loop moves on.
    Nothing raised here can reach the run loop, because a run that dies on company seventeen is
    the bug this whole rewrite exists to remove.
    """
    started = time.monotonic()
    last_error = None

    for attempt in range(1, MAX_TICKER_ATTEMPTS + 1):
        records, share_records, fetch_error = None, None, None
        if refresh:
            # ---- SEC fetch, with NO database connection held ----
            # One companyfacts download serves both: the annual history and every cover-page
            # share count. Parsing it twice costs nothing and downloading it twice would double
            # the run's time and SEC traffic for no reason.
            try:
                records, share_records = provider.get_history_and_share_counts(ticker)
            except ProviderError as e:
                fetch_error = str(e)
            except Exception as e:  # noqa: BLE001 — one bad ticker must never end the run
                fetch_error = f"Unexpected error reading SEC data: {e}"
            time.sleep(SEC_PAUSE_SECONDS)

        try:
            # ---- short database cycle: store, price, validate ----
            with short_lived_db() as db:
                if records:
                    fh.store_history(db, ticker, records)
                price, price_ts = _last_close(db, ticker)
                result = dv.validate_ticker(db, ticker, price=price)
            result["price_as_of"] = price_ts
            result["attempts"] = attempt

            if fetch_error:
                if result.get("periods"):
                    # Stored filings are still valid — a filing does not expire — so this is a
                    # completed ticker with a warning, not a failure.
                    result["notes"].append(
                        f"SEC refresh failed ({fetch_error}). The figures below come from filings "
                        f"stored earlier, which remain valid, but nothing new was added.")
                else:
                    last_error = fetch_error
                    if attempt < MAX_TICKER_ATTEMPTS:
                        continue
                    _save_ticker(run_id, ticker, "failed", fetch_error, attempt,
                                 time.monotonic() - started, None)
                    return False

            _save_ticker(run_id, ticker, "complete", None, attempt,
                         time.monotonic() - started, result)
            return True
        except Exception as e:  # noqa: BLE001
            logger.exception("Validation failed for %s", ticker)
            last_error = str(e)
            if attempt >= MAX_TICKER_ATTEMPTS:
                break

    _save_ticker(run_id, ticker, "failed", last_error, MAX_TICKER_ATTEMPTS,
                 time.monotonic() - started, None)
    return False


def _run_in_background(app, run_id: int, tickers: list, refresh: bool):
    with app.app_context():
        try:
            provider = get_fundamentals_provider()
            with short_lived_db() as db:
                already = _completed_tickers(db, run_id)
            todo = [t for t in tickers if t not in already]
            if already:
                write_progress(TABLE, run_id,
                               f"Resuming — {len(already)} already done, {len(todo)} to go")

            done, failed = len(already), 0
            for i, ticker in enumerate(todo, start=1):
                write_progress(TABLE, run_id,
                               f"{done + i} of {len(tickers)} — {ticker}"
                               + (f" ({failed} failed so far)" if failed else ""))
                if not _process_one(provider, run_id, ticker, refresh):
                    failed += 1

            with short_lived_db() as db:
                payload = _collect(db, run_id)
            payload["refreshed_from_sec"] = refresh
            mark_complete(TABLE, run_id, payload)
        except Exception as e:  # noqa: BLE001
            logger.exception("Data validation run %s failed", run_id)
            mark_failed(TABLE, run_id, str(e))


def _start(run_id: int, tickers: list, refresh: bool):
    threading.Thread(
        target=_run_in_background,
        args=(current_app._get_current_object(), run_id, tickers, refresh),
        daemon=True).start()


@bp.post("/runs")
def start_run():
    body = request.get_json(silent=True) or {}
    requested = [t.strip().upper() for t in (body.get("tickers") or []) if t.strip()]
    tickers = [t for t in requested if t in TICKERS] or sorted(TICKERS)
    refresh = bool(body.get("refresh", True))

    db = get_db()
    reap_stale_runs(db, TABLE)
    db.execute(
        "INSERT INTO data_validation_runs (config_json, status, progress) VALUES (?, 'running', ?)",
        (json.dumps({"tickers": tickers, "refresh": refresh}), "Starting…"))
    db.commit()
    run_id = int(dict(db.execute("SELECT MAX(id) AS id FROM data_validation_runs").fetchone())["id"])

    _start(run_id, tickers, refresh)
    return jsonify({"run_id": run_id, "tickers": len(tickers), "refresh": refresh,
                    "note": "Fetching fifty filings from SEC takes several minutes. Each company "
                            "is saved as it finishes, so a failure costs one company and the run "
                            "can be resumed."}), 202


@bp.post("/runs/<int:run_id>/resume")
def resume_run(run_id):
    """Continue a run from the tickers it has already completed.

    The point of resuming rather than restarting: after a stoppage the completed companies are
    already stored and re-downloading them wastes minutes, SEC's goodwill and Neon's transfer
    allowance to arrive at figures that cannot have changed.
    """
    db = get_db()
    row = db.execute("SELECT id, config_json FROM data_validation_runs WHERE id = ?",
                     (run_id,)).fetchone()
    if row is None:
        return jsonify({"error": f"No data-validation run with id {run_id}"}), 404
    try:
        config = json.loads(dict(row).get("config_json") or "{}")
    except (TypeError, ValueError):
        config = {}
    tickers = config.get("tickers") or sorted(TICKERS)
    remaining = [t for t in tickers if t not in _completed_tickers(db, run_id)]

    db.execute("UPDATE data_validation_runs SET status='running', error=NULL, progress=? "
               "WHERE id = ?", (f"Resuming — {len(remaining)} to go", run_id))
    db.commit()
    _start(run_id, tickers, bool(config.get("refresh", True)))
    return jsonify({"run_id": run_id, "remaining": len(remaining),
                    "already_complete": len(tickers) - len(remaining)}), 202


def _results(db, run_id):
    row = db.execute("SELECT results_json FROM data_validation_runs WHERE id = ?",
                     (run_id,)).fetchone()
    if row is None:
        return None
    try:
        stored = json.loads(dict(row).get("results_json") or "null")
    except (TypeError, ValueError):
        stored = None
    # A run that stopped mid-way has no assembled payload, but its completed tickers are all in
    # the per-ticker table — so a partial answer is available immediately rather than after a
    # full re-run.
    return stored if stored else _collect(db, run_id)


# THREE NARROW READS OF ONE WIDE RESULT.
#
# The full payload is fifty companies times roughly thirty metrics, each with a verdict and a
# sentence of reasoning — large enough that the interesting part sits past where a reader may
# stop. That is not theoretical: the first attempt to read a run came back with the ticker COUNT
# rendered as a ticker LIST, a kroner-reporting company missing from the non-USD list, and a
# verdict string this code cannot produce. Every number in it looked reasonable.
@bp.get("/runs/<int:run_id>/summary")
def get_run_summary(run_id):
    payload = _results(get_db(), run_id)
    if payload is None:
        return jsonify({"error": f"No data-validation run with id {run_id}"}), 404
    return jsonify(payload.get("summary") or {})


@bp.get("/runs/<int:run_id>/flags")
def get_run_flags(run_id):
    """Only the companies that produced a figure which could not be true, plus anomaly warnings.

    An implausible metric is a bug; an anomaly is a figure worth a second look. They are reported
    together here and kept distinct, because treating a warning as a rejection is how real data
    gets thrown away.
    """
    payload = _results(get_db(), run_id)
    if payload is None:
        return jsonify({"error": f"No data-validation run with id {run_id}"}), 404
    flagged, anomalies = [], []
    for r in payload.get("results") or []:
        for name in r.get("implausible") or []:
            metric = (r.get("metrics") or {}).get(name) or {}
            flagged.append({"ticker": r.get("ticker"), "metric": name,
                            "value": metric.get("value"), "reason": metric.get("reason"),
                            "currency": r.get("currency"), "price": r.get("price")})
        for a in r.get("anomalies") or []:
            anomalies.append({"ticker": r.get("ticker"), **a})
    return jsonify({"run_id": run_id, "impossible": len(flagged), "flagged": flagged,
                    "anomaly_warnings": len(anomalies), "anomalies": anomalies,
                    "failures": payload.get("failures") or []})


@bp.get("/runs/<int:run_id>/table")
def get_run_table(run_id):
    """One short line per company — enough to see the shape of the universe, small enough to
    survive being read whole."""
    payload = _results(get_db(), run_id)
    if payload is None:
        return jsonify({"error": f"No data-validation run with id {run_id}"}), 404
    rows = []
    for r in payload.get("results") or []:
        cap = ((r.get("metrics") or {}).get("market_cap") or {}).get("value")
        rows.append({
            "t": r.get("ticker"), "yrs": r.get("periods"), "cur": r.get("currency"),
            "health": r.get("company_health_coverage_pct"),
            "gate": bool(r.get("clears_75pct_gate")),
            "val": r.get("valuation_coverage_pct"),
            "cap_bn": round(cap / 1e9, 1) if cap else None,
            "opinc": r.get("operating_income_basis"),
            "bad": len(r.get("implausible") or []),
            "warn": len(r.get("anomalies") or []),
        })
    rows.sort(key=lambda x: (x["health"] or 0))
    return jsonify({"run_id": run_id, "count": len(rows), "rows": rows,
                    "failures": payload.get("failures") or []})


@bp.get("/runs")
def list_runs():
    db = get_db()
    reap_stale_runs(db, TABLE)
    rows = db.execute(
        "SELECT id, created_at, status, error, progress FROM data_validation_runs "
        "ORDER BY id DESC LIMIT 20").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        counts = db.execute(
            f"SELECT status, COUNT(*) AS n FROM {TICKER_TABLE} WHERE run_id = ? GROUP BY status",
            (d["id"],)).fetchall()
        tally = {dict(c)["status"]: int(dict(c)["n"]) for c in counts}
        d["completed"] = tally.get("complete", 0)
        d["failed"] = tally.get("failed", 0)
        out.append(d)
    return jsonify({"runs": out})


@bp.get("/runs/<int:run_id>")
def get_run(run_id):
    db = get_db()
    reap_stale_runs(db, TABLE)
    row = db.execute(
        "SELECT id, created_at, status, error, progress, config_json "
        "FROM data_validation_runs WHERE id = ?", (run_id,)).fetchone()
    if row is None:
        return jsonify({"error": f"No data-validation run with id {run_id}"}), 404
    d = dict(row)
    try:
        d["config"] = json.loads(d.pop("config_json") or "null")
    except (TypeError, ValueError):
        d.pop("config_json", None)
        d["config"] = None
    d["results"] = _results(db, run_id)
    counts = db.execute(
        f"SELECT status, COUNT(*) AS n FROM {TICKER_TABLE} WHERE run_id = ? GROUP BY status",
        (run_id,)).fetchall()
    tally = {dict(c)["status"]: int(dict(c)["n"]) for c in counts}
    d["completed"] = tally.get("complete", 0)
    d["failed"] = tally.get("failed", 0)
    return jsonify(d)
