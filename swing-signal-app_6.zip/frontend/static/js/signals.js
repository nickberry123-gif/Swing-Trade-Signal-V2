const STOCKS_BY_TICKER = {};
(window.STOCK_UNIVERSE || []).forEach((s) => { STOCKS_BY_TICKER[s.ticker] = s; });

function levelBox(label, value) {
  return `<div class="level-box"><div class="lk">${label}</div><div class="lv">${fmtPrice(value)}</div></div>`;
}

function renderSignalCard(sig, rank) {
  const stock = STOCKS_BY_TICKER[sig.ticker] || {};
  const noData = sig.signal_label === "NO DATA" || sig.score_total === null || sig.score_total === undefined;

  if (noData) {
    return `
      <div class="signal-card" onclick="window.location.href='/stocks/${encodeURIComponent(sig.ticker)}'">
        <div class="signal-card-header">
          <div>
            <div class="rank">#${rank}</div>
            <div class="ticker">${sig.ticker}</div>
            <div class="company">${stock.name || ""}</div>
          </div>
          <div class="score-box">${statusPillHtml("UNAVAILABLE")}</div>
        </div>
        <div class="footer-note" style="margin-top:10px; padding-top:0; border-top:none;">${sig.data_error || "No data available for this stock right now."}</div>
      </div>
    `;
  }

  const scoreMax = sig.score_max_currently_available || 90;
  const setup = sig.strategy_setup && sig.strategy_setup !== "NONE" ? `<span class="setup-badge">${sig.strategy_setup.replace("_", " ")}</span>` : "";

  return `
    <div class="signal-card" onclick="window.location.href='/stocks/${encodeURIComponent(sig.ticker)}'">
      <div class="signal-card-header">
        <div>
          <div class="rank">#${rank}</div>
          <div class="ticker">${sig.ticker}</div>
          <div class="company">${stock.name || ""}</div>
        </div>
        <div class="score-box">
          <div class="score-value ${signalScoreClass(sig.signal_label)}">${fmtNum(sig.score_total, 1)}</div>
          <div class="score-max">/ ${scoreMax} pts</div>
        </div>
      </div>
      ${signalPillHtml(sig.signal_label)} ${setup}
      <div class="levels-grid">
        ${levelBox("Current Price", sig.current_price)}
        ${levelBox("Ideal Buy", sig.ideal_buy)}
        ${levelBox("Buy Zone Low", sig.buy_zone_low)}
        ${levelBox("Buy Zone High", sig.buy_zone_high)}
        ${levelBox("Max Entry", sig.max_entry)}
        ${levelBox("Target 1", sig.target1)}
        ${levelBox("Primary Target", sig.primary_target)}
        ${levelBox("Target 3", sig.target3)}
      </div>
      <div class="thesis-line">
        Expected upside to primary target: <span class="${pctClass(sig.expected_upside_pct)}">${fmtPct(sig.expected_upside_pct, 1)}</span><br>
        Long-term thesis: ${sig.long_term_thesis || "—"}
      </div>
    </div>
  `;
}

async function refreshSignals() {
  const grid = document.getElementById("signals-grid");
  const errBox = document.getElementById("signals-error");
  if (!grid) return;
  try {
    const data = await apiGet("/api/signals");
    if (data.error) {
      errBox.innerHTML = `<div class="warn-banner">SIGNALS UNAVAILABLE — ${data.error}</div>`;
    } else {
      errBox.innerHTML = "";
    }
    const results = data.results || [];
    if (results.length === 0) {
      grid.innerHTML = `<div class="card card-pad text-dim">No signals available.</div>`;
      return;
    }
    grid.innerHTML = results.map((sig, i) => renderSignalCard(sig, i + 1)).join("");
    const refreshedEl = document.getElementById("signals-last-refreshed");
    if (refreshedEl) refreshedEl.textContent = "last refreshed " + new Date().toLocaleTimeString();
  } catch (e) {
    grid.innerHTML = "";
    errBox.innerHTML = `<div class="error-banner">SIGNALS ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

refreshSignals();
setInterval(refreshSignals, 30000);
