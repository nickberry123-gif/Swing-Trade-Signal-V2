function renderStocksTable(results, indicatorsByTicker, signalsByTicker) {
  const tbody = document.getElementById("stocks-tbody");
  if (!tbody) return;
  if (!results || results.length === 0) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="10">No data.</td></tr>`;
    return;
  }
  indicatorsByTicker = indicatorsByTicker || {};
  signalsByTicker = signalsByTicker || {};
  tbody.innerHTML = results.map((r) => {
    const price = fmtPrice(r.last_price !== undefined ? r.last_price : r.last_known_price);
    const change = r.change !== undefined ? fmtChange(r.change, r.change_pct) : "—";
    const statusStr = r.data_status || "UNAVAILABLE";
    const ind = indicatorsByTicker[r.ticker] || {};
    const sig = signalsByTicker[r.ticker] || {};

    const rsi = ind.rsi14 !== undefined ? fmtNum(ind.rsi14, 1) : "—";
    const trendLabel = ind.trend_label || null;
    const trendHtml = trendLabel
      ? `<span class="${trendClass(trendLabel)}">${trendLabel}</span>`
      : `<span class="text-dim">—</span>`;

    const rs = ind.relative_strength || {};
    const rsExcess = rs.rs_spy_20d;
    const rsLabel = rs.labels ? rs.labels[20] : null;
    const relStrengthHtml = rsExcess !== undefined && rsExcess !== null
      ? `<span class="${pctClass(rsExcess)}">${fmtPct(rsExcess, 1)}</span>${rsLabel ? ` <span class="${rsLabelClass(rsLabel)}" style="font-size:11px;">(${rsLabel})</span>` : ""}`
      : `<span class="text-dim">—</span>`;

    const signalHtml = sig.signal_label
      ? `${signalPillHtml(sig.signal_label)} <span class="text-dim mono" style="font-size:11px;">${sig.score_total !== null && sig.score_total !== undefined ? fmtNum(sig.score_total, 0) + "/" + (sig.score_max_currently_available || 90) : ""}</span>`
      : `<span class="text-dim">—</span>`;

    return `
      <tr onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'">
        <td><span class="ticker-badge">${r.ticker}</span></td>
        <td class="name-cell">${r.name || ""} <div class="company-name">${r.industry || ""}</div></td>
        <td class="text-right">${price}</td>
        <td class="text-right">${change}</td>
        <td class="text-right">${rsi}</td>
        <td>${trendHtml}</td>
        <td class="text-right">${relStrengthHtml}</td>
        <td>${r.sector || "—"}</td>
        <td>${signalHtml}</td>
        <td>${statusPillHtml(statusStr)}</td>
      </tr>
    `;
  }).join("");
}

function updateMarketStrip(status) {
  const sessionEl = document.getElementById("mkt-session");
  if (!sessionEl) return; // not on dashboard page
  const subEl = document.getElementById("mkt-session-sub");
  const statusEl = document.getElementById("mkt-data-status");
  const nextOpenEl = document.getElementById("mkt-next-open");
  const nextCloseEl = document.getElementById("mkt-next-close");

  if (status.is_open === true) {
    sessionEl.textContent = "OPEN";
    sessionEl.style.color = "var(--green)";
  } else if (status.session) {
    sessionEl.textContent = status.session.replace("_", " ");
    sessionEl.style.color = "var(--amber)";
  } else {
    sessionEl.textContent = "UNKNOWN";
    sessionEl.style.color = "var(--text-1)";
  }
  subEl.textContent = status.timestamp ? `as of ${fmtTime(status.timestamp)}` : (status.error || "");
  statusEl.innerHTML = statusPillHtml(status.data_status);
  nextOpenEl.textContent = status.next_open ? fmtTime(status.next_open) : "—";
  nextCloseEl.textContent = status.next_close ? fmtTime(status.next_close) : "—";
}

function updateRegimeStrip(regime) {
  const labelEl = document.getElementById("regime-label");
  if (!labelEl) return; // not on dashboard page
  const errEl = document.getElementById("regime-error");

  if (!regime || regime.regime === "UNAVAILABLE") {
    labelEl.textContent = "UNAVAILABLE";
    labelEl.className = "value text-dim";
    document.getElementById("regime-score-sub").textContent = "—";
    document.getElementById("regime-spy").textContent = "—";
    document.getElementById("regime-qqq").textContent = "—";
    document.getElementById("regime-breadth").textContent = "—";
    document.getElementById("regime-vix").textContent = "—";
    errEl.textContent = regime && regime.error ? regime.error : "";
    return;
  }

  errEl.textContent = "";
  labelEl.textContent = regime.regime;
  labelEl.className = "value " + regimeClass(regime.regime);
  document.getElementById("regime-score-sub").textContent =
    regime.regime_score !== null && regime.regime_score !== undefined ? `score ${regime.regime_score > 0 ? "+" : ""}${regime.regime_score}` : "—";

  document.getElementById("regime-spy").textContent = regime.spy_trend_label || "—";
  document.getElementById("regime-spy-sub").textContent =
    regime.spy_price !== null && regime.spy_price !== undefined ? `${fmtPrice(regime.spy_price)} (${fmtPct(regime.spy_chg_pct, 1)} 10d)` : "—";

  document.getElementById("regime-qqq").textContent = regime.qqq_trend_label || "—";
  document.getElementById("regime-qqq-sub").textContent =
    regime.qqq_price !== null && regime.qqq_price !== undefined ? `${fmtPrice(regime.qqq_price)} (${fmtPct(regime.qqq_chg_pct, 1)} 10d)` : "—";

  const breadth = (regime.detail && regime.detail.components && regime.detail.components.sector_breadth) || {};
  const bDetail = breadth.detail || { up: [], down: [], unknown: [] };
  document.getElementById("regime-breadth").textContent = `${bDetail.up.length} up / ${bDetail.down.length} down`;
  document.getElementById("regime-breadth-sub").textContent = bDetail.unknown && bDetail.unknown.length
    ? `${bDetail.unknown.length} unavailable` : "of 7 tracked sector ETFs";

  document.getElementById("regime-vix").textContent = regime.vix_proxy_roc_10d !== null && regime.vix_proxy_roc_10d !== undefined
    ? fmtPct(regime.vix_proxy_roc_10d, 1) + " (10d)" : "—";
  document.getElementById("regime-vix-sub").textContent = regime.vix_proxy_price !== null && regime.vix_proxy_price !== undefined
    ? `${regime.vix_proxy_ticker || "VIXY"} ${fmtPrice(regime.vix_proxy_price)}` : "true VIX unavailable";
}

async function refreshAll() {
  try {
    const marketStatus = await apiGet("/api/market/status");
    updateMarketStrip(marketStatus);
  } catch (e) {
    // topbar.js already surfaces this; dashboard tiles just stay at last-known state
  }

  try {
    const regime = await apiGet("/api/market/regime");
    updateRegimeStrip(regime);
  } catch (e) {
    updateRegimeStrip(null);
  }

  let indicatorsByTicker = {};
  try {
    const ind = await apiGet("/api/stocks/indicators");
    (ind.results || []).forEach((r) => { indicatorsByTicker[r.ticker] = r; });
  } catch (e) {
    console.warn("Failed to load indicators:", e.message);
  }

  let signalsByTicker = {};
  try {
    const sigs = await apiGet("/api/signals");
    (sigs.results || []).forEach((r) => { signalsByTicker[r.ticker] = r; });
  } catch (e) {
    console.warn("Failed to load signals:", e.message);
  }

  try {
    const snap = await apiGet("/api/stocks/snapshots");
    renderStocksTable(snap.results, indicatorsByTicker, signalsByTicker);
    const refreshedEl = document.getElementById("last-refreshed");
    if (refreshedEl) refreshedEl.textContent = "last refreshed " + new Date().toLocaleTimeString();
    if (snap.feed_error) {
      console.warn("Alpaca feed error:", snap.feed_error);
    }
  } catch (e) {
    const tbody = document.getElementById("stocks-tbody");
    if (tbody) tbody.innerHTML = `<tr class="loading-row"><td colspan="10">Failed to load data: ${e.message}</td></tr>`;
  }
}

refreshAll();
setInterval(refreshAll, 15000);
