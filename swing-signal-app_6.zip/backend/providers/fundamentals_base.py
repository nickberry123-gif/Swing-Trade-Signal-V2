"""
Vendor-agnostic fundamentals interface — the same abstraction pattern as MarketDataProvider.

CRITICAL DESIGN RULE (from the project spec): fundamentals are either REAL, sourced, and
attributable, or they are absent. There is no "estimate", no "typical value for this sector",
no interpolation. Every field on `Fundamentals` may be None, and None means "this source did
not report it" — it is never silently turned into a 0 or a plausible-looking guess downstream.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Fundamentals:
    ticker: str
    source: str                       # e.g. "sec-edgar" — always attributed
    as_of: str | None = None          # period end date of the most recent annual figures
    fiscal_year: int | None = None
    filed: str | None = None          # when that filing was actually filed with the SEC

    revenue: float | None = None
    revenue_prior: float | None = None
    revenue_growth_pct: float | None = None

    net_income: float | None = None
    eps_diluted: float | None = None
    eps_diluted_prior: float | None = None
    eps_growth_pct: float | None = None

    gross_profit: float | None = None
    gross_margin_pct: float | None = None
    operating_income: float | None = None
    operating_margin_pct: float | None = None

    operating_cash_flow: float | None = None
    capex: float | None = None
    free_cash_flow: float | None = None
    fcf_margin_pct: float | None = None

    total_cash: float | None = None
    total_debt: float | None = None
    stockholders_equity: float | None = None
    roic_pct: float | None = None     # operating income / (equity + debt) — a proxy, labeled as such

    warnings: list = field(default_factory=list)
    fetched_at: datetime | None = None


@dataclass
class EarningsInfo:
    """What we can honestly say about earnings timing from filing history alone.

    NOTE: SEC filing dates are BACKWARD-looking (when a report was filed). They are not a
    forward earnings calendar. `estimated_next_report` is explicitly an ESTIMATE derived from
    historical filing cadence and is labeled as such everywhere it surfaces — it is never
    presented as a confirmed earnings date.
    """
    ticker: str
    source: str
    last_period_end: str | None = None
    last_filed: str | None = None
    last_form: str | None = None
    median_days_between_reports: float | None = None
    estimated_next_report: str | None = None
    estimate_confidence: str = "LOW"   # LOW/MEDIUM — never "HIGH"; this is inferred, not published
    warnings: list = field(default_factory=list)


class FundamentalDataProvider(ABC):
    """Any fundamentals vendor must implement this. The rest of the app never imports a
    concrete provider directly, so swapping/adding a source is a one-class change."""

    name: str = "abstract"

    @abstractmethod
    def get_fundamentals(self, ticker: str) -> Fundamentals:
        ...

    @abstractmethod
    def get_earnings_info(self, ticker: str) -> EarningsInfo:
        ...
