"""
SEC EDGAR fundamentals provider.

Why EDGAR: it's the primary source — audited figures straight from the companies' own 10-K/10-Q
filings — it's free, and it requires no API key or paid plan (which matters given the project
constraint of not adding paid data vendors). Endpoints and response shapes below were verified
against SEC's live API and documentation, not assumed:

  ticker -> CIK map : https://www.sec.gov/files/company_tickers.json
                      {"0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."}, ...}
  company facts     : https://data.sec.gov/api/xbrl/companyfacts/CIK##########.json
                      root -> facts -> us-gaap -> {TAG} -> units -> {UNIT} -> [ {start,end,val,
                      accn,fy,fp,form,filed,frame}, ... ]
  submissions       : https://data.sec.gov/submissions/CIK##########.json
                      recent filings in columnar arrays (form[], filingDate[], reportDate[])

SEC requires a descriptive User-Agent with contact info for programmatic access and asks for
<= 10 requests/second; both are honored here (see SEC_USER_AGENT and the fact that this
provider is called at most once per ticker per cache-TTL, not per page load).
"""
import json
import statistics
from datetime import datetime, timedelta, timezone

import requests

from providers.base import DataStatus, ProviderError
from providers.fundamentals_base import EarningsInfo, FundamentalDataProvider, Fundamentals

SEC_TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"
SEC_FACTS_URL = "https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json"
SEC_SUBMISSIONS_URL = "https://data.sec.gov/submissions/CIK{cik:010d}.json"

# SEC's fair-access policy requires a real contact address in the User-Agent.
SEC_USER_AGENT = "SwingSignalApp/1.0 (personal swing-trading research; nickberry123@icloud.com)"

# Concept fallback chains. Companies tag the same economic concept differently depending on
# their filing style, so each logical metric maps to an ORDERED list of us-gaap tags and the
# first one that actually has usable annual data wins. Nothing is invented when none match —
# the field simply stays None and a warning is recorded.
CONCEPTS = {
    "revenue": [
        "RevenueFromContractWithCustomerExcludingAssessedTax",
        "Revenues",
        "SalesRevenueNet",
        "RevenueFromContractWithCustomerIncludingAssessedTax",
    ],
    "net_income": ["NetIncomeLoss", "ProfitLoss"],
    "eps_diluted": ["EarningsPerShareDiluted", "EarningsPerShareBasicAndDiluted"],
    "gross_profit": ["GrossProfit"],
    "operating_income": ["OperatingIncomeLoss"],
    "operating_cash_flow": [
        "NetCashProvidedByUsedInOperatingActivities",
        "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations",
    ],
    "capex": [
        "PaymentsToAcquirePropertyPlantAndEquipment",
        "PaymentsToAcquireProductiveAssets",
    ],
    "total_cash": [
        "CashAndCashEquivalentsAtCarryingValue",
        "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents",
    ],
    "stockholders_equity": ["StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"],
}
DEBT_TAGS = ["LongTermDebtNoncurrent", "LongTermDebtCurrent", "LongTermDebt", "DebtCurrent"]

# Concepts measured over a period (income/cash-flow) vs at a point in time (balance sheet).
DURATION_CONCEPTS = {"revenue", "net_income", "eps_diluted", "gross_profit", "operating_income",
                     "operating_cash_flow", "capex"}


def _pct(numerator, denominator):
    if numerator is None or not denominator:
        return None
    return round(numerator / denominator * 100, 4)


def _growth(latest, prior):
    if latest is None or prior in (None, 0):
        return None
    return round((latest - prior) / abs(prior) * 100, 4)


class SecEdgarProvider(FundamentalDataProvider):
    name = "sec-edgar"

    def __init__(self, timeout: float = 20.0, user_agent: str = SEC_USER_AGENT):
        self.timeout = timeout
        self.user_agent = user_agent
        self._ticker_map = None  # lazily fetched ticker -> CIK, cached per process

    # ---------- HTTP ----------

    def _get(self, url: str) -> dict:
        try:
            resp = requests.get(
                url,
                headers={"User-Agent": self.user_agent, "Accept": "application/json"},
                timeout=self.timeout,
            )
        except requests.RequestException as e:
            raise ProviderError(f"Network error contacting SEC EDGAR: {e}", DataStatus.UNAVAILABLE)

        if resp.status_code == 403:
            raise ProviderError(
                "SEC EDGAR rejected the request (403) — this usually means the User-Agent is "
                "missing/blocked or the fair-access rate limit was exceeded.",
                DataStatus.UNAVAILABLE,
            )
        if resp.status_code == 404:
            raise ProviderError("SEC EDGAR has no record at that URL (404).", DataStatus.UNAVAILABLE)
        if resp.status_code != 200:
            raise ProviderError(f"SEC EDGAR returned HTTP {resp.status_code}.", DataStatus.UNAVAILABLE)
        try:
            return resp.json()
        except ValueError as e:
            raise ProviderError(f"SEC EDGAR returned non-JSON content: {e}", DataStatus.UNAVAILABLE)

    # ---------- ticker -> CIK ----------

    def get_cik(self, ticker: str) -> int:
        """Resolved from SEC's own published mapping rather than a hard-coded table, so a wrong
        or stale CIK can't silently attach one company's financials to another's ticker."""
        if self._ticker_map is None:
            raw = self._get(SEC_TICKERS_URL)
            mapping = {}
            # The file is keyed by row index: {"0": {"cik_str":..., "ticker":..., "title":...}}
            rows = raw.values() if isinstance(raw, dict) else raw
            for row in rows:
                if not isinstance(row, dict):
                    continue
                t, cik = row.get("ticker"), row.get("cik_str")
                if t and cik is not None:
                    mapping[str(t).upper()] = int(cik)
            self._ticker_map = mapping

        t = ticker.upper()
        # Class-share tickers differ between vendors: Alpaca uses "BRK.B", SEC uses "BRK-B".
        for candidate in (t, t.replace(".", "-"), t.replace("-", ".")):
            if candidate in self._ticker_map:
                return self._ticker_map[candidate]
        raise ProviderError(f"No SEC CIK found for ticker {ticker}.", DataStatus.UNAVAILABLE)

    # ---------- fact extraction ----------

    @staticmethod
    def _annual_facts(facts: dict, tag: str) -> list:
        """Return annual (10-K) facts for one us-gaap tag, newest first, de-duplicated by period
        end. Amended/restated filings for the same period are collapsed to the latest-filed one."""
        node = (facts.get("us-gaap") or {}).get(tag)
        if not node:
            return []
        units = node.get("units") or {}
        # Prefer USD; fall back to USD-per-share (EPS) or whatever single unit exists.
        for unit_key in ("USD", "USD/shares"):
            if unit_key in units:
                entries = units[unit_key]
                break
        else:
            if not units:
                return []
            entries = next(iter(units.values()))

        annual = []
        for e in entries:
            if e.get("form") not in ("10-K", "20-F", "40-F"):
                continue
            end = e.get("end")
            if not end:
                continue
            start = e.get("start")
            if start:
                # Duration fact: keep only ~full-year periods so a Q4 figure is never mistaken
                # for a full fiscal year.
                try:
                    days = (datetime.fromisoformat(end) - datetime.fromisoformat(start)).days
                except (TypeError, ValueError):
                    continue
                if days < 300 or days > 400:
                    continue
            annual.append(e)

        by_end = {}
        for e in annual:
            end = e["end"]
            prev = by_end.get(end)
            if prev is None or (e.get("filed") or "") > (prev.get("filed") or ""):
                by_end[end] = e
        return sorted(by_end.values(), key=lambda x: x["end"], reverse=True)

    def _latest_and_prior(self, facts: dict, concept: str):
        for tag in CONCEPTS.get(concept, []):
            entries = self._annual_facts(facts, tag)
            if entries:
                latest = entries[0].get("val")
                prior = entries[1].get("val") if len(entries) > 1 else None
                return latest, prior, entries[0], tag
        return None, None, None, None

    def _total_debt(self, facts: dict):
        """Debt is reported under several tags and companies use different combinations; sum the
        current+noncurrent pair when present, else fall back to a single aggregate tag."""
        noncurrent = self._annual_facts(facts, "LongTermDebtNoncurrent")
        current = self._annual_facts(facts, "LongTermDebtCurrent")
        if noncurrent or current:
            total = 0.0
            got = False
            for entries in (noncurrent, current):
                if entries and entries[0].get("val") is not None:
                    total += float(entries[0]["val"])
                    got = True
            return total if got else None
        for tag in ("LongTermDebt", "DebtLongtermAndShorttermCombinedAmount"):
            entries = self._annual_facts(facts, tag)
            if entries and entries[0].get("val") is not None:
                return float(entries[0]["val"])
        return None

    # ---------- public API ----------

    def get_fundamentals(self, ticker: str) -> Fundamentals:
        cik = self.get_cik(ticker)
        payload = self._get(SEC_FACTS_URL.format(cik=cik))
        facts = payload.get("facts") or {}
        warnings = []

        f = Fundamentals(ticker=ticker.upper(), source=self.name,
                         fetched_at=datetime.now(timezone.utc))

        revenue, revenue_prior, rev_entry, rev_tag = self._latest_and_prior(facts, "revenue")
        if revenue is None:
            warnings.append("No annual revenue concept found in this company's XBRL filings.")
        else:
            f.as_of = rev_entry.get("end")
            f.fiscal_year = rev_entry.get("fy")
            f.filed = rev_entry.get("filed")

        net_income, _, _, _ = self._latest_and_prior(facts, "net_income")
        eps, eps_prior, _, _ = self._latest_and_prior(facts, "eps_diluted")
        gross_profit, _, _, _ = self._latest_and_prior(facts, "gross_profit")
        operating_income, _, _, _ = self._latest_and_prior(facts, "operating_income")
        ocf, _, _, _ = self._latest_and_prior(facts, "operating_cash_flow")
        capex, _, _, _ = self._latest_and_prior(facts, "capex")
        cash, _, _, _ = self._latest_and_prior(facts, "total_cash")
        equity, _, _, _ = self._latest_and_prior(facts, "stockholders_equity")
        debt = self._total_debt(facts)

        fcf = (ocf - capex) if (ocf is not None and capex is not None) else None

        f.revenue = revenue
        f.revenue_prior = revenue_prior
        f.revenue_growth_pct = _growth(revenue, revenue_prior)
        f.net_income = net_income
        f.eps_diluted = eps
        f.eps_diluted_prior = eps_prior
        f.eps_growth_pct = _growth(eps, eps_prior)
        f.gross_profit = gross_profit
        f.gross_margin_pct = _pct(gross_profit, revenue)
        f.operating_income = operating_income
        f.operating_margin_pct = _pct(operating_income, revenue)
        f.operating_cash_flow = ocf
        f.capex = capex
        f.free_cash_flow = fcf
        f.fcf_margin_pct = _pct(fcf, revenue)
        f.total_cash = cash
        f.total_debt = debt
        f.stockholders_equity = equity
        if operating_income is not None and equity:
            invested = equity + (debt or 0.0)
            f.roic_pct = _pct(operating_income, invested) if invested else None

        for label, value in (("gross profit", gross_profit), ("operating cash flow", ocf),
                             ("capital expenditure", capex)):
            if value is None:
                warnings.append(f"No annual {label} reported under the tags this app checks.")
        f.warnings = warnings
        return f

    def get_earnings_info(self, ticker: str) -> EarningsInfo:
        cik = self.get_cik(ticker)
        payload = self._get(SEC_SUBMISSIONS_URL.format(cik=cik))
        recent = ((payload.get("filings") or {}).get("recent") or {})
        forms = recent.get("form") or []
        filing_dates = recent.get("filingDate") or []
        report_dates = recent.get("reportDate") or []

        info = EarningsInfo(ticker=ticker.upper(), source=self.name)

        periodic = [
            (filing_dates[i], report_dates[i] if i < len(report_dates) else None, forms[i])
            for i in range(min(len(forms), len(filing_dates)))
            if forms[i] in ("10-Q", "10-K")
        ]
        if not periodic:
            info.warnings.append("No 10-Q/10-K filings found — earnings timing unavailable.")
            return info

        periodic.sort(key=lambda x: x[0], reverse=True)
        info.last_filed, info.last_period_end, info.last_form = periodic[0]

        gaps = []
        for i in range(min(len(periodic) - 1, 8)):
            try:
                a = datetime.fromisoformat(periodic[i][0])
                b = datetime.fromisoformat(periodic[i + 1][0])
                gaps.append((a - b).days)
            except (TypeError, ValueError):
                continue
        gaps = [g for g in gaps if 30 <= g <= 200]
        if gaps:
            info.median_days_between_reports = float(statistics.median(gaps))
            try:
                last = datetime.fromisoformat(info.last_filed)
                info.estimated_next_report = (
                    last + timedelta(days=info.median_days_between_reports)
                ).date().isoformat()
                info.estimate_confidence = "MEDIUM" if len(gaps) >= 4 else "LOW"
            except (TypeError, ValueError):
                pass
        else:
            info.warnings.append("Filing cadence too irregular to estimate the next report date.")

        info.warnings.append(
            "Estimated from historical SEC filing cadence — this is NOT a confirmed, "
            "company-announced earnings date."
        )
        return info
