"""
Thin SQLite data-access layer (stdlib sqlite3 — no ORM dependency required).

Design notes:
- One connection per request (Flask g-scoped), row_factory=sqlite3.Row so callers
  can access columns by name.
- init_db() applies schema.sql and is idempotent (CREATE TABLE IF NOT EXISTS everywhere).
- seed_stocks() upserts the fixed 15-stock universe from config.STOCK_UNIVERSE.
"""
import sqlite3
from pathlib import Path

from flask import g

from config import Config, STOCK_UNIVERSE, BENCHMARK_SYMBOLS

SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(Config.DATABASE_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables if they don't exist, and seed the fixed stock universe."""
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    try:
        with open(SCHEMA_PATH, "r") as f:
            conn.executescript(f.read())
        conn.commit()
        _migrate_add_missing_columns(conn)
        _seed_stocks(conn)
        _seed_benchmark_symbols(conn)
        _seed_strategy_version(conn)
    finally:
        conn.close()


# Columns added to pre-existing tables in later phases. `CREATE TABLE IF NOT EXISTS` will not
# alter a table that already exists, so a database created by an earlier phase would otherwise
# be permanently missing these. Each entry is (table, column, SQL type) and is applied only if
# absent — safe to run on every start, and never destructive.
_LATER_PHASE_COLUMNS = [
    ("fundamentals", "revenue", "REAL"),
    ("fundamentals", "revenue_prior", "REAL"),
    ("fundamentals", "net_income", "REAL"),
    ("fundamentals", "eps_diluted", "REAL"),
    ("fundamentals", "gross_profit", "REAL"),
    ("fundamentals", "operating_income", "REAL"),
    ("fundamentals", "operating_cash_flow", "REAL"),
    ("fundamentals", "capex", "REAL"),
    ("fundamentals", "stockholders_equity", "REAL"),
    ("fundamentals", "long_term_quality_breakdown", "TEXT"),
    ("fundamentals", "fiscal_year", "INTEGER"),
    ("fundamentals", "filed", "TEXT"),
    ("fundamentals", "warnings_json", "TEXT"),
    ("news", "summary", "TEXT"),
    ("news", "impact", "TEXT"),
    ("trades", "fx_rate_usd_gbp", "REAL"),
]


def _migrate_add_missing_columns(conn: sqlite3.Connection):
    for table, column, coltype in _LATER_PHASE_COLUMNS:
        try:
            existing = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        except sqlite3.Error:
            continue
        if not existing:
            continue  # table doesn't exist yet; schema.sql will have created it
        if column not in existing:
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")
            except sqlite3.Error:
                pass  # a concurrent start may have added it; never fatal
    conn.commit()


def _seed_stocks(conn: sqlite3.Connection):
    for s in STOCK_UNIVERSE:
        conn.execute(
            """
            INSERT INTO stocks (ticker, name, sector, industry, exchange)
            VALUES (:ticker, :name, :sector, :industry, :exchange)
            ON CONFLICT(ticker) DO UPDATE SET
                name = excluded.name,
                sector = excluded.sector,
                industry = excluded.industry,
                exchange = excluded.exchange
            """,
            s,
        )
    conn.commit()


def _seed_benchmark_symbols(conn: sqlite3.Connection):
    for b in BENCHMARK_SYMBOLS:
        conn.execute(
            """
            INSERT INTO benchmark_symbols (ticker, name, category)
            VALUES (:ticker, :name, :category)
            ON CONFLICT(ticker) DO UPDATE SET name = excluded.name, category = excluded.category
            """,
            b,
        )
    conn.commit()


def _seed_strategy_version(conn: sqlite3.Connection):
    """Register strategy v1.0 so later phases have a version to attach signals to."""
    import json

    weights = {
        "long_term_trend": 20, "short_term_trend": 10, "momentum": 15,
        "rsi_pullback": 10, "volume": 10, "support_resistance": 10,
        "relative_strength": 10, "market_regime": 5, "news": 5, "earnings_risk": 5,
    }
    conn.execute(
        """
        INSERT INTO strategy_versions (version, description, weights_json, params_json)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(version) DO NOTHING
        """,
        (
            "v1.0",
            "Initial 100-point long-only swing signal engine per project spec.",
            json.dumps(weights),
            json.dumps({}),
        ),
    )
    conn.commit()


def init_app(app):
    app.teardown_appcontext(close_db)
