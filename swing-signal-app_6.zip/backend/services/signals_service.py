"""
Orchestration: ties market regime, Phase 2 stock analysis, Phase 4 fundamentals/news/earnings,
and the signal engine together for one ticker or the whole 15-stock universe. Routers call this
module; they never touch signal_engine or the providers directly.

Failure isolation is deliberate throughout: fundamentals, news and earnings are each optional
enrichments. If SEC EDGAR is down or the news endpoint isn't on the user's Alpaca plan, the
price-based signal still computes — those components simply report as unavailable and drop out
of the achievable maximum, rather than taking the whole signal down with them.
"""
from config import STOCK_UNIVERSE
from services.fundamentals_service import get_earnings_info, get_fundamentals
from services.market_regime import compute_market_regime, store_market_regime
from services.news_service import refresh_news, score_earnings_risk, score_news
from services.signal_engine import compute_signal, persist_signal
from services.stock_analysis import analyze_stock, build_benchmark_cache

TICKERS = [s["ticker"] for s in STOCK_UNIVERSE]


def _safe(fn, *args, **kwargs):
    """Phase 4 enrichments must never be able to break the core price-based signal."""
    try:
        return fn(*args, **kwargs)
    except Exception:  # noqa: BLE001 — deliberately broad; an enrichment failure is not fatal
        return None


def compute_signal_for_ticker(db, ticker: str, timeframe: str = "1Day", benchmark_cache=None,
                               regime: dict | None = None, persist: bool = True,
                               include_fundamentals: bool = True) -> dict:
    analysis = analyze_stock(db, ticker, timeframe=timeframe, benchmark_cache=benchmark_cache,
                             persist=persist)
    if regime is None:
        regime = compute_market_regime(db)

    quality = earnings_info = None
    news_tuple = earnings_tuple = None

    if include_fundamentals:
        quality = _safe(get_fundamentals, db, ticker)
        earnings_info = _safe(get_earnings_info, db, ticker)
        _safe(refresh_news, db, [ticker])
        news_tuple = _safe(score_news, db, ticker)
        earnings_tuple = _safe(score_earnings_risk, earnings_info) if earnings_info else None

    signal = compute_signal(analysis, regime, news=news_tuple, earnings=earnings_tuple,
                            quality=quality, earnings_info=earnings_info)
    if persist:
        persist_signal(db, signal)
    return signal


def compute_all_signals(db, timeframe: str = "1Day", persist: bool = True,
                        include_fundamentals: bool = True) -> list:
    """Computes signals for all 15 tracked stocks, sharing one market-regime fetch, one
    benchmark-bar cache, and ONE batched news call across all 15 (rather than 15x redundant
    SPY/QQQ/sector fetches and 15 separate news requests).

    Returns them ranked best-score-first; tickers with no data sort to the end rather than being
    silently dropped."""
    regime = compute_market_regime(db)
    if persist and regime.get("regime") != "UNAVAILABLE":
        store_market_regime(db, regime)

    benchmark_cache = build_benchmark_cache(db, timeframe)

    # One batched news request for the whole universe — Alpaca's endpoint takes a symbol list.
    if include_fundamentals:
        _safe(refresh_news, db, TICKERS)

    signals = []
    for ticker in TICKERS:
        try:
            quality = earnings_info = None
            news_tuple = earnings_tuple = None
            if include_fundamentals:
                quality = _safe(get_fundamentals, db, ticker)
                earnings_info = _safe(get_earnings_info, db, ticker)
                news_tuple = _safe(score_news, db, ticker)
                earnings_tuple = _safe(score_earnings_risk, earnings_info) if earnings_info else None

            analysis = analyze_stock(db, ticker, timeframe=timeframe,
                                     benchmark_cache=benchmark_cache, persist=persist)
            signal = compute_signal(analysis, regime, news=news_tuple, earnings=earnings_tuple,
                                    quality=quality, earnings_info=earnings_info)
            if persist:
                persist_signal(db, signal)
        except Exception as e:  # noqa: BLE001 — one bad ticker must not take down the whole batch
            signal = {
                "ticker": ticker, "signal_label": "NO DATA", "score_total": None,
                "data_status": "UNAVAILABLE", "data_error": str(e),
            }
        signals.append(signal)

    signals.sort(key=lambda s: (s.get("score_total") is None, -(s.get("score_total") or 0)))
    return signals
