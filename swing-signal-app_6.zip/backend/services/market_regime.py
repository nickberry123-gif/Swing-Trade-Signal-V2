"""
Market regime classification: STRONG BULL / BULL / NEUTRAL / CAUTIOUS / BEAR.

Built from four transparent, independently-scored components (never a black box):
  1. SPY trend  (price vs 200-day SMA, 200-day SMA direction, price vs 50-day SMA)
  2. QQQ trend  (same three checks)
  3. Sector breadth  (how many of the 7 tracked sector ETFs are in an uptrend)
  4. Volatility proxy  (5-day rate of change of VIXY — true CBOE VIX is not available from
     Alpaca; see config.VIX_PROXY_TICKER)

Each component contributes a small signed score; the total is bucketed into the five regime
labels. The full breakdown is returned alongside the label so the UI (and, later, the
trading-score engine) can show exactly why the regime is what it is — mirrors the "WHY THIS
SCORE?" transparency requirement applied one level up, at the market level.
"""
from datetime import datetime, timezone

from config import BROAD_MARKET_SYMBOLS, VIX_PROXY_TICKER, SECTOR_ETF_SYMBOLS
from services.bars_service import get_bars_df
from services.indicators import compute_all_indicators

REGIME_THRESHOLDS = [
    (7, "STRONG BULL"),
    (3, "BULL"),
    (-2, "NEUTRAL"),
    (-6, "CAUTIOUS"),
    (float("-inf"), "BEAR"),
]


def _signed(value: float, zero_tolerance: float = 0.0) -> int:
    """+1 / -1 / 0, with a small dead zone around zero so near-exact ties (e.g. a
    genuinely flat market) score as neutral rather than being arbitrarily pushed bearish."""
    if value > zero_tolerance:
        return 1
    if value < -zero_tolerance:
        return -1
    return 0


def _trend_component(ind: dict) -> tuple[float, list[str]]:
    """Score a single index's trend on -3..+3 using price vs SMA200 / SMA200 direction /
    price vs SMA50 — same three checks the qualitative trend_label uses, kept numeric here.
    Each check has a small neutral dead-zone (~0.1%) so near-flat conditions score as 0,
    not an arbitrary -1."""
    score = 0.0
    notes = []
    price = ind.get("reference_price")
    sma50, sma200, slope = ind.get("sma50"), ind.get("sma200"), ind.get("sma200_slope")

    if price is not None and sma200 is not None and sma200 != 0:
        pct_diff = (price - sma200) / sma200 * 100
        s = _signed(pct_diff, zero_tolerance=0.1)
        score += s
        notes.append(f"price {'above' if s > 0 else 'below' if s < 0 else 'in line with'} 200d SMA ({pct_diff:+.2f}%)")
    if slope is not None:
        s = _signed(slope, zero_tolerance=0.05)
        score += s
        notes.append(f"200d SMA {'rising' if s > 0 else 'falling' if s < 0 else 'flat'} ({slope:+.2f}%)")
    if price is not None and sma50 is not None and sma50 != 0:
        pct_diff = (price - sma50) / sma50 * 100
        s = _signed(pct_diff, zero_tolerance=0.1)
        score += s
        notes.append(f"price {'above' if s > 0 else 'below' if s < 0 else 'in line with'} 50d SMA ({pct_diff:+.2f}%)")
    return score, notes


def _breadth_component(sector_indicators: dict) -> tuple[float, dict]:
    up, down, unknown = [], [], []
    for ticker, ind in sector_indicators.items():
        price, sma50 = ind.get("reference_price"), ind.get("sma50")
        if price is None or sma50 is None or sma50 == 0:
            unknown.append(ticker)
        else:
            pct_diff = (price - sma50) / sma50 * 100
            s = _signed(pct_diff, zero_tolerance=0.1)
            if s > 0:
                up.append(ticker)
            elif s < 0:
                down.append(ticker)
            else:
                unknown.append(ticker)
    total = len(up) + len(down)
    if total == 0:
        return 0.0, {"up": up, "down": down, "unknown": unknown}
    score = (len(up) - len(down)) / total * 3
    return round(score, 3), {"up": up, "down": down, "unknown": unknown}


def _volatility_component(vix_proxy_ind: dict, vix_proxy_bars_len: int) -> tuple[float, str]:
    if vix_proxy_bars_len < 6:
        return 0.0, "insufficient VIXY history"
    close_now = vix_proxy_ind.get("reference_price")
    roc = vix_proxy_ind.get("roc")  # 10-day ROC computed by the shared indicator engine
    if roc is None:
        return 0.0, "VIXY rate-of-change unavailable"
    # Rising VIXY = rising fear = risk-off. Falling VIXY = calming = risk-on.
    if roc <= -8:
        return 2.0, f"VIXY down {roc:.1f}% (10d) — volatility calming"
    if roc <= 5:
        return 0.5, f"VIXY roughly flat ({roc:+.1f}% 10d)"
    if roc <= 15:
        return -1.5, f"VIXY up {roc:.1f}% (10d) — rising volatility"
    return -3.0, f"VIXY up {roc:.1f}% (10d) — sharp volatility spike"


def classify(score: float) -> str:
    for threshold, label in REGIME_THRESHOLDS:
        if score >= threshold:
            return label
    return "BEAR"


def compute_market_regime(db) -> dict:
    now = datetime.now(timezone.utc).isoformat()

    index_indicators = {}
    index_meta = {}
    for ticker in BROAD_MARKET_SYMBOLS:
        df, meta = get_bars_df(db, ticker, "1Day")
        index_meta[ticker] = meta
        index_indicators[ticker] = compute_all_indicators(df) if not df.empty else {"bars_used": 0, "warnings": ["no data"]}

    sector_indicators = {}
    sector_meta = {}
    for ticker in SECTOR_ETF_SYMBOLS:
        df, meta = get_bars_df(db, ticker, "1Day")
        sector_meta[ticker] = meta
        sector_indicators[ticker] = compute_all_indicators(df) if not df.empty else {"bars_used": 0, "warnings": ["no data"]}

    vix_df, vix_meta = get_bars_df(db, VIX_PROXY_TICKER, "1Day")
    vix_ind = compute_all_indicators(vix_df) if not vix_df.empty else {"bars_used": 0, "warnings": ["no data"]}

    spy_ind, qqq_ind = index_indicators.get("SPY", {}), index_indicators.get("QQQ", {})
    have_core_data = spy_ind.get("bars_used", 0) > 0 and qqq_ind.get("bars_used", 0) > 0

    if not have_core_data:
        return {
            "regime": "UNAVAILABLE",
            "regime_score": None,
            "error": "SPY and/or QQQ data unavailable from Alpaca — cannot classify market regime.",
            "computed_at": now,
        }

    spy_score, spy_notes = _trend_component(spy_ind)
    qqq_score, qqq_notes = _trend_component(qqq_ind)
    breadth_score, breadth_detail = _breadth_component(sector_indicators)
    vix_score, vix_note = _volatility_component(vix_ind, vix_ind.get("bars_used", 0))

    total = round(spy_score + qqq_score + breadth_score + vix_score, 3)
    regime = classify(total)

    def _chg_pct(ind):
        roc = ind.get("roc")
        return roc  # 10-day ROC used as the headline "change" figure for regime tiles

    detail = {
        "components": {
            "spy_trend": {"score": spy_score, "notes": spy_notes},
            "qqq_trend": {"score": qqq_score, "notes": qqq_notes},
            "sector_breadth": {"score": breadth_score, "detail": breadth_detail},
            "volatility_proxy": {"score": vix_score, "note": vix_note},
        },
        "sector_readings": {
            t: {"price": ind.get("reference_price"), "sma50": ind.get("sma50"), "trend_label": ind.get("trend_label")}
            for t, ind in sector_indicators.items()
        },
        "vix_true_index_status": "UNAVAILABLE (Alpaca does not provide CBOE index data; see VIX_PROXY_TICKER)",
    }

    return {
        "regime": regime,
        "regime_score": total,
        "spy_price": spy_ind.get("reference_price"),
        "spy_chg_pct": _chg_pct(spy_ind),
        "spy_trend_label": spy_ind.get("trend_label"),
        "qqq_price": qqq_ind.get("reference_price"),
        "qqq_chg_pct": _chg_pct(qqq_ind),
        "qqq_trend_label": qqq_ind.get("trend_label"),
        "vix_status": "UNAVAILABLE",
        "vix_proxy_ticker": VIX_PROXY_TICKER,
        "vix_proxy_price": vix_ind.get("reference_price"),
        "vix_proxy_roc_10d": vix_ind.get("roc"),
        "detail": detail,
        "computed_at": now,
    }


def store_market_regime(db, result: dict):
    import json
    db.execute(
        """
        INSERT INTO market_regime (ts, spy_price, spy_chg_pct, qqq_price, qqq_chg_pct,
                                    vix_price, vix_status, vix_proxy_ticker, vix_proxy_price,
                                    vix_proxy_chg_5d_pct, regime_score, regime, detail_json)
        VALUES (:ts, :spy_price, :spy_chg_pct, :qqq_price, :qqq_chg_pct, NULL, :vix_status,
                :vix_proxy_ticker, :vix_proxy_price, :vix_proxy_roc_10d, :regime_score, :regime,
                :detail_json)
        """,
        {
            "ts": result.get("computed_at"),
            "spy_price": result.get("spy_price"), "spy_chg_pct": result.get("spy_chg_pct"),
            "qqq_price": result.get("qqq_price"), "qqq_chg_pct": result.get("qqq_chg_pct"),
            "vix_status": result.get("vix_status"), "vix_proxy_ticker": result.get("vix_proxy_ticker"),
            "vix_proxy_price": result.get("vix_proxy_price"), "vix_proxy_roc_10d": result.get("vix_proxy_roc_10d"),
            "regime_score": result.get("regime_score"), "regime": result.get("regime"),
            "detail_json": json.dumps(result.get("detail", {})),
        },
    )
    db.commit()
