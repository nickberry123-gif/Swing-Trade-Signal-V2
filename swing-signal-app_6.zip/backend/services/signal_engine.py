"""
Phase 3: the 100-point long-only swing-signal engine.

Turns Phase 2's raw indicators + relative strength + market regime into an actual decision:
a score, a signal label, a strategy setup, and buy/sell price levels.

Design rules carried forward from Phases 1-2 (never relaxed here):
- No stop-loss anywhere. No shorting. No leverage/options. This module only ever proposes a
  price to consider BUYING at, and levels at which one might consider taking profit. It never
  computes, stores, or displays a stop-loss.
- Support/resistance and buy/sell levels are always ranges, never a single exact price
  presented as certain.
- Scoring is a weighted blend of many soft conditions, never a rigid binary pass/fail on one
  indicator. A single temporarily-violated condition must not zero out an otherwise strong setup.
- Never fabricate. Two of the ten strategy_versions weight categories (news=5, earnings_risk=5)
  require data sources this app doesn't have yet (Phase 4). Those two are always awarded 0 and
  explicitly disclosed as PENDING — not hidden, not guessed, not silently redistributed to
  other categories (that would misrepresent how much the other 8 categories actually know).

Weights (must match db._seed_strategy_version's weights_json, strategy v1.0):
    long_term_trend=20, short_term_trend=10, momentum=15, rsi_pullback=10, volume=10,
    support_resistance=10, relative_strength=10, market_regime=5, news=5, earnings_risk=5
    -> 100 total; 90 currently computable, 10 pending Phase 4.
"""
import json
import math

STRATEGY_VERSION = "v1.0"

WEIGHTS = {
    "long_term_trend": 20, "short_term_trend": 10, "momentum": 15, "rsi_pullback": 10,
    "volume": 10, "support_resistance": 10, "relative_strength": 10, "market_regime": 5,
    "news": 5, "earnings_risk": 5,
}
PENDING_PHASE4_NOTE = "not yet available — requires a fundamentals/news data source (Phase 4)"

SIGNAL_THRESHOLDS = [
    (78, "STRONG BUY"), (62, "BUY"), (45, "WATCH"), (25, "NO TRADE"), (float("-inf"), "AVOID"),
]

RS_PERIOD_WEIGHTS = {20: 4, 50: 3, 5: 2, 200: 1}  # sums to 10 — recent/medium term weighted heaviest


def _scale(parts, target_points):
    """parts: list of (earned, possible) tuples; possible<=0 means that sub-condition wasn't
    computable and is skipped entirely (not penalized, not guessed) — the component's score is
    rescaled to `target_points` using only the sub-conditions that were actually evaluated.
    Returns None (not 0) if NONE of the sub-conditions were computable, so the caller can tell
    "genuinely unknown" apart from "known and scored zero"."""
    earned = sum(e for e, p in parts if p and p > 0)
    possible = sum(p for _, p in parts if p and p > 0)
    if possible <= 0:
        return None
    return round(earned / possible * target_points, 2)


def score_long_term_trend(ind: dict) -> tuple:
    """20 pts. Same four conditions services/indicators.classify_trend() already uses,
    scored numerically here rather than just bucketed into a qualitative label."""
    price, sma50, sma200, slope = ind.get("reference_price"), ind.get("sma50"), ind.get("sma200"), ind.get("sma200_slope")
    parts, reasons = [], []

    if price is not None and sma200 not in (None, 0):
        ok = price > sma200
        parts.append((5 if ok else 0, 5))
        reasons.append(f"price is {'above' if ok else 'below'} the 200-day SMA ({(price - sma200) / sma200 * 100:+.2f}%)")
    else:
        parts.append((0, 0))

    if slope is not None:
        ok = slope > 0
        parts.append((5 if ok else 0, 5))
        reasons.append(f"200-day SMA is {'rising' if ok else 'flat/falling'} ({slope:+.2f}% / 10 bars)")
    else:
        parts.append((0, 0))

    if sma50 is not None and sma200 not in (None, 0):
        ok = sma50 > sma200
        parts.append((5 if ok else 0, 5))
        reasons.append(f"50-day SMA is {'above' if ok else 'below'} the 200-day SMA")
    else:
        parts.append((0, 0))

    if price is not None and sma50 not in (None, 0):
        ok = price > sma50
        parts.append((5 if ok else 0, 5))
        reasons.append(f"price is {'above' if ok else 'below'} the 50-day SMA")
    else:
        parts.append((0, 0))

    score = _scale(parts, 20)
    return score, reasons


def score_short_term_trend(ind: dict) -> tuple:
    """10 pts. Shorter-horizon confirmation: EMA20/EMA50 stack, MACD state, 10-day ROC sign."""
    price, ema20, ema50 = ind.get("reference_price"), ind.get("ema20"), ind.get("ema50")
    macd, macd_signal, roc = ind.get("macd"), ind.get("macd_signal"), ind.get("roc")
    parts, reasons = [], []

    if price is not None and ema20 not in (None, 0):
        ok = price > ema20
        parts.append((2.5 if ok else 0, 2.5))
        reasons.append(f"price is {'above' if ok else 'below'} the 20-day EMA")
    else:
        parts.append((0, 0))

    if ema20 is not None and ema50 is not None:
        ok = ema20 > ema50
        parts.append((2.5 if ok else 0, 2.5))
        reasons.append(f"20-day EMA is {'above' if ok else 'below'} the 50-day EMA")
    else:
        parts.append((0, 0))

    if macd is not None and macd_signal is not None:
        ok = macd > macd_signal
        parts.append((2.5 if ok else 0, 2.5))
        reasons.append(f"MACD is {'above' if ok else 'below'} its signal line")
    else:
        parts.append((0, 0))

    if roc is not None:
        ok = roc > 0
        parts.append((2.5 if ok else 0, 2.5))
        reasons.append(f"10-day rate of change is {roc:+.2f}%")
    else:
        parts.append((0, 0))

    score = _scale(parts, 10)
    return score, reasons


def score_momentum(ind: dict) -> tuple:
    """15 pts. RSI band (healthy-bullish vs overbought/oversold), MACD histogram sign, ADX
    trend strength, and 10-day ROC magnitude (rewards steady continuation, not blow-off runs)."""
    rsi, macd_hist, adx, roc = ind.get("rsi14"), ind.get("macd_hist"), ind.get("adx"), ind.get("roc")
    parts, reasons = [], []

    if rsi is not None:
        if 50 <= rsi <= 70:
            pts = 5
        elif 40 <= rsi < 50 or 70 < rsi <= 75:
            pts = 3
        elif 30 <= rsi < 40 or 75 < rsi <= 80:
            pts = 1
        else:
            pts = 0
        parts.append((pts, 5))
        reasons.append(f"RSI(14) is {rsi:.1f}")
    else:
        parts.append((0, 0))

    if macd_hist is not None:
        ok = macd_hist > 0
        parts.append((4 if ok else 0, 4))
        reasons.append(f"MACD histogram is {'positive' if ok else 'non-positive'} ({macd_hist:+.3f})")
    else:
        parts.append((0, 0))

    if adx is not None:
        if adx >= 25:
            pts = 3
        elif adx >= 20:
            pts = 1.5
        else:
            pts = 0
        parts.append((pts, 3))
        reasons.append(f"ADX(14) is {adx:.1f} ({'trending' if adx >= 25 else 'developing' if adx >= 20 else 'choppy/weak'})")
    else:
        parts.append((0, 0))

    if roc is not None:
        if 2 <= roc <= 12:
            pts = 3
        elif 12 < roc <= 20:
            pts = 1.5
        elif roc > 20:
            pts = 0.5
        elif 0 <= roc < 2:
            pts = 1
        else:
            pts = 0
        parts.append((pts, 3))
    else:
        parts.append((0, 0))

    score = _scale(parts, 15)
    return score, reasons


def score_rsi_pullback(ind: dict) -> tuple:
    """10 pts. Rewards a genuine 'buy the dip inside an intact uptrend' setup — not just any
    RSI reading. An oversold RSI during a downtrend is a broken chart, not a pullback, per the
    long-only/trend-respecting philosophy, and scores near zero rather than being treated as
    a bargain."""
    rsi, trend_label = ind.get("rsi14"), ind.get("trend_label")
    if rsi is None or trend_label is None:
        return None, ["RSI or trend data unavailable — pullback quality not evaluated."]

    reasons = [f"RSI(14) {rsi:.1f} in trend context '{trend_label}'"]
    if trend_label in ("Strong Uptrend", "Uptrend"):
        if 35 <= rsi <= 55:
            pts = 10
        elif 30 <= rsi < 35:
            pts = 7
        elif 55 < rsi <= 65:
            pts = 6
        elif 65 < rsi <= 72:
            pts = 3
        else:
            pts = 1
    elif trend_label == "Neutral":
        pts = 4 if 30 <= rsi <= 50 else 1
    else:
        pts = 0
        reasons.append("trend is not an uptrend — a low RSI here is a breakdown, not a buyable pullback")
    return pts, reasons


def score_volume(ind: dict) -> tuple:
    """10 pts. Relative volume (vs 20-day average) plus the 5d-vs-20d volume trend — rewards
    moves happening on real participation, not thin/quiet tape."""
    rel_vol, vol_trend = ind.get("relative_volume"), ind.get("volume_trend")
    parts, reasons = [], []

    if rel_vol is not None:
        if rel_vol >= 1.5:
            pts = 6
        elif rel_vol >= 1.1:
            pts = 4
        elif rel_vol >= 0.8:
            pts = 2
        else:
            pts = 0
        parts.append((pts, 6))
        reasons.append(f"relative volume {rel_vol:.2f}x the 20-day average")
    else:
        parts.append((0, 0))

    if vol_trend is not None:
        pts = {"Increasing": 4, "Flat": 2, "Decreasing": 0}.get(vol_trend, 2)
        parts.append((pts, 4))
        reasons.append(f"volume trend: {vol_trend}")
    else:
        parts.append((0, 0))

    score = _scale(parts, 10)
    return score, reasons


def score_support_resistance(ind: dict) -> tuple:
    """10 pts. Proximity to the support zone (a good entry sits at or just above support, not
    chasing well above it) plus how much room exists to the resistance zone (poor risk/reward
    if price already sits right under resistance)."""
    price = ind.get("reference_price")
    support_low, support_high = ind.get("support_low"), ind.get("support_high")
    resistance_low = ind.get("resistance_low")
    parts, reasons = [], []

    if price is not None and support_low is not None and support_high is not None:
        if support_low <= price <= support_high:
            pts = 7
            reasons.append("price is currently inside the support zone")
        else:
            pct_above = (price - support_high) / support_high * 100 if support_high else None
            if pct_above is None:
                pts = 0
            elif pct_above <= 3:
                pts = 6
            elif pct_above <= 6:
                pts = 4
            elif pct_above <= 10:
                pts = 2
            else:
                pts = 0
            reasons.append(f"price is {pct_above:+.1f}% above the support zone" if pct_above is not None else "support zone unclear")
        parts.append((pts, 7))
    else:
        parts.append((0, 0))

    if price is not None and ind.get("resistance_low") is not None:
        room_pct = (ind["resistance_low"] - price) / price * 100
        if room_pct >= 8:
            pts = 3
        elif room_pct >= 4:
            pts = 2
        elif room_pct >= 1:
            pts = 1
        else:
            pts = 0
        parts.append((pts, 3))
        reasons.append(f"{room_pct:.1f}% room to the resistance zone")
    else:
        parts.append((0, 0))

    score = _scale(parts, 10)
    return score, reasons


def score_relative_strength(rs: dict) -> tuple:
    """10 pts. Weighted blend of the Strong/In-line/Weak labels (vs SPY) across 5/20/50/200
    trading days, weighted toward the 20/50-day windows since this is a swing (not
    buy-and-hold, not day-trade) strategy."""
    labels = (rs or {}).get("labels") or {}
    parts, reasons = [], []
    for period, weight in RS_PERIOD_WEIGHTS.items():
        label = labels.get(period)
        if label is None:
            parts.append((0, 0))
            continue
        pts = {"Strong": weight, "In-line": weight * 0.5, "Weak": 0}.get(label, weight * 0.5)
        parts.append((pts, weight))
        reasons.append(f"{period}d relative strength vs SPY: {label}")
    score = _scale(parts, 10)
    return score, reasons


def score_market_regime(regime: dict) -> tuple:
    """5 pts. The one component shared across all 15 stocks. Deliberately NOT redistributed
    to other categories if unavailable — the fixed weight is what strategy_versions v1.0
    declares, and silently reallocating it would overstate how much the other 8 categories
    know on their own."""
    label = (regime or {}).get("regime")
    mapping = {"STRONG BULL": 5.0, "BULL": 4.0, "NEUTRAL": 2.5, "CAUTIOUS": 1.0, "BEAR": 0.0}
    if label not in mapping:
        return None, ["Market regime unavailable — this component scored 0 and excluded from the total, not guessed."]
    return mapping[label], [f"market regime: {label}"]


def classify_strategy_setup(ind: dict) -> str:
    """PULLBACK / BREAKOUT / DEEP_CORRECTION / NONE — a plain-English label for *why* this
    might be a reasonable entry, shown alongside the score rather than instead of it."""
    price = ind.get("reference_price")
    trend_label = ind.get("trend_label")
    rsi = ind.get("rsi14")
    sma50, sma200 = ind.get("sma50"), ind.get("sma200")
    support_low, support_high = ind.get("support_low"), ind.get("support_high")
    resistance_high = ind.get("resistance_high")
    high_20d = ind.get("high_20d")
    rel_vol = ind.get("relative_volume")

    is_uptrend = trend_label in ("Strong Uptrend", "Uptrend")
    near_support = (
        support_low is not None and support_high is not None and price is not None
        and price <= support_high * 1.02
    )
    if is_uptrend and near_support and rsi is not None and rsi <= 65:
        return "PULLBACK"

    if (
        price is not None and high_20d is not None and price >= high_20d * 0.99
        and rel_vol is not None and rel_vol >= 1.3
        and rsi is not None and 55 <= rsi <= 80
        and trend_label in ("Strong Uptrend", "Uptrend", "Neutral")
    ):
        return "BREAKOUT"

    if (
        price is not None and sma50 not in (None, 0) and sma200 is not None
        and price < sma50 * 0.90 and sma200 is not None and price > sma200 * 0.85
        and rsi is not None and rsi <= 38
    ):
        return "DEEP_CORRECTION"

    return "NONE"


def classify_long_term_thesis(long_term_trend_score, rs: dict, quality: dict | None = None) -> tuple:
    """Long-term conviction — "would I be comfortable still holding this if the swing trade goes
    against me?"

    When real fundamentals are available (Phase 4+), the thesis comes from the audited
    financial-statement quality score and price action is deliberately NOT part of it: price
    already drives the 100-point trading score, and reusing it here would double-count the same
    signal while masquerading as an independent fundamental view.

    Only when fundamentals are genuinely unavailable does this fall back to the technical-only
    proxy, and that fallback is always labeled inline so the two can never be confused.
    """
    if quality and quality.get("long_term_quality_score") is not None:
        score = quality["long_term_quality_score"]
        thesis = quality.get("thesis") or "UNAVAILABLE"
        coverage = quality.get("coverage_pct")
        notes = [f"long-term quality score {score}/100 from {quality.get('source') or 'filings'} "
                 f"fundamentals (fiscal year {quality.get('fiscal_year') or 'n/a'})"]
        if coverage is not None and coverage < 60:
            notes.append(f"only {coverage:.0f}% of quality criteria had reported data")
        return thesis, notes

    if long_term_trend_score is None:
        return "Unknown (insufficient data)", ["long-term trend score unavailable"]
    rs200_label = ((rs or {}).get("labels") or {}).get(200)
    note = "(TECHNICAL-ONLY FALLBACK — fundamentals unavailable, so this is price action, not financials)"
    if long_term_trend_score >= 17 and rs200_label != "Weak":
        return "STRONG " + note, []
    if long_term_trend_score >= 13:
        return "HEALTHY " + note, []
    if long_term_trend_score >= 8:
        return "WATCH " + note, []
    if long_term_trend_score >= 4:
        return "DETERIORATING " + note, []
    return "BROKEN " + note, []


def compute_price_levels(ind: dict) -> dict:
    """Buy/sell levels built from support/resistance ZONES + ATR — never a single point
    presented as exact, and NEVER a stop-loss (that field does not exist anywhere in this
    module or the DB schema). Falls back to ATR-only estimates when zone data is missing,
    and always keeps buy_zone_low <= ideal_buy <= buy_zone_high <= max_entry < target1 <=
    primary_target <= target3 by construction."""
    price = ind.get("reference_price")
    atr = ind.get("atr14")
    support_low, support_high = ind.get("support_low"), ind.get("support_high")
    resistance_low, resistance_high = ind.get("resistance_low"), ind.get("resistance_high")
    swing_high, high_52w = ind.get("swing_high"), ind.get("high_52w")

    if price is None:
        return {k: None for k in (
            "ideal_buy", "buy_zone_low", "buy_zone_high", "max_entry",
            "target1", "primary_target", "target3", "expected_upside_pct",
        )}

    atr_est = atr if atr else price * 0.02  # ~2% fallback "typical daily range" if ATR unavailable

    if support_low is not None and support_high is not None:
        if price <= support_high:
            ideal_buy = price
            buy_zone_low, buy_zone_high = min(support_low, price), max(support_high, price)
        else:
            ideal_buy = support_high
            buy_zone_low, buy_zone_high = support_low, support_high
    else:
        ideal_buy = price - 0.5 * atr_est
        buy_zone_low, buy_zone_high = ideal_buy - 0.5 * atr_est, ideal_buy + 0.25 * atr_est

    max_entry = buy_zone_high + 0.5 * atr_est

    if resistance_low is not None and resistance_low > max_entry:
        target1 = resistance_low
    else:
        target1 = max_entry + 1.5 * atr_est

    candidates = [v for v in (resistance_high, swing_high) if v is not None and v > target1]
    primary_target = min(candidates) if candidates else target1 + 1.5 * atr_est

    stretch_candidates = [v for v in (high_52w,) if v is not None and v > primary_target]
    target3 = max(stretch_candidates) if stretch_candidates else primary_target + 1.5 * atr_est

    expected_upside_pct = round((primary_target - ideal_buy) / ideal_buy * 100, 2) if ideal_buy else None

    return {
        "ideal_buy": round(ideal_buy, 4),
        "buy_zone_low": round(buy_zone_low, 4),
        "buy_zone_high": round(buy_zone_high, 4),
        "max_entry": round(max_entry, 4),
        "target1": round(target1, 4),
        "primary_target": round(primary_target, 4),
        "target3": round(target3, 4),
        "expected_upside_pct": expected_upside_pct,
    }


def classify_signal(total_score, regime_label) -> tuple:
    """Signal label from the total score, with an explicit long-only risk-discipline override:
    a confirmed BEAR market regime caps the signal at WATCH regardless of how well the
    individual stock scores, since this system never shorts and should not be encouraging new
    long entries into a broad downtrend just because one name looks relatively better than
    its peers."""
    label = "AVOID"
    for threshold, name in SIGNAL_THRESHOLDS:
        if total_score >= threshold:
            label = name
            break
    notes = []
    if regime_label == "BEAR" and label in ("STRONG BUY", "BUY"):
        notes.append(f"Signal capped at WATCH: market regime is BEAR (was {label} on stock score alone).")
        label = "WATCH"
    return label, notes


def compute_signal(analysis: dict, regime: dict, news: tuple | None = None,
                    earnings: tuple | None = None, quality: dict | None = None,
                    earnings_info: dict | None = None) -> dict:
    """Main entry point. `analysis` is services.stock_analysis.analyze_stock()'s return value
    (indicators + relative_strength + trend_label etc., flat dict). `regime` is
    services.market_regime.compute_market_regime()'s return value, shared across all 15 stocks.

    Phase 4 additions, all passed in already-computed so this module stays pure (no DB, no HTTP):
      news     : (score, reasons) from services.news_service.score_news
      earnings : (score, reasons) from services.news_service.score_earnings_risk
      quality  : services.fundamentals_service.get_fundamentals() result (for the thesis)
      earnings_info : the raw earnings dict, used for the earnings_blackout flag

    `score_max_currently_available` is computed from what was ACTUALLY evaluated rather than
    hard-coded, so a stock missing news data honestly reports a lower achievable maximum instead
    of being silently penalised against a full 100.

    Returns a flat dict matching (a superset used by) the `signals` table columns."""
    if analysis.get("data_status") == "UNAVAILABLE" or not analysis.get("bars_used"):
        return {
            "ticker": analysis.get("ticker"), "signal_label": "NO DATA",
            "score_total": None, "data_status": "UNAVAILABLE",
            "data_error": analysis.get("data_error"),
            "explanation": "No price/indicator data available — signal cannot be computed.",
        }

    rs = analysis.get("relative_strength", {})

    lt_score, lt_reasons = score_long_term_trend(analysis)
    st_score, st_reasons = score_short_term_trend(analysis)
    mom_score, mom_reasons = score_momentum(analysis)
    pullback_score, pullback_reasons = score_rsi_pullback(analysis)
    vol_score, vol_reasons = score_volume(analysis)
    sr_score, sr_reasons = score_support_resistance(analysis)
    rs_score, rs_reasons = score_relative_strength(rs)
    regime_score, regime_reasons = score_market_regime(regime)

    news_score, news_reasons = news if news else (None, [PENDING_PHASE4_NOTE])
    earnings_score, earnings_reasons = earnings if earnings else (None, [PENDING_PHASE4_NOTE])

    component_scores = {
        "score_long_trend": lt_score, "score_short_trend": st_score, "score_momentum": mom_score,
        "score_rsi_pullback": pullback_score, "score_volume": vol_score,
        "score_support_resistance": sr_score, "score_relative_strength": rs_score,
        "score_market_regime": regime_score,
        "score_news": news_score, "score_earnings_risk": earnings_score,
    }
    total = round(sum(v for v in component_scores.values() if v is not None), 2)

    # Achievable maximum = sum of the weights of the components that actually had data.
    weight_by_key = {
        "score_long_trend": 20, "score_short_trend": 10, "score_momentum": 15,
        "score_rsi_pullback": 10, "score_volume": 10, "score_support_resistance": 10,
        "score_relative_strength": 10, "score_market_regime": 5, "score_news": 5,
        "score_earnings_risk": 5,
    }
    max_available = sum(w for k, w in weight_by_key.items() if component_scores.get(k) is not None)
    unavailable = [k for k in weight_by_key if component_scores.get(k) is None]

    signal_label, override_notes = classify_signal(total, (regime or {}).get("regime"))
    strategy_setup = classify_strategy_setup(analysis)
    long_term_thesis, thesis_notes = classify_long_term_thesis(lt_score, rs, quality)
    price_levels = compute_price_levels(analysis)

    # Earnings blackout: flagged only from a real (if estimated) date, never assumed.
    blackout = 0
    days_to_earnings = (earnings_info or {}).get("days_until_estimated_report")
    if days_to_earnings is not None and 0 <= days_to_earnings <= 5:
        blackout = 1

    def _fmt(score, maximum):
        return f"{score if score is not None else '—'}/{maximum}"

    all_reasons = (
        [f"[Long-Term Trend {_fmt(lt_score, 20)}] " + "; ".join(lt_reasons)]
        + [f"[Short-Term Trend {_fmt(st_score, 10)}] " + "; ".join(st_reasons)]
        + [f"[Momentum {_fmt(mom_score, 15)}] " + "; ".join(mom_reasons)]
        + [f"[RSI Pullback Quality {_fmt(pullback_score, 10)}] " + "; ".join(pullback_reasons)]
        + [f"[Volume {_fmt(vol_score, 10)}] " + "; ".join(vol_reasons)]
        + [f"[Support/Resistance {_fmt(sr_score, 10)}] " + "; ".join(sr_reasons)]
        + [f"[Relative Strength {_fmt(rs_score, 10)}] " + "; ".join(rs_reasons)]
        + [f"[Market Regime {_fmt(regime_score, 5)}] " + "; ".join(regime_reasons)]
        + [f"[News {_fmt(news_score, 5)}] " + "; ".join(news_reasons)]
        + [f"[Earnings Risk {_fmt(earnings_score, 5)}] " + "; ".join(earnings_reasons)]
        + override_notes + thesis_notes
    )
    if unavailable:
        all_reasons.append(
            f"NOTE: {len(unavailable)} component(s) had no data and were excluded from both the "
            f"score and the achievable maximum ({max_available}/100), rather than being scored 0."
        )
    if blackout:
        all_reasons.append(
            "EARNINGS BLACKOUT: an estimated earnings report falls within ~5 days. Holding a "
            "swing position through earnings is an overnight gap risk."
        )

    return {
        "ticker": analysis.get("ticker"),
        "data_status": "OK",
        "strategy_version": STRATEGY_VERSION,
        "score_total": total,
        "score_max_currently_available": max_available,
        **component_scores,
        "signal_label": signal_label,
        "strategy_setup": strategy_setup,
        "current_price": analysis.get("reference_price"),
        **price_levels,
        "long_term_thesis": long_term_thesis,
        "long_term_quality": (quality or {}).get("long_term_quality_score"),
        "market_regime": (regime or {}).get("regime"),
        "earnings_blackout": blackout,
        "days_until_estimated_earnings": days_to_earnings,
        "explanation": " | ".join(all_reasons),
        "trend_label": analysis.get("trend_label"),
        "sector_etf": analysis.get("sector_etf"),
    }


def persist_signal(db, signal: dict):
    """Upserts into `signals` — one row per ticker, overwritten on each recompute (this is the
    CURRENT signal; append-only signal_history is a Phase 6 concern). No-ops for NO DATA /
    UNAVAILABLE signals — there's nothing meaningful to store, and storing a null-filled row
    would just be noise the UI has to filter back out."""
    if signal.get("data_status") != "OK" or signal.get("score_total") is None:
        return

    row = {
        "ticker": signal["ticker"],
        "score_total": signal.get("score_total"),
        "score_long_trend": signal.get("score_long_trend"),
        "score_short_trend": signal.get("score_short_trend"),
        "score_momentum": signal.get("score_momentum"),
        "score_rsi_pullback": signal.get("score_rsi_pullback"),
        "score_volume": signal.get("score_volume"),
        "score_support_resistance": signal.get("score_support_resistance"),
        "score_relative_strength": signal.get("score_relative_strength"),
        "score_market_regime": signal.get("score_market_regime"),
        "score_news": signal.get("score_news"),
        "score_earnings_risk": signal.get("score_earnings_risk"),
        "signal_label": signal.get("signal_label"),
        "strategy_setup": signal.get("strategy_setup"),
        "current_price": signal.get("current_price"),
        "ideal_buy": signal.get("ideal_buy"),
        "buy_zone_low": signal.get("buy_zone_low"),
        "buy_zone_high": signal.get("buy_zone_high"),
        "max_entry": signal.get("max_entry"),
        "target1": signal.get("target1"),
        "primary_target": signal.get("primary_target"),
        "target3": signal.get("target3"),
        "expected_upside_pct": signal.get("expected_upside_pct"),
        "long_term_quality": signal.get("long_term_quality"),
        "long_term_thesis": signal.get("long_term_thesis"),
        "market_regime": signal.get("market_regime"),
        "earnings_blackout": signal.get("earnings_blackout", 0),
        "explanation": signal.get("explanation"),
        "strategy_version": signal.get("strategy_version"),
    }
    columns = list(row.keys())
    placeholders = ", ".join(f":{c}" for c in columns)
    update_clause = ", ".join(f"{c}=excluded.{c}" for c in columns if c != "ticker")
    db.execute(
        f"""
        INSERT INTO signals ({", ".join(columns)}, computed_at)
        VALUES ({placeholders}, datetime('now'))
        ON CONFLICT(ticker) DO UPDATE SET {update_clause}, computed_at=datetime('now')
        """,
        row,
    )
    db.commit()
