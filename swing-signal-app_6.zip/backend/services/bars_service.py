"""
Bar caching/fetch layer sitting between the indicator engine and MarketDataProvider.

Responsibilities:
- Decide whether cached bars in `market_bars` are fresh enough to reuse, or need refetching
  from the provider (daily bars only need to update once a session has closed; there's no
  reason to hit Alpaca on every dashboard poll for data that only changes once a day).
- On a provider failure, fall back to whatever is cached rather than crashing the whole
  request — but always report that honestly (`from_cache_stale=True`), never pretend a
  cached bar set is fresh live data.
- Hand back a plain pandas DataFrame so services/indicators.py never has to know this table
  or the provider abstraction exist.
"""
from datetime import datetime, timedelta, timezone

import pandas as pd

from providers import ProviderError
from services.market_service import get_provider

# How long cached bars are considered fresh before we bother refetching, per timeframe.
# Daily bars only change once a session closes, so a multi-hour TTL is entirely reasonable
# for a swing-trading app (see project spec: "signal stability", "data delay" sections —
# this is explicitly NOT a scalping system).
FRESHNESS_TTL = {
    "1Day": timedelta(hours=6),
    "4Hour": timedelta(hours=2),
    "1Hour": timedelta(hours=1),
    "30Min": timedelta(minutes=20),
    "15Min": timedelta(minutes=10),
}

# How far back to request bars, per timeframe — enough for SMA200 + slope + 52-week hi/lo
# with comfortable buffer (holidays/weekends already thin out calendar days vs trading days).
LOOKBACK_DAYS = {
    "1Day": 560,     # ~2.2 calendar years -> ~380+ trading days
    "4Hour": 120,
    "1Hour": 60,
    "30Min": 30,
    "15Min": 15,
}

MIN_BARS_FOR_FULL_INDICATORS = 210


def _fetch_cached(db, ticker: str, timeframe: str) -> pd.DataFrame:
    rows = db.execute(
        "SELECT ts, open, high, low, close, volume, trade_count, vwap, fetched_at "
        "FROM market_bars WHERE ticker = ? AND timeframe = ? ORDER BY ts ASC",
        (ticker, timeframe),
    ).fetchall()
    if not rows:
        return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])
    return pd.DataFrame([dict(r) for r in rows])


def _cache_is_fresh(cached: pd.DataFrame, timeframe: str) -> bool:
    if cached.empty or len(cached) < 5:
        return False
    last_fetched = pd.to_datetime(cached["fetched_at"]).max()
    if last_fetched.tzinfo is None:
        last_fetched = last_fetched.tz_localize("UTC")
    ttl = FRESHNESS_TTL.get(timeframe, timedelta(hours=6))
    return (datetime.now(timezone.utc) - last_fetched) < ttl


def _store_bars(db, ticker: str, timeframe: str, bars):
    now = datetime.now(timezone.utc).isoformat()
    for b in bars:
        db.execute(
            """
            INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume,
                                      trade_count, vwap, source, fetched_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'alpaca', ?)
            ON CONFLICT(ticker, timeframe, ts) DO UPDATE SET
                open=excluded.open, high=excluded.high, low=excluded.low, close=excluded.close,
                volume=excluded.volume, trade_count=excluded.trade_count, vwap=excluded.vwap,
                fetched_at=excluded.fetched_at
            """,
            (ticker, timeframe, b.ts.isoformat(), b.open, b.high, b.low, b.close, b.volume,
             b.trade_count, b.vwap, now),
        )
    db.commit()


def get_bars_df(db, ticker: str, timeframe: str = "1Day", force_refresh: bool = False):
    """
    Returns (df, meta). `df` has columns [ts, open, high, low, close, volume] sorted
    ascending. `meta` describes provenance honestly:
        {
          "source": "alpaca" | "cache",
          "fresh": bool,           # was a live fetch performed (vs serving cache as-is)?
          "stale_fallback": bool,  # provider failed and we fell back to (possibly old) cache
          "error": str | None,
        }
    """
    cached = _fetch_cached(db, ticker, timeframe)
    meta = {"source": "cache", "fresh": False, "stale_fallback": False, "error": None}

    if not force_refresh and _cache_is_fresh(cached, timeframe):
        cols = ["ts", "open", "high", "low", "close", "volume"]
        return cached[cols].reset_index(drop=True), meta

    lookback = LOOKBACK_DAYS.get(timeframe, 400)
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=lookback)

    try:
        provider = get_provider()
        bars = provider.get_bars(ticker, timeframe, start, end, limit=2000)
        if bars:
            _store_bars(db, ticker, timeframe, bars)
        refreshed = _fetch_cached(db, ticker, timeframe)
        cols = ["ts", "open", "high", "low", "close", "volume"]
        meta.update(source="alpaca", fresh=True)
        return refreshed[cols].reset_index(drop=True), meta
    except ProviderError as e:
        meta.update(error=str(e))
        if not cached.empty:
            meta["stale_fallback"] = True
            cols = ["ts", "open", "high", "low", "close", "volume"]
            return cached[cols].reset_index(drop=True), meta
        cols = ["ts", "open", "high", "low", "close", "volume"]
        return pd.DataFrame(columns=cols), meta
