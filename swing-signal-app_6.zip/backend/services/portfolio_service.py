"""
Phase 5: manual trade journal, holdings, and P&L.

Every trade in this system is entered BY HAND by the user, after they have executed it
themselves in a separate brokerage application. Nothing in this module (or anywhere in this
app) places, modifies, or cancels an order. There is no broker write path.

Accounting: FIFO lot matching. Buying 100 at $10 then 100 at $20 and selling 100 realises the
$10 lot first — which matches how most brokers and HMRC-style reporting treat disposals far
better than a blended average would, and it makes partial sales of a scaled-in position
behave correctly.

Long-only is enforced at the data layer: a SELL that exceeds the quantity actually held is
recorded but flagged loudly, because in a long-only system that state means the journal has a
data-entry error — it does NOT mean a short position was opened.
"""
from datetime import datetime, timezone

SIDE_BUY = "BUY"
SIDE_SELL = "SELL"


def add_trade(db, ticker: str, side: str, trade_date: str, quantity: float, price: float,
              fees: float = 0.0, notes: str | None = None,
              fx_rate_usd_gbp: float | None = None) -> dict:
    """Records one manually-executed trade. Validates inputs strictly rather than silently
    coercing them — a typo'd quantity should be rejected, not quietly stored."""
    side = (side or "").upper().strip()
    ticker = (ticker or "").upper().strip()

    if side not in (SIDE_BUY, SIDE_SELL):
        raise ValueError("side must be BUY or SELL (this system never shorts).")
    try:
        quantity = float(quantity)
        price = float(price)
        fees = float(fees or 0.0)
    except (TypeError, ValueError):
        raise ValueError("quantity, price and fees must be numbers.")
    if quantity <= 0:
        raise ValueError("quantity must be greater than zero.")
    if price <= 0:
        raise ValueError("price must be greater than zero.")
    if fees < 0:
        raise ValueError("fees cannot be negative.")
    if not trade_date:
        trade_date = datetime.now(timezone.utc).date().isoformat()

    exists = db.execute("SELECT 1 FROM stocks WHERE ticker = ?", (ticker,)).fetchone()
    if not exists:
        raise ValueError(f"{ticker} is not one of the 15 tracked stocks.")

    warnings = []
    if side == SIDE_SELL:
        held = get_position_quantity(db, ticker)
        if quantity > held + 1e-9:
            warnings.append(
                f"You are recording a sale of {quantity:g} {ticker} but the journal only shows "
                f"{held:g} held. This is long-only — that difference is a data-entry error, not "
                f"a short position. The trade was still recorded so you can correct the history."
            )

    cur = db.execute(
        "INSERT INTO trades (ticker, side, trade_date, quantity, price, fees, notes, "
        "fx_rate_usd_gbp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (ticker, side, trade_date, quantity, price, fees, notes, fx_rate_usd_gbp),
    )
    db.commit()
    _rebuild_position(db, ticker)
    return {"id": cur.lastrowid, "ticker": ticker, "side": side, "warnings": warnings}


def delete_trade(db, trade_id: int) -> bool:
    row = db.execute("SELECT ticker FROM trades WHERE id = ?", (trade_id,)).fetchone()
    if not row:
        return False
    db.execute("DELETE FROM trades WHERE id = ?", (trade_id,))
    db.commit()
    _rebuild_position(db, row["ticker"])
    return True


def get_trades(db, ticker: str | None = None) -> list:
    if ticker:
        rows = db.execute(
            "SELECT * FROM trades WHERE ticker = ? ORDER BY trade_date DESC, id DESC",
            (ticker.upper(),)).fetchall()
    else:
        rows = db.execute("SELECT * FROM trades ORDER BY trade_date DESC, id DESC").fetchall()
    return [dict(r) for r in rows]


def _fifo_walk(trades: list) -> dict:
    """Walk trades oldest-first, matching sells against buy lots FIFO.

    Returns open lots, total realised P&L, and per-sale detail. Fees are included on both sides:
    a buy's fees increase cost basis, a sale's fees reduce proceeds — so the realised figure is
    what actually landed, not a gross number that flatters the result.
    """
    ordered = sorted(trades, key=lambda t: (t["trade_date"], t["id"]))
    lots = []            # [{qty, price, fee_per_share}]
    realized = 0.0
    sales = []
    oversold = 0.0

    for t in ordered:
        qty, price, fees = float(t["quantity"]), float(t["price"]), float(t["fees"] or 0.0)
        if t["side"] == SIDE_BUY:
            lots.append({"qty": qty, "price": price, "fee_per_share": (fees / qty) if qty else 0.0})
            continue

        remaining = qty
        proceeds = qty * price - fees
        cost = 0.0
        matched = 0.0
        while remaining > 1e-9 and lots:
            lot = lots[0]
            take = min(remaining, lot["qty"])
            cost += take * (lot["price"] + lot["fee_per_share"])
            lot["qty"] -= take
            remaining -= take
            matched += take
            if lot["qty"] <= 1e-9:
                lots.pop(0)

        if remaining > 1e-9:
            # Sold more than the journal shows as held — recorded, but never treated as a short.
            oversold += remaining

        sale_proceeds = proceeds * (matched / qty) if qty else 0.0
        pnl = sale_proceeds - cost
        realized += pnl
        sales.append({
            "trade_id": t["id"], "ticker": t["ticker"], "trade_date": t["trade_date"],
            "quantity": matched, "price": price, "proceeds": round(sale_proceeds, 2),
            "cost_basis": round(cost, 2), "realized_pnl": round(pnl, 2),
            "realized_pnl_pct": round(pnl / cost * 100, 2) if cost else None,
        })

    open_qty = sum(l["qty"] for l in lots)
    open_cost = sum(l["qty"] * (l["price"] + l["fee_per_share"]) for l in lots)
    return {
        "open_quantity": round(open_qty, 6),
        "avg_entry_price": round(open_cost / open_qty, 4) if open_qty > 1e-9 else None,
        "open_cost_basis": round(open_cost, 2),
        "realized_pnl": round(realized, 2),
        "sales": sales,
        "oversold_quantity": round(oversold, 6),
    }


def get_position_quantity(db, ticker: str) -> float:
    return _fifo_walk(get_trades(db, ticker))["open_quantity"]


def _rebuild_position(db, ticker: str):
    result = _fifo_walk(get_trades(db, ticker))
    if result["open_quantity"] <= 1e-9:
        db.execute("DELETE FROM portfolio_positions WHERE ticker = ?", (ticker,))
    else:
        db.execute(
            """
            INSERT INTO portfolio_positions (ticker, quantity, avg_entry_price, updated_at)
            VALUES (?, ?, ?, datetime('now'))
            ON CONFLICT(ticker) DO UPDATE SET quantity=excluded.quantity,
                avg_entry_price=excluded.avg_entry_price, updated_at=excluded.updated_at
            """,
            (ticker, result["open_quantity"], result["avg_entry_price"]),
        )
    db.commit()


def get_portfolio(db, prices_by_ticker: dict | None = None, fx_rate: dict | None = None) -> dict:
    """Current holdings with unrealised P&L, plus realised P&L across all closed trades.

    `prices_by_ticker` maps ticker -> latest price. Any ticker without a live price keeps its
    cost basis and reports market value as None rather than falling back to the entry price,
    which would silently render an unrealised P&L of exactly zero and look like real data.
    """
    prices_by_ticker = prices_by_ticker or {}
    tickers = [r["ticker"] for r in
               db.execute("SELECT DISTINCT ticker FROM trades ORDER BY ticker").fetchall()]

    holdings = []
    total_cost = 0.0
    total_value = 0.0
    total_realized = 0.0
    priced_count = 0
    warnings = []

    for ticker in tickers:
        walk = _fifo_walk(get_trades(db, ticker))
        total_realized += walk["realized_pnl"]
        if walk["oversold_quantity"] > 1e-9:
            warnings.append(
                f"{ticker}: journal records selling {walk['oversold_quantity']:g} more shares "
                f"than were bought. Check the trade history — this app is long-only.")
        if walk["open_quantity"] <= 1e-9:
            continue

        price = prices_by_ticker.get(ticker)
        market_value = (price * walk["open_quantity"]) if price is not None else None
        unrealized = (market_value - walk["open_cost_basis"]) if market_value is not None else None

        total_cost += walk["open_cost_basis"]
        if market_value is not None:
            total_value += market_value
            priced_count += 1

        holdings.append({
            "ticker": ticker,
            "quantity": walk["open_quantity"],
            "avg_entry_price": walk["avg_entry_price"],
            "cost_basis": walk["open_cost_basis"],
            "current_price": price,
            "market_value": round(market_value, 2) if market_value is not None else None,
            "unrealized_pnl": round(unrealized, 2) if unrealized is not None else None,
            "unrealized_pnl_pct": (
                round(unrealized / walk["open_cost_basis"] * 100, 2)
                if (unrealized is not None and walk["open_cost_basis"]) else None),
            "price_status": "OK" if price is not None else "UNAVAILABLE",
        })

    holdings.sort(key=lambda h: h["market_value"] if h["market_value"] is not None else -1,
                  reverse=True)

    unpriced = [h["ticker"] for h in holdings if h["current_price"] is None]
    if unpriced:
        warnings.append(
            f"No live price available for {', '.join(unpriced)} — those holdings are excluded "
            f"from the portfolio total, which is therefore incomplete rather than wrong.")

    summary = {
        "total_cost_basis": round(total_cost, 2),
        "total_market_value": round(total_value, 2) if priced_count else None,
        "total_unrealized_pnl": round(total_value - sum(
            h["cost_basis"] for h in holdings if h["current_price"] is not None), 2)
            if priced_count else None,
        "total_realized_pnl": round(total_realized, 2),
        "positions_held": len(holdings),
        "positions_priced": priced_count,
    }
    if summary["total_unrealized_pnl"] is not None:
        priced_cost = sum(h["cost_basis"] for h in holdings if h["current_price"] is not None)
        summary["total_unrealized_pnl_pct"] = (
            round(summary["total_unrealized_pnl"] / priced_cost * 100, 2) if priced_cost else None)
    else:
        summary["total_unrealized_pnl_pct"] = None

    out = {"holdings": holdings, "summary": summary, "warnings": warnings, "currency": "USD"}
    if fx_rate and fx_rate.get("rate"):
        out["gbp"] = _to_gbp(summary, fx_rate)
        out["fx_rate"] = fx_rate
    return out


def _to_gbp(summary: dict, fx_rate: dict) -> dict:
    """Converts the USD summary using an explicitly-sourced, dated rate. The rate itself is
    always returned alongside so a GBP figure can be traced to exactly what produced it — the
    app never applies an assumed or hard-coded exchange rate."""
    r = fx_rate["rate"]
    def conv(v):
        return round(v * r, 2) if v is not None else None
    return {
        "total_cost_basis": conv(summary.get("total_cost_basis")),
        "total_market_value": conv(summary.get("total_market_value")),
        "total_unrealized_pnl": conv(summary.get("total_unrealized_pnl")),
        "total_realized_pnl": conv(summary.get("total_realized_pnl")),
        "rate_used": r,
        "rate_source": fx_rate.get("source"),
        "rate_as_of": fx_rate.get("as_of"),
    }


# ---------------------------------------------------------------- FX

def set_fx_rate(db, rate: float, source: str = "manual", as_of: str | None = None) -> dict:
    try:
        rate = float(rate)
    except (TypeError, ValueError):
        raise ValueError("FX rate must be a number.")
    if not (0 < rate < 100):
        raise ValueError("FX rate looks implausible — expected USD->GBP, e.g. 0.79.")
    as_of = as_of or datetime.now(timezone.utc).isoformat()
    db.execute(
        """
        INSERT INTO fx_rates (pair, rate, source, as_of, updated_at)
        VALUES ('USDGBP', ?, ?, ?, datetime('now'))
        ON CONFLICT(pair) DO UPDATE SET rate=excluded.rate, source=excluded.source,
            as_of=excluded.as_of, updated_at=excluded.updated_at
        """,
        (rate, source, as_of),
    )
    db.commit()
    return get_fx_rate(db)


def get_fx_rate(db) -> dict | None:
    row = db.execute("SELECT * FROM fx_rates WHERE pair = 'USDGBP'").fetchone()
    return dict(row) if row else None
