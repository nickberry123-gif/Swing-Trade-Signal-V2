"""
Technical indicator engine — pure calculation, no I/O, no Alpaca-specific code.

Input: a pandas DataFrame of OHLCV bars for ONE ticker/timeframe, sorted ascending by
timestamp, with columns ['ts', 'open', 'high', 'low', 'close', 'volume']. Output: a flat
dict matching (a superset used by) the `technical_indicators` table columns.

Design rules followed throughout (per project spec):
- Every indicator is a real, standard, well-known formula (Wilder's RSI/ATR/ADX, standard
  MACD/Bollinger/stochastic-RSI) — nothing invented.
- Values that can't be computed yet (not enough bars) are None, never a guessed/fabricated
  number. `bars_used` and `warnings` in the output tell the caller exactly why.
- No lookahead: every rolling/ewm window only uses bars up to and including the current row,
  so a value computed "as of" bar i never uses bar i+1..n. This matters most for Phase 7
  (backtesting) but the rule holds here from day one rather than being retrofitted later.
- Swing highs/lows require confirmation bars on BOTH sides, so the two most recent bars can
  never be reported as swing points — that would be repainting (the point could still be
  invalidated by the next bar or two).
"""
import json
import math

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ["ts", "open", "high", "low", "close", "volume"]


def _last_or_none(series: pd.Series):
    if series is None or len(series) == 0:
        return None
    val = series.iloc[-1]
    if val is None or (isinstance(val, float) and math.isnan(val)):
        return None
    return round(float(val), 6)


def compute_rsi(close: pd.Series, period: int) -> pd.Series:
    """Wilder's RSI (the standard RSI formula, using Wilder smoothing rather than a
    simple moving average of gains/losses).

    Division-by-zero edge cases (avg_loss == 0) are handled explicitly rather than left to
    produce NaN/inf: a straight run of up-days is RSI 100, and a completely flat price
    (avg_gain == avg_loss == 0) is RSI 50 (neutral), not 100 — these are two different
    market states and must not collapse to the same number.
    """
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    rsi_vals = np.where(avg_loss == 0, np.where(avg_gain == 0, 50.0, 100.0), rsi)
    return pd.Series(rsi_vals, index=close.index)


def compute_macd(close: pd.Series, fast=12, slow=26, signal=9):
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd = ema_fast - ema_slow
    macd_signal = macd.ewm(span=signal, adjust=False).mean()
    macd_hist = macd - macd_signal
    return macd, macd_signal, macd_hist


def compute_true_range(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low),
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr


def compute_atr(high: pd.Series, low: pd.Series, close: pd.Series, period=14) -> pd.Series:
    tr = compute_true_range(high, low, close)
    return tr.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()


def compute_adx(high: pd.Series, low: pd.Series, close: pd.Series, period=14) -> pd.Series:
    """Wilder's ADX. Returns the ADX line only (DI+/DI- are intermediate)."""
    up_move = high.diff()
    down_move = -low.diff()
    plus_dm = pd.Series(np.where((up_move > down_move) & (up_move > 0), up_move, 0.0), index=high.index)
    minus_dm = pd.Series(np.where((down_move > up_move) & (down_move > 0), down_move, 0.0), index=high.index)

    atr = compute_atr(high, low, close, period)
    plus_di = 100 * (plus_dm.ewm(alpha=1 / period, min_periods=period, adjust=False).mean() / atr.replace(0, np.nan))
    minus_di = 100 * (minus_dm.ewm(alpha=1 / period, min_periods=period, adjust=False).mean() / atr.replace(0, np.nan))
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    adx = dx.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    return adx


def compute_stoch_rsi(rsi: pd.Series, period=14) -> pd.Series:
    rsi_min = rsi.rolling(period).min()
    rsi_max = rsi.rolling(period).max()
    denom = (rsi_max - rsi_min).replace(0, np.nan)
    stoch = (rsi - rsi_min) / denom
    return (stoch * 100).clip(0, 100)


def compute_bollinger(close: pd.Series, period=20, num_std=2.0):
    middle = close.rolling(period).mean()
    std = close.rolling(period).std()
    upper = middle + num_std * std
    lower = middle - num_std * std
    width = (upper - lower) / middle.replace(0, np.nan)
    return upper, middle, lower, width


def compute_historical_volatility(close: pd.Series, period=20, trading_days_per_year=252) -> pd.Series:
    log_ret = np.log(close / close.shift(1))
    return log_ret.rolling(period).std() * math.sqrt(trading_days_per_year) * 100


def find_swing_points(high: pd.Series, low: pd.Series, window=2):
    """Fractal swing highs/lows: bar i is a swing high if its high is strictly greater than
    the `window` bars on each side; symmetric for swing lows. The most recent `window` bars
    can never qualify (their right-side neighbors don't exist yet) — this is intentional,
    not a bug: a swing point is only real once confirmed by subsequent price action."""
    n = len(high)
    swing_high = pd.Series([False] * n, index=high.index)
    swing_low = pd.Series([False] * n, index=low.index)
    h = high.values
    l = low.values
    for i in range(window, n - window):
        left_h, right_h = h[i - window:i], h[i + 1:i + window + 1]
        if h[i] > left_h.max() and h[i] > right_h.max():
            swing_high.iloc[i] = True
        left_l, right_l = l[i - window:i], l[i + 1:i + window + 1]
        if l[i] < left_l.min() and l[i] < right_l.min():
            swing_low.iloc[i] = True
    return swing_high, swing_low


def _cluster_levels(levels: list[float], tolerance_pct: float = 1.5) -> list[list[float]]:
    """Group price levels within `tolerance_pct` of each other into clusters."""
    if not levels:
        return []
    levels = sorted(levels)
    clusters = [[levels[0]]]
    for lvl in levels[1:]:
        if abs(lvl - clusters[-1][-1]) / clusters[-1][-1] * 100 <= tolerance_pct:
            clusters[-1].append(lvl)
        else:
            clusters.append([lvl])
    return clusters


def compute_support_resistance(df: pd.DataFrame, swing_high: pd.Series, swing_low: pd.Series,
                                sma50: float | None, sma200: float | None,
                                high_20d: float | None, low_20d: float | None,
                                high_50d: float | None, low_50d: float | None,
                                current_price: float, atr: float | None):
    """
    Support/resistance as ZONES, not single prices, built from: recent confirmed swing
    lows/highs, moving averages, and 20d/50d extremes — per spec, explicitly NOT a fixed
    percentage and NOT a single exact price.
    """
    recent_lows = df.loc[swing_low, "low"].tail(10).tolist()
    recent_highs = df.loc[swing_high, "high"].tail(10).tolist()

    support_candidates = [lvl for lvl in recent_lows if lvl < current_price]
    resistance_candidates = [lvl for lvl in recent_highs if lvl > current_price]
    for ma in (sma50, sma200):
        if ma is not None:
            (support_candidates if ma < current_price else resistance_candidates).append(ma)
    for lvl in (high_20d, low_20d, high_50d, low_50d):
        if lvl is not None:
            (support_candidates if lvl < current_price else resistance_candidates).append(lvl)

    support_low = support_high = resistance_low = resistance_high = None

    if support_candidates:
        clusters = _cluster_levels(support_candidates)
        nearest = max(clusters, key=lambda c: max(c))  # cluster closest to price = highest values
        support_low, support_high = min(nearest), max(nearest)
        if support_low == support_high and atr:
            support_low, support_high = support_low - 0.25 * atr, support_high + 0.25 * atr

    if resistance_candidates:
        clusters = _cluster_levels(resistance_candidates)
        nearest = min(clusters, key=lambda c: min(c))  # cluster closest to price = lowest values
        resistance_low, resistance_high = min(nearest), max(nearest)
        if resistance_low == resistance_high and atr:
            resistance_low, resistance_high = resistance_low - 0.25 * atr, resistance_high + 0.25 * atr

    return support_low, support_high, resistance_low, resistance_high


def classify_trend(price: float | None, sma50: float | None, sma200: float | None,
                    sma200_slope: float | None) -> tuple[str, list[str]]:
    """
    Qualitative trend label built from a small set of transparent conditions, scored rather
    than gated on any single binary rule — per spec: "must NOT blindly reject a stock if one
    condition is temporarily violated. Score the overall trend rather than using binary rules."
    """
    reasons = []
    score = 0
    total = 0

    if price is not None and sma200 is not None:
        total += 1
        if price > sma200:
            score += 1
            reasons.append(f"price (${price:.2f}) is above the 200-day SMA (${sma200:.2f})")
        else:
            reasons.append(f"price (${price:.2f}) is below the 200-day SMA (${sma200:.2f})")

    if sma200_slope is not None:
        total += 1
        if sma200_slope > 0:
            score += 1
            reasons.append(f"200-day SMA is rising ({sma200_slope:+.2f}% over 10 bars)")
        else:
            reasons.append(f"200-day SMA is flat or falling ({sma200_slope:+.2f}% over 10 bars)")

    if sma50 is not None and sma200 is not None:
        total += 1
        if sma50 > sma200:
            score += 1
            reasons.append(f"50-day SMA (${sma50:.2f}) is above the 200-day SMA (${sma200:.2f})")
        else:
            reasons.append(f"50-day SMA (${sma50:.2f}) is below the 200-day SMA (${sma200:.2f})")

    if price is not None and sma50 is not None:
        total += 1
        if price > sma50:
            score += 1
            reasons.append(f"price is above the 50-day SMA (${sma50:.2f})")
        else:
            reasons.append(f"price is below the 50-day SMA (${sma50:.2f})")

    if total == 0:
        return "Unknown (insufficient data)", ["Not enough bars to evaluate trend."]

    ratio = score / total
    if ratio >= 0.9:
        label = "Strong Uptrend"
    elif ratio >= 0.65:
        label = "Uptrend"
    elif ratio >= 0.4:
        label = "Neutral"
    elif ratio >= 0.15:
        label = "Downtrend"
    else:
        label = "Strong Downtrend"
    return label, reasons


def classify_volume_trend(volume: pd.Series, avg5: float | None, avg20: float | None) -> str | None:
    if avg5 is None or avg20 is None or avg20 == 0:
        return None
    ratio = avg5 / avg20
    if ratio >= 1.25:
        return "Increasing"
    if ratio <= 0.8:
        return "Decreasing"
    return "Flat"


def compute_all_indicators(df: pd.DataFrame, current_price: float | None = None) -> dict:
    """
    Compute the full indicator set for one ticker/timeframe from its OHLCV bar history.
    `current_price` optionally overrides the last bar's close (e.g. a fresher intraday
    quote) for price-relative calcs like trend/support-resistance; defaults to last close.
    """
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"bars DataFrame missing required columns: {missing}")

    df = df.sort_values("ts").reset_index(drop=True)
    bars_used = len(df)
    warnings = []

    if bars_used == 0:
        return {"bars_used": 0, "warnings": ["No bars available."]}

    close, high, low, volume = df["close"], df["high"], df["low"], df["volume"]
    price = current_price if current_price is not None else float(close.iloc[-1])

    ema20 = close.ewm(span=20, adjust=False).mean()
    ema50 = close.ewm(span=50, adjust=False).mean()
    sma20 = close.rolling(20).mean()
    sma50 = close.rolling(50).mean()
    sma100 = close.rolling(100).mean()
    sma200 = close.rolling(200).mean()

    sma200_slope = None
    if bars_used >= 210:
        prev = sma200.iloc[-11]
        cur = sma200.iloc[-1]
        if prev and not math.isnan(prev) and prev != 0:
            sma200_slope = round(float((cur - prev) / prev * 100), 4)

    rsi14 = compute_rsi(close, 14)
    rsi7 = compute_rsi(close, 7)
    macd, macd_signal, macd_hist = compute_macd(close)
    adx = compute_adx(high, low, close, 14)
    roc10 = (close - close.shift(10)) / close.shift(10) * 100
    stoch_rsi = compute_stoch_rsi(rsi14, 14)
    atr14 = compute_atr(high, low, close, 14)
    atr_pct = (atr14 / close) * 100
    bb_upper, bb_middle, bb_lower, bb_width = compute_bollinger(close, 20, 2.0)
    hist_vol = compute_historical_volatility(close, 20)

    avg_volume_20d = volume.rolling(20).mean()
    avg_volume_5d = volume.rolling(5).mean()
    relative_volume = None
    if not avg_volume_20d.empty and avg_volume_20d.iloc[-1] and not math.isnan(avg_volume_20d.iloc[-1]) and avg_volume_20d.iloc[-1] > 0:
        relative_volume = round(float(volume.iloc[-1] / avg_volume_20d.iloc[-1]), 4)
    volume_trend = classify_volume_trend(volume, _last_or_none(avg_volume_5d), _last_or_none(avg_volume_20d))

    high_20d = high.rolling(20).max()
    low_20d = low.rolling(20).min()
    high_50d = high.rolling(50).max()
    low_50d = low.rolling(50).min()
    high_52w = high.rolling(min(252, bars_used)).max()
    low_52w = low.rolling(min(252, bars_used)).min()

    swing_high_mask, swing_low_mask = find_swing_points(high, low, window=2)
    last_swing_high = _last_or_none(high[swing_high_mask])
    last_swing_low = _last_or_none(low[swing_low_mask])

    sma50_last, sma200_last = _last_or_none(sma50), _last_or_none(sma200)
    support_low, support_high, resistance_low, resistance_high = compute_support_resistance(
        df, swing_high_mask, swing_low_mask, sma50_last, sma200_last,
        _last_or_none(high_20d), _last_or_none(low_20d),
        _last_or_none(high_50d), _last_or_none(low_50d),
        price, _last_or_none(atr14),
    )

    trend_label, trend_reasons = classify_trend(price, sma50_last, sma200_last, sma200_slope)

    if bars_used < 200:
        warnings.append(
            f"Only {bars_used} bars available — SMA200/52-week fields need ~200+ and may be null "
            f"or based on a shorter window than intended."
        )
    if bars_used < 50:
        warnings.append(f"Only {bars_used} bars available — most indicators are unreliable below ~50 bars.")

    return {
        "ema20": _last_or_none(ema20), "ema50": _last_or_none(ema50),
        "sma20": _last_or_none(sma20), "sma50": sma50_last,
        "sma100": _last_or_none(sma100), "sma200": sma200_last,
        "sma200_slope": sma200_slope,
        "rsi14": _last_or_none(rsi14), "rsi7": _last_or_none(rsi7),
        "macd": _last_or_none(macd), "macd_signal": _last_or_none(macd_signal), "macd_hist": _last_or_none(macd_hist),
        "adx": _last_or_none(adx), "roc": _last_or_none(roc10), "stoch_rsi": _last_or_none(stoch_rsi),
        "atr14": _last_or_none(atr14), "atr_pct": _last_or_none(atr_pct),
        "bb_upper": _last_or_none(bb_upper), "bb_middle": _last_or_none(bb_middle),
        "bb_lower": _last_or_none(bb_lower), "bb_width": _last_or_none(bb_width),
        "hist_volatility": _last_or_none(hist_vol),
        "volume": _last_or_none(volume), "avg_volume_20d": _last_or_none(avg_volume_20d),
        "relative_volume": relative_volume, "volume_trend": volume_trend,
        "swing_high": last_swing_high, "swing_low": last_swing_low,
        "high_20d": _last_or_none(high_20d), "low_20d": _last_or_none(low_20d),
        "high_50d": _last_or_none(high_50d), "low_50d": _last_or_none(low_50d),
        "high_52w": _last_or_none(high_52w), "low_52w": _last_or_none(low_52w),
        "support_low": round(support_low, 4) if support_low is not None else None,
        "support_high": round(support_high, 4) if support_high is not None else None,
        "resistance_low": round(resistance_low, 4) if resistance_low is not None else None,
        "resistance_high": round(resistance_high, 4) if resistance_high is not None else None,
        "trend_label": trend_label,
        "trend_reasons": json.dumps(trend_reasons),
        "bars_used": bars_used,
        "warnings": warnings,
        "last_bar_ts": df["ts"].iloc[-1] if not df.empty else None,
        "reference_price": price,
    }


def compute_returns(close: pd.Series, periods=(5, 20, 50, 200)) -> dict:
    """Simple % return over each lookback period, using the last available bar as 'now'."""
    out = {}
    n = len(close)
    last = float(close.iloc[-1]) if n else None
    for p in periods:
        if last is None or n <= p:
            out[p] = None
            continue
        past = float(close.iloc[-1 - p])
        out[p] = round(((last - past) / past) * 100, 4) if past else None
    return out
