from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services.signals_service import TICKERS, compute_all_signals, compute_signal_for_ticker

bp = Blueprint("api_signals", __name__, url_prefix="/api/signals")


@bp.get("")
def all_signals():
    """The Phase 3 100-point signal for all 15 tracked stocks, ranked best-score-first.
    Powers the Signals page and the dashboard's Score/Signal column."""
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured", "results": [],
        }), 200

    timeframe = request.args.get("timeframe", "1Day")
    db = get_db()
    signals = compute_all_signals(db, timeframe=timeframe)
    return jsonify({"data_source": "alpaca", "timeframe": timeframe, "results": signals})


@bp.get("/<ticker>")
def stock_signal(ticker):
    """Single-stock signal with the full component-score breakdown — powers the stock detail
    page's 'WHY THIS SCORE?' panel."""
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked 15-stock universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({
            "ticker": ticker, "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured",
        }), 200

    timeframe = request.args.get("timeframe", "1Day")
    db = get_db()
    signal = compute_signal_for_ticker(db, ticker, timeframe=timeframe)
    return jsonify(signal)
