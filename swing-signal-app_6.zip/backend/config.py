"""
Central configuration, loaded entirely from environment variables.

CRITICAL: API keys must never be hard-coded and must never be sent to the frontend.
This module is the ONLY place that reads ALPACA_API_KEY / ALPACA_SECRET_KEY from the
environment. Every other module receives what it needs via function calls, not by
reading os.environ directly, so a future audit only has one place to check.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent

# Load backend/.env explicitly (not just cwd's .env) so `python app.py` works
# regardless of the directory it's launched from.
load_dotenv(BACKEND_DIR / ".env")


class Config:
    ALPACA_API_KEY: str | None = os.environ.get("ALPACA_API_KEY")
    ALPACA_SECRET_KEY: str | None = os.environ.get("ALPACA_SECRET_KEY")
    ALPACA_ENV: str = os.environ.get("ALPACA_ENV", "paper").lower()

    DATABASE_PATH: str = os.environ.get("DATABASE_PATH", str(BACKEND_DIR / "swing_signals.db"))
    if not os.path.isabs(DATABASE_PATH):
        DATABASE_PATH = str(BACKEND_DIR / DATABASE_PATH)

    PORT: int = int(os.environ.get("PORT", "8000"))

    ALPACA_DATA_BASE_URL = "https://data.alpaca.markets"
    ALPACA_TRADING_BASE_URL = (
        "https://api.alpaca.markets" if ALPACA_ENV == "live" else "https://paper-api.alpaca.markets"
    )

    @classmethod
    def has_alpaca_credentials(cls) -> bool:
        return bool(cls.ALPACA_API_KEY and cls.ALPACA_SECRET_KEY)


# The 15-company universe. This list is intentionally hard-coded per the project spec:
# "Track exactly these 15 companies ... Do not add additional stocks unless I specifically request them."
STOCK_UNIVERSE = [
    {"ticker": "NVDA", "name": "NVIDIA Corporation", "sector": "Technology", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "AVGO", "name": "Broadcom Inc.", "sector": "Technology", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "MU", "name": "Micron Technology, Inc.", "sector": "Technology", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "AMD", "name": "Advanced Micro Devices, Inc.", "sector": "Technology", "industry": "Semiconductors", "exchange": "NASDAQ"},
    {"ticker": "AAPL", "name": "Apple Inc.", "sector": "Technology", "industry": "Consumer Electronics", "exchange": "NASDAQ"},
    {"ticker": "MSFT", "name": "Microsoft Corporation", "sector": "Technology", "industry": "Software", "exchange": "NASDAQ"},
    {"ticker": "GOOGL", "name": "Alphabet Inc. Class A", "sector": "Communication Services", "industry": "Internet", "exchange": "NASDAQ"},
    {"ticker": "AMZN", "name": "Amazon.com, Inc.", "sector": "Consumer Discretionary", "industry": "E-Commerce", "exchange": "NASDAQ"},
    {"ticker": "META", "name": "Meta Platforms, Inc.", "sector": "Communication Services", "industry": "Internet", "exchange": "NASDAQ"},
    {"ticker": "TSLA", "name": "Tesla, Inc.", "sector": "Consumer Discretionary", "industry": "Automobiles", "exchange": "NASDAQ"},
    {"ticker": "PLTR", "name": "Palantir Technologies Inc.", "sector": "Technology", "industry": "Software", "exchange": "NASDAQ"},
    {"ticker": "LLY", "name": "Eli Lilly and Company", "sector": "Healthcare", "industry": "Pharmaceuticals", "exchange": "NYSE"},
    {"ticker": "JPM", "name": "JPMorgan Chase & Co.", "sector": "Financials", "industry": "Banking", "exchange": "NYSE"},
    {"ticker": "BRK.B", "name": "Berkshire Hathaway Inc. Class B", "sector": "Financials", "industry": "Diversified Holdings", "exchange": "NYSE"},
    {"ticker": "COST", "name": "Costco Wholesale Corporation", "sector": "Consumer Staples", "industry": "Retail", "exchange": "NASDAQ"},
]

# Alpaca's REST symbology and TradingView's widget symbology diverge for dual-class share
# tickers (Alpaca: "BRK.B" with a dot; TradingView: "BRK.B" with a dot too, but some vendors
# use "BRK-B" with a hyphen) — kept as an explicit map here rather than a string transform so
# any future divergence is a one-line fix, not a hunt through the codebase.
TRADINGVIEW_SYMBOL_OVERRIDES = {
    "BRK.B": "BRK.B",
}

# Market-regime / relative-strength reference symbols. NOTE: 'VIX' itself is a CBOE index,
# not an equity/ETF, and Alpaca's market data API (like all equities-only feeds) does not
# carry it — confirmed against Alpaca's own community docs, not assumed. VIXY (ProShares VIX
# Short-Term Futures ETF) is a real, Alpaca-tradable proxy used instead, and is always labeled
# as a proxy, never presented as the actual index value.
BROAD_MARKET_SYMBOLS = ["SPY", "QQQ"]
VIX_TRUE_TICKER = "VIX"          # kept for display/labeling only — never fetched, always UNAVAILABLE
VIX_PROXY_TICKER = "VIXY"        # what actually gets fetched from Alpaca
SECTOR_ETF_SYMBOLS = ["SMH", "SOXX", "XLK", "XLF", "XLV", "XLY", "XLP"]
REGIME_SYMBOLS = BROAD_MARKET_SYMBOLS + [VIX_PROXY_TICKER] + SECTOR_ETF_SYMBOLS

BENCHMARK_SYMBOLS = (
    [{"ticker": t, "name": n, "category": "BROAD_MARKET"} for t, n in [
        ("SPY", "SPDR S&P 500 ETF Trust"), ("QQQ", "Invesco QQQ Trust (Nasdaq-100)"),
    ]]
    + [{"ticker": VIX_PROXY_TICKER, "name": "ProShares VIX Short-Term Futures ETF (VIX proxy)", "category": "VOLATILITY_PROXY"}]
    + [{"ticker": t, "name": n, "category": "SECTOR"} for t, n in [
        ("SMH", "VanEck Semiconductor ETF"), ("SOXX", "iShares Semiconductor ETF"),
        ("XLK", "Technology Select Sector SPDR"), ("XLF", "Financial Select Sector SPDR"),
        ("XLV", "Health Care Select Sector SPDR"), ("XLY", "Consumer Discretionary Select Sector SPDR"),
        ("XLP", "Consumer Staples Select Sector SPDR"),
    ]]
)

# Each of the 15 tracked stocks' most relevant sector ETF, drawn only from the ETF list the
# project spec provided (SMH/SOXX/XLK/XLF/XLV/XLY/XLP — there is no XLC "communication
# services" ETF in that list, so META and GOOGL are mapped to XLK as the closest available
# proxy; this simplification is surfaced in the UI, not hidden).
SECTOR_ETF_MAP = {
    "NVDA": "SMH", "AVGO": "SMH", "MU": "SMH", "AMD": "SMH",
    "AAPL": "XLK", "MSFT": "XLK", "GOOGL": "XLK", "META": "XLK", "PLTR": "XLK",
    "AMZN": "XLY", "TSLA": "XLY",
    "LLY": "XLV",
    "JPM": "XLF", "BRK.B": "XLF",
    "COST": "XLP",
}

# Canonical timeframe strings used throughout the app (must match TIMEFRAME_MAP in
# providers/alpaca_provider.py). Daily is primary for Phase 2 indicators/regime; the others
# are wired through the same code path for later use (intraday entry refinement, Phase 3+).
TIMEFRAMES = ["1Day", "4Hour", "1Hour", "30Min", "15Min"]
PRIMARY_TIMEFRAME = "1Day"
