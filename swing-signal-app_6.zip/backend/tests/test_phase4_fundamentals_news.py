"""
Unit tests for Phase 4: SEC EDGAR fundamentals parsing, the long-term quality score, the news
provider's keyword classifier, and news/earnings scoring.

All network-free — SEC and Alpaca HTTP calls are mocked with payloads shaped exactly like the
real APIs (schemas verified against SEC's live endpoints and documentation).
"""
import sqlite3
import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import STOCK_UNIVERSE
from providers.base import ProviderError
from providers.news_provider import (AlpacaNewsProvider, classify_headline_impact,
                                     classify_headline_sentiment)
from providers.sec_edgar_provider import SecEdgarProvider
from services import news_service
from services.quality_score import compute_quality_score

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]),
        )
    conn.commit()
    return conn


def annual_fact(end, val, start=None, form="10-K", filed=None, fy=None):
    """A fact shaped exactly like SEC's XBRL response entries:
    {start, end, val, accn, fy, fp, form, filed, frame}."""
    entry = {"end": end, "val": val, "accn": "0000-1", "fy": fy, "fp": "FY", "form": form,
             "filed": filed or end}
    if start:
        entry["start"] = start
    return entry


def companyfacts(tags: dict) -> dict:
    return {
        "cik": 1045810, "entityName": "TEST CORP",
        "facts": {"us-gaap": {
            tag: {"label": tag, "units": {"USD": entries}} for tag, entries in tags.items()
        }},
    }


# ---------------------------------------------------------------- SEC EDGAR parsing

class TestSecEdgarParsing(unittest.TestCase):
    def setUp(self):
        self.p = SecEdgarProvider()
        self.p._ticker_map = {"NVDA": 1045810, "BRK-B": 1067983}

    def test_ticker_to_cik_handles_class_share_dot_vs_hyphen(self):
        # Alpaca says "BRK.B", SEC says "BRK-B" — the lookup must bridge that.
        self.assertEqual(self.p.get_cik("BRK.B"), 1067983)
        self.assertEqual(self.p.get_cik("NVDA"), 1045810)

    def test_unknown_ticker_raises_rather_than_guessing(self):
        with self.assertRaises(ProviderError):
            self.p.get_cik("ZZZZ")

    def test_quarterly_facts_are_not_mistaken_for_annual(self):
        facts = companyfacts({"Revenues": [
            annual_fact("2025-01-26", 130_000, start="2024-01-29"),   # ~363 days -> annual
            annual_fact("2024-10-27", 35_000, start="2024-07-29"),    # ~90 days  -> quarterly
        ]})["facts"]
        entries = self.p._annual_facts(facts, "Revenues")
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["val"], 130_000)

    def test_amended_filing_supersedes_original_for_same_period(self):
        facts = companyfacts({"Revenues": [
            annual_fact("2025-01-26", 100, start="2024-01-29", filed="2025-02-20"),
            annual_fact("2025-01-26", 130, start="2024-01-29", filed="2025-06-01"),
        ]})["facts"]
        entries = self.p._annual_facts(facts, "Revenues")
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["val"], 130)  # later-filed wins

    def test_concept_fallback_chain_finds_alternate_tag(self):
        # No "Revenues" tag, but the newer revenue-recognition tag is present.
        facts = companyfacts({"RevenueFromContractWithCustomerExcludingAssessedTax": [
            annual_fact("2025-01-26", 500, start="2024-01-29"),
        ]})["facts"]
        latest, prior, entry, tag = self.p._latest_and_prior(facts, "revenue")
        self.assertEqual(latest, 500)
        self.assertEqual(tag, "RevenueFromContractWithCustomerExcludingAssessedTax")

    def test_missing_concept_returns_none_not_zero(self):
        facts = companyfacts({"Revenues": [annual_fact("2025-01-26", 100, start="2024-01-29")]})["facts"]
        latest, _, _, _ = self.p._latest_and_prior(facts, "gross_profit")
        self.assertIsNone(latest)

    def test_full_fundamentals_computation(self):
        payload = companyfacts({
            "Revenues": [
                annual_fact("2025-01-26", 200.0, start="2024-01-29", fy=2025),
                annual_fact("2024-01-28", 100.0, start="2023-01-30", fy=2024),
            ],
            "GrossProfit": [annual_fact("2025-01-26", 150.0, start="2024-01-29")],
            "OperatingIncomeLoss": [annual_fact("2025-01-26", 80.0, start="2024-01-29")],
            "NetCashProvidedByUsedInOperatingActivities": [annual_fact("2025-01-26", 90.0, start="2024-01-29")],
            "PaymentsToAcquirePropertyPlantAndEquipment": [annual_fact("2025-01-26", 20.0, start="2024-01-29")],
            "CashAndCashEquivalentsAtCarryingValue": [annual_fact("2025-01-26", 60.0)],
            "LongTermDebtNoncurrent": [annual_fact("2025-01-26", 40.0)],
            "StockholdersEquity": [annual_fact("2025-01-26", 160.0)],
        })
        with patch.object(self.p, "_get", return_value=payload):
            f = self.p.get_fundamentals("NVDA")

        self.assertEqual(f.revenue, 200.0)
        self.assertEqual(f.revenue_growth_pct, 100.0)
        self.assertEqual(f.gross_margin_pct, 75.0)
        self.assertEqual(f.operating_margin_pct, 40.0)
        self.assertEqual(f.free_cash_flow, 70.0)      # 90 OCF - 20 capex
        self.assertEqual(f.fcf_margin_pct, 35.0)
        self.assertEqual(f.total_debt, 40.0)
        self.assertEqual(f.roic_pct, 40.0)            # 80 / (160 + 40)
        self.assertEqual(f.source, "sec-edgar")
        self.assertEqual(f.fiscal_year, 2025)

    def test_earnings_info_estimates_and_labels_confidence(self):
        base = datetime(2026, 1, 15)
        filings = [(base - timedelta(days=91 * i)).date().isoformat() for i in range(6)]
        payload = {"filings": {"recent": {
            "form": ["10-Q", "10-Q", "10-K", "10-Q", "10-Q", "10-K"],
            "filingDate": filings,
            "reportDate": filings,
        }}}
        with patch.object(self.p, "_get", return_value=payload):
            info = self.p.get_earnings_info("NVDA")

        self.assertIsNotNone(info.estimated_next_report)
        self.assertIn(info.estimate_confidence, ("LOW", "MEDIUM"))
        self.assertTrue(any("NOT a confirmed" in w for w in info.warnings))

    def test_no_periodic_filings_is_unavailable_not_invented(self):
        payload = {"filings": {"recent": {"form": ["8-K"], "filingDate": ["2026-01-01"],
                                          "reportDate": ["2026-01-01"]}}}
        with patch.object(self.p, "_get", return_value=payload):
            info = self.p.get_earnings_info("NVDA")
        self.assertIsNone(info.estimated_next_report)


# ---------------------------------------------------------------- quality score

class TestQualityScore(unittest.TestCase):
    def test_excellent_fundamentals_score_high(self):
        result = compute_quality_score({
            "revenue_growth_pct": 40.0, "eps_growth_pct": 50.0, "gross_margin_pct": 70.0,
            "operating_margin_pct": 45.0, "fcf_margin_pct": 35.0, "roic_pct": 40.0,
            "total_cash": 100.0, "total_debt": 20.0, "free_cash_flow": 50.0,
        })
        self.assertGreaterEqual(result["score"], 90)
        self.assertEqual(result["thesis"], "STRONG")
        self.assertEqual(result["coverage_pct"], 100.0)

    def test_poor_fundamentals_score_low(self):
        result = compute_quality_score({
            "revenue_growth_pct": -20.0, "eps_growth_pct": -30.0, "gross_margin_pct": 5.0,
            "operating_margin_pct": -5.0, "fcf_margin_pct": -10.0, "roic_pct": -2.0,
            "total_cash": 5.0, "total_debt": 500.0, "free_cash_flow": -50.0,
        })
        self.assertLessEqual(result["score"], 20)
        self.assertEqual(result["thesis"], "BROKEN")

    def test_missing_criteria_are_excluded_not_scored_zero(self):
        # Only two criteria have data; both are excellent. The score must reflect the excellent
        # data (rescaled), NOT be dragged down as if the missing six were failures.
        result = compute_quality_score({"revenue_growth_pct": 40.0, "gross_margin_pct": 70.0})
        self.assertEqual(result["score"], 100.0)
        self.assertEqual(result["criteria_evaluated"], 2)
        self.assertLess(result["coverage_pct"], 60)
        self.assertTrue(any("partial" in w for w in result["warnings"]))

    def test_no_data_at_all_is_unavailable_not_zero(self):
        result = compute_quality_score({})
        self.assertIsNone(result["score"])
        self.assertEqual(result["thesis"], "UNAVAILABLE")
        self.assertTrue(any("not a score of zero" in w.lower() for w in result["warnings"]))

    def test_breakdown_marks_unreported_criteria(self):
        result = compute_quality_score({"revenue_growth_pct": 20.0})
        unreported = [b for b in result["breakdown"] if b["points"] is None]
        self.assertTrue(len(unreported) > 0)
        self.assertTrue(all("not reported" in b["note"] or "not" in b["note"] for b in unreported))


# ---------------------------------------------------------------- news classification

class TestNewsClassifier(unittest.TestCase):
    def test_bullish_headline(self):
        self.assertEqual(classify_headline_sentiment("NVIDIA beats estimates and raises guidance"),
                         "BULLISH")

    def test_bearish_headline(self):
        self.assertEqual(classify_headline_sentiment("Regulators open investigation into company"),
                         "BEARISH")

    def test_mixed_signals_stay_neutral_rather_than_guessing(self):
        self.assertEqual(
            classify_headline_sentiment("Company beats estimates but faces lawsuit"), "NEUTRAL")

    def test_unmatched_headline_is_neutral(self):
        self.assertEqual(classify_headline_sentiment("Company announces annual meeting date"),
                         "NEUTRAL")

    def test_impact_detection(self):
        self.assertEqual(classify_headline_impact("Q3 earnings released"), "HIGH")
        self.assertEqual(classify_headline_impact("Company opens new office"), "NORMAL")


class TestAlpacaNewsProviderParsing(unittest.TestCase):
    def test_parses_expected_schema(self):
        p = AlpacaNewsProvider("k", "s")
        item = p._parse_item({
            "id": 123, "headline": "Company beats estimates", "summary": "Strong quarter",
            "source": "benzinga", "url": "https://example.com/a",
            "created_at": "2026-08-01T12:00:00Z", "symbols": ["NVDA"],
        })
        self.assertEqual(item.id, "123")
        self.assertEqual(item.sentiment, "BULLISH")
        self.assertEqual(item.symbols, ["NVDA"])

    def test_tolerates_unexpected_field_names(self):
        # The docs page doesn't render the response example, so the parser must not explode if
        # a field is named differently or missing entirely.
        p = AlpacaNewsProvider("k", "s")
        item = p._parse_item({"title": "Some headline", "published_at": "2026-08-01T12:00:00Z"})
        self.assertEqual(item.headline, "Some headline")
        self.assertIsNone(item.id)
        self.assertEqual(item.symbols, [])

    def test_missing_credentials_raises_rather_than_returning_empty(self):
        p = AlpacaNewsProvider(None, None)
        with self.assertRaises(ProviderError):
            p.get_news(["NVDA"])


# ---------------------------------------------------------------- news + earnings scoring

class TestNewsScoring(unittest.TestCase):
    def _insert(self, db, ticker, headline, sentiment, impact="NORMAL", days_ago=1):
        published = (datetime.now(timezone.utc) - timedelta(days=days_ago)).isoformat()
        db.execute(
            "INSERT INTO news (ticker, headline, source, url, published_at, sentiment, impact, "
            "fetched_at) VALUES (?, ?, 'test', ?, ?, ?, ?, ?)",
            (ticker, headline, f"https://x/{headline}", published, sentiment, impact,
             datetime.now(timezone.utc).isoformat()),
        )
        db.commit()

    def test_no_news_fetched_yet_returns_none_not_zero(self):
        db = make_db()
        score, reasons = news_service.score_news(db, "NVDA")
        self.assertIsNone(score)

    def test_bearish_news_scores_below_bullish_news(self):
        db = make_db()
        self._insert(db, "NVDA", "Company beats estimates", "BULLISH")
        bullish_score, _ = news_service.score_news(db, "NVDA")

        db2 = make_db()
        self._insert(db2, "AMD", "Company faces investigation", "BEARISH", impact="HIGH")
        bearish_score, _ = news_service.score_news(db2, "AMD")

        self.assertGreater(bullish_score, bearish_score)

    def test_score_stays_within_bounds(self):
        db = make_db()
        for i in range(10):
            self._insert(db, "NVDA", f"Company faces lawsuit {i}", "BEARISH", impact="HIGH")
        score, _ = news_service.score_news(db, "NVDA")
        self.assertGreaterEqual(score, 0.0)
        self.assertLessEqual(score, 5.0)


class TestEarningsRiskScoring(unittest.TestCase):
    def test_imminent_earnings_scores_low(self):
        score, reasons = news_service.score_earnings_risk(
            {"days_until_estimated_report": 2, "estimate_confidence": "MEDIUM",
             "data_status": "OK"})
        self.assertLessEqual(score, 1.0)
        self.assertTrue(any("not a" in r.lower() for r in reasons))

    def test_far_from_earnings_scores_max(self):
        score, _ = news_service.score_earnings_risk(
            {"days_until_estimated_report": 60, "estimate_confidence": "MEDIUM",
             "data_status": "OK"})
        self.assertEqual(score, 5.0)

    def test_unavailable_returns_none(self):
        score, _ = news_service.score_earnings_risk({"data_status": "UNAVAILABLE"})
        self.assertIsNone(score)

    def test_every_reason_discloses_the_estimate_caveat(self):
        for days in (2, 8, 20, 60):
            _, reasons = news_service.score_earnings_risk(
                {"days_until_estimated_report": days, "estimate_confidence": "LOW",
                 "data_status": "OK"})
            self.assertTrue(any("estimated" in r.lower() or "not a" in r.lower() for r in reasons))


if __name__ == "__main__":
    unittest.main()
