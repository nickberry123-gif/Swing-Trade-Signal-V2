"""
Unit tests for services/bars_service.py: caching, freshness TTL, and graceful fallback to
cache on a provider failure. Uses a real temporary SQLite DB (not mocked — sqlite3 is stdlib
and fast) with the provider itself mocked out.
"""
import sqlite3
import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from providers.base import Bar, ProviderError, DataStatus
from services import bars_service

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_PATH.read_text())
    conn.commit()
    return conn


def make_provider_bars(n=5, start_price=100.0):
    now = datetime.now(timezone.utc)
    bars = []
    for i in range(n):
        ts = now - timedelta(days=n - i)
        px = start_price + i
        bars.append(Bar(ts=ts, open=px, high=px + 1, low=px - 1, close=px, volume=1000.0))
    return bars


class TestBarsServiceFetchesWhenEmpty(unittest.TestCase):
    @patch("services.bars_service.get_provider")
    def test_empty_cache_triggers_fetch_and_stores(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(10)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")

        self.assertEqual(len(df), 10)
        self.assertEqual(meta["source"], "alpaca")
        self.assertTrue(meta["fresh"])
        self.assertFalse(meta["stale_fallback"])
        mock_provider.get_bars.assert_called_once()

        # Bars actually landed in the DB
        count = db.execute("SELECT COUNT(*) FROM market_bars WHERE ticker='AAPL'").fetchone()[0]
        self.assertEqual(count, 10)


class TestBarsServiceUsesFreshCache(unittest.TestCase):
    @patch("services.bars_service.get_provider")
    def test_fresh_cache_skips_provider_call(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(10)

        # First call populates cache
        bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.reset_mock()

        # Second call, immediately after, should use cache (well within TTL)
        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertEqual(meta["source"], "cache")
        self.assertFalse(meta["fresh"])
        mock_provider.get_bars.assert_not_called()
        self.assertEqual(len(df), 10)

    @patch("services.bars_service.get_provider")
    def test_force_refresh_bypasses_fresh_cache(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(10)
        bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.reset_mock()
        mock_provider.get_bars.return_value = make_provider_bars(11)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day", force_refresh=True)
        mock_provider.get_bars.assert_called_once()
        self.assertEqual(meta["source"], "alpaca")


class TestBarsServiceStaleCache(unittest.TestCase):
    @patch("services.bars_service.get_provider")
    def test_stale_cache_triggers_refetch(self, mock_get_provider):
        db = make_db()
        # Manually insert a bar with an old fetched_at timestamp (outside TTL)
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
        db.execute(
            "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume, "
            "source, fetched_at) VALUES ('AAPL','1Day',?,100,101,99,100,1000,'alpaca',?)",
            (old_ts, old_ts),
        )
        db.commit()

        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.return_value = make_provider_bars(20)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        mock_provider.get_bars.assert_called_once()
        self.assertEqual(meta["source"], "alpaca")


class TestBarsServiceProviderFailure(unittest.TestCase):
    @patch("services.bars_service.get_provider")
    def test_failure_with_no_cache_returns_empty_honestly(self, mock_get_provider):
        db = make_db()
        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.side_effect = ProviderError("boom", DataStatus.UNAVAILABLE)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertTrue(df.empty)
        self.assertIsNotNone(meta["error"])
        self.assertFalse(meta["stale_fallback"])

    @patch("services.bars_service.get_provider")
    def test_failure_with_stale_cache_falls_back_honestly(self, mock_get_provider):
        db = make_db()
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
        db.execute(
            "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume, "
            "source, fetched_at) VALUES ('AAPL','1Day',?,100,101,99,100,1000,'alpaca',?)",
            (old_ts, old_ts),
        )
        db.commit()

        mock_provider = mock_get_provider.return_value
        mock_provider.get_bars.side_effect = ProviderError("boom", DataStatus.UNAVAILABLE)

        df, meta = bars_service.get_bars_df(db, "AAPL", "1Day")
        self.assertEqual(len(df), 1)
        self.assertTrue(meta["stale_fallback"])
        self.assertIsNotNone(meta["error"])


if __name__ == "__main__":
    unittest.main()
