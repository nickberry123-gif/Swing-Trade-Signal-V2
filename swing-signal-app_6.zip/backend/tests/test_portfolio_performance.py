"""
Unit tests for Phase 5 (portfolio/trades/FIFO/GBP) and Phase 6 (signal history, forward-return
evaluation, performance analytics). Real in-memory SQLite, no network.
"""
import sqlite3
import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import STOCK_UNIVERSE
from services import performance_service as perf
from services import portfolio_service as pf

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]),
        )
    conn.commit()
    return conn


class TestTradeValidation(unittest.TestCase):
    def test_rejects_unknown_ticker(self):
        db = make_db()
        with self.assertRaises(ValueError):
            pf.add_trade(db, "FAKE", "BUY", "2026-01-01", 10, 100)

    def test_rejects_non_buy_sell_side(self):
        db = make_db()
        with self.assertRaises(ValueError):
            pf.add_trade(db, "NVDA", "SHORT", "2026-01-01", 10, 100)

    def test_rejects_zero_or_negative_quantity(self):
        db = make_db()
        for bad in (0, -5):
            with self.assertRaises(ValueError):
                pf.add_trade(db, "NVDA", "BUY", "2026-01-01", bad, 100)

    def test_rejects_negative_price(self):
        db = make_db()
        with self.assertRaises(ValueError):
            pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, -1)


class TestFifoAccounting(unittest.TestCase):
    def test_single_buy_creates_position(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, 100.0)
        walk = pf._fifo_walk(pf.get_trades(db, "NVDA"))
        self.assertEqual(walk["open_quantity"], 10)
        self.assertEqual(walk["avg_entry_price"], 100.0)
        self.assertEqual(walk["realized_pnl"], 0.0)

    def test_fifo_consumes_oldest_lot_first(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 100, 10.0)
        pf.add_trade(db, "NVDA", "BUY", "2026-02-01", 100, 20.0)
        pf.add_trade(db, "NVDA", "SELL", "2026-03-01", 100, 30.0)

        walk = pf._fifo_walk(pf.get_trades(db, "NVDA"))
        # Sold the $10 lot: proceeds 3000 - cost 1000 = 2000 realised.
        self.assertEqual(walk["realized_pnl"], 2000.0)
        self.assertEqual(walk["open_quantity"], 100)
        self.assertEqual(walk["avg_entry_price"], 20.0)  # the $20 lot remains

    def test_partial_sale_leaves_correct_remainder(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 100, 10.0)
        pf.add_trade(db, "NVDA", "SELL", "2026-02-01", 40, 15.0)
        walk = pf._fifo_walk(pf.get_trades(db, "NVDA"))
        self.assertEqual(walk["open_quantity"], 60)
        self.assertEqual(walk["realized_pnl"], 200.0)  # 40 * (15-10)

    def test_fees_reduce_realised_pnl_on_both_sides(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, 100.0, fees=5.0)
        pf.add_trade(db, "NVDA", "SELL", "2026-02-01", 10, 110.0, fees=5.0)
        walk = pf._fifo_walk(pf.get_trades(db, "NVDA"))
        # Gross gain 100, minus 5 buy fee and 5 sell fee = 90.
        self.assertAlmostEqual(walk["realized_pnl"], 90.0, places=2)

    def test_full_exit_removes_position_row(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, 100.0)
        pf.add_trade(db, "NVDA", "SELL", "2026-02-01", 10, 120.0)
        row = db.execute("SELECT * FROM portfolio_positions WHERE ticker='NVDA'").fetchone()
        self.assertIsNone(row)

    def test_overselling_is_flagged_never_treated_as_a_short(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, 100.0)
        result = pf.add_trade(db, "NVDA", "SELL", "2026-02-01", 25, 120.0)
        self.assertTrue(any("long-only" in w for w in result["warnings"]))

        walk = pf._fifo_walk(pf.get_trades(db, "NVDA"))
        self.assertGreater(walk["oversold_quantity"], 0)
        # Crucially the position never goes negative — no short is ever created.
        self.assertGreaterEqual(walk["open_quantity"], 0)

    def test_delete_trade_rebuilds_position(self):
        db = make_db()
        t = pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, 100.0)
        pf.delete_trade(db, t["id"])
        self.assertEqual(pf.get_position_quantity(db, "NVDA"), 0)


class TestPortfolioView(unittest.TestCase):
    def test_unrealized_pnl_with_live_price(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, 100.0)
        result = pf.get_portfolio(db, prices_by_ticker={"NVDA": 150.0})
        holding = result["holdings"][0]
        self.assertEqual(holding["market_value"], 1500.0)
        self.assertEqual(holding["unrealized_pnl"], 500.0)
        self.assertEqual(holding["unrealized_pnl_pct"], 50.0)

    def test_missing_price_is_unavailable_not_silently_zero(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, 100.0)
        result = pf.get_portfolio(db, prices_by_ticker={})
        holding = result["holdings"][0]
        self.assertIsNone(holding["market_value"])
        self.assertIsNone(holding["unrealized_pnl"])
        self.assertEqual(holding["price_status"], "UNAVAILABLE")
        self.assertTrue(any("no live price" in w.lower() for w in result["warnings"]))

    def test_gbp_conversion_only_with_an_explicit_dated_rate(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, 100.0)

        without = pf.get_portfolio(db, prices_by_ticker={"NVDA": 150.0}, fx_rate=None)
        self.assertNotIn("gbp", without)

        pf.set_fx_rate(db, 0.80, source="manual")
        with_fx = pf.get_portfolio(db, prices_by_ticker={"NVDA": 150.0},
                                   fx_rate=pf.get_fx_rate(db))
        self.assertEqual(with_fx["gbp"]["total_market_value"], 1200.0)
        self.assertEqual(with_fx["gbp"]["rate_used"], 0.80)
        self.assertEqual(with_fx["gbp"]["rate_source"], "manual")
        self.assertIsNotNone(with_fx["gbp"]["rate_as_of"])

    def test_implausible_fx_rate_rejected(self):
        db = make_db()
        for bad in (0, -1, 500):
            with self.assertRaises(ValueError):
                pf.set_fx_rate(db, bad)


class TestSignalHistoryAndOutcomes(unittest.TestCase):
    def _signal(self, ticker="NVDA", label="BUY", score=70.0, price=100.0):
        return {"ticker": ticker, "signal_label": label, "score_total": score,
                "current_price": price, "data_status": "OK", "strategy_version": "v1.0",
                "ideal_buy": 98.0, "buy_zone_low": 97.0, "buy_zone_high": 99.0,
                "max_entry": 101.0, "target1": 110.0, "primary_target": 115.0,
                "target3": 120.0, "market_regime": "BULL", "long_term_quality": 80.0,
                "long_term_thesis": "STRONG"}

    def test_snapshot_is_append_only(self):
        db = make_db()
        perf.snapshot_signals(db, [self._signal()])
        perf.snapshot_signals(db, [self._signal(score=75.0)])
        rows = perf.get_signal_history(db, "NVDA")
        self.assertEqual(len(rows), 2)  # second call adds, never overwrites

    def test_no_data_signals_are_not_recorded(self):
        db = make_db()
        written = perf.snapshot_signals(db, [
            {"ticker": "NVDA", "score_total": None, "data_status": "UNAVAILABLE"}])
        self.assertEqual(written, 0)

    def test_outcome_not_evaluated_before_horizon_elapses(self):
        db = make_db()
        perf.snapshot_signals(db, [self._signal()])
        result = perf.evaluate_signal_outcomes(db)
        self.assertEqual(result["evaluated"], 0)
        self.assertGreater(result["pending_time"], 0)

    def test_outcome_evaluated_against_real_forward_price(self):
        db = make_db()
        # A signal 60 days ago at $100.
        past = (datetime.now(timezone.utc) - timedelta(days=60)).isoformat()
        db.execute(
            "INSERT INTO signal_history (ticker, ts, score_total, signal_label, current_price) "
            "VALUES ('NVDA', ?, 70.0, 'BUY', 100.0)", (past,))
        # A real cached bar 10 calendar days later at $110.
        bar_ts = (datetime.now(timezone.utc) - timedelta(days=50)).isoformat()
        db.execute(
            "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume, "
            "source, fetched_at) VALUES ('NVDA','1Day',?,110,110,110,110,1000,'alpaca',?)",
            (bar_ts, bar_ts))
        db.commit()

        result = perf.evaluate_signal_outcomes(db, horizons=(5,))
        self.assertEqual(result["evaluated"], 1)
        row = db.execute("SELECT * FROM signal_outcomes WHERE ticker='NVDA'").fetchone()
        self.assertAlmostEqual(row["return_pct"], 10.0, places=2)

    def test_outcomes_are_not_duplicated_on_rerun(self):
        db = make_db()
        past = (datetime.now(timezone.utc) - timedelta(days=60)).isoformat()
        db.execute(
            "INSERT INTO signal_history (ticker, ts, score_total, signal_label, current_price) "
            "VALUES ('NVDA', ?, 70.0, 'BUY', 100.0)", (past,))
        bar_ts = (datetime.now(timezone.utc) - timedelta(days=50)).isoformat()
        db.execute(
            "INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume, "
            "source, fetched_at) VALUES ('NVDA','1Day',?,110,110,110,110,1000,'alpaca',?)",
            (bar_ts, bar_ts))
        db.commit()

        perf.evaluate_signal_outcomes(db, horizons=(5,))
        perf.evaluate_signal_outcomes(db, horizons=(5,))
        count = db.execute("SELECT COUNT(*) FROM signal_outcomes").fetchone()[0]
        self.assertEqual(count, 1)


class TestPerformanceSummary(unittest.TestCase):
    def _add_outcome(self, db, ret, label="BUY", score=70.0, horizon=5, idx=1):
        db.execute(
            "INSERT INTO signal_history (id, ticker, ts, score_total, signal_label, "
            "current_price) VALUES (?, 'NVDA', ?, ?, ?, 100.0)",
            (idx, datetime.now(timezone.utc).isoformat(), score, label))
        db.execute(
            "INSERT INTO signal_outcomes (signal_history_id, ticker, signal_label, score_total, "
            "signal_ts, signal_price, horizon_days, evaluated_price, return_pct) "
            "VALUES (?, 'NVDA', ?, ?, ?, 100.0, ?, ?, ?)",
            (idx, label, score, datetime.now(timezone.utc).isoformat(), horizon,
             100 * (1 + ret / 100), ret))
        db.commit()

    def test_empty_history_says_so_rather_than_showing_zeroes(self):
        db = make_db()
        summary = perf.get_performance_summary(db)
        self.assertEqual(summary["total_outcomes_evaluated"], 0)
        self.assertTrue(any("No signal outcomes" in w for w in summary["warnings"]))

    def test_small_sample_is_flagged_as_not_meaningful(self):
        db = make_db()
        for i, r in enumerate([5.0, -2.0, 3.0], start=1):
            self._add_outcome(db, r, idx=i)
        summary = perf.get_performance_summary(db)
        stats = summary["by_horizon"][5]
        self.assertEqual(stats["sample_size"], 3)
        self.assertFalse(stats["meaningful"])
        self.assertTrue(any("noise" in w for w in summary["warnings"]))

    def test_large_sample_is_marked_meaningful(self):
        db = make_db()
        for i in range(1, 26):
            self._add_outcome(db, 2.0 if i % 2 else -1.0, idx=i)
        summary = perf.get_performance_summary(db)
        stats = summary["by_horizon"][5]
        self.assertTrue(stats["meaningful"])
        self.assertEqual(stats["sample_size"], 25)
        self.assertIsNotNone(stats["win_rate_pct"])

    def test_actionable_labels_tracked_separately_from_watch(self):
        db = make_db()
        self._add_outcome(db, 10.0, label="BUY", idx=1)
        self._add_outcome(db, -10.0, label="AVOID", idx=2)
        summary = perf.get_performance_summary(db)
        self.assertEqual(summary["actionable_by_horizon"][5]["sample_size"], 1)
        self.assertIn("AVOID", summary["by_label"])


class TestTradePerformance(unittest.TestCase):
    def test_no_closed_trades_says_so(self):
        db = make_db()
        result = perf.get_trade_performance(db)
        self.assertEqual(result["closed_trades"], 0)
        self.assertTrue(result["warnings"])

    def test_realised_stats_computed_from_closed_trades(self):
        db = make_db()
        pf.add_trade(db, "NVDA", "BUY", "2026-01-01", 10, 100.0)
        pf.add_trade(db, "NVDA", "SELL", "2026-02-01", 10, 120.0)
        pf.add_trade(db, "AMD", "BUY", "2026-01-01", 10, 100.0)
        pf.add_trade(db, "AMD", "SELL", "2026-02-01", 10, 90.0)

        result = perf.get_trade_performance(db)
        self.assertEqual(result["closed_trades"], 2)
        self.assertEqual(result["total_realized_pnl"], 100.0)
        self.assertEqual(result["win_rate_pct"], 50.0)
        self.assertTrue(any("too small a sample" in w for w in result["warnings"]))


if __name__ == "__main__":
    unittest.main()
