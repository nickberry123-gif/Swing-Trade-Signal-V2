# Swing Signal — Long-Only Swing Trading Signal System

**Phase 6 of 9.** A personal market-analysis / signal-generation / portfolio-journal dashboard
for a fixed 15-stock universe. This application does not and will never place, modify, or
cancel trades. No shorting. No leverage. No options. No stop losses. No automated buying or
selling. You execute every trade manually in a separate brokerage app — this is the analysis
layer only.

## What Phase 4 adds — fundamentals, news, earnings

- **Real fundamentals from SEC EDGAR** (`providers/sec_edgar_provider.py`) — audited figures
  pulled straight from each company's own 10-K filings via SEC's public XBRL API. No API key,
  no paid vendor, no new subscription. Ticker→CIK is resolved from SEC's own published mapping
  rather than a hard-coded table, so a stale CIK can never attach one company's financials to
  another's ticker.
- **Long-term quality score (0-100)** — eight criteria (revenue growth, EPS growth, gross /
  operating / FCF margins, ROIC proxy, balance-sheet strength, positive FCF). Built **only**
  from financial-statement data, deliberately never from price action — price already drives
  the trading score, and reusing it here would double-count the same signal while pretending to
  be an independent fundamental view. This replaces Phase 3's technical-only placeholder and is
  what actually answers "would I be comfortable still holding this if the trade goes wrong?"
- **Criteria with no reported data are excluded, not scored zero** — and `coverage_pct` is
  reported, so a score built from 3 of 8 criteria can't be mistaken for a complete assessment.
- **News via Alpaca's news API** — same vendor, no new cost. Sentiment is a deliberately
  simple, fully inspectable **keyword classifier** (the word lists are right there in
  `providers/news_provider.py`), and it is described as exactly that everywhere it appears.
  No claim of NLP/AI sentiment analysis is made, because none is performed.
- **Earnings timing from SEC filing cadence** — with the honest caveat attached everywhere:
  it is an **estimate** derived from historical filing gaps, never a company-confirmed date.
- **The last 10 points of the 100-point score are now live** (news 5, earnings risk 5), and
  `score_max_currently_available` is now computed from what was actually evaluated rather than
  hard-coded — so a stock missing news data reports a lower achievable maximum instead of being
  silently penalised against a full 100.

## What Phase 5 adds — portfolio & trade journal

- **Manual trade entry** (BUY/SELL only — enforced by a database CHECK constraint, so there is
  no short side even at the storage layer), with strict validation rather than silent coercion.
- **FIFO lot accounting** — buying 100 @ $10 then 100 @ $20 and selling 100 realises the $10
  lot first, which handles partial sales of a scaled-in position correctly. Fees are applied on
  both sides so realised P&L reflects what actually landed, not a flattering gross number.
- **Holdings with live unrealised P&L**; any position without a live price reports
  UNAVAILABLE and is excluded from the total (making it *incomplete*, which is stated) rather
  than silently falling back to cost basis and showing a fake P&L of exactly zero.
- **Over-selling is flagged loudly, never treated as a short** — in a long-only system, selling
  more than you hold is a data-entry error, and the app says so instead of going negative.
- **GBP conversion** using an explicitly user-entered, timestamped rate. The app never fetches
  or assumes an exchange rate; GBP figures stay hidden until a rate is set, and the rate and its
  date are always shown alongside the converted numbers.

## What Phase 6 adds — signal history & performance

- **Append-only signal history** — past calls are never overwritten or recomputed, including
  the bad ones.
- **Forward-return evaluation** at 5/10/20 trading-day horizons, measured from the price
  recorded when the signal fired against the real cached close later. A horizon is only scored
  once it has genuinely elapsed *and* a real forward price exists — never extrapolated.
- **Sample-size honesty throughout** — every statistic carries its sample size and a
  `meaningful` flag; anything under 20 observations is explicitly labeled as noise rather than
  rendered as a clean-looking percentage.
- **Score-band analysis** — the "does a higher score actually produce a better outcome?" table,
  which is the one that tells you whether the model deserves trust or revision.
- **Actionable signals tracked separately** from WATCH/NO TRADE/AVOID, since scoring non-actions
  as if they were entries would be misleading.
- **Your own trade performance** kept separate from signal accuracy — a signal being right and
  your execution being profitable are two different questions.

## What Phase 3 adds

- **The 100-point signal engine** (`services/signal_engine.py`) — scores every stock across 8
  currently-computable weighted categories (long-term trend 20, short-term trend 10, momentum
  15, RSI pullback quality 10, volume 10, support/resistance 10, relative strength 10, market
  regime 5 = 90 pts). News (5) and earnings risk (5) are part of the 100-point design per the
  original spec but always score 0 for now — there's no news/earnings data source yet (Phase
  4). That's disclosed everywhere a score appears (`score / 90`), never padded to look like a
  full evaluation.
- **Signal labels** — STRONG BUY / BUY / WATCH / NO TRADE / AVOID from the total score, with an
  explicit risk-discipline override: a confirmed BEAR market regime caps any stock at WATCH
  regardless of its own score, since this system never shorts and shouldn't be pushing new long
  entries into a broad downtrend.
- **Strategy setup classification** — PULLBACK / BREAKOUT / DEEP_CORRECTION / NONE, a
  plain-English label for *why* a setup might be reasonable, shown alongside the score.
  Long-term thesis (STRONG/HEALTHY/WATCH/DETERIORATING/BROKEN) is a preliminary technical-only
  proxy, clearly labeled as such — the real fundamentals-based version arrives in Phase 4.
- **Buy/sell price levels** — ideal buy, buy zone, max entry, target 1 / primary target /
  target 3, and expected upside, all built from Phase 2's support/resistance zones and ATR.
  Always ranges, never a single "exact" price — and there is no stop-loss field anywhere in
  this module, the database schema, or the UI.
- **New API routes** — `GET /api/signals` (all 15, ranked best-to-worst, sharing one market
  regime + benchmark fetch), `GET /api/signals/<ticker>` (single stock with full breakdown).
- **New Signals page** — replaces the old "coming soon" placeholder with a ranked card grid:
  score, signal pill, strategy setup, all six price levels, expected upside, long-term thesis.
- **Dashboard & stock detail updates** — a Signal column on the 15-stock table, and a full
  "Why this score?" component-by-component breakdown (with a visual bar per category) on each
  stock's detail page, plus the buy/sell levels card.

## What Phase 2 adds

- **Technical indicator engine** (`services/indicators.py`) — Wilder's RSI (14 &amp; 7), MACD,
  Wilder's ADX, ATR (value + % of price), stochastic RSI, Bollinger Bands, historical
  volatility, volume trend, 20/50-day and 52-week highs/lows. Every value is a real, standard
  formula; anything that can't be computed yet (not enough bars) is `null`, never guessed.
- **Support/resistance as zones, never single prices** — built from confirmed fractal swing
  highs/lows (requiring confirmation bars on both sides, so the two most recent bars can never
  be reported as swing points), moving averages, and 20/50-day extremes, clustered and widened
  by ATR so a lone level still renders as a real range.
- **Trend classification** — a scored blend of price-vs-SMA200, SMA200 slope, and
  price-vs-SMA50 (Strong Uptrend/Uptrend/Neutral/Downtrend/Strong Downtrend), with the specific
  reasons behind the label always shown — never a rigid binary pass/fail on one condition.
- **Market regime** (`services/market_regime.py`) — STRONG BULL/BULL/NEUTRAL/CAUTIOUS/BEAR from
  a transparent additive score across SPY trend, QQQ trend, sector-ETF breadth (7 tracked
  sectors), and a volatility proxy. True CBOE VIX isn't available from Alpaca (it only covers
  equities/ETFs, not index data) — VIXY, a real Alpaca-tradable ETF, is used instead and always
  labeled explicitly as a proxy, never presented as the real VIX.
- **Relative strength** (`services/relative_strength.py`) — each stock's return vs SPY, QQQ,
  and its mapped sector ETF over 5/20/50/200 trading days, labeled Strong/In-line/Weak.
  Benchmarks with no data return `null`, never a fabricated 0.
- **Bar caching layer** (`services/bars_service.py`) — caches OHLCV bars per ticker/timeframe
  with a freshness TTL (daily bars: 6h) so the dashboard doesn't hit Alpaca on every poll;
  falls back to stale cache on a provider failure rather than crashing, always flagging that
  fallback honestly rather than presenting old data as fresh.
- **New API routes** — `GET /api/stocks/<ticker>/indicators`, `GET /api/stocks/indicators`
  (all 15 at once, sharing one fetch of the benchmark data), `GET /api/market/regime`.
- **Dashboard & stock-detail UI updates** — RSI/Trend/Relative-Strength columns on the
  15-stock table, a live Market Regime tile strip, and a full Technical Indicators /
  Support &amp; Resistance / Relative Strength panel on each stock's detail page.

## What Phase 1 delivers

- **Application shell** — dark, professional trading-dashboard UI with the full 8-tab
  navigation (Dashboard, Stocks, Portfolio, Signals, Trades, Performance, Backtest, Settings).
  Only Dashboard and Stocks/[ticker] are functional; the rest are clearly labeled "coming in
  Phase N" placeholders rather than fake/empty pages.
- **Relational database** (SQLite) with the full schema described in the project spec —
  `stocks`, `market_bars`, `quotes`, `technical_indicators`, `signals`, `signal_history`,
  `news`, `trades`, `portfolio_positions`, `fundamentals`, `market_regime`,
  `strategy_versions`, `alerts`. Only `stocks`, `quotes`, and `strategy_versions` are populated
  in Phase 1; the rest are ready for Phases 2–8 with no migration needed later.
- **The fixed 15-stock universe**, seeded automatically on first run.
- **MarketDataProvider abstraction** — the app never talks to Alpaca directly outside of
  `providers/alpaca_provider.py`. Swapping vendors later means writing one new class.
- **AlpacaProvider** — calls Alpaca's official documented REST endpoints (`/v2/clock`,
  `/v2/stocks/{symbol}/snapshot`, `/v2/stocks/snapshots`, `/v2/stocks/{symbol}/bars`) directly
  over HTTPS with `requests`. Credentials live only in `backend/.env`, read only by
  `config.py`, and are never sent to the frontend.
- **Honest data-status labeling** — every price on screen is tagged `LIVE`, `DELAYED`,
  `MARKET_CLOSED`, `STALE`, or `UNAVAILABLE`, never silently presented as something it isn't.
  If Alpaca is unreachable or credentials are missing, the app says so explicitly instead of
  freezing on old numbers or inventing data.
- **TradingView charts** on every stock detail page (official embedded widget only —
  15m/30m/1H/4H/1D/1W), used purely for visual charting. Nothing on the page reads data back
  out of the widget; all calculated figures come from Alpaca via this app's own backend.

## Stack (and why it differs slightly from the original FastAPI/React plan)

The sandbox this was built in has locked-down network egress at the org level — it cannot
reach `pypi.org`, the npm registry, or Alpaca's API domains directly, so `pip install
fastapi`/`alpaca-py` and `npm install` weren't possible *inside that sandbox*, and a live
Alpaca call couldn't be tested from there either. Rather than hand you FastAPI/React code that
had never actually been run, the stack was adapted to what's provable right now:

- **Backend:** Flask + Python's built-in `sqlite3` + `requests` — all runnable and testable
  without any package installs.
- **Frontend:** plain HTML/CSS/JS (Jinja2 templates + `fetch`) — no Node.js, no build step.

None of this changes the architecture (same provider abstraction, same DB schema, same API
shape) — just the framework names. On your own machine, with normal internet access,
`pip install -r requirements.txt` pulls everything and live Alpaca calls will work immediately.

## Setup

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env and paste your ALPACA_API_KEY / ALPACA_SECRET_KEY
# (free paper-trading keys from https://app.alpaca.markets are fine — Alpaca's free
#  market-data plan serves the real-time IEX feed, not simulated/paid data)

python3 scripts/check_alpaca_connection.py   # confirms your keys + network actually work
python3 app.py                               # starts the app on http://localhost:8000
```

Open `http://localhost:8000` in a browser. The dashboard polls `/api/stocks/snapshots` and
`/api/market/status` every 15 seconds.

## Running the tests

```bash
cd backend
python3 -m unittest discover -s tests -v
```

189 unit tests, all network-free (mocked HTTP / mocked provider / in-memory SQLite), so they run
and pass identically inside the sandbox this was built in and on your own machine:

- 16 for `AlpacaProvider` — timestamp parsing (including nanosecond precision), missing-
  credentials handling, market-session classification, snapshot parsing against Alpaca's real
  documented schema, LIVE/MARKET_CLOSED/STALE/UNAVAILABLE classification, HTTP error handling.
- 37 for the indicator engine — RSI/MACD/ATR/ADX/Bollinger/historical-volatility correctness
  against known synthetic series, swing-point no-repaint behavior, support/resistance zones,
  trend classification (including the "one condition violated ≠ automatic rejection" rule).
- 6 for the bar caching layer — fresh-cache reuse, TTL expiry, force-refresh, and honest
  stale-cache fallback on a provider failure.
- 6 for market regime — threshold boundaries, bullish/bearish/flat(neutral) classification,
  and UNAVAILABLE-not-fabricated when SPY/QQQ data is missing.
- 8 for relative strength — label thresholds, outperformance/underperformance sign, missing-
  benchmark-is-null-not-zero.
- 7 for the `stock_analysis` orchestration layer — end-to-end result shape, no-data handling,
  upsert-not-duplicate persistence, and benchmark-cache reuse across the 15-stock batch.
- 46 for the signal engine — every scoring component (bullish/bearish/missing-data-returns-
  None for each), strategy setup classification, the BEAR-regime signal cap, and buy/sell
  price-level ordering invariants (buy zone ≤ ideal buy ≤ max entry < target 1 ≤ primary
  target ≤ target 3) across full-data, partial-data, and no-data scenarios.
- 4 for the signals orchestration layer — full-signal computation and persistence, ranking,
  one-bad-ticker-doesn't-break-the-batch, and shared benchmark-fetch reuse across all 15 stocks.

**What was and wasn't tested where this was built:** every Flask route, the database schema,
seeding, HTML rendering of all 8 nav pages (verified visually via Playwright screenshots), and
the full data-unavailable/error-handling path were tested live in-sandbox. The one thing that
*couldn't* be tested there was an actual successful Alpaca API call, purely because that
sandbox's network policy blocks `alpaca.markets` and `tradingview.com` outbound — the app
correctly detected this and displayed `DATA STATUS: UNAVAILABLE` with a clear error message
rather than failing silently or faking data, which is itself a real (and correct) test of that
code path. Run `scripts/check_alpaca_connection.py` on your machine to confirm the live path.

## Project layout

```
backend/
  app.py                    Flask app factory + routes
  config.py                 env-var config, the 15-stock universe, benchmark/sector symbols
  db.py / schema.sql        SQLite data-access layer + full relational schema
  providers/
    base.py                 MarketDataProvider abstract interface (vendor-agnostic)
    alpaca_provider.py       AlpacaProvider implementation
  services/
    market_service.py        provider singleton + short-TTL cache, used by routes
    bars_service.py           bar caching/fetch layer with freshness TTL + stale fallback
    indicators.py             pure technical-indicator calculation engine
    market_regime.py          SPY/QQQ/sector/VIXY-proxy regime classification
    relative_strength.py      excess-return calc vs SPY/QQQ/sector ETF
    stock_analysis.py         orchestration: bars -> indicators -> relative strength -> persist
    signal_engine.py           Phase 3: the 100-point scoring engine + buy/sell price levels
    signals_service.py         orchestration: regime + stock_analysis -> signal_engine -> persist
  routers/
    api_stocks.py            /api/stocks, /snapshots, /<t>/snapshot, /<t>/bars, /<t>/indicators, /indicators
    api_market.py             /api/market/status, /api/market/regime
    api_signals.py             /api/signals, /api/signals/<ticker>
  scripts/check_alpaca_connection.py   standalone live connectivity check
  tests/                      130 unit tests across providers/indicators/bars/regime/RS/analysis/signals
frontend/
  templates/                 Jinja2 pages (dashboard, stocks, stock_detail, signals, coming_soon, ...)
  static/css/style.css       dark trading-dashboard theme
  static/js/                 api.js (fetch helpers), topbar.js, dashboard.js, stock_detail.js, signals.js
```

## Roadmap (Phases 7–9, not yet built)

4. Fundamentals (via a separate FundamentalDataProvider, only real data, never fabricated),
   news, earnings/earnings-blackout, long-term quality score.
5. Manual portfolio & trade journal, partial sales, P/L, GBP conversion.
6. Signal history (append-only) & performance tracking, trade analytics.
7. Backtesting engine with strict look-ahead-bias prevention and walk-forward
   in-sample/validation/out-of-sample splits.
8. Alerts (informational only — never trigger trades).
9. AI-generated plain-English signal explanations, built strictly from the engine's own
   calculated numbers.

## Security notes

- `ALPACA_API_KEY` / `ALPACA_SECRET_KEY` are read only in `config.py` from `backend/.env` and
  never appear in any frontend file, any API response, or any log statement.
- `.gitignore` excludes `backend/.env` and the SQLite database file.
- The app makes zero outbound calls to any trade-execution endpoint. There is no order,
  cancel-order, or modify-order code anywhere in this codebase.
