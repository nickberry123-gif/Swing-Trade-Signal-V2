"""
Tests for services/backtest_service.py.

The look-ahead tests are the important ones here. A backtest that peeks at future data produces
excellent, meaningless results, so the guarantees are asserted directly rather than assumed:
future prices must not alter past signals, and fills must land on the bar AFTER the signal.
"""
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import database
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import STOCK_UNIVERSE
from services import backtest_service as bt

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]),
        )
    conn.commit()
    return conn


def bars(n=300, start=100.0, drift=0.2, noise=1.6, seed=0, wave=6.0, period=25):
    """Uptrend WITH periodic pullbacks.

    A straight-line uptrend generates zero trades, and that is correct behaviour rather than a
    bug: the strategy refuses to buy above `max_entry`, so it never chases a price that never
    dips into its buy zone. Real equities oscillate, so the test data has to as well — otherwise
    the entry path is never exercised.
    """
    rng = np.random.default_rng(seed)
    trend = start + np.cumsum(drift + rng.normal(0, noise, n))
    cycle = wave * np.sin(np.arange(n) * 2 * np.pi / period)
    closes = np.maximum(trend + cycle, 1.0)
    ts = [(datetime(2024, 1, 1) + timedelta(days=i)).date().isoformat() for i in range(n)]
    return pd.DataFrame({
        "ts": ts, "open": closes, "high": closes * 1.01, "low": closes * 0.99,
        "close": closes, "volume": [1_000_000.0] * n,
    })


class TestLookAheadPrevention(unittest.TestCase):
    """The core guarantees. If any of these fail, every metric this engine produces is void."""

    def test_future_prices_cannot_change_a_past_signal(self):
        base = bars(seed=1)

        # Identical history, but the final 20 bars are replaced with a massive spike. Any
        # signal generated before that spike must be byte-identical in both worlds.
        spiked = base.copy()
        spiked.loc[spiked.index[-20:], ["open", "high", "low", "close"]] *= 5.0

        cutoff = len(base) - 25
        ind_base = bt.compute_all_indicators(base.iloc[:cutoff])
        ind_spiked = bt.compute_all_indicators(spiked.iloc[:cutoff])

        for key in ("rsi14", "sma50", "sma200", "macd", "trend_label", "reference_price"):
            self.assertEqual(ind_base.get(key), ind_spiked.get(key),
                             f"{key} changed when only FUTURE bars differed — look-ahead bias")

    def test_trades_before_a_future_spike_are_unchanged_by_it(self):
        base = bars(seed=2)
        spiked = base.copy()
        spiked.loc[spiked.index[-15:], ["open", "high", "low", "close"]] *= 4.0

        t_base = bt._simulate_ticker("NVDA", base, {}, {})
        t_spiked = bt._simulate_ticker("NVDA", spiked, {}, {})

        cutoff_date = base["ts"].iloc[-30]
        early_base = [t for t in t_base if t["signal_date"] < cutoff_date]
        early_spiked = [t for t in t_spiked if t["signal_date"] < cutoff_date]

        self.assertEqual(len(early_base), len(early_spiked))
        for a, b in zip(early_base, early_spiked):
            self.assertEqual(a["signal_date"], b["signal_date"])
            self.assertEqual(a["entry_price"], b["entry_price"])

    def test_entry_fills_at_the_next_bars_open_not_the_signal_close(self):
        df = bars(seed=3)
        trades = bt._simulate_ticker("NVDA", df, {}, {})
        self.assertTrue(trades, "expected at least one trade in a strong uptrend")

        for t in trades:
            signal_idx = df.index[df["ts"] == t["signal_date"]][0]
            entry_idx = df.index[df["ts"] == t["entry_date"]][0]
            self.assertEqual(entry_idx, signal_idx + 1,
                             "entry must be the bar AFTER the signal bar")
            self.assertAlmostEqual(t["entry_price"], float(df["open"].iloc[entry_idx]), places=4)
            self.assertNotAlmostEqual(t["entry_price"], float(df["close"].iloc[signal_idx]),
                                      places=6)

    def test_no_signal_is_generated_before_warmup_completes(self):
        df = bars(seed=4)
        trades = bt._simulate_ticker("NVDA", df, {}, {})
        for t in trades:
            idx = df.index[df["ts"] == t["signal_date"]][0]
            self.assertGreaterEqual(idx, bt.MIN_WARMUP_BARS)

    def test_exit_never_precedes_entry(self):
        df = bars(seed=5)
        for t in bt._simulate_ticker("NVDA", df, {}, {}):
            if t.get("exit_date"):
                self.assertGreater(t["exit_date"], t["entry_date"])
                self.assertGreaterEqual(t["holding_days"], 0)


class TestNoStopLoss(unittest.TestCase):
    def test_engine_has_no_stop_loss_concept_anywhere(self):
        source = (Path(__file__).resolve().parent.parent
                  / "services" / "backtest_service.py").read_text().lower()
        # "no stop-loss" appears in documentation; an actual implementation would need these.
        self.assertNotIn("stop_price", source)
        self.assertNotIn("stop_loss_pct", source)
        for t in bt._simulate_ticker("NVDA", bars(seed=6), {}, {}):
            self.assertNotIn("stop_loss", t)
            self.assertIn(t.get("exit_reason"),
                          ("TARGET", "TIME_LIMIT", "SIGNAL_EXIT", "OPEN_AT_END"))


class TestExitRules(unittest.TestCase):
    def test_max_holding_days_is_respected(self):
        df = bars(seed=7, drift=0.01, noise=0.05)   # flat: targets unlikely to trigger
        trades = bt._simulate_ticker("NVDA", df, {}, {"max_holding_days": 5,
                                                       "exit_on_signal": False})
        for t in trades:
            if t["exit_reason"] == "TIME_LIMIT":
                self.assertLessEqual(t["holding_days"], 6)

    def test_slippage_worsens_results(self):
        df = bars(seed=8)
        clean = bt._metrics(bt._simulate_ticker("NVDA", df, {}, {}))
        slipped = bt._metrics(bt._simulate_ticker("NVDA", df, {}, {"slippage_pct": 0.5}))
        if clean["trades"] and slipped["trades"]:
            self.assertLessEqual(slipped["avg_return_pct"], clean["avg_return_pct"])

    def test_only_one_open_position_per_ticker(self):
        df = bars(seed=9)
        trades = sorted(bt._simulate_ticker("NVDA", df, {}, {}), key=lambda t: t["entry_date"])
        for a, b in zip(trades, trades[1:]):
            self.assertLessEqual(a["exit_date"], b["entry_date"],
                                 "positions must not overlap for the same ticker")


class TestMetrics(unittest.TestCase):
    def test_metrics_on_hand_computed_trades(self):
        trades = [
            {"entry_date": "2024-01-01", "return_pct": 10.0, "holding_days": 5},
            {"entry_date": "2024-02-01", "return_pct": -5.0, "holding_days": 3},
            {"entry_date": "2024-03-01", "return_pct": 20.0, "holding_days": 10},
            {"entry_date": "2024-04-01", "return_pct": -10.0, "holding_days": 7},
        ]
        m = bt._metrics(trades)
        self.assertEqual(m["trades"], 4)
        self.assertEqual(m["win_rate_pct"], 50.0)
        self.assertEqual(m["avg_return_pct"], 3.75)
        self.assertEqual(m["best_pct"], 20.0)
        self.assertEqual(m["worst_pct"], -10.0)
        self.assertEqual(m["profit_factor"], 2.0)          # 30 gross win / 15 gross loss
        self.assertLess(m["max_drawdown_pct"], 0)

    def test_empty_trades_returns_nulls_not_zeros(self):
        m = bt._metrics([])
        self.assertEqual(m["trades"], 0)
        self.assertIsNone(m["win_rate_pct"])
        self.assertIsNone(m["avg_return_pct"])


class TestWalkForward(unittest.TestCase):
    def test_segments_split_chronologically(self):
        dates = [f"2024-{m:02d}-01" for m in range(1, 13)]
        trades = [{"entry_date": d} for d in dates]
        bt._assign_segments(trades, dates)
        segs = [t["segment"] for t in trades]
        self.assertEqual(segs[0], "IN_SAMPLE")
        self.assertEqual(segs[-1], "OUT_OF_SAMPLE")
        # Once out-of-sample begins it must never revert to an earlier segment.
        order = {"IN_SAMPLE": 0, "VALIDATION": 1, "OUT_OF_SAMPLE": 2}
        self.assertEqual(segs, sorted(segs, key=lambda s: order[s]))


class TestRunBacktest(unittest.TestCase):
    def _bars_set(self, seed=10):
        return {t: bars(seed=seed + i) for i, t in enumerate(["NVDA", "AMD", "SPY", "QQQ"])}

    def test_full_run_shape_and_persistence(self):
        db = make_db()
        data = self._bars_set()
        result = bt.run_backtest(db, ["NVDA", "AMD"], data, {"use_regime": False})

        self.assertIn("overall", result)
        self.assertIn("by_segment", result)
        self.assertIn("buy_and_hold_benchmark", result)
        self.assertTrue(result["limitations"])
        self.assertTrue(any("SURVIVORSHIP" in l for l in result["limitations"]))

        run_id = bt.persist_backtest(db, result, "2024-01-01", "2024-12-31")
        self.assertIsInstance(run_id, int)
        count = db.execute("SELECT COUNT(*) FROM backtest_trades WHERE run_id = ?",
                           (run_id,)).fetchone()[0]
        self.assertEqual(count, len(result["trades"]))

    def test_insufficient_history_is_skipped_not_silently_zeroed(self):
        db = make_db()
        data = {"NVDA": bars(n=50), "SPY": bars(), "QQQ": bars()}
        result = bt.run_backtest(db, ["NVDA"], data, {"use_regime": False})
        self.assertIn("NVDA", result["tickers_skipped"])
        self.assertEqual(result["overall"]["trades"], 0)

    def test_underperforming_buy_and_hold_is_called_out(self):
        db = make_db()
        # Strong steady uptrend: buy-and-hold is very hard to beat with intermittent swings.
        data = {t: bars(drift=0.5, noise=0.05, seed=20 + i)
                for i, t in enumerate(["NVDA", "SPY", "QQQ"])}
        result = bt.run_backtest(db, ["NVDA"], data, {"use_regime": False})
        bh = result["buy_and_hold_benchmark"]["return_pct"]
        total = result["overall"]["total_return_pct"]
        if total is not None and bh is not None and total < bh:
            self.assertTrue(any("UNDERPERFORMED" in w for w in result["warnings"]))

    def test_low_trade_count_is_flagged_as_noise(self):
        db = make_db()
        data = {"NVDA": bars(n=230), "SPY": bars(), "QQQ": bars()}
        result = bt.run_backtest(db, ["NVDA"], data, {"use_regime": False})
        if result["overall"]["trades"] < 30:
            self.assertTrue(any("noise" in w for w in result["warnings"]))


if __name__ == "__main__":
    unittest.main()
