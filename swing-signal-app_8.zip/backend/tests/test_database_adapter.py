"""
Tests for the SQLite<->PostgreSQL adapter in database.py.

The Postgres path itself cannot be exercised here (no Postgres server in this environment, and
psycopg isn't installed locally), so these tests cover the part that CAN be verified
deterministically: the SQL/DDL translation and the row-access shim. Everything the translator
touches is a construct this codebase actually uses.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


class TestUrlDetection(unittest.TestCase):
    def test_detects_postgres_urls(self):
        self.assertTrue(database.is_postgres_url("postgres://u:p@h/db"))
        self.assertTrue(database.is_postgres_url("postgresql://u:p@h/db"))

    def test_rejects_non_postgres(self):
        self.assertFalse(database.is_postgres_url(None))
        self.assertFalse(database.is_postgres_url(""))
        self.assertFalse(database.is_postgres_url("sqlite:///foo.db"))
        self.assertFalse(database.is_postgres_url("/var/data/app.db"))


class TestSqlTranslation(unittest.TestCase):
    def test_positional_placeholders(self):
        self.assertEqual(
            database.translate_sql("SELECT * FROM t WHERE a = ? AND b = ?"),
            "SELECT * FROM t WHERE a = %s AND b = %s")

    def test_named_placeholders(self):
        self.assertEqual(
            database.translate_sql("INSERT INTO t (a, b) VALUES (:a, :b)"),
            "INSERT INTO t (a, b) VALUES (%(a)s, %(b)s)")

    def test_datetime_now_becomes_utc_text(self):
        out = database.translate_sql("INSERT INTO t (ts) VALUES (datetime('now'))")
        self.assertNotIn("datetime('now')", out)
        self.assertIn("now()", out)
        self.assertIn("::text", out)  # columns are TEXT, so the cast must be present

    def test_question_marks_inside_string_literals_are_untouched(self):
        out = database.translate_sql("SELECT * FROM t WHERE label = 'why?' AND id = ?")
        self.assertIn("'why?'", out)
        self.assertIn("id = %s", out)

    def test_upsert_syntax_passes_through_unchanged(self):
        # ON CONFLICT ... DO UPDATE is valid in both dialects and must not be mangled.
        sql = "INSERT INTO t (a) VALUES (?) ON CONFLICT(a) DO UPDATE SET a=excluded.a"
        out = database.translate_sql(sql)
        self.assertIn("ON CONFLICT(a) DO UPDATE SET a=excluded.a", out)


class TestSchemaTranslation(unittest.TestCase):
    def setUp(self):
        self.translated = database.translate_schema(SCHEMA_PATH.read_text())

    def test_pragma_removed(self):
        self.assertNotIn("PRAGMA", self.translated.upper())

    def test_autoincrement_becomes_serial(self):
        self.assertNotIn("AUTOINCREMENT", self.translated.upper())
        self.assertIn("SERIAL PRIMARY KEY", self.translated)

    def test_real_becomes_double_precision(self):
        # Postgres REAL is single-precision and would lose accuracy on prices/P&L.
        self.assertIn("DOUBLE PRECISION", self.translated)
        import re
        self.assertIsNone(re.search(r"\bREAL\b", self.translated, re.IGNORECASE))

    def test_datetime_defaults_translated(self):
        self.assertNotIn("datetime('now')", self.translated)

    def test_all_tables_survive_translation(self):
        for table in ("stocks", "market_bars", "quotes", "technical_indicators", "signals",
                      "signal_history", "signal_outcomes", "news", "trades",
                      "portfolio_positions", "fundamentals", "earnings_info", "fx_rates",
                      "market_regime", "strategy_versions", "alerts", "benchmark_symbols"):
            self.assertIn(table, self.translated, f"{table} missing after translation")


class TestRowShim(unittest.TestCase):
    def test_supports_name_and_index_access(self):
        row = database.Row(["ticker", "price"], ["NVDA", 150.0])
        self.assertEqual(row["ticker"], "NVDA")
        self.assertEqual(row[0], "NVDA")
        self.assertEqual(row[1], 150.0)

    def test_converts_to_plain_dict(self):
        row = database.Row(["ticker", "price"], ["NVDA", 150.0])
        self.assertEqual(dict(row), {"ticker": "NVDA", "price": 150.0})


class TestSqliteConnectionInterface(unittest.TestCase):
    """The SQLite path must expose the same surface the Postgres path does, or code written
    against one would break on the other."""

    def test_interface_parity(self):
        conn = database.connect(None, ":memory:")
        for method in ("execute", "executescript", "insert_returning_id", "commit", "rollback",
                       "close"):
            self.assertTrue(hasattr(conn, method), f"missing {method}")
        self.assertEqual(conn.dialect, "sqlite")
        conn.close()

    def test_insert_returning_id_works_on_sqlite(self):
        conn = database.connect(None, ":memory:")
        conn.executescript(SCHEMA_PATH.read_text())
        conn.execute("INSERT INTO stocks (ticker, name) VALUES (?, ?)", ("NVDA", "NVIDIA"))
        conn.commit()
        new_id = conn.insert_returning_id(
            "INSERT INTO trades (ticker, side, trade_date, quantity, price) "
            "VALUES (?, ?, ?, ?, ?)", ("NVDA", "BUY", "2026-01-01", 10, 100.0))
        self.assertIsInstance(new_id, int)
        self.assertGreater(new_id, 0)
        conn.close()

    def test_rows_support_both_access_styles_on_sqlite(self):
        conn = database.connect(None, ":memory:")
        conn.executescript(SCHEMA_PATH.read_text())
        conn.execute("INSERT INTO stocks (ticker, name) VALUES (?, ?)", ("NVDA", "NVIDIA"))
        conn.commit()
        row = conn.execute("SELECT ticker, name FROM stocks").fetchone()
        self.assertEqual(row["ticker"], "NVDA")
        self.assertEqual(row[0], "NVDA")
        conn.close()


if __name__ == "__main__":
    unittest.main()
