"""
Phase 7 backtest routes.

Backtests are expensive (indicators are recomputed per bar to guarantee no look-ahead), so this
runs synchronously and is deliberately NOT called on page load — the user triggers it.
"""
import json

from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services.backtest_service import persist_backtest, run_backtest
from services.bars_service import get_bars_df
from services.signals_service import TICKERS

bp = Blueprint("api_backtest", __name__, url_prefix="/api/backtest")


@bp.get("/runs")
def list_runs():
    db = get_db()
    rows = db.execute(
        "SELECT id, created_at, strategy_version, tickers, start_date, end_date, total_trades, "
        "win_rate_pct, avg_return_pct, total_return_pct, max_drawdown_pct "
        "FROM backtest_runs ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify({"runs": [dict(r) for r in rows]})


@bp.get("/runs/<int:run_id>")
def get_run(run_id):
    db = get_db()
    row = db.execute("SELECT * FROM backtest_runs WHERE id = ?", (run_id,)).fetchone()
    if not row:
        return jsonify({"error": "Run not found"}), 404
    run = dict(row)
    try:
        run["results"] = json.loads(run.pop("results_json") or "{}")
    except (TypeError, ValueError):
        run["results"] = {}
    trades = db.execute(
        "SELECT * FROM backtest_trades WHERE run_id = ? ORDER BY entry_date DESC LIMIT 300",
        (run_id,)).fetchall()
    run["trades"] = [dict(t) for t in trades]
    return jsonify(run)


@bp.post("/run")
def run():
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca API credentials not configured — no historical bars "
                                 "available to backtest against."}), 200

    payload = request.get_json(silent=True) or {}
    tickers = payload.get("tickers") or TICKERS
    tickers = [t for t in tickers if t in TICKERS]
    if not tickers:
        return jsonify({"error": "No valid tickers from the tracked universe were requested."}), 400

    config = {
        "max_holding_days": int(payload.get("max_holding_days", 40)),
        "slippage_pct": float(payload.get("slippage_pct", 0.0)),
        "commission_per_trade": float(payload.get("commission_per_trade", 0.0)),
        "min_score": float(payload.get("min_score", 0)),
        "exit_on_signal": bool(payload.get("exit_on_signal", True)),
        "use_regime": bool(payload.get("use_regime", True)),
    }

    db = get_db()
    bars_by_ticker = {}
    needed = list(dict.fromkeys(tickers + (["SPY", "QQQ"] if config["use_regime"] else [])))
    for t in needed:
        df, _meta = get_bars_df(db, t, "1Day")
        if not df.empty:
            bars_by_ticker[t] = df.reset_index(drop=True)

    if not bars_by_ticker:
        return jsonify({"error": "No historical bar data available to backtest."}), 200

    result = run_backtest(db, tickers, bars_by_ticker, config)
    dates = sorted({t["entry_date"] for t in result.get("trades", [])})
    run_id = persist_backtest(db, result, dates[0] if dates else None,
                              dates[-1] if dates else None)
    result["run_id"] = run_id
    result["trades"] = result["trades"][:100]   # keep the response payload sane
    return jsonify(result)
