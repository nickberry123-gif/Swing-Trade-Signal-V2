"""
Data-access layer. Backend-agnostic: SQLite locally and in tests, PostgreSQL in production
(selected by the DATABASE_URL env var — see database.py for why and how).

Design notes:
- One connection per request (Flask g-scoped); rows support both name and index access.
- init_db() applies schema.sql and is idempotent (CREATE TABLE IF NOT EXISTS everywhere).
- seed_stocks() upserts the fixed 15-stock universe from config.STOCK_UNIVERSE.
"""
import sqlite3
from pathlib import Path

from flask import g

import database
from config import Config, STOCK_UNIVERSE, BENCHMARK_SYMBOLS

SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"


def get_db():
    if "db" not in g:
        g.db = database.connect(Config.DATABASE_URL, Config.DATABASE_PATH)
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables if they don't exist, and seed the fixed stock universe."""
    conn = database.connect(Config.DATABASE_URL, Config.DATABASE_PATH)
    try:
        with open(SCHEMA_PATH, "r") as f:
            conn.executescript(f.read())
        conn.commit()
        _migrate_add_missing_columns(conn)
        _seed_stocks(conn)
        _seed_benchmark_symbols(conn)
        _seed_strategy_version(conn)
    finally:
        conn.close()


# Columns added to pre-existing tables in later phases. `CREATE TABLE IF NOT EXISTS` will not
# alter a table that already exists, so a database created by an earlier phase would otherwise
# be permanently missing these. Each entry is (table, column, SQL type) and is applied only if
# absent — safe to run on every start, and never destructive.
_LATER_PHASE_COLUMNS = [
    ("fundamentals", "revenue", "REAL"),
    ("fundamentals", "revenue_prior", "REAL"),
    ("fundamentals", "net_income", "REAL"),
    ("fundamentals", "eps_diluted", "REAL"),
    ("fundamentals", "gross_profit", "REAL"),
    ("fundamentals", "operating_income", "REAL"),
    ("fundamentals", "operating_cash_flow", "REAL"),
    ("fundamentals", "capex", "REAL"),
    ("fundamentals", "stockholders_equity", "REAL"),
    ("fundamentals", "long_term_quality_breakdown", "TEXT"),
    ("fundamentals", "fiscal_year", "INTEGER"),
    ("fundamentals", "filed", "TEXT"),
    ("fundamentals", "warnings_json", "TEXT"),
    ("news", "summary", "TEXT"),
    ("news", "impact", "TEXT"),
    ("trades", "fx_rate_usd_gbp", "REAL"),
]


def _existing_columns(conn, table: str) -> set:
    """Column introspection differs per backend: SQLite has PRAGMA, Postgres has
    information_schema. Both return an empty set for an unknown table."""
    try:
        if conn.dialect == "postgres":
            rows = conn.execute(
                "SELECT column_name AS name FROM information_schema.columns "
                "WHERE table_name = %s", (table,)).fetchall()
        else:
            rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
        return {r["name"] for r in rows}
    except Exception:  # noqa: BLE001 — introspection failure must never block startup
        return set()


def _migrate_add_missing_columns(conn):
    for table, column, coltype in _LATER_PHASE_COLUMNS:
        existing = _existing_columns(conn, table)
        if not existing:
            continue  # table doesn't exist yet; schema.sql will have created it
        if column not in existing:
            col_sql = "DOUBLE PRECISION" if (coltype == "REAL" and conn.dialect == "postgres") else coltype
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_sql}")
                conn.commit()
            except Exception:  # noqa: BLE001 — a concurrent start may have added it; never fatal
                conn.rollback()
    conn.commit()


def _seed_stocks(conn: sqlite3.Connection):
    for s in STOCK_UNIVERSE:
        conn.execute(
            """
            INSERT INTO stocks (ticker, name, sector, industry, exchange)
            VALUES (:ticker, :name, :sector, :industry, :exchange)
            ON CONFLICT(ticker) DO UPDATE SET
                name = excluded.name,
                sector = excluded.sector,
                industry = excluded.industry,
                exchange = excluded.exchange
            """,
            s,
        )
    conn.commit()


def _seed_benchmark_symbols(conn: sqlite3.Connection):
    for b in BENCHMARK_SYMBOLS:
        conn.execute(
            """
            INSERT INTO benchmark_symbols (ticker, name, category)
            VALUES (:ticker, :name, :category)
            ON CONFLICT(ticker) DO UPDATE SET name = excluded.name, category = excluded.category
            """,
            b,
        )
    conn.commit()


def _seed_strategy_version(conn: sqlite3.Connection):
    """Register strategy v1.0 so later phases have a version to attach signals to."""
    import json

    weights = {
        "long_term_trend": 20, "short_term_trend": 10, "momentum": 15,
        "rsi_pullback": 10, "volume": 10, "support_resistance": 10,
        "relative_strength": 10, "market_regime": 5, "news": 5, "earnings_risk": 5,
    }
    conn.execute(
        """
        INSERT INTO strategy_versions (version, description, weights_json, params_json)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(version) DO NOTHING
        """,
        (
            "v1.0",
            "Initial 100-point long-only swing signal engine per project spec.",
            json.dumps(weights),
            json.dumps({}),
        ),
    )
    conn.commit()


def init_app(app):
    app.teardown_appcontext(close_db)
