function statTile(label, value, sub, cls) {
  return `<div class="stat-tile"><div class="st-label">${label}</div>
    <div class="st-value ${cls || ""}">${value}</div>
    ${sub ? `<div class="st-sub">${sub}</div>` : ""}</div>`;
}

function num(v, digits, suffix) {
  if (v === null || v === undefined) return "—";
  return fmtNum(v, digits === undefined ? 2 : digits) + (suffix || "");
}

function segRow(name, m) {
  return `<tr>
    <td>${name.replace(/_/g, " ")}</td>
    <td class="text-right">${m.trades}</td>
    <td class="text-right">${num(m.win_rate_pct, 1, "%")}</td>
    <td class="text-right ${pctClass(m.avg_return_pct)}">${fmtPct(m.avg_return_pct, 2)}</td>
    <td class="text-right ${pctClass(m.total_return_pct)}">${fmtPct(m.total_return_pct, 2)}</td>
    <td class="text-right num-neg">${fmtPct(m.max_drawdown_pct, 2)}</td>
  </tr>`;
}

function renderResults(r) {
  document.getElementById("bt-results").style.display = "";
  const o = r.overall || {};

  document.getElementById("bt-overall").innerHTML = [
    statTile("Total Return", fmtPct(o.total_return_pct, 2), "compounded across trades", pctClass(o.total_return_pct)),
    statTile("Trades", o.trades ?? "—", "simulated"),
    statTile("Win Rate", num(o.win_rate_pct, 1, "%")),
    statTile("Avg Return / Trade", fmtPct(o.avg_return_pct, 2), null, pctClass(o.avg_return_pct)),
    statTile("Max Drawdown", fmtPct(o.max_drawdown_pct, 2), "peak to trough", "num-neg"),
    statTile("Profit Factor", num(o.profit_factor, 2), "gross win / gross loss"),
    statTile("Avg Hold", num(o.avg_holding_days, 1) + " days"),
    statTile("Best / Worst", `${fmtPct(o.best_pct, 1)} / ${fmtPct(o.worst_pct, 1)}`),
  ].join("");

  const bh = r.buy_and_hold_benchmark || {};
  const beat = o.total_return_pct !== null && bh.return_pct !== null &&
               o.total_return_pct !== undefined && bh.return_pct !== undefined
               ? o.total_return_pct - bh.return_pct : null;
  document.getElementById("bt-benchmark").innerHTML = `
    <div class="stat-grid">
      ${statTile("Strategy", fmtPct(o.total_return_pct, 2), null, pctClass(o.total_return_pct))}
      ${statTile("Buy &amp; Hold", fmtPct(bh.return_pct, 2), `equal weight, ${bh.tickers || 0} stocks`, pctClass(bh.return_pct))}
      ${statTile("Difference", fmtPct(beat, 2), beat !== null && beat < 0 ? "strategy underperformed doing nothing" : "strategy added value", pctClass(beat))}
    </div>
    <p class="inline-note">Buy &amp; hold is the honest benchmark: if actively trading these stocks does not beat simply owning them, the extra effort, tax events and screen time are not being rewarded.</p>`;

  const segs = r.by_segment || {};
  document.getElementById("bt-segments").innerHTML =
    ["IN_SAMPLE", "VALIDATION", "OUT_OF_SAMPLE"]
      .filter((s) => segs[s]).map((s) => segRow(s, segs[s])).join("") ||
    `<tr class="loading-row"><td colspan="6">No trades to segment.</td></tr>`;

  document.getElementById("bt-wf-note").innerHTML =
    `Strategy v1.0's weights are <strong>fixed, not fitted to this data</strong> — nothing was optimised. ` +
    `So these segments do not prove absence of overfitting the way they would for a tuned model; ` +
    `what they show is whether the strategy holds up across <em>different market periods</em>. ` +
    `If a future version starts tuning weights, that tuning must happen on in-sample data only, ` +
    `or the out-of-sample column stops meaning anything.`;

  const byTicker = r.by_ticker || {};
  document.getElementById("bt-byticker").innerHTML = Object.keys(byTicker)
    .sort((a, b) => (byTicker[b].total_return_pct || -999) - (byTicker[a].total_return_pct || -999))
    .map((t) => {
      const m = byTicker[t];
      return `<tr onclick="window.location.href='/stocks/${encodeURIComponent(t)}'">
        <td><span class="ticker-badge">${t}</span></td>
        <td class="text-right">${m.trades}</td>
        <td class="text-right">${num(m.win_rate_pct, 1, "%")}</td>
        <td class="text-right ${pctClass(m.avg_return_pct)}">${fmtPct(m.avg_return_pct, 2)}</td>
        <td class="text-right ${pctClass(m.total_return_pct)}">${fmtPct(m.total_return_pct, 2)}</td>
        <td class="text-right">${num(m.avg_holding_days, 1)}</td>
      </tr>`;
    }).join("") || `<tr class="loading-row"><td colspan="6">No trades.</td></tr>`;

  const trades = r.trades || [];
  document.getElementById("bt-trades").innerHTML = trades.length
    ? trades.slice(0, 100).map((t) => `
        <tr>
          <td><span class="ticker-badge">${t.ticker}</span></td>
          <td>${t.signal_date}</td>
          <td>${t.entry_date}</td>
          <td class="text-right">${fmtPrice(t.entry_price)}</td>
          <td>${t.exit_date || "—"}</td>
          <td class="text-right">${fmtPrice(t.exit_price)}</td>
          <td>${(t.exit_reason || "").replace(/_/g, " ")}</td>
          <td class="text-right">${t.holding_days ?? "—"}</td>
          <td class="text-right ${pctClass(t.return_pct)}">${fmtPct(t.return_pct, 2)}</td>
          <td class="text-dim" style="font-size:11px;">${(t.segment || "").replace(/_/g, " ")}</td>
        </tr>`).join("")
    : `<tr class="loading-row"><td colspan="10">No trades were generated. In a relentless uptrend this is expected: the strategy refuses to buy above its maximum entry price rather than chase.</td></tr>`;

  document.getElementById("bt-limitations").innerHTML =
    (r.limitations || []).map((l) => `<li>${l}</li>`).join("");

  document.getElementById("bt-message").innerHTML =
    (r.warnings || []).map((w) => `<div class="warn-banner">${w}</div>`).join("");
}

async function loadRuns() {
  try {
    const data = await apiGet("/api/backtest/runs");
    const runs = data.runs || [];
    document.getElementById("bt-runs").innerHTML = runs.length
      ? runs.map((r) => `
          <tr>
            <td>#${r.id}</td>
            <td>${fmtTime(r.created_at)}</td>
            <td class="text-right">${r.total_trades ?? "—"}</td>
            <td class="text-right">${num(r.win_rate_pct, 1, "%")}</td>
            <td class="text-right ${pctClass(r.avg_return_pct)}">${fmtPct(r.avg_return_pct, 2)}</td>
            <td class="text-right ${pctClass(r.total_return_pct)}">${fmtPct(r.total_return_pct, 2)}</td>
            <td class="text-right num-neg">${fmtPct(r.max_drawdown_pct, 2)}</td>
          </tr>`).join("")
      : `<tr class="loading-row"><td colspan="7">No backtests run yet.</td></tr>`;
  } catch (e) {
    document.getElementById("bt-runs").innerHTML =
      `<tr class="loading-row"><td colspan="7">Could not load runs: ${e.message}</td></tr>`;
  }
}

document.getElementById("bt-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const btn = document.getElementById("bt-run-btn");
  btn.disabled = true;
  btn.textContent = "Running… (30-90s)";
  document.getElementById("bt-message").innerHTML =
    `<div class="warn-banner">Recomputing indicators for every historical bar to guarantee no look-ahead. This takes a while — leave the page open.</div>`;

  try {
    const res = await fetch("/api/backtest/run", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        max_holding_days: Number(document.getElementById("bt-hold").value),
        min_score: Number(document.getElementById("bt-minscore").value),
        slippage_pct: Number(document.getElementById("bt-slip").value),
        commission_per_trade: Number(document.getElementById("bt-comm").value),
        exit_on_signal: document.getElementById("bt-exit").value === "true",
      }),
    });
    const data = await res.json();
    if (data.error) {
      document.getElementById("bt-message").innerHTML = `<div class="error-banner">${data.error}</div>`;
    } else {
      renderResults(data);
      loadRuns();
    }
  } catch (e) {
    document.getElementById("bt-message").innerHTML =
      `<div class="error-banner">Backtest failed: ${e.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Run Backtest";
  }
});

loadRuns();
