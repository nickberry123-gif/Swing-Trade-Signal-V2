// TradingView is used strictly as the visual chart layer (official embedded widget).
// No data is scraped or read back out of it; nothing here feeds the signal engine.
let tvSymbol = `${window.STOCK_EXCHANGE || "NASDAQ"}:${window.STOCK_TICKER}`;

function renderChart(interval) {
  const container = document.getElementById("tv_chart_widget");
  // A failure here (e.g. TradingView's script blocked/unreachable) must never take down the
  // rest of the page — price, indicators, and everything else below are independent of the
  // chart and must keep working even if the chart itself can't load.
  try {
    if (typeof TradingView === "undefined") {
      container.innerHTML = `<div class="warn-banner" style="margin:16px;">Chart unavailable — TradingView's widget script did not load (network issue). This does not affect price, indicator, or signal data below, which come from Alpaca via this app's own backend.</div>`;
      return;
    }
    container.innerHTML = "";
    // eslint-disable-next-line no-undef
    new TradingView.widget({
      autosize: true,
      symbol: tvSymbol,
      interval: interval,
      timezone: "America/New_York",
      theme: "dark",
      style: "1",
      locale: "en",
      toolbar_bg: "#10151f",
      enable_publishing: false,
      allow_symbol_change: false,
      hide_side_toolbar: false,
      studies: ["MASimple@tv-basicstudies"],
      container_id: "tv_chart_widget",
    });
  } catch (e) {
    container.innerHTML = `<div class="warn-banner" style="margin:16px;">Chart failed to load: ${e.message}. This does not affect price, indicator, or signal data below.</div>`;
  }
}

document.querySelectorAll(".tf-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tf-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    renderChart(btn.dataset.interval);
  });
});

renderChart("D");

async function refreshSnapshot() {
  const ticker = window.STOCK_TICKER;
  const errBox = document.getElementById("snapshot-error");
  try {
    const snap = await apiGet(`/api/stocks/${encodeURIComponent(ticker)}/snapshot`);

    if (snap.data_status === "UNAVAILABLE" || snap.error) {
      errBox.innerHTML = `<div class="error-banner">DATA FEED ERROR — ${snap.error || "no data available"}. ${
        snap.last_known_price ? `Last known price from local database: $${Number(snap.last_known_price).toFixed(2)} (as of ${fmtTime(snap.as_of)}) — NOT live.` : ""
      }</div>`;
    } else {
      errBox.innerHTML = "";
    }

    document.getElementById("dp-price").textContent = fmtPrice(snap.last_price !== undefined ? snap.last_price : snap.last_known_price);
    document.getElementById("dp-change").innerHTML = snap.change !== undefined ? fmtChange(snap.change, snap.change_pct) : "—";
    document.getElementById("dp-status-pill").innerHTML = statusPillHtml(snap.data_status);

    document.getElementById("dp-open").textContent = fmtPrice(snap.daily_open);
    document.getElementById("dp-high").textContent = fmtPrice(snap.daily_high);
    document.getElementById("dp-low").textContent = fmtPrice(snap.daily_low);
    document.getElementById("dp-volume").textContent = fmtVolume(snap.daily_volume);
    document.getElementById("dp-prevclose").textContent = fmtPrice(snap.prev_close);
    document.getElementById("dp-bidask").textContent =
      snap.bid_price && snap.ask_price ? `${fmtPrice(snap.bid_price)} / ${fmtPrice(snap.ask_price)}` : "—";
    document.getElementById("dp-trade-ts").textContent = fmtTime(snap.last_trade_ts);
    document.getElementById("dp-fetched-ts").textContent = fmtTime(snap.fetched_at);
  } catch (e) {
    errBox.innerHTML = `<div class="error-banner">DATA FEED ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

refreshSnapshot();
setInterval(refreshSnapshot, 15000);

function fmtZone(low, high) {
  if (low === null || low === undefined || high === null || high === undefined) return "—";
  return `${fmtPrice(low)} – ${fmtPrice(high)}`;
}

function rsCellHtml(v) {
  if (v === null || v === undefined) return `<span class="text-dim">&mdash;</span>`;
  return `<span class="${pctClass(v)}">${fmtPct(v, 1)}</span>`;
}

async function refreshIndicators() {
  const ticker = window.STOCK_TICKER;
  const errBox = document.getElementById("indicators-error");
  try {
    const ind = await apiGet(`/api/stocks/${encodeURIComponent(ticker)}/indicators`);

    if (ind.data_status === "UNAVAILABLE" || ind.data_error) {
      errBox.innerHTML = `<div class="warn-banner">TECHNICAL INDICATORS UNAVAILABLE — ${ind.data_error || "no bar data available"}.</div>`;
    } else {
      errBox.innerHTML = "";
    }

    // Trend
    document.getElementById("ind-trend-label").textContent = ind.trend_label || "—";
    document.getElementById("ind-trend-label").className = "value " + trendClass(ind.trend_label);
    document.getElementById("ind-bars-used").textContent = ind.bars_used ? `based on ${ind.bars_used} bars` : "";
    const reasonsEl = document.getElementById("ind-trend-reasons");
    const reasons = Array.isArray(ind.trend_reasons) ? ind.trend_reasons : [];
    reasonsEl.innerHTML = reasons.length
      ? reasons.map((r) => `<li>${r}</li>`).join("")
      : `<li class="text-dim">${(ind.warnings && ind.warnings[0]) || "No trend data available."}</li>`;

    // Support / resistance
    document.getElementById("ind-resistance-zone").textContent = fmtZone(ind.resistance_low, ind.resistance_high);
    document.getElementById("ind-support-zone").textContent = fmtZone(ind.support_low, ind.support_high);

    // Indicator tiles
    document.getElementById("ind-rsi14").textContent = fmtNum(ind.rsi14, 1);
    document.getElementById("ind-rsi7").textContent = fmtNum(ind.rsi7, 1);
    document.getElementById("ind-stochrsi").textContent = fmtNum(ind.stoch_rsi, 1);
    document.getElementById("ind-macdhist").textContent = ind.macd_hist !== null && ind.macd_hist !== undefined ? Number(ind.macd_hist).toFixed(3) : "—";
    document.getElementById("ind-adx").textContent = fmtNum(ind.adx, 1);
    document.getElementById("ind-atr").textContent = ind.atr14 !== null && ind.atr14 !== undefined
      ? `${fmtPrice(ind.atr14)} (${fmtNum(ind.atr_pct, 1)}%)` : "—";
    document.getElementById("ind-sma50").textContent = fmtPrice(ind.sma50);
    document.getElementById("ind-sma200").textContent = fmtPrice(ind.sma200);
    document.getElementById("ind-bbwidth").textContent = ind.bb_width !== null && ind.bb_width !== undefined ? (Number(ind.bb_width) * 100).toFixed(2) + "%" : "—";
    document.getElementById("ind-histvol").textContent = ind.hist_volatility !== null && ind.hist_volatility !== undefined ? fmtNum(ind.hist_volatility, 1) + "%" : "—";
    document.getElementById("ind-voltrend").textContent = ind.volume_trend || "—";
    document.getElementById("ind-relvol").textContent = ind.relative_volume !== null && ind.relative_volume !== undefined ? Number(ind.relative_volume).toFixed(2) + "x" : "—";
    document.getElementById("ind-52wh").textContent = fmtPrice(ind.high_52w);
    document.getElementById("ind-52wl").textContent = fmtPrice(ind.low_52w);

    // Relative strength
    const rs = ind.relative_strength || {};
    document.getElementById("rs-spy-5").innerHTML = rsCellHtml(rs.rs_spy_5d);
    document.getElementById("rs-spy-20").innerHTML = rsCellHtml(rs.rs_spy_20d);
    document.getElementById("rs-spy-50").innerHTML = rsCellHtml(rs.rs_spy_50d);
    document.getElementById("rs-spy-200").innerHTML = rsCellHtml(rs.rs_spy_200d);
    document.getElementById("rs-qqq-5").innerHTML = rsCellHtml(rs.rs_qqq_5d);
    document.getElementById("rs-qqq-20").innerHTML = rsCellHtml(rs.rs_qqq_20d);
    document.getElementById("rs-qqq-50").innerHTML = rsCellHtml(rs.rs_qqq_50d);
    document.getElementById("rs-qqq-200").innerHTML = rsCellHtml(rs.rs_qqq_200d);
    document.getElementById("rs-sector-label").textContent = ind.sector_etf ? `Sector (${ind.sector_etf})` : "Sector ETF";
    document.getElementById("rs-sector-5").innerHTML = rsCellHtml(rs.rs_sector_5d);
    document.getElementById("rs-sector-20").innerHTML = rsCellHtml(rs.rs_sector_20d);
    document.getElementById("rs-sector-50").innerHTML = rsCellHtml(rs.rs_sector_50d);
    document.getElementById("rs-sector-200").innerHTML = rsCellHtml(rs.rs_sector_200d);
  } catch (e) {
    errBox.innerHTML = `<div class="error-banner">TECHNICAL INDICATORS ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

refreshIndicators();
setInterval(refreshIndicators, 60000);

const SIGNAL_COMPONENTS = [
  { key: "score_long_trend", label: "Long-Term Trend", max: 20 },
  { key: "score_short_trend", label: "Short-Term Trend", max: 10 },
  { key: "score_momentum", label: "Momentum", max: 15 },
  { key: "score_rsi_pullback", label: "RSI Pullback Quality", max: 10 },
  { key: "score_volume", label: "Volume", max: 10 },
  { key: "score_support_resistance", label: "Support / Resistance", max: 10 },
  { key: "score_relative_strength", label: "Relative Strength", max: 10 },
  { key: "score_market_regime", label: "Market Regime", max: 5 },
  { key: "score_news", label: "News (pending Phase 4)", max: 5 },
  { key: "score_earnings_risk", label: "Earnings Risk (pending Phase 4)", max: 5 },
];

function levelBoxHtml(label, value) {
  return `<div class="level-box"><div class="lk">${label}</div><div class="lv">${fmtPrice(value)}</div></div>`;
}

async function refreshSignal() {
  const ticker = window.STOCK_TICKER;
  const errBox = document.getElementById("signal-error");
  try {
    const sig = await apiGet(`/api/signals/${encodeURIComponent(ticker)}`);

    if (sig.signal_label === "NO DATA" || sig.data_status === "UNAVAILABLE" || sig.error) {
      errBox.innerHTML = `<div class="warn-banner">SIGNAL UNAVAILABLE — ${sig.data_error || sig.error || "no data available"}.</div>`;
      document.getElementById("sig-pill").innerHTML = signalPillHtml(sig.signal_label || "NO DATA");
      document.getElementById("sig-score").textContent = "—";
      document.getElementById("sig-score-max").textContent = "";
      document.getElementById("sig-breakdown").innerHTML = `<div class="text-dim">No component breakdown — no data available.</div>`;
      return;
    }
    errBox.innerHTML = "";

    document.getElementById("sig-pill").innerHTML = signalPillHtml(sig.signal_label);
    document.getElementById("sig-score").textContent = fmtNum(sig.score_total, 1);
    document.getElementById("sig-score").className = "score-value " + signalScoreClass(sig.signal_label);
    document.getElementById("sig-score-max").textContent = `/ ${sig.score_max_currently_available || 90} pts currently achievable (of 100 designed)`;
    document.getElementById("sig-setup").innerHTML = sig.strategy_setup && sig.strategy_setup !== "NONE"
      ? `<span class="setup-badge">${sig.strategy_setup.replace("_", " ")}</span>` : "";
    document.getElementById("sig-thesis").textContent = sig.long_term_thesis
      ? `Long-term thesis: ${sig.long_term_thesis}` : "";

    document.getElementById("sig-levels-grid").innerHTML = [
      levelBoxHtml("Ideal Buy", sig.ideal_buy),
      `<div class="level-box"><div class="lk">Buy Zone</div><div class="lv">${fmtZone(sig.buy_zone_low, sig.buy_zone_high)}</div></div>`,
      levelBoxHtml("Max Entry", sig.max_entry),
      `<div class="level-box"><div class="lk">Expected Upside</div><div class="lv ${pctClass(sig.expected_upside_pct)}">${fmtPct(sig.expected_upside_pct, 1)}</div></div>`,
      levelBoxHtml("Target 1", sig.target1),
      levelBoxHtml("Primary Target", sig.primary_target),
      levelBoxHtml("Target 3", sig.target3),
    ].join("");

    document.getElementById("sig-breakdown").innerHTML = SIGNAL_COMPONENTS.map((c) => {
      const val = sig[c.key];
      const pct = val !== null && val !== undefined ? Math.max(0, Math.min(100, (val / c.max) * 100)) : 0;
      const display = val !== null && val !== undefined ? `${fmtNum(val, 1)} / ${c.max}` : `— / ${c.max}`;
      return `
        <div class="score-breakdown-row">
          <div class="comp-name">${c.label}</div>
          <div class="comp-bar-wrap"><div class="comp-bar" style="width:${pct}%;"></div></div>
          <div class="comp-value">${display}</div>
        </div>
      `;
    }).join("");
  } catch (e) {
    errBox.innerHTML = `<div class="error-banner">SIGNAL ERROR — could not reach the backend: ${e.message}</div>`;
  }
}

refreshSignal();
setInterval(refreshSignal, 60000);

function bigMoney(v) {
  if (v === null || v === undefined) return "—";
  const n = Number(v);
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 1e12) return `${sign}$${(abs / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `${sign}$${(abs / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `${sign}$${(abs / 1e6).toFixed(2)}M`;
  return `${sign}$${abs.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
}

function fundRow(label, value, formatter) {
  const display = value === null || value === undefined
    ? `<span class="text-dim">UNAVAILABLE</span>`
    : formatter(value);
  return `<div class="fundamental-row"><span class="fk">${label}</span><span class="fv">${display}</span></div>`;
}

async function refreshFundamentals() {
  const ticker = window.STOCK_TICKER;
  const errBox = document.getElementById("fundamentals-error");
  try {
    const f = await apiGet(`/api/fundamentals/${encodeURIComponent(ticker)}`);

    if (f.data_status === "UNAVAILABLE") {
      errBox.innerHTML = `<div class="warn-banner">FUNDAMENTALS UNAVAILABLE — ${f.data_error || "no data"}. The quality score is not shown rather than being estimated.</div>`;
    } else {
      errBox.innerHTML = "";
    }

    const score = f.long_term_quality_score;
    document.getElementById("fund-score").textContent = score !== null && score !== undefined ? fmtNum(score, 0) : "—";
    document.getElementById("fund-score").className = "quality-score-big " + (
      score === null || score === undefined ? "text-dim"
        : score >= 62 ? "num-pos" : score >= 45 ? "text-dim" : "num-neg");
    document.getElementById("fund-thesis").textContent = f.thesis || "UNAVAILABLE";
    document.getElementById("fund-source").textContent = f.source
      ? `Source: ${f.source} · fiscal year ${f.fiscal_year || "n/a"} · period ending ${f.as_of || "n/a"}` +
        (f.coverage_pct !== null && f.coverage_pct !== undefined ? ` · ${fmtNum(f.coverage_pct, 0)}% criteria coverage` : "")
      : "No fundamentals source available.";

    const breakdown = f.quality_breakdown || [];
    document.getElementById("fund-breakdown").innerHTML = breakdown.length
      ? breakdown.map((b) => {
          const pct = b.points !== null && b.points !== undefined ? (b.points / b.max) * 100 : 0;
          const val = b.points !== null && b.points !== undefined
            ? `${fmtNum(b.points, 1)} / ${b.max}` : `<span class="text-dim">n/a</span>`;
          return `
            <div class="score-breakdown-row">
              <div class="comp-name">${b.criterion}<div class="text-dim" style="font-size:10.5px;">${b.note || ""}</div></div>
              <div class="comp-bar-wrap"><div class="comp-bar" style="width:${pct}%;"></div></div>
              <div class="comp-value">${val}</div>
            </div>`;
        }).join("")
      : `<div class="text-dim">No quality criteria could be evaluated.</div>`;

    document.getElementById("fund-financials").innerHTML = [
      fundRow("Revenue", f.revenue, bigMoney),
      fundRow("Revenue growth (YoY)", f.revenue_growth_pct, (v) => `<span class="${pctClass(v)}">${fmtPct(v, 1)}</span>`),
      fundRow("Net income", f.net_income, bigMoney),
      fundRow("Diluted EPS", f.eps_diluted, (v) => `$${Number(v).toFixed(2)}`),
      fundRow("EPS growth (YoY)", f.eps_growth_pct, (v) => `<span class="${pctClass(v)}">${fmtPct(v, 1)}</span>`),
      fundRow("Gross margin", f.gross_margin_pct, (v) => fmtNum(v, 1) + "%"),
      fundRow("Operating margin", f.operating_margin_pct, (v) => fmtNum(v, 1) + "%"),
      fundRow("Operating cash flow", f.operating_cash_flow, bigMoney),
      fundRow("Capital expenditure", f.capex, bigMoney),
      fundRow("Free cash flow", f.free_cash_flow, bigMoney),
      fundRow("FCF margin", f.fcf_margin_pct, (v) => fmtNum(v, 1) + "%"),
      fundRow("Return on invested capital (proxy)", f.roic_pct, (v) => fmtNum(v, 1) + "%"),
      fundRow("Cash", f.total_cash, bigMoney),
      fundRow("Total debt", f.total_debt, bigMoney),
      fundRow("Shareholders' equity", f.stockholders_equity, bigMoney),
    ].join("") + `<p class="inline-note">Figures are as reported in the company's most recent annual filing. "UNAVAILABLE" means that concept was not tagged in the filing — it does not mean zero.</p>`;

    const e = f.earnings || {};
    const days = e.days_until_estimated_report;
    document.getElementById("earnings-box").innerHTML = e.estimated_next_report
      ? `
        <div class="stat-grid">
          <div class="stat-tile"><div class="st-label">Estimated Next Report</div><div class="st-value" style="font-size:16px;">${e.estimated_next_report}</div><div class="st-sub">${days !== null && days !== undefined ? `~${days} days away` : ""}</div></div>
          <div class="stat-tile"><div class="st-label">Estimate Confidence</div><div class="st-value" style="font-size:16px;">${e.estimate_confidence || "LOW"}</div></div>
          <div class="stat-tile"><div class="st-label">Last Filed</div><div class="st-value" style="font-size:16px;">${e.last_filed || "—"}</div><div class="st-sub">${e.last_form || ""}</div></div>
        </div>
        <p class="inline-note"><strong>This is an estimate</strong>, derived from the historical gap between this company's SEC filings. It is NOT a company-confirmed earnings date — verify with the company's investor relations page before trading around it.</p>`
      : `<div class="text-dim">No estimated earnings date could be derived from SEC filing history.</div>`;
  } catch (err) {
    errBox.innerHTML = `<div class="error-banner">FUNDAMENTALS ERROR — ${err.message}</div>`;
  }
}

async function refreshNews() {
  const ticker = window.STOCK_TICKER;
  const box = document.getElementById("news-box");
  try {
    const data = await apiGet(`/api/news/${encodeURIComponent(ticker)}`);
    const items = data.items || [];
    if (items.length === 0) {
      box.innerHTML = `<div class="text-dim">${data.error ? `News unavailable — ${data.error}` : "No recent news found for this stock in the last 14 days."}</div>`;
      return;
    }
    box.innerHTML = items.map((n) => {
      const sentClass = n.sentiment === "BULLISH" ? "tag-bullish" : n.sentiment === "BEARISH" ? "tag-bearish" : "tag-neutral";
      return `
        <div class="news-item">
          <a href="${n.url || "#"}" target="_blank" rel="noopener noreferrer">${(n.headline || "").replace(/</g, "&lt;")}</a>
          <div class="news-meta">
            <span class="tag ${sentClass}">${n.sentiment || "NEUTRAL"}</span>
            ${n.impact === "HIGH" ? `<span class="tag tag-high">HIGH IMPACT</span>` : ""}
            <span>${n.source || ""}</span>
            <span>${fmtTime(n.published_at)}</span>
          </div>
        </div>`;
    }).join("") + `<p class="inline-note">Sentiment tags come from a simple, transparent keyword classifier — not NLP or AI sentiment analysis. Treat them as a rough filter and read the headline yourself.</p>`;
  } catch (err) {
    box.innerHTML = `<div class="error-banner">NEWS ERROR — ${err.message}</div>`;
  }
}

refreshFundamentals();
refreshNews();
setInterval(refreshNews, 300000);


async function refreshExplanation() {
  const ticker = window.STOCK_TICKER;
  try {
    const e = await apiGet(`/api/explain/${encodeURIComponent(ticker)}`);
    document.getElementById("explain-text").textContent = e.text || "No explanation available.";
    document.getElementById("explain-generator").textContent =
      e.generator === "rule-based" ? "deterministic" : `written by ${e.generator}`;
    document.getElementById("explain-note").textContent = e.generator_note || "";
  } catch (err) {
    document.getElementById("explain-text").textContent =
      "Explanation unavailable: " + err.message;
  }
}

refreshExplanation();
setInterval(refreshExplanation, 120000);
