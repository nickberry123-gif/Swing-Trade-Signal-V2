"""
The share-basis defect: a filing's share count against today's price.

THE FAILURE, EXACTLY. Booking Holdings reported 31,673,346 shares on the cover of its February
2026 annual report. In August the stock traded at $204.72. Multiply the two and the company is
worth $6.5bn — while earning $8.8bn of operating profit and $9.1bn of operating cash flow, on a
price/earnings ratio of 1.24.

Every input was individually correct. The share count was right for February. The price was right
for August. What was wrong was combining them, because a corporate action in between put them on
different bases — and the result inherited into market capitalisation, enterprise value,
free-cash-flow yield and buyback yield.

NOTHING CAUGHT IT. Price-to-sales was 0.24, comfortably inside its band. The share-count
consistency check did not fire because diluted and outstanding agreed — both were pre-split. Two
anomaly checks, and the problem went between them.

This file exists so that cannot happen again, and it is written generically: not one test mentions
a split factor, and none is specific to Booking.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
from config import STOCK_UNIVERSE  # noqa: E402
from providers.edgar_concepts import HISTORY_VALUE_FIELDS, tags_for  # noqa: E402
from providers.fundamentals_base import AnnualPeriod  # noqa: E402
from providers.sec_edgar_provider import SecEdgarProvider  # noqa: E402
from services import data_validation_service as dv  # noqa: E402
from services import fundamentals_history_service as fh  # noqa: E402

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]))
    conn.commit()
    return conn


def period(period_end, filed, ticker="BKNG", **values):
    full = {f: None for f in HISTORY_VALUE_FIELDS}
    full.update(values)
    return AnnualPeriod(ticker=ticker, source="test", period_end=period_end, filed=filed,
                        taxonomy="us-gaap", currency="USD", form="10-K", values=full)


def booking_shaped(db, ticker="BKNG"):
    """Booking's real reported figures for FY2025, as stored by the live app."""
    p = period("2025-12-31", "2026-02-18", ticker=ticker,
               revenue=26_917e6, operating_income=8_825e6, pretax_income=6_832e6,
               net_income=5_404e6, eps_diluted=165.57, diluted_shares=32.639e6,
               shares_outstanding=31_673_346, buybacks=6_440e6, dividends_paid=1_248e6,
               operating_cash_flow=9_409e6, capex=322e6, total_assets=29_264e6,
               stockholders_equity=-5_578e6, total_debt=18_736e6, total_cash=17_203e6,
               interest_expense=1_617e6, depreciation_amortisation=623e6)
    p.ticker = ticker
    fh.store_history(db, ticker, [p])
    return db


class TheMostRecentShareCountIsUsed(unittest.TestCase):
    """A market capitalisation is a share count times a price at a moment. Pinning the count to
    the last ANNUAL report is the whole defect — quarterly cover pages carry the same element and
    are far more recent."""

    def test_a_quarterly_cover_page_supersedes_the_annual_one(self):
        db = booking_shaped(make_db())
        fh.store_share_counts(db, "BKNG", [
            {"as_of": "2026-02-10", "filed": "2026-02-18", "form": "10-K", "shares": 31_673_346},
            {"as_of": "2026-07-25", "filed": "2026-08-01", "form": "10-Q", "shares": 950_200_000},
        ])
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        self.assertEqual(out["share_count"], 950_200_000)
        self.assertIn("10-Q", out["shares_basis"])

    def test_the_market_cap_becomes_credible_once_the_count_is_current(self):
        """$6.5bn on $8.8bn of operating profit was the symptom. With the current count the same
        price gives a figure that could actually be true."""
        db = booking_shaped(make_db())
        fh.store_share_counts(db, "BKNG", [
            {"as_of": "2026-07-25", "filed": "2026-08-01", "form": "10-Q", "shares": 950_200_000}])
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        cap = out["metrics"]["market_cap"]["value"]
        self.assertGreater(cap, 150e9)
        self.assertLess(cap, 250e9)

    def test_every_price_based_metric_is_re_derived_from_the_corrected_count(self):
        """The four that inherited the error: enterprise value, FCF yield, buyback yield and P/E."""
        db = booking_shaped(make_db())
        fh.store_share_counts(db, "BKNG", [
            {"as_of": "2026-07-25", "filed": "2026-08-01", "form": "10-Q", "shares": 950_200_000}])
        m = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")["metrics"]
        self.assertLess(m["fcf_yield_pct"]["value"], 10.0)       # was 140.1
        self.assertLess(m["buyback_yield_pct"]["value"], 10.0)   # was 99.3
        self.assertGreater(m["enterprise_value"]["value"], 150e9)
        self.assertIn(m["pe_ratio"]["verdict"], dv.USABLE)

    def test_the_annual_count_is_still_used_when_nothing_newer_exists(self):
        db = booking_shaped(make_db(), ticker="AAPL")
        out = dv.validate_ticker(db, "AAPL", price=204.72, price_as_of="2026-08-17")
        self.assertEqual(out["share_count"], 31_673_346)
        self.assertIn("no more recent filing", out["shares_basis"])

    def test_a_share_count_not_yet_published_is_invisible(self):
        """Point-in-time applies to the new store too: a count dated June does not become usable
        until the quarterly report carrying it is filed in August."""
        db = booking_shaped(make_db())
        fh.store_share_counts(db, "BKNG", [
            {"as_of": "2026-02-10", "filed": "2026-02-18", "form": "10-K", "shares": 31_673_346},
            {"as_of": "2026-07-25", "filed": "2026-08-01", "form": "10-Q", "shares": 950_200_000}])
        early = fh.latest_share_count(db, "BKNG", as_of_filed="2026-06-30")
        self.assertEqual(early["shares"], 31_673_346)
        late = fh.latest_share_count(db, "BKNG", as_of_filed="2026-08-18")
        self.assertEqual(late["shares"], 950_200_000)

    def test_the_filter_is_the_filing_date_not_the_as_of_date(self):
        """The subtle version: a count dated 30 June was not knowable on 1 July if the filing
        carrying it went out in August."""
        db = make_db()
        fh.store_share_counts(db, "AAPL", [
            {"as_of": "2026-06-30", "filed": "2026-08-01", "form": "10-Q", "shares": 500}])
        self.assertIsNone(fh.latest_share_count(db, "AAPL", as_of_filed="2026-07-01"))


class TheMismatchIsDetected(unittest.TestCase):
    """Detection matters as much as the fix, because the fix depends on a newer filing existing.
    When one does not, the app has to know it cannot trust the combination."""

    def test_two_routes_to_the_same_ratio_disagree_and_that_is_the_signal(self):
        """basis-free P/E = market cap / net income. Per-share P/E = price / EPS. They can only
        differ if a share count somewhere is on a different basis from the price."""
        db = booking_shaped(make_db())
        fh.store_share_counts(db, "BKNG", [
            {"as_of": "2026-07-25", "filed": "2026-08-01", "form": "10-Q", "shares": 950_200_000}])
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        self.assertIn("share_basis_mismatch", [a["check"] for a in out["anomalies"]])
        self.assertFalse(out["share_basis_coherent"])

    def test_the_basis_free_route_is_the_one_kept(self):
        """It contains no per-share figure at all, so a split cannot touch it."""
        db = booking_shaped(make_db())
        fh.store_share_counts(db, "BKNG", [
            {"as_of": "2026-07-25", "filed": "2026-08-01", "form": "10-Q", "shares": 950_200_000}])
        r = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")["metrics"]["pe_ratio"]
        self.assertAlmostEqual(r["value"], 950_200_000 * 204.72 / 5_404e6, places=2)
        self.assertIn("market capitalisation", r["reason"])

    def test_an_absurd_per_share_pe_alone_is_enough_to_refuse(self):
        """The case where no newer filing exists, so the count cannot be corrected. A profitable
        company does not trade at 1.2x earnings; no P/E is reported rather than a wrong one."""
        db = make_db()
        p = period("2025-12-31", "2026-02-18", revenue=26_917e6, eps_diluted=165.57,
                   diluted_shares=32.639e6, shares_outstanding=31_673_346,
                   operating_cash_flow=9_409e6, capex=322e6)
        fh.store_history(db, "BKNG", [p])
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        self.assertEqual(out["metrics"]["pe_ratio"]["verdict"], dv.UNAVAILABLE)
        self.assertIn("different bases", out["metrics"]["pe_ratio"]["reason"])
        self.assertIn("share_basis_mismatch", [a["check"] for a in out["anomalies"]])

    def test_a_coherent_company_raises_nothing_and_keeps_its_pe(self):
        """The check must be silent on the other 49, or it is noise."""
        db = make_db()
        p = period("2025-09-27", "2025-10-31", ticker="AAPL", revenue=416_161e6,
                   net_income=112_000e6, eps_diluted=7.47, diluted_shares=15.0e9,
                   shares_outstanding=14_776_353_000)
        fh.store_history(db, "AAPL", [p])
        fh.store_share_counts(db, "AAPL", [
            {"as_of": "2025-10-17", "filed": "2025-10-31", "form": "10-K",
             "shares": 14_776_353_000}])
        out = dv.validate_ticker(db, "AAPL", price=230.0, price_as_of="2025-11-01")
        self.assertEqual(out["anomalies"], [])
        self.assertTrue(out["share_basis_coherent"])
        self.assertIn(out["metrics"]["pe_ratio"]["verdict"], dv.USABLE)

    def test_coherence_is_none_rather_than_true_when_it_cannot_be_judged(self):
        """"We could not check" and "we checked and it agreed" are different claims."""
        db = make_db()
        p = period("2025-12-31", "2026-02-01", ticker="AAPL", revenue=1000e6, net_income=100e6,
                   shares_outstanding=1e9)
        fh.store_history(db, "AAPL", [p])
        out = dv.validate_ticker(db, "AAPL", price=10.0, price_as_of="2026-02-02")
        self.assertIsNone(out["share_basis_coherent"])

    def test_a_genuinely_low_pe_on_a_loss_making_company_is_not_flagged(self):
        """The check must not fire on companies that are simply unprofitable — their EPS is
        negative and no P/E is computed at all."""
        db = make_db()
        p = period("2025-12-31", "2026-02-01", ticker="CVNA", revenue=1000e6, net_income=-50e6,
                   eps_diluted=-1.0, shares_outstanding=50e6)
        fh.store_history(db, "CVNA", [p])
        out = dv.validate_ticker(db, "CVNA", price=10.0, price_as_of="2026-02-02")
        self.assertNotIn("share_basis_mismatch", [a["check"] for a in out["anomalies"]])


class Staleness(unittest.TestCase):

    def test_an_old_share_count_is_reported_with_its_age(self):
        db = booking_shaped(make_db())
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        self.assertGreater(out["share_count_age_days"], 150)
        self.assertIn("stale_share_count", [a["check"] for a in out["anomalies"]])

    def test_a_fresh_count_raises_no_staleness_warning(self):
        db = booking_shaped(make_db())
        fh.store_share_counts(db, "BKNG", [
            {"as_of": "2026-07-25", "filed": "2026-08-01", "form": "10-Q", "shares": 950_200_000}])
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        self.assertLess(out["share_count_age_days"], 30)
        self.assertNotIn("stale_share_count", [a["check"] for a in out["anomalies"]])

    def test_staleness_alone_never_removes_a_metric(self):
        """An old share count is a prompt to look, not a reason to withhold. Only a DEMONSTRATED
        basis mismatch withholds, and this company's figures are internally coherent — the count
        is simply old."""
        db = make_db()
        p = period("2025-09-27", "2025-10-31", ticker="AAPL", revenue=416_161e6,
                   net_income=112_000e6, eps_diluted=7.47, diluted_shares=15.0e9,
                   shares_outstanding=14_776_353_000)
        fh.store_history(db, "AAPL", [p])
        out = dv.validate_ticker(db, "AAPL", price=230.0, price_as_of="2026-08-17")
        self.assertIn("stale_share_count", [a["check"] for a in out["anomalies"]])
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.OK)


class TheParserReadsEveryFilingType(unittest.TestCase):

    def _payload(self, entries):
        return {"facts": {"dei": {"EntityCommonStockSharesOutstanding": {
            "units": {"shares": entries}}}}}

    def test_quarterly_cover_pages_are_read(self):
        rows = SecEdgarProvider.parse_share_counts(self._payload([
            {"end": "2026-02-10", "val": 31_673_346, "form": "10-K", "filed": "2026-02-18"},
            {"end": "2026-07-25", "val": 950_200_000, "form": "10-Q", "filed": "2026-08-01"},
        ]))
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["shares"], 950_200_000)      # newest as_of first
        self.assertEqual(rows[0]["form"], "10-Q")

    def test_an_unrecognised_filing_type_is_ignored(self):
        rows = SecEdgarProvider.parse_share_counts(self._payload([
            {"end": "2026-07-25", "val": 1, "form": "S-1", "filed": "2026-08-01"}]))
        self.assertEqual(rows, [])

    def test_a_missing_dei_namespace_is_empty_not_an_error(self):
        self.assertEqual(SecEdgarProvider.parse_share_counts({"facts": {}}), [])
        self.assertEqual(SecEdgarProvider.parse_share_counts({}), [])

    def test_duplicate_entries_are_collapsed(self):
        rows = SecEdgarProvider.parse_share_counts(self._payload([
            {"end": "2026-07-25", "val": 950_200_000, "form": "10-Q", "filed": "2026-08-01"},
            {"end": "2026-07-25", "val": 950_200_000, "form": "10-Q", "filed": "2026-08-01"},
        ]))
        self.assertEqual(len(rows), 1)

    def test_one_download_serves_both_parsers(self):
        """Fifty companyfacts payloads is the expensive part of a run; fetching each twice would
        double both the wall clock and the traffic SEC sees from this app."""
        source = (Path(__file__).resolve().parent.parent / "routers"
                  / "api_validation.py").read_text()
        self.assertIn("get_history_and_share_counts", source)
        self.assertNotIn("provider.get_share_counts(", source)


class NetIncomeFallback(unittest.TestCase):
    """BKNG tags its annual total under `NetIncomeLossAvailableToCommonStockholdersBasic`, not
    `NetIncomeLoss` — found by reading what it publishes. Without it, net margin, ROE, ROA and
    accruals were all blank, AND the basis-free P/E route could not be computed at all, which is
    what left the mismatch undetectable."""

    def test_the_available_to_common_element_is_in_the_chain(self):
        chain = [tag for _ns, tag in tags_for("net_income", "us-gaap")]
        self.assertIn("NetIncomeLossAvailableToCommonStockholdersBasic", chain)
        self.assertLess(chain.index("NetIncomeLoss"),
                        chain.index("NetIncomeLossAvailableToCommonStockholdersBasic"))


if __name__ == "__main__":
    unittest.main()


class TheGatingIsProportionate(unittest.TestCase):
    """Two different situations, two different responses. Conflating them either publishes wrong
    figures or throws away right ones."""

    def test_a_fresh_count_with_a_stale_eps_keeps_the_market_cap(self):
        """We know WHICH side is wrong: the count is current, the EPS is not. Withholding the
        market capitalisation here would discard the very figure the fix exists to produce."""
        db = booking_shaped(make_db())
        fh.store_share_counts(db, "BKNG", [
            {"as_of": "2026-07-25", "filed": "2026-08-01", "form": "10-Q", "shares": 950_200_000}])
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        self.assertFalse(out["share_basis_coherent"])
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.OK)
        self.assertIsNot(out.get("price_metrics_reliable"), False)

    def test_no_fresh_count_withholds_every_price_based_figure(self):
        """We cannot tell which side is wrong, so nothing that multiplies a fundamental by a
        price is published. Coverage falls, and that is the truthful consequence."""
        db = booking_shaped(make_db())
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        self.assertFalse(out["price_metrics_reliable"])
        for name in ("market_cap", "enterprise_value", "fcf_yield_pct", "buyback_yield_pct"):
            self.assertEqual(out["metrics"][name]["verdict"], dv.UNAVAILABLE, name)

    def test_the_withheld_figures_are_not_reported_as_impossible(self):
        """THE WRONG DIAGNOSIS THIS REPLACES. A 140% free-cash-flow yield was labelled a 'parsing
        or arithmetic fault'. The arithmetic was perfect; the inputs were from different dates.
        Sending the next person to look for a parser bug that does not exist is worse than saying
        nothing."""
        db = booking_shaped(make_db())
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        self.assertEqual(out["implausible"], [])
        self.assertIn("different bases", out["metrics"]["fcf_yield_pct"]["reason"])

    def test_agreement_between_two_figures_from_one_filing_is_not_evidence(self):
        """THE FLAW THE LIVE RUN EXPOSED IN MY OWN CHECK. Booking's share count and its EPS come
        from the SAME stale filing, so the two P/E routes agreed at about 1.2 and corroborated
        each other into publishing it. The credibility floor now applies to the answer itself,
        whichever route produced it."""
        db = booking_shaped(make_db())
        out = dv.validate_ticker(db, "BKNG", price=204.72, price_as_of="2026-08-17")
        self.assertEqual(out["metrics"]["pe_ratio"]["verdict"], dv.UNAVAILABLE)
        self.assertIn("share_basis_mismatch", [a["check"] for a in out["anomalies"]])


class TheRunActuallyStoresWhatItFetches(unittest.TestCase):
    """A structural test, added because the first version of this build fetched every share count
    and then never stored one — a string replacement that silently matched nothing. The whole
    fix was inert on the server while every unit test passed, and only the live run showed it."""

    def test_the_worker_stores_share_counts_and_passes_the_price_date(self):
        source = (Path(__file__).resolve().parent.parent / "routers"
                  / "api_validation.py").read_text()
        self.assertIn("fh.store_share_counts(db, ticker, share_records)", source)
        self.assertIn("price_as_of=price_ts", source)

    def test_the_fetched_counts_are_not_silently_discarded(self):
        source = (Path(__file__).resolve().parent.parent / "routers"
                  / "api_validation.py").read_text()
        fetched = source.count("share_records")
        self.assertGreaterEqual(fetched, 3)   # declared, assigned, stored
