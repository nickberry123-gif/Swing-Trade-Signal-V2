"""
Storage and point-in-time reads for the multi-year fundamentals history (Build B).

WHAT THIS LAYER IS FOR, IN ONE SENTENCE: to make it structurally impossible to score a past date
using a filing that did not exist on that date.

Every read below goes through `as_of_filed`. There is deliberately no "just give me everything"
function that a future caller could reach for by accident — `history()` requires the date, and
passing None means today, which is the only case where the newest filing is legitimately the
right answer. This is the same discipline the backtester uses for price bars (physical slicing
rather than a promise not to peek), applied to fundamentals, and for the same reason: a rule that
depends on the next person remembering it is not a rule.

TRANSFER COST. The Neon free tier allows 5 GB of network transfer a month and the last incident
spent it in under two days on repeated reads. A full history is ~30-50 rows per ticker of ~30
small columns, refetched at most monthly and written with executemany rather than row by row. A
whole-universe rebuild moves single-digit megabytes; the point-in-time read for one ticker moves
a few kilobytes. Neither is on a polling path.
"""
import json
from datetime import datetime, timedelta, timezone

from providers.base import ProviderError
from providers.edgar_concepts import HISTORY_VALUE_FIELDS
from services.fundamentals_service import get_fundamentals_provider

# Annual filings arrive once a year. Refetching more often than monthly spends SEC's goodwill and
# Neon's transfer allowance to re-download figures that cannot have changed.
HISTORY_TTL = timedelta(days=30)

_META_FIELDS = ("ticker", "period_end", "filed", "fiscal_year", "form", "taxonomy", "currency",
                "accn")
_ALL_COLUMNS = _META_FIELDS + HISTORY_VALUE_FIELDS + ("warnings_json", "source", "fetched_at")


def _placeholders(n: int) -> str:
    return ", ".join(["?"] * n)


def store_history(db, ticker: str, records: list) -> int:
    """Upsert every (period_end, filed) record for one ticker. Returns rows written.

    Upsert rather than delete-then-insert on purpose: a provider hiccup that returns a short
    history must not erase years of correctly-stored data. Old rows for periods no longer
    returned simply remain, which is harmless — they are still true statements about what was
    filed and when.
    """
    if not records:
        return 0
    now = datetime.now(timezone.utc).isoformat()
    rows = []
    for r in records:
        values = r.values or {}
        rows.append(tuple(
            [r.ticker.upper(), r.period_end, r.filed, r.fiscal_year, r.form, r.taxonomy,
             r.currency, r.accn]
            + [values.get(f) for f in HISTORY_VALUE_FIELDS]
            + [json.dumps(r.warnings or []), r.source, now]
        ))

    updatable = [c for c in _ALL_COLUMNS if c not in ("ticker", "period_end", "filed")]
    db.executemany(
        f"""
        INSERT INTO fundamentals_history ({", ".join(_ALL_COLUMNS)})
        VALUES ({_placeholders(len(_ALL_COLUMNS))})
        ON CONFLICT(ticker, period_end, filed) DO UPDATE SET
            {", ".join(f"{c}=excluded.{c}" for c in updatable)}
        """,
        rows,
    )
    db.commit()
    return len(rows)


def _newest_fetched_at(db, ticker: str):
    row = db.execute(
        "SELECT MAX(fetched_at) AS newest FROM fundamentals_history WHERE ticker = ?",
        (ticker.upper(),)).fetchone()
    return dict(row).get("newest") if row is not None else None


def _is_fresh(fetched_at) -> bool:
    if not fetched_at:
        return False
    try:
        ts = datetime.fromisoformat(str(fetched_at))
    except (TypeError, ValueError):
        return False
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - ts) < HISTORY_TTL


def refresh(db, ticker: str, force: bool = False) -> dict:
    """Fetch and store one ticker's full annual history. Cheap and idempotent when already fresh.

    A provider failure with data already stored is reported as a warning, not an exception: the
    stored history is still valid — it is a record of what was filed, and filings do not expire.
    """
    ticker = ticker.upper()
    if not force and _is_fresh(_newest_fetched_at(db, ticker)):
        return {"ticker": ticker, "status": "CACHED", "rows_written": 0}
    try:
        records = get_fundamentals_provider().get_fundamentals_history(ticker)
    except ProviderError as e:
        stored = count(db, ticker)
        return {"ticker": ticker, "status": "STALE_CACHE" if stored else "UNAVAILABLE",
                "rows_written": 0, "rows_stored": stored, "error": str(e)}
    written = store_history(db, ticker, records)
    return {"ticker": ticker, "status": "LIVE", "rows_written": written,
            "periods": len({r.period_end for r in records}),
            "taxonomy": records[0].taxonomy if records else None,
            "currency": records[0].currency if records else None}


def count(db, ticker: str) -> int:
    row = db.execute("SELECT COUNT(*) AS n FROM fundamentals_history WHERE ticker = ?",
                     (ticker.upper(),)).fetchone()
    return int(dict(row).get("n") or 0) if row is not None else 0


def history(db, ticker: str, as_of_filed: str | None = None, limit: int = 10) -> list:
    """The annual history AS IT WAS KNOWN on `as_of_filed`, newest fiscal period first.

    One row per fiscal period: the newest version of that period that had been filed by the
    as-of date. A restatement published afterwards is not merely ignored — it is excluded by the
    WHERE clause, so no code path further down can reach it.

    `as_of_filed=None` means today, which is the only situation in which the newest filing is
    the correct one. Callers scoring a historical date MUST pass that date; there is no function
    here that returns everything, precisely so that "I forgot to pass it" cannot happen silently.
    """
    ticker = ticker.upper()
    cutoff = as_of_filed or datetime.now(timezone.utc).date().isoformat()
    rows = db.execute(
        f"""
        SELECT {", ".join(_ALL_COLUMNS)} FROM fundamentals_history
        WHERE ticker = ? AND filed <= ?
        ORDER BY period_end DESC, filed DESC
        """,
        (ticker, cutoff),
    ).fetchall()

    out, seen = [], set()
    for row in rows:
        d = dict(row)
        if d["period_end"] in seen:
            continue          # already have the newest version of this period at the cutoff
        seen.add(d["period_end"])
        try:
            d["warnings"] = json.loads(d.pop("warnings_json") or "[]")
        except (TypeError, ValueError):
            d.pop("warnings_json", None)
            d["warnings"] = []
        # Repeated at every layer because it is the one thing that must not be forgotten: these
        # figures may not be dollars, and nothing in this app converts currencies.
        d["can_combine_with_usd_prices"] = d.get("currency") == "USD"
        d["as_of_filed"] = cutoff
        out.append(d)
        if len(out) >= limit:
            break
    return out


def history_all_vintages(db, ticker: str, as_of_filed: str | None = None,
                         limit: int = 60) -> list:
    """EVERY stored (period, filing) row, not one row per period.

    `history()` answers "what is the best current figure for each year". This answers a different
    question — "which filing said what, and when" — and the five-year EPS chain cannot be built
    without it: the whole technique depends on seeing the same fiscal year as reported by more
    than one filing, so that growth can be computed inside a filing and never across one.

    Still point-in-time. The `filed <= cutoff` clause is identical, so a chain built for a past
    date cannot reach a filing that did not exist then.
    """
    ticker = ticker.upper()
    cutoff = as_of_filed or datetime.now(timezone.utc).date().isoformat()
    rows = db.execute(
        f"""
        SELECT {", ".join(_ALL_COLUMNS)} FROM fundamentals_history
        WHERE ticker = ? AND filed <= ?
        ORDER BY period_end DESC, filed DESC
        LIMIT ?
        """,
        (ticker, cutoff, limit),
    ).fetchall()

    out = []
    for row in rows:
        d = dict(row)
        d.pop("warnings_json", None)
        d["as_of_filed"] = cutoff
        out.append(d)
    return out


def coverage(db, ticker: str, as_of_filed: str | None = None, years: int = 5) -> dict:
    """How much of the history is actually populated — the input to Build B2's validation.

    Reports per-field counts rather than a single percentage, because "83% covered" hides which
    field is missing, and a valuation block missing share count is not the same as one missing
    R&D. Every field this app asks for is listed, including the ones that came back empty, so a
    gap is visible rather than absent.
    """
    rows = history(db, ticker, as_of_filed=as_of_filed, limit=years)
    per_field = {f: sum(1 for r in rows if r.get(f) is not None) for f in HISTORY_VALUE_FIELDS}
    return {
        "ticker": ticker.upper(),
        "periods": len(rows),
        "period_ends": [r["period_end"] for r in rows],
        "taxonomy": rows[0]["taxonomy"] if rows else None,
        "currency": rows[0]["currency"] if rows else None,
        "can_combine_with_usd_prices": bool(rows) and rows[0]["currency"] == "USD",
        "per_field_periods": per_field,
        "fields_never_reported": sorted(f for f, n in per_field.items() if n == 0),
        # Deliberately not rolled into one headline number: a mean across fields would let a
        # fully-covered R&D line paper over a completely absent share count.
        "fields_total": len(HISTORY_VALUE_FIELDS),
        "fields_with_any_data": sum(1 for n in per_field.values() if n > 0),
    }


# =============================================================================================
# COVER-PAGE SHARE COUNTS — separate from the annual history, and separate on purpose
# =============================================================================================

def store_share_counts(db, ticker: str, records: list) -> int:
    """Upsert every cover-page share count for one ticker, from any filing type."""
    if not records:
        return 0
    now = datetime.now(timezone.utc).isoformat()
    rows = [(ticker.upper(), r["as_of"], r["filed"], r.get("form"), float(r["shares"]),
             "sec-edgar", now) for r in records]
    db.executemany(
        """
        INSERT INTO share_counts (ticker, as_of, filed, form, shares, source, fetched_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(ticker, as_of, filed) DO UPDATE SET
            form=excluded.form, shares=excluded.shares, source=excluded.source,
            fetched_at=excluded.fetched_at
        """,
        rows,
    )
    db.commit()
    return len(rows)


def latest_share_count(db, ticker: str, as_of_filed: str | None = None) -> dict | None:
    """The most recent share count that had been PUBLISHED by `as_of_filed`.

    Ordered by `as_of` — the date the count was true — but filtered on `filed`, the date it
    became public. Using `as_of` for the filter would be look-ahead of the subtlest kind: a count
    dated 30 June does not become usable until the quarterly report carrying it is filed in
    August.

    Returns {shares, as_of, filed, form} or None.
    """
    ticker = ticker.upper()
    cutoff = as_of_filed or datetime.now(timezone.utc).date().isoformat()
    row = db.execute(
        """
        SELECT shares, as_of, filed, form FROM share_counts
        WHERE ticker = ? AND filed <= ?
        ORDER BY as_of DESC, filed DESC
        LIMIT 1
        """,
        (ticker, cutoff),
    ).fetchone()
    return dict(row) if row is not None else None


def refresh_share_counts(db, ticker: str) -> dict:
    """Fetch and store every cover-page share count. Shares the annual history's cache window."""
    ticker = ticker.upper()
    try:
        records = get_fundamentals_provider().get_share_counts(ticker)
    except ProviderError as e:
        return {"ticker": ticker, "status": "UNAVAILABLE", "rows_written": 0, "error": str(e)}
    return {"ticker": ticker, "status": "LIVE",
            "rows_written": store_share_counts(db, ticker, records),
            "newest": records[0] if records else None}
