"""
Annual-reset backtesting: every calendar year evaluated as an independent experiment.

THE QUESTION THIS ANSWERS
-------------------------
If the strategy were judged one year at a time, how often would it reach its target before the
year ended, and how long would that typically take? A continuous backtest can hide a trade that
was opened in 2021 and only worked out in 2025 — that trade is counted as a win, but nobody
holding it would have experienced it as one.

WHAT CHANGED, AND WHAT DID NOT
------------------------------
This is an EVALUATION change only. Entry rules, exit rules, indicators, thresholds, position
handling and signal generation are untouched — `_simulate_ticker` is the same function the
continuous backtest calls, with one extra boundary:

  * crossing into a new calendar year force-closes any open position at the CLOSE of the
    previous year's final trading day;
  * state resets, so the new year begins flat with no inherited position, counter or P&L.

Everything else the strategy does between those boundaries is exactly as before. Both versions
are run on the same bars so the difference between them is attributable to the boundary alone.

WHY INDICATORS STILL SEE PRIOR YEARS
------------------------------------
Resetting the PORTFOLIO is not the same as resetting HISTORY. A 200-day average on 4 January
needs the previous autumn's prices; blanking it would test a different, worse strategy rather
than the same one under an annual rule. So the bar series is continuous and only positions
reset — which is what the specification asks for, and it introduces no look-ahead because every
indicator is still computed from a physically truncated slice ending at the decision bar.

ON THE TARGET/YEAR-END CLASSIFICATION
-------------------------------------
The specification asks for every trade to be TARGET or YEAR_END. The strategy also exits on a
time limit and on signal degradation, and those are strategy rules that must not be rewritten.
So `exit_reason` keeps its truthful value and two explicit flags carry the distinction the
specification actually needs: `target_reached` (true only for a real target hit) and
`year_end_exit` (true only when the calendar boundary or the end of data closed the trade).
Reporting a 40-day time-limit exit as "the year ended" would be a false statement about what
happened.
"""
import logging
from datetime import datetime, timezone

import pandas as pd

from services.backtest_service import (LIMITATIONS, _metrics, _regime_by_date, _simulate_ticker,
                                       run_backtest)

log = logging.getLogger(__name__)

PERCENTILES = [25, 50, 75, 90]


def _year_bounds(bars_by_ticker: dict) -> dict:
    """First and last trading day actually present for each calendar year, across all tickers.

    Taken from the data rather than the calendar: 1 January is never a trading day and 31
    December often is not either, so an evaluation window written from the calendar would claim
    a boundary that no price exists for.
    """
    days = set()
    for df in bars_by_ticker.values():
        if df is not None and len(df):
            days.update(str(t) for t in df["ts"])
    out = {}
    for d in sorted(days):
        y = int(d[:4])
        if y not in out:
            out[y] = {"first_trading_day": d, "last_trading_day": d}
        else:
            out[y]["last_trading_day"] = d
    return out


def _partial_years(bounds: dict, today: str | None = None) -> set:
    """Years whose data does not reach the end of the year.

    The current year is the obvious case, but a year can also be partial because the history
    starts mid-way through it. Both are marked, because comparing a three-month year against a
    twelve-month one as if they were equivalent is the single easiest way to misread this page.
    """
    partial = set()
    for y, b in bounds.items():
        starts_late = b["first_trading_day"] > f"{y}-01-20"
        ends_early = b["last_trading_day"] < f"{y}-12-15"
        if starts_late or ends_early:
            partial.add(y)
    return partial


def _pctile(values: list, p: int):
    if not values:
        return None
    return round(float(pd.Series(values, dtype="float64").quantile(p / 100.0)), 1)


def _time_to_target(trades: list) -> dict:
    """Holding periods of trades that ACTUALLY reached their target.

    Year-end closures are excluded by definition — they did not reach the target, and including
    them would describe how long the year is rather than how long the strategy takes.
    """
    days = [t["holding_days"] for t in trades
            if t.get("target_reached") and t.get("holding_days") is not None]
    if not days:
        return {"n": 0, "mean": None, "median": None, "min": None, "max": None,
                "p25": None, "p75": None, "p90": None}
    s = pd.Series(days, dtype="float64")
    return {
        "n": len(days),
        "mean": round(float(s.mean()), 1),
        "median": round(float(s.median()), 1),
        "min": int(s.min()),
        "max": int(s.max()),
        "p25": _pctile(days, 25),
        "p75": _pctile(days, 75),
        "p90": _pctile(days, 90),
    }


def _year_end_analysis(trades: list) -> dict:
    """What the trades that ran out of year were worth when they were closed."""
    rets = [t["return_pct"] for t in trades
            if t.get("year_end_exit") and t.get("return_pct") is not None]
    if not rets:
        return {"n": 0, "mean_pct": None, "median_pct": None, "best_pct": None,
                "worst_pct": None, "profitable": 0, "unprofitable": 0}
    s = pd.Series(rets, dtype="float64")
    return {
        "n": len(rets),
        "mean_pct": round(float(s.mean()), 2),
        "median_pct": round(float(s.median()), 2),
        "best_pct": round(float(s.max()), 2),
        "worst_pct": round(float(s.min()), 2),
        "profitable": int((s > 0).sum()),
        "unprofitable": int((s <= 0).sum()),
    }


def _summarise(trades: list, slots: int = 1) -> dict:
    """Per-year statistics. Deliberately never pooled across years."""
    completed = [t for t in trades if t.get("return_pct") is not None]
    base = _metrics(completed, slots)
    hits = [t for t in completed if t.get("target_reached")]
    year_ends = [t for t in completed if t.get("year_end_exit")]
    holds = [t["holding_days"] for t in completed if t.get("holding_days") is not None]
    return {
        "trades": len(completed),
        "target_hits": len(hits),
        "year_end_exits": len(year_ends),
        # Rates are None rather than 0 when there is nothing to divide: "0% hit rate" and "no
        # trades happened" are different facts and must not look the same.
        "target_hit_rate_pct": (round(len(hits) / len(completed) * 100, 1)
                                if completed else None),
        "year_end_rate_pct": (round(len(year_ends) / len(completed) * 100, 1)
                              if completed else None),
        "avg_return_pct": base["avg_return_pct"],
        "median_return_pct": (round(float(pd.Series([t["return_pct"] for t in completed]).median()), 2)
                              if completed else None),
        "best_pct": base["best_pct"],
        "worst_pct": base["worst_pct"],
        "avg_holding_days": base["avg_holding_days"],
        "median_holding_days": (round(float(pd.Series(holds, dtype="float64").median()), 1)
                                if holds else None),
        "max_holding_days": max(holds) if holds else None,
        "total_return_pct": base["total_return_pct"],
        "max_drawdown_pct": base["max_drawdown_pct"],
        "win_rate_pct": base["win_rate_pct"],
    }


def _validate(trades: list, bounds: dict) -> dict:
    """The checks that decide whether anything else on the page can be believed.

    Written as failures-found rather than a boolean, so a partial breach is visible instead of
    collapsing the whole report to "invalid".
    """
    crossing, late_exit, bad_reason, missing_year = [], [], [], []
    valid_reasons = {"TARGET", "TIME_LIMIT", "SIGNAL_EXIT", "YEAR_END", "DATA_END"}

    for t in trades:
        entry, exit_ = str(t.get("entry_date") or ""), str(t.get("exit_date") or "")
        if not entry or not exit_:
            continue
        if entry[:4] != exit_[:4]:
            crossing.append({"ticker": t.get("ticker"), "entry": entry, "exit": exit_})
        year = int(entry[:4])
        if t.get("calendar_year") != year:
            missing_year.append({"ticker": t.get("ticker"), "entry": entry,
                                 "calendar_year": t.get("calendar_year")})
        b = bounds.get(year)
        if b and exit_ > b["last_trading_day"]:
            late_exit.append({"ticker": t.get("ticker"), "exit": exit_,
                              "year_end": b["last_trading_day"]})
        if t.get("exit_reason") not in valid_reasons:
            bad_reason.append({"ticker": t.get("ticker"), "reason": t.get("exit_reason")})

    checks = [
        {"check": "No trade crosses a calendar-year boundary",
         "passed": not crossing, "failures": crossing[:10], "count": len(crossing)},
        {"check": "Every trade's exit is on or before its year's final trading day",
         "passed": not late_exit, "failures": late_exit[:10], "count": len(late_exit)},
        {"check": "calendar_year matches the entry date's year",
         "passed": not missing_year, "failures": missing_year[:10], "count": len(missing_year)},
        {"check": "Every trade has a recognised exit reason",
         "passed": not bad_reason, "failures": bad_reason[:10], "count": len(bad_reason)},
        {"check": "No look-ahead: signals use a truncated slice and fill at the NEXT bar's open",
         "passed": True, "failures": [],
         "note": "Structural — enforced in _simulate_ticker and covered by the look-ahead tests, "
                 "not re-derived here."},
    ]
    return {"all_passed": all(c["passed"] for c in checks), "checks": checks}


def run_annual_backtest(db, tickers: list, bars_by_ticker: dict,
                        config: dict | None = None, strategy: dict | None = None) -> dict:
    config = config or {}
    strategy_name = (strategy or {}).get("name", "v1.0 baseline")
    regime_by_date = _regime_by_date(bars_by_ticker) if config.get("use_regime", True) else {}

    bounds = _year_bounds({t: bars_by_ticker.get(t) for t in tickers if t in bars_by_ticker})
    partial = _partial_years(bounds)

    all_trades, skipped = [], {}
    for ticker in tickers:
        df = bars_by_ticker.get(ticker)
        if df is None or len(df) < 250:
            skipped[ticker] = f"needs at least 250 daily bars, has {0 if df is None else len(df)}"
            continue
        all_trades.extend(_simulate_ticker(ticker, df.reset_index(drop=True), regime_by_date,
                                           config, strategy, annual_reset=True))

    tested = [t for t in tickers if t not in skipped]
    slots = max(1, len(tested))

    by_year, by_year_stock = {}, []
    for year in sorted(bounds):
        yt = [t for t in all_trades if t.get("calendar_year") == year]
        if not yt and year not in bounds:
            continue
        by_year[year] = {
            **_summarise(yt, slots),
            "partial_year": year in partial,
            "first_trading_day": bounds[year]["first_trading_day"],
            "last_trading_day": bounds[year]["last_trading_day"],
            "time_to_target": _time_to_target(yt),
            "year_end_analysis": _year_end_analysis(yt),
        }
        for ticker in sorted({t["ticker"] for t in yt}):
            st = [t for t in yt if t["ticker"] == ticker]
            by_year_stock.append({
                "year": year, "stock": ticker, "strategy": strategy_name,
                "partial_year": year in partial,
                **_summarise(st, 1),
                "time_to_target": _time_to_target(st),
            })

    completed = [t for t in all_trades if t.get("return_pct") is not None]
    complete_years = [y for y in by_year if y not in partial]

    # The overall figures are built from the collection of annual tests, not by re-running a
    # continuous backtest — that distinction is the whole point of this page.
    overall = {
        "annual_test_periods": len(by_year),
        "complete_years": len(complete_years),
        "partial_years": sorted(partial),
        **_summarise(completed, slots),
        "time_to_target": _time_to_target(completed),
        "year_end_analysis": _year_end_analysis(completed),
    }

    result = {
        "mode": "ANNUAL_RESET",
        "strategy_name": strategy_name,
        "config": dict(config),
        "year_bounds": bounds,
        "by_year": by_year,
        "by_year_stock": by_year_stock,
        "overall": overall,
        "trades": sorted(all_trades, key=lambda t: (t.get("calendar_year") or 0,
                                                    str(t.get("entry_date")))),
        "tickers_tested": tested,
        "tickers_skipped": skipped,
        "validation": _validate(completed, bounds),
        "limitations": LIMITATIONS + [
            "Each calendar year is scored independently, so a trade that would have worked out "
            "in the following year is recorded as a year-end exit at whatever it was worth on "
            "31 December. That is the intended behaviour, not a defect.",
            "Indicators still read prior-year prices — resetting the portfolio is not the same "
            "as resetting history, and blanking it would test a different strategy.",
        ],
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }

    # Reconciliation: the annual rows must account for every trade. A mismatch means a trade
    # was assigned to no year, or to two.
    annual_total = sum(v["trades"] for v in by_year.values())
    result["validation"]["checks"].append({
        "check": "Annual trade counts reconcile with the overall total",
        "passed": annual_total == len(completed),
        "count": abs(annual_total - len(completed)),
        "failures": [] if annual_total == len(completed)
                    else [{"annual_sum": annual_total, "overall": len(completed)}],
    })
    result["validation"]["all_passed"] = all(c["passed"] for c in result["validation"]["checks"])
    return result


def run_comparison(db, tickers: list, bars_by_ticker: dict,
                   config: dict | None = None, strategy: dict | None = None) -> dict:
    """Both frameworks on identical bars, so the difference is the boundary and nothing else."""
    annual = run_annual_backtest(db, tickers, bars_by_ticker, config, strategy)
    continuous = run_backtest(db, tickers, bars_by_ticker, config, strategy)

    c_over, a_over = continuous.get("overall", {}), annual.get("overall", {})
    cross_year = [t for t in continuous.get("trades", [])
                  if str(t.get("entry_date"))[:4] != str(t.get("exit_date"))[:4]]

    return {
        "annual": annual,
        "continuous": {
            "overall": c_over,
            "trades": len(continuous.get("trades", [])),
            "buy_and_hold_benchmark": continuous.get("buy_and_hold_benchmark"),
        },
        "difference": {
            "trades_continuous": c_over.get("trades"),
            "trades_annual": a_over.get("trades"),
            "avg_return_continuous_pct": c_over.get("avg_return_pct"),
            "avg_return_annual_pct": a_over.get("avg_return_pct"),
            "win_rate_continuous_pct": c_over.get("win_rate_pct"),
            "win_rate_annual_pct": a_over.get("win_rate_pct"),
            # The number that answers "how much of the original result depended on holding
            # across the new year".
            "continuous_trades_crossing_a_year": len(cross_year),
            "continuous_cross_year_share_pct": (
                round(len(cross_year) / len(continuous["trades"]) * 100, 1)
                if continuous.get("trades") else None),
        },
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
