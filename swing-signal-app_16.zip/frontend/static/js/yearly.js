// Yearly page: average traded price per calendar year, plus today's price.
//
// This endpoint is NOT polled. On a cache that does not already hold five full years it
// triggers one deep provider fetch per ticker, which takes minutes; a timer would stack those
// calls on top of each other. It loads once, with an explicit Refresh button.

let latestPrices = {};   // ticker -> live price from the snapshots endpoint
let yearlyData = null;

function cellPrice(v) {
  return v === null || v === undefined ? `<span class="text-dim">&mdash;</span>` : fmtPrice(v);
}

/**
 * One year's cell: the average price, with that year's step underneath.
 *
 * Both readings of "show me the years" are covered in one cell — the average price you asked
 * for, and the percentage move that produced it — so neither has to be inferred by comparing
 * columns by eye.
 */
function yearCell(stat, step) {
  if (!stat || stat.avg_price === null || stat.avg_price === undefined) {
    return `<td class="text-right"><span class="pill pill-unavailable"><span class="dot bad"></span>UNAVAILABLE</span></td>`;
  }
  const stepHtml = step && step.pct !== null && step.pct !== undefined
    ? `<div class="yc-sub ${pctClass(step.pct)}">${fmtPct(step.pct, 1)}</div>`
    : `<div class="yc-sub text-dim">&mdash;</div>`;
  // A partial year's average is a real number over a shorter window, so it is shown rather than
  // hidden — but it is not comparable to a full year, and an unmarked one reads as a genuine
  // fall in the average price.
  const flag = stat.partial
    ? `<span class="yc-flag" title="${stat.reason || "incomplete year"}: ${stat.first_date} to ${stat.last_date}">partial</span>`
    : stat.year_in_progress
      ? `<span class="yc-flag" title="Year to date, ${stat.first_date} to ${stat.last_date}">YTD</span>`
      : "";
  return `<td class="text-right">${fmtPrice(stat.avg_price)}${flag}${stepHtml}</td>`;
}

function renderTable(data, rowsIn, headId, bodyId, firstColLabel) {
  const years = data.years_shown || [];
  const head = document.getElementById(headId);
  head.innerHTML = [
    `<th>${firstColLabel}</th>`,
    ...years.map((y) => `<th class="text-right">${y}${y === data.current_year ? " <span class='yc-flag'>YTD</span>" : ""}</th>`),
    `<th class="text-right">Current Price</th>`,
    `<th class="text-right">Avg Year % Increase</th>`,
  ].join("");

  const colCount = years.length + 3;
  const rows = (rowsIn || []).slice().sort(
    (a, b) => (b.avg_year_pct ?? -9999) - (a.avg_year_pct ?? -9999));

  const tbody = document.getElementById(bodyId);
  if (!rows.length) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="${colCount}">No data.</td></tr>`;
    return;
  }

  tbody.innerHTML = rows.map((r) => {
    const byYear = {};
    (r.years || []).forEach((s) => { byYear[s.year] = s; });
    const stepTo = {};
    (r.yoy_pct || []).forEach((s) => { stepTo[s.to] = s; });

    // Live prices are keyed by the symbol Alpaca actually quotes, which for an ETF row is the
    // proxy, not the UCITS ticker shown in the first column.
    const priceKey = r.priced_via || r.ticker;
    const live = latestPrices[priceKey];
    const current = live !== undefined && live !== null ? live : r.latest_close;
    const currentIsLive = live !== undefined && live !== null;

    const nameCell = r.is_etf
      ? `<td>
           <span class="ticker-badge">${r.ticker}</span>
           <div class="company-name">${r.name || ""}${r.listing ? " &middot; " + r.listing : ""}</div>
           <div class="yc-proxy" title="${(r.proxy_note || "").replace(/"/g, "&quot;")}">
             priced via <strong>${r.priced_via}</strong>
             <span class="yc-match ${r.match === "EXACT" ? "yc-match-exact" : "yc-match-approx"}">${
               r.match === "EXACT" ? "same index" : "approximate"}</span>
           </div>
         </td>`
      : `<td><span class="ticker-badge">${r.ticker}</span></td>`;

    const click = r.is_etf ? "" : ` onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'"`;

    return `<tr${click}>
      ${nameCell}
      ${years.map((y) => yearCell(byYear[y], stepTo[y])).join("")}
      <td class="text-right">${cellPrice(current)}${
        currentIsLive ? "" : `<div class="yc-sub text-dim">last close${r.latest_close_date ? " " + r.latest_close_date : ""}</div>`}</td>
      <td class="text-right ${pctClass(r.avg_year_pct)}" style="font-weight:600;">${
        r.avg_year_pct === null || r.avg_year_pct === undefined
          ? `<span class="text-dim">&mdash;</span>`
          : fmtPct(r.avg_year_pct, 1)}</td>
    </tr>`;
  }).join("");
}

function renderYearlyTable(data) {
  renderTable(data, data.results, "yearly-head", "yearly-tbody", "Stock");
  renderTable(data, data.etfs, "etf-head", "etf-tbody", "ETF");
  document.getElementById("yearly-basis").textContent =
    `${data.basis} The last column averages each company's year-on-year steps; the current year is ` +
    `still in progress, so its step compares a full year against a part year.`;
}

/**
 * Diverging bar chart of average yearly change.
 *
 * Built as plain HTML rather than SVG or a charting library: the app has no build step and no
 * external dependencies, and a bar chart is a row of divs.
 *
 * Colour alone never carries the meaning here. Gain and loss share the app's green/red pair,
 * which sits in the weak band for red-green colour blindness, so direction is also encoded by
 * which side of the centre line a bar occupies AND by a signed label on every bar. Any one of
 * the three is enough to read it.
 */
function renderYearlyChart(data) {
  const withPct = (list) => (list || [])
    .filter((r) => r.avg_year_pct !== null && r.avg_year_pct !== undefined)
    .sort((a, b) => b.avg_year_pct - a.avg_year_pct);

  const stocks = withPct(data.results);
  const etfs = withPct(data.etfs);
  // Scaled together so a stock bar and an ETF bar of the same length mean the same thing —
  // that comparison is the entire reason the benchmarks are on this chart at all.
  const rows = stocks.concat(etfs);

  const wrap = document.getElementById("yearly-chart");
  if (!rows.length) {
    wrap.innerHTML = `<div class="text-dim" style="font-size:12.5px;">No yearly figures available to chart.</div>`;
    return;
  }

  // Only split the track down the middle when there is actually something to show on both
  // sides. In a period where every company gained, a centred zero line leaves half the chart
  // permanently blank and halves the length available to distinguish the bars from each other.
  const hasLosses = rows.some((r) => r.avg_year_pct < 0);
  const extent = Math.max(...rows.map((r) => Math.abs(r.avg_year_pct))) || 1;
  const zeroPct = hasLosses ? 50 : 0;
  // Bars stop short of the full track so the value label has somewhere to sit without being
  // clipped at the edge.
  const span = hasLosses ? 44 : 88;

  const bar = (r) => {
    const pct = r.avg_year_pct;
    const width = Math.abs(pct) / extent * span;
    const pos = pct >= 0;
    const barStyle = pos
      ? `left:${zeroPct}%; width:${width}%;`
      : `right:${100 - zeroPct}%; width:${width}%;`;
    const labelStyle = pos
      ? `left:calc(${zeroPct}% + ${width}% + 8px)`
      : `right:calc(${100 - zeroPct}% + ${width}% + 8px)`;
    // ETF bars are striped rather than a third colour: green/red already carry direction here,
    // and a new hue would compete with that. Texture separates the two groups without adding a
    // meaning that has to be looked up, and survives colour blindness and greyscale printing.
    const etfClass = r.is_etf ? " yc-bar-etf" : "";
    const via = r.is_etf && r.priced_via ? ` (priced via ${r.priced_via})` : "";
    return `
      <div class="yc-row" title="${r.ticker}${via}: ${fmtPct(pct, 1)} average year-on-year change">
        <div class="yc-label${r.is_etf ? " yc-label-etf" : ""}">${r.ticker}</div>
        <div class="yc-track">
          <div class="yc-zero" style="left:${zeroPct}%;"></div>
          <div class="yc-bar ${pos ? "yc-bar-pos" : "yc-bar-neg"}${etfClass}" style="${barStyle}"></div>
          <div class="yc-value ${pctClass(pct)}" style="${labelStyle}">${fmtPct(pct, 1)}${
            r.is_etf ? ` <span class="text-dim" style="font-size:10px;">via ${r.priced_via}</span>` : ""}</div>
        </div>
      </div>`;
  };

  wrap.innerHTML = stocks.map(bar).join("")
    + (etfs.length ? `<div class="yc-divider"><span>ETFs &amp; trackers &mdash; proxy prices</span></div>` : "")
    + etfs.map(bar).join("");
}

function renderAll() {
  if (!yearlyData) return;
  renderYearlyChart(yearlyData);
  renderYearlyTable(yearlyData);
}

async function loadYearly() {
  const msg = document.getElementById("yearly-message");
  const btn = document.getElementById("yearly-refresh");
  btn.disabled = true;
  msg.innerHTML = `<div class="warn-banner">Loading five years of daily history for 15 stocks. If this is the first time, the missing history has to be fetched from Alpaca and this can take a couple of minutes.</div>`;

  // Live prices are a separate, cheap call. If it fails the table still renders using each
  // stock's last close, clearly labelled as such rather than passed off as a current price.
  try {
    const snap = await apiGet("/api/stocks/snapshots");
    const next = {};
    (snap.results || []).forEach((r) => {
      const p = r.last_price !== undefined && r.last_price !== null ? r.last_price : r.last_known_price;
      if (p !== undefined && p !== null) next[r.ticker] = p;
    });
    latestPrices = next;
  } catch (e) {
    console.warn("Live prices unavailable, falling back to last close:", e.message);
  }

  try {
    const data = await apiGet("/api/stocks/yearly");
    if (data.error) {
      msg.innerHTML = `<div class="error-banner">${data.error}</div>`;
      btn.disabled = false;
      return;
    }
    yearlyData = data;
    msg.innerHTML = "";
    renderAll();
  } catch (e) {
    msg.innerHTML = `<div class="error-banner">Could not load yearly prices: ${e.message}</div>`;
    document.getElementById("yearly-tbody").innerHTML =
      `<tr class="loading-row"><td colspan="9">No data.</td></tr>`;
  } finally {
    btn.disabled = false;
  }
}

document.getElementById("yearly-refresh").addEventListener("click", loadYearly);
loadYearly();
