"""VALUE — the second pillar. Read-only; nothing here trades, recommends or blends with anything."""
from flask import Blueprint, jsonify, request

from db import get_db
from services import fundamentals_history_service as fh
from services import value_bars_service as vb
from services import value_service as vs
from services.signals_service import TICKERS

bp = Blueprint("api_value", __name__, url_prefix="/api/value")

# Every stored (period, filing) row is needed, not one row per period: `pick_filing` must be able
# to answer "what was public on THIS day", which the best-current-per-period view cannot do.
_VINTAGE_LIMIT = 80


def _evaluate(db, ticker, as_of):
    return vs.evaluate(ticker,
                       vb.bars(db, ticker, as_of=as_of),
                       fh.history_all_vintages(db, ticker, as_of_filed=as_of,
                                               limit=_VINTAGE_LIMIT),
                       as_of=as_of)


@bp.get("/<ticker>")
def value_for(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    db = get_db()
    out = _evaluate(db, ticker, request.args.get("as_of") or None)
    out["stored_bars"] = vb.stored_summary(db, ticker)
    return jsonify(out)


@bp.get("/<ticker>/series")
def value_series(ticker):
    """The full daily multiple series — the audit trail behind a percentile.

    Exists so a percentile can be READ rather than trusted. `?limit=` takes the most recent N days.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    db = get_db()
    as_of = request.args.get("as_of") or None
    bars = vb.bars(db, ticker, as_of=as_of)
    series = vs.build_series(bars, fh.history_all_vintages(db, ticker, as_of_filed=as_of,
                                                           limit=_VINTAGE_LIMIT))
    limit = max(1, min(int(request.args.get("limit", 250)), 5000))
    return jsonify({"ticker": ticker, "observations": len(series),
                    "observed_floor": vs.observed_floor(bars),
                    "splits_detected": vs.split_steps(bars),
                    "basis": vs.BASIS_NOTE, "series": series[-limit:]})


@bp.post("/refresh")
def refresh_bars():
    """Fetch dual-basis daily closes. POST because it writes and calls out to Alpaca."""
    db = get_db()
    requested = [t.strip().upper() for t in (request.args.get("tickers") or "").split(",")
                 if t.strip()]
    tickers = [t for t in requested if t in TICKERS] or sorted(TICKERS)
    results = [vb.refresh(db, t) for t in tickers]
    ok = [r for r in results if r["status"] == "OK"]
    floors = sorted({r["observed_floor"] for r in ok if r.get("observed_floor")})
    return jsonify({
        "requested": len(tickers), "ok": len(ok), "failed": len(results) - len(ok),
        # Recorded so that a rolling data window shows up as a change rather than as a percentile
        # that drifts while appearing stable.
        "expected_floor": vs.DATA_FLOOR_OBSERVED,
        "observed_floors": floors[:5],
        "results": results,
    })


@bp.get("/universe/all")
def value_universe():
    """Value for every tracked company — the 50-stock real-data check."""
    db = get_db()
    as_of = request.args.get("as_of") or None
    rows = []
    for t in sorted(TICKERS):
        r = _evaluate(db, t, as_of)
        m = r["metrics"]

        def part(name):
            d = m.get(name) or {}
            return {"status": d.get("status"), "value": d.get("value"),
                    "percentile": d.get("percentile"), "reason": d.get("reason")}

        rows.append({
            "ticker": t, "value": r["value"], "verdict": r["verdict"],
            "fcf_yield_pct": part("fcf_yield_pct"),
            "ev_to_ebit": part("ev_to_ebit"),
            "ev_to_sales": part(vs.EV_SALES),
            "pe_ratio": part("pe_ratio"),
            "substitution": r["substitution"], "split_withheld": r["split_withheld"],
            "coverage": r["coverage"], "history": r["history"], "notes": r["notes"],
        })

    scored = [r for r in rows if r["value"] is not None]
    counts = {}
    for r in rows:
        counts[r["verdict"]] = counts.get(r["verdict"], 0) + 1
    per_metric = {}
    for name in ("fcf_yield_pct", "ev_to_ebit", vs.EV_SALES, "pe_ratio"):
        per_metric[name] = sum(1 for r in rows if (r[name] or {}).get("status") == vs.OK)
    return jsonify({
        "as_of": (as_of or "today"), "basis": vs.BASIS_NOTE,
        "data_floor_observed": vs.DATA_FLOOR_OBSERVED,
        "tickers": len(rows), "scored": len(scored), "unknown": len(rows) - len(scored),
        "verdicts": counts, "metric_coverage": per_metric,
        "substitutions": [r["ticker"] for r in rows if r["substitution"]],
        "split_withheld": [r["ticker"] for r in rows if r["split_withheld"]],
        "results": rows,
    })
