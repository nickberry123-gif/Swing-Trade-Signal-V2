from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services import fundamentals_history_service as fh
from services.fundamentals_service import get_earnings_info, get_fundamentals
from services.news_service import get_news_for_ticker, refresh_news
from services.signals_service import TICKERS

bp = Blueprint("api_fundamentals", __name__, url_prefix="/api")


@bp.get("/fundamentals/<ticker>")
def stock_fundamentals(ticker):
    """Audited financial-statement data from SEC EDGAR plus the derived long-term quality score.
    Requires no API key (EDGAR is public) and is independent of the Alpaca credentials."""
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404

    db = get_db()
    force = request.args.get("refresh") == "1"
    data = get_fundamentals(db, ticker, force_refresh=force)
    data["earnings"] = get_earnings_info(db, ticker, force_refresh=force)
    return jsonify(data)


@bp.get("/fundamentals/history/<ticker>")
def stock_fundamentals_history(ticker):
    """The multi-year annual history, optionally AS IT WAS KNOWN on a given date.

    `?as_of=YYYY-MM-DD` restricts the answer to filings published on or before that date, which
    is how a historical score avoids using figures that did not exist yet. Omitting it means
    today — the only case where the newest filing is the right one.

    `?refresh=1` refetches from SEC. Rate-limited by a 30-day cache because annual filings
    arrive annually.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404

    db = get_db()
    refreshed = fh.refresh(db, ticker, force=request.args.get("refresh") == "1")
    as_of = request.args.get("as_of") or None
    rows = fh.history(db, ticker, as_of_filed=as_of, limit=int(request.args.get("years", 10)))
    return jsonify({
        "ticker": ticker,
        "as_of_filed": as_of or "today",
        "refresh": refreshed,
        "periods": rows,
        "coverage": fh.coverage(db, ticker, as_of_filed=as_of),
        "note": "Figures are as reported in filings published on or before the as-of date. "
                "Restatements filed later are excluded by the query, not merely ignored.",
    })


@bp.get("/fundamentals/tags/<ticker>")
def stock_fundamentals_tags(ticker):
    """Which XBRL tags this company actually publishes — a diagnostic, not a data path.

    `?contains=share` filters by substring. It exists because when a concept comes back empty the
    only honest way to find the right tag is to read SEC's response; the alternative is inventing
    plausible-looking tag names and shipping them, which is how a wrong number gets a confident
    label. Nothing scores off this endpoint.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    from providers.base import ProviderError
    from services.fundamentals_service import get_fundamentals_provider
    try:
        return jsonify({
            "ticker": ticker,
            "contains": request.args.get("contains") or "",
            "namespaces": get_fundamentals_provider().list_tags(
                ticker, contains=request.args.get("contains")),
        })
    except ProviderError as e:
        return jsonify({"ticker": ticker, "data_status": "UNAVAILABLE", "error": str(e)}), 200


@bp.get("/fundamentals/share-counts/<ticker>")
def stock_share_counts(ticker):
    """Every stored cover-page share count, and which one the app would select — a diagnostic.

    Added after a share count from a document filed in 2012 was chosen ahead of fourteen years of
    newer ones. The selection looked wrong and there was no way to see the underlying rows, so the
    cause had to be reasoned about rather than read. This endpoint removes that: it shows what is
    stored, in the order the selector sees it, plus the row actually chosen.

    `?rejects=1` additionally refetches from SEC and reports any facts DISCARDED for having an
    impossible date — a count cannot be dated years after the filing that carries it. Nothing
    scores off any of this.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    db = get_db()
    out = {
        "ticker": ticker,
        "selected": fh.latest_share_count(db, ticker),
        "stored": fh.stored_share_counts(db, ticker),
        "note": "ordered by FILING date — the count from the most recently published document, "
                "not the one bearing the latest internal date.",
    }
    if request.args.get("rejects") == "1":
        from providers.base import ProviderError
        from services.fundamentals_service import get_fundamentals_provider
        try:
            provider = get_fundamentals_provider()
            cik = provider.get_cik(ticker)
            from providers.sec_edgar_provider import SEC_FACTS_URL
            payload = provider._get(SEC_FACTS_URL.format(cik=cik))
            kept, rejected = provider.parse_share_counts(payload, with_rejects=True)
            out["parsed_now"] = {"kept": len(kept), "rejected": rejected,
                                 "newest_kept": kept[0] if kept else None}
        except ProviderError as e:
            out["parsed_now"] = {"error": str(e)}
    return jsonify(out)


@bp.get("/fundamentals/share-periods/<ticker>")
def stock_share_periods(ticker):
    """Weighted-average share counts per reported period, and the one that would be selected.

    A diagnostic. These figures are what makes a stock split survivable without computing a split
    factor: a weighted average published after the split is already on the post-split basis. The
    endpoint exists so that claim can be READ rather than trusted — Carvana's rows should show
    roughly 137.6m from the annual filing and roughly 717.7m from the quarter filed after May 2026,
    with this app doing no arithmetic between them.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    db = get_db()
    return jsonify({
        "ticker": ticker,
        "selected": fh.latest_share_period(db, ticker),
        "stored": fh.stored_share_periods(db, ticker),
        "note": "ordered by FILING date, then by the shortest period. No split factor is applied "
                "to any of these figures anywhere in this app.",
    })


@bp.get("/corporate-actions/probe")
def corporate_actions_probe():
    """Does this Alpaca account actually serve corporate actions? One request, read-only.

    Built as a probe rather than assumed. Nothing in the share basis depends on the answer being
    yes: when it is no, splits are detected from the discontinuity in the cover-page share counts
    this app already stores, which is reliable but only appears at the next filing.
    """
    from services.market_service import get_provider
    if not Config.has_alpaca_credentials():
        return jsonify({"available": False, "error": "Alpaca credentials are not configured"}), 200
    return jsonify(get_provider().corporate_actions_probe(
        request.args.get("symbol", "AAPL").upper()))


@bp.get("/fundamentals/coverage")
def fundamentals_coverage():
    """Per-ticker, per-field coverage across the universe — the input to the Build B2 check that
    Company Health and valuation can actually be populated before any score depends on them.

    Read-only and deliberately never refetches: this endpoint reports what is stored, so it can
    be used to check whether a refresh worked rather than quietly performing one and reporting
    success either way.
    """
    db = get_db()
    tickers = [t.strip().upper() for t in (request.args.get("tickers") or "").split(",") if t.strip()]
    tickers = [t for t in tickers if t in TICKERS] or sorted(TICKERS)
    return jsonify({
        "tickers": len(tickers),
        "results": [fh.coverage(db, t, as_of_filed=request.args.get("as_of") or None)
                    for t in tickers],
    })


@bp.get("/news/<ticker>")
def stock_news(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({"ticker": ticker, "data_status": "UNAVAILABLE",
                        "error": "Alpaca API credentials not configured", "items": []}), 200

    db = get_db()
    result = refresh_news(db, [ticker], force=request.args.get("refresh") == "1")
    items = get_news_for_ticker(db, ticker, limit=20)
    return jsonify({
        "ticker": ticker,
        "data_status": "UNAVAILABLE" if (result.get("error") and not items) else "OK",
        "error": result.get("error"),
        "sentiment_method": "keyword-based classifier (not NLP/AI sentiment analysis) — see "
                            "providers/news_provider.py for the exact keyword lists",
        "items": items,
    })
