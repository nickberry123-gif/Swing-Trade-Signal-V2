"""
Signal v2: two scores, three gatekeepers, and a change detector.

WHY THIS EXISTS RATHER THAN A RE-WEIGHTED v1.0
----------------------------------------------
v1.0 puts one 0-100 number on the page and asks it three different questions at once. Three
independent measurements say it answers none of them well:

  * Entry Test      — the BUY label fires on 48% of ALL DAYS. Buying on signal returned +45.96%
                      over 12 months against +49.57% for buying on a random day.
  * Selection Test  — ranked by score, the TOP stocks returned +31.05% and the BOTTOM ones
                      +72.22%, correlation -0.099. The ranking points the wrong way.
  * Backtest        — underperformed simply paying the same money in monthly.

Re-weighting the same eight components is the most overfittable change available and there is no
evidence it would help. So the structural problems are what get fixed here:

1. TWO SCORES, NOT ONE.
   HOLD QUALITY  — should I own this business at all? Slow-moving. Trend, relative strength,
                   financial quality, market regime.
   ENTRY QUALITY — is TODAY a sensible price to add? Fast-moving. Pullback depth, distance to
                   support, volatility, risk/reward.
   An excellent company at a stupid price reads GOOD STOCK / BAD ENTRY, which is precisely the
   state a single number cannot express.

2. GATEKEEPERS. A high score alone can no longer produce BUY. It must ALSO have a positive
   long-term trend and a market regime that is not strongly bearish. This is what addresses the
   48%-of-days problem: the score stops being sufficient on its own.

3. A CHANGE DETECTOR. Every level-based score answers "what is it now". The stated worry is
   missing a fundamental change on something already owned, which is a question about what MOVED.
   Score deltas, a broken trend, relative strength rolling over, price losing the 200 SMA, a new
   52-week low — reported as events against the previous reading, not as a level.

WHAT IS DELIBERATELY NOT HERE
-----------------------------
No stop-loss, in any disguise. The sell triggers are trend break, relative-strength
deterioration, score collapse and breakout failure. "Support broke on heavy volume" and "your
stop level was hit" are stop-losses under other names and are excluded by the project's own rule.

No short side. A failing stock produces AVOID, never a short.

FINANCIAL QUALITY AND LOOK-AHEAD
--------------------------------
Scoring TODAY with TODAY's fundamentals is simply using the data, and it carries its full weight
live. Scoring a 2022 signal with figures only knowable in 2026 is look-ahead, so in any historical
context the component is UNKNOWN and its weight is redistributed across what can be measured.
`live` is the flag that decides which of those two worlds a call is in.
"""
import logging
from datetime import datetime, timezone

log = logging.getLogger(__name__)

STRATEGY_VERSION = "v2.0"

# Hold Quality: is this a business worth owning? Slow-moving by design.
HOLD_WEIGHTS = {
    "long_term_trend": 30,
    "relative_strength": 25,
    "financial_quality": 20,
    "market_regime": 15,
    "momentum": 10,
}

# Entry Quality: is today a sensible price? Fast-moving by design.
ENTRY_WEIGHTS = {
    "pullback_depth": 30,
    "support_proximity": 25,
    "short_term_trend": 20,
    "risk_reward": 15,
    "volatility": 10,
}

# Bands, as specified.
BUY_MIN = 75
WATCH_MIN = 55

# A sell trigger fires below this, whatever else is true.
SELL_SCORE = 55


def _band(score):
    if score is None:
        return "UNAVAILABLE"
    if score >= BUY_MIN:
        return "BUY"
    if score >= WATCH_MIN:
        return "WATCH"
    return "AVOID"


def _weighted(components: dict, weights: dict) -> dict:
    """Score over the components that could be MEASURED.

    A component of None is unavailable, and its weight leaves the denominator rather than
    counting as zero. Scoring a missing news feed as a failure is as dishonest as scoring it as a
    pass — both invent a fact. The unknown list travels with the score so "82" is never read
    without noticing what it was out of.
    """
    earned = available = 0.0
    unknown = []
    detail = {}
    for key, weight in weights.items():
        pts = components.get(key)
        if pts is None:
            unknown.append(key)
            continue
        pts = max(0.0, min(1.0, float(pts)))        # each component is a 0..1 fraction
        earned += pts * weight
        available += weight
        detail[key] = {"fraction": round(pts, 3), "weight": weight,
                       "points": round(pts * weight, 2)}
    score = (earned / available * 100.0) if available > 0 else None
    return {
        "score": round(score, 1) if score is not None else None,
        "weight_available": available,
        "weight_unknown": sum(weights[k] for k in unknown),
        "unknown": unknown,
        "components": detail,
    }


# ---------------------------------------------------------------- gatekeepers

def gatekeepers(hold_score, long_term_trend_positive, regime_label) -> dict:
    """Three conditions, ALL required before BUY is permitted.

    v1.0 let the score alone decide, and the result labelled BUY on 48% of days — a description
    of a market that mostly went up, not a selection of anything. A gate cannot be compensated
    for by a high score, which is the entire point: these are not extra points, they are permission.
    """
    strongly_bearish = str(regime_label or "").upper() in ("BEARISH", "STRONGLY BEARISH", "RISK OFF")
    checks = [
        {"gate": "Score at least 75",
         "passed": bool(hold_score is not None and hold_score >= BUY_MIN),
         "detail": f"hold quality {hold_score}" if hold_score is not None else "no score"},
        {"gate": "Long-term trend is positive",
         "passed": bool(long_term_trend_positive),
         "detail": "long-term trend positive" if long_term_trend_positive
                   else "long-term trend is not positive"},
        {"gate": "Market regime is not strongly bearish",
         "passed": not strongly_bearish,
         "detail": f"regime {regime_label or 'UNKNOWN'}"},
    ]
    failed = [c for c in checks if not c["passed"]]
    return {"checks": checks, "all_passed": not failed,
            "blocked_by": [c["gate"] for c in failed]}


def classify(hold_score, entry_score, long_term_trend_positive, regime_label) -> dict:
    """The label a person acts on, and the reason for it.

    Hold and entry are kept apart to the very end. A great company at a poor price is a real and
    common state, and collapsing it into one number is what made the old page unusable for the
    question actually being asked.
    """
    gates = gatekeepers(hold_score, long_term_trend_positive, regime_label)
    hold_band = _band(hold_score)
    entry_band = _band(entry_score)

    if hold_score is None:
        action, why = "UNAVAILABLE", "Not enough data to score this stock."
    elif hold_score < SELL_SCORE:
        action = "AVOID"
        why = (f"Hold quality {hold_score} is below {SELL_SCORE}. This is about the business and "
               f"the trend, not today's price.")
    elif not gates["all_passed"]:
        action = "WATCH"
        why = ("Blocked by: " + "; ".join(gates["blocked_by"]) +
               ". A high score alone is not permission to buy.")
    elif entry_score is not None and entry_score < WATCH_MIN:
        # The distinction the whole redesign exists for.
        action = "GOOD STOCK, POOR ENTRY"
        why = (f"Hold quality {hold_score} passes every gate, but entry quality is "
               f"{entry_score}. Worth owning; today is not the day to add.")
    else:
        action = "BUY"
        why = (f"Hold quality {hold_score}, entry quality {entry_score}, and all three gates "
               f"passed.")

    return {
        "action": action,
        "reason": why,
        "hold_quality": hold_score, "hold_band": hold_band,
        "entry_quality": entry_score, "entry_band": entry_band,
        "gatekeepers": gates,
    }


# ---------------------------------------------------------------- sell triggers

def sell_triggers(current: dict, previous: dict | None) -> dict:
    """Reasons to sell, split into WHAT CHANGED and WHAT IS CURRENTLY TRUE.

    THE LINE THIS DOES NOT CROSS. A stop-loss exits because the PRICE moved against the position.
    Every item here is a change in the STRUCTURE or the QUALITY of the holding — the trend
    breaking, relative strength rolling over, the score collapsing, a breakout failing back into
    its base. Those can be true while the price is up, and false while the price is down.

    Deliberately absent, though both were suggested: "major support breaks on heavy volume" and
    "your predefined stop level is hit". Both are price-against-you exits. The project's rule is
    no stop-loss anywhere, and a stop-loss with a different name is still one.

    WHY THIS IS SPLIT IN TWO — a bug this function shipped with.
    ------------------------------------------------------------
    The first version tested STATES and called them triggers. "Long-term trend broke" fired
    whenever the trend was not positive, not when it stopped being positive. On live data that
    lit up 18 of 50 tickers at once, and a stock that had been under its 200-day average for two
    years would have fired "trend broke" every single day forever.

    "Broke" is a transition. A monitor that reports a standing condition as breaking news is one
    that gets ignored, and an ignored monitor is worse than none because it feels like cover.

    So: `fired` is what CHANGED since the last reading and is the number worth attention.
    `standing` is what is currently true — still shown, because a trend that has been broken for
    six months is worth seeing, just not as an alarm every morning.
    """
    fired, standing = [], []
    prev = previous or {}

    def _crossed(now_bad, was_bad):
        """A transition needs a previous reading. Without one, nothing has been observed to
        change, so it can only be reported as standing — never as news."""
        return bool(now_bad) and previous is not None and was_bad is False

    score, prev_score = current.get("hold_quality"), prev.get("hold_quality")
    if score is not None and score < SELL_SCORE:
        detail = f"hold quality {score} is below {SELL_SCORE}"
        if _crossed(True, (prev_score is not None and prev_score < SELL_SCORE)):
            fired.append({"trigger": "Score collapsed below the line",
                          "detail": f"hold quality fell from {prev_score} to {score}, "
                                    f"through {SELL_SCORE}"})
        else:
            standing.append({"condition": "Score is below the line", "detail": detail})

    trend_now = current.get("long_term_trend_positive")
    if trend_now is False:
        if _crossed(True, prev.get("long_term_trend_positive") is False):
            fired.append({"trigger": "Long-term trend broke",
                          "detail": "the long-term trend was positive at the last reading and "
                                    "is not now"})
        else:
            standing.append({"condition": "Long-term trend is not positive",
                             "detail": "price is not above a rising 200-day average"})

    rs_now, rs_then = current.get("relative_strength_pct"), prev.get("relative_strength_pct")
    if rs_now is not None and rs_then is not None and (rs_then - rs_now) >= MATERIAL["rs_drop"]:
        # Already a comparison between two readings by construction, so this one was never a
        # state test and needs no split.
        fired.append({"trigger": "Relative strength deteriorated",
                      "detail": f"relative strength fell from {rs_then}% to {rs_now}% "
                                f"versus the benchmark"})

    if current.get("breakout_failed"):
        fired.append({"trigger": "Breakout failed",
                      "detail": "price broke out and has fallen back below the level it broke"})

    return {
        "fired": fired,
        "any": bool(fired),                 # "any" means NEWS. Standing conditions are not news.
        "standing": standing,
        "any_standing": bool(standing),
        "excluded_by_design": [
            "Support breaking on heavy volume — a price-against-you exit, i.e. a stop-loss.",
            "A predefined stop level being hit — a stop-loss by definition.",
        ],
    }


# ---------------------------------------------------------------- change detection

# How much a move has to be before it is worth a person's attention. Below these, a reading is
# noise: a monitor that reports every wobble is one that gets ignored, and an ignored monitor is
# worse than none because it feels like cover.
MATERIAL = {
    "score_drop": 8.0,          # points of hold quality
    "score_rise": 10.0,
    "rs_drop": 10.0,            # percentage points of relative strength
}


def detect_changes(current: dict, previous: dict | None) -> dict:
    """What MOVED since the last reading — the question a level-based score never answers.

    The stated purpose of this page is not missing a fundamental change on something already
    owned. A score of 71 tells you nothing about that. A score of 71 that was 86 last week tells
    you everything.
    """
    if not previous:
        return {"first_reading": True, "changes": [], "material": False,
                "note": "No previous reading to compare against. Changes appear from the next "
                        "update onward."}

    changes = []
    now_score, then_score = current.get("hold_quality"), previous.get("hold_quality")
    if now_score is not None and then_score is not None:
        delta = now_score - then_score
        if delta <= -MATERIAL["score_drop"]:
            changes.append({"change": "Hold quality fell", "severity": "HIGH",
                            "detail": f"{then_score} to {now_score} ({delta:+.1f})"})
        elif delta >= MATERIAL["score_rise"]:
            changes.append({"change": "Hold quality rose", "severity": "INFO",
                            "detail": f"{then_score} to {now_score} ({delta:+.1f})"})

    # A band change is worth reporting even when the points moved little — crossing 75 or 55 is
    # what changes the action, and a 2-point move across a boundary matters more than a 9-point
    # move inside one.
    if current.get("hold_band") != previous.get("hold_band"):
        changes.append({"change": "Hold band changed", "severity": "HIGH",
                        "detail": f"{previous.get('hold_band')} to {current.get('hold_band')}"})

    if previous.get("long_term_trend_positive") and current.get("long_term_trend_positive") is False:
        changes.append({"change": "Long-term trend broke", "severity": "HIGH",
                        "detail": "was positive at the last reading, is not now"})

    rs_now, rs_then = current.get("relative_strength_pct"), previous.get("relative_strength_pct")
    if rs_now is not None and rs_then is not None and (rs_then - rs_now) >= MATERIAL["rs_drop"]:
        changes.append({"change": "Relative strength rolled over", "severity": "HIGH",
                        "detail": f"{rs_then}% to {rs_now}% versus the benchmark"})

    if previous.get("above_sma200") and current.get("above_sma200") is False:
        changes.append({"change": "Lost the 200-day average", "severity": "HIGH",
                        "detail": "price was above the 200 SMA at the last reading and is below "
                                  "it now"})

    if current.get("new_52w_low"):
        changes.append({"change": "New 52-week low", "severity": "HIGH",
                        "detail": "the price has not been this low in a year"})

    return {
        "first_reading": False,
        "compared_with": previous.get("ts"),
        "changes": changes,
        "material": any(c["severity"] == "HIGH" for c in changes),
        "thresholds": MATERIAL,
    }


# ============================================================================================
# THE ADAPTER
# ============================================================================================
# Everything above is pure arithmetic on 0..1 fractions. Everything below turns the indicators
# this app already computes into those fractions.
#
# NOTHING NEW IS MEASURED HERE. Every input is a number v1.0 already produced — the same trend
# score, the same relative strength, the same support zone. What changes is how they are
# ARRANGED: split into two questions instead of one, with gates in front of the answer. That is
# deliberate. Inventing new indicators to fix a scoring problem is how a strategy gets fitted to
# its own backtest, and this rebuild is a response to three measurements, not a search for a
# better-looking number.

from services.signal_engine import (  # noqa: E402 — imported here to keep the pure part above import-free
    compute_price_levels, score_long_term_trend, score_market_regime, score_momentum,
    score_relative_strength, score_rsi_pullback, score_short_term_trend,
    score_support_resistance,
)


def _frac(score, maximum):
    """A v1 component score out of `maximum`, as a 0..1 fraction. None stays None — an
    unmeasured component must not arrive here as a zero."""
    if score is None or not maximum:
        return None
    return max(0.0, min(1.0, score / maximum))


# ATR as a percentage of price, scored as a preference band rather than "less is better".
# A stock that moves 0.5% a day will not reach a 10% target inside a swing horizon; one that
# moves 9% a day will hit anything in either direction for reasons unrelated to the setup.
# These boundaries are a considered heuristic, not a measured optimum, and are labelled as such
# on the page. They were NOT tuned against the backtest — that is exactly the overfitting the
# rebuild exists to avoid.
_VOL_BANDS = [(1.0, 0.40, "very quiet — a target may take longer than the thesis"),
              (2.0, 0.80, "quiet but workable"),
              (4.0, 1.00, "a normal swing-trading range"),
              (6.0, 0.60, "lively — position size matters more than usual"),
              (8.0, 0.30, "volatile"),
              (float("inf"), 0.10, "extremely volatile")]


def _volatility(atr_pct):
    if atr_pct is None:
        return None, "average true range unavailable"
    for ceiling, frac, note in _VOL_BANDS:
        if atr_pct < ceiling:
            return frac, f"daily range about {atr_pct:.1f}% of price — {note}"
    return None, "average true range unavailable"


def _risk_reward(price, target, support_low):
    """Upside to the target against the room beneath price before the support zone begins.

    THIS IS NOT A STOP-LOSS, AND THE DIFFERENCE IS NOT COSMETIC. A stop-loss is an INSTRUCTION:
    when price reaches X, sell. This is a MEASUREMENT: today, there is this much room above and
    this much room below. It produces no order, no exit, no field to enter one in, and nothing
    downstream reads it as a trigger. It only makes a poor entry score like a poor entry.

    Returns (ratio, fraction, note). Ratio is None when it cannot be measured honestly.
    """
    if price is None or target is None or support_low is None:
        return None, None, "not enough level data to measure the room above and below"
    room_below = price - support_low
    room_above = target - price
    if room_below <= 0:
        return None, None, ("price is at or below the support zone — there is no measured floor "
                            "beneath it, so the ratio would be invented rather than measured")
    if room_above <= 0:
        return 0.0, 0.0, "price is already at or above the target — no upside left to this level"
    ratio = room_above / room_below
    # 3:1 or better earns the full weight; below 1:1 earns nothing. Linear between.
    frac = max(0.0, min(1.0, (ratio - 1.0) / 2.0))
    return round(ratio, 2), frac, (f"{room_above / price * 100:.1f}% to the target against "
                                   f"{room_below / price * 100:.1f}% down to the support zone")


def build_state(analysis: dict, regime: dict | None, quality: dict | None = None,
                live: bool = True) -> dict:
    """The raw facts v2 needs, pulled from one analyze_stock() result.

    Kept separate from scoring so the facts can be asserted in tests without going through a
    weighting scheme, and so the change detector compares FACTS between readings rather than
    comparing two scores and hoping the components behind them were the same.
    """
    price = analysis.get("reference_price")
    sma200 = analysis.get("sma200")
    slope = analysis.get("sma200_slope")
    low_52w = analysis.get("low_52w")
    high_20d = analysis.get("high_20d")
    rs = analysis.get("relative_strength") or {}

    above_sma200 = None if (price is None or not sma200) else bool(price > sma200)
    rising_sma200 = None if slope is None else bool(slope > 0)
    # BOTH are required, and an unknown is not a pass. "Cannot confirm the trend is positive" and
    # "the trend is positive" must not produce the same gate result.
    if above_sma200 is None or rising_sma200 is None:
        trend_positive = None
    else:
        trend_positive = above_sma200 and rising_sma200

    return {
        "ticker": analysis.get("ticker"),
        "price": price,
        "above_sma200": above_sma200,
        "sma200_rising": rising_sma200,
        "long_term_trend_positive": trend_positive,
        "relative_strength_pct": rs.get("rs_spy_20d"),
        "rs_labels": rs.get("labels") or {},
        "regime_label": (regime or {}).get("regime"),
        "atr_pct": analysis.get("atr_pct"),
        "high_20d": high_20d,
        "low_52w": low_52w,
        "new_52w_low": (None if (price is None or not low_52w)
                        else bool(price <= low_52w * 1.001)),
        "trend_label": analysis.get("trend_label"),
        "financial_quality_score": (quality or {}).get("long_term_quality_score"),
        "live": bool(live),
    }


def _earnings_flag(earnings_info: dict | None) -> dict:
    """An earnings date near a swing position is an overnight gap risk. Shown as a FLAG, never
    as points.

    It was worth 5 points in v1.0 and that was the wrong shape for it. "Earnings in 3 days"
    should not be quietly offset by a strong MACD — it is a piece of information a person needs
    to see and decide about, not a small deduction from a number they then read as a single
    verdict. Absent an estimated date the flag is UNKNOWN, never assumed clear.
    """
    days = (earnings_info or {}).get("days_until_estimated_report")
    if days is None:
        return {"status": "UNKNOWN", "days": None,
                "detail": "no estimated earnings date available — not assumed clear"}
    if 0 <= days <= 5:
        return {"status": "BLACKOUT", "days": days,
                "detail": f"estimated earnings in about {days} day(s) — holding a swing position "
                          f"through a report is an overnight gap risk"}
    return {"status": "CLEAR", "days": days,
            "detail": f"estimated earnings in about {days} day(s)"}


def evaluate(analysis: dict, regime: dict | None, quality: dict | None = None,
             live: bool = True, previous: dict | None = None,
             earnings_info: dict | None = None) -> dict:
    """One ticker, end to end: two scores, three gates, an action, changes, and sell triggers.

    `live=False` is the historical path. Fundamentals are dropped there because scoring a 2022
    signal with figures published in 2026 is look-ahead — the component reports UNKNOWN and its
    weight leaves the denominator rather than quietly counting as a pass.
    """
    if analysis.get("data_status") == "UNAVAILABLE" or not analysis.get("bars_used"):
        return {
            "ticker": analysis.get("ticker"), "strategy_version": STRATEGY_VERSION,
            "data_status": "UNAVAILABLE", "action": "UNAVAILABLE",
            "reason": "No price data — nothing was scored.",
            "hold_quality": None, "entry_quality": None,
        }

    state = build_state(analysis, regime, quality, live=live)
    rs = analysis.get("relative_strength") or {}

    lt, _ = score_long_term_trend(analysis)
    st, _ = score_short_term_trend(analysis)
    mom, _ = score_momentum(analysis)
    pull, _ = score_rsi_pullback(analysis)
    sr, _ = score_support_resistance(analysis)
    rss, _ = score_relative_strength(rs)
    reg, _ = score_market_regime(regime)

    fq = state["financial_quality_score"]
    fq_frac = _frac(fq, 100) if live else None
    fq_note = ("financial quality unavailable" if (live and fq_frac is None)
               else "excluded in historical scoring — today's fundamentals were not knowable then"
               if not live else f"quality score {fq}/100 from filings")

    hold = _weighted({
        "long_term_trend": _frac(lt, 20),
        "relative_strength": _frac(rss, 10),
        "financial_quality": fq_frac,
        "market_regime": _frac(reg, 5),
        "momentum": _frac(mom, 15),
    }, HOLD_WEIGHTS)

    vol_frac, vol_note = _volatility(state["atr_pct"])
    levels = compute_price_levels(analysis)
    rr_ratio, rr_frac, rr_note = _risk_reward(
        state["price"], levels.get("primary_target"), analysis.get("support_low"))

    entry = _weighted({
        "pullback_depth": _frac(pull, 10),
        "support_proximity": _frac(sr, 10),
        "short_term_trend": _frac(st, 10),
        "risk_reward": rr_frac,
        "volatility": vol_frac,
    }, ENTRY_WEIGHTS)

    verdict = classify(hold["score"], entry["score"],
                       state["long_term_trend_positive"], state["regime_label"])

    current = {
        **state,
        "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "hold_quality": hold["score"],
        "hold_band": verdict["hold_band"],
        "entry_quality": entry["score"],
        "entry_band": verdict["entry_band"],
        "breakout_failed": _breakout_failed(state, previous),
    }

    return {
        "ticker": state["ticker"],
        "strategy_version": STRATEGY_VERSION,
        "data_status": "OK",
        **verdict,
        "hold": hold,
        "entry": entry,
        "state": current,
        "levels": levels,
        "risk_reward": {"ratio": rr_ratio, "note": rr_note,
                        "not_a_stop_loss": "This measures room above and below. It issues no "
                                           "exit and there is nowhere to enter one."},
        "earnings": _earnings_flag(earnings_info) if live else {
            "status": "UNKNOWN", "days": None,
            "detail": "earnings dates are not reconstructed historically"},
        "notes": {"volatility": vol_note, "financial_quality": fq_note},
        "changes": detect_changes(current, previous),
        "sell": sell_triggers(current, previous),
    }


def _breakout_failed(state: dict, previous: dict | None):
    """Price made a 20-day high at the last reading and has since fallen back below it.

    Needs two readings by construction — a breakout that failed is a sequence, not a snapshot.
    With one reading this is None (unknown), never False, because "no evidence of a failure" and
    "evidence of no failure" are different claims.
    """
    if not previous:
        return None
    prev_price, prev_high = previous.get("price"), previous.get("high_20d")
    price = state.get("price")
    if None in (prev_price, prev_high, price) or not prev_high:
        return None
    broke_out = prev_price >= prev_high * 0.999
    return bool(broke_out and price < prev_high)


# ============================================================================================
# PERSISTENCE AND ORCHESTRATION
# ============================================================================================
# The change detector is the reason this section exists. A level can be computed from today's
# bars alone; a CHANGE cannot. Something has to remember the last reading, and it has to remember
# the facts, not just the score.

import json  # noqa: E402


def load_previous(db, ticker: str) -> dict | None:
    """The most recent stored reading for one ticker, or None if this is the first."""
    row = db.execute(
        "SELECT ts, state_json FROM signal_v2_history WHERE ticker = :t "
        "ORDER BY ts DESC, id DESC LIMIT 1", {"t": ticker}).fetchone()
    if not row:
        return None
    raw = row["state_json"] if not isinstance(row, tuple) else row[1]
    try:
        state = json.loads(raw) if raw else None
    except (ValueError, TypeError):
        # A corrupt snapshot must read as "no previous reading", not crash the page. The cost is
        # one missed comparison; the alternative is a blank Signals page.
        log.warning("Unreadable v2 snapshot for %s — treating as first reading", ticker)
        return None
    return state


# How old the last stored reading must be before another one is written.
#
# THIS IS NOT A PERFORMANCE SETTING. Without it the change detector destroys itself: the page
# computes on load, every computation stores a reading, and so refreshing twice in a minute makes
# the "previous reading" sixty seconds old. Every comparison would then be against a near-identical
# snapshot and the honest answer would always be "nothing changed" — true over sixty seconds, and
# worthless over the week that a deteriorating holding actually takes to deteriorate.
#
# Six hours means the comparison is always against a different trading session at least, so
# "hold quality fell 11 points" describes something that happened rather than something that
# was measured twice.
MIN_SNAPSHOT_GAP_HOURS = 6


def _hours_since(ts: str | None) -> float | None:
    if not ts:
        return None
    try:
        parsed = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - parsed).total_seconds() / 3600.0


def save_reading(db, result: dict, previous: dict | None = None) -> None:
    """Append one reading, unless the last one is too recent to be a useful comparison.

    Never overwrites. The history IS the change detector's memory, and a memory that records the
    same moment repeatedly remembers nothing.
    """
    if result.get("data_status") != "OK":
        return
    if previous is not None:
        age = _hours_since(previous.get("ts"))
        if age is not None and age < MIN_SNAPSHOT_GAP_HOURS:
            return
    state = result.get("state") or {}
    db.execute(
        """INSERT INTO signal_v2_history
             (ticker, ts, hold_quality, entry_quality, hold_band, entry_band, action,
              state_json, strategy_version)
           VALUES (:ticker, :ts, :hold, :entry, :hb, :eb, :action, :state, :ver)""",
        {"ticker": result["ticker"], "ts": state.get("ts"),
         "hold": result.get("hold_quality"), "entry": result.get("entry_quality"),
         "hb": result.get("hold_band"), "eb": result.get("entry_band"),
         "action": result.get("action"), "state": json.dumps(state),
         "ver": STRATEGY_VERSION})
    db.commit()


def compute_v2_for_ticker(db, ticker: str, timeframe: str = "1Day", benchmark_cache=None,
                          regime: dict | None = None, persist: bool = True) -> dict:
    from services.fundamentals_service import get_earnings_info, get_fundamentals
    from services.market_regime import compute_market_regime
    from services.stock_analysis import analyze_stock

    analysis = analyze_stock(db, ticker, timeframe=timeframe, benchmark_cache=benchmark_cache,
                             persist=persist)
    if regime is None:
        regime = compute_market_regime(db)

    quality = earnings_info = None
    for name, fn in (("fundamentals", get_fundamentals), ("earnings", get_earnings_info)):
        try:
            value = fn(db, ticker)
        except Exception as e:  # noqa: BLE001 — an enrichment failing is never fatal
            # Roll back before continuing: on PostgreSQL a failed statement aborts the whole
            # transaction, so a swallowed error without a rollback poisons every later query.
            log.warning("%s unavailable for %s: %s", name, ticker, e)
            try:
                db.rollback()
            except Exception:  # noqa: BLE001
                pass
            continue
        if name == "fundamentals":
            quality = value
        else:
            earnings_info = value

    previous = load_previous(db, ticker)
    result = evaluate(analysis, regime, quality, live=True, previous=previous,
                      earnings_info=earnings_info)
    if persist:
        save_reading(db, result, previous=previous)
    return result


def compute_all_v2(db, timeframe: str = "1Day", persist: bool = True) -> list:
    """All 15 tickers, sharing one regime fetch and one benchmark-bar cache.

    Ranked by hold quality, because the page's stated job is "am I still happy owning these" and
    that is the number that answers it. Entry quality is a second column, not a tiebreak — a
    ranking that mixed them would be back to one number answering two questions.
    """
    from config import STOCK_UNIVERSE
    from services.market_regime import compute_market_regime, store_market_regime
    from services.stock_analysis import build_benchmark_cache

    regime = compute_market_regime(db)
    if persist and regime.get("regime") != "UNAVAILABLE":
        store_market_regime(db, regime)
    benchmark_cache = build_benchmark_cache(db, timeframe)

    out = []
    for stock in STOCK_UNIVERSE:
        ticker = stock["ticker"]
        try:
            out.append(compute_v2_for_ticker(db, ticker, timeframe=timeframe,
                                             benchmark_cache=benchmark_cache, regime=regime,
                                             persist=persist))
        except Exception as e:  # noqa: BLE001 — one bad ticker must not empty the whole page
            log.warning("v2 signal failed for %s: %s", ticker, e)
            try:
                db.rollback()
            except Exception:  # noqa: BLE001
                pass
            out.append({"ticker": ticker, "data_status": "UNAVAILABLE", "action": "UNAVAILABLE",
                        "reason": str(e), "hold_quality": None, "entry_quality": None})

    out.sort(key=lambda r: (r.get("hold_quality") is None, -(r.get("hold_quality") or 0)))
    return out


# ============================================================================================
# CACHED READS AND BACKGROUND REFRESH
# ============================================================================================
# WHY THIS EXISTS. Computing all 50 tickers takes about 90 seconds on the free tier — bars,
# indicators, relative strength and SEC fundamentals for each. Doing that inside the page's own
# request means ninety seconds of spinner, and the gateway gives up before then anyway. Worse,
# it made the page indistinguishable from a hung one, which is the exact failure this project
# has already been bitten by twice.
#
# So the page READS and a background thread WRITES. A read is a single indexed SELECT and returns
# instantly with an honest "computed 14 minutes ago"; the recompute happens behind it.

import threading  # noqa: E402

# How old the displayed reading may be before a refresh is kicked off automatically. Daily bars
# do not move faster than this, and the scores are built from 50- and 200-day averages.
STALE_AFTER_MINUTES = 90

# A refresh still marked 'running' after this long is treated as dead rather than waited on
# forever. Set well above the ~90s a real refresh takes.
ABANDONED_RUN_MINUTES = 20


def save_latest(db, result: dict) -> None:
    """Upsert the newest reading for one ticker. Overwrites by design — this is the display row."""
    if result.get("data_status") != "OK":
        return
    row = {"ticker": result["ticker"], "hold": result.get("hold_quality"),
           "entry": result.get("entry_quality"), "action": result.get("action"),
           "payload": json.dumps(result), "ver": STRATEGY_VERSION}
    db.execute(
        """INSERT INTO signal_v2_latest
             (ticker, computed_at, hold_quality, entry_quality, action, result_json,
              strategy_version)
           VALUES (:ticker, datetime('now'), :hold, :entry, :action, :payload, :ver)
           ON CONFLICT(ticker) DO UPDATE SET
             computed_at=datetime('now'), hold_quality=excluded.hold_quality,
             entry_quality=excluded.entry_quality, action=excluded.action,
             result_json=excluded.result_json, strategy_version=excluded.strategy_version""",
        row)
    db.commit()


def load_latest_all(db) -> tuple[list, str | None]:
    """Every stored reading plus the OLDEST computed_at across them.

    Oldest, not newest, deliberately. If 49 tickers refreshed a minute ago and one failed three
    days ago, "computed 1 minute ago" would be a lie about the table as a whole. The age shown
    to a person should be the age of the worst row in it.
    """
    rows = db.execute(
        "SELECT ticker, computed_at, result_json FROM signal_v2_latest").fetchall() or []
    results, oldest = [], None
    for r in rows:
        raw = r["result_json"]
        ts = r["computed_at"]
        try:
            results.append(json.loads(raw) if raw else None)
        except (ValueError, TypeError):
            log.warning("Unreadable stored v2 result for %s", r["ticker"])
            continue
        if ts and (oldest is None or str(ts) < str(oldest)):
            oldest = ts
    results = [r for r in results if r]
    results.sort(key=lambda r: (r.get("hold_quality") is None, -(r.get("hold_quality") or 0)))
    return results, oldest


def _run_state(db) -> dict:
    """Is a refresh in flight, and is it plausibly still alive?"""
    row = db.execute(
        "SELECT id, created_at, status, progress, error FROM signal_v2_runs "
        "ORDER BY id DESC LIMIT 1").fetchone()
    if not row:
        return {"running": False, "progress": None, "error": None}
    status = row["status"]
    if status != "running":
        return {"running": False, "progress": row["progress"], "error": row["error"]}
    age = _hours_since(row["created_at"])
    if age is not None and age * 60 > ABANDONED_RUN_MINUTES:
        # Do not wait on a thread that no longer exists. A server restart mid-refresh would
        # otherwise leave this row saying 'running' forever and the page waiting on it forever.
        return {"running": False, "progress": None,
                "error": "A refresh stopped without finishing — most likely the server restarted "
                         "while it was working. Nothing was lost; start another."}
    return {"running": True, "progress": row["progress"], "error": None}


def start_refresh(app, db) -> bool:
    """Kick off a whole-universe recompute in the background. Returns whether one was started.

    Refuses if a refresh is already running: fifty tickers of SEC and Alpaca requests fired twice
    over is how a free-tier rate limit gets hit, and the second run would produce the same answer.
    """
    if _run_state(db)["running"]:
        return False
    cur = db.execute("INSERT INTO signal_v2_runs (status, progress) "
                     "VALUES ('running', 'Starting…')")
    db.commit()
    run_id = cur.lastrowid if hasattr(cur, "lastrowid") else None
    if run_id is None:
        row = db.execute("SELECT id FROM signal_v2_runs ORDER BY id DESC LIMIT 1").fetchone()
        run_id = row["id"] if row else None

    threading.Thread(target=_refresh_worker, args=(app, run_id), daemon=True).start()
    return True


def _refresh_worker(app, run_id) -> None:
    """The background recompute.

    CONNECTION DISCIPLINE, same rule as services/job_runner: a connection is opened, used and
    closed inside one short operation, never held across the compute. Neon closes idle
    connections after a few minutes, and a 90-second compute with a connection sitting open
    across it is how two annual backtests previously finished their work and then lost it at the
    final write.
    """
    import database
    from config import Config, STOCK_UNIVERSE
    from services.market_regime import compute_market_regime, store_market_regime
    from services.stock_analysis import build_benchmark_cache

    def _write(sql, params):
        # Best-effort and on its own fresh connection: a failed progress note must never be able
        # to destroy the results.
        try:
            conn = database.connect(Config.DATABASE_URL, Config.DATABASE_PATH)
            try:
                conn.execute(sql, params)
                conn.commit()
            finally:
                conn.close()
        except Exception:  # noqa: BLE001
            log.debug("v2 refresh bookkeeping write failed", exc_info=True)

    def progress(msg):
        _write("UPDATE signal_v2_runs SET progress = :p WHERE id = :i", {"p": msg, "i": run_id})

    with app.app_context():
        try:
            conn = database.connect(Config.DATABASE_URL, Config.DATABASE_PATH)
            try:
                regime = compute_market_regime(conn)
                if regime.get("regime") != "UNAVAILABLE":
                    store_market_regime(conn, regime)
                benchmark_cache = build_benchmark_cache(conn, "1Day")
            finally:
                conn.close()

            total = len(STOCK_UNIVERSE)
            for n, stock in enumerate(STOCK_UNIVERSE, start=1):
                ticker = stock["ticker"]
                progress(f"{ticker} ({n} of {total})")
                # One short-lived connection per ticker. Fifty small operations rather than one
                # long-held socket is exactly the trade this codebase already learned to make.
                conn = database.connect(Config.DATABASE_URL, Config.DATABASE_PATH)
                try:
                    result = compute_v2_for_ticker(conn, ticker, benchmark_cache=benchmark_cache,
                                                   regime=regime, persist=True)
                    save_latest(conn, result)
                except Exception as e:  # noqa: BLE001 — one bad ticker must not end the refresh
                    log.warning("v2 refresh failed for %s: %s", ticker, e)
                finally:
                    try:
                        conn.close()
                    except Exception:  # noqa: BLE001
                        pass

            _write("UPDATE signal_v2_runs SET status='complete', finished_at=datetime('now'), "
                   "progress='Done' WHERE id = :i", {"i": run_id})
        except Exception as e:  # noqa: BLE001
            log.exception("v2 refresh run %s failed", run_id)
            _write("UPDATE signal_v2_runs SET status='failed', finished_at=datetime('now'), "
                   "error=:e WHERE id = :i", {"e": str(e), "i": run_id})


def summarise(results: list) -> dict:
    """Counts by action plus what needs a person's attention. Small enough to poll."""
    def n(action):
        return sum(1 for r in results if r.get("action") == action)
    return {
        "tickers": len(results),
        "buy": n("BUY"),
        "good_stock_poor_entry": n("GOOD STOCK, POOR ENTRY"),
        "watch": n("WATCH"),
        "avoid": n("AVOID"),
        "unavailable": n("UNAVAILABLE"),
        "material_changes": sum(1 for r in results if (r.get("changes") or {}).get("material")),
        "sell_triggers": sum(1 for r in results if (r.get("sell") or {}).get("any")),
        "standing_concerns": sum(1 for r in results
                                 if (r.get("sell") or {}).get("any_standing")),
        "earnings_blackouts": sum(1 for r in results
                                  if (r.get("earnings") or {}).get("status") == "BLACKOUT"),
    }


def read_v2(app, db, auto_refresh: bool = True) -> dict:
    """What the page calls. Always returns instantly from storage, never computes inline."""
    results, oldest = load_latest_all(db)
    age_minutes = None
    if oldest is not None:
        hrs = _hours_since(oldest)
        age_minutes = round(hrs * 60, 1) if hrs is not None else None
    stale = (not results) or (age_minutes is None) or (age_minutes > STALE_AFTER_MINUTES)

    state = _run_state(db)
    started = False
    if auto_refresh and stale and not state["running"]:
        started = start_refresh(app, db)

    return {
        "strategy_version": STRATEGY_VERSION,
        "results": results,
        "summary": summarise(results),
        "computed_at": oldest,
        "age_minutes": age_minutes,
        "stale": stale,
        "refreshing": state["running"] or started,
        "progress": state["progress"],
        "refresh_error": state["error"],
        "note": ("No reading stored yet — a first computation has been started. It takes about "
                 "90 seconds for all 50; reload shortly."
                 if not results else None),
    }
