"""
Vendor-agnostic fundamentals interface — the same abstraction pattern as MarketDataProvider.

CRITICAL DESIGN RULE (from the project spec): fundamentals are either REAL, sourced, and
attributable, or they are absent. There is no "estimate", no "typical value for this sector",
no interpolation. Every field on `Fundamentals` may be None, and None means "this source did
not report it" — it is never silently turned into a 0 or a plausible-looking guess downstream.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Fundamentals:
    ticker: str
    source: str                       # e.g. "sec-edgar" — always attributed
    as_of: str | None = None          # period end date of the most recent annual figures
    fiscal_year: int | None = None
    filed: str | None = None          # when that filing was actually filed with the SEC

    revenue: float | None = None
    revenue_prior: float | None = None
    revenue_growth_pct: float | None = None

    net_income: float | None = None
    eps_diluted: float | None = None
    eps_diluted_prior: float | None = None
    eps_growth_pct: float | None = None

    gross_profit: float | None = None
    gross_margin_pct: float | None = None
    operating_income: float | None = None
    operating_margin_pct: float | None = None

    operating_cash_flow: float | None = None
    capex: float | None = None
    free_cash_flow: float | None = None
    fcf_margin_pct: float | None = None

    total_cash: float | None = None
    total_debt: float | None = None
    stockholders_equity: float | None = None
    roic_pct: float | None = None     # operating income / (equity + debt) — a proxy, labeled as such

    # Which accounting standard the figures were filed under, and the currency they are
    # denominated in. Both were previously implicit ("US-GAAP, dollars, obviously") and both
    # were wrong for the two 20-F filers in the universe. `currency` is not cosmetic: no FX
    # conversion exists anywhere in this app, so any calculation that puts a fundamental next to
    # a market price must refuse to proceed unless this reads "USD".
    framework: str | None = None      # "us-gaap" | "ifrs-full"
    currency: str | None = None       # "USD", "EUR", "DKK", ...

    warnings: list = field(default_factory=list)
    fetched_at: datetime | None = None


@dataclass
class AnnualPeriod:
    """ONE fiscal year, AS REPORTED BY ONE FILING.

    The distinction in that sentence is the whole point of the class, and it is what makes
    honest historical scoring possible for the first time.

    A fiscal year is not a single set of numbers. FY2023 was reported once in the FY2023 10-K,
    again as a comparative in the FY2024 10-K, and possibly restated in between. Those versions
    can differ. Keeping only the newest — which is what the `fundamentals` table does, having
    `ticker` as its primary key — means any backtest scoring a 2023 date uses figures published
    in 2026. That is look-ahead bias of the purest kind: it cannot be detected by inspecting the
    result, it always improves it, and it is invisible in the code unless you know to look.

    So the identity here is (ticker, period_end, filed), not (ticker). `filed` is the date the
    information became public, and therefore the earliest date it may legitimately be used on.
    A point-in-time read asks for the newest row per period whose `filed` is on or before the
    date being scored, and cannot see the future because the future is a different row.

    `values` holds raw reported figures only — no ratios, no margins, no growth rates. Everything
    derived is computed once in the scoring engine so the Dashboard and Signals pages cannot
    drift apart, which is the entire premise of the v3 shared-engine design.
    """
    ticker: str
    source: str
    period_end: str                   # fiscal period end, e.g. "2025-01-26"
    filed: str                        # when THIS version of the period became public
    framework: str                    # "us-gaap" | "ifrs-full"
    currency: str | None = None       # currency of every money value below; None if unknowable
    fiscal_year: int | None = None
    form: str | None = None           # "10-K", "20-F", "40-F"
    accn: str | None = None           # SEC accession number of the filing, for traceability
    values: dict = field(default_factory=dict)   # concept -> float | None
    warnings: list = field(default_factory=list)


@dataclass
class EarningsInfo:
    """What we can honestly say about earnings timing from filing history alone.

    NOTE: SEC filing dates are BACKWARD-looking (when a report was filed). They are not a
    forward earnings calendar. `estimated_next_report` is explicitly an ESTIMATE derived from
    historical filing cadence and is labeled as such everywhere it surfaces — it is never
    presented as a confirmed earnings date.
    """
    ticker: str
    source: str
    last_period_end: str | None = None
    last_filed: str | None = None
    last_form: str | None = None
    median_days_between_reports: float | None = None
    estimated_next_report: str | None = None
    estimate_confidence: str = "LOW"   # LOW/MEDIUM — never "HIGH"; this is inferred, not published
    warnings: list = field(default_factory=list)


class FundamentalDataProvider(ABC):
    """Any fundamentals vendor must implement this. The rest of the app never imports a
    concrete provider directly, so swapping/adding a source is a one-class change."""

    name: str = "abstract"

    @abstractmethod
    def get_fundamentals(self, ticker: str) -> Fundamentals:
        ...

    @abstractmethod
    def get_earnings_info(self, ticker: str) -> EarningsInfo:
        ...

    def get_fundamentals_history(self, ticker: str) -> list:
        """Every annual period the source reports, in every version it reported them in.

        Not abstract, because a vendor that only sells a current snapshot is a legitimate source
        for other things. It raises rather than returning an empty list on purpose: [] is a
        factual claim ("this company filed nothing"), and a source that simply cannot answer the
        question must not be able to make that claim by accident.
        """
        raise NotImplementedError(
            f"The {self.name} provider does not supply multi-year fundamentals history.")
