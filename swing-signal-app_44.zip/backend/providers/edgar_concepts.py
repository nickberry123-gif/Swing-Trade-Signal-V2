"""
The XBRL vocabulary this app reads, in one place.

WHY THIS FILE EXISTS SEPARATELY. Two things were tangled together in the provider and both were
wrong in the same way — they assumed every company on earth files under US-GAAP in dollars.

  1. `facts["us-gaap"]` was the only namespace read. ASML and NVO file a 20-F under IFRS, so both
     returned completely empty and scored UNAVAILABLE. Two of the fifty stocks had no
     fundamentals at all and the reason was one hard-coded dictionary key.
  2. Unit selection was "USD, else USD/shares, else whatever unit happens to be first". For a
     US filer that is right by luck. For ASML, whose figures are in EUR, "whatever is first"
     is not a decision — it is a coin toss that decides what currency a number is in.

THE CURRENCY RULE, AND IT IS THE IMPORTANT ONE. Every value carries the unit it was reported in.
A euro revenue and a dollar share price produce a P/E that is wrong by roughly the exchange rate
and looks entirely plausible — the exact failure this project keeps hitting. No FX conversion
happens anywhere in this app, so anything downstream that combines a fundamental with a market
price MUST check `currency == "USD"` first and report UNKNOWN otherwise. Storing the currency is
what makes that check possible; it is not decoration.

A NOTE ON HOW FAR I CAN VOUCH FOR THESE TAGS. The US-GAAP chains have been exercised against
live SEC data through the existing provider. The IFRS chains have NOT — this sandbox has no
network route to sec.gov, so they are written from the published IFRS taxonomy and verified on
the server, which is what Build B2 (coverage validation across all 50) is for. A tag name that
turns out to be wrong is not dangerous — it simply finds nothing and the field stays None, which
is the honest answer — but it does mean IFRS coverage is unproven until B2 runs.
"""

# Which kind of unit a concept is measured in. This is per-concept because it cannot be guessed:
# EPS lives under "USD/shares", a share count under "shares", and everything else under a
# three-letter currency code. Getting this wrong silently returns a share count where a dollar
# figure was expected.
UNIT_CURRENCY = "currency"
UNIT_PER_SHARE = "per_share"
UNIT_SHARES = "shares"

CONCEPT_UNIT_KIND = {
    "eps_diluted": UNIT_PER_SHARE,
    "eps_basic": UNIT_PER_SHARE,
    "diluted_shares": UNIT_SHARES,
    "basic_shares": UNIT_SHARES,
}

# Concepts measured OVER a period (income statement, cash flow) rather than AT an instant
# (balance sheet). Duration facts get the ~full-year filter so a Q4 figure is never mistaken for
# a fiscal year; instant facts have no `start` and must not be filtered that way.
DURATION_CONCEPTS = frozenset({
    "revenue", "gross_profit", "operating_income", "net_income", "rnd_expense",
    "interest_expense", "depreciation_amortisation", "eps_diluted", "eps_basic",
    "diluted_shares", "basic_shares",
    "operating_cash_flow", "capex", "buybacks", "dividends_paid", "acquisitions",
})

# ---------------------------------------------------------------------------------------------
# The concept -> namespace -> ordered tag chain map.
#
# Order matters WITHIN a namespace: the first tag that reports a given period wins for that
# period only (see _merged_annual_facts), so a company migrating between tags mid-history is
# handled without dragging the whole result back to the year the old tag stopped.
#
# Order does NOT matter ACROSS namespaces: the framework is chosen once per company and every
# concept then reads from that framework alone. Merging us-gaap and ifrs-full figures for the
# same company would be combining two different accounting standards into one ratio.
# ---------------------------------------------------------------------------------------------
CONCEPTS = {
    # ---- income statement -------------------------------------------------------------------
    "revenue": {
        "us-gaap": [
            "RevenueFromContractWithCustomerExcludingAssessedTax",
            "Revenues",
            "SalesRevenueNet",
            "RevenueFromContractWithCustomerIncludingAssessedTax",
        ],
        "ifrs-full": [
            "Revenue",
            "RevenueFromContractsWithCustomers",
            "RevenueFromSaleOfGoods",
        ],
    },
    "gross_profit": {
        "us-gaap": ["GrossProfit"],
        "ifrs-full": ["GrossProfit"],
    },
    "operating_income": {
        "us-gaap": ["OperatingIncomeLoss"],
        "ifrs-full": ["ProfitLossFromOperatingActivities", "OperatingIncomeLoss"],
    },
    "net_income": {
        "us-gaap": ["NetIncomeLoss", "ProfitLoss"],
        "ifrs-full": ["ProfitLoss", "ProfitLossAttributableToOwnersOfParent"],
    },
    # R&D intensity is one of the four Moat Evidence inputs. Absent for most non-technology
    # companies, and absent is the correct answer there — it is not a zero.
    "rnd_expense": {
        "us-gaap": [
            "ResearchAndDevelopmentExpense",
            "ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost",
        ],
        "ifrs-full": ["ResearchAndDevelopmentExpense"],
    },
    # Interest expense -> interest coverage, a balance-sheet-strength input that has been
    # missing entirely (the 15% category could only reach 5% without it).
    "interest_expense": {
        "us-gaap": [
            "InterestExpense",
            "InterestExpenseDebt",
            "InterestExpenseNonoperating",
            "InterestIncomeExpenseNet",
        ],
        "ifrs-full": ["FinanceCosts", "InterestExpense"],
    },
    # D&A -> EBITDA -> EV/EBITDA, one of the valuation metrics.
    "depreciation_amortisation": {
        "us-gaap": [
            "DepreciationDepletionAndAmortization",
            "DepreciationAmortizationAndAccretionNet",
            "DepreciationAndAmortization",
        ],
        "ifrs-full": [
            "DepreciationAndAmortisationExpense",
            "DepreciationAmortisationAndImpairmentLossReversalOfImpairmentLossRecognisedInProfitOrLoss",
        ],
    },
    "eps_diluted": {
        "us-gaap": ["EarningsPerShareDiluted", "EarningsPerShareBasicAndDiluted"],
        "ifrs-full": ["DilutedEarningsLossPerShare", "BasicAndDilutedEarningsLossPerShare"],
    },
    "eps_basic": {
        "us-gaap": ["EarningsPerShareBasic", "EarningsPerShareBasicAndDiluted"],
        "ifrs-full": ["BasicEarningsLossPerShare", "BasicAndDilutedEarningsLossPerShare"],
    },
    # THE SINGLE MOST LOAD-BEARING ADDITION IN BUILD B. Without a share count there is no market
    # capitalisation, therefore no enterprise value, therefore no P/E, no EV/EBIT, no FCF yield —
    # which is most of the 35% valuation block that the removal of the 200DMA gate makes the only
    # remaining brake on BUY.
    "diluted_shares": {
        "us-gaap": [
            "WeightedAverageNumberOfDilutedSharesOutstanding",
            "WeightedAverageNumberOfDilutedSharesOutstandingBasicAndDiluted",
        ],
        "ifrs-full": [
            "WeightedAverageNumberOfDilutedOrdinarySharesOutstanding",
            "AdjustedWeightedAverageNumberOfOrdinarySharesOutstanding",
        ],
    },
    "basic_shares": {
        "us-gaap": [
            "WeightedAverageNumberOfSharesOutstandingBasic",
            "WeightedAverageNumberOfBasicSharesOutstanding",
            "WeightedAverageNumberOfSharesOutstanding",
        ],
        "ifrs-full": [
            "WeightedAverageNumberOfOrdinarySharesOutstanding",
            "NumberOfSharesOutstanding",
        ],
    },

    # ---- cash flow --------------------------------------------------------------------------
    "operating_cash_flow": {
        "us-gaap": [
            "NetCashProvidedByUsedInOperatingActivities",
            "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations",
        ],
        "ifrs-full": [
            "CashFlowsFromUsedInOperatingActivities",
            "NetCashFlowsFromUsedInOperatingActivities",
        ],
    },
    "capex": {
        "us-gaap": [
            "PaymentsToAcquirePropertyPlantAndEquipment",
            "PaymentsToAcquireProductiveAssets",
            "PaymentsForCapitalImprovements",
        ],
        "ifrs-full": [
            "PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities",
            "PurchaseOfPropertyPlantAndEquipmentIntangibleAssetsOtherThanGoodwillInvestmentPropertyAndOtherNoncurrentAssets",
        ],
    },
    # The three capital-allocation concepts. This whole 10% category scored 0% before Build B
    # because none of these tags was requested.
    "buybacks": {
        "us-gaap": ["PaymentsForRepurchaseOfCommonStock", "PaymentsForRepurchaseOfEquity"],
        "ifrs-full": ["PaymentsToAcquireOrRedeemEntitysShares"],
    },
    "dividends_paid": {
        "us-gaap": [
            "PaymentsOfDividendsCommonStock",
            "PaymentsOfDividends",
            "PaymentsOfOrdinaryDividends",
        ],
        "ifrs-full": ["DividendsPaidClassifiedAsFinancingActivities", "DividendsPaid"],
    },
    "acquisitions": {
        "us-gaap": [
            "PaymentsToAcquireBusinessesNetOfCashAcquired",
            "PaymentsToAcquireBusinessesGross",
        ],
        "ifrs-full": [
            "CashFlowsUsedInObtainingControlOfSubsidiariesOrOtherBusinessesClassifiedAsInvestingActivities",
        ],
    },

    # ---- balance sheet (instant facts — no `start`, no duration filter) ----------------------
    "total_assets": {
        "us-gaap": ["Assets"],
        "ifrs-full": ["Assets"],
    },
    "current_assets": {
        "us-gaap": ["AssetsCurrent"],
        "ifrs-full": ["CurrentAssets"],
    },
    "current_liabilities": {
        "us-gaap": ["LiabilitiesCurrent"],
        "ifrs-full": ["CurrentLiabilities"],
    },
    "total_liabilities": {
        "us-gaap": ["Liabilities"],
        "ifrs-full": ["Liabilities"],
    },
    "total_cash": {
        "us-gaap": [
            "CashAndCashEquivalentsAtCarryingValue",
            "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents",
        ],
        "ifrs-full": ["CashAndCashEquivalents"],
    },
    "stockholders_equity": {
        "us-gaap": [
            "StockholdersEquity",
            "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest",
        ],
        "ifrs-full": ["EquityAttributableToOwnersOfParent", "Equity"],
    },

    # ---- debt components --------------------------------------------------------------------
    # Kept as separate concepts rather than one "total debt" tag because companies split debt
    # between current and non-current portions and no single tag holds the total for everyone.
    # They are summed per period by the provider, never across periods.
    "debt_noncurrent": {
        "us-gaap": ["LongTermDebtNoncurrent"],
        "ifrs-full": ["NoncurrentPortionOfNoncurrentBorrowings", "NoncurrentBorrowings"],
    },
    "debt_current": {
        "us-gaap": ["LongTermDebtCurrent"],
        "ifrs-full": ["CurrentPortionOfNoncurrentBorrowings", "ShorttermBorrowings"],
    },
    "debt_total_reported": {
        "us-gaap": ["LongTermDebt", "DebtLongtermAndShorttermCombinedAmount"],
        "ifrs-full": ["Borrowings"],
    },
}

# The frameworks this app understands, in the order they are tried when deciding which one a
# company files under. A company that uses neither gets no fundamentals — which is correct, and
# visible, rather than an empty score presented as a real one.
FRAMEWORKS = ("us-gaap", "ifrs-full")

# The concept whose coverage decides the framework. Revenue is the right choice because every
# operating company reports it under both standards, so "which namespace has more annual revenue
# periods" is a reliable answer to "which standard does this company file under".
FRAMEWORK_ANCHOR = "revenue"

# The stored, per-period record. THIS TUPLE IS THE SOURCE OF TRUTH for the fundamentals_history
# table's value columns — a test asserts the schema matches it, so adding a concept here without
# adding the column fails the suite rather than silently dropping the value at write time.
HISTORY_VALUE_FIELDS = (
    "revenue",
    "gross_profit",
    "operating_income",
    "net_income",
    "rnd_expense",
    "interest_expense",
    "depreciation_amortisation",
    "eps_diluted",
    "eps_basic",
    "diluted_shares",
    "basic_shares",
    "operating_cash_flow",
    "capex",
    "buybacks",
    "dividends_paid",
    "acquisitions",
    "total_assets",
    "current_assets",
    "current_liabilities",
    "total_liabilities",
    "total_cash",
    "stockholders_equity",
    "total_debt",
)


def tags_for(concept: str, framework: str) -> list:
    """The ordered tag chain for one concept under one framework. Unknown pairs return [] rather
    than raising, so a concept that simply doesn't exist in a taxonomy is absent, not an error."""
    return list((CONCEPTS.get(concept) or {}).get(framework) or [])


def unit_kind(concept: str) -> str:
    return CONCEPT_UNIT_KIND.get(concept, UNIT_CURRENCY)


def is_duration(concept: str) -> bool:
    return concept in DURATION_CONCEPTS
