from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services import fundamentals_history_service as fh
from services.fundamentals_service import get_earnings_info, get_fundamentals
from services.news_service import get_news_for_ticker, refresh_news
from services.signals_service import TICKERS

bp = Blueprint("api_fundamentals", __name__, url_prefix="/api")


@bp.get("/fundamentals/<ticker>")
def stock_fundamentals(ticker):
    """Audited financial-statement data from SEC EDGAR plus the derived long-term quality score.
    Requires no API key (EDGAR is public) and is independent of the Alpaca credentials."""
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404

    db = get_db()
    force = request.args.get("refresh") == "1"
    data = get_fundamentals(db, ticker, force_refresh=force)
    data["earnings"] = get_earnings_info(db, ticker, force_refresh=force)
    return jsonify(data)


@bp.get("/fundamentals/history/<ticker>")
def stock_fundamentals_history(ticker):
    """The multi-year annual history, optionally AS IT WAS KNOWN on a given date.

    `?as_of=YYYY-MM-DD` restricts the answer to filings published on or before that date, which
    is how a historical score avoids using figures that did not exist yet. Omitting it means
    today — the only case where the newest filing is the right one.

    `?refresh=1` refetches from SEC. Rate-limited by a 30-day cache because annual filings
    arrive annually.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404

    db = get_db()
    refreshed = fh.refresh(db, ticker, force=request.args.get("refresh") == "1")
    as_of = request.args.get("as_of") or None
    rows = fh.history(db, ticker, as_of_filed=as_of, limit=int(request.args.get("years", 10)))
    return jsonify({
        "ticker": ticker,
        "as_of_filed": as_of or "today",
        "refresh": refreshed,
        "periods": rows,
        "coverage": fh.coverage(db, ticker, as_of_filed=as_of),
        "note": "Figures are as reported in filings published on or before the as-of date. "
                "Restatements filed later are excluded by the query, not merely ignored.",
    })


@bp.get("/fundamentals/coverage")
def fundamentals_coverage():
    """Per-ticker, per-field coverage across the universe — the input to the Build B2 check that
    Company Health and valuation can actually be populated before any score depends on them.

    Read-only and deliberately never refetches: this endpoint reports what is stored, so it can
    be used to check whether a refresh worked rather than quietly performing one and reporting
    success either way.
    """
    db = get_db()
    tickers = [t.strip().upper() for t in (request.args.get("tickers") or "").split(",") if t.strip()]
    tickers = [t for t in tickers if t in TICKERS] or sorted(TICKERS)
    return jsonify({
        "tickers": len(tickers),
        "results": [fh.coverage(db, t, as_of_filed=request.args.get("as_of") or None)
                    for t in tickers],
    })


@bp.get("/news/<ticker>")
def stock_news(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({"ticker": ticker, "data_status": "UNAVAILABLE",
                        "error": "Alpaca API credentials not configured", "items": []}), 200

    db = get_db()
    result = refresh_news(db, [ticker], force=request.args.get("refresh") == "1")
    items = get_news_for_ticker(db, ticker, limit=20)
    return jsonify({
        "ticker": ticker,
        "data_status": "UNAVAILABLE" if (result.get("error") and not items) else "OK",
        "error": result.get("error"),
        "sentiment_method": "keyword-based classifier (not NLP/AI sentiment analysis) — see "
                            "providers/news_provider.py for the exact keyword lists",
        "items": items,
    })
