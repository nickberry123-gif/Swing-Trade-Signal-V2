"""Which share count may stand behind a current market capitalisation, and how sure we are of it.

WHY THIS MODULE EXISTS
======================
Regeneron was valued using a cover-page share count of 93,955,110 from a document filed in
**July 2012**. The company's actual count in 2026 is about 104.8 million. The resulting market
capitalisation was roughly 10% too small — and that is the whole problem, because 10% too small
is not absurd. The price/earnings ratio came out at 16.8 instead of 18.4. Every plausibility
check passed. Nothing looked wrong.

The earlier Booking Holdings defect was the easy version of this: a share basis so wrong it
produced a P/E of 1.20, which cannot be true and was therefore caught. A share count wrong by a
*plausible* margin produces a *plausible* valuation, and no threshold on the answer will ever
find it. The error has to be caught on the INPUT — by asking whether the count is entitled to be
used at all — because by the time it reaches the output it is indistinguishable from a real one.

Investigation established that this is not a selection bug. Every non-dimensional share concept
Regeneron publishes stops in late 2012:

    dei:EntityCommonStockSharesOutstanding    9 facts, newest filed 2012-07-25
    us-gaap:CommonStockSharesOutstanding     19 facts, newest filed 2012-10-24
    us-gaap:CommonStockSharesIssued          22 facts, newest filed 2012-10-24
    us-gaap:TreasuryStockCommonShares        31 facts, newest filed 2026-07-30

Treasury stock is current because it is not broken out by share class; everything that IS broken
out by class disappeared from SEC's `companyfacts` the moment the company began tagging per
class. So there is no aggregate route left, including issued-minus-treasury — the issued side is
just as stale. The count genuinely is not obtainable from the API this app reads.

That leaves one honest question, which is what this module answers: given that the newest actual
count may be missing, WHICH figure is allowed to stand behind a market capitalisation, and what
must be said about it.

THE RULE THAT DOES THE WORK
===========================
Not an age in days. The primary test is cadence-relative:

    A share count may feed current valuation only if it comes from the most recent filing this
    app holds for the company, or the one immediately before it.

This is self-calibrating and needs no filer classification. It catches Regeneron immediately and
for exactly the right reason: the app was holding a Regeneron 10-K **filed 2026-02-04** while
valuing the company on a count from a filing published in **2012**. It already knew about a newer
document and used an older one. No number of days expresses that as directly, and any fixed
threshold that caught it would have been chosen to catch it.

Two filings of latitude rather than one, because the two stores fill up independently: a
cover-page count and an annual figure arrive from different documents, and a company should not
lose its valuation because the newest filing happened to be the one carrying the other kind.

Day counts sit UNDERNEATH as a backstop, for the case where the newest filing this app holds is
itself old. They are derived from the filing calendar rather than picked:

    quarterly source — a new document every ~90 days, filed up to ~45 days after the period it
                       covers, so ~135 days is the longest a current count should ever be.
                       200 allows one late cycle.
    annual source    — 365 + ~60 days of filing lag = ~425. 450 rounds it up.

CADENCE IS MEASURED, NOT ASSUMED
================================
Which backstop applies is decided by how often filings ACTUALLY arrive in this app, not by what
the company theoretically files. That distinction matters: Alphabet is a quarterly filer whose
cover-page count is absent from `companyfacts` entirely, so this app only ever sees its annual
figure. Judging it against a 200-day quarterly rule would withhold Alphabet's market
capitalisation for half of every year over a data-availability gap rather than a data problem.
Measuring the cadence of what actually arrives gives Alphabet the annual allowance, which is the
truthful description of what this app knows about Alphabet.

WHAT THE FALLBACK IS, AND WHY IT IS BASIC RATHER THAN DILUTED
=============================================================
When no actual count qualifies, the weighted-average share count from the income statement is
used instead, labelled ESTIMATED so that nothing downstream can mistake it for a real one.

It must be BASIC, not diluted. Diluted deliberately counts shares that do not exist yet —
options, restricted stock, convertibles — because that is the right denominator for earnings per
share. It is the wrong denominator for a market capitalisation, because those shares cannot be
bought. Measured on Regeneron against the actual all-class count of 104,839,032 from the 10-Q
filed 2026-04-29:

    2012 cover-page count      93,955,110    -10.4%    <- what the app was using
    weighted-average diluted  108,600,000     +3.6%
    weighted-average basic    104,600,000     -0.23%   <- what this module selects

Basic is still an average across a year rather than a point in time, so it lags a company that
is buying back or issuing heavily — roughly half the annual change. That is why it is published
as ESTIMATED and never as a count.

WHAT IS NOT HERE
================
No cover-page extraction from filing documents. The figure IS reachable — FilingSummary.xml
names R1.htm, and Regeneron's R1.htm carries Class A 1,817,146 and Common 103,902,660 — but that
route serves exactly one company in this fifty, adds HTML shape-parsing and two extra requests
per company per run, and carries a class-aggregation double-count risk that cannot be validated
against a single example. Building it would repeat the pattern this work exists to stop.
"""
from __future__ import annotations

from datetime import date, datetime, timezone

# ---- provenance -----------------------------------------------------------------------------
# Structured, not prose. Every metric built on a share count carries one of these, so a reader
# never has to infer from a sentence whether a number rests on a measurement or an estimate.
ACTUAL = "ACTUAL"                  # a real count, from the newest filing carrying one
ACTUAL_ANNUAL = "ACTUAL_ANNUAL"    # a real count, but from the annual filing rather than a newer one
ESTIMATED = "ESTIMATED"            # weighted-average shares — an average, not a count
UNKNOWN = "UNKNOWN"                # nothing qualifies; publish no market capitalisation

#: Provenances a market capitalisation may be published under.
PUBLISHABLE = (ACTUAL, ACTUAL_ANNUAL, ESTIMATED)

#: Provenances that are a genuine point-in-time count of shares in issue.
COUNTED = (ACTUAL, ACTUAL_ANNUAL)

QUARTERLY = "QUARTERLY"
ANNUAL = "ANNUAL"

# ---- the thresholds, all derived above rather than chosen ------------------------------------
QUARTERLY_MAX_AGE_DAYS = 200
ANNUAL_MAX_AGE_DAYS = 450

#: Filings closer together than this mean documents are arriving more often than once a year.
QUARTERLY_CADENCE_MAX_GAP_DAYS = 150

#: How far back to look when measuring cadence. Three years is enough to see the rhythm and
#: short enough that a company's filing history from a decade ago cannot distort it — which
#: matters here, because Regeneron's only cover-page filings are from 2012.
CADENCE_LOOKBACK_DAYS = 1100

#: How many of the most recent filings may carry the count. See the module note.
ACCEPTED_FILING_DEPTH = 2


def _as_date(value):
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value)[:10]).date()
    except (TypeError, ValueError):
        return None


def _days_between(earlier, later):
    a, b = _as_date(earlier), _as_date(later)
    if a is None or b is None:
        return None
    return (b - a).days


def _today():
    return datetime.now(timezone.utc).date().isoformat()


def _number(value):
    try:
        out = float(value) if value is not None else None
    except (TypeError, ValueError):
        return None
    return out if (out is not None and out > 0) else None


def known_filing_dates(*date_lists) -> list:
    """Every distinct filing date this app holds for one company, newest first.

    The union of the two stores on purpose. A cover-page count and an annual figure come from
    different documents filed on different days, and the question "is there a newer filing than
    the one this count came from" can only be answered by looking at both.
    """
    seen = set()
    for group in date_lists:
        for value in group or ():
            parsed = _as_date(value)
            if parsed is not None:
                seen.add(parsed.isoformat())
    return sorted(seen, reverse=True)


def measure_cadence(filed_dates, reference_date=None) -> dict:
    """How often filings actually reach this app for one company.

    Uses the MEDIAN gap rather than the mean so that one unusual interval — an amended filing
    days after the original, or a gap while a company was late — cannot move the answer. A
    company with fewer than two filings inside the window has no measurable rhythm, and is given
    the annual allowance: the app has no evidence it files more often, and the conservative
    choice is the one that does not withhold a figure over an absence of evidence.
    """
    reference = _as_date(reference_date) or _as_date(_today())
    recent = []
    for value in filed_dates or ():
        parsed = _as_date(value)
        if parsed is None:
            continue
        age = (reference - parsed).days
        if 0 <= age <= CADENCE_LOOKBACK_DAYS:
            recent.append(parsed)
    recent.sort(reverse=True)

    if len(recent) < 2:
        return {"cadence": ANNUAL, "max_age_days": ANNUAL_MAX_AGE_DAYS,
                "median_gap_days": None, "filings_in_window": len(recent),
                "why": ("fewer than two filings in the last three years, so no filing rhythm can "
                        "be measured — the annual allowance is used rather than assuming a "
                        "cadence the evidence does not show")}

    gaps = sorted((recent[i] - recent[i + 1]).days for i in range(len(recent) - 1))
    middle = len(gaps) // 2
    median_gap = gaps[middle] if len(gaps) % 2 else (gaps[middle - 1] + gaps[middle]) / 2.0

    if median_gap <= QUARTERLY_CADENCE_MAX_GAP_DAYS:
        return {"cadence": QUARTERLY, "max_age_days": QUARTERLY_MAX_AGE_DAYS,
                "median_gap_days": median_gap, "filings_in_window": len(recent),
                "why": (f"filings arrive about every {median_gap:.0f} days, so a current count "
                        f"should never be more than {QUARTERLY_MAX_AGE_DAYS} days old")}
    return {"cadence": ANNUAL, "max_age_days": ANNUAL_MAX_AGE_DAYS,
            "median_gap_days": median_gap, "filings_in_window": len(recent),
            "why": (f"filings reach this app about every {median_gap:.0f} days, so the annual "
                    f"allowance of {ANNUAL_MAX_AGE_DAYS} days applies — this describes what this "
                    f"app receives, not how often the company files")}


def _qualify(filed, accepted, cadence, reference_date):
    """Whether a figure from `filed` is entitled to stand behind a current valuation."""
    filed_iso = _as_date(filed)
    filed_iso = filed_iso.isoformat() if filed_iso else None
    if filed_iso is None:
        return False, "the filing date of this figure is not recorded, so its age cannot be checked"

    age = _days_between(filed_iso, reference_date)
    if filed_iso not in accepted:
        newest = accepted[0] if accepted else "an unknown date"
        return False, (
            f"it comes from a filing published {filed_iso}, but this app already holds a more "
            f"recent filing for this company ({newest}). A count is only current if it comes "
            f"from the newest filing, or the one before it"
            + (f" — this one is {age:,} days old" if age is not None else ""))

    if age is not None and age > cadence["max_age_days"]:
        return False, (
            f"it comes from a filing published {filed_iso}, {age:,} days ago, beyond the "
            f"{cadence['max_age_days']}-day limit for this company — {cadence['why']}")
    return True, None


def resolve(cover_count, latest_row, filed_dates, reference_date=None) -> dict:
    """Pick the share basis, or refuse to pick one.

    `cover_count`  — the newest stored cover-page count, or None
    `latest_row`   — the newest annual history row (shares_outstanding, basic_shares, ...)
    `filed_dates`  — every filing date this app holds for the company (see `known_filing_dates`)
    `reference_date` — the date the price is from; today when omitted

    Returns a dict that always carries `provenance`, and carries `shares` only when that
    provenance is publishable. The rejected candidates travel with it, because "why is this
    company's market capitalisation missing" must be answerable from the result rather than by
    re-running anything.
    """
    reference = _as_date(reference_date)
    reference = reference.isoformat() if reference else _today()
    latest_row = latest_row or {}

    cadence = measure_cadence(filed_dates, reference)
    accepted = list(filed_dates or ())[:ACCEPTED_FILING_DEPTH]

    out = {
        "provenance": UNKNOWN,
        "shares": None,
        "source": None,
        "source_form": None,
        "source_filed": None,
        "as_of": None,
        "age_days": None,
        "cadence": cadence,
        "accepted_filings": accepted,
        "rejected": [],
        "reason": None,
        "label": None,
    }

    annual_filed = latest_row.get("filed")

    # Level 1 — a real count from a cover page, quarterly or annual, whichever is newest.
    # Level 2 — the annual filing's own count, when no newer document carried one.
    # Level 3 — weighted-average basic shares. Level 3b — diluted, only if basic is absent.
    #
    # Every level faces the SAME qualification test. An estimate from a filing this app should
    # have superseded is no more usable than a count from one, and letting the fallback in
    # unchecked would rebuild the defect one level down.
    candidates = [
        (ACTUAL, _number((cover_count or {}).get("shares")), (cover_count or {}).get("filed"),
         (cover_count or {}).get("as_of"), (cover_count or {}).get("form"),
         "cover-page count", None),
        (ACTUAL_ANNUAL, _number(latest_row.get("shares_outstanding")), annual_filed,
         latest_row.get("period_end"), latest_row.get("form"),
         "shares outstanding reported in the annual filing", None),
        (ESTIMATED, _number(latest_row.get("basic_shares")), annual_filed,
         latest_row.get("period_end"), latest_row.get("form"),
         "weighted-average basic shares",
         "weighted-average basic shares, not current shares outstanding"),
        (ESTIMATED, _number(latest_row.get("diluted_shares")), annual_filed,
         latest_row.get("period_end"), latest_row.get("form"),
         "weighted-average diluted shares",
         "weighted-average diluted shares, not current shares outstanding — basic shares were "
         "not reported, and diluted includes shares that do not yet exist"),
    ]

    for provenance, shares, filed, as_of, form, source, label in candidates:
        if shares is None:
            continue
        ok, why = _qualify(filed, accepted, cadence, reference)
        if not ok:
            out["rejected"].append({"provenance": provenance, "source": source, "shares": shares,
                                    "filed": _as_date(filed).isoformat() if _as_date(filed) else None,
                                    "why": why})
            continue
        out.update({
            "provenance": provenance,
            "shares": shares,
            "source": source,
            "source_form": form,
            "source_filed": _as_date(filed).isoformat() if _as_date(filed) else None,
            "as_of": _as_date(as_of).isoformat() if _as_date(as_of) else None,
            "age_days": _days_between(filed, reference),
            "label": label,
        })
        return out

    out["reason"] = _unknown_reason(out["rejected"])
    return out


def _unknown_reason(rejected):
    if not rejected:
        return ("no share count of any kind appears in the filings this app reads for this "
                "company, so no market capitalisation can be calculated")
    worst = rejected[0]
    return (f"no share count is current enough to stand behind a valuation. The best available "
            f"is {worst['source']} of {worst['shares']:,.0f}, and {worst['why']}. A market "
            f"capitalisation built on it would be wrong by however much the count has moved "
            f"since, which is exactly the kind of error that still produces a believable number.")


def describe(resolved: dict) -> str:
    """One sentence a person can check, for the diagnostic page."""
    if resolved["provenance"] == UNKNOWN:
        return resolved["reason"] or "no usable share basis"
    age = resolved.get("age_days")
    parts = [f"{resolved['provenance']}: {resolved['shares']:,.0f} shares from "
             f"{resolved['source']}"]
    if resolved.get("source_form"):
        parts.append(f"in the {resolved['source_form']}")
    if resolved.get("source_filed"):
        parts.append(f"filed {resolved['source_filed']}")
    if age is not None:
        parts.append(f"({age:,} days old)")
    if resolved.get("label"):
        parts.append(f"— {resolved['label']}")
    return " ".join(parts)
