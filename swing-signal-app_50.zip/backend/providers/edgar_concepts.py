"""
The XBRL vocabulary this app reads, in one place.

WHY THIS FILE EXISTS SEPARATELY. Two things were tangled together in the provider and both were
wrong in the same way — they assumed every company on earth files under US-GAAP in dollars.

  1. `facts["us-gaap"]` was the only namespace read. ASML and NVO file a 20-F under IFRS, so both
     returned completely empty and scored UNAVAILABLE. Two of the fifty stocks had no
     fundamentals at all and the reason was one hard-coded dictionary key.
  2. Unit selection was "USD, else USD/shares, else whatever unit happens to be first". For a
     US filer that is right by luck. For ASML, whose figures are in EUR, "whatever is first"
     is not a decision — it is a coin toss that decides what currency a number is in.

THE CURRENCY RULE, AND IT IS THE IMPORTANT ONE. Every value carries the unit it was reported in.
A euro revenue and a dollar share price produce a P/E that is wrong by roughly the exchange rate
and looks entirely plausible — the exact failure this project keeps hitting. No FX conversion
happens anywhere in this app, so anything downstream that combines a fundamental with a market
price MUST check `currency == "USD"` first and report UNKNOWN otherwise. Storing the currency is
what makes that check possible; it is not decoration.

A NOTE ON HOW FAR I CAN VOUCH FOR THESE TAGS. The US-GAAP chains have been exercised against
live SEC data through the existing provider. The IFRS chains have NOT — this sandbox has no
network route to sec.gov, so they are written from the published IFRS taxonomy and verified on
the server, which is what Build B2 (coverage validation across all 50) is for. A tag name that
turns out to be wrong is not dangerous — it simply finds nothing and the field stays None, which
is the honest answer — but it does mean IFRS coverage is unproven until B2 runs.
"""

# Which kind of unit a concept is measured in. This is per-concept because it cannot be guessed:
# EPS lives under "USD/shares", a share count under "shares", and everything else under a
# three-letter currency code. Getting this wrong silently returns a share count where a dollar
# figure was expected.
UNIT_CURRENCY = "currency"
UNIT_PER_SHARE = "per_share"
UNIT_SHARES = "shares"

CONCEPT_UNIT_KIND = {
    "eps_diluted": UNIT_PER_SHARE,
    "eps_basic": UNIT_PER_SHARE,
    "diluted_shares": UNIT_SHARES,
    "basic_shares": UNIT_SHARES,
    "shares_outstanding": UNIT_SHARES,
}

# Namespaces to try BEFORE the company's own detected taxonomy, per concept.
#
# `dei` (Document and Entity Information) is the cover-page namespace. Most US filers publish
# their shares-outstanding count there, which makes it the first place to look — but NOT the only
# one. NVO's entire `dei` namespace contains a single tag and it is not a share count, so a
# dei-only rule left the field empty. Trying dei first and then falling back to the company's own
# taxonomy covers both.
NAMESPACE_PREFERENCE = {
    "shares_outstanding": ("dei",),
}

# How far a fact's own date may sit from the fiscal period end and still belong to that period,
# as (days_before, days_after).
#
# The default ±15 days exists because fiscal year ends drift: NVIDIA's FY2025 ended 2025-01-26
# and FY2024 ended 2024-01-28, so an exact match would miss legitimate alignments.
#
# `shares_outstanding` NEEDS ITS OWN WINDOW AND THIS IS NOT A DETAIL. The cover-page share count
# is dated when the filing was prepared, which is always AFTER the period it accompanies —
# Apple's FY2025 ended 27 September and the 10-K was filed 31 October. Under the default window
# that fact is 20-plus days away from the period end and would be silently discarded, leaving
# every US filer without the one figure that unlocks market capitalisation. The window is
# therefore asymmetric: never before the period end (a count from before the year closed belongs
# to the previous year), and generously after it. 200 days cannot reach the next fiscal year, so
# there is no ambiguity about which period a match belongs to.
CONCEPT_PERIOD_TOLERANCE_DAYS = {
    "shares_outstanding": (0, 200),
}
DEFAULT_PERIOD_TOLERANCE_DAYS = (15, 15)

# CONCEPTS WHOSE VALUE DEPENDS ON THE SHARE BASIS IN FORCE WHEN THE FILING WAS MADE.
#
# A stock split does not change a company; it changes every per-share number ever printed about
# it. Filings are restated for splits going forward only, so the FY2022 share count printed in
# the 2024 annual report and the FY2022 share count printed in the 2026 annual report differ by
# the split factor — both correct, on different bases.
#
# Found on live data: NVIDIA's FY2022 diluted share count read 2.535 billion from a 2024 filing
# and its FY2024 count read 24.94 billion from a 2026 filing. That is the 10-for-1 split, and
# comparing the two produced an 877% "dilution" for a company that has been buying stock back.
# Worse, the same 10x gap appeared BETWEEN TWO FIELDS OF ONE ROW, because each concept
# independently took the newest filing that reported it.
#
# The rule: these concepts must come from the vintage filing ITSELF, not merely from the newest
# filing published by that date. Every split-sensitive figure in a row then shares one basis, and
# rows sharing a filing date are comparable to each other. No split factor is inferred anywhere —
# inferring one would mean guessing, and a guessed 10x is worse than an absent number.
SPLIT_SENSITIVE_CONCEPTS = frozenset({
    "eps_diluted", "eps_basic", "diluted_shares", "basic_shares", "shares_outstanding",
})


def period_tolerance(concept: str) -> tuple:
    return CONCEPT_PERIOD_TOLERANCE_DAYS.get(concept, DEFAULT_PERIOD_TOLERANCE_DAYS)

# Concepts measured OVER a period (income statement, cash flow) rather than AT an instant
# (balance sheet). Duration facts get the ~full-year filter so a Q4 figure is never mistaken for
# a fiscal year; instant facts have no `start` and must not be filtered that way.
DURATION_CONCEPTS = frozenset({
    "revenue", "gross_profit", "cost_of_revenue", "costs_and_expenses", "operating_expenses",
    "pretax_income", "nonoperating_income_expense", "operating_income", "net_income", "rnd_expense",
    "interest_expense", "depreciation_amortisation", "eps_diluted", "eps_basic",
    "diluted_shares", "basic_shares",
    "operating_cash_flow", "capex", "buybacks", "dividends_paid", "acquisitions",
})

# ---------------------------------------------------------------------------------------------
# The concept -> namespace -> ordered tag chain map.
#
# Order matters WITHIN a namespace: the first tag that reports a given period wins for that
# period only (see _merged_annual_facts), so a company migrating between tags mid-history is
# handled without dragging the whole result back to the year the old tag stopped.
#
# Order does NOT matter ACROSS namespaces: the taxonomy is chosen once per company and every
# concept then reads from that taxonomy alone. Merging us-gaap and ifrs-full figures for the
# same company would be combining two different accounting standards into one ratio.
# ---------------------------------------------------------------------------------------------
CONCEPTS = {
    # ---- income statement -------------------------------------------------------------------
    # ---- the income-statement structure needed to RECONCILE an operating profit --------------
    # Added because 22-plus companies, Eli Lilly among them, do not print an operating income
    # subtotal at all. Their statements run revenue -> costs -> income before taxes. That is a
    # legitimate presentation, not missing data, and it left seven dependent metrics blank.
    #
    # These four concepts exist so operating profit can be RECONCILED from what the filing does
    # say, by more than one route, rather than assumed from a single subtraction.
    "costs_and_expenses": {
        # The total of ALL operating costs including cost of revenue. Where a company reports it,
        # revenue minus this is the cleanest possible operating profit.
        "us-gaap": ["CostsAndExpenses", "BenefitsLossesAndExpenses"],
        "ifrs-full": [],
    },
    "operating_expenses": {
        # Operating costs EXCLUDING cost of revenue. Only usable alongside a gross profit.
        "us-gaap": ["OperatingExpenses"],
        "ifrs-full": ["OperatingExpense"],
    },
    "pretax_income": {
        "us-gaap": [
            "IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest",
            "IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments",
            "IncomeLossFromContinuingOperationsBeforeIncomeTaxesDomestic",
        ],
        "ifrs-full": ["ProfitLossBeforeTax"],
    },
    "nonoperating_income_expense": {
        # The aggregate of everything BELOW the operating line. Required before pre-tax income can
        # be walked back to an operating figure: without it the walk silently absorbs investment
        # gains, one-off settlements and foreign-exchange swings into "operating" profit.
        "us-gaap": ["NonoperatingIncomeExpense"],
        "ifrs-full": [],
    },
    "revenue": {
        # `Revenues` FIRST, AND THE ORDER IS A BUG FIX, NOT A PREFERENCE.
        #
        # `RevenueFromContractWithCustomerExcludingAssessedTax` is the ASC 606 contract-revenue
        # element. For most companies it equals total revenue. For a company with material
        # non-contract revenue — leases, interest, royalties — it is a SUBSET, and putting it
        # first silently returned part of the top line as if it were all of it.
        #
        # Found on live data: United Rentals, an equipment RENTAL business whose rental income is
        # lease revenue under ASC 842, reported revenue of $3.7bn against gross profit of $6.1bn.
        # A gross margin of 166% is what made it visible; the understated revenue also inflated
        # every margin, every growth rate and every valuation multiple built on it, and would
        # have done so quietly on any company whose margins stayed under 100%.
        "us-gaap": [
            "Revenues",
            "RevenueFromContractWithCustomerExcludingAssessedTax",
            "SalesRevenueNet",
            "RevenueFromContractWithCustomerIncludingAssessedTax",
        ],
        "ifrs-full": [
            "Revenue",
            "RevenueFromContractsWithCustomers",
            "RevenueFromSaleOfGoods",
        ],
    },
    "gross_profit": {
        "us-gaap": ["GrossProfit"],
        "ifrs-full": ["GrossProfit"],
    },
    # COST OF REVENUE, ADDED BECAUSE GROSS PROFIT WAS MISSING ON 22 OF THE 50 COMPANIES.
    #
    # `GrossProfit` is not a required XBRL element and plenty of companies simply do not tag it —
    # they report revenue and cost of revenue and leave the subtraction to the reader. That single
    # gap was the largest in the whole universe: it took out gross margin on 22 companies and
    # gross-margin stability (a Moat Evidence input) on 21.
    #
    # Gross profit = revenue - cost of revenue is an accounting identity, not an estimate, so
    # deriving it is not fabrication. It is done in the scoring layer rather than here, because
    # this table holds figures AS REPORTED and a derived number stored beside reported ones
    # eventually gets mistaken for one. What is stored is the raw cost line; the subtraction —
    # and the label saying it was derived — happens where the metric is computed.
    "cost_of_revenue": {
        "us-gaap": [
            "CostOfRevenue",
            "CostOfGoodsAndServicesSold",
            "CostOfGoodsSold",
            "CostOfServices",
        ],
        "ifrs-full": ["CostOfSales"],
    },
    "operating_income": {
        "us-gaap": ["OperatingIncomeLoss"],
        "ifrs-full": ["ProfitLossFromOperatingActivities", "OperatingIncomeLoss"],
    },
    "net_income": {
        "us-gaap": ["NetIncomeLoss", "ProfitLoss"],
        "ifrs-full": ["ProfitLoss", "ProfitLossAttributableToOwnersOfParent"],
    },
    # R&D intensity is one of the four Moat Evidence inputs. Absent for most non-technology
    # companies, and absent is the correct answer there — it is not a zero.
    "rnd_expense": {
        "us-gaap": [
            "ResearchAndDevelopmentExpense",
            "ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost",
        ],
        "ifrs-full": ["ResearchAndDevelopmentExpense"],
    },
    # Interest expense -> interest coverage, a balance-sheet-strength input that has been
    # missing entirely (the 15% category could only reach 5% without it).
    "interest_expense": {
        "us-gaap": [
            "InterestExpense",
            "InterestExpenseDebt",
            "InterestExpenseNonoperating",
            "InterestAndDebtExpense",
            "InterestExpenseBorrowings",
            "InterestIncomeExpenseNet",
        ],
        "ifrs-full": ["FinanceCosts", "InterestExpense"],
    },
    # D&A -> EBITDA -> EV/EBITDA, one of the valuation metrics.
    "depreciation_amortisation": {
        "us-gaap": [
            "DepreciationDepletionAndAmortization",
            "DepreciationAmortizationAndAccretionNet",
            "DepreciationAndAmortization",
        ],
        "ifrs-full": [
            "DepreciationAndAmortisationExpense",
            "DepreciationAmortisationAndImpairmentLossReversalOfImpairmentLossRecognisedInProfitOrLoss",
        ],
    },
    "eps_diluted": {
        "us-gaap": ["EarningsPerShareDiluted", "EarningsPerShareBasicAndDiluted"],
        "ifrs-full": ["DilutedEarningsLossPerShare", "BasicAndDilutedEarningsLossPerShare"],
    },
    "eps_basic": {
        "us-gaap": ["EarningsPerShareBasic", "EarningsPerShareBasicAndDiluted"],
        "ifrs-full": ["BasicEarningsLossPerShare", "BasicAndDilutedEarningsLossPerShare"],
    },
    # THE SINGLE MOST LOAD-BEARING ADDITION IN BUILD B. Without a share count there is no market
    # capitalisation, therefore no enterprise value, therefore no P/E, no EV/EBIT, no FCF yield —
    # which is most of the 35% valuation block that the removal of the 200DMA gate makes the only
    # remaining brake on BUY.
    "diluted_shares": {
        "us-gaap": [
            "WeightedAverageNumberOfDilutedSharesOutstanding",
            "WeightedAverageNumberOfDilutedSharesOutstandingBasicAndDiluted",
        ],
        "ifrs-full": [
            "WeightedAverageNumberOfDilutedOrdinarySharesOutstanding",
            "AdjustedWeightedAverageNumberOfOrdinarySharesOutstanding",
            # Novo Nordisk's actual tag. My first two guesses were both wrong — the real name is
            # shorter — and the field sat empty until the tag diagnostic showed what NVO really
            # publishes. "Adjusted" is the IFRS convention for the diluted denominator.
            "AdjustedWeightedAverageShares",
        ],
    },
    "basic_shares": {
        "us-gaap": [
            "WeightedAverageNumberOfSharesOutstandingBasic",
            "WeightedAverageNumberOfBasicSharesOutstanding",
            "WeightedAverageNumberOfSharesOutstanding",
        ],
        "ifrs-full": [
            "WeightedAverageNumberOfOrdinarySharesOutstanding",
            # Novo Nordisk's actual tag, read off its live filings via the tag diagnostic rather
            # than guessed. `NumberOfSharesOutstanding` used to sit in this chain and was wrong
            # for two reasons: it is a point-in-time count rather than a weighted average, and it
            # therefore belongs under `shares_outstanding`, where it now is.
            "WeightedAverageShares",
        ],
    },
    # THE COVER-PAGE SHARE COUNT, AND IT IS A DIFFERENT THING FROM THE TWO ABOVE — hence its own
    # name rather than being bolted onto the diluted chain as a fallback.
    #
    # `dei:EntityCommonStockSharesOutstanding` is the shares-outstanding figure on the front page
    # of every annual filing, in the `dei` namespace that both US-GAAP and IFRS filers use. It is
    # a point-in-time count at the filing date, NOT a weighted average over the year, and it
    # excludes the dilutive effect of options.
    #
    # For market capitalisation it is arguably the better input — market cap is shares times
    # price at a moment, not an average over a year. For per-share earnings it is the wrong
    # number. Keeping them separate means the validation layer can say which one it used, and
    # NVO — whose IFRS diluted-share tag came back empty against live data — gets a market cap
    # from a source that is honestly labelled rather than from a tag that happens to be nearby.
    "shares_outstanding": {
        "dei": ["EntityCommonStockSharesOutstanding"],
        # Foreign private issuers frequently do not publish the dei cover-page count — NVO's
        # entire dei namespace holds one tag and it is not this one — so the taxonomy's own
        # point-in-time count is the fallback.
        # `CommonStockSharesIssued` IS DELIBERATELY ABSENT. Issued shares include those held in
        # treasury; outstanding shares do not. The two names look interchangeable and are not.
        # Found on live data: Booking Holdings read 63-64 million shares (issued) against roughly
        # 32 million actually outstanding, which halved its market capitalisation to $6.5bn and
        # produced a free-cash-flow yield of 140%. Better no share count than the wrong one.
        "us-gaap": ["CommonStockSharesOutstanding"],
        "ifrs-full": ["NumberOfSharesOutstanding"],
    },

    # ---- cash flow --------------------------------------------------------------------------
    "operating_cash_flow": {
        "us-gaap": [
            "NetCashProvidedByUsedInOperatingActivities",
            "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations",
        ],
        "ifrs-full": [
            "CashFlowsFromUsedInOperatingActivities",
            "NetCashFlowsFromUsedInOperatingActivities",
        ],
    },
    "capex": {
        "us-gaap": [
            "PaymentsToAcquirePropertyPlantAndEquipment",
            "PaymentsToAcquireProductiveAssets",
            "PaymentsForCapitalImprovements",
        ],
        "ifrs-full": [
            "PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities",
            "PurchaseOfPropertyPlantAndEquipmentIntangibleAssetsOtherThanGoodwillInvestmentPropertyAndOtherNoncurrentAssets",
        ],
    },
    # The three capital-allocation concepts. This whole 10% category scored 0% before Build B
    # because none of these tags was requested.
    "buybacks": {
        # Wider than dividends and checked more strictly before any nil is inferred, because a
        # repurchase can legitimately appear under several different concepts and "absent from
        # the one tag I read" is not evidence that a company bought nothing back.
        "us-gaap": [
            "PaymentsForRepurchaseOfCommonStock",
            "PaymentsForRepurchaseOfEquity",
            "PaymentsForRepurchaseOfRedeemableConvertiblePreferredStock",
            "TreasuryStockValueAcquiredCostMethod",
            "TreasuryStockValueAcquiredParValueMethod",
        ],
        "ifrs-full": ["PaymentsToAcquireOrRedeemEntitysShares", "PurchaseOfTreasuryShares"],
    },
    # THE CHAIN LENGTH IS THE POINT FOR THESE TWO. A nil is only ever inferred after every
    # supported concept has been positively checked and found absent, so "we looked everywhere we
    # know how to look" has to actually mean everywhere.
    "dividends_paid": {
        "us-gaap": [
            "PaymentsOfDividendsCommonStock",
            "PaymentsOfDividends",
            "PaymentsOfOrdinaryDividends",
            "PaymentsOfDividendsPreferredStockAndPreferenceStock",
            "PaymentsOfDistributionsToAffiliates",
        ],
        "ifrs-full": ["DividendsPaidClassifiedAsFinancingActivities", "DividendsPaid",
                      "DividendsPaidOrdinaryShares"],
    },
    "acquisitions": {
        "us-gaap": [
            "PaymentsToAcquireBusinessesNetOfCashAcquired",
            "PaymentsToAcquireBusinessesGross",
        ],
        "ifrs-full": [
            "CashFlowsUsedInObtainingControlOfSubsidiariesOrOtherBusinessesClassifiedAsInvestingActivities",
        ],
    },

    # ---- balance sheet (instant facts — no `start`, no duration filter) ----------------------
    "total_assets": {
        "us-gaap": ["Assets"],
        "ifrs-full": ["Assets"],
    },
    "current_assets": {
        "us-gaap": ["AssetsCurrent"],
        "ifrs-full": ["CurrentAssets"],
    },
    "current_liabilities": {
        "us-gaap": ["LiabilitiesCurrent"],
        "ifrs-full": ["CurrentLiabilities"],
    },
    "total_liabilities": {
        "us-gaap": ["Liabilities"],
        "ifrs-full": ["Liabilities"],
    },
    "total_cash": {
        "us-gaap": [
            "CashAndCashEquivalentsAtCarryingValue",
            "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents",
        ],
        "ifrs-full": ["CashAndCashEquivalents"],
    },
    "stockholders_equity": {
        "us-gaap": [
            "StockholdersEquity",
            "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest",
        ],
        "ifrs-full": ["EquityAttributableToOwnersOfParent", "Equity"],
    },

    # ---- debt components --------------------------------------------------------------------
    # Kept as separate concepts rather than one "total debt" tag because companies split debt
    # between current and non-current portions and no single tag holds the total for everyone.
    # They are summed per period by the provider, never across periods.
    "debt_noncurrent": {
        "us-gaap": ["LongTermDebtNoncurrent"],
        "ifrs-full": ["NoncurrentPortionOfNoncurrentBorrowings", "NoncurrentBorrowings"],
    },
    "debt_current": {
        "us-gaap": ["LongTermDebtCurrent"],
        "ifrs-full": ["CurrentPortionOfNoncurrentBorrowings", "ShorttermBorrowings"],
    },
    "debt_total_reported": {
        "us-gaap": ["LongTermDebt", "DebtLongtermAndShorttermCombinedAmount"],
        "ifrs-full": ["Borrowings"],
    },
}

# The taxonomys this app understands, in the order they are tried when deciding which one a
# company files under. A company that uses neither gets no fundamentals — which is correct, and
# visible, rather than an empty score presented as a real one.
TAXONOMIES = ("us-gaap", "ifrs-full")

# The concept whose coverage decides the taxonomy. Revenue is the right choice because every
# operating company reports it under both standards, so "which namespace has more annual revenue
# periods" is a reliable answer to "which standard does this company file under".
TAXONOMY_ANCHOR = "revenue"

# The stored, per-period record. THIS TUPLE IS THE SOURCE OF TRUTH for the fundamentals_history
# table's value columns — a test asserts the schema matches it, so adding a concept here without
# adding the column fails the suite rather than silently dropping the value at write time.
HISTORY_VALUE_FIELDS = (
    "revenue",
    "gross_profit",
    "cost_of_revenue",
    "costs_and_expenses",
    "operating_expenses",
    "pretax_income",
    "nonoperating_income_expense",
    "operating_income",
    "net_income",
    "rnd_expense",
    "interest_expense",
    "depreciation_amortisation",
    "eps_diluted",
    "eps_basic",
    "diluted_shares",
    "basic_shares",
    "shares_outstanding",
    "operating_cash_flow",
    "capex",
    "buybacks",
    "dividends_paid",
    "acquisitions",
    "total_assets",
    "current_assets",
    "current_liabilities",
    "total_liabilities",
    "total_cash",
    "stockholders_equity",
    "total_debt",
)


def namespaces_for(concept: str, taxonomy: str) -> tuple:
    """Which XBRL namespaces a concept is read from, in priority order: any declared preference
    first (see NAMESPACE_PREFERENCE), then the company's own detected taxonomy."""
    preferred = NAMESPACE_PREFERENCE.get(concept, ())
    return preferred + ((taxonomy,) if taxonomy not in preferred else ())


def tags_for(concept: str, taxonomy: str) -> list:
    """The ordered (namespace, tag) chain for one concept. Earlier entries win where two report
    the same period. Unknown pairs yield nothing rather than raising, so a concept that simply
    doesn't exist in a taxonomy is absent, not an error."""
    by_namespace = CONCEPTS.get(concept) or {}
    out = []
    for namespace in namespaces_for(concept, taxonomy):
        for tag in by_namespace.get(namespace) or []:
            out.append((namespace, tag))
    return out


def unit_kind(concept: str) -> str:
    return CONCEPT_UNIT_KIND.get(concept, UNIT_CURRENCY)


def is_duration(concept: str) -> bool:
    return concept in DURATION_CONCEPTS
