"""
B2 hardening — operating profit, evidence-based nil, assets, run resilience, look-ahead.

Five separate concerns, one file, because they were one instruction: make the data correct rather
than plentiful. The rule every class here enforces in its own way is that a value is never forced
to improve coverage. UNKNOWN is a good answer and is often the right one.
"""
import sys
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
import requests  # noqa: E402
from config import STOCK_UNIVERSE  # noqa: E402
from providers.base import ProviderError  # noqa: E402
from providers.edgar_concepts import HISTORY_VALUE_FIELDS  # noqa: E402
from providers.fundamentals_base import AnnualPeriod  # noqa: E402
from providers.sec_edgar_provider import SecEdgarProvider  # noqa: E402
from services import data_validation_service as dv  # noqa: E402
from services import fundamentals_history_service as fh  # noqa: E402
from services import operating_profit as op  # noqa: E402

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]))
    conn.commit()
    return conn


def period(period_end, filed, ticker="AAPL", currency="USD", **values):
    full = {f: None for f in HISTORY_VALUE_FIELDS}
    full.update(values)
    return AnnualPeriod(ticker=ticker, source="test", period_end=period_end, filed=filed,
                        taxonomy="us-gaap", currency=currency, form="10-K", values=full)


def store(db, ticker, periods):
    for p in periods:
        p.ticker = ticker
    fh.store_history(db, ticker, periods)


# =============================================================================================
# 1. OPERATING PROFIT
# =============================================================================================

class OperatingProfitIsReconciledNotAssumed(unittest.TestCase):
    """Eli Lilly does not print an operating income subtotal — its statement runs revenue → costs
    → income before taxes. Seven metrics hang off operating profit, so one absent line emptied
    three of the six Company Health categories.

    THE DERIVATION FIRST PROPOSED WAS WRONG and these tests pin the corrected one. Pre-tax income
    plus interest expense is NOT operating profit: pre-tax income already contains investment
    income, disposals, foreign-exchange swings and one-off settlements, so adding back only
    interest leaves all of those inside — silently, and in the flattering direction.
    """

    def test_a_reported_operating_income_is_always_used_unchanged(self):
        got = op.reconcile({"revenue": 1000.0, "operating_income": 250.0,
                            "costs_and_expenses": 900.0})
        self.assertEqual(got["value"], 250.0)
        self.assertEqual(got["basis"], op.REPORTED)

    def test_route_a_revenue_less_total_costs(self):
        """The cleanest route because it assumes nothing — the company states the total itself."""
        got = op.reconcile({"revenue": 1000.0, "costs_and_expenses": 780.0})
        self.assertEqual(got["value"], 220.0)
        self.assertIn("total costs", got["basis"])

    def test_route_b_gross_profit_less_operating_expenses(self):
        got = op.reconcile({"revenue": 1000.0, "operating_expenses": 180.0}, gross_profit=400.0)
        self.assertEqual(got["value"], 220.0)
        self.assertIn("operating expenses", got["basis"])

    def test_route_c_removes_the_whole_non_operating_aggregate_not_just_interest(self):
        """Pre-tax 200 with a reported +60 of non-operating income is an operating profit of 140.
        The原 proposal would have produced 200 + interest, which is larger than the truth and
        wrong in the direction that flatters."""
        got = op.reconcile({"revenue": 1000.0, "pretax_income": 200.0,
                            "nonoperating_income_expense": 60.0, "interest_expense": 25.0})
        self.assertEqual(got["value"], 140.0)
        self.assertIn("non-operating", got["basis"])

    def test_route_c_is_refused_when_the_non_operating_aggregate_is_absent(self):
        """THE CORRECTION, ASSERTED. Without the aggregate there is no way to know what else is
        sitting inside pre-tax income, so the walk is not attempted at all."""
        got = op.reconcile({"revenue": 1000.0, "pretax_income": 200.0, "interest_expense": 25.0})
        self.assertIsNone(got["value"])
        skipped = [c for c in got["checked"] if "pre-tax" in c["route"]]
        self.assertTrue(skipped)
        self.assertIn("investment income", skipped[0]["why_not"])

    def test_a_reconciliation_larger_than_revenue_is_rejected(self):
        got = op.reconcile({"revenue": 1000.0, "costs_and_expenses": -500.0})
        self.assertIsNone(got["value"])
        self.assertTrue(got["rejected"])

    def test_a_reconciliation_larger_than_gross_profit_is_rejected(self):
        """Operating expenses cannot be negative in aggregate, so an operating profit above gross
        profit means one of the two inputs is measuring something else."""
        got = op.reconcile({"revenue": 1000.0, "costs_and_expenses": 200.0}, gross_profit=400.0)
        self.assertIsNone(got["value"])
        self.assertIn("exceeds gross profit", got["rejected"][0]["why"])

    def test_two_routes_that_disagree_produce_unknown_rather_than_a_choice(self):
        """Picking the more flattering of two contradictory reconciliations is exactly how a
        wrong number acquires a confident label."""
        got = op.reconcile({"revenue": 1000.0, "costs_and_expenses": 800.0,
                            "operating_expenses": 100.0}, gross_profit=400.0)
        self.assertIsNone(got["value"])
        self.assertIsNone(got["basis"])
        self.assertIn("disagree", got["note"])

    def test_two_routes_that_agree_are_reported_as_corroborated(self):
        got = op.reconcile({"revenue": 1000.0, "costs_and_expenses": 800.0,
                            "operating_expenses": 200.0}, gross_profit=400.0)
        self.assertEqual(got["value"], 200.0)
        self.assertIn("agree", got["note"])

    def test_nothing_to_reconcile_from_is_unknown_and_says_so(self):
        got = op.reconcile({"revenue": 1000.0})
        self.assertIsNone(got["value"])
        self.assertIn("Left UNKNOWN rather than forced", got["note"])

    def test_ebitda_is_unknown_when_operating_profit_is(self):
        self.assertIsNone(op.ebitda(None, 100.0))
        self.assertIsNone(op.ebitda(200.0, None))
        self.assertEqual(op.ebitda(200.0, 100.0), 300.0)


class DerivedOperatingProfitFlowsThroughAndIsLabelled(unittest.TestCase):

    def _lilly_shaped(self):
        """Lilly's actual shape: revenue and costs present, no operating income subtotal."""
        db = make_db()
        store(db, "LLY", [period("2025-12-31", "2026-02-12", ticker="LLY",
                                 revenue=65_179e6, cost_of_revenue=13_000e6,
                                 costs_and_expenses=45_000e6, net_income=12_000e6,
                                 depreciation_amortisation=1_997e6, interest_expense=895e6,
                                 stockholders_equity=26_535e6, total_debt=40_868e6,
                                 total_cash=3_000e6, current_assets=55_629e6,
                                 current_liabilities=35_228e6, total_assets=90_000e6,
                                 operating_cash_flow=15_000e6, capex=5_000e6)])
        return db

    def test_the_dependent_metrics_come_back_once_operating_profit_is_reconciled(self):
        out = dv.validate_ticker(self._lilly_shaped(), "LLY", price=900.0)
        for name in ("operating_margin_pct", "roic_pct", "net_debt_to_ebitda",
                     "interest_coverage"):
            self.assertIn(out["metrics"][name]["verdict"], dv.USABLE, name)

    def test_every_one_of_them_is_marked_derived_rather_than_reported(self):
        out = dv.validate_ticker(self._lilly_shaped(), "LLY", price=900.0)
        self.assertEqual(out["metrics"]["operating_margin_pct"]["verdict"], dv.DERIVED)
        self.assertIn("operating_income", out["derived"])
        self.assertIn("derived", out["operating_income_basis"])

    def test_the_routes_that_were_tried_are_all_visible(self):
        """So a derived figure can be argued with rather than merely accepted."""
        out = dv.validate_ticker(self._lilly_shaped(), "LLY", price=900.0)
        self.assertTrue(out["operating_income_routes"])
        self.assertTrue(any(r.get("used") for r in out["operating_income_routes"]))

    def test_an_irreconcilable_company_leaves_all_seven_unknown_rather_than_guessing(self):
        db = make_db()
        store(db, "LLY", [period("2025-12-31", "2026-02-12", ticker="LLY",
                                 revenue=65_179e6, net_income=12_000e6,
                                 pretax_income=14_000e6, interest_expense=895e6)])
        out = dv.validate_ticker(db, "LLY", price=900.0)
        for name in ("operating_margin_pct", "roic_pct", "ev_to_ebit", "net_debt_to_ebitda",
                     "interest_coverage"):
            self.assertEqual(out["metrics"][name]["verdict"], dv.UNAVAILABLE, name)

    def test_a_company_that_reports_operating_income_is_untouched_by_any_of_this(self):
        db = make_db()
        store(db, "MSFT", [period("2025-06-30", "2025-07-30", ticker="MSFT",
                                  revenue=1000e6, operating_income=450e6, gross_profit=700e6,
                                  net_income=380e6)])
        out = dv.validate_ticker(db, "MSFT", price=400.0)
        self.assertEqual(out["operating_income_basis"], "reported")
        self.assertEqual(out["metrics"]["operating_margin_pct"]["verdict"], dv.OK)
        self.assertNotIn("operating_income", out["derived"])


# =============================================================================================
# 2. INFERRED NIL — zero only on positive evidence
# =============================================================================================

class NilRequiresEvidence(unittest.TestCase):
    """The one place the never-turn-missing-into-zero rule is bent, and it is bent narrowly.

    Zero is allowed only where absence is itself evidence: the cash-flow statement is
    demonstrably parsed AND the other financing line is present, proving the financing section
    specifically was read. Otherwise UNKNOWN — because a company with neither line found may have
    paid both and had neither parsed, and those two situations are not the same.
    """

    def _rows(self, **over):
        base = dict(revenue=1000e6, net_income=200e6, operating_cash_flow=250e6, capex=50e6,
                    shares_outstanding=1e9, total_assets=2000e6)
        base.update(over)
        return [period("2024-12-31", "2025-02-01", **base)]

    def test_a_non_payer_with_a_parsed_statement_reads_nil_not_unknown(self):
        db = make_db()
        store(db, "NVDA", self._rows(buybacks=100e6))     # buybacks present -> financing read
        r = dv.validate_ticker(db, "NVDA", price=10.0)["metrics"]["dividend_yield_pct"]
        self.assertEqual(r["verdict"], dv.INFERRED_NIL)
        self.assertEqual(r["value"], 0.0)
        self.assertIn("every supported", r["reason"])

    def test_the_provenance_says_it_was_inferred_never_just_zero(self):
        db = make_db()
        store(db, "NVDA", self._rows(buybacks=100e6))
        r = dv.validate_ticker(db, "NVDA", price=10.0)["metrics"]["dividend_yield_pct"]
        self.assertIn("INFERRED NIL", r["reason"])

    def test_no_financing_line_at_all_means_unknown_for_both(self):
        """The cautious case, and the reason buybacks get the stricter treatment: absence proves
        nothing when we cannot show the financing section was read."""
        db = make_db()
        store(db, "PLTR", self._rows())
        out = dv.validate_ticker(db, "PLTR", price=10.0)
        for metric in ("dividend_yield_pct", "buyback_yield_pct"):
            self.assertEqual(out["metrics"][metric]["verdict"], dv.UNAVAILABLE, metric)
            self.assertIn("could mean nil or could mean unparsed", out["metrics"][metric]["reason"])

    def test_an_unparsed_cash_flow_statement_can_never_produce_a_nil(self):
        db = make_db()
        store(db, "PLTR", self._rows(operating_cash_flow=None, buybacks=100e6))
        r = dv.validate_ticker(db, "PLTR", price=10.0)["metrics"]["dividend_yield_pct"]
        self.assertEqual(r["verdict"], dv.UNAVAILABLE)
        self.assertIn("not fully parsed", r["reason"])

    def test_a_real_dividend_is_reported_as_a_real_number(self):
        db = make_db()
        store(db, "ABBV", self._rows(dividends_paid=50e6, buybacks=10e6))
        r = dv.validate_ticker(db, "ABBV", price=10.0)["metrics"]["dividend_yield_pct"]
        self.assertEqual(r["verdict"], dv.OK)
        self.assertAlmostEqual(r["value"], 0.5, places=4)      # 50m on a 10bn market cap

    def test_a_buyback_company_reports_a_real_buyback_yield(self):
        db = make_db()
        store(db, "AAPL", self._rows(buybacks=90e6, dividends_paid=15e6))
        r = dv.validate_ticker(db, "AAPL", price=10.0)["metrics"]["buyback_yield_pct"]
        self.assertEqual(r["verdict"], dv.OK)
        self.assertAlmostEqual(r["value"], 0.9, places=4)

    def test_there_is_no_global_missing_equals_zero_anywhere(self):
        """A structural guard: the nil inference must stay confined to the two cash-flow lines it
        was authorised for, and must never become a general fallback."""
        source = (Path(__file__).resolve().parent.parent / "services"
                  / "data_validation_service.py").read_text()
        self.assertEqual(source.count("_nil_or_unknown"), 2)   # one definition, one call site


# =============================================================================================
# 3. TOTAL ASSETS — the spec's metrics, now actually computed
# =============================================================================================

class AssetsAreUsed(unittest.TestCase):

    def _two_years(self, **over):
        base = dict(revenue=1000e6, net_income=100e6, operating_cash_flow=140e6, capex=20e6)
        base.update(over)
        return [period("2024-12-31", "2025-02-01", total_assets=1100e6, **base),
                period("2023-12-31", "2025-02-01", total_assets=900e6, **base)]

    def test_return_on_assets_uses_the_average_of_opening_and_closing(self):
        """Net income is earned across a year; a balance sheet is a single instant. Averaging is
        the ordinary treatment and the basis is reported rather than assumed."""
        db = make_db()
        store(db, "AAPL", self._two_years())
        out = dv.validate_ticker(db, "AAPL", price=10.0)
        self.assertEqual(out["metrics"]["roa_pct"]["verdict"], dv.OK)
        self.assertAlmostEqual(out["metrics"]["roa_pct"]["value"], 10.0, places=4)  # 100/1000
        self.assertIn("average", out["assets_basis"])

    def test_a_single_year_falls_back_to_closing_assets_and_says_so(self):
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=1000e6, net_income=100e6,
                                  total_assets=1000e6)])
        out = dv.validate_ticker(db, "AAPL", price=10.0)
        self.assertAlmostEqual(out["metrics"]["roa_pct"]["value"], 10.0, places=4)
        self.assertIn("closing assets only", out["assets_basis"])

    def test_accruals_measure_the_gap_between_profit_and_cash(self):
        """Net income 100, operating cash flow 140, average assets 1000 -> -4%. Negative is the
        healthy direction: cash arrived ahead of reported profit."""
        db = make_db()
        store(db, "AAPL", self._two_years())
        r = dv.validate_ticker(db, "AAPL", price=10.0)["metrics"]["accruals_ratio"]
        self.assertEqual(r["verdict"], dv.OK)
        self.assertAlmostEqual(r["value"], -0.04, places=4)

    def test_accruals_go_positive_when_earnings_run_ahead_of_cash(self):
        """The condition worth catching: profit reported that the cash has not backed up."""
        db = make_db()
        store(db, "AAPL", self._two_years(operating_cash_flow=40e6))
        r = dv.validate_ticker(db, "AAPL", price=10.0)["metrics"]["accruals_ratio"]
        self.assertGreater(r["value"], 0)

    def test_no_assets_means_unknown_for_both_rather_than_zero(self):
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=1000e6, net_income=100e6)])
        out = dv.validate_ticker(db, "AAPL", price=10.0)
        self.assertEqual(out["metrics"]["roa_pct"]["verdict"], dv.UNAVAILABLE)
        self.assertEqual(out["metrics"]["accruals_ratio"]["verdict"], dv.UNAVAILABLE)
        self.assertIsNone(out["assets_basis"])


# =============================================================================================
# 4. MOAT EVIDENCE — independent of growth
# =============================================================================================

class MoatEvidenceIsIndependentOfGrowth(unittest.TestCase):

    def test_revenue_consistency_appears_in_exactly_one_category(self):
        """It used to sit in both Growth & Durability and Moat Evidence, so one measurement
        quietly drove 35% of Company Health."""
        appearances = [name for name, (_w, inputs) in dv.COMPANY_HEALTH_CATEGORIES.items()
                       if "revenue_consistency" in inputs]
        self.assertEqual(appearances, ["growth_durability"])

    def test_moat_evidence_uses_only_independent_measures(self):
        _weight, inputs = dv.COMPANY_HEALTH_CATEGORIES["moat_evidence"]
        self.assertNotIn("revenue_consistency", inputs)
        for expected in ("roic_persistence", "gross_margin_stability",
                         "operating_margin_stability", "revenue_resilience", "rnd_intensity_pct"):
            self.assertIn(expected, inputs)

    def test_resilience_and_consistency_are_genuinely_different_measurements(self):
        """Four good years and one collapse: consistency reads well, resilience reads badly. If
        they moved together, splitting them would be decoration."""
        series = [100, 95, 160, 150, 140]      # newest-first: a 40% fall in the middle
        self.assertGreaterEqual(dv._consistency(series), 50.0)
        self.assertLess(dv._resilience(series), -35.0)

    def test_the_weights_still_sum_to_one_hundred(self):
        self.assertEqual(sum(w for w, _ in dv.COMPANY_HEALTH_CATEGORIES.values()), 100)

    def test_nothing_claims_to_measure_market_share_or_switching_costs(self):
        source = (Path(__file__).resolve().parent.parent / "services"
                  / "data_validation_service.py").read_text().lower()
        for invented in ("market_share", "switching_cost", "customer_concentration"):
            self.assertNotIn(invented, source)


# =============================================================================================
# 5. THE RUN CANNOT HANG — bounded fetch, isolation, resume
# =============================================================================================

class SlowResponsesCannotStopARun(unittest.TestCase):
    """The failure being fixed: a run stopped at ticker fifteen with no error and no log line,
    and forty-nine companies of completed work were discarded.

    `requests`' timeout is per socket operation, so a server sending one byte every nineteen
    seconds never trips a twenty-second timeout. These tests drive exactly that case.
    """

    class _DripResponse:
        """A response that keeps sending, slowly, forever — the shape that hangs."""
        status_code = 200

        def __init__(self, chunk_delay=0.02):
            self.chunk_delay = chunk_delay
            self.closed = False

        def iter_content(self, chunk_size=None):
            while True:
                time.sleep(self.chunk_delay)
                yield b"x" * 16

        def close(self):
            self.closed = True

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            self.close()
            return False

    def test_a_response_that_never_ends_is_abandoned_at_the_deadline(self):
        provider = SecEdgarProvider(total_timeout=0.35)
        provider.MAX_ATTEMPTS = 1
        response = self._DripResponse()
        started = time.monotonic()
        with patch.object(requests, "get", return_value=response):
            with self.assertRaises(ProviderError) as caught:
                provider._get("https://example.invalid/facts.json")
        elapsed = time.monotonic() - started
        self.assertLess(elapsed, 5.0)
        self.assertIn("did not finish sending", str(caught.exception))

    def test_the_connection_is_closed_rather_than_left_running(self):
        """The reason this is not solved with a watchdog thread: abandoning a blocked thread does
        not stop it, and a run that 'recovered' fifty times would be a process with fifty
        orphaned downloads still going."""
        provider = SecEdgarProvider(total_timeout=0.2)
        provider.MAX_ATTEMPTS = 1
        response = self._DripResponse()
        with patch.object(requests, "get", return_value=response):
            with self.assertRaises(ProviderError):
                provider._get("https://example.invalid/facts.json")
        self.assertTrue(response.closed)

    def test_no_watchdog_thread_is_used_for_the_fetch(self):
        source = (Path(__file__).resolve().parent.parent / "providers"
                  / "sec_edgar_provider.py").read_text()
        self.assertNotIn("threading", source)

    def test_an_oversized_response_is_refused_before_it_exhausts_memory(self):
        provider = SecEdgarProvider(total_timeout=30)
        provider.MAX_ATTEMPTS = 1
        provider.MAX_RESPONSE_BYTES = 1000

        class Big:
            status_code = 200

            def iter_content(self, chunk_size=None):
                for _ in range(100):
                    yield b"x" * 512

            def close(self):
                pass

            def __enter__(self):
                return self

            def __exit__(self, *exc):
                return False

        with patch.object(requests, "get", return_value=Big()):
            with self.assertRaises(ProviderError) as caught:
                provider._get("https://example.invalid/facts.json")
        self.assertIn("exceeded", str(caught.exception))

    def test_a_transport_failure_is_retried_but_a_404_is_not(self):
        """A 404 is an answer. Asking three times gets the same answer more slowly."""
        provider = SecEdgarProvider()
        provider.RETRY_BACKOFF_SECONDS = 0
        calls = []

        def flaky(url):
            calls.append(url)
            raise ProviderError("SEC EDGAR did not finish sending within 90s")

        with patch.object(provider, "_get_once", side_effect=flaky):
            with self.assertRaises(ProviderError):
                provider._get("https://example.invalid/x")
        self.assertEqual(len(calls), provider.MAX_ATTEMPTS)

        calls.clear()

        def missing(url):
            calls.append(url)
            raise ProviderError("SEC EDGAR has no record at that URL (404).")

        with patch.object(provider, "_get_once", side_effect=missing):
            with self.assertRaises(ProviderError):
                provider._get("https://example.invalid/x")
        self.assertEqual(len(calls), 1)

    def test_a_retry_that_eventually_succeeds_returns_the_data(self):
        provider = SecEdgarProvider()
        provider.RETRY_BACKOFF_SECONDS = 0
        attempts = {"n": 0}

        def sometimes(url):
            attempts["n"] += 1
            if attempts["n"] < 2:
                raise ProviderError("connection reset")
            return {"facts": {}}

        with patch.object(provider, "_get_once", side_effect=sometimes):
            self.assertEqual(provider._get("https://example.invalid/x"), {"facts": {}})


class OneBadTickerCannotBlockTheOthers(unittest.TestCase):

    def _client(self):
        import os
        import tempfile
        os.environ["DATABASE_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
        from app import create_app
        return create_app().test_client()

    def test_a_failing_ticker_is_recorded_and_the_loop_continues(self):
        from routers import api_validation as av
        client = self._client()
        with client.application.app_context():
            calls = []

            class Provider:
                def get_fundamentals_history(self, ticker):
                    calls.append(ticker)
                    if ticker == "BAD":
                        raise ProviderError("SEC EDGAR did not finish sending within 90s")
                    return []

            av.SEC_PAUSE_SECONDS = 0
            av.MAX_TICKER_ATTEMPTS = 1
            for ticker in ("AAPL", "BAD", "MSFT"):
                av._process_one(Provider(), 99, ticker, refresh=True)
            self.assertEqual(calls, ["AAPL", "BAD", "MSFT"])

    def test_every_ticker_result_is_written_as_it_finishes_not_at_the_end(self):
        """The reason forty-nine companies were lost: the result only existed in memory until all
        fifty were done."""
        from routers import api_validation as av
        client = self._client()
        with client.application.app_context():
            from db import get_db
            av.SEC_PAUSE_SECONDS = 0

            class Provider:
                def get_fundamentals_history(self, ticker):
                    return []

            av._process_one(Provider(), 77, "AAPL", refresh=True)
            rows = get_db().execute(
                "SELECT ticker, status FROM data_validation_ticker_results WHERE run_id = 77"
            ).fetchall()
            self.assertEqual([dict(r)["ticker"] for r in rows], ["AAPL"])
            self.assertEqual(dict(rows[0])["status"], "complete")

    def test_a_resumed_run_skips_the_tickers_already_completed(self):
        from routers import api_validation as av
        client = self._client()
        with client.application.app_context():
            from db import get_db
            db = get_db()
            db.execute("INSERT INTO data_validation_runs (config_json, status) "
                       "VALUES ('{\"tickers\": [\"AAPL\", \"MSFT\"]}', 'failed')")
            db.commit()
            run_id = int(dict(db.execute(
                "SELECT MAX(id) AS id FROM data_validation_runs").fetchone())["id"])
            av._save_ticker(run_id, "AAPL", "complete", None, 1, 0.1, {"ticker": "AAPL"})
            self.assertEqual(av._completed_tickers(db, run_id), {"AAPL"})

        response = client.post(f"/api/data-validation/runs/{run_id}/resume")
        self.assertEqual(response.status_code, 202)
        self.assertEqual(response.get_json()["already_complete"], 1)
        self.assertEqual(response.get_json()["remaining"], 1)

    def test_a_partial_run_can_still_be_read_rather_than_being_all_or_nothing(self):
        from routers import api_validation as av
        client = self._client()
        with client.application.app_context():
            from db import get_db
            db = get_db()
            db.execute("INSERT INTO data_validation_runs (config_json, status) VALUES ('{}', "
                       "'running')")
            db.commit()
            run_id = int(dict(db.execute(
                "SELECT MAX(id) AS id FROM data_validation_runs").fetchone())["id"])
            av._save_ticker(run_id, "AAPL", "complete", None, 1, 0.1,
                            {"ticker": "AAPL", "clears_75pct_gate": True, "periods": 3,
                             "company_health_coverage_pct": 90, "valuation_coverage_pct": 40,
                             "implausible": [], "anomalies": [], "currency": "USD"})
            av._save_ticker(run_id, "BAD", "failed", "timed out", 2, 90.0, None)

        body = client.get(f"/api/data-validation/runs/{run_id}/table").get_json()
        self.assertEqual(body["count"], 1)
        self.assertEqual(body["failures"][0]["ticker"], "BAD")
        self.assertEqual(body["failures"][0]["error"], "timed out")


# =============================================================================================
# 6. LOOK-AHEAD, ACROSS EVERY NEW CALCULATION
# =============================================================================================

class NoNewCalculationCanSeeTheFuture(unittest.TestCase):
    """Point-in-time is only a guarantee if it holds for every metric, not just the ones it was
    designed for. Each new calculation added in this build is checked against a date on which the
    newest filing did not exist."""

    def _history(self):
        db = make_db()
        store(db, "AAPL", [
            # Filed in 2026 — invisible to any 2025 score.
            period("2025-12-31", "2026-02-01", revenue=2000e6, net_income=300e6,
                   costs_and_expenses=1500e6, total_assets=3000e6, operating_cash_flow=350e6,
                   capex=50e6, eps_diluted=3.0, buybacks=10e6, dividends_paid=5e6),
            period("2024-12-31", "2026-02-01", revenue=1500e6, net_income=200e6,
                   costs_and_expenses=1200e6, total_assets=2500e6, operating_cash_flow=250e6,
                   capex=40e6, eps_diluted=2.0, buybacks=8e6, dividends_paid=4e6),
            # Filed in 2025 — the only view available at a 2025 date.
            period("2024-12-31", "2025-02-01", revenue=1500e6, net_income=200e6,
                   costs_and_expenses=1250e6, total_assets=2500e6, operating_cash_flow=250e6,
                   capex=40e6, eps_diluted=2.0, buybacks=8e6, dividends_paid=4e6),
            period("2023-12-31", "2025-02-01", revenue=1000e6, net_income=120e6,
                   costs_and_expenses=850e6, total_assets=2000e6, operating_cash_flow=150e6,
                   capex=30e6, eps_diluted=1.2, buybacks=6e6, dividends_paid=3e6),
        ])
        return db

    def test_the_newest_fiscal_year_is_absent_entirely_at_an_earlier_date(self):
        out = dv.validate_ticker(self._history(), "AAPL", price=10.0, as_of_filed="2025-06-01")
        self.assertNotIn("2025-12-31", out["period_ends"])

    def test_the_derived_operating_profit_uses_only_the_visible_filing(self):
        """The 2025 filing states costs of 1250; the 2026 filing restates them to 1200. A 2025
        score must reconcile from 1250."""
        out = dv.validate_ticker(self._history(), "AAPL", price=10.0, as_of_filed="2025-06-01")
        self.assertAlmostEqual(out["metrics"]["operating_margin_pct"]["value"],
                               (1500e6 - 1250e6) / 1500e6 * 100, places=4)

    def test_the_same_metric_moves_when_the_later_filing_becomes_visible(self):
        """Proves the cutoff is doing the work rather than the row ordering."""
        later = dv.validate_ticker(self._history(), "AAPL", price=10.0, as_of_filed="2026-06-01")
        self.assertNotAlmostEqual(later["metrics"]["operating_margin_pct"]["value"],
                                  (1500e6 - 1250e6) / 1500e6 * 100, places=4)

    def test_return_on_assets_and_accruals_respect_the_cutoff(self):
        out = dv.validate_ticker(self._history(), "AAPL", price=10.0, as_of_filed="2025-06-01")
        # Average of FY2024 (2500) and FY2023 (2000) assets, with FY2024 net income of 200.
        self.assertAlmostEqual(out["metrics"]["roa_pct"]["value"], 200e6 / 2250e6 * 100, places=4)

    def test_the_eps_chain_respects_the_cutoff(self):
        out = dv.validate_ticker(self._history(), "AAPL", price=10.0, as_of_filed="2025-06-01")
        for link in out["eps_chain"]["links_used"]:
            self.assertLessEqual(link["reported_in_filing"], "2025-06-01")

    def test_the_nil_inference_respects_the_cutoff(self):
        out = dv.validate_ticker(self._history(), "AAPL", price=10.0, as_of_filed="2025-06-01")
        self.assertEqual(out["per_share_comparison_filing"], "2025-02-01")

    def test_a_date_before_every_filing_produces_nothing_rather_than_the_newest_data(self):
        out = dv.validate_ticker(self._history(), "AAPL", price=10.0, as_of_filed="2024-01-01")
        self.assertEqual(out["periods"], 0)
        self.assertFalse(out["clears_75pct_gate"])


if __name__ == "__main__":
    unittest.main()
