"""
Build B2 — does the data actually support v3, and are the numbers it produces possible?

WHY THIS EXISTS RATHER THAN "THE FIELDS ARE POPULATED, SHIP IT"
--------------------------------------------------------------
This project's recurring failure is not missing data. It is CORRECT CODE PRODUCING IMPOSSIBLE
NUMBERS: unadjusted prices, a fundamentals mix-up, a +88,446% backtest return. Every one had
passing tests and a populated field. A report that only counts non-null values would have called
all three healthy.

So three separate jobs, reported separately and never merged into one comforting percentage:

  1. COVERAGE — is the input present, weighted exactly as the v3 spec weights it. Answers "would
     v3 clear its own 75% gate", which is what decides whether Build C can start.
  2. PLAUSIBILITY — could the computed figure be true. Outside a stated bound is IMPLAUSIBLE: a
     bug until proven otherwise.
  3. ANOMALIES — figures that are possible but suspicious. These are WARNINGS THAT PROMPT A LOOK,
     never rejections. A company is not wrong because its price-to-sales is unusual, and throwing
     out real data on an arbitrary threshold is its own kind of error.

FOUR VERDICTS, AND THE DIFFERENCES ARE THE WHOLE POINT
  OK           — computed, inside the bound
  DERIVED      — computed from a reconciliation rather than a reported figure, and labelled so
  IMPLAUSIBLE  — computed, outside the bound. A bug until shown otherwise.
  UNAVAILABLE  — could not be computed, with the reason. NOT a zero, and NOT a statement about
                 the company: "we have no share count" and "the company has no shares" are
                 different claims and only one of them is ever true.

INFERRED NIL is a fifth and narrower thing, used only where absence is itself evidence — see
`_nil_evidence`. It is never the global rule that a missing tag means zero.

CURRENCY. Every price-based metric refuses unless the fundamentals are in USD, because no FX
conversion exists anywhere in this app. The refusal names the currency rather than hiding.

THE STANDARD: correct data and correct calculations, not maximum coverage. Nothing here forces a
value to make a percentage look better.
"""
import logging
from datetime import datetime, timezone

from providers.edgar_concepts import HISTORY_VALUE_FIELDS
from services import eps_chain
from services import fundamentals_history_service as fh
from services import operating_profit as op

logger = logging.getLogger(__name__)

OK = "OK"
DERIVED = "DERIVED"
IMPLAUSIBLE = "IMPLAUSIBLE"
UNAVAILABLE = "UNAVAILABLE"
INFERRED_NIL = "INFERRED NIL"

# Verdicts that mean "we have a usable number". DERIVED counts — a reconciled figure that passed
# validation is a real measurement, and the label exists for transparency, not to demote it.
USABLE = (OK, DERIVED, INFERRED_NIL)

# (low, high) bounds. These separate IMPOSSIBLE from UNUSUAL. They are not opinions about what
# makes a good company: a P/E of 300 is a real stock, a gross margin of 4,000% is a parsing bug.
BOUNDS = {
    "pe_ratio":            (0.0, 500.0),
    "enterprise_value":    (0.0, 1.2e13),
    "ev_to_ebit":          (0.0, 500.0),
    "ev_to_ebitda":        (0.0, 500.0),
    "fcf_yield_pct":       (-50.0, 50.0),
    "gross_margin_pct":    (-100.0, 100.0),
    "operating_margin_pct": (-200.0, 100.0),
    "fcf_margin_pct":      (-200.0, 100.0),
    "net_margin_pct":      (-500.0, 100.0),
    "roic_pct":            (-200.0, 500.0),
    "roe_pct":             (-500.0, 500.0),
    "roa_pct":             (-200.0, 200.0),
    "accruals_ratio":      (-2.0, 2.0),
    "interest_coverage":   (-1000.0, 10000.0),
    "net_debt_to_ebitda":  (-50.0, 50.0),
    "current_ratio":       (0.0, 50.0),
    # Widened deliberately, and the reason is recorded so it does not read as tuning: NVIDIA's
    # FY2024 diluted EPS went from $0.17 to $1.19 — real, reported, about +600%. A 300% ceiling
    # flagged a fact as a fault, and a check that flags real things teaches you to ignore it.
    "revenue_cagr_pct":    (-50.0, 500.0),
    "eps_cagr_pct":        (-100.0, 2000.0),
    "share_change_pct":    (-90.0, 500.0),
    "buyback_yield_pct":   (0.0, 30.0),
    "dividend_yield_pct":  (0.0, 30.0),
    "rnd_intensity_pct":   (0.0, 100.0),
    # NO BOUND ON market_cap. The old $100m-$10tn range was so wide it never fired — Booking's
    # wrong $6.5bn walked straight through it — and a check that never fires is worse than no
    # check, because it looks like one. Market capitalisation is now examined by the anomaly
    # tests below, which compare it against other things we know rather than against a range
    # somebody picked.
}

# ---- anomaly thresholds. WARNINGS, NOT GATES. -----------------------------------------------
# Crossing one of these means "look at this", never "discard this". Legitimate companies sit
# outside all of them: a business between funding rounds can have a bizarre price-to-sales, and
# dual-class or treasury-heavy structures make share counts differ for real accounting reasons.
SHARE_COUNT_DIVERGENCE_WARN = 0.30    # diluted vs outstanding, as a fraction
PRICE_TO_SALES_LOW = 0.05
PRICE_TO_SALES_HIGH = 100.0

# ---------------------------------------------------------------------------------------------
# The v3 spec's weights. Coverage is measured against these because the spec's Gate 4 is expressed
# in them: BUY requires >= 75% coverage, and an unmeasurable component's weight leaves the
# denominator rather than scoring zero.
#
# REVENUE CONSISTENCY APPEARS EXACTLY ONCE. It used to sit in both Growth & Durability and Moat
# Evidence, so one measurement quietly drove 35% of Company Health. It belongs to growth.
# Competitive Strength Evidence now uses genuinely independent measures — and it is named as
# evidence because this system infers competitive strength from a financial footprint. It does
# not measure a moat and does not claim to. Market share, switching costs and customer
# concentration have no source and are not invented.
# ---------------------------------------------------------------------------------------------
COMPANY_HEALTH_CATEGORIES = {
    "profitability_returns": (25, ["gross_margin_pct", "operating_margin_pct", "net_margin_pct",
                                   "roic_pct", "roe_pct", "roa_pct"]),
    "growth_durability":     (20, ["revenue_cagr_pct", "eps_cagr_pct", "revenue_consistency"]),
    "cashflow_quality":      (15, ["fcf_margin_pct", "fcf_to_net_income", "ocf_to_net_income",
                                   "accruals_ratio"]),
    "balance_sheet":         (15, ["net_debt_to_ebitda", "interest_coverage", "current_ratio"]),
    "moat_evidence":         (15, ["roic_persistence", "gross_margin_stability",
                                   "operating_margin_stability", "revenue_resilience",
                                   "rnd_intensity_pct"]),
    "capital_allocation":    (10, ["buyback_yield_pct", "dividend_yield_pct", "share_change_pct"]),
}

VALUATION_METRICS = {
    "forward_pe_vs_history": 7,     # needs analyst estimates — no free source carries them
    "forward_pe_vs_peers":   4,
    "ev_to_ebit":            4,
    "fcf_yield_pct":         6,
    "growth_adjusted_pe":    5,
    "intrinsic_value":       9,     # deliberately not built — see the note where it is reported
}
COMPANY_HEALTH_BUY_GATE = 75.0


def _v(value):
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _div(a, b):
    a, b = _v(a), _v(b)
    if a is None or b in (None, 0):
        return None
    return a / b


def _pct(a, b):
    r = _div(a, b)
    return None if r is None else r * 100.0


def _verdict(name, value, reason_if_missing=None, derived_note=None):
    """One metric's result. Never a bare number — the verdict and the provenance travel with it."""
    if value is None:
        return {"value": None, "verdict": UNAVAILABLE,
                "reason": reason_if_missing or "not reported in the filings this app reads"}
    low, high = BOUNDS.get(name, (float("-inf"), float("inf")))
    if not (low <= value <= high):
        return {"value": round(value, 4), "verdict": IMPLAUSIBLE,
                "reason": f"outside the plausible range {low:g} to {high:g} — treat as a parsing "
                          f"or arithmetic fault until shown otherwise"}
    if derived_note:
        return {"value": round(value, 4), "verdict": DERIVED, "reason": derived_note}
    return {"value": round(value, 4), "verdict": OK, "reason": None}


def _derive_gross_profit(revenue, cost_of_revenue):
    """revenue - cost of revenue, or None when the result cannot be a gross profit.

    The identity is exact; the risk is a cost line narrower than the whole cost of revenue, which
    makes the difference larger than any gross profit could be. Refused in that case — a missing
    margin is a far smaller problem than a margin that looks fine and is not.
    """
    revenue, cost_of_revenue = _v(revenue), _v(cost_of_revenue)
    if revenue is None or cost_of_revenue is None or revenue <= 0:
        return None
    derived = revenue - cost_of_revenue
    if not (-revenue <= derived <= revenue):
        return None
    return derived


def _cagr(latest, earliest, years):
    """Compound annual growth. None when the base is non-positive — a CAGR from a negative
    starting value is not a number that means anything, and producing one anyway is how a
    nonsensical growth rate ends up on a page looking authoritative."""
    latest, earliest = _v(latest), _v(earliest)
    if latest is None or earliest is None or years <= 0:
        return None
    if earliest <= 0 or latest <= 0:
        return None
    return ((latest / earliest) ** (1.0 / years) - 1.0) * 100.0


def _consistency(series):
    """Percentage of year-on-year changes that were positive. Newest-first input.

    The plainest honest measure of durability from annual figures: how often the number went up,
    and nothing more.
    """
    values = [_v(x) for x in series if _v(x) is not None]
    if len(values) < 3:
        return None
    ups = sum(1 for a, b in zip(values, values[1:]) if a > b)
    return ups / (len(values) - 1) * 100.0


def _resilience(series):
    """The WORST year-on-year change in the history, as a percentage. Newest-first input.

    Deliberately a different measurement from consistency, not a rephrasing of it. Consistency
    asks how often revenue rose; resilience asks how far it fell in its worst year. A company
    that grew in four years out of five and collapsed 40% in the fifth scores well on one and
    badly on the other, which is exactly the distinction Competitive Strength Evidence needs and
    the reason revenue consistency no longer appears in two categories at once.
    """
    values = [_v(x) for x in series if _v(x) is not None]
    if len(values) < 3:
        return None
    changes = [(a - b) / abs(b) * 100.0 for a, b in zip(values, values[1:]) if b]
    return min(changes) if changes else None


def _stability(series):
    """Coefficient of variation inverted onto 0-100. A margin held steady for years is the
    financial footprint of a competitive advantage — evidence of one, not a measurement of it."""
    values = [_v(x) for x in series if _v(x) is not None]
    if len(values) < 3:
        return None
    mean = sum(values) / len(values)
    if mean == 0:
        return None
    var = sum((x - mean) ** 2 for x in values) / len(values)
    cv = (var ** 0.5) / abs(mean)
    return max(0.0, min(100.0, (1.0 - cv) * 100.0))


# ---------------------------------------------------------------------------------------------
# INFERRED NIL
# ---------------------------------------------------------------------------------------------
def _nil_evidence(period: dict, kind: str) -> tuple:
    """May an absent cash-flow line be read as zero for this period? Returns (allowed, why).

    NOT a global "missing tag means zero" rule — that would undo the principle this whole project
    is built on. Zero is only permitted where absence is itself positive evidence, which requires
    two things to be true at once:

      * the cash-flow statement was demonstrably parsed for this period — operating cash flow AND
        capital expenditure are both present, so we are not looking at a period where the
        statement simply never came through;
      * the OTHER financing line is present, which proves the financing section specifically was
        read. Without that, absence tells us nothing: a company with no dividends line and no
        buybacks line may have paid both and had neither parsed.

    BUYBACKS ARE HELD TO THE SAME BAR AND THEN SOME, because a repurchase legitimately appears
    under several different concepts. The chain checked for them is deliberately the longer one,
    and "absent from the one tag I happened to read" is never evidence a company bought nothing
    back. Where the evidence is not there, the answer is UNKNOWN.
    """
    ocf, capex = _v(period.get("operating_cash_flow")), _v(period.get("capex"))
    if ocf is None or capex is None:
        return False, ("the cash-flow statement for this period is not fully parsed (operating "
                       "cash flow or capital expenditure is missing), so an absent line is not "
                       "evidence of a nil amount")
    other = "buybacks" if kind == "dividends_paid" else "dividends_paid"
    if _v(period.get(other)) is None:
        return False, (f"neither a dividend nor a share-repurchase line was found, so there is no "
                       f"positive evidence that the financing section was read — absence here "
                       f"could mean nil or could mean unparsed, and those are different")
    return True, (f"INFERRED NIL — the cash-flow statement for this period is present and every "
                  f"supported {kind.replace('_', ' ')} concept was checked; none is reported")


def _nil_or_unknown(period: dict, kind: str, market_cap, no_price_reason):
    """Yield-style metric for a capital-allocation line, with nil inferred only on evidence."""
    raw = _v(period.get(kind))
    if raw is not None:
        return _pct(raw, market_cap), None, no_price_reason
    allowed, why = _nil_evidence(period, kind)
    if allowed:
        return (0.0 if market_cap else None), why, (no_price_reason or why)
    return None, None, why


def validate_ticker(db, ticker: str, price: float | None = None,
                    as_of_filed: str | None = None, years: int = 6) -> dict:
    """Every v3 input for one company: computed, bounded, verdicted and attributed.

    `price` is the latest stored close. When it is absent — or the fundamentals are not in USD —
    every price-based metric reports UNAVAILABLE with the reason rather than being skipped
    silently or computed against a currency it does not belong to.
    """
    ticker = ticker.upper()
    rows = fh.history(db, ticker, as_of_filed=as_of_filed, limit=years)
    out = {
        "ticker": ticker,
        "price": _v(price),
        "as_of_filed": as_of_filed or "today",
        "periods": len(rows),
        "period_ends": [r["period_end"] for r in rows],
        "currency": rows[0]["currency"] if rows else None,
        "taxonomy": rows[0]["taxonomy"] if rows else None,
        "metrics": {},
        "notes": [],
        "anomalies": [],
        "derived": [],
    }
    if not rows:
        out["notes"].append(
            "No stored fundamentals history for this ticker. Nothing below can be computed, and "
            "that is a gap in this app's data — not a statement about the company.")
        out["company_health_coverage_pct"] = 0.0
        out["valuation_coverage_pct"] = 0.0
        out["clears_75pct_gate"] = False
        return out

    latest = rows[0]
    currency = latest.get("currency")
    usd = currency == "USD"
    if not usd:
        out["notes"].append(
            f"Figures are in {currency or 'an unrecorded currency'}. No currency conversion "
            f"exists anywhere in this app, so every metric that multiplies a fundamental by a "
            f"US-dollar share price is reported UNAVAILABLE rather than converted at a guessed "
            f"rate. Ratios that divide {currency} by {currency} are unaffected.")

    g = latest.get
    revenue, net_income = _v(g("revenue")), _v(g("net_income"))
    ocf, capex = _v(g("operating_cash_flow")), _v(g("capex"))
    fcf = (ocf - capex) if (ocf is not None and capex is not None) else None
    equity, debt, cash = _v(g("stockholders_equity")), _v(g("total_debt")), _v(g("total_cash"))
    dna, interest = _v(g("depreciation_amortisation")), _v(g("interest_expense"))
    total_assets = _v(g("total_assets"))

    # ---- gross profit: reported, else the revenue-minus-cost identity ----
    gross_profit = _v(g("gross_profit"))
    out["gross_profit_basis"] = "reported" if gross_profit is not None else None
    if gross_profit is None and revenue:
        derived_gp = _derive_gross_profit(revenue, g("cost_of_revenue"))
        if derived_gp is not None:
            gross_profit = derived_gp
            out["gross_profit_basis"] = "derived: revenue - cost of revenue"
            out["derived"].append("gross_profit")

    # ---- operating profit: reported, else reconciled, else UNKNOWN ----
    resolved_op = op.reconcile(latest, gross_profit=gross_profit)
    op_income = resolved_op["value"]
    out["operating_income_basis"] = resolved_op["basis"]
    out["operating_income_routes"] = resolved_op["checked"]
    if resolved_op["note"]:
        out["notes"].append(resolved_op["note"])
    op_is_derived = bool(resolved_op["basis"]) and resolved_op["basis"] != op.REPORTED
    if op_is_derived:
        out["derived"].append("operating_income")
    op_note = resolved_op["basis"] if op_is_derived else None
    ebitda = op.ebitda(op_income, dna)

    # ---- share count ----
    shares = _v(g("shares_outstanding"))
    shares_basis = "cover-page shares outstanding (dei)"
    if shares is None:
        shares = _v(g("diluted_shares"))
        shares_basis = "weighted-average diluted shares (a full-year average, not a point-in-time count)"
    if shares is None:
        shares_basis = None
    out["shares_basis"] = shares_basis

    price_v = _v(price)
    no_price = ("no share price available" if price_v is None else
                f"fundamentals are in {currency}, not USD" if not usd else None)
    market_cap = (shares * price_v) if (shares and price_v and usd) else None
    ev = ((market_cap + (debt or 0.0) - (cash or 0.0)) if market_cap is not None else None)

    m = out["metrics"]

    # ---- valuation (price x fundamental) ----
    m["market_cap"] = _verdict("market_cap", market_cap,
                               no_price or "no share count in any filing this app reads")
    m["enterprise_value"] = _verdict("enterprise_value", ev,
                                     no_price or "market capitalisation unavailable")
    eps = _v(g("eps_diluted"))
    pe = (price_v / eps) if (price_v and eps and eps > 0 and usd) else None
    m["pe_ratio"] = _verdict(
        "pe_ratio", pe,
        no_price or ("diluted EPS is zero or negative, so a P/E would not be meaningful"
                     if eps is not None and eps <= 0 else "no diluted EPS reported"))
    m["ev_to_ebit"] = _verdict(
        "ev_to_ebit", _div(ev, op_income) if (op_income and op_income > 0) else None,
        no_price or ("operating profit could not be reconciled" if op_income is None
                     else "operating profit is not positive"), op_note)
    m["ev_to_ebitda"] = _verdict(
        "ev_to_ebitda", _div(ev, ebitda) if (ebitda and ebitda > 0) else None,
        no_price or "EBITDA needs an operating profit and depreciation; one is missing", op_note)
    m["fcf_yield_pct"] = _verdict("fcf_yield_pct", _pct(fcf, market_cap),
                                  no_price or "free cash flow needs operating cash flow and capex")

    # ---- profitability (currency-neutral: safe for every filer) ----
    m["gross_margin_pct"] = _verdict(
        "gross_margin_pct", _pct(gross_profit, revenue), None,
        out["gross_profit_basis"] if "derived" in (out["gross_profit_basis"] or "") else None)
    m["operating_margin_pct"] = _verdict(
        "operating_margin_pct", _pct(op_income, revenue),
        "operating profit is not reported and could not be reconciled from the income statement",
        op_note)
    m["net_margin_pct"] = _verdict("net_margin_pct", _pct(net_income, revenue))
    m["fcf_margin_pct"] = _verdict("fcf_margin_pct", _pct(fcf, revenue))
    invested = (equity + (debt or 0.0)) if equity is not None else None
    m["roic_pct"] = _verdict(
        "roic_pct", _pct(op_income, invested) if invested else None,
        "needs an operating profit and shareholders' equity", op_note)
    m["roe_pct"] = _verdict("roe_pct", _pct(net_income, equity) if equity else None)

    # ---- return on assets: the spec asked for it and total assets were being stored unused ----
    # Average assets where two periods are available, because net income is earned across a year
    # while the balance sheet is a single instant. Ending assets otherwise, and the basis is said.
    prior_assets = _v(rows[1].get("total_assets")) if len(rows) > 1 else None
    if total_assets is not None and prior_assets is not None:
        assets_base, assets_note = (total_assets + prior_assets) / 2.0, "average of opening and closing assets"
    else:
        assets_base, assets_note = total_assets, "closing assets only — no prior year available"
    out["assets_basis"] = assets_note if total_assets is not None else None
    m["roa_pct"] = _verdict("roa_pct", _pct(net_income, assets_base) if assets_base else None,
                            "needs net income and total assets")

    # ---- cash-flow quality ----
    m["fcf_to_net_income"] = _verdict("fcf_to_net_income", _div(fcf, net_income)
                                      if (net_income and net_income > 0) else None,
                                      "needs free cash flow and positive net income")
    m["ocf_to_net_income"] = _verdict("ocf_to_net_income", _div(ocf, net_income)
                                      if (net_income and net_income > 0) else None,
                                      "needs operating cash flow and positive net income")
    # Accruals: the gap between reported profit and the cash that arrived, scaled by the assets
    # that produced it. A large positive value means earnings are running ahead of cash, which is
    # the classic early sign of aggressive revenue recognition — the reason the spec asks for it.
    m["accruals_ratio"] = _verdict(
        "accruals_ratio",
        _div((net_income - ocf) if (net_income is not None and ocf is not None) else None,
             assets_base) if assets_base else None,
        "needs net income, operating cash flow and total assets")

    # ---- balance sheet ----
    net_debt = ((debt or 0.0) - (cash or 0.0)) if (debt is not None or cash is not None) else None
    m["net_debt_to_ebitda"] = _verdict(
        "net_debt_to_ebitda", _div(net_debt, ebitda) if (ebitda and ebitda > 0) else None,
        "needs net debt and EBITDA, and EBITDA needs an operating profit", op_note)
    m["interest_coverage"] = _verdict(
        "interest_coverage", _div(op_income, interest) if (interest and interest > 0) else None,
        # Apple stopped tagging interest expense separately after FY2023. That is a real
        # disclosure gap, not a parser fault, and it is left UNKNOWN rather than invented.
        "interest expense is not separately tagged in these filings, and it cannot be safely "
        "derived from anything else that is", op_note)
    m["current_ratio"] = _verdict("current_ratio",
                                  _div(g("current_assets"), g("current_liabilities")))

    # ---- growth and durability ----
    # Revenue is an absolute currency amount, untouched by share splits, so it spans the whole
    # history regardless of which filing each year came from.
    span_years = max(len(rows) - 1, 0)
    m["revenue_cagr_pct"] = _verdict(
        "revenue_cagr_pct", _cagr(revenue, rows[-1].get("revenue"), span_years),
        f"needs at least two annual periods (this ticker has {len(rows)})")

    # PER-SHARE FIGURES ARE NOT. Growth is chained from within-filing links, so no comparison
    # ever crosses a share basis. See services/eps_chain.py for why this is not a split guess.
    all_vintages = fh.history_all_vintages(db, ticker, as_of_filed=as_of_filed)
    chained = eps_chain.chain(all_vintages, years=5, as_of_filed=as_of_filed)
    out["eps_chain"] = chained
    m["eps_cagr_pct"] = _verdict(
        "eps_cagr_pct", chained["value"],
        chained["reason"] or "no usable per-share growth chain",
        chained["basis"] if chained["value"] is not None else None)
    if chained["value"] is not None:
        out["derived"].append("eps_cagr_pct")

    m["revenue_consistency"] = _verdict("revenue_consistency",
                                        _consistency([r.get("revenue") for r in rows]),
                                        "needs at least three annual periods")

    # ---- competitive strength evidence (a financial footprint, never a measured moat) ----
    margins, op_margins = [], []
    for r in rows:
        gp = _v(r.get("gross_profit")) or _derive_gross_profit(r.get("revenue"),
                                                               r.get("cost_of_revenue"))
        margins.append(_pct(gp, r.get("revenue")))
        row_op = op.reconcile(r, gross_profit=gp)["value"]
        op_margins.append(_pct(row_op, r.get("revenue")))
    m["gross_margin_stability"] = _verdict("gross_margin_stability", _stability(margins),
                                           "needs a gross margin in at least three periods")
    m["operating_margin_stability"] = _verdict(
        "operating_margin_stability", _stability(op_margins),
        "needs an operating margin in at least three periods")
    roics = [_pct(op.reconcile(r)["value"],
                  (_v(r.get("stockholders_equity")) or 0) + (_v(r.get("total_debt")) or 0) or None)
             for r in rows]
    m["roic_persistence"] = _verdict("roic_persistence", _stability(roics),
                                     "needs an operating profit and equity in three periods")
    m["revenue_resilience"] = _verdict(
        "revenue_resilience", _resilience([r.get("revenue") for r in rows]),
        "needs at least three annual periods")
    m["rnd_intensity_pct"] = _verdict(
        "rnd_intensity_pct", _pct(g("rnd_expense"), revenue),
        "no research and development expense is separately tagged — normal outside technology "
        "and pharmaceuticals, and NOT the same as spending nothing")

    # ---- capital allocation, with nil inferred only on positive evidence ----
    for line, metric in (("buybacks", "buyback_yield_pct"), ("dividends_paid", "dividend_yield_pct")):
        value, nil_note, reason = _nil_or_unknown(latest, line, market_cap, no_price)
        m[metric] = _verdict(metric, value, reason)
        if nil_note and value is not None:
            m[metric]["verdict"] = INFERRED_NIL
            m[metric]["reason"] = nil_note
            out["derived"].append(metric)

    # Dilution: same split problem as EPS, same fix — one filing, one basis.
    vintage_rows = [r for r in rows if r.get("filed") == latest.get("filed")]
    out["per_share_comparison_filing"] = latest.get("filed")
    out["per_share_comparison_years"] = len(vintage_rows)
    oldest_shares = (vintage_rows[-1].get("diluted_shares")
                     or vintage_rows[-1].get("shares_outstanding")) if vintage_rows else None
    newest_shares = g("diluted_shares") or g("shares_outstanding")
    m["share_change_pct"] = _verdict(
        "share_change_pct",
        _pct((_v(newest_shares) - _v(oldest_shares)), oldest_shares)
        if (len(vintage_rows) >= 2 and _v(newest_shares) is not None and _v(oldest_shares))
        else None,
        f"per-share figures can only be compared within one filing (a split rewrites them), and "
        f"the filing of {latest.get('filed')} covers {len(vintage_rows)} year(s)")

    # ---- the remaining valuation components ----
    peg = None
    if (m["pe_ratio"]["verdict"] in USABLE and m["eps_cagr_pct"]["verdict"] in USABLE
            and (m["eps_cagr_pct"]["value"] or 0) > 0):
        peg = m["pe_ratio"]["value"] / m["eps_cagr_pct"]["value"]
    m["growth_adjusted_pe"] = _verdict(
        "growth_adjusted_pe", peg,
        "needs a positive P/E and a positive EPS growth rate; one is missing or negative")
    m["forward_pe_vs_history"] = _verdict(
        "forward_pe_vs_history", None,
        "needs forward analyst EPS estimates. No source this app reads carries them, so this is "
        "permanently unavailable unless an estimates provider is added.")
    m["forward_pe_vs_peers"] = _verdict(
        "forward_pe_vs_peers", None,
        "needs forward estimates for genuine sector peers. The other 49 tickers are not a sector.")
    m["intrinsic_value"] = _verdict(
        "intrinsic_value", None,
        "NOT BUILT, by decision. A discounted cash flow is dominated by three subjective "
        "assumptions — growth, discount rate and terminal value — and can look authoritative "
        "while being arbitrary. Lower valuation coverage containing reliable measurements is "
        "preferred to higher coverage containing a weak DCF. This 9% is NOT redistributed.")

    # ---- anomalies: suspicion, never rejection ----
    _add_anomalies(out, m, latest, price_v, market_cap, revenue, shares, usd)

    # ---- cross-check that names its own cause ----
    if (gross_profit is not None and revenue is not None and revenue > 0
            and gross_profit > revenue):
        out["notes"].append(
            f"Reported gross profit ({gross_profit:,.0f}) exceeds reported revenue "
            f"({revenue:,.0f}), which is impossible. The revenue tag has almost certainly "
            f"captured only part of the top line — lease, interest or royalty income excluded — "
            f"so every margin, growth rate and valuation multiple for this company is suspect.")

    # ---- coverage, weighted as the spec weights it ----
    health, categories = 0.0, {}
    for name, (weight, inputs) in COMPANY_HEALTH_CATEGORIES.items():
        have = sum(1 for i in inputs if m.get(i, {}).get("verdict") in USABLE)
        share = have / len(inputs)
        categories[name] = {"weight": weight, "inputs": len(inputs), "available": have,
                            "coverage_pct": round(share * 100, 1),
                            "missing": [i for i in inputs
                                        if m.get(i, {}).get("verdict") not in USABLE]}
        health += weight * share
    out["company_health_categories"] = categories
    out["company_health_coverage_pct"] = round(health, 1)
    out["clears_75pct_gate"] = health >= COMPANY_HEALTH_BUY_GATE

    val = sum(w for n, w in VALUATION_METRICS.items() if m.get(n, {}).get("verdict") in USABLE)
    out["valuation_coverage_pct"] = round(val / sum(VALUATION_METRICS.values()) * 100, 1)
    out["valuation_unavailable"] = [n for n in VALUATION_METRICS
                                    if m.get(n, {}).get("verdict") not in USABLE]

    out["implausible"] = [n for n, r in m.items() if r["verdict"] == IMPLAUSIBLE]
    out["unknown"] = {n: r["reason"] for n, r in m.items() if r["verdict"] == UNAVAILABLE}
    out["fields_never_reported"] = [f for f in HISTORY_VALUE_FIELDS
                                    if all(r.get(f) is None for r in rows)]
    return out


def _add_anomalies(out, m, latest, price, market_cap, revenue, shares, usd):
    """Figures that are possible but worth a second look.

    THE DISTINCTION FROM `implausible` IS DELIBERATE AND LOAD-BEARING. An implausible metric is a
    bug: it could not be true. An anomaly could perfectly well be true — dual-class structures,
    heavy treasury holdings and companies between growth phases all sit outside these thresholds
    legitimately. So nothing here rejects data or removes a metric from coverage. It raises a
    hand, names the numbers, and leaves the judgement to a person.
    """
    diluted = _v(latest.get("diluted_shares"))
    outstanding = _v(latest.get("shares_outstanding"))
    if diluted and outstanding:
        divergence = abs(diluted - outstanding) / outstanding
        if divergence > SHARE_COUNT_DIVERGENCE_WARN:
            out["anomalies"].append({
                "check": "share_count_consistency",
                "severity": "WARNING",
                "detail": (f"diluted shares ({diluted:,.0f}) and shares outstanding "
                           f"({outstanding:,.0f}) differ by {divergence * 100:.0f}%"),
                "why_it_matters": ("these two counts describe the same company, so a large gap "
                                   "usually means one of them is measuring something else — "
                                   "shares ISSUED including treasury stock is the common case, "
                                   "and it halves a market capitalisation. It can also be a "
                                   "legitimate consequence of the company's share structure, so "
                                   "this is a prompt to look, not a reason to discard."),
            })

    if market_cap and revenue and revenue > 0:
        ps = market_cap / revenue
        if ps < PRICE_TO_SALES_LOW or ps > PRICE_TO_SALES_HIGH:
            out["anomalies"].append({
                "check": "price_to_sales",
                "severity": "WARNING",
                "detail": (f"price-to-sales of {ps:.2f} (market cap {market_cap:,.0f} on revenue "
                           f"{revenue:,.0f})"),
                "why_it_matters": ("an extreme multiple is more often a wrong share count or a "
                                   "mis-parsed revenue line than a real valuation — but real "
                                   "companies do trade at extreme multiples, so this is a "
                                   "warning and never a validity gate."),
            })

    # The arithmetic that produced the market cap, restated so it can be checked by eye against
    # an outside source. This is the cross-check that no internal test can replace.
    if market_cap and shares and price:
        out["market_cap_check"] = {
            "shares": shares, "price": price, "market_cap": market_cap,
            "implied_price_per_share": round(market_cap / shares, 4),
            "note": ("market cap = share count x last stored close. If the market cap looks "
                     "wrong, one of these two inputs is wrong — compare both against an outside "
                     "source rather than trusting the product."),
        }


def summarise(results: list) -> dict:
    """The one thing B2 has to answer: can Build C start, and if not, what is stopping it."""
    n = len(results)
    if not n:
        return {"tickers": 0}
    clearing = [r for r in results if r.get("clears_75pct_gate")]
    implausible = {r["ticker"]: r["implausible"] for r in results if r.get("implausible")}
    anomalies = {r["ticker"]: [a["check"] for a in r["anomalies"]]
                 for r in results if r.get("anomalies")}
    derived = {r["ticker"]: sorted(set(r.get("derived") or []))
               for r in results if r.get("derived")}

    missing_counts, unknown_reasons = {}, {}
    for r in results:
        for info in (r.get("company_health_categories") or {}).values():
            for miss in info["missing"]:
                missing_counts[miss] = missing_counts.get(miss, 0) + 1
        for metric, reason in (r.get("unknown") or {}).items():
            unknown_reasons.setdefault(metric, reason)

    return {
        "tickers": n,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "clearing_the_75pct_gate": len(clearing),
        "blocked_by_coverage": n - len(clearing),
        "mean_company_health_coverage_pct": round(
            sum(r.get("company_health_coverage_pct") or 0 for r in results) / n, 1),
        "mean_valuation_coverage_pct": round(
            sum(r.get("valuation_coverage_pct") or 0 for r in results) / n, 1),
        "tickers_with_no_history": [r["ticker"] for r in results if not r.get("periods")],
        "tickers_not_in_usd": [r["ticker"] for r in results
                               if r.get("currency") not in (None, "USD")],
        "tickers_with_implausible_metrics": implausible,
        "tickers_with_anomaly_warnings": anomalies,
        "tickers_using_derived_figures": derived,
        "most_commonly_missing_inputs": sorted(missing_counts.items(), key=lambda kv: -kv[1])[:15],
        "why_each_metric_is_unknown": unknown_reasons,
        "verdict": (
            "READY — coverage clears the gate on enough of the universe for Build C to proceed."
            if len(clearing) >= n * 0.8 and not implausible else
            "NOT READY — see blocked_by_coverage and tickers_with_implausible_metrics. An "
            "implausible metric is a bug to fix before any score consumes it, not a row to skip."),
        "valuation_note": (
            "Valuation coverage is reported separately and deliberately. Removing the 200-day "
            "moving average as a BUY gate makes valuation the load-bearing constraint, and a "
            "weakly populated valuation score must not be allowed to issue BUY verdicts. The "
            "missing forward-estimate and intrinsic-value weights are NOT redistributed."),
    }
