// Yearly page, monthly-buying basis. Deliberately a separate file from yearly.js: the two pages
// answer different questions from different numbers, and sharing a renderer would mean every
// future change to one had to be checked against the other.

let mbData = null;

function mbPct(v) {
  return v === null || v === undefined
    ? `<span class="text-dim">&mdash;</span>`
    : fmtPct(v, 1);
}

function mbMoney(v) {
  return v === null || v === undefined
    ? `<span class="text-dim">&mdash;</span>`
    : Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 });
}

/** One year's cell: the return, plus why it should be discounted if it should. */
function mbYearCell(stat) {
  if (!stat || stat.return_pct === null || stat.return_pct === undefined) {
    return `<td class="text-right"><span class="text-dim">UNAVAILABLE</span>${
      stat && stat.reason ? `<div class="yc-sub text-dim">${stat.reason}</div>` : ""}</td>`;
  }
  // A part-year is flagged on the cell itself rather than only in a footnote. An unflagged
  // seven-month year reads as a bad year for the company instead of a short one.
  const flag = stat.partial
    ? `<div class="yc-sub text-dim">${stat.months} month${stat.months === 1 ? "" : "s"}${
        stat.year_in_progress ? ", in progress" : ""}</div>`
    : "";
  return `<td class="text-right ${pctClass(stat.return_pct)}">${fmtPct(stat.return_pct, 1)}${flag}</td>`;
}

function mbRenderTable(data, rowsIn, headId, bodyId, firstColLabel) {
  const years = data.years_shown || [];
  document.getElementById(headId).innerHTML = [
    `<th>${firstColLabel}</th>`,
    ...years.map((y) => `<th class="text-right">${y}${
      y === data.current_year ? " <span class='yc-flag'>YTD</span>" : ""}</th>`),
    `<th class="text-right">Avg Year %<div class="yc-sub text-dim">complete years only</div></th>`,
  ].join("");

  const colCount = years.length + 2;
  const rows = (rowsIn || []).slice().sort(
    (a, b) => (b.avg_year_pct ?? -9999) - (a.avg_year_pct ?? -9999));

  const tbody = document.getElementById(bodyId);
  if (!rows.length) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="${colCount}">No data.</td></tr>`;
    return;
  }

  tbody.innerHTML = rows.map((r) => {
    const byYear = {};
    (r.years || []).forEach((s) => { byYear[s.year] = s; });

    const nameCell = r.is_etf
      ? `<td>
           <span class="ticker-badge">${r.ticker}</span>
           <div class="company-name">${r.name || ""}${r.listing ? " &middot; " + r.listing : ""}</div>
           <div class="yc-proxy" title="${(r.proxy_note || "").replace(/"/g, "&quot;")}">
             priced via <strong>${r.priced_via}</strong>
             <span class="yc-match ${r.match === "EXACT" ? "yc-match-exact" : "yc-match-approx"}">${
               r.match === "EXACT" ? "same index" : "approximate"}</span>
           </div>
         </td>`
      : `<td><span class="ticker-badge">${r.ticker}</span></td>`;

    const click = r.is_etf ? "" : ` onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'"`;

    return `<tr${click}>
      ${nameCell}
      ${years.map((y) => mbYearCell(byYear[y])).join("")}
      <td class="text-right ${pctClass(r.avg_year_pct)}" style="font-weight:600;">${
        mbPct(r.avg_year_pct)}${
        r.avg_year_pct !== null && r.avg_year_pct !== undefined
          ? `<div class="yc-sub text-dim">${r.avg_year_pct_basis || 0} full year${
              (r.avg_year_pct_basis || 0) === 1 ? "" : "s"}</div>` : ""}</td>
    </tr>`;
  }).join("");
}

function mbRenderTotals(data) {
  const rows = data.totals || [];
  const tbody = document.getElementById("mb-totals");
  tbody.innerHTML = rows.length
    ? rows.map((t) => `<tr>
        <td>${t.year}${t.partial ? ` <span class="yc-flag">partial</span>` : ""}</td>
        <td class="text-right">${t.stocks || 0}</td>
        <td class="text-right">${mbMoney(t.invested)}</td>
        <td class="text-right">${mbMoney(t.value)}</td>
        <td class="text-right ${pctClass(t.return_pct)}" style="font-weight:600;">${
          mbPct(t.return_pct)}</td>
      </tr>`).join("")
    : `<tr class="loading-row"><td colspan="5">No data.</td></tr>`;
}

function mbRenderAll() {
  if (!mbData) return;
  mbRenderTable(mbData, mbData.results, "mb-head", "mb-tbody", "Stock");
  mbRenderTable(mbData, mbData.etfs, "mb-etf-head", "mb-etf-tbody", "ETF");
  mbRenderTotals(mbData);
}

async function loadMonthlyBuying() {
  const msg = document.getElementById("mb-message");
  const btn = document.getElementById("mb-refresh");
  btn.disabled = true;
  msg.innerHTML = `<div class="warn-banner">Loading daily history for every tracked stock. If the Yearly page has not been opened yet the history has to come from Alpaca first, which can take a couple of minutes.</div>`;

  try {
    const data = await apiGet("/api/stocks/monthly-buying");
    if (data.error && !(data.results || []).length) throw new Error(data.error);
    mbData = data;
    msg.innerHTML = "";
    mbRenderAll();
  } catch (e) {
    msg.innerHTML = `<div class="error-banner">${e.message}</div>`;
    document.getElementById("mb-tbody").innerHTML =
      `<tr class="loading-row"><td colspan="9">Could not load.</td></tr>`;
  } finally {
    btn.disabled = false;
  }
}

document.getElementById("mb-refresh").addEventListener("click", loadMonthlyBuying);
loadMonthlyBuying();
