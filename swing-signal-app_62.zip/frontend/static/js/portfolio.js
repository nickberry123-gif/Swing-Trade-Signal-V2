async function postJson(path, body) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data;
}

function money(v) {
  return v === null || v === undefined ? "—" : fmtPrice(v);
}

function moneyGbp(v) {
  return v === null || v === undefined ? "—" : "£" + Number(v).toFixed(2);
}

function renderPortfolio(data) {
  const s = data.summary || {};
  document.getElementById("pf-value").textContent = money(s.total_market_value);
  document.getElementById("pf-value-sub").textContent =
    s.positions_priced !== undefined && s.positions_held !== undefined
      ? `${s.positions_priced} of ${s.positions_held} positions priced`
      : "";
  document.getElementById("pf-cost").textContent = money(s.total_cost_basis);

  const unrealizedEl = document.getElementById("pf-unrealized");
  unrealizedEl.textContent = money(s.total_unrealized_pnl);
  unrealizedEl.className = "st-value " + pctClass(s.total_unrealized_pnl);
  document.getElementById("pf-unrealized-pct").textContent =
    s.total_unrealized_pnl_pct !== null && s.total_unrealized_pnl_pct !== undefined
      ? fmtPct(s.total_unrealized_pnl_pct, 2) : "—";

  const realizedEl = document.getElementById("pf-realized");
  realizedEl.textContent = money(s.total_realized_pnl);
  realizedEl.className = "st-value " + pctClass(s.total_realized_pnl);

  document.getElementById("pf-positions").textContent = s.positions_held ?? "—";

  const tbody = document.getElementById("holdings-tbody");
  const holdings = data.holdings || [];
  if (holdings.length === 0) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="8">No open positions. Record a BUY on the Trades page to start tracking a holding.</td></tr>`;
  } else {
    tbody.innerHTML = holdings.map((h) => `
      <tr onclick="window.location.href='/stocks/${encodeURIComponent(h.ticker)}'">
        <td><span class="ticker-badge">${h.ticker}</span></td>
        <td class="text-right">${Number(h.quantity).toLocaleString(undefined, {maximumFractionDigits: 4})}</td>
        <td class="text-right">${money(h.avg_entry_price)}</td>
        <td class="text-right">${money(h.current_price)}</td>
        <td class="text-right">${money(h.cost_basis)}</td>
        <td class="text-right">${money(h.market_value)}</td>
        <td class="text-right ${pctClass(h.unrealized_pnl)}">${money(h.unrealized_pnl)}${
          h.unrealized_pnl_pct !== null && h.unrealized_pnl_pct !== undefined
            ? ` <span style="font-size:11px;">(${fmtPct(h.unrealized_pnl_pct, 1)})</span>` : ""
        }</td>
        <td>${statusPillHtml(h.price_status === "OK" ? "LIVE" : "UNAVAILABLE")}</td>
      </tr>
    `).join("");
  }

  const warnBox = document.getElementById("portfolio-warnings");
  warnBox.innerHTML = (data.warnings || []).map((w) => `<div class="warn-banner">${w}</div>`).join("");

  const gbpBox = document.getElementById("gbp-display");
  if (data.gbp) {
    gbpBox.innerHTML = `
      <div class="stat-tile"><div class="st-label">Market Value (GBP)</div><div class="st-value">${moneyGbp(data.gbp.total_market_value)}</div></div>
      <div class="stat-tile"><div class="st-label">Cost Basis (GBP)</div><div class="st-value">${moneyGbp(data.gbp.total_cost_basis)}</div></div>
      <div class="stat-tile"><div class="st-label">Unrealised P&amp;L (GBP)</div><div class="st-value ${pctClass(data.gbp.total_unrealized_pnl)}">${moneyGbp(data.gbp.total_unrealized_pnl)}</div></div>
      <div class="stat-tile"><div class="st-label">Realised P&amp;L (GBP)</div><div class="st-value ${pctClass(data.gbp.total_realized_pnl)}">${moneyGbp(data.gbp.total_realized_pnl)}</div></div>
    `;
    document.getElementById("fx-note").innerHTML =
      `Converted at <strong>${data.gbp.rate_used}</strong> USD&rarr;GBP (source: ${data.gbp.rate_source}, set ${fmtTime(data.gbp.rate_as_of)}). ` +
      `This app does not fetch or assume an exchange rate — update the rate below whenever you want the conversion refreshed.`;
    document.getElementById("fx-rate").value = data.gbp.rate_used;
  } else {
    gbpBox.innerHTML = `<div class="text-dim" style="font-size:12.5px;">No USD&rarr;GBP rate set — GBP figures are hidden rather than shown with an assumed rate.</div>`;
  }
}

async function loadPortfolio() {
  try {
    const data = await apiGet("/api/portfolio");
    renderPortfolio(data);
  } catch (e) {
    document.getElementById("portfolio-warnings").innerHTML =
      `<div class="error-banner">Could not load portfolio: ${e.message}</div>`;
  }
}

document.getElementById("fx-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const rate = document.getElementById("fx-rate").value;
  try {
    await postJson("/api/fx", { rate, source: "manual" });
    loadPortfolio();
  } catch (e) {
    document.getElementById("portfolio-warnings").innerHTML =
      `<div class="error-banner">${e.message}</div>`;
  }
});

startPolling(loadPortfolio, 30000);
