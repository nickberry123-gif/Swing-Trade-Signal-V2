/* VALUE — the second pillar. Read-only. Nothing here trades, ranks or recommends.
 *
 * UNAVAILABLE is rendered as the word and its reason, never as a blank cell and never as a dash
 * that could be mistaken for zero. A missing multiple leaves the denominator; it does not score
 * badly. That distinction is the whole difference between "we could not measure this" and
 * "this is expensive", and it has to survive into the display. */
(function () {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  const num = (v, dp) => (v == null || Number.isNaN(v)) ? null : Number(v).toFixed(dp == null ? 1 : dp);

  function cell(part, dp) {
    if (!part || part.status !== 'OK') {
      const why = part && part.reason ? part.reason : 'not available';
      return `<td class="text-dim" title="${esc(why)}">UNAVAILABLE</td>`;
    }
    return `<td>${esc(num(part.value, dp))}</td>`;
  }

  function pctCell(part) {
    if (!part || part.status !== 'OK' || part.percentile == null) return '<td class="text-dim">—</td>';
    const p = part.percentile;
    const colour = p >= 75 ? '#2e7d32' : (p < 25 ? '#c62828' : '');
    return `<td style="${colour ? 'color:' + colour + ';font-weight:600' : ''}">${esc(num(p, 1))}</td>`;
  }

  function verdictCell(v) {
    const colour = { CHEAP: '#2e7d32', EXPENSIVE: '#c62828', FAIR: '' }[v] || '';
    return `<td style="${colour ? 'color:' + colour + ';font-weight:600' : ''}">${esc(v)}</td>`;
  }

  function render(data) {
    $('v-basis').textContent = data.basis || '';
    const v = data.verdicts || {};
    const mc = data.metric_coverage || {};
    $('v-summary').innerHTML = `
      <div><strong>${data.scored}</strong> of <strong>${data.tickers}</strong> scored ·
        <strong>${data.unknown}</strong> UNKNOWN ·
        CHEAP ${v.CHEAP || 0} · FAIR ${v.FAIR || 0} · EXPENSIVE ${v.EXPENSIVE || 0}</div>
      <div class="text-dim" style="margin-top:6px">
        Metric coverage — FCF yield ${mc.fcf_yield_pct || 0}/${data.tickers} ·
        EV/EBIT ${mc.ev_to_ebit || 0}/${data.tickers} ·
        EV/Sales substitute ${mc.ev_to_sales || 0}/${data.tickers} ·
        P/E ${mc.pe_ratio || 0}/${data.tickers}
      </div>
      <div class="text-dim" style="margin-top:6px">
        Observed data floor ${esc(data.data_floor_observed)} ·
        EV/Sales substituted for: ${(data.substitutions || []).join(', ') || 'none'} ·
        Withheld for a post-filing split: ${(data.split_withheld || []).join(', ') || 'none'}
      </div>`;

    const rows = (data.results || []).slice().sort((a, b) => {
      if (a.value == null && b.value == null) return a.ticker.localeCompare(b.ticker);
      if (a.value == null) return 1;
      if (b.value == null) return -1;
      return b.value - a.value;                 // cheapest first
    });

    $('v-tbody').innerHTML = rows.map((r) => {
      const ebit = (r.substitution ? r.ev_to_sales : r.ev_to_ebit) || {};
      const label = r.substitution ? ' <span class="text-dim">(EV/Sales)</span>' : '';
      const notes = (r.notes || []).join(' ');
      return `<tr>
        <td><a href="/stocks/${esc(r.ticker)}">${esc(r.ticker)}</a></td>
        <td><strong>${r.value == null ? '<span class="text-dim">—</span>' : esc(num(r.value, 1))}</strong></td>
        ${verdictCell(r.verdict)}
        ${cell(r.fcf_yield_pct, 2)}
        ${pctCell(r.fcf_yield_pct)}
        ${cell(ebit, 1)}${label ? '' : ''}
        ${pctCell(ebit)}
        ${cell(r.pe_ratio, 1)}
        ${pctCell(r.pe_ratio)}
        <td>${r.coverage ? r.coverage.available + '/' + r.coverage.of : ''}${label}</td>
        <td class="text-dim">${r.history && r.history.years ? esc(r.history.years) + 'y' : '—'}</td>
        <td class="text-dim" style="max-width:340px">${esc(notes)}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="12" class="text-dim">No results.</td></tr>';
  }

  async function load() {
    $('v-tbody').innerHTML = '<tr><td colspan="12" class="text-dim">Loading&hellip;</td></tr>';
    try {
      const res = await fetch('/api/value/universe/all');
      render(await res.json());
    } catch (e) {
      $('v-message').innerHTML = `<div class="card card-pad">Could not load: ${esc(e.message)}</div>`;
    }
  }

  async function refresh() {
    const btn = $('v-refresh');
    btn.disabled = true;
    btn.textContent = 'Fetching (this takes a few minutes)…';
    try {
      const res = await fetch('/api/value/refresh', { method: 'POST' });
      const body = await res.json();
      $('v-message').innerHTML =
        `<div class="card card-pad">Fetched ${body.ok} of ${body.requested}. ` +
        `Observed floor: ${esc((body.observed_floors || []).join(', '))} ` +
        `(expected ${esc(body.expected_floor)}).</div>`;
      await load();
    } catch (e) {
      $('v-message').innerHTML = `<div class="card card-pad">Fetch failed: ${esc(e.message)}</div>`;
    } finally {
      btn.disabled = false;
      btn.textContent = 'Fetch Raw Price History (all 50)';
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    $('v-load').addEventListener('click', load);
    $('v-refresh').addEventListener('click', refresh);
    load();
  });
})();
