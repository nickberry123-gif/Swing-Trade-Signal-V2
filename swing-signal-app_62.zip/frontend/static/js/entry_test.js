// Entry Test page. Runs in a background thread server-side and is polled, exactly like the
// backtest — a synchronous request would exceed the worker timeout and come back as HTML.

const HORIZON_ORDER = ["1 month", "3 months", "6 months", "12 months", "24 months"];

function edgeCell(v) {
  if (v === null || v === undefined) return `<td class="text-right text-dim">&mdash;</td>`;
  // Signed and labelled, so the sign is never carried by colour alone.
  return `<td class="text-right ${pctClass(v)}" style="font-weight:600;">${fmtPct(v, 2)}</td>`;
}

function armCell(arm) {
  if (!arm || arm.mean_pct === null || arm.mean_pct === undefined) {
    return `<td class="text-right text-dim">&mdash;</td>`;
  }
  return `<td class="text-right ${pctClass(arm.mean_pct)}">${fmtPct(arm.mean_pct, 2)}
    <div class="yc-sub text-dim">${arm.entries} entries</div></td>`;
}

function renderOverall(results) {
  const overall = results.overall || {};
  const tbody = document.getElementById("et-overall");
  const rows = HORIZON_ORDER.filter((h) => overall[h]);
  if (!rows.length) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="6">No horizon could be measured.</td></tr>`;
    return;
  }
  tbody.innerHTML = rows.map((h) => {
    const r = overall[h];
    return `<tr>
      <td>${h}</td>
      ${armCell(r.SIGNAL)}
      ${armCell(r.MONTHLY)}
      ${armCell(r.EVERY_DAY)}
      ${edgeCell(r.edge_vs_monthly_pct)}
      <td class="text-right">${r.tickers_compared ?? "&mdash;"}</td>
    </tr>`;
  }).join("");
}

function renderByTicker(results) {
  const per = results.by_ticker || {};
  const tbody = document.getElementById("et-byticker");
  const rows = Object.keys(per)
    .map((t) => {
      const h = (per[t].horizons || {})["12 months"];
      if (!h || !h.SIGNAL || h.SIGNAL.n === 0) return null;
      const diff = h.SIGNAL.mean_pct !== null && h.MONTHLY.mean_pct !== null
        ? Number((h.SIGNAL.mean_pct - h.MONTHLY.mean_pct).toFixed(2)) : null;
      return { ticker: t, sig: h.SIGNAL, mon: h.MONTHLY, diff };
    })
    .filter(Boolean)
    .sort((a, b) => (b.diff ?? -9999) - (a.diff ?? -9999));

  if (!rows.length) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="6">No stock had both signal and monthly entries with a full 12-month forward window.</td></tr>`;
    return;
  }

  tbody.innerHTML = rows.map((r) => `
    <tr onclick="window.location.href='/stocks/${encodeURIComponent(r.ticker)}'">
      <td><span class="ticker-badge">${r.ticker}</span></td>
      <td class="text-right">${r.sig.n}</td>
      <td class="text-right ${pctClass(r.sig.mean_pct)}">${fmtPct(r.sig.mean_pct, 2)}</td>
      <td class="text-right ${pctClass(r.mon.mean_pct)}">${fmtPct(r.mon.mean_pct, 2)}</td>
      ${edgeCell(r.diff)}
      <td class="text-right">${r.sig.positive_pct === null ? "&mdash;" : fmtNum(r.sig.positive_pct, 1) + "%"}</td>
    </tr>`).join("");
}

function renderResults(results) {
  document.getElementById("et-results").style.display = "";

  const v = results.verdict || {};
  const headline = document.getElementById("et-verdict-headline");
  headline.textContent = v.headline || "—";
  // Green only for a result that actually favours the signal; everything else stays neutral so
  // an inconclusive answer never looks like a win.
  headline.className = "quality-score-big " +
    (v.headline === "SOME ADVANTAGE" ? "num-pos"
      : v.headline === "NO ADVANTAGE" ? "num-neg" : "text-dim");
  document.getElementById("et-verdict-detail").textContent = v.detail || "";

  renderOverall(results);
  renderByTicker(results);
  document.getElementById("et-limitations").innerHTML =
    (results.limitations || []).map((l) => `<li>${l}</li>`).join("");
}

document.getElementById("et-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const btn = document.getElementById("et-run-btn");
  const msg = document.getElementById("et-message");
  btn.disabled = true;
  btn.textContent = "Running…";

  const started = Date.now();
  // Server-reported stage. Without it a long run looks identical to a hung one.
  let stage = "";
  const tick = () => {
    const secs = Math.round((Date.now() - started) / 1000);
    msg.innerHTML = `<div class="warn-banner">Entry test running — ${secs}s elapsed. Every signal across five years is recomputed from a truncated slice of history to guarantee no look-ahead, so this takes 1–2 minutes. The run continues on the server whether or not you stay on this page.${stage ? `<br><strong>${stage}</strong>` : ""}</div>`;
  };
  tick();
  const ticker = setInterval(tick, 1000);

  try {
    const res = await fetch("/api/entry-test/run", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        min_score: Number(document.getElementById("et-minscore").value),
        strategy_id: selectedStrategyId("et-strategy"),
      }),
    });
    const contentType = res.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      throw new Error(`Server returned ${res.status} (${contentType || "no content-type"}) instead of JSON — the request likely timed out at the gateway.`);
    }
    const startedRun = await res.json();
    if (startedRun.error) throw new Error(startedRun.error);
    const runId = startedRun.run_id;
    if (!runId) throw new Error("Server did not return a run id.");

    const deadline = Date.now() + 40 * 60 * 1000;
    let run = null;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 10000));
      const poll = await fetch(`/api/entry-test/runs/${runId}`, { headers: { Accept: "application/json" } });
      if (!poll.ok) continue;
      run = await poll.json();
      if (run.progress) stage = run.progress;
      if (run.status && run.status !== "running") break;
    }
    clearInterval(ticker);

    if (!run || run.status === "running") {
      throw new Error("Still running after 40 minutes. Reload shortly — the result is stored on the server when it finishes.");
    }
    if (run.status === "failed") throw new Error(run.error || "The entry test failed on the server.");

    msg.innerHTML = "";
    renderResults(run.results || {});
  } catch (e) {
    clearInterval(ticker);
    msg.innerHTML = `<div class="error-banner">${e.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Run Entry Test";
  }
});

// Show the most recent completed run on load, so the page is not blank after a refresh.
populateStrategySelect("et-strategy");

(async function showLatest() {
  try {
    const list = await apiGet("/api/entry-test/runs");
    const done = (list.runs || []).find((r) => r.status === "complete");
    if (!done) return;
    const run = await apiGet(`/api/entry-test/runs/${done.id}`);
    if (run.results) renderResults(run.results);
  } catch (e) {
    // Nothing to show is not an error worth interrupting the page for.
  }
})();
