// Strategy Lab — create and edit the rule sets the three tests run against.

const COMPONENT_LABELS = {
  long_trend: "Long-term trend",
  short_trend: "Short-term trend",
  momentum: "Momentum",
  rsi_pullback: "RSI pullback",
  volume: "Volume",
  support_resistance: "Support / resistance",
  relative_strength: "Relative strength",
  market_regime: "Market regime",
};

let editingId = null;
let template = null;

async function api(path, method, body) {
  const res = await fetch(path, {
    method: method || "GET",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data;
}

function weightSummary(cfg) {
  // Only the non-zero ones, biggest first — the shape of a strategy is which components it
  // leans on, and listing eight numbers hides that.
  const entries = Object.entries(cfg.weights || {})
    .filter(([, v]) => v > 0)
    .sort((a, b) => b[1] - a[1]);
  if (!entries.length) return `<span class="text-dim">none</span>`;
  return entries.map(([k, v]) =>
    `<span class="sl-chip">${COMPONENT_LABELS[k] || k} ${v}</span>`).join(" ");
}

function filterSummary(cfg) {
  const f = cfg.filters || {};
  const bits = [];
  if (f.require_bull_regime) bits.push("BULL regime only");
  if (f.require_above_sma200) bits.push("above SMA200");
  if (f.max_rsi !== null && f.max_rsi !== undefined) bits.push(`RSI &lt; ${f.max_rsi}`);
  if (f.min_rsi !== null && f.min_rsi !== undefined) bits.push(`RSI &gt; ${f.min_rsi}`);
  return bits.length ? bits.join(", ") : `<span class="text-dim">none</span>`;
}

function exitSummary(cfg) {
  const e = cfg.exits || {};
  const bits = [`max ${e.max_holding_days}d`];
  if (e.profit_target_pct) bits.push(`target ${e.profit_target_pct}%`);
  if (e.exit_on_signal) bits.push("exit on signal loss");
  return bits.join(", ");
}

function renderList(data) {
  const attempts = data.attempts || 0;
  // The attempt count is stated in plain language every time, because "best of N" is the whole
  // reason a search like this produces false winners.
  document.getElementById("sl-attempts").innerHTML = attempts === 0
    ? `No variants tried yet. The baseline is the control &mdash; whatever you build gets compared against it.`
    : `<strong>${attempts} variant${attempts === 1 ? "" : "s"} tried so far.</strong> Whichever looks best is the best of ${attempts}, and the best of ${attempts} random rule sets would also look good. Judge a result against the random-strategy percentile on the Selection Test, not against the baseline alone.`;

  const tbody = document.getElementById("sl-tbody");
  const rows = data.strategies || [];
  tbody.innerHTML = rows.map((s) => {
    const cfg = s.config || {};
    return `<tr>
      <td>
        <strong>${s.name}</strong>
        ${s.is_baseline ? `<span class="yc-flag">baseline &mdash; locked</span>` : ""}
        ${cfg.notes ? `<div class="company-name">${cfg.notes}</div>` : ""}
      </td>
      <td>${weightSummary(cfg)}</td>
      <td class="text-right mono">${cfg.buy_threshold} / ${cfg.strong_buy_threshold}</td>
      <td style="font-size:11.5px;">${filterSummary(cfg)}</td>
      <td style="font-size:11.5px;">${exitSummary(cfg)}</td>
      <td class="text-right">
        <button class="btn btn-secondary sl-dup" data-id="${s.id}" type="button">Duplicate</button>
        ${s.is_baseline ? "" : `
          <button class="btn btn-secondary sl-edit" data-id="${s.id}" type="button">Edit</button>
          <button class="btn btn-secondary sl-del" data-id="${s.id}" type="button">Delete</button>`}
      </td>
    </tr>`;
  }).join("") || `<tr class="loading-row"><td colspan="6">No strategies.</td></tr>`;

  tbody.querySelectorAll(".sl-edit").forEach((b) =>
    b.addEventListener("click", () => openEditor(Number(b.dataset.id), false)));
  tbody.querySelectorAll(".sl-dup").forEach((b) =>
    b.addEventListener("click", () => openEditor(Number(b.dataset.id), true)));
  tbody.querySelectorAll(".sl-del").forEach((b) =>
    b.addEventListener("click", () => removeStrategy(Number(b.dataset.id))));
}

function fillEditor(cfg, duplicate) {
  document.getElementById("sl-name").value = duplicate ? `${cfg.name} (copy)` : cfg.name || "";
  const wrap = document.getElementById("sl-weights");
  wrap.innerHTML = Object.keys(COMPONENT_LABELS).map((k) => `
    <div class="form-field">
      <label for="w-${k}">${COMPONENT_LABELS[k]}</label>
      <input type="number" id="w-${k}" min="0" max="50" step="1" value="${(cfg.weights || {})[k] ?? 0}">
    </div>`).join("");

  document.getElementById("sl-buy").value = cfg.buy_threshold;
  document.getElementById("sl-strong").value = cfg.strong_buy_threshold;

  const f = cfg.filters || {};
  document.getElementById("sl-regime").value = f.require_bull_regime ? "true" : "false";
  document.getElementById("sl-sma200").value = f.require_above_sma200 ? "true" : "false";
  document.getElementById("sl-maxrsi").value = f.max_rsi ?? "";
  document.getElementById("sl-minrsi").value = f.min_rsi ?? "";

  const e = cfg.exits || {};
  document.getElementById("sl-hold").value = e.max_holding_days;
  document.getElementById("sl-target").value = e.profit_target_pct ?? "";
  document.getElementById("sl-exitsignal").value = e.exit_on_signal ? "true" : "false";
}

async function openEditor(id, duplicate) {
  document.getElementById("sl-editor-error").innerHTML = "";
  let cfg;
  if (id === null) {
    cfg = template;
    editingId = null;
  } else {
    const s = await api(`/api/strategies/${id}`);
    cfg = s.config;
    // Duplicating a locked baseline is how you start from it without editing it.
    editingId = duplicate ? null : id;
  }
  fillEditor(cfg, duplicate || id === null);
  document.getElementById("sl-editor-title").textContent =
    editingId ? "Edit Strategy" : "New Strategy";
  document.getElementById("sl-editor").style.display = "";
  document.getElementById("sl-editor").scrollIntoView({ behavior: "smooth" });
}

function readEditor() {
  const num = (id) => {
    const v = document.getElementById(id).value;
    return v === "" ? null : Number(v);
  };
  const weights = {};
  Object.keys(COMPONENT_LABELS).forEach((k) => {
    weights[k] = Number(document.getElementById(`w-${k}`).value || 0);
  });
  return {
    name: document.getElementById("sl-name").value.trim() || "Untitled strategy",
    weights,
    buy_threshold: num("sl-buy"),
    strong_buy_threshold: num("sl-strong"),
    filters: {
      require_bull_regime: document.getElementById("sl-regime").value === "true",
      require_above_sma200: document.getElementById("sl-sma200").value === "true",
      max_rsi: num("sl-maxrsi"),
      min_rsi: num("sl-minrsi"),
    },
    exits: {
      max_holding_days: num("sl-hold"),
      profit_target_pct: num("sl-target"),
      exit_on_signal: document.getElementById("sl-exitsignal").value === "true",
    },
  };
}

async function save() {
  const body = readEditor();
  const errBox = document.getElementById("sl-editor-error");
  if (Object.values(body.weights).every((v) => !v)) {
    errBox.innerHTML = `<div class="error-banner">Every weight is zero, so nothing would ever be scored. Give at least one component some weight.</div>`;
    return;
  }
  try {
    if (editingId) await api(`/api/strategies/${editingId}`, "PUT", body);
    else await api("/api/strategies", "POST", body);
    document.getElementById("sl-editor").style.display = "none";
    await load();
  } catch (e) {
    errBox.innerHTML = `<div class="error-banner">${e.message}</div>`;
  }
}

async function removeStrategy(id) {
  try {
    await api(`/api/strategies/${id}`, "DELETE");
    await load();
  } catch (e) {
    document.getElementById("sl-editor-error").innerHTML =
      `<div class="error-banner">${e.message}</div>`;
  }
}

async function load() {
  try {
    const data = await api("/api/strategies");
    template = data.template;
    renderList(data);
  } catch (e) {
    document.getElementById("sl-tbody").innerHTML =
      `<tr class="loading-row"><td colspan="6">Could not load strategies: ${e.message}</td></tr>`;
  }
}

document.getElementById("sl-new").addEventListener("click", () => openEditor(null, true));
document.getElementById("sl-save").addEventListener("click", save);
document.getElementById("sl-cancel").addEventListener("click", () => {
  document.getElementById("sl-editor").style.display = "none";
});

load();
