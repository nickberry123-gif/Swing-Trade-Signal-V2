async function refreshTopbar() {
  const badge = document.getElementById("market-status-badge");
  if (!badge) return;
  try {
    const status = await apiGet("/api/market/status");
    const meta = dataStatusMeta(status.data_status);
    let sessionText = "";
    if (status.is_open === true) sessionText = " · MARKET OPEN";
    else if (status.is_open === false && status.session) sessionText = ` · ${status.session.replace("_", " ")}`;
    badge.innerHTML = `<span class="dot ${meta.dot}"></span> DATA SOURCE: ALPACA · DATA STATUS: ${meta.label}${sessionText}`;
  } catch (e) {
    badge.innerHTML = `<span class="dot bad"></span> DATA SOURCE: ALPACA · DATA STATUS: UNAVAILABLE (request failed)`;
  }
}

startPolling(refreshTopbar, 15000);
