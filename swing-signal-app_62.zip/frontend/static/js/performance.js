function reliabilityHtml(stats) {
  if (!stats || !stats.sample_size) return `<span class="text-dim">no data</span>`;
  if (stats.meaningful) {
    return `<span class="pill pill-live"><span class="dot ok"></span>MEANINGFUL</span>`;
  }
  return `<span class="pill pill-stale"><span class="dot warn"></span>TOO FEW (${stats.sample_size})</span>`;
}

function statRow(label, horizon, stats) {
  return `
    <tr>
      <td>${label}</td>
      <td class="text-right">${horizon}d</td>
      <td class="text-right">${stats.sample_size}</td>
      <td class="text-right ${pctClass(stats.avg_return_pct)}">${fmtPct(stats.avg_return_pct, 2)}</td>
      <td class="text-right">${stats.win_rate_pct === null || stats.win_rate_pct === undefined ? "—" : fmtNum(stats.win_rate_pct, 1) + "%"}</td>
      <td>${reliabilityHtml(stats)}</td>
    </tr>
  `;
}

function renderPerformance(data) {
  const sp = data.signal_performance || {};
  const tp = data.trade_performance || {};
  const run = data.evaluation_run || {};

  document.getElementById("ps-recorded").textContent = sp.total_signals_recorded ?? "—";
  document.getElementById("ps-evaluated").textContent = sp.total_outcomes_evaluated ?? "—";
  document.getElementById("ps-pending").textContent =
    `${run.pending_time || 0} awaiting time, ${run.pending_price_data || 0} awaiting price data`;

  // Actionable signals by horizon
  const actionable = sp.actionable_by_horizon || {};
  const horizons = sp.horizons || [5, 10, 20];
  const actionableRows = horizons
    .filter((h) => actionable[h])
    .map((h) => {
      const s = actionable[h];
      return `
        <tr>
          <td>${h} trading days</td>
          <td class="text-right">${s.sample_size}</td>
          <td class="text-right ${pctClass(s.avg_return_pct)}">${fmtPct(s.avg_return_pct, 2)}</td>
          <td class="text-right">${s.win_rate_pct === null ? "—" : fmtNum(s.win_rate_pct, 1) + "%"}</td>
          <td class="text-right ${pctClass(s.best_pct)}">${fmtPct(s.best_pct, 2)}</td>
          <td class="text-right ${pctClass(s.worst_pct)}">${fmtPct(s.worst_pct, 2)}</td>
          <td>${reliabilityHtml(s)}</td>
        </tr>`;
    }).join("");
  document.getElementById("actionable-tbody").innerHTML = actionableRows ||
    `<tr class="loading-row"><td colspan="7">No BUY / STRONG BUY signals have completed a horizon yet.</td></tr>`;

  // By label
  const byLabel = sp.by_label || {};
  const labelRows = Object.keys(byLabel).flatMap((label) =>
    Object.keys(byLabel[label]).map((h) => statRow(signalPillHtml(label), h, byLabel[label][h]))
  ).join("");
  document.getElementById("bylabel-tbody").innerHTML = labelRows ||
    `<tr class="loading-row"><td colspan="6">No evaluated signals yet.</td></tr>`;

  // By score band — ordered high to low so the "does score predict outcome?" question reads top-down
  const bands = ["80+", "70-79", "60-69", "50-59", "<50"];
  const byScore = sp.by_score_band || {};
  const scoreRows = bands.filter((b) => byScore[b]).flatMap((b) =>
    Object.keys(byScore[b]).map((h) => statRow(b, h, byScore[b][h]))
  ).join("");
  document.getElementById("byscore-tbody").innerHTML = scoreRows ||
    `<tr class="loading-row"><td colspan="6">Not enough evaluated signals to compare score bands yet.</td></tr>`;

  // Trade performance
  document.getElementById("tp-closed").textContent = tp.closed_trades ?? "—";
  const pnlEl = document.getElementById("tp-pnl");
  pnlEl.textContent = tp.total_realized_pnl !== undefined && tp.total_realized_pnl !== null
    ? fmtPrice(tp.total_realized_pnl) : "—";
  pnlEl.className = "st-value " + pctClass(tp.total_realized_pnl);
  document.getElementById("tp-winrate").textContent =
    tp.win_rate_pct !== undefined && tp.win_rate_pct !== null ? fmtNum(tp.win_rate_pct, 1) + "%" : "—";
  document.getElementById("tp-avg").textContent = fmtPct(tp.avg_return_pct, 2);
  document.getElementById("tp-best").textContent = fmtPct(tp.best_trade_pct, 2);
  document.getElementById("tp-worst").textContent = fmtPct(tp.worst_trade_pct, 2);

  const sales = tp.recent_sales || [];
  document.getElementById("sales-tbody").innerHTML = sales.length
    ? sales.map((s) => `
        <tr>
          <td>${s.trade_date}</td>
          <td><span class="ticker-badge">${s.ticker}</span></td>
          <td class="text-right">${Number(s.quantity).toLocaleString(undefined, {maximumFractionDigits: 4})}</td>
          <td class="text-right">${fmtPrice(s.price)}</td>
          <td class="text-right">${fmtPrice(s.cost_basis)}</td>
          <td class="text-right ${pctClass(s.realized_pnl)}">${fmtPrice(s.realized_pnl)}${
            s.realized_pnl_pct !== null && s.realized_pnl_pct !== undefined
              ? ` <span style="font-size:11px;">(${fmtPct(s.realized_pnl_pct, 1)})</span>` : ""
          }</td>
        </tr>`).join("")
    : `<tr class="loading-row"><td colspan="6">No closed trades yet.</td></tr>`;

  const warnings = [...(sp.warnings || []), ...(tp.warnings || [])];
  document.getElementById("perf-warnings").innerHTML =
    warnings.map((w) => `<div class="warn-banner">${w}</div>`).join("");
}

async function loadPerformance() {
  try {
    const data = await apiGet("/api/performance");
    renderPerformance(data);
  } catch (e) {
    document.getElementById("perf-warnings").innerHTML =
      `<div class="error-banner">Could not load performance data: ${e.message}</div>`;
  }
}

document.getElementById("snapshot-btn").addEventListener("click", async (ev) => {
  const btn = ev.currentTarget;
  btn.disabled = true;
  btn.textContent = "Recording…";
  try {
    const res = await fetch("/api/signal-history/snapshot", {
      method: "POST", headers: { Accept: "application/json" },
    });
    const data = await res.json();
    document.getElementById("perf-warnings").innerHTML =
      `<div class="warn-banner" style="background:var(--green-bg); border-color:var(--green); color:var(--green);">Recorded ${data.snapshotted} signal(s) into history.</div>`;
    loadPerformance();
  } catch (e) {
    document.getElementById("perf-warnings").innerHTML =
      `<div class="error-banner">Snapshot failed: ${e.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Record Today's Signals";
  }
});

loadPerformance();
