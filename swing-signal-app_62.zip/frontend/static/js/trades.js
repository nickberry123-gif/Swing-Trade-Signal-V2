async function apiSend(path, method, body) {
  const res = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data;
}

function showMessage(html) {
  document.getElementById("trade-message").innerHTML = html;
}

async function loadTrades() {
  const tbody = document.getElementById("trades-tbody");
  try {
    const data = await apiGet("/api/trades");
    const trades = data.trades || [];
    document.getElementById("trade-count").textContent =
      trades.length ? `${trades.length} recorded` : "";

    if (trades.length === 0) {
      tbody.innerHTML = `<tr class="loading-row"><td colspan="9">No trades recorded yet. Use the form above after you execute a trade in your brokerage app.</td></tr>`;
      return;
    }

    tbody.innerHTML = trades.map((t) => {
      // A NULL fee is UNKNOWN, not zero. It is excluded from the arithmetic and the row is
      // marked, rather than a missing cost silently reading as no cost.
      const feeKnown = t.fees !== null && t.fees !== undefined;
      const fee = feeKnown ? t.fees : 0;
      const total = t.quantity * t.price + (t.side === "BUY" ? fee : -fee);
      const sideCls = t.side === "BUY" ? "num-pos" : "num-neg";
      return `
        <tr>
          <td>${t.trade_date || "—"}</td>
          <td><span class="ticker-badge">${t.ticker}</span></td>
          <td><span class="${sideCls}" style="font-weight:700;">${t.side}</span></td>
          <td class="text-right">${Number(t.quantity).toLocaleString(undefined, {maximumFractionDigits: 4})}</td>
          <td class="text-right">${fmtPrice(t.price)}</td>
          <td class="text-right">${feeKnown ? fmtPrice(t.fees) : '<span class="text-dim">UNKNOWN</span>'}</td>
          <td class="text-right">${fmtPrice(total)}</td>
          <td class="name-cell">${t.notes ? String(t.notes).replace(/</g, "&lt;") : "—"}</td>
          <td><button class="btn btn-danger" onclick="removeTrade(${t.id})">Delete</button></td>
        </tr>
      `;
    }).join("");
  } catch (e) {
    tbody.innerHTML = `<tr class="loading-row"><td colspan="9">Failed to load trades: ${e.message}</td></tr>`;
  }
}

async function removeTrade(id) {
  try {
    await apiSend(`/api/trades/${id}`, "DELETE");
    showMessage(`<div class="warn-banner">Trade deleted. Holdings recalculated.</div>`);
    loadTrades();
  } catch (e) {
    showMessage(`<div class="error-banner">Could not delete trade: ${e.message}</div>`);
  }
}

document.getElementById("trade-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const payload = {
    ticker: document.getElementById("t-ticker").value,
    side: document.getElementById("t-side").value,
    trade_date: document.getElementById("t-date").value,
    quantity: document.getElementById("t-qty").value,
    price: document.getElementById("t-price").value,
    fees: document.getElementById("t-fees").value || 0,
    notes: document.getElementById("t-notes").value || null,
  };
  try {
    const result = await apiSend("/api/trades", "POST", payload);
    const warnings = (result.warnings || []).map((w) => `<div class="warn-banner">${w}</div>`).join("");
    showMessage(warnings || `<div class="warn-banner" style="background:var(--green-bg); border-color:var(--green); color:var(--green);">Recorded ${payload.side} ${payload.quantity} ${payload.ticker} @ ${fmtPrice(payload.price)}.</div>`);
    document.getElementById("t-qty").value = "";
    document.getElementById("t-price").value = "";
    document.getElementById("t-notes").value = "";
    loadTrades();
  } catch (e) {
    showMessage(`<div class="error-banner">${e.message}</div>`);
  }
});

// Default the date field to today for convenience.
document.getElementById("t-date").value = new Date().toISOString().slice(0, 10);
loadTrades();
