function severityTag(sev) {
  const cls = sev === "URGENT" ? "tag-bearish" : sev === "IMPORTANT" ? "tag-high" : "tag-neutral";
  return `<span class="tag ${cls}">${sev}</span>`;
}

async function post(path) {
  const res = await fetch(path, { method: "POST", headers: { Accept: "application/json" } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data;
}

async function loadAlerts() {
  const box = document.getElementById("alerts-list");
  try {
    const data = await apiGet("/api/alerts");
    const alerts = data.alerts || [];
    if (alerts.length === 0) {
      box.innerHTML = `<div class="text-dim">No alerts. Use "Check For New Alerts" to evaluate the current signals against your holdings.</div>`;
      return;
    }
    box.innerHTML = alerts.map((a) => `
      <div class="news-item" style="${a.acknowledged ? "opacity:0.5;" : ""}">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
          <div>
            <div style="font-size:13px; font-weight:600; color:var(--text-0);">${a.message}</div>
            <div class="news-meta">
              ${severityTag(a.severity)}
              <span class="tag tag-neutral">${(a.alert_type || "").replace(/_/g, " ")}</span>
              ${a.ticker ? `<span class="ticker-badge">${a.ticker}</span>` : ""}
              <span>${fmtTime(a.created_at)}</span>
            </div>
          </div>
          ${a.acknowledged ? `<span class="text-dim" style="font-size:11px;">read</span>`
            : `<button class="btn btn-secondary" style="font-size:11px; padding:4px 10px;" onclick="ackOne(${a.id})">Mark read</button>`}
        </div>
      </div>`).join("");
  } catch (e) {
    box.innerHTML = `<div class="error-banner">Could not load alerts: ${e.message}</div>`;
  }
}

async function ackOne(id) {
  try { await post(`/api/alerts/${id}/acknowledge`); loadAlerts(); }
  catch (e) { document.getElementById("alert-message").innerHTML = `<div class="error-banner">${e.message}</div>`; }
}

document.getElementById("evaluate-btn").addEventListener("click", async (ev) => {
  const btn = ev.currentTarget;
  btn.disabled = true; btn.textContent = "Checking… (may take 30-60s)";
  try {
    const r = await post("/api/alerts/evaluate");
    document.getElementById("alert-message").innerHTML =
      `<div class="warn-banner" style="background:var(--green-bg); border-color:var(--green); color:var(--green);">Evaluation complete — ${r.created} new alert(s).</div>`;
    loadAlerts();
  } catch (e) {
    document.getElementById("alert-message").innerHTML = `<div class="error-banner">${e.message}</div>`;
  } finally { btn.disabled = false; btn.textContent = "Check For New Alerts"; }
});

document.getElementById("ackall-btn").addEventListener("click", async () => {
  try { await post("/api/alerts/acknowledge-all"); loadAlerts(); }
  catch (e) { document.getElementById("alert-message").innerHTML = `<div class="error-banner">${e.message}</div>`; }
});

startPolling(loadAlerts, 60000);
