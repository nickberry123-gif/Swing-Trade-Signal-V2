# Moving to a new database (Neon project, or another provider)

The app stores almost nothing irreplaceable. `market_bars`, `technical_indicators`, `quotes`,
`fundamentals` and `news` are a CACHE of Alpaca and SEC data and rebuild themselves on first
use. Only backtest results and signal history are genuinely lost by switching, and both can be
re-run.

## Steps

1. **Create the database.** In the new Neon project, copy the connection string. It looks like
   `postgresql://USER:PASSWORD@HOST/DBNAME?sslmode=require`.

2. **Set it in Render**, not in the code. Dashboard → your service → Environment →
   `DATABASE_URL`. The password must never appear in a file, a zip, or a chat window.

3. **Deploy.** `init_db()` runs on startup and creates every table from `schema.sql`. There is
   no migration to run and no data to import.

4. **Verify, in this order:**
   - `/health` returns `"status": "ok"` — the app started and reached the database.
   - Open the Dashboard. The first load refetches bars from Alpaca for all 50 tickers, so it is
     slower than usual once. Prices appearing means the cache rebuilt.
   - Open Signals and press **Recompute all 50**. Takes about 90 seconds.

## Which connection string to use

Any of them. `database.py` connects with `prepare_threshold=None`, which disables psycopg's
automatic prepared statements.

That matters because prepared statements live in a database SESSION, and every hosted Postgres
puts a connection pooler in front. In transaction mode a pooler hands your next query to a
different backend session, where the prepared statement does not exist — producing intermittent
"prepared statement does not exist" errors under concurrency, on whichever page is unlucky. The
cost of turning it off is a query-plan cache this app does not need.

## What actually consumed the last 5 GB

Reads, not writes. Neon's free limit is on network transfer OUT of the database. The dashboard
polled every 60 seconds and each poll pulled ~75,000 rows of price history, about 10 MB, roughly
600 MB an hour with one tab open — the monthly allowance in under nine hours.

Measured after the fix in this build: **15.5 MB an hour**, ~97% less. At 1–2 hours a day that is
roughly 0.5–1 GB a month against the 5 GB allowance.

There was never a write problem. There is no streaming ingestion in this app — no WebSocket, no
subscription — and every write is an upsert (`ON CONFLICT (ticker, timeframe, ts) DO UPDATE`),
so refetching the same day overwrites its row rather than appending. The database is about 10 MB.

## Keeping it that way

- Don't leave the dashboard open all day. It polls.
- Backtests read five years instead of 560 days, roughly 8 MB per run. Occasional runs are fine.
- `bars_service.MAX_ROWS_PER_STORE` refuses any single write batch above 2,500 rows, so a bug in
  the fetch path fails loudly instead of writing implausible amounts.
