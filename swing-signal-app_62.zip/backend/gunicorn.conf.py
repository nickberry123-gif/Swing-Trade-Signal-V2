"""
Gunicorn settings.

Gunicorn automatically loads `gunicorn.conf.py` from its working directory, and the Render start
command is `cd backend && gunicorn --bind 0.0.0.0:$PORT app:app` — so this file is picked up
without needing to change that command (there is no Render API to edit a service's start
command).

=== WHY THESE VALUES ===

The defaults took the site down twice.

`timeout` defaults to 30s. Anything slower — a cold cache refetching bars for 24 tickers, or a
backtest — got the worker SIGKILLed mid-request, restarted, and retried, producing a crash loop
that made every page unreachable:

    [CRITICAL] WORKER TIMEOUT (pid:68)
    [ERROR] Worker (pid:68) was sent SIGKILL! Perhaps out of memory?

`# Raised from 300 to 600 when the universe grew from 15 to 50 tickers: a cold cache warms
# them sequentially, and 50 fetches at a few seconds each sat right on the old ceiling.
worker_class` defaults to `sync`, which handles exactly one request at a time per worker. The
backtester runs in a background thread inside the worker process, and under the sync worker that
thread starves request handling. `gthread` lets the background work and incoming requests
interleave, so the site stays responsive while a backtest runs.

Worker count stays at 1 deliberately: Render's free tier has limited memory and pandas/numpy
carry a large per-process footprint, so a second worker risks genuine out-of-memory kills.
Concurrency comes from threads instead.
"""

# Long enough for a cold-cache request or a heavy computation, short enough that a genuinely
# hung worker is still recycled rather than wedging forever.
timeout = 600
graceful_timeout = 30

# Threads, not processes — see the memory note above.
worker_class = "gthread"
workers = 1
threads = 4

# WORKER RECYCLING IS OFF, AND MUST STAY OFF.
#
# This was `max_requests = 400`, to guard against a slow leak in a long-lived process. It killed
# a 22-minute analysis stone dead, and the thing that killed it was the page watching it:
#
#     19:55:20  [66] Autorestarting worker after current request.
#     19:55:21  [66] Worker exiting (pid: 66)
#     19:55:29  [73] Booting worker with pid: 73
#
# Every long analysis runs in a BACKGROUND THREAD inside the worker, and the client polls for
# its status every few seconds. A 22-minute run is roughly 380 status polls plus the market
# ticker — which crosses 400, so gunicorn recycled the worker exactly as instructed and took the
# in-flight computation with it. The run row was left saying 'running' forever, because the
# thread that would have recorded the failure no longer existed.
#
# The longer a run takes, the more polls it generates, so the runs most likely to be killed are
# precisely the expensive ones nobody wants to repeat. A hypothetical slow leak is a far smaller
# problem than that: this instance is on a free plan that sleeps after 15 minutes idle and is
# restarted regularly anyway.
max_requests = 0
max_requests_jitter = 0

accesslog = "-"
errorlog = "-"
loglevel = "info"
