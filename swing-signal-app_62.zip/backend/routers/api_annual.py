"""
Annual-reset backtest routes.

Same background-thread + polling shape as the backtest, and for the same reason: the analysis
scores all 50 tickers on every month-start across five years, which takes minutes. A
synchronous request would be killed by the worker timeout and the client would get an HTML error
page where it expected JSON.
"""
import json
import logging
import threading

from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services.bars_service import BACKTEST_LOOKBACK_DAYS, get_bars_df
from services.annual_backtest_service import run_comparison
from services.job_runner import reap_stale_runs, run_background_job
from services.strategy_service import attempt_count, get_strategy
from services.signals_service import TICKERS

logger = logging.getLogger(__name__)
bp = Blueprint("api_annual", __name__, url_prefix="/api/annual-backtest")


TABLE = "annual_backtest_runs"


def _run_in_background(app, run_id: int, tickers: list, config: dict):
    """Loads bars, computes, saves — each on its own short-lived connection.

    This run is the longest in the app (both frameworks, ~16-19 minutes on the free tier) and was
    the one that exposed the dead-connection bug: it held a connection idle through the whole
    compute and lost the result at the final write. See services/job_runner.py.
    """
    def load(db):
        bars_by_ticker = {}
        needed = list(dict.fromkeys(
            tickers + (["SPY", "QQQ"] if config.get("use_regime", True) else [])))
        for t in needed:
            df, _meta = get_bars_df(db, t, "1Day", lookback_days=BACKTEST_LOOKBACK_DAYS)
            if not df.empty:
                bars_by_ticker[t] = df.reset_index(drop=True)
        if not bars_by_ticker:
            raise RuntimeError("No historical bar data available to analyse.")

        strategy = None
        if config.get("strategy_id"):
            row = get_strategy(db, int(config["strategy_id"]))
            strategy = row["config"] if row else None
        # Read while a connection is open, so the result can carry how many variants have been
        # tried. The bar a result must clear rises with that number.
        config["attempts"] = attempt_count(db)
        return bars_by_ticker, strategy

    def compute(loaded, progress):
        bars_by_ticker, strategy = loaded
        # db is passed as None deliberately: run_comparison never touches it, and passing a live
        # connection here is exactly the mistake this restructure exists to prevent.
        return run_comparison(None, tickers, bars_by_ticker, config, strategy, progress=progress)

    run_background_job(app, table=TABLE, run_id=run_id, label="Annual backtest",
                       load=load, compute=compute)


@bp.get("/runs")
def list_runs():
    db = get_db()
    reap_stale_runs(db, TABLE)
    rows = db.execute(
        "SELECT id, created_at, status, error, progress FROM annual_backtest_runs "
        "ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify({"runs": [dict(r) for r in rows]})


@bp.get("/runs/<int:run_id>")
def get_run(run_id):
    db = get_db()
    reap_stale_runs(db, TABLE)
    row = db.execute(
        "SELECT id, created_at, status, error, progress, config_json, results_json "
        "FROM annual_backtest_runs WHERE id = ?", (run_id,)).fetchone()
    if row is None:
        return jsonify({"error": f"No annual backtest run with id {run_id}"}), 404
    run = dict(row)
    for key in ("config_json", "results_json"):
        if run.get(key):
            try:
                run[key.replace("_json", "")] = json.loads(run[key])
            except (TypeError, ValueError):
                pass
        run.pop(key, None)
    return jsonify(run)


@bp.get("/runs/<int:run_id>/summary")
def get_run_summary(run_id):
    """The same run without the two arrays that dominate its size.

    A completed 50-stock run returns thousands of trades and a row per stock per year. Anything
    reading this endpoint over the network — including me, checking a result for you — hits a
    size limit part-way through `by_year_stock` and never reaches `overall` or `validation`,
    which are the two things that decide whether the rest of the page means anything. Those now
    come back first and small.
    """
    db = get_db()
    reap_stale_runs(db, TABLE)
    row = db.execute(
        "SELECT id, created_at, status, error, progress, config_json, results_json "
        "FROM annual_backtest_runs WHERE id = ?", (run_id,)).fetchone()
    if row is None:
        return jsonify({"error": f"No annual backtest run with id {run_id}"}), 404

    run = dict(row)
    try:
        results = json.loads(run.get("results_json") or "{}")
    except (TypeError, ValueError):
        results = {}
    annual = results.get("annual") or {}

    return jsonify({
        "id": run["id"],
        "created_at": run["created_at"],
        "status": run["status"],
        "error": run["error"],
        # Validation first, deliberately: nothing below it is worth reading if it failed.
        "validation": annual.get("validation"),
        "overall": annual.get("overall"),
        "by_year": annual.get("by_year"),
        "difference": results.get("difference"),
        "continuous": results.get("continuous"),
        "strategy_name": annual.get("strategy_name"),
        "first_tradeable_day": annual.get("first_tradeable_day"),
        "warmup_bars": annual.get("warmup_bars"),
        "tickers_tested": len(annual.get("tickers_tested") or []),
        "tickers_skipped": len(annual.get("tickers_skipped") or {}),
        "trade_count": len(annual.get("trades") or []),
        "limitations": annual.get("limitations"),
        "omitted": ["trades", "by_year_stock"],
    })


@bp.post("/run")
def run():
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca API credentials not configured — no historical bars "
                                 "available to analyse."}), 200

    payload = request.get_json(silent=True) or {}
    tickers = [t for t in (payload.get("tickers") or TICKERS) if t in TICKERS]
    if not tickers:
        return jsonify({"error": "No valid tickers from the tracked universe were requested."}), 400

    config = {
        "use_regime": bool(payload.get("use_regime", True)),
        "max_holding_days": int(payload.get("max_holding_days", 40)),
        "slippage_pct": float(payload.get("slippage_pct", 0.0)),
        "commission_per_trade": float(payload.get("commission_per_trade", 0.0)),
        # Hard-wired off — see routers/api_backtest.py for the measurement behind this.
        "exit_on_signal": False,
        "max_positions": int(payload.get("max_positions") or 0),
        "strategy_id": payload.get("strategy_id"),
    }

    db = get_db()
    run_id = db.insert_returning_id(
        "INSERT INTO annual_backtest_runs (config_json, status) VALUES (?, 'running')",
        (json.dumps(config),))
    db.commit()

    from flask import current_app
    threading.Thread(target=_run_in_background,
                     args=(current_app._get_current_object(), run_id, tickers, config),
                     daemon=True).start()

    return jsonify({"run_id": run_id, "status": "running",
                    "note": "Poll /api/annual-backtest/runs/<id> until status is no longer 'running'."}), 202
