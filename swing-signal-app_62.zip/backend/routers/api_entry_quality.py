"""
Entry-quality experiment routes.

Same background-thread + polling shape as the backtest, and for the same reason: the analysis
recomputes every signal across five years of bars for 50 tickers, which takes minutes. A
synchronous request would be killed by the worker timeout and the client would get an HTML error
page where it expected JSON.
"""
import json
import logging
import threading

from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services.job_runner import reap_stale_runs, run_background_job
from services.bars_service import BACKTEST_LOOKBACK_DAYS, get_bars_df
from services.entry_quality_service import run_entry_quality
from services.strategy_service import get_strategy
from services.signals_service import TICKERS

logger = logging.getLogger(__name__)
bp = Blueprint("api_entry_quality", __name__, url_prefix="/api/entry-test")


TABLE = "entry_quality_runs"


def _run_in_background(app, run_id: int, tickers: list, config: dict):
    """Loads bars, computes, saves — each on its own short-lived connection.

    Never holds a connection across the compute: Neon closes idle connections after a few
    minutes, and a run that outlived that window lost its entire result at the final write.
    See services/job_runner.py for the incident this shape prevents.
    """
    def load(db):
        bars_by_ticker = {}
        needed = list(dict.fromkeys(
            tickers + (["SPY", "QQQ"] if config.get("use_regime", True) else [])))
        for t in needed:
            df, _meta = get_bars_df(db, t, "1Day", lookback_days=BACKTEST_LOOKBACK_DAYS)
            if not df.empty:
                bars_by_ticker[t] = df.reset_index(drop=True)
        if not bars_by_ticker:
            raise RuntimeError("No historical bar data available to analyse.")

        strategy = None
        if config.get("strategy_id"):
            row = get_strategy(db, int(config["strategy_id"]))
            strategy = row["config"] if row else None
        return bars_by_ticker, strategy

    def compute(loaded, progress):
        bars_by_ticker, strategy = loaded
        progress("Analysing {} stocks…".format(len(tickers)))
        return run_entry_quality(bars_by_ticker, tickers, config, strategy)

    run_background_job(app, table=TABLE, run_id=run_id, label="Entry-quality test",
                       load=load, compute=compute)


@bp.get("/runs")
def list_runs():
    db = get_db()
    reap_stale_runs(db, TABLE)
    rows = db.execute(
        "SELECT id, created_at, status, error, progress FROM entry_quality_runs "
        "ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify({"runs": [dict(r) for r in rows]})


@bp.get("/runs/<int:run_id>")
def get_run(run_id):
    db = get_db()
    reap_stale_runs(db, TABLE)
    row = db.execute(
        "SELECT id, created_at, status, error, progress, config_json, results_json "
        "FROM entry_quality_runs WHERE id = ?", (run_id,)).fetchone()
    if row is None:
        return jsonify({"error": f"No entry-quality run with id {run_id}"}), 404
    run = dict(row)
    for key in ("config_json", "results_json"):
        if run.get(key):
            try:
                run[key.replace("_json", "")] = json.loads(run[key])
            except (TypeError, ValueError):
                pass
        run.pop(key, None)
    return jsonify(run)


@bp.post("/run")
def run():
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca API credentials not configured — no historical bars "
                                 "available to analyse."}), 200

    payload = request.get_json(silent=True) or {}
    tickers = [t for t in (payload.get("tickers") or TICKERS) if t in TICKERS]
    if not tickers:
        return jsonify({"error": "No valid tickers from the tracked universe were requested."}), 400

    config = {
        "min_score": float(payload.get("min_score", 0)),
        "use_regime": bool(payload.get("use_regime", True)),
        "strategy_id": payload.get("strategy_id"),
    }

    db = get_db()
    run_id = db.insert_returning_id(
        "INSERT INTO entry_quality_runs (config_json, status) VALUES (?, 'running')",
        (json.dumps(config),))
    db.commit()

    from flask import current_app
    threading.Thread(target=_run_in_background,
                     args=(current_app._get_current_object(), run_id, tickers, config),
                     daemon=True).start()

    return jsonify({"run_id": run_id, "status": "running",
                    "note": "Poll /api/entry-test/runs/<id> until status is no longer 'running'."}), 202
