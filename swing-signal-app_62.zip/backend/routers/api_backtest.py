"""
Phase 7 backtest routes.

A full 5-year backtest recomputes indicators for every bar of every ticker — tens of thousands
of computations, taking one to two minutes. That is far longer than gunicorn's 30-second worker
timeout, which killed the request mid-run and returned an HTML error page (the frontend then
failed to parse it as JSON: "Unexpected token '<'").

So runs execute in a BACKGROUND THREAD: the POST returns a run_id immediately and the client
polls the run until its status leaves 'running'. The request itself finishes in milliseconds and
never trips any timeout.
"""
import json
import logging
import threading

from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services.job_runner import reap_stale_runs, run_background_job
from services.backtest_service import persist_backtest, run_backtest
from services.strategy_service import attempt_count, get_strategy
from services.bars_service import BACKTEST_LOOKBACK_DAYS, get_bars_df
from services.signals_service import TICKERS

logger = logging.getLogger(__name__)
bp = Blueprint("api_backtest", __name__, url_prefix="/api/backtest")


TABLE = "backtest_runs"


def _run_in_background(app, run_id: int, tickers: list, config: dict):
    """Loads bars, computes, persists — each on its own short-lived connection.

    A Flask `g`-scoped connection belongs to the request that created it and is closed when that
    request ends — which happens immediately here — so this thread opens its own. It opens them
    one at a time and never across the compute; see services/job_runner.py for why that matters.
    """
    def load(db):
        bars_by_ticker = {}
        needed = list(dict.fromkeys(
            tickers + (["SPY", "QQQ"] if config.get("use_regime", True) else [])))
        for t in needed:
            df, _meta = get_bars_df(db, t, "1Day", lookback_days=BACKTEST_LOOKBACK_DAYS)
            if not df.empty:
                bars_by_ticker[t] = df.reset_index(drop=True)
        if not bars_by_ticker:
            raise RuntimeError("No historical bar data available to backtest.")

        strategy = None
        if config.get("strategy_id"):
            row = get_strategy(db, int(config["strategy_id"]))
            strategy = row["config"] if row else None
        # Read while a connection is open, so the result can carry how many variants have been
        # tried. The bar a result must clear rises with that number.
        config["attempts"] = attempt_count(db)
        return bars_by_ticker, strategy

    def compute(loaded, progress):
        bars_by_ticker, strategy = loaded
        # run_backtest does not use the db argument; passing None keeps that honest.
        return run_backtest(None, tickers, bars_by_ticker, config, strategy, progress=progress)

    def save(db, result):
        dates = sorted({t["entry_date"] for t in result.get("trades", [])})
        persist_backtest(db, result, dates[0] if dates else None,
                         dates[-1] if dates else None, run_id=run_id)

    run_background_job(app, table=TABLE, run_id=run_id, label="Backtest",
                       load=load, compute=compute, save=save)


@bp.get("/runs")
def list_runs():
    db = get_db()
    reap_stale_runs(db, TABLE)
    rows = db.execute(
        "SELECT id, created_at, strategy_version, tickers, start_date, end_date, total_trades, "
        "win_rate_pct, avg_return_pct, total_return_pct, max_drawdown_pct, status, error, "
        "progress FROM backtest_runs ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify({"runs": [dict(r) for r in rows]})


@bp.get("/runs/<int:run_id>")
def get_run(run_id):
    db = get_db()
    reap_stale_runs(db, TABLE)
    row = db.execute("SELECT * FROM backtest_runs WHERE id = ?", (run_id,)).fetchone()
    if not row:
        return jsonify({"error": "Run not found"}), 404
    run = dict(row)
    try:
        run["results"] = json.loads(run.pop("results_json") or "{}")
    except (TypeError, ValueError):
        run["results"] = {}
    trades = db.execute(
        "SELECT * FROM backtest_trades WHERE run_id = ? ORDER BY entry_date DESC LIMIT 300",
        (run_id,)).fetchall()
    run["trades"] = [dict(t) for t in trades]
    return jsonify(run)


@bp.post("/run")
def run():
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca API credentials not configured — no historical bars "
                                 "available to backtest against."}), 200

    payload = request.get_json(silent=True) or {}
    tickers = [t for t in (payload.get("tickers") or TICKERS) if t in TICKERS]
    if not tickers:
        return jsonify({"error": "No valid tickers from the tracked universe were requested."}), 400

    config = {
        "max_holding_days": int(payload.get("max_holding_days", 40)),
        "slippage_pct": float(payload.get("slippage_pct", 0.0)),
        "commission_per_trade": float(payload.get("commission_per_trade", 0.0)),
        "min_score": float(payload.get("min_score", 0)),
        # HARD-WIRED OFF, and no longer a control.
        #
        # It exited when the score degraded to NO TRADE/AVOID. Measured through this engine,
        # 96.9% of those exits closed at a LOSS averaging -4.65%: the score is built from trend
        # and momentum, so a falling price degrades it until the position is sold. No price
        # threshold, but the behaviour is "sell after it has gone against you" — a stop-loss in
        # effect, and this project's rule is no stop-loss anywhere. It was defaulted ON for
        # every run before this build.
        "exit_on_signal": False,
        "use_regime": bool(payload.get("use_regime", True)),
        # 0 or unset = one slot per tested ticker, which is what every earlier run used.
        "max_positions": int(payload.get("max_positions") or 0),
        "strategy_id": payload.get("strategy_id"),
    }

    db = get_db()
    run_id = db.insert_returning_id(
        "INSERT INTO backtest_runs (strategy_version, tickers, config_json, status) "
        "VALUES (?, ?, ?, 'running')",
        ("v1.0", json.dumps(tickers), json.dumps(config)))
    db.commit()

    from flask import current_app
    thread = threading.Thread(
        target=_run_in_background,
        args=(current_app._get_current_object(), run_id, tickers, config),
        daemon=True)
    thread.start()

    # Returns immediately — the client polls /runs/<id> until status != 'running'.
    return jsonify({"run_id": run_id, "status": "running",
                    "message": "Backtest started. This takes 1-2 minutes for 5 years of data."}), 202
