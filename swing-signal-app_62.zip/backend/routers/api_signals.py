from flask import Blueprint, current_app, jsonify, request

from config import Config
from db import get_db
from services.signal_v2_service import compute_v2_for_ticker, read_v2, start_refresh
from services.signals_service import TICKERS, compute_all_signals, compute_signal_for_ticker

bp = Blueprint("api_signals", __name__, url_prefix="/api/signals")


@bp.get("")
def all_signals():
    """The Phase 3 100-point signal for all 50 tracked stocks, ranked best-score-first.
    Powers the Signals page and the dashboard's Score/Signal column."""
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured", "results": [],
        }), 200

    timeframe = request.args.get("timeframe", "1Day")
    db = get_db()
    signals = compute_all_signals(db, timeframe=timeframe)
    return jsonify({"data_source": "alpaca", "timeframe": timeframe, "results": signals})


@bp.get("/<ticker>")
def stock_signal(ticker):
    """Single-stock signal with the full component-score breakdown — powers the stock detail
    page's 'WHY THIS SCORE?' panel."""
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({
            "ticker": ticker, "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured",
        }), 200

    timeframe = request.args.get("timeframe", "1Day")
    db = get_db()
    signal = compute_signal_for_ticker(db, ticker, timeframe=timeframe)
    return jsonify(signal)


@bp.get("/v2")
def all_signals_v2():
    """Signal v2 for the whole universe: two scores, three gates, what changed, sell triggers.

    READS ONLY. Computing all 50 takes about 90 seconds — bars, indicators, relative strength and
    SEC fundamentals each — and doing that inside this request meant a 90-second spinner that was
    indistinguishable from a hung page, which is a failure mode this project has already been
    bitten by. So this returns whatever was last computed, immediately, and says how old it is.
    A background refresh starts by itself when the stored reading goes stale.

    Ranked by HOLD quality, not by a blend. The page's job is "am I still happy owning these" —
    entry quality is a separate column because it is a separate question.
    """
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca", "data_status": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured", "results": [],
        }), 200
    return jsonify({"data_source": "alpaca",
                    **read_v2(current_app._get_current_object(), get_db())})


@bp.get("/v2/summary")
def signals_v2_summary():
    """Counts and freshness only — small enough to poll every few seconds, and small enough to
    put on the dashboard without recomputing anything."""
    if not Config.has_alpaca_credentials():
        return jsonify({"data_status": "UNAVAILABLE"}), 200
    full = read_v2(current_app._get_current_object(), get_db(), auto_refresh=False)
    return jsonify({k: full[k] for k in
                    ("strategy_version", "summary", "computed_at", "age_minutes", "stale",
                     "refreshing", "progress", "refresh_error")})


@bp.post("/v2/refresh")
def signals_v2_refresh():
    """Recompute the whole universe in the background. Returns at once; poll /v2/summary."""
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca API credentials not configured"}), 200
    started = start_refresh(current_app._get_current_object(), get_db())
    return jsonify({"started": started,
                    "message": "Refresh started — about 90 seconds for all 50." if started
                               else "A refresh is already running."})


@bp.get("/v2/<ticker>")
def stock_signal_v2(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({"ticker": ticker, "data_status": "UNAVAILABLE",
                        "error": "Alpaca API credentials not configured"}), 200
    db = get_db()
    return jsonify(compute_v2_for_ticker(db, ticker,
                                         timeframe=request.args.get("timeframe", "1Day")))
