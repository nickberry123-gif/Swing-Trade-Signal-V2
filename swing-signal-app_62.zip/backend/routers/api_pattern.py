"""
52-week / 200MA pattern-test routes.

Same background-thread + polling shape as the backtest, and for the same reason: the analysis
scores all 50 tickers on every month-start across five years, which takes minutes. A
synchronous request would be killed by the worker timeout and the client would get an HTML error
page where it expected JSON.
"""
import json
import logging
import threading

from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services.job_runner import reap_stale_runs, run_background_job
from services.bars_service import BACKTEST_LOOKBACK_DAYS, get_bars_df
from services.bullish_setup_service import run_bullish_setup_test
from services.signals_service import TICKERS

logger = logging.getLogger(__name__)
bp = Blueprint("api_pattern", __name__, url_prefix="/api/pattern-test")


TABLE = "pattern_runs"


def _run_in_background(app, run_id: int, tickers: list, config: dict):
    """Loads bars, computes, saves — each on its own short-lived connection.

    Never holds a connection across the compute: Neon closes idle connections after a few
    minutes, and a run that outlived that window lost its entire result at the final write.
    See services/job_runner.py for the incident this shape prevents.
    """
    def load(db):
        bars_by_ticker = {}
        needed = list(dict.fromkeys(
            tickers + (["SPY", "QQQ"] if config.get("use_regime", True) else [])))
        for t in needed:
            df, _meta = get_bars_df(db, t, "1Day", lookback_days=BACKTEST_LOOKBACK_DAYS)
            if not df.empty:
                bars_by_ticker[t] = df.reset_index(drop=True)
        if not bars_by_ticker:
            raise RuntimeError("No historical bar data available to analyse.")
        return bars_by_ticker

    def compute(loaded, progress):
        bars_by_ticker = loaded
        progress("Analysing {} stocks…".format(len(tickers)))
        return run_bullish_setup_test(bars_by_ticker, tickers, config)

    run_background_job(app, table=TABLE, run_id=run_id, label="Pattern test",
                       load=load, compute=compute)


@bp.get("/runs")
def list_runs():
    db = get_db()
    reap_stale_runs(db, TABLE)
    rows = db.execute(
        "SELECT id, created_at, status, error, progress FROM pattern_runs "
        "ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify({"runs": [dict(r) for r in rows]})


@bp.get("/runs/<int:run_id>")
def get_run(run_id):
    db = get_db()
    reap_stale_runs(db, TABLE)
    row = db.execute(
        "SELECT id, created_at, status, error, progress, config_json, results_json "
        "FROM pattern_runs WHERE id = ?", (run_id,)).fetchone()
    if row is None:
        return jsonify({"error": f"No pattern run with id {run_id}"}), 404
    run = dict(row)
    for key in ("config_json", "results_json"):
        if run.get(key):
            try:
                run[key.replace("_json", "")] = json.loads(run[key])
            except (TypeError, ValueError):
                pass
        run.pop(key, None)
    return jsonify(run)


@bp.post("/run")
def run():
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca API credentials not configured — no historical bars "
                                 "available to analyse."}), 200

    payload = request.get_json(silent=True) or {}
    tickers = [t for t in (payload.get("tickers") or TICKERS) if t in TICKERS]
    if not tickers:
        return jsonify({"error": "No valid tickers from the tracked universe were requested."}), 400

    # The 52-week / 200MA state machine that used to run here still exists in
    # services/pattern_service.py, untouched and fully tested. This page now runs the two bullish
    # setups instead; restoring the old one means pointing `compute` back at run_pattern_test.
    config = {
        "use_regime": bool(payload.get("use_regime", True)),
        "setup_types": (payload.get("setup_types")
                        or ["BULLISH_RETRACEMENT", "BULLISH_BASE_BREAKOUT"]),
        "min_quality": str(payload.get("min_quality") or "MEDIUM").upper(),
        "min_rr": float(payload.get("min_rr", 2.0)),
        "max_dollar_risk": float(payload.get("max_dollar_risk", 100.0)),
        "retrace_min_pct": float(payload.get("retrace_min_pct", 40.0)),
        "retrace_max_pct": float(payload.get("retrace_max_pct", 60.0)),
        "min_red_candles": int(payload.get("min_red_candles", 3)),
        "base_max_width_pct": float(payload.get("base_max_width_pct", 8.0)),
        "max_stop_pct": float(payload.get("max_stop_pct", 8.0)),
        "min_avg_volume": int(payload.get("min_avg_volume", 3_000_000)),
        "max_holding_days": int(payload.get("max_holding_days", 40)),
    }

    db = get_db()
    run_id = db.insert_returning_id(
        "INSERT INTO pattern_runs (config_json, status) VALUES (?, 'running')",
        (json.dumps(config),))
    db.commit()

    from flask import current_app
    threading.Thread(target=_run_in_background,
                     args=(current_app._get_current_object(), run_id, tickers, config),
                     daemon=True).start()

    return jsonify({"run_id": run_id, "status": "running",
                    "note": "Poll /api/pattern-test/runs/<id> until status is no longer 'running'."}), 202
