from flask import Blueprint, jsonify, request

from config import Config
from db import get_db
from services import fundamentals_history_service as fh
from services.fundamentals_service import get_earnings_info, get_fundamentals
from services.news_service import get_news_for_ticker, refresh_news
from services.signals_service import TICKERS

bp = Blueprint("api_fundamentals", __name__, url_prefix="/api")


@bp.get("/fundamentals/<ticker>")
def stock_fundamentals(ticker):
    """Audited financial-statement data from SEC EDGAR plus the derived long-term quality score.
    Requires no API key (EDGAR is public) and is independent of the Alpaca credentials."""
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404

    db = get_db()
    force = request.args.get("refresh") == "1"
    data = get_fundamentals(db, ticker, force_refresh=force)
    data["earnings"] = get_earnings_info(db, ticker, force_refresh=force)
    return jsonify(data)


@bp.get("/fundamentals/history/<ticker>")
def stock_fundamentals_history(ticker):
    """The multi-year annual history, optionally AS IT WAS KNOWN on a given date.

    `?as_of=YYYY-MM-DD` restricts the answer to filings published on or before that date, which
    is how a historical score avoids using figures that did not exist yet. Omitting it means
    today — the only case where the newest filing is the right one.

    `?refresh=1` refetches from SEC. Rate-limited by a 30-day cache because annual filings
    arrive annually.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404

    db = get_db()
    refreshed = fh.refresh(db, ticker, force=request.args.get("refresh") == "1")
    as_of = request.args.get("as_of") or None
    rows = fh.history(db, ticker, as_of_filed=as_of, limit=int(request.args.get("years", 10)))
    return jsonify({
        "ticker": ticker,
        "as_of_filed": as_of or "today",
        "refresh": refreshed,
        "periods": rows,
        "coverage": fh.coverage(db, ticker, as_of_filed=as_of),
        "note": "Figures are as reported in filings published on or before the as-of date. "
                "Restatements filed later are excluded by the query, not merely ignored.",
    })


@bp.get("/fundamentals/tags/<ticker>")
def stock_fundamentals_tags(ticker):
    """Which XBRL tags this company actually publishes — a diagnostic, not a data path.

    `?contains=share` filters by substring. It exists because when a concept comes back empty the
    only honest way to find the right tag is to read SEC's response; the alternative is inventing
    plausible-looking tag names and shipping them, which is how a wrong number gets a confident
    label. Nothing scores off this endpoint.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    from providers.base import ProviderError
    from services.fundamentals_service import get_fundamentals_provider
    try:
        return jsonify({
            "ticker": ticker,
            "contains": request.args.get("contains") or "",
            "namespaces": get_fundamentals_provider().list_tags(
                ticker, contains=request.args.get("contains")),
        })
    except ProviderError as e:
        return jsonify({"ticker": ticker, "data_status": "UNAVAILABLE", "error": str(e)}), 200


@bp.get("/fundamentals/share-counts/<ticker>")
def stock_share_counts(ticker):
    """Every stored cover-page share count, and which one the app would select — a diagnostic.

    Added after a share count from a document filed in 2012 was chosen ahead of fourteen years of
    newer ones. The selection looked wrong and there was no way to see the underlying rows, so the
    cause had to be reasoned about rather than read. This endpoint removes that: it shows what is
    stored, in the order the selector sees it, plus the row actually chosen.

    `?rejects=1` additionally refetches from SEC and reports any facts DISCARDED for having an
    impossible date — a count cannot be dated years after the filing that carries it. Nothing
    scores off any of this.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    db = get_db()
    out = {
        "ticker": ticker,
        "selected": fh.latest_share_count(db, ticker),
        "stored": fh.stored_share_counts(db, ticker),
        "note": "ordered by FILING date — the count from the most recently published document, "
                "not the one bearing the latest internal date.",
    }
    if request.args.get("rejects") == "1":
        from providers.base import ProviderError
        from services.fundamentals_service import get_fundamentals_provider
        try:
            provider = get_fundamentals_provider()
            cik = provider.get_cik(ticker)
            from providers.sec_edgar_provider import SEC_FACTS_URL
            payload = provider._get(SEC_FACTS_URL.format(cik=cik))
            kept, rejected = provider.parse_share_counts(payload, with_rejects=True)
            out["parsed_now"] = {"kept": len(kept), "rejected": rejected,
                                 "newest_kept": kept[0] if kept else None}
        except ProviderError as e:
            out["parsed_now"] = {"error": str(e)}
    return jsonify(out)


@bp.get("/fundamentals/share-periods/<ticker>")
def stock_share_periods(ticker):
    """Weighted-average share counts per reported period, and the one that would be selected.

    A diagnostic. These figures are what makes a stock split survivable without computing a split
    factor: a weighted average published after the split is already on the post-split basis. The
    endpoint exists so that claim can be READ rather than trusted — Carvana's rows should show
    roughly 137.6m from the annual filing and roughly 717.7m from the quarter filed after May 2026,
    with this app doing no arithmetic between them.
    """
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    db = get_db()
    return jsonify({
        "ticker": ticker,
        "selected": fh.latest_share_period(db, ticker),
        "stored": fh.stored_share_periods(db, ticker),
        "note": "ordered by FILING date, then by the shortest period. No split factor is applied "
                "to any of these figures anywhere in this app.",
    })


@bp.get("/bar-adjustment-check/<ticker>")
def bar_adjustment_check(ticker):
    """Does Alpaca actually serve RAW bars, and do they behave the way a valuation needs?

    A VERIFICATION PROBE, not a feature. Nothing scores off it and nothing stores its output.

    The Value pillar rests on one claim that has to be proven rather than assumed: that a raw
    historical price can be paired with the as-reported per-share figures of that date to give a
    valuation on a single consistent basis. The evidence is a known stock split. Across the split
    date the RAW series must jump by the split ratio, because that is what actually happened to the
    quoted price — and the ADJUSTED series must NOT, because it has been restated onto today's
    basis.

    If raw and adjusted look the same across a split, raw is not raw and the whole approach fails.

    `?date=` the split date, `?days=` the window either side. Defaults verify NVIDIA's ten-for-one
    of 10 June 2024.
    """
    from datetime import datetime, timedelta, timezone as _tz
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({"error": "Alpaca credentials are not configured"}), 200

    split_date = request.args.get("date", "2024-06-10")
    days = max(1, min(int(request.args.get("days", 6)), 30))
    try:
        centre = datetime.fromisoformat(split_date).replace(tzinfo=_tz.utc)
    except ValueError:
        return jsonify({"error": f"date must be YYYY-MM-DD, got {split_date!r}"}), 400
    start, end = centre - timedelta(days=days), centre + timedelta(days=days)

    from providers.base import ProviderError
    from services.market_service import get_provider
    provider = get_provider()

    def series(adjustment):
        try:
            bars = provider.get_bars_with_adjustment(ticker, "1Day", start, end, adjustment)
        except ProviderError as e:
            return {"error": str(e)}, None
        return ([{"d": b.ts.date().isoformat(), "close": b.close} for b in bars], bars)

    raw_rows, raw_bars = series("raw")
    adj_rows, adj_bars = series("all")

    def ratio_across(bars):
        """Last close BEFORE the date, divided by the first close ON OR AFTER it."""
        if not bars:
            return None
        before = [b for b in bars if b.ts.date().isoformat() < split_date]
        after = [b for b in bars if b.ts.date().isoformat() >= split_date]
        if not before or not after or not after[0].close:
            return None
        return round(before[-1].close / after[0].close, 4)

    raw_ratio = ratio_across(raw_bars) if raw_bars else None
    adj_ratio = ratio_across(adj_bars) if adj_bars else None
    return jsonify({
        "ticker": ticker, "split_date": split_date, "window_days": days,
        "raw": raw_rows, "adjusted": adj_rows,
        "raw_ratio_across_date": raw_ratio,
        "adjusted_ratio_across_date": adj_ratio,
        "reading": (
            "The RAW ratio should be approximately the split ratio — the quoted price really did "
            "fall by that factor overnight. The ADJUSTED ratio should be approximately 1.0, "
            "because that series has been restated onto today's basis. If both are near 1.0, "
            "Alpaca is not serving genuinely unadjusted bars and the historical-valuation approach "
            "does not work."),
    })


@bp.get("/corporate-actions/probe")
def corporate_actions_probe():
    """Does this Alpaca account actually serve corporate actions? One request, read-only.

    Built as a probe rather than assumed. Nothing in the share basis depends on the answer being
    yes: when it is no, splits are detected from the discontinuity in the cover-page share counts
    this app already stores, which is reliable but only appears at the next filing.
    """
    from services.market_service import get_provider
    if not Config.has_alpaca_credentials():
        return jsonify({"available": False, "error": "Alpaca credentials are not configured"}), 200
    return jsonify(get_provider().corporate_actions_probe(
        request.args.get("symbol", "AAPL").upper()))


@bp.get("/fundamentals/coverage")
def fundamentals_coverage():
    """Per-ticker, per-field coverage across the universe — the input to the Build B2 check that
    Company Health and valuation can actually be populated before any score depends on them.

    Read-only and deliberately never refetches: this endpoint reports what is stored, so it can
    be used to check whether a refresh worked rather than quietly performing one and reporting
    success either way.
    """
    db = get_db()
    tickers = [t.strip().upper() for t in (request.args.get("tickers") or "").split(",") if t.strip()]
    tickers = [t for t in tickers if t in TICKERS] or sorted(TICKERS)
    return jsonify({
        "tickers": len(tickers),
        "results": [fh.coverage(db, t, as_of_filed=request.args.get("as_of") or None)
                    for t in tickers],
    })


@bp.get("/news/<ticker>")
def stock_news(ticker):
    ticker = ticker.upper()
    if ticker not in TICKERS:
        return jsonify({"error": f"{ticker} is not in the tracked universe"}), 404
    if not Config.has_alpaca_credentials():
        return jsonify({"ticker": ticker, "data_status": "UNAVAILABLE",
                        "error": "Alpaca API credentials not configured", "items": []}), 200

    db = get_db()
    result = refresh_news(db, [ticker], force=request.args.get("refresh") == "1")
    items = get_news_for_ticker(db, ticker, limit=20)
    return jsonify({
        "ticker": ticker,
        "data_status": "UNAVAILABLE" if (result.get("error") and not items) else "OK",
        "error": result.get("error"),
        "sentiment_method": "keyword-based classifier (not NLP/AI sentiment analysis) — see "
                            "providers/news_provider.py for the exact keyword lists",
        "items": items,
    })
