from flask import Blueprint, jsonify

from config import Config
from db import get_db
from providers import ProviderError
from services.market_service import get_market_clock_cached
from services.market_regime import compute_market_regime, store_market_regime

bp = Blueprint("api_market", __name__, url_prefix="/api/market")


@bp.get("/status")
def market_status():
    if not Config.has_alpaca_credentials():
        return jsonify({
            "data_source": "alpaca",
            "data_status": "UNAVAILABLE",
            "error": "ALPACA_API_KEY / ALPACA_SECRET_KEY not configured in backend/.env",
            "is_open": None,
            "session": None,
        }), 200

    try:
        status = get_market_clock_cached()
    except ProviderError as e:
        return jsonify({
            "data_source": "alpaca",
            "data_status": e.status.value,
            "error": str(e),
            "is_open": None,
            "session": None,
        }), 200

    return jsonify({
        "data_source": "alpaca",
        "data_status": "LIVE",
        "is_open": status.is_open,
        "session": status.session,
        "timestamp": status.timestamp.isoformat(),
        "next_open": status.next_open.isoformat(),
        "next_close": status.next_close.isoformat(),
    })


@bp.get("/regime")
def market_regime():
    """STRONG BULL / BULL / NEUTRAL / CAUTIOUS / BEAR classification built from SPY/QQQ
    trend, sector breadth, and the VIXY volatility proxy (true CBOE VIX is not available from
    Alpaca — see detail.vix_true_index_status). Persists each computed snapshot to
    `market_regime` for future history/analytics phases."""
    if not Config.has_alpaca_credentials():
        return jsonify({
            "regime": "UNAVAILABLE",
            "error": "Alpaca API credentials not configured",
        }), 200

    db = get_db()
    result = compute_market_regime(db)
    if result.get("regime") != "UNAVAILABLE":
        store_market_regime(db, result)
    return jsonify(result)
