"""
Strategy CRUD for the Strategy Lab.

Read-only listing is cheap; every response carries `attempts` — how many non-baseline strategies
exist — because that number is what tells you how much multiple-testing luck is baked into
whichever one currently looks best. It is deliberately returned alongside the results rather
than tucked away on a settings page.
"""
import logging

from flask import Blueprint, jsonify, request

from db import get_db
from services.strategy_service import (attempt_count, default_strategy, delete_strategy,
                                       get_strategy, list_strategies, save_strategy)

logger = logging.getLogger(__name__)
bp = Blueprint("api_strategies", __name__, url_prefix="/api/strategies")


@bp.get("")
def list_all():
    db = get_db()
    return jsonify({
        "strategies": list_strategies(db),
        "attempts": attempt_count(db),
        "template": default_strategy(),
    })


@bp.get("/<int:strategy_id>")
def get_one(strategy_id):
    s = get_strategy(get_db(), strategy_id)
    if s is None:
        return jsonify({"error": f"No strategy with id {strategy_id}"}), 404
    return jsonify(s)


@bp.post("")
def create():
    payload = request.get_json(silent=True) or {}
    try:
        new_id = save_strategy(get_db(), payload)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"id": new_id}), 201


@bp.put("/<int:strategy_id>")
def update(strategy_id):
    payload = request.get_json(silent=True) or {}
    try:
        save_strategy(get_db(), payload, strategy_id)
    except ValueError as e:
        # The baseline is protected: it is the control every comparison is measured against, and
        # a comparison whose control drifts is not a comparison.
        return jsonify({"error": str(e)}), 400
    return jsonify({"id": strategy_id})


@bp.delete("/<int:strategy_id>")
def remove(strategy_id):
    try:
        delete_strategy(get_db(), strategy_id)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"deleted": strategy_id})
