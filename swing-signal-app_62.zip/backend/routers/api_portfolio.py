"""
Phase 5 + 6 routes: manual trade journal, holdings/P&L, FX rate, signal history, performance.

Note there is deliberately NO route anywhere in this app that sends an order to a broker. The
only write operations here record what the user has already done elsewhere, by hand.
"""
from flask import Blueprint, jsonify, request

from db import get_db
from providers.base import ProviderError
from services.market_service import get_snapshots_cached
from services.performance_service import (evaluate_signal_outcomes, get_performance_summary,
                                          get_signal_history, get_trade_performance,
                                          snapshot_signals)
from services.portfolio_service import (add_trade, delete_trade, get_fx_rate, get_portfolio,
                                        get_trades, set_fx_rate)
from services.signals_service import TICKERS, compute_all_signals

bp = Blueprint("api_portfolio", __name__, url_prefix="/api")


def _live_prices(tickers: list) -> dict:
    """Best-effort live prices for P&L. A failure here degrades the portfolio to cost-basis-only
    (with market value shown as UNAVAILABLE) rather than failing the whole request."""
    if not tickers:
        return {}
    try:
        snapshots = get_snapshots_cached(tickers)
    except ProviderError:
        return {}
    return {t: s.last_price for t, s in snapshots.items()
            if s is not None and s.last_price is not None}


@bp.get("/trades")
def list_trades():
    db = get_db()
    return jsonify({"trades": get_trades(db, request.args.get("ticker"))})


@bp.post("/trades")
def create_trade():
    payload = request.get_json(silent=True) or {}
    db = get_db()
    try:
        result = add_trade(
            db,
            ticker=payload.get("ticker"),
            side=payload.get("side"),
            trade_date=payload.get("trade_date"),
            quantity=payload.get("quantity"),
            price=payload.get("price"),
            fees=payload.get("fees") or 0,
            notes=payload.get("notes"),
            fx_rate_usd_gbp=payload.get("fx_rate_usd_gbp"),
        )
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(result), 201


@bp.delete("/trades/<int:trade_id>")
def remove_trade(trade_id):
    db = get_db()
    if not delete_trade(db, trade_id):
        return jsonify({"error": "Trade not found"}), 404
    return jsonify({"deleted": trade_id})


@bp.get("/portfolio")
def portfolio():
    db = get_db()
    held = [r["ticker"] for r in
            db.execute("SELECT DISTINCT ticker FROM trades").fetchall()]
    prices = _live_prices([t for t in held if t in TICKERS])
    return jsonify(get_portfolio(db, prices_by_ticker=prices, fx_rate=get_fx_rate(db)))


@bp.get("/fx")
def fx_get():
    db = get_db()
    rate = get_fx_rate(db)
    if not rate:
        return jsonify({
            "rate": None,
            "note": "No USD->GBP rate has been set. GBP figures stay hidden until you enter a "
                    "rate — the app will not assume or invent one.",
        })
    return jsonify(rate)


@bp.post("/fx")
def fx_set():
    payload = request.get_json(silent=True) or {}
    db = get_db()
    try:
        return jsonify(set_fx_rate(db, payload.get("rate"), source=payload.get("source", "manual"),
                                   as_of=payload.get("as_of")))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400


@bp.get("/signal-history")
def signal_history():
    db = get_db()
    return jsonify({"history": get_signal_history(db, request.args.get("ticker"),
                                                  limit=int(request.args.get("limit", 200)))})


@bp.post("/signal-history/snapshot")
def snapshot():
    """Records the current signals into the append-only history. Called manually or on a
    schedule; each call adds a new dated row rather than replacing anything."""
    db = get_db()
    signals = compute_all_signals(db, persist=True)
    written = snapshot_signals(db, signals)
    return jsonify({"snapshotted": written})


@bp.get("/performance")
def performance():
    db = get_db()
    evaluation = evaluate_signal_outcomes(db)
    return jsonify({
        "signal_performance": get_performance_summary(db),
        "trade_performance": get_trade_performance(db),
        "evaluation_run": evaluation,
    })
