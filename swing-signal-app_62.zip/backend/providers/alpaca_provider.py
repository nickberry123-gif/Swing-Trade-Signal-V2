"""
AlpacaProvider — concrete MarketDataProvider backed by Alpaca Markets' REST API.

Uses `requests` directly against Alpaca's documented v2 REST endpoints rather than the
alpaca-py SDK, so the app has zero dependency on a package that may not always be
installable in every environment. This still satisfies "use Alpaca's official API":
every endpoint/field used here is Alpaca's public documented REST contract
(https://docs.alpaca.markets), not a scrape or reverse-engineered API.

Free-tier note: Alpaca's free market-data plan serves the IEX feed (single-exchange,
real-time — NOT artificially delayed by Alpaca, unlike some other "free" vendors). Paid
plans add the full consolidated SIP feed. We request feed=iex explicitly so the app
never silently assumes SIP access it doesn't have.
"""
import re
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import requests

from .base import MarketDataProvider, DataStatus, Snapshot, Bar, MarketStatus, ProviderError

NY_TZ = ZoneInfo("America/New_York")

# How fresh a trade must be, during regular market hours, to be called LIVE vs STALE.
# Swing trading on daily/4h/1h bars does not need sub-second freshness (see project spec:
# "signal stability" / "data delay" sections) — these thresholds are deliberately generous.
LIVE_FRESHNESS_SECONDS = 5 * 60      # <= 5 min old during market hours => LIVE
STALE_THRESHOLD_SECONDS = 30 * 60    # > 30 min old during market hours => STALE

# Alpaca's REST timeframe strings happen to match this app's canonical timeframe names
# 1:1 today. This map exists anyway so the vendor coupling is explicit and isolated here
# (per MarketDataProvider's abstraction requirement) rather than assumed elsewhere.
TIMEFRAME_MAP = {
    "1Day": "1Day",
    "4Hour": "4Hour",
    "1Hour": "1Hour",
    "30Min": "30Min",
    "15Min": "15Min",
}

# Corporate-action adjustment applied to historical bars.
#
# This was 'raw' (unadjusted) and it silently wrecked every historical calculation in the app.
# Alpaca's raw bars report the price actually printed on the day, so a stock split shows up as a
# genuine one-day collapse. Verified in production: NVDA closed at $1208.42 on 2024-06-07 and
# $121.93 on 2024-06-10 — its 10-for-1 split, which the backtester scored as an 89.9% loss.
# AVGO (10:1, 2024), AMZN and GOOGL (20:1, 2022) and TSLA (3:1, 2022) all sit inside the
# 5-year backtest window too. Beyond the fake losses, every SMA/RSI/ATR/ADX spanning a split
# date was computed across a 10x discontinuity, so entry signals were wrong as well.
#
# 'all' back-adjusts history for both splits and dividends. The most recent bar is unchanged
# (adjustments are applied relative to the latest price), so live prices are unaffected and this
# is safe for the request-path endpoints as well as the backtester. Dividend adjustment matters
# for the income-paying names in the universe (JPM, AAPL, COST, LLY): without it a total-return
# simulation quietly under-counts every holding period that spans an ex-dividend date.
BAR_ADJUSTMENT = "all"

# Written to market_bars.source. The adjustment basis is part of a cached bar's identity: an
# unadjusted row and an adjusted row for the same (ticker, timeframe, ts) are different numbers.
# Tagging the rows lets bars_service detect a cache written under the old basis and purge it,
# rather than serving a silent mix of pre- and post-fix prices forever.
BAR_SOURCE_TAG = f"alpaca:adj-{BAR_ADJUSTMENT}"


_TS_RE = re.compile(
    r"^(?P<base>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})"
    r"(?P<frac>\.\d+)?"
    r"(?P<tz>Z|[+-]\d{2}:\d{2})?$"
)


def _parse_ts(ts: str | None) -> datetime | None:
    """Parse Alpaca's RFC3339 timestamps (which may carry up to nanosecond precision,
    e.g. '2024-01-02T14:30:00.123456789Z') into an aware UTC datetime, without relying
    on fromisoformat()'s version-dependent leniency — this must work on any Python 3.9+."""
    if not ts:
        return None
    m = _TS_RE.match(ts.strip())
    if not m:
        raise ProviderError(f"Unrecognized timestamp format from Alpaca: {ts!r}")
    base = m.group("base")
    frac = (m.group("frac") or ".0")[1:][:6].ljust(6, "0")  # truncate/pad to microseconds
    tz = m.group("tz") or "Z"
    tz = "+00:00" if tz == "Z" else tz
    return datetime.fromisoformat(f"{base}.{frac}{tz}")


class AlpacaProvider(MarketDataProvider):
    name = "alpaca"

    def __init__(self, api_key: str | None, secret_key: str | None, trading_base_url: str,
                 data_base_url: str = "https://data.alpaca.markets", feed: str = "iex",
                 timeout: float = 10.0):
        self.api_key = api_key
        self.secret_key = secret_key
        self.trading_base_url = trading_base_url
        self.data_base_url = data_base_url
        self.feed = feed
        self.timeout = timeout

    # -- raw bars, for point-in-time valuation only ----------------------------
    # SEPARATE FROM get_bars ON PURPOSE, AND get_bars IS NOT TOUCHED.
    #
    # Everything in this app that reads prices — signals, yearly, backtests — uses the split- and
    # dividend-ADJUSTED series, and must go on doing so: a total return between two dates is only
    # correct on a consistently adjusted series. This method exists for the opposite need.
    #
    # A historical VALUATION cannot use adjusted prices. An adjusted bar from 2019 is expressed in
    # today's share basis, while the per-share figures in the 2019 filing are as-reported on the
    # basis of the day. Dividing one by the other is wrong by every corporate action since — the
    # same defect that already blocks historical market capitalisation in this app.
    #
    #     RAW price      + as-reported per-share fundamentals  -> a valid historical valuation
    #     ADJUSTED price + adjusted price                      -> a valid return
    #
    # Mixing the two is the error this method exists to avoid, and nothing here changes what the
    # rest of the app receives.
    def get_bars_with_adjustment(self, ticker: str, timeframe: str, start: datetime,
                                 end: datetime, adjustment: str, limit: int = 1000) -> list:
        """Daily bars on an explicitly chosen adjustment basis. Read-only, additive.

        `adjustment` is passed straight through to Alpaca: "raw", "split", "dividend" or "all".
        """
        if timeframe not in TIMEFRAME_MAP:
            raise ProviderError(f"Unsupported timeframe '{timeframe}'", DataStatus.UNAVAILABLE)
        params = {
            "timeframe": TIMEFRAME_MAP[timeframe],
            "start": start.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "end": end.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "limit": min(limit, 10000),
            "feed": self.feed,
            "adjustment": adjustment,
        }
        # Paginated for the same reason get_bars is: six years of daily bars is ~1,520 rows, and a
        # silently truncated series would shorten a valuation history rather than fail, which is
        # the kind of defect that produces a plausible wrong number instead of an error.
        bars: list[Bar] = []
        page_token = None
        while True:
            q = dict(params)
            if page_token:
                q["page_token"] = page_token
            raw = self._get(f"{self.data_base_url}/v2/stocks/{ticker}/bars", params=q)
            for b in (raw.get("bars") or []):
                bars.append(Bar(ts=_parse_ts(b["t"]), open=b["o"], high=b["h"], low=b["l"],
                                close=b["c"], volume=b["v"], trade_count=b.get("n"),
                                vwap=b.get("vw")))
            page_token = raw.get("next_page_token")
            if not page_token or len(bars) >= limit:
                break
        return bars[:limit]

    # -- corporate actions ----------------------------------------------------
    # ADDED AS A PROBE, NOT AS A DEPENDENCY. Alpaca documents a corporate-actions endpoint that
    # names the action type — forward_split, reverse_split, stock_dividend — which is the only
    # signal available that arrives near the ex-date rather than with the next SEC filing. SEC
    # data is roughly twelve weeks behind: Carvana split on 5 May 2026 and the first filing
    # showing it was published on 29 July.
    #
    # Whether this account's plan serves the endpoint is NOT assumed. `corporate_actions_probe`
    # exists so the question is answered by a request rather than by reading a pricing page, and
    # every caller treats UNAVAILABLE as an ordinary outcome. Nothing in the share basis depends
    # on this working; when it is absent the detector falls back to the discontinuity visible in
    # the cover-page counts this app already stores.
    def get_corporate_actions(self, symbols, start: str, end: str, types: str | None = None):
        """Corporate actions for one or more symbols. Raises ProviderError when unavailable."""
        params = {
            "symbols": ",".join(symbols) if not isinstance(symbols, str) else symbols,
            "start": start,
            "end": end,
            "limit": 1000,
        }
        if types:
            params["types"] = types
        return self._get(f"{self.data_base_url}/v1/corporate-actions", params)

    def corporate_actions_probe(self, symbol: str = "AAPL") -> dict:
        """One request that answers 'does this account get corporate actions at all'.

        Read-only and deliberately narrow. Returns a verdict rather than raising, because the
        answer 'no' is information and not an error.
        """
        start = (datetime.now(timezone.utc).date() - timedelta(days=365)).isoformat()
        end = datetime.now(timezone.utc).date().isoformat()
        try:
            payload = self.get_corporate_actions([symbol], start, end)
        except ProviderError as e:
            return {"available": False, "symbol": symbol, "window": [start, end],
                    "error": str(e),
                    "consequence": ("corporate actions are not read from Alpaca. Splits are "
                                    "detected from the discontinuity in stored cover-page share "
                                    "counts instead, which is reliable but only becomes visible "
                                    "at the next filing.")}
        actions = (payload or {}).get("corporate_actions") or {}
        return {"available": True, "symbol": symbol, "window": [start, end],
                "action_types_returned": sorted(actions.keys()) if isinstance(actions, dict) else [],
                "raw_keys": sorted((payload or {}).keys())}

    # -- internal HTTP helper -------------------------------------------------
    def _headers(self) -> dict:
        if not self.api_key or not self.secret_key:
            raise ProviderError(
                "Alpaca API credentials are not configured (ALPACA_API_KEY / ALPACA_SECRET_KEY missing).",
                DataStatus.UNAVAILABLE,
            )
        return {"APCA-API-KEY-ID": self.api_key, "APCA-API-SECRET-KEY": self.secret_key}

    def _get(self, url: str, params: dict | None = None) -> dict:
        try:
            resp = requests.get(url, headers=self._headers(), params=params, timeout=self.timeout)
        except requests.exceptions.RequestException as e:
            raise ProviderError(f"Network error contacting Alpaca: {e}", DataStatus.UNAVAILABLE) from e

        if resp.status_code == 401 or resp.status_code == 403:
            raise ProviderError(
                f"Alpaca rejected credentials ({resp.status_code}): {resp.text[:200]}",
                DataStatus.UNAVAILABLE,
            )
        if resp.status_code == 429:
            raise ProviderError("Alpaca rate limit exceeded (429).", DataStatus.UNAVAILABLE)
        if resp.status_code >= 400:
            raise ProviderError(
                f"Alpaca API error {resp.status_code}: {resp.text[:200]}", DataStatus.UNAVAILABLE
            )
        try:
            return resp.json()
        except ValueError as e:
            raise ProviderError(f"Alpaca returned non-JSON response: {e}", DataStatus.UNAVAILABLE) from e

    # -- MarketDataProvider interface -----------------------------------------
    def get_market_clock(self) -> MarketStatus:
        data = self._get(f"{self.trading_base_url}/v2/clock")
        now = _parse_ts(data["timestamp"])
        is_open = bool(data["is_open"])
        next_open = _parse_ts(data["next_open"])
        next_close = _parse_ts(data["next_close"])

        session = "CLOSED"
        if is_open:
            session = "REGULAR"
        else:
            now_ny = now.astimezone(NY_TZ)
            if now_ny.weekday() < 5:
                t = now_ny.time()
                if t >= datetime.strptime("04:00", "%H:%M").time() and t < datetime.strptime("09:30", "%H:%M").time():
                    session = "PRE_MARKET"
                elif t >= datetime.strptime("16:00", "%H:%M").time() and t < datetime.strptime("20:00", "%H:%M").time():
                    session = "AFTER_HOURS"

        return MarketStatus(is_open=is_open, timestamp=now, next_open=next_open,
                             next_close=next_close, session=session)

    def _snapshot_from_raw(self, ticker: str, raw: dict, market_open: bool) -> Snapshot:
        latest_trade = raw.get("latestTrade") or {}
        latest_quote = raw.get("latestQuote") or {}
        daily_bar = raw.get("dailyBar") or {}
        prev_daily_bar = raw.get("prevDailyBar") or {}

        last_price = latest_trade.get("p")
        last_trade_ts = _parse_ts(latest_trade.get("t"))
        fetched_at = datetime.now(timezone.utc)

        data_status = self._classify_status(last_trade_ts, market_open, has_price=last_price is not None)

        return Snapshot(
            ticker=ticker,
            last_price=last_price,
            last_trade_ts=last_trade_ts,
            bid_price=latest_quote.get("bp"),
            bid_size=latest_quote.get("bs"),
            ask_price=latest_quote.get("ap"),
            ask_size=latest_quote.get("as"),
            quote_ts=_parse_ts(latest_quote.get("t")),
            daily_open=daily_bar.get("o"),
            daily_high=daily_bar.get("h"),
            daily_low=daily_bar.get("l"),
            daily_close=daily_bar.get("c"),
            daily_volume=daily_bar.get("v"),
            prev_close=prev_daily_bar.get("c"),
            data_source="alpaca",
            data_status=data_status,
            fetched_at=fetched_at,
        )

    def _classify_status(self, last_trade_ts: datetime | None, market_open: bool, has_price: bool) -> DataStatus:
        if not has_price or last_trade_ts is None:
            return DataStatus.UNAVAILABLE
        if not market_open:
            return DataStatus.MARKET_CLOSED
        age_seconds = (datetime.now(timezone.utc) - last_trade_ts).total_seconds()
        if age_seconds <= LIVE_FRESHNESS_SECONDS:
            return DataStatus.LIVE
        if age_seconds <= STALE_THRESHOLD_SECONDS:
            # Still within market hours but hasn't traded recently (illiquid moment) —
            # true, not falsely "live", but not a feed failure either.
            return DataStatus.STALE
        return DataStatus.STALE

    def get_snapshot(self, ticker: str) -> Snapshot:
        clock = self.get_market_clock()
        raw = self._get(f"{self.data_base_url}/v2/stocks/{ticker}/snapshot", params={"feed": self.feed})
        return self._snapshot_from_raw(ticker, raw, clock.is_open)

    def get_snapshots(self, tickers: list[str]) -> dict[str, Snapshot]:
        if not tickers:
            return {}
        clock = self.get_market_clock()
        raw = self._get(
            f"{self.data_base_url}/v2/stocks/snapshots",
            params={"symbols": ",".join(tickers), "feed": self.feed},
        )
        out = {}
        for ticker in tickers:
            item = raw.get(ticker)
            if item is None:
                out[ticker] = Snapshot(
                    ticker=ticker, last_price=None, last_trade_ts=None, bid_price=None,
                    bid_size=None, ask_price=None, ask_size=None, quote_ts=None,
                    daily_open=None, daily_high=None, daily_low=None, daily_close=None,
                    daily_volume=None, prev_close=None, data_source="alpaca",
                    data_status=DataStatus.UNAVAILABLE, fetched_at=datetime.now(timezone.utc),
                )
            else:
                out[ticker] = self._snapshot_from_raw(ticker, item, clock.is_open)
        return out

    def get_bars(self, ticker: str, timeframe: str, start: datetime, end: datetime,
                 limit: int = 1000) -> list[Bar]:
        if timeframe not in TIMEFRAME_MAP:
            raise ProviderError(f"Unsupported timeframe '{timeframe}'", DataStatus.UNAVAILABLE)
        vendor_tf = TIMEFRAME_MAP[timeframe]

        bars: list[Bar] = []
        page_token = None
        params = {
            "timeframe": vendor_tf,
            "start": start.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "end": end.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "limit": min(limit, 10000),
            "feed": self.feed,
            "adjustment": BAR_ADJUSTMENT,
        }
        while True:
            q = dict(params)
            if page_token:
                q["page_token"] = page_token
            raw = self._get(f"{self.data_base_url}/v2/stocks/{ticker}/bars", params=q)
            for b in raw.get("bars", []) or []:
                bars.append(Bar(
                    ts=_parse_ts(b["t"]), open=b["o"], high=b["h"], low=b["l"],
                    close=b["c"], volume=b["v"], trade_count=b.get("n"), vwap=b.get("vw"),
                ))
            page_token = raw.get("next_page_token")
            if not page_token or len(bars) >= limit:
                break
        return bars[:limit]
