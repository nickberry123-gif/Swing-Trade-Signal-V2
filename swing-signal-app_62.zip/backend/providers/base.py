"""
MarketDataProvider abstraction.

The rest of the application (signal engine, API routes, future indicator/backtest code)
must ONLY talk to this interface — never to Alpaca-specific request/response shapes
directly. This is what lets the market-data provider be swapped later without touching
anything downstream:

    MarketDataProvider (this file)
        |
        +-- AlpacaProvider   (providers/alpaca_provider.py)
        +-- (future) OtherProvider

Every concrete provider translates its vendor's raw response into the plain dataclasses
defined here (Snapshot, Bar, MarketStatus) so downstream code is 100% vendor-agnostic.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional


class DataStatus(str, Enum):
    """
    Honest labeling of what the caller is looking at. Never collapse these into each
    other — the whole point is that delayed data is never presented as live, and a
    failed/absent feed is never silently masked by stale cached numbers.
    """
    LIVE = "LIVE"                    # fresh trade/quote during regular session, provider confirms real-time
    DELAYED = "DELAYED"              # feed is inherently delayed (e.g. free-tier SIP delay)
    MARKET_CLOSED = "MARKET_CLOSED"  # market not in regular session; last price shown is the prior close/session
    STALE = "STALE"                  # data is older than freshness threshold for the current session state
    UNAVAILABLE = "UNAVAILABLE"      # no data could be retrieved at all (missing keys, network/API failure)


class ProviderError(Exception):
    """Raised when a provider cannot fulfil a request. Callers must NOT fall back to
    fabricated or silently-stale data on this — they must surface DATA FEED ERROR."""
    def __init__(self, message: str, status: DataStatus = DataStatus.UNAVAILABLE):
        super().__init__(message)
        self.status = status


@dataclass
class Bar:
    ts: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    trade_count: Optional[int] = None
    vwap: Optional[float] = None


@dataclass
class Snapshot:
    """Latest-known trade/quote/bar state for a single ticker."""
    ticker: str
    last_price: Optional[float]
    last_trade_ts: Optional[datetime]
    bid_price: Optional[float]
    bid_size: Optional[float]
    ask_price: Optional[float]
    ask_size: Optional[float]
    quote_ts: Optional[datetime]
    daily_open: Optional[float]
    daily_high: Optional[float]
    daily_low: Optional[float]
    daily_close: Optional[float]
    daily_volume: Optional[float]
    prev_close: Optional[float]
    data_source: str
    data_status: DataStatus
    fetched_at: datetime


@dataclass
class MarketStatus:
    is_open: bool
    timestamp: datetime
    next_open: datetime
    next_close: datetime
    session: str  # 'REGULAR' | 'PRE_MARKET' | 'AFTER_HOURS' | 'CLOSED'


class MarketDataProvider(ABC):
    """Abstract market-data source. Concrete implementations must not leak vendor-specific
    types or field names past this boundary."""

    name: str = "abstract"

    @abstractmethod
    def get_market_clock(self) -> MarketStatus:
        """Current US equities market session status."""
        raise NotImplementedError

    @abstractmethod
    def get_snapshot(self, ticker: str) -> Snapshot:
        """Latest trade/quote/daily-bar snapshot for one ticker."""
        raise NotImplementedError

    @abstractmethod
    def get_snapshots(self, tickers: list[str]) -> dict[str, Snapshot]:
        """Latest snapshots for multiple tickers in one call where the vendor supports it."""
        raise NotImplementedError

    @abstractmethod
    def get_bars(self, ticker: str, timeframe: str, start: datetime, end: datetime,
                 limit: int = 1000) -> list[Bar]:
        """
        Historical OHLCV bars. `timeframe` is one of the app's canonical timeframe
        strings: '1Day', '4Hour', '1Hour', '30Min', '15Min'. Concrete providers are
        responsible for mapping these to their own vendor's timeframe syntax.
        """
        raise NotImplementedError
