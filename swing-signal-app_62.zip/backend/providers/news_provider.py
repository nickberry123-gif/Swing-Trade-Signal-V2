"""
News provider abstraction + Alpaca implementation.

Alpaca's news endpoint (https://data.alpaca.markets/v1beta1/news) is part of the same Alpaca
account/plan already in use, so this adds no new vendor and no new cost — it stays within the
project constraint that Alpaca is the market-data provider.

IMPORTANT — sentiment honesty: Alpaca's news payload contains no sentiment field. Rather than
pretend to do NLP sentiment analysis, `classify_headline_sentiment()` below is a deliberately
simple, fully transparent keyword classifier. It is labeled as exactly that everywhere it
surfaces, and its keyword lists are visible in this file rather than hidden behind a model. A
crude-but-inspectable heuristic that is described accurately is acceptable; a black box
presented as "AI sentiment analysis" would not be.

Response-shape note: Alpaca's public docs page does not render its response example, so this
parser reads every field defensively (`.get()`, multiple accepted wrapper keys) and degrades to
partial data rather than raising if a field name differs from what's expected.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

import requests

from providers.base import DataStatus, ProviderError

ALPACA_NEWS_URL = "https://data.alpaca.markets/v1beta1/news"

# Transparent keyword lists. Deliberately conservative: anything not matched is NEUTRAL rather
# than being forced into a positive/negative bucket.
BULLISH_KEYWORDS = [
    "beats", "beat expectations", "raises guidance", "raised guidance", "upgrade", "upgraded",
    "record revenue", "record profit", "strong demand", "outperform", "buyback", "surges",
    "soars", "jumps", "rallies", "tops estimates", "better than expected", "expands", "wins",
    "approval", "breakthrough", "partnership", "all-time high",
]
BEARISH_KEYWORDS = [
    "misses", "missed expectations", "cuts guidance", "lowers guidance", "downgrade",
    "downgraded", "investigation", "lawsuit", "recall", "probe", "plunges", "tumbles", "sinks",
    "slumps", "falls short", "worse than expected", "layoffs", "delay", "delayed", "warning",
    "warns", "fraud", "subpoena", "antitrust", "ban", "halts", "resigns", "steps down",
]
HIGH_IMPACT_KEYWORDS = [
    "earnings", "guidance", "acquisition", "merger", "ceo", "sec ", "fda", "antitrust",
    "lawsuit", "investigation", "bankruptcy", "split", "dividend", "buyback", "downgrade",
    "upgrade",
]


@dataclass
class NewsItem:
    id: str | None
    headline: str
    summary: str | None
    source: str | None
    url: str | None
    published_at: str | None
    symbols: list = field(default_factory=list)
    sentiment: str = "NEUTRAL"        # BULLISH / BEARISH / NEUTRAL — keyword-derived, labeled
    impact: str = "NORMAL"            # HIGH / NORMAL — keyword-derived, labeled


def classify_headline_sentiment(text: str) -> str:
    """Keyword sentiment. Returns NEUTRAL unless there's a clear, listed signal word — and if a
    headline contains both bullish and bearish markers it stays NEUTRAL rather than guessing."""
    if not text:
        return "NEUTRAL"
    lowered = text.lower()
    bull = any(k in lowered for k in BULLISH_KEYWORDS)
    bear = any(k in lowered for k in BEARISH_KEYWORDS)
    if bull and not bear:
        return "BULLISH"
    if bear and not bull:
        return "BEARISH"
    return "NEUTRAL"


def classify_headline_impact(text: str) -> str:
    if not text:
        return "NORMAL"
    lowered = text.lower()
    return "HIGH" if any(k in lowered for k in HIGH_IMPACT_KEYWORDS) else "NORMAL"


class NewsProvider(ABC):
    name: str = "abstract"

    @abstractmethod
    def get_news(self, tickers: list, days_back: int = 14, limit: int = 50) -> list:
        ...


class AlpacaNewsProvider(NewsProvider):
    name = "alpaca"

    def __init__(self, api_key: str | None, secret_key: str | None, timeout: float = 15.0):
        self.api_key = api_key
        self.secret_key = secret_key
        self.timeout = timeout

    def _headers(self):
        return {
            "APCA-API-KEY-ID": self.api_key or "",
            "APCA-API-SECRET-KEY": self.secret_key or "",
            "Accept": "application/json",
        }

    @staticmethod
    def _parse_item(raw: dict) -> NewsItem:
        headline = raw.get("headline") or raw.get("title") or ""
        summary = raw.get("summary") or raw.get("description")
        # Sentiment/impact are derived from the headline plus summary text, never from a
        # provider-supplied sentiment field (Alpaca doesn't publish one).
        basis = f"{headline} {summary or ''}"
        return NewsItem(
            id=str(raw.get("id")) if raw.get("id") is not None else None,
            headline=headline,
            summary=summary,
            source=raw.get("source"),
            url=raw.get("url"),
            published_at=raw.get("created_at") or raw.get("updated_at") or raw.get("published_at"),
            symbols=raw.get("symbols") or [],
            sentiment=classify_headline_sentiment(basis),
            impact=classify_headline_impact(basis),
        )

    def get_news(self, tickers: list, days_back: int = 14, limit: int = 50) -> list:
        if not (self.api_key and self.secret_key):
            raise ProviderError("Alpaca API credentials not configured.", DataStatus.UNAVAILABLE)

        start = (datetime.now(timezone.utc) - timedelta(days=days_back)).strftime("%Y-%m-%d")
        params = {
            "symbols": ",".join(tickers),
            "start": start,
            "limit": min(max(int(limit), 1), 50),   # Alpaca caps this at 50 per page
            "sort": "desc",
            "exclude_contentless": "true",
        }
        try:
            resp = requests.get(ALPACA_NEWS_URL, headers=self._headers(), params=params,
                                timeout=self.timeout)
        except requests.RequestException as e:
            raise ProviderError(f"Network error contacting Alpaca news: {e}", DataStatus.UNAVAILABLE)

        if resp.status_code in (401, 403):
            raise ProviderError(
                "Alpaca rejected the news request (check that the API keys are valid and that "
                "the account's data plan includes the news API).", DataStatus.UNAVAILABLE)
        if resp.status_code != 200:
            raise ProviderError(f"Alpaca news returned HTTP {resp.status_code}.", DataStatus.UNAVAILABLE)

        try:
            payload = resp.json()
        except ValueError as e:
            raise ProviderError(f"Alpaca news returned non-JSON content: {e}", DataStatus.UNAVAILABLE)

        # Accept either {"news": [...]} or a bare list, since the docs page doesn't render the
        # response example and the wrapper key shouldn't be a single point of failure.
        if isinstance(payload, dict):
            raw_items = payload.get("news") or payload.get("data") or []
        elif isinstance(payload, list):
            raw_items = payload
        else:
            raw_items = []

        return [self._parse_item(r) for r in raw_items if isinstance(r, dict)]
