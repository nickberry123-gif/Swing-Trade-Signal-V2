#!/usr/bin/env python3
"""
Run this ON YOUR OWN MACHINE (not in a locked-down sandbox) after setting up backend/.env,
to confirm your Alpaca credentials and network access actually work end-to-end:

    cd backend
    python3 scripts/check_alpaca_connection.py

It exercises the exact same AlpacaProvider class the Flask app uses — this is a real
connectivity check, not a mock.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import Config
from providers import AlpacaProvider, ProviderError


def main():
    print("== Alpaca connection check ==")
    if not Config.has_alpaca_credentials():
        print("FAIL: ALPACA_API_KEY / ALPACA_SECRET_KEY are not set in backend/.env")
        sys.exit(1)

    provider = AlpacaProvider(
        api_key=Config.ALPACA_API_KEY,
        secret_key=Config.ALPACA_SECRET_KEY,
        trading_base_url=Config.ALPACA_TRADING_BASE_URL,
        data_base_url=Config.ALPACA_DATA_BASE_URL,
    )

    print(f"Trading API base: {Config.ALPACA_TRADING_BASE_URL}")
    print(f"Data API base:    {Config.ALPACA_DATA_BASE_URL}")
    print()

    try:
        clock = provider.get_market_clock()
        print("Market clock OK:")
        print(f"  is_open:    {clock.is_open}")
        print(f"  session:    {clock.session}")
        print(f"  timestamp:  {clock.timestamp}")
        print(f"  next_open:  {clock.next_open}")
        print(f"  next_close: {clock.next_close}")
    except ProviderError as e:
        print(f"FAIL: market clock request failed ({e.status.value}): {e}")
        sys.exit(1)

    print()
    try:
        snap = provider.get_snapshot("AAPL")
        print("AAPL snapshot OK:")
        print(f"  last_price:    {snap.last_price}")
        print(f"  last_trade_ts: {snap.last_trade_ts}")
        print(f"  data_status:   {snap.data_status.value}")
        print(f"  prev_close:    {snap.prev_close}")
    except ProviderError as e:
        print(f"FAIL: AAPL snapshot request failed ({e.status.value}): {e}")
        sys.exit(1)

    print()
    print("SUCCESS — Alpaca credentials and connectivity are working.")


if __name__ == "__main__":
    main()
