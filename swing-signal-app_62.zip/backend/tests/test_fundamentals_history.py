"""
Build B — multi-year point-in-time fundamentals, the expanded line items, and IFRS support.

WHAT THIS FILE IS REALLY TESTING. Three things, in descending order of how badly they would hurt
if they were wrong:

  1. LOOK-AHEAD. That a score computed for a past date cannot reach a filing published after it.
     This is the failure that cannot be spotted by looking at the output, always flatters the
     result, and would make every backtest from here on meaningless. Several tests below exist
     only to attack it.
  2. CURRENCY. That a euro figure never silently ends up in a dollar calculation. No FX
     conversion exists anywhere in this app, so the only safe behaviour is to refuse.
  3. ISOLATION. That none of this moved an existing number. Build B is additive: the fifty
     tickers' current fundamentals, quality scores and signals must read exactly as before.

WHAT THIS FILE CANNOT TEST, STATED PLAINLY. This sandbox has no network route to sec.gov, so
every payload here is a fixture shaped like SEC's documented response. The US-GAAP tag chains
have been exercised against live data by the existing provider; THE IFRS TAG NAMES HAVE NOT.
If an IFRS tag name is wrong it finds nothing and the field stays None — honest, but empty. That
is exactly what Build B2 (coverage validation across all 50 tickers, on the server) is for, and
until B2 runs, IFRS coverage for ASML and NVO is unproven rather than confirmed.
"""
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
from config import STOCK_UNIVERSE  # noqa: E402
from providers.edgar_concepts import HISTORY_VALUE_FIELDS, tags_for  # noqa: E402
from providers.fundamentals_base import FundamentalDataProvider  # noqa: E402
from providers.sec_edgar_provider import SecEdgarProvider  # noqa: E402
from services import fundamentals_history_service as fh  # noqa: E402

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]))
    conn.commit()
    return conn


def fact(end, val, start=None, filed=None, form="10-K", fy=None, accn="0000-1"):
    e = {"end": end, "val": val, "accn": accn, "fy": fy, "fp": "FY", "form": form,
         "filed": filed or end}
    if start:
        e["start"] = start
    return e


def payload(namespace="us-gaap", unit="USD", **tags):
    """companyfacts shaped exactly like SEC's: facts -> namespace -> tag -> units -> unit -> []"""
    return {"cik": 1, "entityName": "TEST", "facts": {namespace: {
        tag: {"label": tag, "units": {unit: entries}} for tag, entries in tags.items()}}}


def multi_unit_payload(namespace, spec):
    """spec: {tag: (unit, entries)} — for mixing USD, EUR, shares and USD/shares in one company."""
    return {"cik": 1, "entityName": "TEST", "facts": {namespace: {
        tag: {"label": tag, "units": {unit: entries}} for tag, (unit, entries) in spec.items()}}}


P = SecEdgarProvider()


# =============================================================================================
# 1. LOOK-AHEAD — the tests that matter most
# =============================================================================================

class PointInTime(unittest.TestCase):
    """A fiscal year is not one set of numbers; it is one set of numbers PER FILING."""

    def setUp(self):
        # FY2023 reported twice: originally in Feb 2024, then restated DOWNWARDS in Feb 2025
        # when it appeared as a comparative in the FY2024 10-K. This is the ordinary case, not
        # an exotic one, and the restatement is unflattering — which is the direction that
        # matters, because using it early makes the past look worse and the *signal* look better.
        self.facts = payload(
            Revenues=[
                fact("2023-12-31", 1000, start="2023-01-01", filed="2024-02-15", fy=2023),
                fact("2023-12-31", 900, start="2023-01-01", filed="2025-02-14", fy=2023),
                fact("2024-12-31", 1200, start="2024-01-01", filed="2025-02-14", fy=2024),
            ])

    def test_both_versions_of_a_year_are_retained_not_collapsed(self):
        """The old parser kept the latest-filed version only. That is right for "what is true
        today" and catastrophic for "what was known in 2024"."""
        records = P.parse_history("TEST", self.facts)
        fy23 = [r for r in records if r.period_end == "2023-12-31"]
        self.assertEqual(len(fy23), 2)
        self.assertEqual({r.filed for r in fy23}, {"2024-02-15", "2025-02-14"})

    def test_scoring_2024_sees_the_original_figure_not_the_2025_restatement(self):
        db = make_db()
        fh.store_history(db, "AAPL", [r for r in P.parse_history("AAPL", self.facts)])
        rows = fh.history(db, "AAPL", as_of_filed="2024-06-30")
        fy23 = [r for r in rows if r["period_end"] == "2023-12-31"]
        self.assertEqual(len(fy23), 1)
        self.assertEqual(fy23[0]["revenue"], 1000)     # what was public in June 2024
        self.assertEqual(fy23[0]["filed"], "2024-02-15")

    def test_scoring_today_sees_the_restated_figure(self):
        """The same query, a later date, a different answer — which is the correct behaviour and
        proves the cutoff is doing the work rather than the row order."""
        db = make_db()
        fh.store_history(db, "AAPL", P.parse_history("AAPL", self.facts))
        rows = fh.history(db, "AAPL", as_of_filed="2026-01-01")
        fy23 = [r for r in rows if r["period_end"] == "2023-12-31"]
        self.assertEqual(fy23[0]["revenue"], 900)

    def test_a_fiscal_year_that_had_not_been_filed_yet_is_absent_entirely(self):
        """Not zero, not a stale carry-forward, not the prior year relabelled — ABSENT. FY2024
        did not exist in June 2024 and must not appear in a June 2024 view."""
        db = make_db()
        fh.store_history(db, "AAPL", P.parse_history("AAPL", self.facts))
        rows = fh.history(db, "AAPL", as_of_filed="2024-06-30")
        self.assertNotIn("2024-12-31", {r["period_end"] for r in rows})

    def test_the_cutoff_is_the_filing_date_not_the_period_end(self):
        """The distinction the whole design rests on. FY2023 ENDED on 2023-12-31 but was not
        knowable until 2024-02-15. A cutoff of 2024-01-10 is after the period end and before the
        filing, and must return nothing."""
        db = make_db()
        fh.store_history(db, "AAPL", P.parse_history("AAPL", self.facts))
        self.assertEqual(fh.history(db, "AAPL", as_of_filed="2024-01-10"), [])

    def test_a_concept_filed_later_cannot_attach_itself_to_an_early_vintage(self):
        """The subtle version of the same bug: revenue from the original filing paired with a
        cash-flow figure that only appeared in the restatement. Each vintage must be internally
        consistent, not a best-of assembled across filings."""
        facts = payload(
            Revenues=[fact("2023-12-31", 1000, start="2023-01-01", filed="2024-02-15")],
            NetCashProvidedByUsedInOperatingActivities=[
                fact("2023-12-31", 500, start="2023-01-01", filed="2025-02-14")],
        )
        rec = [r for r in P.parse_history("T", facts) if r.filed == "2024-02-15"][0]
        self.assertIsNone(rec.values["operating_cash_flow"])

    def test_history_defaults_to_today_rather_than_to_everything(self):
        """There is deliberately no "give me all rows" function. The default is today, which is
        the only date on which the newest filing is the right answer."""
        db = make_db()
        fh.store_history(db, "AAPL", P.parse_history("AAPL", self.facts))
        rows = fh.history(db, "AAPL")
        self.assertEqual(len(rows), 2)                      # one per period, newest version
        self.assertEqual(rows[0]["period_end"], "2024-12-31")


# =============================================================================================
# 2. CURRENCY — the failure that looks entirely plausible
# =============================================================================================

class Currency(unittest.TestCase):

    def test_an_ifrs_filer_in_euros_is_parsed_and_labelled_as_euros(self):
        facts = payload("ifrs-full", "EUR",
                        Revenue=[fact("2024-12-31", 28_000, start="2024-01-01",
                                      filed="2025-02-12", form="20-F")])
        records = P.parse_history("ASML", facts)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].taxonomy, "ifrs-full")
        self.assertEqual(records[0].currency, "EUR")
        self.assertEqual(records[0].values["revenue"], 28_000)

    def test_a_non_usd_period_refuses_to_be_combined_with_a_dollar_price(self):
        """The one flag every valuation calculation in v3 has to check. A EUR revenue against a
        USD market cap produces a P/E wrong by roughly the exchange rate and completely ordinary
        to look at — the exact class of bug this project keeps hitting."""
        db = make_db()
        facts = payload("ifrs-full", "EUR",
                        Revenue=[fact("2024-12-31", 28_000, start="2024-01-01",
                                      filed="2025-02-12", form="20-F")])
        fh.store_history(db, "ASML", P.parse_history("ASML", facts))
        row = fh.history(db, "ASML")[0]
        self.assertEqual(row["currency"], "EUR")
        self.assertFalse(row["can_combine_with_usd_prices"])

    def test_a_us_filer_is_cleared_for_price_based_valuation(self):
        db = make_db()
        facts = payload(Revenues=[fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")])
        fh.store_history(db, "AAPL", P.parse_history("AAPL", facts))
        self.assertTrue(fh.history(db, "AAPL")[0]["can_combine_with_usd_prices"])

    def test_a_stray_foreign_currency_figure_is_dropped_rather_than_mixed(self):
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")]),
            "GrossProfit": ("EUR", [fact("2024-12-31", 60, start="2024-01-01", filed="2025-02-01")]),
        })
        rec = P.parse_history("T", facts)[0]
        self.assertEqual(rec.values["revenue"], 100)
        self.assertIsNone(rec.values["gross_profit"])
        self.assertTrue(any("currencies" in w for w in rec.warnings))

    def test_share_counts_are_read_from_the_shares_unit_never_from_a_dollar_block(self):
        """A share count read out of a USD block is a dollar figure wearing a share count's name,
        and it feeds straight into market capitalisation."""
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")]),
            "WeightedAverageNumberOfDilutedSharesOutstanding": (
                "shares", [fact("2024-12-31", 15_400_000_000, start="2024-01-01",
                                filed="2025-02-01")]),
        })
        rec = P.parse_history("AAPL", facts)[0]
        self.assertEqual(rec.values["diluted_shares"], 15_400_000_000)

    def test_a_share_count_reported_only_in_dollars_is_refused(self):
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")]),
            "WeightedAverageNumberOfDilutedSharesOutstanding": (
                "USD", [fact("2024-12-31", 999, start="2024-01-01", filed="2025-02-01")]),
        })
        self.assertIsNone(P.parse_history("T", facts)[0].values["diluted_shares"])

    def test_unit_selection_is_deterministic_not_dictionary_order(self):
        """The old rule ended in "whatever unit comes out first", which for a multi-currency
        filer is a coin toss deciding what currency every downstream number is in."""
        units = {"DKK": [1, 2, 3], "EUR": [1, 2, 3, 4]}
        first = SecEdgarProvider._select_unit(units, "currency")
        second = SecEdgarProvider._select_unit(dict(reversed(list(units.items()))), "currency")
        self.assertEqual(first[1], second[1])
        self.assertEqual(first[1], "EUR")      # more entries wins, ties broken alphabetically


# =============================================================================================
# 3. FRAMEWORK — us-gaap and ifrs-full must never mix within one company
# =============================================================================================

class Taxonomy(unittest.TestCase):

    def test_a_us_filer_resolves_to_us_gaap(self):
        facts = payload(Revenues=[fact("2024-12-31", 1, start="2024-01-01", filed="2025-01-01")])
        self.assertEqual(P.detect_taxonomy(facts["facts"]), "us-gaap")

    def test_an_ifrs_filer_resolves_to_ifrs_full(self):
        facts = payload("ifrs-full", "EUR",
                        Revenue=[fact("2024-12-31", 1, start="2024-01-01", filed="2025-01-01",
                                      form="20-F")])
        self.assertEqual(P.detect_taxonomy(facts["facts"]), "ifrs-full")

    def test_no_data_at_all_falls_back_to_us_gaap_preserving_old_behaviour(self):
        self.assertEqual(P.detect_taxonomy({}), "us-gaap")

    def test_concepts_are_never_taken_from_the_losing_taxonomy(self):
        """A return on equity built from us-gaap operating income and ifrs-full equity belongs to
        no accounting standard. The taxonomy is decided once and then binds every concept."""
        facts = {"cik": 1, "facts": {
            "us-gaap": {"Revenues": {"units": {"USD": [
                fact("2023-12-31", 100, start="2023-01-01", filed="2024-02-01"),
                fact("2024-12-31", 110, start="2024-01-01", filed="2025-02-01")]}}},
            # A single stray IFRS equity tag — the company is plainly a US filer.
            "ifrs-full": {"Equity": {"units": {"EUR": [
                fact("2024-12-31", 5000, filed="2025-02-01")]}}},
        }}
        rec = P.parse_history("T", facts)[0]
        self.assertEqual(rec.taxonomy, "us-gaap")
        self.assertIsNone(rec.values["stockholders_equity"])


# =============================================================================================
# 4. THE NEW LINE ITEMS — the ones whose absence capped coverage at ~43%
# =============================================================================================

class NewLineItems(unittest.TestCase):

    def test_every_previously_missing_concept_now_has_a_tag_chain(self):
        """These are the specific gaps named in the feasibility report: capital allocation scored
        0% and balance-sheet strength 5% purely because nobody asked EDGAR for these tags."""
        for concept in ("diluted_shares", "basic_shares", "interest_expense",
                        "depreciation_amortisation", "buybacks", "dividends_paid",
                        "acquisitions", "total_assets", "current_assets", "current_liabilities",
                        "total_liabilities", "rnd_expense"):
            self.assertTrue(tags_for(concept, "us-gaap"), concept)
            self.assertTrue(tags_for(concept, "ifrs-full"), concept)

    def test_the_cover_page_share_count_is_found_though_it_postdates_the_year_end(self):
        """THE BUG THIS WOULD HAVE SHIPPED. A cover-page share count is dated when the filing was
        prepared, always AFTER the year it accompanies — Apple's FY2025 ended 27 September and the
        10-K was filed 31 October. Under the default ±15-day window that fact sits 20-plus days
        from the period end and was silently discarded, so every US filer came back with no share
        count at all: no market cap, no P/E, no enterprise value, no FCF yield. The whole
        valuation block, lost to a date window."""
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2025-09-27", 416e9, start="2024-09-29",
                                      filed="2025-10-31")]),
        })
        facts["facts"]["dei"] = {"EntityCommonStockSharesOutstanding": {"units": {"shares": [
            fact("2025-10-17", 14_840_000_000, filed="2025-10-31")]}}}
        rec = P.parse_history("AAPL", facts)[0]
        self.assertEqual(rec.values["shares_outstanding"], 14_840_000_000)

    def test_a_share_count_from_before_the_year_end_is_not_pulled_forward(self):
        """The window is asymmetric on purpose. Widening it backwards as well is what lets one
        year's count attach itself to the previous year."""
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2025-09-27", 416e9, start="2024-09-29",
                                      filed="2025-10-31")]),
        })
        facts["facts"]["dei"] = {"EntityCommonStockSharesOutstanding": {"units": {"shares": [
            fact("2025-06-30", 15_100_000_000, filed="2025-10-31")]}}}
        self.assertIsNone(P.parse_history("AAPL", facts)[0].values["shares_outstanding"])

    def test_the_wide_window_cannot_reach_into_the_next_fiscal_year(self):
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2024-09-28", 391e9, start="2023-09-30",
                                      filed="2024-11-01")]),
        })
        facts["facts"]["dei"] = {"EntityCommonStockSharesOutstanding": {"units": {"shares": [
            fact("2025-10-17", 14_840_000_000, filed="2025-10-31")]}}}   # 384 days later
        self.assertIsNone(P.parse_history("AAPL", facts)[0].values["shares_outstanding"])

    def test_the_dei_namespace_is_searched_before_the_companys_own_taxonomy(self):
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")]),
            "CommonStockSharesOutstanding": ("shares", [fact("2024-12-31", 111,
                                                             filed="2025-02-01")]),
        })
        facts["facts"]["dei"] = {"EntityCommonStockSharesOutstanding": {"units": {"shares": [
            fact("2025-01-20", 999, filed="2025-02-01")]}}}
        self.assertEqual(P.parse_history("T", facts)[0].values["shares_outstanding"], 999)

    def test_an_ifrs_filer_without_a_dei_count_falls_back_to_its_own_taxonomy(self):
        """NVO's ENTIRE dei namespace holds one tag and it is not a share count. A dei-only rule
        left the field permanently empty; this is the fallback that fixes it."""
        facts = multi_unit_payload("ifrs-full", {
            "Revenue": ("DKK", [fact("2024-12-31", 290e9, start="2024-01-01", filed="2025-02-05",
                                     form="20-F")]),
            "NumberOfSharesOutstanding": ("shares", [fact("2024-12-31", 4_440_000_000,
                                                          filed="2025-02-05", form="20-F")]),
        })
        rec = P.parse_history("NVO", facts)[0]
        self.assertEqual(rec.taxonomy, "ifrs-full")
        self.assertEqual(rec.values["shares_outstanding"], 4_440_000_000)

    def test_novo_nordisks_real_diluted_share_tag_is_recognised(self):
        """`AdjustedWeightedAverageShares` was read off NVO's live filings via the tag
        diagnostic. My first two guesses at this tag name were both wrong and the field sat empty
        — which is why the diagnostic exists rather than a third guess."""
        facts = multi_unit_payload("ifrs-full", {
            "Revenue": ("DKK", [fact("2024-12-31", 290e9, start="2024-01-01", filed="2025-02-05",
                                     form="20-F")]),
            "AdjustedWeightedAverageShares": ("shares", [
                fact("2024-12-31", 4_460_000_000, start="2024-01-01", filed="2025-02-05",
                     form="20-F")]),
            "WeightedAverageShares": ("shares", [
                fact("2024-12-31", 4_430_000_000, start="2024-01-01", filed="2025-02-05",
                     form="20-F")]),
        })
        v = P.parse_history("NVO", facts)[0].values
        self.assertEqual(v["diluted_shares"], 4_460_000_000)
        self.assertEqual(v["basic_shares"], 4_430_000_000)

    def test_a_balance_sheet_instant_fact_survives_the_full_year_duration_filter(self):
        """Instant facts have no `start`. An early version of the duration filter would have
        dropped every balance-sheet line in the file."""
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")]),
            "Assets": ("USD", [fact("2024-12-31", 4200, filed="2025-02-01")]),
        })
        self.assertEqual(P.parse_history("T", facts)[0].values["total_assets"], 4200)

    def test_debt_sums_current_and_noncurrent_within_one_period_only(self):
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")]),
            "LongTermDebtNoncurrent": ("USD", [fact("2024-12-31", 900, filed="2025-02-01")]),
            "LongTermDebtCurrent": ("USD", [fact("2024-12-31", 100, filed="2025-02-01")]),
        })
        self.assertEqual(P.parse_history("T", facts)[0].values["total_debt"], 1000)

    def test_debt_falls_back_to_a_single_aggregate_tag_when_the_pair_is_absent(self):
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")]),
            "LongTermDebt": ("USD", [fact("2024-12-31", 750, filed="2025-02-01")]),
        })
        self.assertEqual(P.parse_history("T", facts)[0].values["total_debt"], 750)

    def test_no_debt_reported_is_none_not_zero(self):
        """A company with no debt tag and a company with no debt are different claims, and only
        one of them makes an interest-coverage ratio infinite."""
        facts = payload(Revenues=[fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")])
        self.assertIsNone(P.parse_history("T", facts)[0].values["total_debt"])

    def test_every_declared_field_appears_on_every_record_even_when_unreported(self):
        facts = payload(Revenues=[fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")])
        rec = P.parse_history("T", facts)[0]
        self.assertEqual(set(rec.values), set(HISTORY_VALUE_FIELDS))
        self.assertIsNone(rec.values["buybacks"])


# =============================================================================================
# 5. STORAGE, SCHEMA AND COVERAGE
# =============================================================================================

class Storage(unittest.TestCase):

    def _facts(self):
        years = [("2020-12-31", 100), ("2021-12-31", 200), ("2022-12-31", 300),
                 ("2023-12-31", 400), ("2024-12-31", 500)]
        return payload(Revenues=[
            fact(end, val, start=f"{int(end[:4])}-01-01", filed=f"{int(end[:4]) + 1}-02-01",
                 fy=int(end[:4]))
            for end, val in years])

    def test_the_schema_columns_match_the_declared_field_list(self):
        """THE DRIFT GUARD. HISTORY_VALUE_FIELDS is the source of truth; a concept added there
        without a column would otherwise be dropped silently at write time — the value would be
        parsed correctly, stored nowhere, and read back as None forever."""
        db = make_db()
        cols = {r["name"] for r in db.execute("PRAGMA table_info(fundamentals_history)").fetchall()}
        for f in HISTORY_VALUE_FIELDS:
            self.assertIn(f, cols, f"{f} is declared but has no column")

    def test_five_years_of_history_round_trip(self):
        db = make_db()
        written = fh.store_history(db, "AAPL", P.parse_history("AAPL", self._facts()))
        self.assertEqual(written, 5)
        rows = fh.history(db, "AAPL")
        self.assertEqual([r["revenue"] for r in rows], [500, 400, 300, 200, 100])

    def test_restoring_the_same_history_twice_does_not_duplicate_rows(self):
        db = make_db()
        records = P.parse_history("AAPL", self._facts())
        fh.store_history(db, "AAPL", records)
        fh.store_history(db, "AAPL", records)
        self.assertEqual(fh.count(db, "AAPL"), 5)

    def test_a_short_provider_response_never_erases_stored_years(self):
        """Upsert, not delete-and-replace. A provider hiccup returning one year must not wipe
        four good ones — they are still true statements about what was filed and when."""
        db = make_db()
        fh.store_history(db, "AAPL", P.parse_history("AAPL", self._facts()))
        short = payload(Revenues=[fact("2024-12-31", 500, start="2024-01-01", filed="2025-02-01")])
        fh.store_history(db, "AAPL", P.parse_history("AAPL", short))
        self.assertEqual(fh.count(db, "AAPL"), 5)

    def test_storing_nothing_writes_nothing_and_does_not_raise(self):
        self.assertEqual(fh.store_history(make_db(), "AAPL", []), 0)

    def test_coverage_names_the_fields_that_came_back_empty(self):
        """A single coverage percentage would let a fully-populated R&D line paper over a
        completely absent share count. Those are not equally survivable gaps."""
        db = make_db()
        fh.store_history(db, "AAPL", P.parse_history("AAPL", self._facts()))
        cov = fh.coverage(db, "AAPL")
        self.assertEqual(cov["periods"], 5)
        self.assertEqual(cov["per_field_periods"]["revenue"], 5)
        self.assertIn("diluted_shares", cov["fields_never_reported"])
        self.assertIn("buybacks", cov["fields_never_reported"])

    def test_coverage_respects_the_as_of_date(self):
        db = make_db()
        fh.store_history(db, "AAPL", P.parse_history("AAPL", self._facts()))
        self.assertEqual(fh.coverage(db, "AAPL", as_of_filed="2022-06-01")["periods"], 2)

    def test_warnings_are_stored_as_json_and_read_back_as_a_list(self):
        db = make_db()
        facts = multi_unit_payload("us-gaap", {
            "Revenues": ("USD", [fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")]),
            "GrossProfit": ("EUR", [fact("2024-12-31", 60, start="2024-01-01", filed="2025-02-01")]),
        })
        fh.store_history(db, "AAPL", P.parse_history("AAPL", facts))
        row = fh.history(db, "AAPL")[0]
        self.assertIsInstance(row["warnings"], list)
        self.assertTrue(row["warnings"])
        self.assertNotIn("warnings_json", row)


class Bounds(unittest.TestCase):
    """Neon's transfer allowance was exhausted once already. An unbounded history walk is
    exactly the shape of that mistake."""

    def test_history_is_capped_at_twelve_fiscal_years(self):
        facts = payload(Revenues=[
            fact(f"{y}-12-31", y, start=f"{y}-01-01", filed=f"{y + 1}-02-01")
            for y in range(2000, 2025)])
        self.assertEqual(len({r.period_end for r in P.parse_history("T", facts)}), 12)

    def test_a_heavily_restated_year_keeps_the_original_and_the_recent_versions(self):
        """The original report is what a point-in-time score just after the period needs; the
        recent ones are what today needs. The middle restatements are the ones dropped, and the
        cap is stated here rather than left implicit."""
        facts = payload(Revenues=[
            fact("2023-12-31", 100 + i, start="2023-01-01", filed=f"2024-0{i + 1}-01")
            for i in range(8)])
        vintages = sorted(r.filed for r in P.parse_history("T", facts))
        self.assertEqual(len(vintages), 4)
        self.assertEqual(vintages[0], "2024-01-01")     # the original survives
        self.assertEqual(vintages[-1], "2024-08-01")    # so does the newest


# =============================================================================================
# 6. ISOLATION — Build B must not have moved any existing number
# =============================================================================================

class BuildBChangedNothingExisting(unittest.TestCase):
    """Every one of the fifty tickers files under US-GAAP in dollars, so the taxonomy detector
    returns "us-gaap" for all of them and every lookup takes the same branch it took before.
    That is the argument; these tests are the evidence.
    """

    def test_the_us_gaap_snapshot_path_produces_identical_figures(self):
        facts = payload(
            Revenues=[fact("2025-01-26", 130_497, start="2024-01-29", filed="2025-02-26", fy=2025),
                      fact("2024-01-28", 60_922, start="2023-01-30", filed="2024-02-21", fy=2024)],
            GrossProfit=[fact("2025-01-26", 97_858, start="2024-01-29", filed="2025-02-26")],
            OperatingIncomeLoss=[fact("2025-01-26", 81_453, start="2024-01-29", filed="2025-02-26")],
        )
        from unittest.mock import patch
        p = SecEdgarProvider()
        p._ticker_map = {"NVDA": 1045810}
        with patch.object(p, "_get", return_value=facts):
            f = p.get_fundamentals("NVDA")
        self.assertEqual(f.revenue, 130_497)
        self.assertEqual(f.revenue_prior, 60_922)
        self.assertEqual(f.gross_profit, 97_858)
        self.assertEqual(f.operating_income, 81_453)
        self.assertEqual(f.as_of, "2025-01-26")
        self.assertEqual(f.taxonomy, "us-gaap")
        self.assertEqual(f.currency, "USD")

    def test_a_dollar_filer_gets_no_currency_warning(self):
        """The warning exists for the two 20-F filers. If it fired for US companies it would be
        noise on 48 of 50 rows, and noise is how a real warning gets ignored."""
        facts = payload(Revenues=[fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")])
        from unittest.mock import patch
        p = SecEdgarProvider()
        p._ticker_map = {"AAPL": 320193}
        with patch.object(p, "_get", return_value=facts):
            f = p.get_fundamentals("AAPL")
        self.assertFalse([w for w in f.warnings if "currency" in w.lower()])

    def test_the_history_table_is_additive_and_touches_nothing_else(self):
        """Build B writes to exactly one new table. If a future change makes it write to
        `fundamentals` as well, the two would drift and the page would show one thing while the
        score used another."""
        db = make_db()
        fh.store_history(db, "AAPL", P.parse_history("AAPL", payload(
            Revenues=[fact("2024-12-31", 100, start="2024-01-01", filed="2025-02-01")])))
        n = db.execute("SELECT COUNT(*) AS n FROM fundamentals").fetchone()
        self.assertEqual(int(dict(n)["n"]), 0)

    def test_a_provider_without_history_refuses_rather_than_claiming_none_exists(self):
        class Minimal(FundamentalDataProvider):
            name = "minimal"

            def get_fundamentals(self, ticker):
                return None

            def get_earnings_info(self, ticker):
                return None

        with self.assertRaises(NotImplementedError):
            Minimal().get_fundamentals_history("AAPL")


class NoStreamingOrTradingCode(unittest.TestCase):
    """Standing structural guard, extended to the files Build B adds. This app has no WebSocket,
    no streaming subscription and no order placement anywhere, and these tests exist so that
    remains a checkable fact rather than a recollection."""

    FILES = ("providers/edgar_concepts.py", "providers/sec_edgar_provider.py",
             "services/fundamentals_history_service.py")

    def test_no_streaming_or_order_placement_in_the_new_files(self):
        root = Path(__file__).resolve().parent.parent
        for rel in self.FILES:
            text = (root / rel).read_text().lower()
            for banned in ("websocket", "websockets", "wss://", "submit_order", "place_order",
                           "stop_loss", "stoploss"):
                self.assertNotIn(banned, text, f"{banned} appeared in {rel}")


if __name__ == "__main__":
    unittest.main()
