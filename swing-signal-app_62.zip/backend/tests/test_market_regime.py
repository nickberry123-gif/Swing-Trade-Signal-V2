"""
Unit tests for services/market_regime.py. get_bars_df is mocked (network-free); the
classification logic itself is exercised against synthetic bar series with known trends.
"""
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import market_regime


def trending_bars(n=300, start=100.0, daily_drift=0.15, noise=0.3, seed=0):
    rng = np.random.default_rng(seed)
    closes = start + np.cumsum(daily_drift + rng.normal(0, noise, n))
    closes = np.maximum(closes, 1.0)
    ts = [(datetime(2024, 1, 1) + timedelta(days=i)).isoformat() for i in range(n)]
    return pd.DataFrame({
        "ts": ts, "open": closes, "high": closes + 0.5, "low": closes - 0.5,
        "close": closes, "volume": [1_000_000.0] * n,
    })


def flat_bars(n=300, price=100.0):
    ts = [(datetime(2024, 1, 1) + timedelta(days=i)).isoformat() for i in range(n)]
    return pd.DataFrame({
        "ts": ts, "open": [price] * n, "high": [price + 0.2] * n, "low": [price - 0.2] * n,
        "close": [price] * n, "volume": [1_000_000.0] * n,
    })


def empty_bars():
    return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])


class TestClassifyThresholds(unittest.TestCase):
    def test_boundaries(self):
        self.assertEqual(market_regime.classify(10), "STRONG BULL")
        self.assertEqual(market_regime.classify(7), "STRONG BULL")
        self.assertEqual(market_regime.classify(6.99), "BULL")
        self.assertEqual(market_regime.classify(3), "BULL")
        self.assertEqual(market_regime.classify(2.99), "NEUTRAL")
        self.assertEqual(market_regime.classify(0), "NEUTRAL")
        self.assertEqual(market_regime.classify(-2), "NEUTRAL")
        self.assertEqual(market_regime.classify(-2.01), "CAUTIOUS")
        self.assertEqual(market_regime.classify(-6), "CAUTIOUS")
        self.assertEqual(market_regime.classify(-6.01), "BEAR")
        self.assertEqual(market_regime.classify(-100), "BEAR")


class TestComputeMarketRegime(unittest.TestCase):
    @patch("services.market_regime.get_bars_df")
    def test_strong_uptrend_everywhere_yields_bullish_regime(self, mock_get_bars):
        def side_effect(db, ticker, timeframe):
            if ticker == market_regime.VIX_PROXY_TICKER:
                # Falling VIXY = calming volatility = bullish contribution
                return trending_bars(daily_drift=-0.05, seed=1), {}
            return trending_bars(daily_drift=0.2, seed=hash(ticker) % 100), {}

        mock_get_bars.side_effect = side_effect
        result = market_regime.compute_market_regime(db=None)

        self.assertIn(result["regime"], ("BULL", "STRONG BULL"))
        self.assertIsNotNone(result["regime_score"])
        self.assertEqual(result["vix_status"], "UNAVAILABLE")
        self.assertEqual(result["vix_proxy_ticker"], "VIXY")
        self.assertIn("components", result["detail"])

    @patch("services.market_regime.get_bars_df")
    def test_strong_downtrend_everywhere_yields_bearish_regime(self, mock_get_bars):
        def side_effect(db, ticker, timeframe):
            if ticker == market_regime.VIX_PROXY_TICKER:
                # Rising VIXY sharply = fear spike = bearish contribution
                return trending_bars(daily_drift=0.5, start=20, seed=2), {}
            return trending_bars(daily_drift=-0.2, start=300, seed=hash(ticker) % 100), {}

        mock_get_bars.side_effect = side_effect
        result = market_regime.compute_market_regime(db=None)

        self.assertIn(result["regime"], ("BEAR", "CAUTIOUS"))

    @patch("services.market_regime.get_bars_df")
    def test_flat_market_yields_neutral(self, mock_get_bars):
        def side_effect(db, ticker, timeframe):
            return flat_bars(), {}

        mock_get_bars.side_effect = side_effect
        result = market_regime.compute_market_regime(db=None)
        self.assertEqual(result["regime"], "NEUTRAL")

    @patch("services.market_regime.get_bars_df")
    def test_missing_spy_qqq_data_is_unavailable_not_fabricated(self, mock_get_bars):
        def side_effect(db, ticker, timeframe):
            if ticker in ("SPY", "QQQ"):
                return empty_bars(), {"error": "no data"}
            return flat_bars(), {}

        mock_get_bars.side_effect = side_effect
        result = market_regime.compute_market_regime(db=None)
        self.assertEqual(result["regime"], "UNAVAILABLE")
        self.assertIn("error", result)
        self.assertNotIn("regime_score", result) if "regime_score" not in result else \
            self.assertIsNone(result.get("regime_score"))

    @patch("services.market_regime.get_bars_df")
    def test_partial_sector_data_does_not_crash(self, mock_get_bars):
        def side_effect(db, ticker, timeframe):
            if ticker in ("SMH", "SOXX"):
                return empty_bars(), {"error": "no data"}
            return flat_bars(), {}

        mock_get_bars.side_effect = side_effect
        result = market_regime.compute_market_regime(db=None)
        self.assertIn(result["regime"], ("STRONG BULL", "BULL", "NEUTRAL", "CAUTIOUS", "BEAR"))
        unknown = result["detail"]["components"]["sector_breadth"]["detail"]["unknown"]
        self.assertIn("SMH", unknown)
        self.assertIn("SOXX", unknown)


if __name__ == "__main__":
    unittest.main()
