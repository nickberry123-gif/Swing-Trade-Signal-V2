"""
Tests for the background-job plumbing, and for the two bugs that produced it.

BUG 1 — the result was computed and then thrown away.
Every long analysis opened a database connection, spent 16-19 minutes computing with it idle,
then wrote the result. Neon closes idle connections after a few minutes, so the write failed with
"SSL connection has been closed unexpectedly" and the whole run was lost. The error handler then
tried to record the failure down the same dead connection and threw again, silently, leaving the
row saying 'running' forever.

BUG 2 — run_backtest accepted a `strategy` and never applied it.
It used the strategy for the display name and dropped it before simulating, so every Strategy Lab
comparison run through the Backtest page returned baseline numbers under the chosen strategy's
name. Two deliberately opposite strategies produced byte-identical trades.

The tests below are written so that they fail if either bug is reintroduced, and — importantly —
so that they cannot pass vacuously. Each one first proves its fixture actually distinguishes the
thing under test.
"""
import copy
import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import database

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import backtest_service as bt
from services import annual_backtest_service as ab
from services import job_runner
from services.strategy_service import default_strategy
from tests.test_annual_backtest import bars, make_db

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def loose_strategy():
    s = copy.deepcopy(default_strategy())
    s.update(name="LOOSE", buy_threshold=30, strong_buy_threshold=40)
    s["exits"] = {"max_holding_days": 5, "exit_on_signal": False, "profit_target_pct": 2.0}
    return s


def tight_strategy():
    s = copy.deepcopy(default_strategy())
    s.update(name="TIGHT", buy_threshold=90, strong_buy_threshold=95)
    s["exits"] = {"max_holding_days": 60, "exit_on_signal": True, "profit_target_pct": 25.0}
    return s


def fingerprint(trades):
    """Identity of a trade list — not merely its length.

    An earlier test of mine compared trade COUNTS between two very different strategies that
    happened to produce the same number of trades, and passed while the bug was live.
    """
    return [(t["ticker"], t["entry_date"], t.get("exit_date"), t.get("exit_reason"),
             t.get("return_pct")) for t in trades]


class StrategyIsActuallyApplied(unittest.TestCase):
    """BUG 2. The Backtest page silently ran the baseline whatever you picked."""

    @classmethod
    def setUpClass(cls):
        cls.df = bars(900, seed=3)
        cls.bars_by = {"AAA": cls.df, "SPY": bars(900, seed=4), "QQQ": bars(900, seed=5)}
        cls.cfg = {"use_regime": True, "max_holding_days": 40, "slippage_pct": 0.0,
                   "exit_on_signal": True}
        cls.regime = bt._regime_by_date(cls.bars_by)

    def test_the_engine_responds_to_strategy_at_all(self):
        """Guards against a vacuous suite: if this fails, the tests below prove nothing."""
        base = bt._simulate_ticker("AAA", self.df, self.regime, self.cfg)
        loose = bt._simulate_ticker("AAA", self.df, self.regime, self.cfg, loose_strategy())
        tight = bt._simulate_ticker("AAA", self.df, self.regime, self.cfg, tight_strategy())
        self.assertNotEqual(fingerprint(base), fingerprint(loose))
        self.assertNotEqual(fingerprint(base), fingerprint(tight))
        self.assertNotEqual(fingerprint(loose), fingerprint(tight))

    def test_run_backtest_actually_applies_the_strategy(self):
        db = make_db()
        base = bt.run_backtest(db, ["AAA"], self.bars_by, self.cfg)
        loose = bt.run_backtest(db, ["AAA"], self.bars_by, self.cfg, loose_strategy())
        tight = bt.run_backtest(db, ["AAA"], self.bars_by, self.cfg, tight_strategy())

        self.assertNotEqual(fingerprint(base["trades"]), fingerprint(loose["trades"]),
                            "run_backtest ignored the strategy — the original bug")
        self.assertNotEqual(fingerprint(base["trades"]), fingerprint(tight["trades"]))
        self.assertNotEqual(fingerprint(loose["trades"]), fingerprint(tight["trades"]))

    def test_run_backtest_matches_the_engine_it_claims_to_run(self):
        """The page's numbers must equal what _simulate_ticker produces for that strategy."""
        db = make_db()
        strategy = loose_strategy()
        via_page = bt.run_backtest(db, ["AAA"], self.bars_by, self.cfg, strategy)
        direct = bt._simulate_ticker("AAA", self.df, self.regime, self.cfg, strategy)
        self.assertEqual(fingerprint(via_page["trades"]), fingerprint(direct))

    def test_no_strategy_still_means_baseline(self):
        """The control has to keep meaning exactly what it always meant."""
        db = make_db()
        self.assertEqual(
            fingerprint(bt.run_backtest(db, ["AAA"], self.bars_by, self.cfg)["trades"]),
            fingerprint(bt._simulate_ticker("AAA", self.df, self.regime, self.cfg)))

    def test_comparison_runs_both_sides_on_the_same_strategy(self):
        """Annual vs continuous is only a test of the calendar boundary if both sides agree."""
        db = make_db()
        strategy = loose_strategy()
        result = ab.run_comparison(db, ["AAA"], self.bars_by, self.cfg, strategy)
        continuous_direct = bt.run_backtest(db, ["AAA"], self.bars_by, self.cfg, strategy)
        self.assertEqual(result["difference"]["trades_continuous"],
                         continuous_direct["overall"]["trades"])
        # And the continuous side must NOT equal the baseline, or the strategy was dropped again.
        baseline = bt.run_backtest(db, ["AAA"], self.bars_by, self.cfg)
        self.assertNotEqual(result["difference"]["trades_continuous"],
                            baseline["overall"]["trades"])


class ProgressReporting(unittest.TestCase):

    def test_run_backtest_reports_each_ticker(self):
        db = make_db()
        seen = []
        bars_by = {"AAA": bars(600, seed=1), "BBB": bars(600, seed=2),
                   "SPY": bars(600, seed=4), "QQQ": bars(600, seed=5)}
        bt.run_backtest(db, ["AAA", "BBB"], bars_by, {"use_regime": True},
                        progress=seen.append)
        self.assertTrue(any("AAA" in m for m in seen), seen)
        self.assertTrue(any("BBB" in m for m in seen), seen)

    def test_annual_reports_its_own_pass_separately(self):
        db = make_db()
        seen = []
        bars_by = {"AAA": bars(900, seed=1), "SPY": bars(900, seed=4), "QQQ": bars(900, seed=5)}
        ab.run_comparison(db, ["AAA"], bars_by, {"use_regime": True}, None, progress=seen.append)
        self.assertTrue(any("Annual-reset pass" in m for m in seen), seen)
        self.assertTrue(any("Continuous backtest" in m for m in seen), seen)

    def test_progress_is_not_required(self):
        """Callers that pass no progress callback must be unaffected."""
        db = make_db()
        bars_by = {"AAA": bars(600, seed=1), "SPY": bars(600, seed=4), "QQQ": bars(600, seed=5)}
        with_cb = bt.run_backtest(db, ["AAA"], bars_by, {"use_regime": True}, progress=lambda m: None)
        without = bt.run_backtest(db, ["AAA"], bars_by, {"use_regime": True})
        self.assertEqual(fingerprint(with_cb["trades"]), fingerprint(without["trades"]))


class StaleRunReaper(unittest.TestCase):

    def _run_row(self, db, created_at, status="running"):
        db.execute("INSERT INTO annual_backtest_runs (created_at, config_json, status) "
                   "VALUES (?, '{}', ?)", (created_at, status))
        db.commit()
        return db.execute("SELECT MAX(id) AS id FROM annual_backtest_runs").fetchone()["id"]

    def setUp(self):
        self.db = make_db()

    def _iso(self, minutes_ago):
        return (datetime.now(timezone.utc) - timedelta(minutes=minutes_ago)).isoformat()

    def test_old_running_row_is_reaped(self):
        run_id = self._run_row(self.db, self._iso(120))
        self.assertEqual(job_runner.reap_stale_runs(self.db, "annual_backtest_runs"), 1)
        row = self.db.execute("SELECT status, error FROM annual_backtest_runs WHERE id=?",
                              (run_id,)).fetchone()
        self.assertEqual(dict(row)["status"], "failed")
        self.assertIn("stopped without finishing", dict(row)["error"])

    def test_recent_running_row_is_left_alone(self):
        """A slow run must never be reaped out from under itself."""
        run_id = self._run_row(self.db, self._iso(5))
        self.assertEqual(job_runner.reap_stale_runs(self.db, "annual_backtest_runs"), 0)
        self.assertEqual(
            dict(self.db.execute("SELECT status FROM annual_backtest_runs WHERE id=?",
                                 (run_id,)).fetchone())["status"], "running")

    def test_a_run_at_nineteen_minutes_survives(self):
        """The real annual run took 19.3 minutes. The threshold must clear it comfortably."""
        self._run_row(self.db, self._iso(19))
        self.assertEqual(job_runner.reap_stale_runs(self.db, "annual_backtest_runs"), 0)

    def test_completed_rows_are_never_touched(self):
        run_id = self._run_row(self.db, self._iso(500), status="complete")
        job_runner.reap_stale_runs(self.db, "annual_backtest_runs")
        self.assertEqual(
            dict(self.db.execute("SELECT status FROM annual_backtest_runs WHERE id=?",
                                 (run_id,)).fetchone())["status"], "complete")

    def test_unparseable_timestamp_does_not_reap_and_does_not_raise(self):
        run_id = self._run_row(self.db, "not a date")
        self.assertEqual(job_runner.reap_stale_runs(self.db, "annual_backtest_runs"), 0)
        self.assertEqual(
            dict(self.db.execute("SELECT status FROM annual_backtest_runs WHERE id=?",
                                 (run_id,)).fetchone())["status"], "running")

    def test_reaper_on_a_missing_table_is_survivable(self):
        self.assertEqual(job_runner.reap_stale_runs(self.db, "no_such_table"), 0)


class ConnectionDiscipline(unittest.TestCase):
    """BUG 1. The rule: no connection is held across the compute."""

    def setUp(self):
        self.tmp = Path("/tmp/job_runner_test.sqlite")
        if self.tmp.exists():
            self.tmp.unlink()
        conn = database.connect(None, str(self.tmp))
        conn.executescript(SCHEMA_PATH.read_text())
        conn.commit()
        conn.execute("INSERT INTO annual_backtest_runs (config_json, status) VALUES ('{}', 'running')")
        conn.commit()
        self.run_id = dict(conn.execute(
            "SELECT MAX(id) AS id FROM annual_backtest_runs").fetchone())["id"]
        conn.close()

        # Every connection the runner opens is wrapped so the test can see, at any instant,
        # exactly how many are still open. No monkeypatching of the database classes themselves —
        # that leaked state into other tests in the first version of this file.
        self._real_open = job_runner.open_db
        self.open_count = 0
        self.total_opened = 0
        test = self

        class TrackedConnection:
            def __init__(self, inner):
                self._inner = inner
                self._closed = False

            def __getattr__(self, name):
                return getattr(self._inner, name)

            def close(self):
                if not self._closed:
                    self._closed = True
                    test.open_count -= 1
                return self._inner.close()

        def tracking_open():
            test.open_count += 1
            test.total_opened += 1
            return TrackedConnection(database.connect(None, str(test.tmp)))

        job_runner.open_db = tracking_open

        import flask
        self.app = flask.Flask(__name__)

    def tearDown(self):
        job_runner.open_db = self._real_open

    def _row(self):
        conn = database.connect(None, str(self.tmp))
        row = dict(conn.execute(
            "SELECT status, error, progress, results_json FROM annual_backtest_runs WHERE id=?",
            (self.run_id,)).fetchone())
        conn.close()
        return row

    def test_no_connection_is_open_while_computing(self):
        """The heart of it. If any connection is live during compute, the bug can recur."""
        open_during_compute = []

        def compute(loaded, progress):
            open_during_compute.append(self.open_count)
            # Progress writes happen mid-compute in real runs; they must open and close, never
            # leave anything behind.
            progress("halfway")
            open_during_compute.append(self.open_count)
            return {"ok": True}

        job_runner.run_background_job(
            self.app, table="annual_backtest_runs", run_id=self.run_id, label="test",
            load=lambda db: "loaded", compute=compute)

        self.assertEqual(open_during_compute, [0, 0],
                         "a database connection was held open across the compute")
        self.assertEqual(self._row()["status"], "complete")

    def test_the_tracking_would_notice_a_held_connection(self):
        """Proves the assertion above is not vacuous by deliberately holding one open."""
        seen = []

        def leaky_load(db):
            return job_runner.open_db()      # opened and never closed

        def compute(loaded, progress):
            seen.append(self.open_count)
            return {"ok": True}

        job_runner.run_background_job(
            self.app, table="annual_backtest_runs", run_id=self.run_id, label="test",
            load=leaky_load, compute=compute)
        self.assertEqual(seen, [1], "the leak detector failed to detect a deliberate leak")

    def test_result_is_saved_on_a_connection_opened_after_the_compute(self):
        opened_before_compute = []

        def compute(loaded, progress):
            opened_before_compute.append(self.total_opened)
            return {"value": 42}

        job_runner.run_background_job(
            self.app, table="annual_backtest_runs", run_id=self.run_id, label="test",
            load=lambda db: None, compute=compute)

        # More connections were opened after compute began => the save used a fresh one.
        self.assertGreater(self.total_opened, opened_before_compute[0])
        row = self._row()
        self.assertEqual(row["status"], "complete")
        self.assertIn("42", row["results_json"])

    def test_failure_is_recorded_not_swallowed(self):
        def compute(loaded, progress):
            raise RuntimeError("boom in the compute")

        job_runner.run_background_job(
            self.app, table="annual_backtest_runs", run_id=self.run_id, label="test",
            load=lambda db: None, compute=compute)

        row = self._row()
        self.assertEqual(row["status"], "failed")
        self.assertIn("boom in the compute", row["error"])

    def test_a_dead_connection_at_save_time_still_records_the_failure(self):
        """The exact production failure: the save throws. The row must not stay 'running'."""
        def exploding_mark_complete(table, run_id, result):
            raise RuntimeError("SSL connection has been closed unexpectedly")

        real = job_runner.mark_complete
        job_runner.mark_complete = exploding_mark_complete
        try:
            job_runner.run_background_job(
                self.app, table="annual_backtest_runs", run_id=self.run_id, label="test",
                load=lambda db: None, compute=lambda loaded, progress: {"ok": True})
        finally:
            job_runner.mark_complete = real

        row = self._row()
        self.assertEqual(row["status"], "failed",
                         "a failed save left the row saying 'running' — the original bug")
        self.assertIn("SSL connection has been closed", row["error"])

    def test_progress_failures_never_abort_a_run(self):
        """Losing a progress line is cosmetic; it must not destroy a 20-minute result.

        The first version of this test asserted status == 'failed' and passed — because a
        throwing progress write really did kill the run. The assertion was written to match the
        behaviour instead of to the requirement. It is 'complete' that is correct here.
        """
        real = job_runner.write_progress
        job_runner.write_progress = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("no db"))
        try:
            job_runner.run_background_job(
                self.app, table="annual_backtest_runs", run_id=self.run_id, label="test",
                load=lambda db: None,
                compute=lambda loaded, progress: (progress("mid"), {"survived": True})[1])
        finally:
            job_runner.write_progress = real

        row = self._row()
        self.assertEqual(row["status"], "complete",
                         "a failed progress write destroyed an otherwise good result")
        self.assertIn("survived", row["results_json"])

    def test_progress_is_written_and_visible_mid_run(self):
        """Assert the intermediate value, not just the terminal one."""
        observed = []

        def compute(loaded, progress):
            progress("Annual-reset pass — NVDA (7 of 50)")
            observed.append(self._row()["progress"])   # read it back from the database
            return {"ok": True}

        job_runner.run_background_job(
            self.app, table="annual_backtest_runs", run_id=self.run_id, label="test",
            load=lambda db: None, compute=compute)

        self.assertEqual(observed, ["Annual-reset pass — NVDA (7 of 50)"])
        self.assertEqual(self._row()["progress"], "Complete.")


if __name__ == "__main__":
    unittest.main()


class WorkerRecyclingMustStayOff(unittest.TestCase):
    """The polling that watches a long run must not be what kills it.

    gunicorn was configured with max_requests = 400, to recycle the worker periodically against a
    slow leak. Every long analysis runs in a background THREAD inside that worker, and the client
    polls its status every few seconds. A 22-minute run generated roughly 380 status polls plus
    the market ticker, crossed 400, and gunicorn recycled the worker exactly as told:

        19:55:20  [66] Autorestarting worker after current request.
        19:55:21  [66] Worker exiting (pid: 66)

    The computation went with it and the run row was left saying 'running', because the thread
    that would have recorded the failure no longer existed. The longer a run takes the more polls
    it generates, so the runs most likely to be killed were the expensive ones.
    """

    def setUp(self):
        self.conf = (Path(__file__).resolve().parent.parent / "gunicorn.conf.py").read_text()

    def _setting(self, name):
        """The EXECUTABLE value, not the prose.

        The first version of this test asserted the string "max_requests = 400" was absent, and
        failed against the comment explaining why it was removed. Asserting on documentation
        rather than on code is how a test ends up enforcing the wrong thing.
        """
        namespace = {}
        exec(compile(self.conf, "gunicorn.conf.py", "exec"), namespace)   # noqa: S102
        return namespace.get(name)

    def test_max_requests_is_disabled(self):
        self.assertEqual(self._setting("max_requests"), 0)

    def test_the_jitter_is_disabled_too(self):
        """Jitter alone would still recycle, just less predictably."""
        self.assertEqual(self._setting("max_requests_jitter"), 0)

    def test_the_timeout_is_still_generous_enough_for_a_cold_cache(self):
        self.assertGreaterEqual(self._setting("timeout"), 600)

    def test_the_reason_is_recorded_next_to_the_setting(self):
        """A future tidy-up would otherwise 'restore' it as a sensible default."""
        self.assertIn("Autorestarting worker", self.conf)
        self.assertIn("background", self.conf.lower())

    def test_the_worker_class_still_allows_background_work(self):
        """gthread, not sync: under sync the background thread starves request handling."""
        self.assertEqual(self._setting("worker_class"), "gthread")

    def test_no_poller_hammers_the_server_faster_than_ten_seconds(self):
        """Fewer polls is both less load on a 0.15-CPU box and less recycling pressure."""
        import re
        frontend = Path(__file__).resolve().parent.parent.parent / "frontend" / "static" / "js"
        for js in frontend.glob("*.js"):
            for delay in re.findall(r"setTimeout\(r, (\d+)\)", js.read_text()):
                with self.subTest(file=js.name):
                    self.assertGreaterEqual(int(delay), 10000,
                                            f"{js.name} polls every {int(delay)/1000}s")
