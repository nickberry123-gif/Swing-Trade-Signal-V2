"""
Signal v2: two scores, three gates, the change detector, and the no-stop-loss boundary.

WHAT THESE TESTS ARE FOR. Not "does the function return a number" — every scoring bug this
project has hit returned a perfectly plausible number. They are for the specific claims v2 makes:
that a gate cannot be bought off with a high score, that an unknown component leaves the
denominator instead of scoring zero, that no exit fires because the price moved against the
position, and that the change detector cannot be blinded by refreshing the page.
"""
import json
import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import signal_v2_service as v2  # noqa: E402

# ------------------------------------------------------------------ look-ahead

def _fake_analysis(**over):
    base = {
        "ticker": "TEST", "bars_used": 400, "data_status": "OK",
        "reference_price": 100.0, "sma50": 95.0, "sma200": 90.0, "sma200_slope": 1.2,
        "ema20": 99.0, "ema50": 97.0, "macd": 1.0, "macd_signal": 0.5, "macd_hist": 0.5,
        "rsi14": 52.0, "adx": 27.0, "roc": 4.0, "atr14": 3.0, "atr_pct": 3.0,
        "relative_volume": 1.4, "volume_trend": "Increasing",
        "support_low": 92.0, "support_high": 98.0,
        "resistance_low": 112.0, "resistance_high": 120.0,
        "swing_high": 118.0, "high_52w": 125.0, "low_52w": 70.0, "high_20d": 104.0,
        "trend_label": "Uptrend",
        "relative_strength": {"labels": {5: "Strong", 20: "Strong", 50: "In-line", 200: "Strong"},
                              "rs_spy_20d": 6.5},
    }
    base.update(over)
    return base


# ------------------------------------------------------------------ persistence

class _FakeCursor:
    def __init__(self, rows):
        self._rows = rows

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def fetchall(self):
        return self._rows


class _RowsDB:
    """A stand-in for the database that records whether anything tried to START A COMPUTATION.

    The assertion this exists for is behavioural. Checking the returned payload would not catch a
    read that quietly kicked off ninety seconds of work in a background thread — the payload
    would look identical either way.
    """

    def __init__(self, rows, run=None):
        self.rows = rows
        self.run = run
        self.threads_started = 0
        self.writes = []

    def execute(self, sql, params=None):
        upper = " ".join(sql.split()).upper()
        if "FROM SIGNAL_V2_LATEST" in upper:
            return _FakeCursor(self.rows)
        if "FROM SIGNAL_V2_RUNS" in upper:
            return _FakeCursor([self.run] if self.run else [])
        if "INSERT INTO SIGNAL_V2_RUNS" in upper:
            self.threads_started += 1
        self.writes.append((sql, params))
        return _FakeCursor([])

    def commit(self):
        pass

    def rollback(self):
        pass


class _FakeDB:
    """Records what was written, so the throttle can be asserted on writes rather than on a
    return value that would look the same either way."""

    def __init__(self, existing=None):
        self.existing = existing
        self.writes = []
        self.commits = 0

    def execute(self, sql, params=None):
        if sql.strip().upper().startswith("SELECT"):
            return _FakeCursor([self.existing] if self.existing else [])
        self.writes.append((sql, params))
        return _FakeCursor([])

    def commit(self):
        self.commits += 1

    def rollback(self):
        pass


def _result(ts, hold=80.0):
    return {"ticker": "TEST", "data_status": "OK", "hold_quality": hold, "entry_quality": 70.0,
            "hold_band": "BUY", "entry_band": "WATCH", "action": "BUY",
            "state": {"ts": ts, "hold_quality": hold}}




class TestSignalV2(unittest.TestCase):

    # ------------------------------------------------------------------ weighting

    def test_unknown_component_leaves_the_denominator_it_does_not_score_zero(self):
        """The single most important property. A missing component must not be a silent failure.

        Two perfect components out of a possible three: the honest answer is 100 out of the 55 points
        that could be measured, NOT 100*(55/100)=55 as if the third had failed.
        """
        out = v2._weighted({"long_term_trend": 1.0, "relative_strength": 1.0,
                            "financial_quality": None, "market_regime": None, "momentum": None},
                           v2.HOLD_WEIGHTS)
        assert out["score"] == 100.0
        assert out["weight_available"] == 55
        assert out["weight_unknown"] == 45
        assert set(out["unknown"]) == {"financial_quality", "market_regime", "momentum"}


    def test_a_failed_component_and_a_missing_component_produce_different_scores(self):
        """Guards the distinction directly, because collapsing them is the easy mistake."""
        failed = v2._weighted({"long_term_trend": 1.0, "relative_strength": 0.0}, v2.HOLD_WEIGHTS)
        missing = v2._weighted({"long_term_trend": 1.0, "relative_strength": None}, v2.HOLD_WEIGHTS)
        assert abs(failed["score"] - 54.5) < 0.1   # 30 of 55
        assert missing["score"] == 100.0                          # 30 of 30
        assert failed["score"] != missing["score"]


    def test_every_component_unknown_gives_no_score_rather_than_zero(self):
        out = v2._weighted({}, v2.HOLD_WEIGHTS)
        assert out["score"] is None
        assert out["weight_available"] == 0


    def test_component_fractions_are_clamped_not_trusted(self):
        out = v2._weighted({"long_term_trend": 3.0, "relative_strength": -2.0}, v2.HOLD_WEIGHTS)
        assert out["components"]["long_term_trend"]["fraction"] == 1.0
        assert out["components"]["relative_strength"]["fraction"] == 0.0


    # ------------------------------------------------------------------ gatekeepers

    def test_a_perfect_score_cannot_buy_off_a_failed_gate(self):
        """The whole point of the redesign. 100 with a broken trend is still not permission."""
        gates = v2.gatekeepers(100.0, long_term_trend_positive=False, regime_label="BULL")
        assert gates["all_passed"] is False
        assert gates["blocked_by"] == ["Long-term trend is positive"]


    def test_unknown_trend_is_not_treated_as_a_positive_trend(self):
        """"Cannot confirm the trend is positive" must not pass a gate that says it is positive."""
        gates = v2.gatekeepers(90.0, long_term_trend_positive=None, regime_label="BULL")
        assert gates["all_passed"] is False


    def test_all_three_gates_must_pass_together(self):
        assert v2.gatekeepers(80.0, True, "BULL")["all_passed"] is True
        assert v2.gatekeepers(74.9, True, "BULL")["all_passed"] is False
        assert v2.gatekeepers(80.0, True, "BEARISH")["all_passed"] is False


    def test_missing_regime_does_not_block_but_is_disclosed(self):
        """An unknown regime is not evidence of a bearish one. It blocks nothing, and says so."""
        gates = v2.gatekeepers(80.0, True, None)
        assert gates["all_passed"] is True
        assert "UNKNOWN" in gates["checks"][2]["detail"]


    # ------------------------------------------------------------------ classification

    def test_good_company_bad_price_is_its_own_answer(self):
        """The state a single 0-100 number cannot express, which is why there are two."""
        out = v2.classify(hold_score=88.0, entry_score=30.0,
                          long_term_trend_positive=True, regime_label="BULL")
        assert out["action"] == "GOOD STOCK, POOR ENTRY"
        assert out["hold_band"] == "BUY"
        assert out["entry_band"] == "AVOID"


    def test_buy_requires_both_scores_and_the_gates(self):
        out = v2.classify(88.0, 80.0, True, "BULL")
        assert out["action"] == "BUY"


    def test_blocked_by_a_gate_reads_watch_and_names_the_gate(self):
        out = v2.classify(88.0, 80.0, False, "BULL")
        assert out["action"] == "WATCH"
        assert "Long-term trend is positive" in out["reason"]


    def test_low_hold_score_is_avoid_regardless_of_a_great_entry(self):
        """A cheap price on a broken business is not an opportunity."""
        out = v2.classify(40.0, 99.0, True, "BULL")
        assert out["action"] == "AVOID"


    def test_no_hold_score_is_unavailable_never_a_default(self):
        out = v2.classify(None, 90.0, True, "BULL")
        assert out["action"] == "UNAVAILABLE"


    # ------------------------------------------------------------------ the no-stop-loss boundary

    def test_no_sell_trigger_fires_because_the_price_fell(self):
        """THE PROJECT'S HARDEST RULE, ASSERTED DIRECTLY.

        A holding whose price has collapsed 40% but whose structure is intact — trend still positive,
        relative strength unchanged, score healthy — must produce NO sell trigger. If a price fall
        alone can trigger an exit, a stop-loss has been reintroduced under another name.
        """
        current = {"hold_quality": 80.0, "long_term_trend_positive": True,
                   "relative_strength_pct": 5.0, "price": 60.0, "breakout_failed": False}
        previous = {"hold_quality": 82.0, "long_term_trend_positive": True,
                    "relative_strength_pct": 5.0, "price": 100.0}
        out = v2.sell_triggers(current, previous)
        assert out["any"] is False, f"a price fall alone fired: {out['fired']}"


    def test_sell_triggers_fire_on_structure_not_price(self):
        current = {"hold_quality": 40.0, "long_term_trend_positive": False,
                   "relative_strength_pct": -8.0, "breakout_failed": True}
        previous = {"hold_quality": 80.0, "long_term_trend_positive": True,
                    "relative_strength_pct": 6.0}
        fired = {f["trigger"] for f in v2.sell_triggers(current, previous)["fired"]}
        assert fired == {"Score collapsed below the line", "Long-term trend broke",
                         "Relative strength deteriorated", "Breakout failed"}


    def test_the_excluded_stop_losses_are_named_in_the_output(self):
        """Documented in the payload, not only in a comment, so the page can show WHY they are absent."""
        out = v2.sell_triggers({"hold_quality": 80.0}, None)
        joined = " ".join(out["excluded_by_design"]).lower()
        assert "stop" in joined and "support" in joined


    def test_no_module_level_symbol_mentions_a_stop_loss_as_a_field(self):
        """A structural guard: v2 must not grow a stop_loss/stop_price field later by accident."""
        banned = [n for n in dir(v2) if "stop_loss" in n.lower() or n.lower().endswith("stop")]
        assert banned == []


    def test_risk_reward_is_a_measurement_and_produces_no_exit(self):
        ratio, frac, note = v2._risk_reward(price=100.0, target=130.0, support_low=90.0)
        assert ratio == 3.0
        assert frac == 1.0
        # It returns numbers and prose. There is no level, action, or order anywhere in the result.
        assert isinstance(note, str)


    def test_risk_reward_refuses_to_invent_a_floor_that_is_not_there(self):
        """Price below the support zone has no measured floor beneath it. None, not a made-up number."""
        ratio, frac, note = v2._risk_reward(price=85.0, target=130.0, support_low=90.0)
        assert ratio is None and frac is None
        assert "invented" in note


    def test_risk_reward_is_zero_not_negative_when_price_is_past_the_target(self):
        ratio, frac, _ = v2._risk_reward(price=140.0, target=130.0, support_low=90.0)
        assert ratio == 0.0 and frac == 0.0


    # ------------------------------------------------------------------ change detection

    def test_first_reading_reports_no_changes_and_says_why(self):
        out = v2.detect_changes({"hold_quality": 80.0}, None)
        assert out["first_reading"] is True
        assert out["changes"] == []
        assert "next update" in out["note"]


    def test_a_material_fall_in_hold_quality_is_reported(self):
        out = v2.detect_changes({"hold_quality": 68.0, "hold_band": "WATCH"},
                                {"hold_quality": 84.0, "hold_band": "BUY"})
        kinds = {c["change"] for c in out["changes"]}
        assert "Hold quality fell" in kinds
        assert out["material"] is True


    def test_noise_below_the_threshold_is_not_reported(self):
        """A monitor that reports every wobble gets ignored, and an ignored monitor is worse than none."""
        out = v2.detect_changes({"hold_quality": 80.0, "hold_band": "BUY"},
                                {"hold_quality": 83.0, "hold_band": "BUY"})
        assert out["changes"] == []
        assert out["material"] is False


    def test_a_small_move_across_a_band_boundary_is_reported_anyway(self):
        """2 points across 75 changes the action; 9 points inside a band does not."""
        out = v2.detect_changes({"hold_quality": 74.0, "hold_band": "WATCH"},
                                {"hold_quality": 76.0, "hold_band": "BUY"})
        assert any(c["change"] == "Hold band changed" for c in out["changes"])


    def test_the_events_the_user_asked_not_to_miss_are_all_detected(self):
        current = {"hold_quality": 80.0, "hold_band": "BUY", "long_term_trend_positive": False,
                   "relative_strength_pct": -6.0, "above_sma200": False, "new_52w_low": True}
        previous = {"hold_quality": 80.0, "hold_band": "BUY", "long_term_trend_positive": True,
                    "relative_strength_pct": 9.0, "above_sma200": True, "new_52w_low": False}
        kinds = {c["change"] for c in v2.detect_changes(current, previous)["changes"]}
        assert kinds == {"Long-term trend broke", "Relative strength rolled over",
                         "Lost the 200-day average", "New 52-week low"}


    def test_a_recovering_trend_is_not_reported_as_a_break(self):
        """Direction matters: not-positive to positive is good news, not an alert."""
        out = v2.detect_changes({"hold_quality": 80.0, "hold_band": "BUY",
                                 "long_term_trend_positive": True, "above_sma200": True},
                                {"hold_quality": 80.0, "hold_band": "BUY",
                                 "long_term_trend_positive": False, "above_sma200": False})
        assert out["changes"] == []


    def test_breakout_failure_needs_two_readings_and_is_unknown_with_one(self):
        """"No evidence of a failure" and "evidence of no failure" are different claims."""
        state = {"price": 100.0, "high_20d": 105.0}
        assert v2._breakout_failed(state, None) is None
        # broke out at 110 against a 20-day high of 109, now back at 100
        assert v2._breakout_failed({"price": 100.0, "high_20d": 105.0},
                                   {"price": 110.0, "high_20d": 109.0}) is True
        # never broke out
        assert v2._breakout_failed({"price": 100.0, "high_20d": 105.0},
                                   {"price": 95.0, "high_20d": 109.0}) is False


    # ------------------------------------------------------------------ volatility band

    def test_volatility_prefers_a_workable_range_over_the_quietest_stock(self):
        """Less is NOT better. A stock that moves 0.4% a day will not reach a swing target."""
        quiet, _ = v2._volatility(0.4)
        normal, _ = v2._volatility(3.0)
        wild, _ = v2._volatility(12.0)
        assert normal > quiet
        assert normal > wild


    def test_missing_atr_is_unknown_not_a_middling_guess(self):
        frac, note = v2._volatility(None)
        assert frac is None
        assert "unavailable" in note


    def test_fundamentals_carry_weight_live_and_are_unknown_historically(self):
        """Scoring today with today's figures is using the data. Scoring 2022 with them is look-ahead."""
        quality = {"long_term_quality_score": 90}
        regime = {"regime": "BULL"}
        live = v2.evaluate(_fake_analysis(), regime, quality, live=True)
        hist = v2.evaluate(_fake_analysis(), regime, quality, live=False)

        assert "financial_quality" not in live["hold"]["unknown"]
        assert "financial_quality" in hist["hold"]["unknown"]
        assert hist["hold"]["weight_available"] == live["hold"]["weight_available"] - 20
        assert "not knowable" in hist["notes"]["financial_quality"]


    def test_evaluate_on_a_healthy_stock_produces_a_coherent_whole(self):
        out = v2.evaluate(_fake_analysis(), {"regime": "BULL"}, {"long_term_quality_score": 85})
        assert out["data_status"] == "OK"
        assert out["hold_quality"] is not None and out["entry_quality"] is not None
        assert out["action"] in ("BUY", "GOOD STOCK, POOR ENTRY", "WATCH", "AVOID")
        # The action and the gates must agree — a BUY with a failed gate is the bug v2 exists to stop.
        if out["action"] == "BUY":
            assert out["gatekeepers"]["all_passed"] is True


    def test_a_stock_below_its_200_day_average_can_never_read_buy(self):
        """The gate, end to end, through the real scoring path rather than in isolation."""
        out = v2.evaluate(_fake_analysis(reference_price=80.0, sma200=90.0, sma200_slope=-0.8,
                                         trend_label="Downtrend"),
                          {"regime": "BULL"}, {"long_term_quality_score": 99})
        assert out["action"] != "BUY"
        assert out["state"]["long_term_trend_positive"] is False


    def test_no_bars_reads_unavailable_rather_than_scoring_an_empty_stock(self):
        out = v2.evaluate({"ticker": "TEST", "bars_used": 0, "data_status": "UNAVAILABLE"},
                          {"regime": "BULL"})
        assert out["action"] == "UNAVAILABLE"
        assert out["hold_quality"] is None


    def test_build_state_requires_both_trend_conditions(self):
        """Above the 200 SMA while the 200 SMA falls is not a positive long-term trend."""
        above_but_falling = v2.build_state(_fake_analysis(sma200_slope=-0.5), {"regime": "BULL"})
        assert above_but_falling["long_term_trend_positive"] is False

        unknown_slope = v2.build_state(_fake_analysis(sma200_slope=None), {"regime": "BULL"})
        assert unknown_slope["long_term_trend_positive"] is None


    def test_refreshing_the_page_does_not_erase_the_change_detectors_memory(self):
        """THE FAILURE THIS PREVENTS: the page computes on load and every computation stores a
        reading, so two refreshes a minute apart would make the "previous reading" 60 seconds old.
        Every comparison would then be against a near-identical snapshot and the page would report
        "nothing changed" forever — true over a minute, worthless over the week a holding takes to
        deteriorate."""
        recent = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
        db = _FakeDB()
        v2.save_reading(db, _result(datetime.now(timezone.utc).isoformat()),
                        previous={"ts": recent})
        assert db.writes == [], "a reading was stored only minutes after the last one"


    def test_a_reading_is_stored_once_the_gap_has_passed(self):
        old = (datetime.now(timezone.utc) - timedelta(hours=v2.MIN_SNAPSHOT_GAP_HOURS + 1)).isoformat()
        db = _FakeDB()
        v2.save_reading(db, _result(datetime.now(timezone.utc).isoformat()), previous={"ts": old})
        assert len(db.writes) == 1
        assert db.commits == 1


    def test_the_first_ever_reading_is_always_stored(self):
        db = _FakeDB()
        v2.save_reading(db, _result(datetime.now(timezone.utc).isoformat()), previous=None)
        assert len(db.writes) == 1


    def test_an_unscoreable_stock_is_not_stored_as_a_reading(self):
        """Storing a null-filled row would make the next comparison meaningless."""
        db = _FakeDB()
        v2.save_reading(db, {"ticker": "TEST", "data_status": "UNAVAILABLE"}, previous=None)
        assert db.writes == []


    def test_an_unparseable_timestamp_stores_rather_than_silently_skipping(self):
        """When the age cannot be established, writing loses nothing; skipping loses the reading."""
        db = _FakeDB()
        v2.save_reading(db, _result("not-a-date"), previous={"ts": "not-a-date"})
        assert len(db.writes) == 1


    def test_a_corrupt_stored_snapshot_reads_as_no_previous_reading_not_a_crash(self):
        """The cost is one missed comparison. The alternative is a blank Signals page."""
        db = _FakeDB(existing={"ts": "2026-08-01T00:00:00+00:00", "state_json": "{not json"})
        assert v2.load_previous(db, "TEST") is None


    def test_a_stored_snapshot_round_trips(self):
        state = {"ts": "2026-08-01T00:00:00+00:00", "hold_quality": 77.0, "above_sma200": True}
        db = _FakeDB(existing={"ts": state["ts"], "state_json": json.dumps(state)})
        assert v2.load_previous(db, "TEST") == state


    # -------------------------------------------------------------- earnings flag

    def test_earnings_is_a_flag_and_never_points(self):
        """It was worth 5 points in v1.0, and that was the wrong shape. "Earnings in 3 days"
        must not be quietly offset by a strong MACD inside a single number."""
        out = v2.evaluate(_fake_analysis(), {"regime": "BULL"}, {"long_term_quality_score": 85},
                          earnings_info={"days_until_estimated_report": 3})
        assert out["earnings"]["status"] == "BLACKOUT"
        # It appears nowhere in either score's components.
        assert "earnings" not in out["hold"]["components"]
        assert "earnings" not in out["entry"]["components"]
        assert "earnings" not in out["hold"]["unknown"]

    def test_no_earnings_date_is_unknown_not_assumed_clear(self):
        assert v2._earnings_flag(None)["status"] == "UNKNOWN"
        assert v2._earnings_flag({})["status"] == "UNKNOWN"

    def test_a_distant_earnings_date_reads_clear(self):
        flag = v2._earnings_flag({"days_until_estimated_report": 40})
        assert flag["status"] == "CLEAR" and flag["days"] == 40

    def test_earnings_are_unknown_in_historical_scoring(self):
        """An estimated report date published in 2026 was not knowable in 2022."""
        out = v2.evaluate(_fake_analysis(), {"regime": "BULL"}, live=False,
                          earnings_info={"days_until_estimated_report": 2})
        assert out["earnings"]["status"] == "UNKNOWN"


    # -------------------------------------------------------------- cached reads

    def test_the_displayed_age_is_the_oldest_row_not_the_newest(self):
        """If 49 tickers refreshed a minute ago and one failed three days back, "1 minute ago"
        would be a lie about the table as a whole. The age of a table is the age of its worst row."""
        fresh = datetime.now(timezone.utc).isoformat()
        old = (datetime.now(timezone.utc) - timedelta(days=3)).isoformat()
        db = _RowsDB([
            {"ticker": "AAA", "computed_at": fresh, "result_json": json.dumps({"ticker": "AAA", "hold_quality": 80})},
            {"ticker": "BBB", "computed_at": old, "result_json": json.dumps({"ticker": "BBB", "hold_quality": 60})},
        ])
        results, oldest = v2.load_latest_all(db)
        assert len(results) == 2
        assert oldest == old

    def test_stored_readings_are_ranked_by_hold_quality(self):
        db = _RowsDB([
            {"ticker": "LOW", "computed_at": "2026-08-15T00:00:00+00:00",
             "result_json": json.dumps({"ticker": "LOW", "hold_quality": 40})},
            {"ticker": "HIGH", "computed_at": "2026-08-15T00:00:00+00:00",
             "result_json": json.dumps({"ticker": "HIGH", "hold_quality": 90})},
            {"ticker": "NONE", "computed_at": "2026-08-15T00:00:00+00:00",
             "result_json": json.dumps({"ticker": "NONE", "hold_quality": None})},
        ])
        results, _ = v2.load_latest_all(db)
        assert [r["ticker"] for r in results] == ["HIGH", "LOW", "NONE"]

    def test_one_corrupt_stored_row_does_not_lose_the_other_forty_nine(self):
        db = _RowsDB([
            {"ticker": "GOOD", "computed_at": "2026-08-15T00:00:00+00:00",
             "result_json": json.dumps({"ticker": "GOOD", "hold_quality": 80})},
            {"ticker": "BAD", "computed_at": "2026-08-15T00:00:00+00:00",
             "result_json": "{not json"},
        ])
        results, _ = v2.load_latest_all(db)
        assert [r["ticker"] for r in results] == ["GOOD"]

    def test_a_read_never_computes_inline(self):
        """THE FAILURE THIS PREVENTS: computing 50 tickers inside the page request takes about 90
        seconds, exceeds the gateway timeout, and looks identical to a hung page."""
        db = _RowsDB([{"ticker": "AAA", "computed_at": datetime.now(timezone.utc).isoformat(),
                       "result_json": json.dumps({"ticker": "AAA", "hold_quality": 80,
                                                  "action": "BUY"})}])
        out = v2.read_v2(app=None, db=db, auto_refresh=False)
        assert out["results"][0]["ticker"] == "AAA"
        assert out["stale"] is False
        assert db.threads_started == 0, "a read started a computation"

    def test_an_empty_store_reads_as_stale_and_says_so_rather_than_looking_broken(self):
        db = _RowsDB([])
        out = v2.read_v2(app=None, db=db, auto_refresh=False)
        assert out["stale"] is True
        assert out["results"] == []
        assert "started" in (out["note"] or "")

    def test_an_old_reading_is_stale(self):
        old = (datetime.now(timezone.utc) - timedelta(hours=5)).isoformat()
        db = _RowsDB([{"ticker": "AAA", "computed_at": old,
                       "result_json": json.dumps({"ticker": "AAA", "hold_quality": 80})}])
        out = v2.read_v2(app=None, db=db, auto_refresh=False)
        assert out["stale"] is True
        assert out["age_minutes"] > v2.STALE_AFTER_MINUTES

    def test_a_second_refresh_is_refused_while_one_is_running(self):
        """Fifty tickers of SEC and Alpaca requests fired twice over is how a free-tier rate
        limit gets hit, and the second run would produce the same answer anyway."""
        db = _RowsDB([], run={"id": 1, "created_at": datetime.now(timezone.utc).isoformat(),
                              "status": "running", "progress": "NVDA (1 of 50)", "error": None})
        assert v2.start_refresh(app=None, db=db) is False
        assert db.threads_started == 0

    def test_a_refresh_that_died_is_not_waited_on_forever(self):
        """A server restart mid-refresh would otherwise leave the row saying 'running' for good
        and the page polling it for good."""
        ancient = (datetime.now(timezone.utc)
                   - timedelta(minutes=v2.ABANDONED_RUN_MINUTES + 5)).isoformat()
        db = _RowsDB([], run={"id": 1, "created_at": ancient, "status": "running",
                              "progress": "NVDA (1 of 50)", "error": None})
        state = v2._run_state(db)
        assert state["running"] is False
        assert "restarted" in state["error"]

    def test_the_summary_counts_every_action_and_the_things_needing_attention(self):
        results = [
            {"action": "BUY"}, {"action": "BUY"},
            {"action": "GOOD STOCK, POOR ENTRY"},
            {"action": "WATCH"}, {"action": "AVOID"},
            {"action": "AVOID", "changes": {"material": True}},
            {"action": "WATCH", "sell": {"any": True}},
            {"action": "BUY", "earnings": {"status": "BLACKOUT"}},
        ]
        s = v2.summarise(results)
        assert s == {"tickers": 8, "buy": 3, "good_stock_poor_entry": 1, "watch": 2, "avoid": 2,
                     "unavailable": 0, "material_changes": 1, "sell_triggers": 1,
                     "standing_concerns": 0, "earnings_blackouts": 1}

    # ------------------------------------------ standing conditions vs news (the cry-wolf bug)

    def test_a_long_broken_trend_is_standing_not_breaking_news_every_day(self):
        """THE BUG THIS FIXES, and it shipped. The first version fired "Long-term trend broke"
        whenever the trend was not positive rather than when it stopped being positive. On live
        data it lit up 18 of 50 tickers at once, and a stock under its 200-day average for two
        years would have fired "broke" every day forever."""
        unchanged = {"hold_quality": 70.0, "long_term_trend_positive": False}
        previous = {"hold_quality": 70.0, "long_term_trend_positive": False}
        out = v2.sell_triggers(unchanged, previous)
        assert out["any"] is False, f"a standing condition was reported as news: {out['fired']}"
        assert out["any_standing"] is True
        assert out["standing"][0]["condition"] == "Long-term trend is not positive"

    def test_a_trend_that_actually_broke_this_reading_is_news(self):
        out = v2.sell_triggers({"hold_quality": 70.0, "long_term_trend_positive": False},
                               {"hold_quality": 70.0, "long_term_trend_positive": True})
        assert [f["trigger"] for f in out["fired"]] == ["Long-term trend broke"]
        assert out["standing"] == []

    def test_a_score_that_has_been_low_for_months_is_standing_not_news(self):
        out = v2.sell_triggers({"hold_quality": 40.0}, {"hold_quality": 42.0})
        assert out["any"] is False
        assert out["standing"][0]["condition"] == "Score is below the line"

    def test_a_score_crossing_the_line_this_reading_is_news(self):
        out = v2.sell_triggers({"hold_quality": 51.0}, {"hold_quality": 62.0})
        assert [f["trigger"] for f in out["fired"]] == ["Score collapsed below the line"]

    def test_with_no_previous_reading_nothing_can_be_called_news(self):
        """Without a comparison, nothing has been OBSERVED to change. Reporting a first-ever
        reading as a break would make every stock alarm on the day it is first seen."""
        out = v2.sell_triggers({"hold_quality": 30.0, "long_term_trend_positive": False}, None)
        assert out["any"] is False
        assert len(out["standing"]) == 2

    def test_the_summary_separates_news_from_standing_concerns(self):
        results = [
            {"action": "AVOID", "sell": {"any": True, "any_standing": False}},
            {"action": "AVOID", "sell": {"any": False, "any_standing": True}},
            {"action": "WATCH", "sell": {"any": False, "any_standing": True}},
        ]
        s = v2.summarise(results)
        assert s["sell_triggers"] == 1
        assert s["standing_concerns"] == 2


if __name__ == "__main__":
    unittest.main()
