"""
C1 — Company Health scoring.

WHAT THESE TESTS ARE FOR. The model is a set of numbers that were approved before any company was
scored, and the single largest risk to it is not a coding error — it is that the numbers get
adjusted later, once results are visible, until the output agrees with somebody's intuition. That
is how a measurement stops being a measurement. So a good part of this file asserts the SPEC
ITSELF: the weights, the anchors, the gates, the bands. If any of them changes, a test fails and
the change has to be a decision rather than a drift.

The rest tests the properties that make the score trustworthy:

  * missing data reduces CONFIDENCE, never quality — an unmeasurable metric leaves the
    denominator and never scores zero;
  * a company that cannot be measured is reported as unmeasured, not as weak;
  * the score never touches a price, a market capitalisation, or anything derived from one;
  * a red flag needs enough of its category measured to mean anything.

The fixtures are shaped, not named. No test asserts a result for a real ticker, because the first
50-stock run has to stay genuinely out-of-sample against a specification written without it.
"""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
from config import STOCK_UNIVERSE  # noqa: E402
from providers.edgar_concepts import HISTORY_VALUE_FIELDS  # noqa: E402
from providers.fundamentals_base import AnnualPeriod  # noqa: E402
from services import company_health as ch  # noqa: E402
from services import data_validation_service as dv  # noqa: E402
from services import fundamentals_history_service as fh  # noqa: E402

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"
TODAY = date.today()


def ago(days: int) -> str:
    return (TODAY - timedelta(days=days)).isoformat()


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]))
    conn.commit()
    return conn


def period(period_end, filed, ticker="AAPL", **values):
    full = {f: None for f in HISTORY_VALUE_FIELDS}
    full.update(values)
    return AnnualPeriod(ticker=ticker, source="test", period_end=period_end, filed=filed,
                        taxonomy="us-gaap", currency="USD", form="10-K", values=full)


def metric(value, verdict=dv.OK):
    return {"value": value, "verdict": verdict, "reason": None}


def all_metrics(value_map=None, verdict=dv.OK):
    """Every scored metric present, so a test can vary one thing at a time."""
    out = {}
    for _weight, definitions in ch.COMPANY_HEALTH_MODEL.values():
        for name, _direction, _w, adequate, _s in definitions:
            out[name] = metric(adequate, verdict)
    for name, value in (value_map or {}).items():
        out[name] = value if isinstance(value, dict) else metric(value)
    return out


# =================================================================================================
# THE SPECIFICATION, PINNED
# =================================================================================================
class TheApprovedSpecification(unittest.TestCase):
    """Approved before any company was scored. A change here must be a decision, not a drift."""

    def test_the_six_categories_and_their_weights(self):
        self.assertEqual(
            {name: weight for name, (weight, _m) in ch.COMPANY_HEALTH_MODEL.items()},
            {"profitability_returns": 25, "growth_durability": 20, "cashflow_quality": 15,
             "balance_sheet": 15, "moat_evidence": 15, "capital_allocation": 10})

    def test_the_weights_sum_to_one_hundred(self):
        self.assertEqual(sum(w for w, _m in ch.COMPANY_HEALTH_MODEL.values()), 100)

    def test_every_approved_anchor(self):
        expected = {
            "roic_pct": (ch.HIGHER, 8.0, 15.0, 25.0),
            "roe_pct": (ch.HIGHER, 8.0, 18.0, 30.0),
            "roa_pct": (ch.HIGHER, 2.0, 7.0, 14.0),
            "gross_margin_pct": (ch.HIGHER, 5.0, 15.0, 30.0),
            "operating_margin_pct": (ch.HIGHER, 3.0, 12.0, 25.0),
            "net_margin_pct": (ch.HIGHER, 2.0, 10.0, 20.0),
            "revenue_cagr_pct": (ch.HIGHER, 2.0, 8.0, 15.0),
            "eps_cagr_pct": (ch.HIGHER, 3.0, 10.0, 20.0),
            "revenue_consistency": (ch.HIGHER, 50.0, 75.0, 100.0),
            "fcf_margin_pct": (ch.HIGHER, 3.0, 10.0, 20.0),
            "fcf_to_net_income": (ch.HIGHER, 0.6, 0.9, 1.1),
            "ocf_to_net_income": (ch.HIGHER, 0.9, 1.2, 1.5),
            "accruals_ratio": (ch.LOWER, 0.15, 0.05, -0.05),
            "net_debt_to_ebitda": (ch.LOWER, 3.5, 1.5, 0.0),
            "interest_coverage": (ch.HIGHER, 3.0, 8.0, 20.0),
            "current_ratio": (ch.HIGHER, 0.8, 1.1, 1.5),
            "roic_persistence": (ch.HIGHER, 40.0, 65.0, 85.0),
            "gross_margin_stability": (ch.HIGHER, 60.0, 80.0, 93.0),
            "operating_margin_stability": (ch.HIGHER, 50.0, 72.0, 88.0),
            "revenue_resilience": (ch.HIGHER, -15.0, -2.0, 5.0),
            "share_change_pct": (ch.LOWER, 3.0, 0.0, -2.0),
            "distribution_sustainability": (ch.LOWER, 1.3, 1.0, 0.8),
        }
        actual = {name: (d, w, a, s)
                  for _weight, defs in ch.COMPANY_HEALTH_MODEL.values()
                  for name, d, w, a, s in defs}
        self.assertEqual(actual, expected)

    def test_the_gates_and_bands(self):
        self.assertEqual(ch.COVERAGE_GATE_PCT, 75.0)
        self.assertEqual(ch.RED_FLAG_CATEGORY_SCORE, 25.0)
        self.assertEqual(ch.RED_FLAG_MIN_CATEGORY_COVERAGE_PCT, 50.0)
        self.assertEqual(ch.CAP_AT_N_RED_FLAGS, 2)
        self.assertEqual(ch.SOLVENCY_CATEGORY, "balance_sheet")
        self.assertEqual(ch.VERDICT_BANDS,
                         ((80.0, "STRONG"), (65.0, "SOLID"), (50.0, "ADEQUATE"), (0.0, "WEAK")))

    def test_no_metric_appears_in_two_categories(self):
        """One measurement driving two categories is a defect this project has already had once,
        when revenue consistency sat in both Growth and Moat and quietly drove 35% of the score."""
        seen = []
        for _weight, defs in ch.COMPANY_HEALTH_MODEL.values():
            seen.extend(name for name, *_rest in defs)
        self.assertEqual(len(seen), len(set(seen)))

    def test_company_health_touches_no_price_based_metric(self):
        health_inputs = {name for _w, defs in ch.COMPANY_HEALTH_MODEL.values()
                         for name, *_rest in defs}
        self.assertEqual(health_inputs & set(dv.MARKET_CAP_DEPENDENT), set())


# =================================================================================================
# THE SCORING CURVE
# =================================================================================================
class TheScoringCurve(unittest.TestCase):

    def test_the_three_anchors_score_zero_sixty_and_one_hundred(self):
        self.assertEqual(ch.score_metric(8.0, ch.HIGHER, 8.0, 15.0, 25.0), 0.0)
        self.assertEqual(ch.score_metric(15.0, ch.HIGHER, 8.0, 15.0, 25.0), 60.0)
        self.assertEqual(ch.score_metric(25.0, ch.HIGHER, 8.0, 15.0, 25.0), 100.0)

    def test_interpolation_is_linear_between_anchors(self):
        self.assertAlmostEqual(ch.score_metric(11.5, ch.HIGHER, 8.0, 15.0, 25.0), 30.0)
        self.assertAlmostEqual(ch.score_metric(20.0, ch.HIGHER, 8.0, 15.0, 25.0), 80.0)

    def test_there_is_no_cliff_at_a_round_number(self):
        """The reason bands were rejected: 14.9% and 15.1% describe the same company.

        Crossing the ADEQUATE anchor changes the gradient — 60 points over the lower span, 40 over
        the upper — so the two are not exactly equal. What matters is that the step is small: a
        banded model would jump the full 40 points at the same boundary."""
        low = ch.score_metric(14.9, ch.HIGHER, 8.0, 15.0, 25.0)
        high = ch.score_metric(15.1, ch.HIGHER, 8.0, 15.0, 25.0)
        self.assertLess(abs(high - low), 2.0)
        self.assertLess(abs(high - low), (ch.STRONG_SCORE - ch.ADEQUATE_SCORE) / 10.0)

    def test_values_outside_the_anchors_clamp(self):
        self.assertEqual(ch.score_metric(-50.0, ch.HIGHER, 8.0, 15.0, 25.0), 0.0)
        self.assertEqual(ch.score_metric(500.0, ch.HIGHER, 8.0, 15.0, 25.0), 100.0)

    def test_an_inverted_metric_scores_the_other_way_round(self):
        """Leverage, accruals and dilution: lower is better."""
        self.assertEqual(ch.score_metric(3.5, ch.LOWER, 3.5, 1.5, 0.0), 0.0)
        self.assertEqual(ch.score_metric(1.5, ch.LOWER, 3.5, 1.5, 0.0), 60.0)
        self.assertEqual(ch.score_metric(0.0, ch.LOWER, 3.5, 1.5, 0.0), 100.0)
        self.assertEqual(ch.score_metric(-2.0, ch.LOWER, 3.5, 1.5, 0.0), 100.0)

    def test_an_inverted_metric_interpolates_correctly_in_the_middle(self):
        self.assertAlmostEqual(ch.score_metric(2.5, ch.LOWER, 3.5, 1.5, 0.0), 30.0)

    def test_a_negative_strong_anchor_works(self):
        """Accruals: STRONG is -0.05, which is below zero. A sign error here would invert the
        whole cash-flow category silently."""
        self.assertEqual(ch.score_metric(0.15, ch.LOWER, 0.15, 0.05, -0.05), 0.0)
        self.assertEqual(ch.score_metric(0.05, ch.LOWER, 0.15, 0.05, -0.05), 60.0)
        self.assertEqual(ch.score_metric(-0.05, ch.LOWER, 0.15, 0.05, -0.05), 100.0)

    def test_none_scores_nothing_rather_than_zero(self):
        self.assertIsNone(ch.score_metric(None, ch.HIGHER, 1.0, 2.0, 3.0))


# =================================================================================================
# MISSING DATA REDUCES CONFIDENCE, NEVER QUALITY
# =================================================================================================
class MissingDataNeverScoresZero(unittest.TestCase):

    def test_an_unavailable_metric_leaves_the_denominator(self):
        """The rule the whole app is built on, applied to scoring. Two companies identical except
        that one has an unmeasurable metric must score the same, with different coverage."""
        full = ch.evaluate(all_metrics(), dv.USABLE)
        partial = ch.evaluate(
            all_metrics({"roa_pct": {"value": None, "verdict": dv.UNAVAILABLE, "reason": "x"}}),
            dv.USABLE)
        self.assertEqual(full["score"], partial["score"])
        self.assertLess(partial["coverage_pct"], full["coverage_pct"])

    def test_a_not_applicable_metric_also_leaves_the_denominator(self):
        result = ch.evaluate(
            all_metrics({"distribution_sustainability":
                         {"value": None, "verdict": dv.NOT_APPLICABLE, "reason": "no payout"}}),
            dv.USABLE)
        cap = result["categories"]["capital_allocation"]
        self.assertEqual(cap["coverage_pct"], 50.0)
        self.assertNotIn("distribution_sustainability", cap["metrics_scored"])

    def test_an_implausible_metric_is_not_scored(self):
        """A figure that could not be true must not become a number in a score."""
        result = ch.evaluate(
            all_metrics({"roic_pct": {"value": 4000.0, "verdict": dv.IMPLAUSIBLE, "reason": "x"}}),
            dv.USABLE)
        self.assertNotIn("roic_pct", result["categories"]["profitability_returns"]["metrics_scored"])

    def test_a_wholly_unmeasurable_category_leaves_the_overall_denominator(self):
        metrics = all_metrics()
        for name, *_rest in ch.COMPANY_HEALTH_MODEL["balance_sheet"][1]:
            metrics[name] = {"value": None, "verdict": dv.UNAVAILABLE, "reason": "x"}
        result = ch.evaluate(metrics, dv.USABLE)
        self.assertIsNone(result["categories"]["balance_sheet"]["score"])
        # Everything else was at its ADEQUATE anchor, so the score stays 60 rather than falling.
        self.assertAlmostEqual(result["score"], 60.0, places=1)

    def test_below_the_coverage_gate_there_is_no_score_at_all(self):
        """A company this app cannot measure is not a weak company, and reporting it as one would
        be the most damaging error available here."""
        metrics = all_metrics()
        for category in ("profitability_returns", "growth_durability", "cashflow_quality"):
            for name, *_rest in ch.COMPANY_HEALTH_MODEL[category][1]:
                metrics[name] = {"value": None, "verdict": dv.UNAVAILABLE, "reason": "x"}
        result = ch.evaluate(metrics, dv.USABLE)
        self.assertLess(result["coverage_pct"], ch.COVERAGE_GATE_PCT)
        self.assertIsNone(result["score"])
        self.assertEqual(result["verdict"], ch.INSUFFICIENT)
        self.assertIn("not the same as a weak company", result["verdict_reason"])


# =================================================================================================
# RED FLAGS AND CAPPING
# =================================================================================================
class RedFlagsAndCapping(unittest.TestCase):

    def _with_weak_category(self, category, coverage_metrics=None):
        metrics = all_metrics()
        definitions = ch.COMPANY_HEALTH_MODEL[category][1]
        for i, (name, direction, weak, _a, _s) in enumerate(definitions):
            if coverage_metrics is not None and i >= coverage_metrics:
                metrics[name] = {"value": None, "verdict": dv.UNAVAILABLE, "reason": "x"}
            else:
                metrics[name] = metric(weak)
        return metrics

    def test_a_category_below_twenty_five_raises_a_red_flag(self):
        result = ch.evaluate(self._with_weak_category("growth_durability"), dv.USABLE)
        self.assertIn("growth_durability", result["red_flags"])
        self.assertTrue(result["categories"]["growth_durability"]["red_flag"])

    def test_one_red_flag_alone_does_not_cap_the_verdict(self):
        """One weak area can be deliberate strategy or a bad year, so it is flagged and left to
        speak through the score rather than overriding it.

        Capital allocation is used here (weight 10) rather than a heavier category, because with a
        heavy one the SCORE alone falls into the WEAK band and the test would pass whether capping
        worked or not — proving nothing. Here the score stays above the WEAK boundary, so the
        verdict can only be WEAK if capping fired, and it must not."""
        result = ch.evaluate(self._with_weak_category("capital_allocation"), dv.USABLE)
        self.assertEqual(result["red_flags"], ["capital_allocation"])
        self.assertFalse(result["capped"])
        self.assertGreaterEqual(result["score"], 50.0)
        self.assertNotEqual(result["verdict"], ch.WEAK)

    def test_two_red_flags_cap_the_verdict_at_weak(self):
        metrics = self._with_weak_category("growth_durability")
        for name, _d, weak, _a, _s in ch.COMPANY_HEALTH_MODEL["moat_evidence"][1]:
            metrics[name] = metric(weak)
        result = ch.evaluate(metrics, dv.USABLE)
        self.assertTrue(result["capped"])
        self.assertEqual(result["verdict"], ch.WEAK)
        self.assertIn("pattern rather than a phase", result["cap_reason"])

    def test_the_balance_sheet_alone_caps_the_verdict(self):
        """The one asymmetry: every other category says how well a business performs, this one
        says whether it survives — and solvency is the weakness a patient holder cannot wait out."""
        result = ch.evaluate(self._with_weak_category("balance_sheet"), dv.USABLE)
        self.assertTrue(result["capped"])
        self.assertEqual(result["verdict"], ch.WEAK)
        self.assertIn("whether it survives", result["cap_reason"])

    def test_a_capped_verdict_still_shows_the_score_and_says_why(self):
        """Capping must not hide the number — a reader has to see the disagreement."""
        result = ch.evaluate(self._with_weak_category("balance_sheet"), dv.USABLE)
        self.assertIsNotNone(result["score"])
        self.assertIn("capped at WEAK", result["verdict_reason"])

    def test_a_thinly_covered_category_cannot_raise_a_red_flag(self):
        """A category scored on one metric of three is far too thin a basis on which to call a
        company fundamentally flawed. Without this guard a red flag is an artefact of missing data
        rather than a finding about the business."""
        metrics = self._with_weak_category("balance_sheet", coverage_metrics=1)
        result = ch.evaluate(metrics, dv.USABLE)
        self.assertLess(result["categories"]["balance_sheet"]["coverage_pct"],
                        ch.RED_FLAG_MIN_CATEGORY_COVERAGE_PCT)
        self.assertFalse(result["categories"]["balance_sheet"]["red_flag"])
        self.assertFalse(result["capped"])

    def test_a_half_covered_category_can_still_raise_one(self):
        metrics = self._with_weak_category("cashflow_quality", coverage_metrics=2)
        result = ch.evaluate(metrics, dv.USABLE)
        self.assertEqual(result["categories"]["cashflow_quality"]["coverage_pct"], 50.0)
        self.assertTrue(result["categories"]["cashflow_quality"]["red_flag"])


class TheVerdictBands(unittest.TestCase):

    def _scoring(self, value):
        return ch.evaluate(all_metrics({name: metric(value)
                                        for _w, defs in ch.COMPANY_HEALTH_MODEL.values()
                                        for name, *_r in defs}), dv.USABLE)

    def test_every_anchor_at_strong_gives_strong(self):
        metrics = {name: metric(strong)
                   for _w, defs in ch.COMPANY_HEALTH_MODEL.values()
                   for name, _d, _wk, _a, strong in defs}
        result = ch.evaluate(all_metrics(metrics), dv.USABLE)
        self.assertEqual(result["score"], 100.0)
        self.assertEqual(result["verdict"], "STRONG")

    def test_every_anchor_at_adequate_gives_adequate(self):
        result = ch.evaluate(all_metrics(), dv.USABLE)
        self.assertEqual(result["score"], 60.0)
        self.assertEqual(result["verdict"], "ADEQUATE")

    def test_every_anchor_at_weak_gives_weak_and_caps(self):
        metrics = {name: metric(weak)
                   for _w, defs in ch.COMPANY_HEALTH_MODEL.values()
                   for name, _d, weak, _a, _s in defs}
        result = ch.evaluate(all_metrics(metrics), dv.USABLE)
        self.assertEqual(result["score"], 0.0)
        self.assertEqual(result["verdict"], ch.WEAK)
        self.assertTrue(result["capped"])

    def test_the_band_boundaries_are_inclusive_at_the_floor(self):
        self.assertEqual(next(n for f, n in ch.VERDICT_BANDS if 80.0 >= f), "STRONG")
        self.assertEqual(next(n for f, n in ch.VERDICT_BANDS if 79.9 >= f), "SOLID")
        self.assertEqual(next(n for f, n in ch.VERDICT_BANDS if 65.0 >= f), "SOLID")
        self.assertEqual(next(n for f, n in ch.VERDICT_BANDS if 49.9 >= f), "WEAK")


# =================================================================================================
# DISTRIBUTION SUSTAINABILITY — THE METRIC THAT REFUSES TO REWARD SILENCE
# =================================================================================================
class DistributionSustainability(unittest.TestCase):

    def test_a_covered_distribution_scores_well(self):
        value, status, _note = ch.distribution_sustainability(
            {"buybacks": 400e6, "dividends_paid": 200e6}, 1000e6)
        self.assertEqual(status, "OK")
        self.assertAlmostEqual(value, 0.6)

    def test_a_distribution_exceeding_cash_flow_scores_badly(self):
        value, status, _note = ch.distribution_sustainability(
            {"buybacks": 1200e6, "dividends_paid": 300e6}, 1000e6)
        self.assertEqual(status, "OK")
        self.assertAlmostEqual(value, 1.5)
        self.assertEqual(ch.score_metric(value, ch.LOWER, 1.3, 1.0, 0.8), 0.0)

    def test_paying_nothing_is_not_applicable_rather_than_excellent(self):
        """THE CHANGE YOU ASKED FOR. Returning nothing is not evidence of good capital
        allocation — the company may be reinvesting productively, retaining sensibly, or
        allocating badly, and this measurement cannot tell those three apart."""
        value, status, note = ch.distribution_sustainability(
            {"buybacks": 0.0, "dividends_paid": 0.0}, 1000e6)
        self.assertEqual(status, "NOT_APPLICABLE")
        self.assertIsNone(value)
        self.assertIn("NOT scored as excellent", note)

    def test_paying_nothing_is_not_penalised_either(self):
        """It is not evidence of BAD allocation either, so the weight leaves rather than scoring
        zero. A non-payer is judged on dilution alone."""
        result = ch.evaluate(
            all_metrics({"distribution_sustainability":
                         {"value": None, "verdict": dv.NOT_APPLICABLE, "reason": "none"}}),
            dv.USABLE)
        full = ch.evaluate(all_metrics(), dv.USABLE)
        self.assertEqual(result["categories"]["capital_allocation"]["score"],
                         full["categories"]["capital_allocation"]["score"])

    def test_an_unparsed_financing_section_is_unknown_not_nil(self):
        _value, status, note = ch.distribution_sustainability({}, 1000e6)
        self.assertEqual(status, "UNKNOWN")
        self.assertIn("cannot be established", note)

    def test_negative_free_cash_flow_gives_unknown_rather_than_a_wrong_sign(self):
        _value, status, _note = ch.distribution_sustainability(
            {"buybacks": 100e6, "dividends_paid": 0.0}, -500e6)
        self.assertEqual(status, "UNKNOWN")

    def test_return_on_capital_is_not_used_as_a_reinvestment_proxy(self):
        """Deliberately absent. A company retaining all its cash at a high ROIC is reinvesting
        well by definition — but ROIC is already scored in Profitability & Returns, and reusing it
        here would put one measurement behind 35% of Company Health across two categories. That is
        exactly the defect fixed when revenue consistency sat in two categories."""
        source = (Path(__file__).resolve().parent.parent / "services" / "company_health.py")
        import ast
        tree = ast.parse(source.read_text())
        function = next(n for n in ast.walk(tree)
                        if isinstance(n, ast.FunctionDef) and n.name == "distribution_sustainability")
        names = {n.id for n in ast.walk(function) if isinstance(n, ast.Name)}
        names |= {n.value for n in ast.walk(function)
                  if isinstance(n, ast.Constant) and isinstance(n.value, str)
                  and n.value in ("roic_pct", "roic")}
        self.assertNotIn("roic_pct", names)


# =================================================================================================
# END TO END, THROUGH THE VALIDATOR
# =================================================================================================
class EndToEnd(unittest.TestCase):

    def _company(self, **overrides):
        db = make_db()
        base = dict(revenue=400e9, gross_profit=184e9, operating_income=100e9, net_income=80e9,
                    eps_diluted=6.5, basic_shares=15.2e9, diluted_shares=15.4e9,
                    shares_outstanding=15.0e9, operating_cash_flow=95e9, capex=11e9,
                    total_assets=365e9, current_assets=160e9, current_liabilities=140e9,
                    stockholders_equity=60e9, total_debt=95e9, total_cash=60e9,
                    interest_expense=3.0e9, depreciation_amortisation=11e9,
                    buybacks=50e9, dividends_paid=15e9)
        base.update(overrides)
        rows = [period(ago(230 + i * 365), ago(190), ticker="AAPL",
                       **{k: (v * (1 - i * 0.07) if isinstance(v, float) else v)
                          for k, v in base.items()})
                for i in range(4)]
        for r in rows:
            r.ticker = "AAPL"
        fh.store_history(db, "AAPL", rows)
        return dv.validate_ticker(db, "AAPL", price=230.0)

    def test_a_score_and_a_verdict_are_produced(self):
        out = self._company()
        self.assertIsInstance(out["company_health_score"], float)
        self.assertIn(out["company_health_verdict"],
                      ("STRONG", "SOLID", "ADEQUATE", "WEAK", ch.INSUFFICIENT))

    def test_score_and_coverage_are_both_reported(self):
        """Never one without the other — that is how "we could not measure this" turns into
        "this is a bad company"."""
        out = self._company()
        self.assertIn("company_health_score", out)
        self.assertIn("company_health_coverage_pct", out)

    def test_every_category_reports_its_own_score_and_coverage(self):
        out = self._company()
        for name, entry in out["company_health_categories"].items():
            self.assertIn("score", entry, name)
            self.assertIn("coverage_pct", entry, name)
            self.assertIn("red_flag", entry, name)

    def test_the_score_does_not_move_when_the_price_moves(self):
        """The strongest statement that Company Health is independent of valuation: the same
        company at a different price must produce an identical score."""
        db = make_db()
        rows = [period(ago(230), ago(190), ticker="AAPL", revenue=400e9, gross_profit=184e9,
                       operating_income=100e9, net_income=80e9, total_assets=365e9,
                       stockholders_equity=60e9, operating_cash_flow=95e9, capex=11e9)]
        for r in rows:
            r.ticker = "AAPL"
        fh.store_history(db, "AAPL", rows)
        cheap = dv.validate_ticker(db, "AAPL", price=10.0)
        dear = dv.validate_ticker(db, "AAPL", price=10_000.0)
        self.assertEqual(cheap["company_health_score"], dear["company_health_score"])
        self.assertEqual(cheap["company_health_coverage_pct"],
                         dear["company_health_coverage_pct"])

    def test_no_price_at_all_does_not_reduce_the_score(self):
        db = make_db()
        rows = [period(ago(230), ago(190), ticker="AAPL", revenue=400e9, gross_profit=184e9,
                       operating_income=100e9, net_income=80e9, total_assets=365e9,
                       stockholders_equity=60e9, operating_cash_flow=95e9, capex=11e9)]
        for r in rows:
            r.ticker = "AAPL"
        fh.store_history(db, "AAPL", rows)
        priced = dv.validate_ticker(db, "AAPL", price=230.0)
        unpriced = dv.validate_ticker(db, "AAPL", price=None)
        self.assertEqual(priced["company_health_score"], unpriced["company_health_score"])

    def test_a_company_with_almost_no_data_is_unmeasured_not_weak(self):
        db = make_db()
        rows = [period(ago(230), ago(190), ticker="AAPL", revenue=1e9)]
        for r in rows:
            r.ticker = "AAPL"
        fh.store_history(db, "AAPL", rows)
        out = dv.validate_ticker(db, "AAPL", price=230.0)
        self.assertEqual(out["company_health_verdict"], ch.INSUFFICIENT)
        self.assertIsNone(out["company_health_score"])


class NegativeEquityIsNotAFailingReturn(unittest.TestCase):
    """The correctness fix C1 exposed, and the reason it had to be fixed before scoring.

    HCA earned $6,784m on shareholders' equity of -$6,027m and was reported at -112.6% return on
    equity; Booking earned $5,404m on -$5,578m and read -96.9%. Both are among the most profitable
    companies in the universe — the negative equity comes from returning more to shareholders than
    they have retained, which is a capital-structure fact and not distress. While the figure was
    only counted toward coverage nobody noticed. Scored, it hands two excellent companies a zero
    inside a category weighted 25.
    """

    def _with_equity(self, equity):
        db = make_db()
        rows = [period(ago(230), ago(190), ticker="HCA", revenue=70e9, gross_profit=30e9,
                       operating_income=12e9, net_income=6.784e9, total_assets=60e9,
                       stockholders_equity=equity, total_debt=44e9, total_cash=1e9,
                       operating_cash_flow=10e9, capex=5e9)]
        for r in rows:
            r.ticker = "HCA"
        fh.store_history(db, "HCA", rows)
        return dv.validate_ticker(db, "HCA", price=300.0)

    def test_negative_equity_makes_roe_unavailable_not_negative(self):
        roe = self._with_equity(-6.027e9)["metrics"]["roe_pct"]
        self.assertEqual(roe["verdict"], dv.UNAVAILABLE)
        self.assertIsNone(roe["value"])
        self.assertIn("negative", roe["reason"])

    def test_the_reason_does_not_imply_the_company_is_unprofitable(self):
        roe = self._with_equity(-6.027e9)["metrics"]["roe_pct"]
        self.assertIn("says nothing about profitability", roe["reason"])

    def test_roic_still_works_because_its_denominator_includes_debt(self):
        out = self._with_equity(-6.027e9)
        self.assertEqual(out["metrics"]["roic_pct"]["verdict"], dv.OK)
        self.assertGreater(out["metrics"]["roic_pct"]["value"], 0)

    def test_positive_equity_is_unaffected(self):
        roe = self._with_equity(30e9)["metrics"]["roe_pct"]
        self.assertEqual(roe["verdict"], dv.OK)
        self.assertAlmostEqual(roe["value"], 22.6133, places=3)

    def test_the_weight_leaves_rather_than_scoring_zero(self):
        out = self._with_equity(-6.027e9)
        category = out["company_health_categories"]["profitability_returns"]
        self.assertIn("roe_pct", category["missing"])
        self.assertLess(category["coverage_pct"], 100.0)


class ThePointInTimeGuaranteeSurvivesScoring(unittest.TestCase):

    def test_a_historical_score_uses_only_filings_available_then(self):
        db = make_db()
        rows = [period("2019-12-31", "2020-02-10", ticker="AAPL", revenue=260e9,
                       gross_profit=98e9, operating_income=63e9, net_income=55e9,
                       total_assets=338e9, stockholders_equity=90e9, operating_cash_flow=69e9,
                       capex=10e9),
                period("2024-12-31", "2025-02-10", ticker="AAPL", revenue=400e9,
                       gross_profit=180e9, operating_income=120e9, net_income=100e9,
                       total_assets=365e9, stockholders_equity=60e9, operating_cash_flow=110e9,
                       capex=11e9)]
        for r in rows:
            r.ticker = "AAPL"
        fh.store_history(db, "AAPL", rows)
        past = dv.validate_ticker(db, "AAPL", price=75.0, as_of_filed="2020-04-01")
        self.assertEqual(past["period_ends"], ["2019-12-31"])
        self.assertNotIn("2024-12-31", past["period_ends"])

    def test_company_health_is_still_scored_for_a_historical_date(self):
        """Only VALUATION is blocked historically — the business quality question is answerable
        at any date, and blocking it would make a backtest impossible for no reason."""
        db = make_db()
        rows = [period("2019-12-31", "2020-02-10", ticker="AAPL", revenue=260e9,
                       gross_profit=98e9, operating_income=63e9, net_income=55e9,
                       total_assets=338e9, current_assets=162e9, current_liabilities=105e9,
                       stockholders_equity=90e9, operating_cash_flow=69e9, capex=10e9,
                       total_debt=108e9, total_cash=48e9, depreciation_amortisation=12e9,
                       interest_expense=3e9)]
        for r in rows:
            r.ticker = "AAPL"
        fh.store_history(db, "AAPL", rows)
        past = dv.validate_ticker(db, "AAPL", price=75.0, as_of_filed="2020-04-01")
        self.assertTrue(past["historical_valuation_blocked"])
        self.assertIsNotNone(past["company_health_coverage_pct"])


if __name__ == "__main__":
    unittest.main()
