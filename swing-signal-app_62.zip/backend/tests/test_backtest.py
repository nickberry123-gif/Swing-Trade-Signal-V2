"""
Tests for services/backtest_service.py.

The look-ahead tests are the important ones here. A backtest that peeks at future data produces
excellent, meaningless results, so the guarantees are asserted directly rather than assumed:
future prices must not alter past signals, and fills must land on the bar AFTER the signal.
"""
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import database
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import STOCK_UNIVERSE
from services import backtest_service as bt

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]),
        )
    conn.commit()
    return conn


def bars(n=300, start=100.0, drift=0.2, noise=1.6, seed=0, wave=6.0, period=25):
    """Uptrend WITH periodic pullbacks.

    A straight-line uptrend generates zero trades, and that is correct behaviour rather than a
    bug: the strategy refuses to buy above `max_entry`, so it never chases a price that never
    dips into its buy zone. Real equities oscillate, so the test data has to as well — otherwise
    the entry path is never exercised.
    """
    rng = np.random.default_rng(seed)
    trend = start + np.cumsum(drift + rng.normal(0, noise, n))
    cycle = wave * np.sin(np.arange(n) * 2 * np.pi / period)
    closes = np.maximum(trend + cycle, 1.0)
    ts = [(datetime(2024, 1, 1) + timedelta(days=i)).date().isoformat() for i in range(n)]
    return pd.DataFrame({
        "ts": ts, "open": closes, "high": closes * 1.01, "low": closes * 0.99,
        "close": closes, "volume": [1_000_000.0] * n,
    })


class TestLookAheadPrevention(unittest.TestCase):
    """The core guarantees. If any of these fail, every metric this engine produces is void."""

    def test_future_prices_cannot_change_a_past_signal(self):
        base = bars(seed=1)

        # Identical history, but the final 20 bars are replaced with a massive spike. Any
        # signal generated before that spike must be byte-identical in both worlds.
        spiked = base.copy()
        spiked.loc[spiked.index[-20:], ["open", "high", "low", "close"]] *= 5.0

        cutoff = len(base) - 25
        ind_base = bt.compute_all_indicators(base.iloc[:cutoff])
        ind_spiked = bt.compute_all_indicators(spiked.iloc[:cutoff])

        for key in ("rsi14", "sma50", "sma200", "macd", "trend_label", "reference_price"):
            self.assertEqual(ind_base.get(key), ind_spiked.get(key),
                             f"{key} changed when only FUTURE bars differed — look-ahead bias")

    def test_trades_before_a_future_spike_are_unchanged_by_it(self):
        base = bars(seed=2)
        spiked = base.copy()
        spiked.loc[spiked.index[-15:], ["open", "high", "low", "close"]] *= 4.0

        t_base = bt._simulate_ticker("NVDA", base, {}, {})
        t_spiked = bt._simulate_ticker("NVDA", spiked, {}, {})

        cutoff_date = base["ts"].iloc[-30]
        early_base = [t for t in t_base if t["signal_date"] < cutoff_date]
        early_spiked = [t for t in t_spiked if t["signal_date"] < cutoff_date]

        self.assertEqual(len(early_base), len(early_spiked))
        for a, b in zip(early_base, early_spiked):
            self.assertEqual(a["signal_date"], b["signal_date"])
            self.assertEqual(a["entry_price"], b["entry_price"])

    def test_entry_fills_at_the_next_bars_open_not_the_signal_close(self):
        df = bars(seed=3)
        trades = bt._simulate_ticker("NVDA", df, {}, {})
        self.assertTrue(trades, "expected at least one trade in a strong uptrend")

        for t in trades:
            signal_idx = df.index[df["ts"] == t["signal_date"]][0]
            entry_idx = df.index[df["ts"] == t["entry_date"]][0]
            self.assertEqual(entry_idx, signal_idx + 1,
                             "entry must be the bar AFTER the signal bar")
            self.assertAlmostEqual(t["entry_price"], float(df["open"].iloc[entry_idx]), places=4)
            self.assertNotAlmostEqual(t["entry_price"], float(df["close"].iloc[signal_idx]),
                                      places=6)

    def test_no_signal_is_generated_before_warmup_completes(self):
        df = bars(seed=4)
        trades = bt._simulate_ticker("NVDA", df, {}, {})
        for t in trades:
            idx = df.index[df["ts"] == t["signal_date"]][0]
            self.assertGreaterEqual(idx, bt.MIN_WARMUP_BARS)

    def test_exit_never_precedes_entry(self):
        df = bars(seed=5)
        for t in bt._simulate_ticker("NVDA", df, {}, {}):
            if t.get("exit_date"):
                self.assertGreater(t["exit_date"], t["entry_date"])
                self.assertGreaterEqual(t["holding_days"], 0)


class TestNoStopLoss(unittest.TestCase):
    def test_engine_has_no_stop_loss_concept_anywhere(self):
        source = (Path(__file__).resolve().parent.parent
                  / "services" / "backtest_service.py").read_text().lower()
        # "no stop-loss" appears in documentation; an actual implementation would need these.
        self.assertNotIn("stop_price", source)
        self.assertNotIn("stop_loss_pct", source)
        for t in bt._simulate_ticker("NVDA", bars(seed=6), {}, {}):
            self.assertNotIn("stop_loss", t)
            self.assertIn(t.get("exit_reason"),
                          ("TARGET", "TIME_LIMIT", "SIGNAL_EXIT", "OPEN_AT_END"))


class TestExitRules(unittest.TestCase):
    def test_max_holding_days_is_respected(self):
        df = bars(seed=7, drift=0.01, noise=0.05)   # flat: targets unlikely to trigger
        trades = bt._simulate_ticker("NVDA", df, {}, {"max_holding_days": 5,
                                                       "exit_on_signal": False})
        for t in trades:
            if t["exit_reason"] == "TIME_LIMIT":
                self.assertLessEqual(t["holding_days"], 6)

    def test_slippage_worsens_results(self):
        df = bars(seed=8)
        clean = bt._metrics(bt._simulate_ticker("NVDA", df, {}, {}))
        slipped = bt._metrics(bt._simulate_ticker("NVDA", df, {}, {"slippage_pct": 0.5}))
        if clean["trades"] and slipped["trades"]:
            self.assertLessEqual(slipped["avg_return_pct"], clean["avg_return_pct"])

    def test_only_one_open_position_per_ticker(self):
        df = bars(seed=9)
        trades = sorted(bt._simulate_ticker("NVDA", df, {}, {}), key=lambda t: t["entry_date"])
        for a, b in zip(trades, trades[1:]):
            self.assertLessEqual(a["exit_date"], b["entry_date"],
                                 "positions must not overlap for the same ticker")


class TestMetrics(unittest.TestCase):
    def test_metrics_on_hand_computed_trades(self):
        # Exit dates are required now that equity is modelled as an account with a finite number
        # of position slots: capital stays committed until a trade closes. Every trade the
        # simulator emits carries one (a position still open at the end of the data is closed at
        # the last bar with exit_reason OPEN_AT_END), so this fixture matches reality — the
        # earlier version, which omitted them, did not.
        trades = [
            {"entry_date": "2024-01-01", "exit_date": "2024-01-08", "return_pct": 10.0, "holding_days": 5},
            {"entry_date": "2024-02-01", "exit_date": "2024-02-06", "return_pct": -5.0, "holding_days": 3},
            {"entry_date": "2024-03-01", "exit_date": "2024-03-15", "return_pct": 20.0, "holding_days": 10},
            {"entry_date": "2024-04-01", "exit_date": "2024-04-10", "return_pct": -10.0, "holding_days": 7},
        ]
        m = bt._metrics(trades)
        self.assertEqual(m["trades"], 4)
        self.assertEqual(m["win_rate_pct"], 50.0)
        self.assertEqual(m["avg_return_pct"], 3.75)
        self.assertEqual(m["best_pct"], 20.0)
        self.assertEqual(m["worst_pct"], -10.0)
        self.assertEqual(m["profit_factor"], 2.0)          # 30 gross win / 15 gross loss
        self.assertLess(m["max_drawdown_pct"], 0)

    def test_empty_trades_returns_nulls_not_zeros(self):
        m = bt._metrics([])
        self.assertEqual(m["trades"], 0)
        self.assertIsNone(m["win_rate_pct"])
        self.assertIsNone(m["avg_return_pct"])


class TestWalkForward(unittest.TestCase):
    def test_segments_split_chronologically(self):
        dates = [f"2024-{m:02d}-01" for m in range(1, 13)]
        trades = [{"entry_date": d} for d in dates]
        bt._assign_segments(trades, dates)
        segs = [t["segment"] for t in trades]
        self.assertEqual(segs[0], "IN_SAMPLE")
        self.assertEqual(segs[-1], "OUT_OF_SAMPLE")
        # Once out-of-sample begins it must never revert to an earlier segment.
        order = {"IN_SAMPLE": 0, "VALIDATION": 1, "OUT_OF_SAMPLE": 2}
        self.assertEqual(segs, sorted(segs, key=lambda s: order[s]))


class TestRunBacktest(unittest.TestCase):
    def _bars_set(self, seed=10):
        return {t: bars(seed=seed + i) for i, t in enumerate(["NVDA", "AMD", "SPY", "QQQ"])}

    def test_full_run_shape_and_persistence(self):
        db = make_db()
        data = self._bars_set()
        result = bt.run_backtest(db, ["NVDA", "AMD"], data, {"use_regime": False})

        self.assertIn("overall", result)
        self.assertIn("by_segment", result)
        self.assertIn("monthly_contributions_benchmark", result)
        self.assertTrue(result["limitations"])
        self.assertTrue(any("SURVIVORSHIP" in l for l in result["limitations"]))

        run_id = bt.persist_backtest(db, result, "2024-01-01", "2024-12-31")
        self.assertIsInstance(run_id, int)
        count = db.execute("SELECT COUNT(*) FROM backtest_trades WHERE run_id = ?",
                           (run_id,)).fetchone()[0]
        self.assertEqual(count, len(result["trades"]))

    def test_insufficient_history_is_skipped_not_silently_zeroed(self):
        db = make_db()
        data = {"NVDA": bars(n=50), "SPY": bars(), "QQQ": bars()}
        result = bt.run_backtest(db, ["NVDA"], data, {"use_regime": False})
        self.assertIn("NVDA", result["tickers_skipped"])
        self.assertEqual(result["overall"]["trades"], 0)

    def test_underperforming_the_monthly_benchmark_is_called_out(self):
        """The benchmark is now monthly contributions, not a lump sum on day one.

        Lump-sum buy-and-hold assumed a pile of cash nobody has, which made it both unfair and
        not the decision actually being made. See services/monthly_buying_service.py.
        """
        db = make_db()
        # Strong steady uptrend: simply contributing is very hard to beat with intermittent swings.
        data = {t: bars(drift=0.5, noise=0.05, seed=20 + i)
                for i, t in enumerate(["NVDA", "SPY", "QQQ"])}
        result = bt.run_backtest(db, ["NVDA"], data, {"use_regime": False})
        mc = result["monthly_contributions_benchmark"]["return_pct"]
        total = result["overall"]["total_return_pct"]
        if total is not None and mc is not None and total < mc:
            self.assertTrue(any("UNDERPERFORMED" in w for w in result["warnings"]))

    def test_low_trade_count_is_flagged_as_noise(self):
        db = make_db()
        data = {"NVDA": bars(n=230), "SPY": bars(), "QQQ": bars()}
        result = bt.run_backtest(db, ["NVDA"], data, {"use_regime": False})
        if result["overall"]["trades"] < 30:
            self.assertTrue(any("noise" in w for w in result["warnings"]))



class TestFastPathEquivalence(unittest.TestCase):
    """The backtester precomputes indicators once per ticker instead of re-slicing on every bar.

    That is a pure performance change and must be numerically indistinguishable from the original
    slow path — otherwise the optimisation has quietly introduced look-ahead, which is the one
    failure this whole module exists to prevent. These tests compare the two directly.
    """

    SCORED_FIELDS = ("reference_price", "ema20", "ema50", "sma50", "sma200", "sma200_slope",
                     "rsi14", "macd", "macd_signal", "macd_hist", "adx", "roc", "atr14",
                     "relative_volume", "volume_trend", "trend_label", "support_low",
                     "support_high", "resistance_low", "resistance_high", "swing_high",
                     "high_20d", "high_52w")

    def test_fast_path_matches_the_slow_slice_path(self):
        df = bars(n=420, seed=11)
        pre = bt._precompute(df)

        # Sample across the series rather than every bar — the slow path is O(n^2).
        for i in range(bt.MIN_WARMUP_BARS, len(df), 17):
            fast = bt._indicators_at(df, pre, i)
            slow = bt.compute_all_indicators(df.iloc[:i + 1], minimal=True)
            for field in self.SCORED_FIELDS:
                self.assertEqual(
                    fast.get(field), slow.get(field),
                    f"bar {i}: '{field}' differs between fast and slow paths "
                    f"({fast.get(field)!r} vs {slow.get(field)!r})")

    def test_fast_path_scores_identically(self):
        df = bars(n=400, seed=12)
        pre = bt._precompute(df)
        for i in range(bt.MIN_WARMUP_BARS, len(df), 23):
            fast = bt._score_from_indicators(bt._indicators_at(df, pre, i), {})
            slow = bt._score_from_indicators(
                bt.compute_all_indicators(df.iloc[:i + 1], minimal=True), {})
            self.assertEqual(fast["score"], slow["score"], f"score differs at bar {i}")
            self.assertEqual(fast["label"], slow["label"], f"label differs at bar {i}")

    def test_precompute_is_unaffected_by_future_bars(self):
        """The decisive look-ahead check: truncating the series must not change earlier values."""
        full = bars(n=420, seed=13)
        truncated = full.iloc[:350].reset_index(drop=True)

        pre_full = bt._precompute(full)
        pre_trunc = bt._precompute(truncated)

        for i in range(bt.MIN_WARMUP_BARS, 348, 13):
            a = bt._indicators_at(full, pre_full, i)
            b = bt._indicators_at(truncated, pre_trunc, i)
            for field in self.SCORED_FIELDS:
                self.assertEqual(a.get(field), b.get(field),
                                 f"bar {i}: '{field}' changed when only LATER bars were removed "
                                 f"— the fast path is reading the future")

    def test_swing_points_are_never_used_before_confirmation(self):
        df = bars(n=300, seed=14)
        pre = bt._precompute(df)
        for i in range(bt.MIN_WARMUP_BARS, len(df), 11):
            ind = bt._indicators_at(df, pre, i)
            sh = ind.get("swing_high")
            if sh is None:
                continue
            # Any reported swing high must sit at or before bar i-2 (window=2 confirmation).
            confirmed = df["high"].iloc[:max(0, i - 1)]
            self.assertIn(round(float(sh), 6), [round(float(v), 6) for v in confirmed.values],
                          f"bar {i}: swing high {sh} is not among bars confirmed by then")

if __name__ == "__main__":
    unittest.main()


class TestMinScoreControl(unittest.TestCase):
    """The Minimum Score field appeared broken: 0, 55 and 60 returned identical results.

    They were not being ignored — they were redundant. The entry gate requires a BUY or
    STRONG BUY label, and BUY begins at 62, so nothing below 62 could exclude a trade the label
    gate had not already excluded. effective_min_score() makes that floor explicit and the run
    config reports it, so the number on screen is the number that was applied.
    """

    def test_floor_is_derived_from_the_buy_threshold_not_hard_coded(self):
        from services.signal_engine import SIGNAL_THRESHOLDS
        buy_threshold = dict((name, t) for t, name in SIGNAL_THRESHOLDS)["BUY"]
        self.assertEqual(bt.ENTRY_LABEL_FLOOR, buy_threshold)

    def test_requests_below_the_floor_are_raised_to_it(self):
        for requested in (0, 25, 55, 60, 61.9):
            self.assertEqual(bt.effective_min_score(requested), float(bt.ENTRY_LABEL_FLOOR),
                             f"{requested} should clamp to the BUY floor")

    def test_requests_above_the_floor_are_respected(self):
        self.assertEqual(bt.effective_min_score(75), 75.0)
        self.assertEqual(bt.effective_min_score(100), 100.0)

    def test_garbage_input_falls_back_to_the_floor_rather_than_crashing(self):
        for bad in (None, "", "abc", object()):
            self.assertEqual(bt.effective_min_score(bad), float(bt.ENTRY_LABEL_FLOOR))

    def test_below_floor_values_produce_identical_trades_by_construction(self):
        """Documents the behaviour the user actually observed, so it can never be mistaken for
        a bug again: these settings SHOULD match exactly."""
        df = bars(seed=4)
        runs = [bt._simulate_ticker("NVDA", df, {}, {"min_score": s}) for s in (0, 55, 60, 62)]
        counts = [len(r) for r in runs]
        self.assertEqual(len(set(counts)), 1, f"expected identical trade counts, got {counts}")

    def test_raising_the_score_above_the_floor_actually_filters(self):
        """The real assertion: the control is not inert, it just has a floor."""
        df = bars(seed=4)
        base = bt._simulate_ticker("NVDA", df, {}, {"min_score": 62})
        strict = bt._simulate_ticker("NVDA", df, {}, {"min_score": 95})
        self.assertGreater(len(base), 0, "fixture produced no trades; test proves nothing")
        self.assertLess(len(strict), len(base),
                        "a stricter minimum score must reduce the number of entries")
        for t in strict:
            self.assertGreaterEqual(t["score_at_entry"], 95)

    def test_run_config_reports_the_applied_threshold(self):
        db = make_db()
        res = bt.run_backtest(db, ["NVDA"], {"NVDA": bars(seed=4)}, {"min_score": 10})
        self.assertEqual(res["config"]["min_score"], 10)
        self.assertEqual(res["config"]["min_score_effective"], float(bt.ENTRY_LABEL_FLOOR))
        self.assertIn(str(bt.ENTRY_LABEL_FLOOR), res["config"]["min_score_note"])


class TestPortfolioEquity(unittest.TestCase):
    """Total return used to compound every trade in sequence, as if one position were held at a
    time. Across 15 tickers many trades overlapped, so the same capital funded several at once:
    326 trades averaging +2.84% reported +88,446%. Equity is now modelled as one account with a
    finite number of equal-weight slots.
    """

    def test_single_slot_matches_sequential_compounding(self):
        trades = [
            {"entry_date": "2024-01-01", "exit_date": "2024-01-10", "return_pct": 10.0},
            {"entry_date": "2024-02-01", "exit_date": "2024-02-10", "return_pct": -5.0},
        ]
        equity, _dd, _f, _u = bt._portfolio_equity(trades, slots=1)
        self.assertAlmostEqual(equity, 1.10 * 0.95, places=9)

    def test_concurrent_trades_share_capital_instead_of_multiplying_it(self):
        """Two simultaneous +100% trades on a 2-slot account double the money — they do not
        quadruple it, which is what sequential compounding claimed."""
        trades = [
            {"entry_date": "2024-01-01", "exit_date": "2024-06-01", "return_pct": 100.0},
            {"entry_date": "2024-01-01", "exit_date": "2024-06-01", "return_pct": 100.0},
        ]
        equity, _dd, _f, _u = bt._portfolio_equity(trades, slots=2)
        self.assertAlmostEqual(equity, 2.0, places=9)
        seq = bt._metrics(trades, slots=2)["sequential_compounded_return_pct"]
        self.assertAlmostEqual(seq, 300.0, places=6)   # the old, wrong headline

    def test_capital_is_finite_so_extra_concurrent_signals_are_skipped(self):
        """Three overlapping signals on a one-slot account: only the first can be funded."""
        trades = [
            {"entry_date": "2024-01-01", "exit_date": "2024-06-01", "return_pct": 50.0},
            {"entry_date": "2024-01-02", "exit_date": "2024-06-01", "return_pct": 50.0},
            {"entry_date": "2024-01-03", "exit_date": "2024-06-01", "return_pct": 50.0},
        ]
        equity, _dd, _f, _u = bt._portfolio_equity(trades, slots=1)
        self.assertAlmostEqual(equity, 1.5, places=9)

    def test_return_cannot_exceed_what_the_capital_allows(self):
        """The bug's signature was an implausible headline. 100 concurrent +50% trades across 15
        slots must land near +50%, nowhere near the 1.5^100 sequential compounding produced."""
        trades = [{"entry_date": "2024-01-01", "exit_date": "2024-06-01", "return_pct": 50.0}
                  for _ in range(100)]
        equity, _dd, _f, _u = bt._portfolio_equity(trades, slots=15)
        self.assertLess(equity, 2.0)
        self.assertGreater(equity, 1.0)

    def test_drawdown_is_negative_when_losses_follow_a_peak(self):
        trades = [
            {"entry_date": "2024-01-01", "exit_date": "2024-01-10", "return_pct": 20.0},
            {"entry_date": "2024-02-01", "exit_date": "2024-02-10", "return_pct": -30.0},
        ]
        _equity, dd, _f, _u = bt._portfolio_equity(trades, slots=1)
        self.assertAlmostEqual(dd, -30.0, places=6)

    def test_all_winning_trades_never_produce_a_drawdown(self):
        trades = [
            {"entry_date": "2024-01-01", "exit_date": "2024-01-10", "return_pct": 5.0},
            {"entry_date": "2024-02-01", "exit_date": "2024-02-10", "return_pct": 5.0},
        ]
        _equity, dd, _f, _u = bt._portfolio_equity(trades, slots=1)
        self.assertEqual(dd, 0.0)

    def test_missing_entry_date_is_ignored_rather_than_crashing(self):
        trades = [{"exit_date": "2024-01-10", "return_pct": 5.0},
                  {"entry_date": "2024-01-01", "exit_date": "2024-01-10", "return_pct": 10.0}]
        equity, _dd, _f, _u = bt._portfolio_equity(trades, slots=1)
        self.assertAlmostEqual(equity, 1.10, places=9)

    def test_null_return_is_treated_as_flat_not_fabricated(self):
        trades = [{"entry_date": "2024-01-01", "exit_date": "2024-01-10", "return_pct": None}]
        equity, _dd, _f, _u = bt._portfolio_equity(trades, slots=1)
        self.assertAlmostEqual(equity, 1.0, places=9)

    def test_per_ticker_metrics_use_one_slot(self):
        """Within a single ticker the simulator never overlaps positions, so compounding one
        after another is exactly right — and must stay that way."""
        db = make_db()
        res = bt.run_backtest(db, ["NVDA"], {"NVDA": bars(seed=4)}, {})
        per_ticker = res["by_ticker"]["NVDA"]
        self.assertAlmostEqual(per_ticker["total_return_pct"],
                               per_ticker["sequential_compounded_return_pct"], places=6)
