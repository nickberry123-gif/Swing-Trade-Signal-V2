"""
Unit tests for services/stock_analysis.py — the orchestration layer that ties bars_service +
indicators + relative_strength together and persists to `technical_indicators`.

get_bars_df is mocked at the module level it's imported into (services.stock_analysis),
matching the pattern used in test_market_regime.py. Persistence is tested against a real
in-memory SQLite DB built from schema.sql (cheap, stdlib, no need to mock the DB layer).
"""
import sqlite3
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import database
from unittest.mock import patch

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import SECTOR_ETF_MAP
from services import stock_analysis

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    conn.commit()
    return conn


def trending_bars(n=250, start=100.0, daily_drift=0.15, noise=0.3, seed=0):
    rng = np.random.default_rng(seed)
    closes = start + np.cumsum(daily_drift + rng.normal(0, noise, n))
    closes = np.maximum(closes, 1.0)
    ts = [(datetime(2024, 1, 1) + timedelta(days=i)).isoformat() for i in range(n)]
    return pd.DataFrame({
        "ts": ts, "open": closes, "high": closes + 0.5, "low": closes - 0.5,
        "close": closes, "volume": [1_000_000.0] * n,
    })


def empty_bars():
    return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])


class TestAnalyzeStock(unittest.TestCase):
    @patch("services.stock_analysis.get_bars_df")
    def test_basic_result_shape(self, mock_get_bars):
        def side_effect(db, ticker, timeframe, force_refresh=False):
            seed = hash(ticker) % 1000
            return trending_bars(seed=seed), {"source": "alpaca", "fresh": True, "stale_fallback": False, "error": None}

        mock_get_bars.side_effect = side_effect
        db = make_db()

        result = stock_analysis.analyze_stock(db, "NVDA", persist=False)

        self.assertEqual(result["ticker"], "NVDA")
        self.assertEqual(result["sector_etf"], SECTOR_ETF_MAP["NVDA"])
        self.assertIn("relative_strength", result)
        self.assertIn("rs_spy_5d", result["relative_strength"])
        self.assertEqual(result["data_status"], "OK")
        self.assertGreater(result["bars_used"], 0)
        self.assertIn("trend_label", result)

    @patch("services.stock_analysis.get_bars_df")
    def test_no_data_returns_unavailable_not_fabricated(self, mock_get_bars):
        mock_get_bars.return_value = (empty_bars(), {"source": "cache", "fresh": False, "stale_fallback": False, "error": "no data"})
        db = make_db()

        result = stock_analysis.analyze_stock(db, "AAPL", persist=False)

        self.assertEqual(result["data_status"], "UNAVAILABLE")
        self.assertEqual(result["bars_used"], 0)
        self.assertIn("data_error", result)

    @patch("services.stock_analysis.get_bars_df")
    def test_persist_upserts_single_row_on_repeat_call(self, mock_get_bars):
        def side_effect(db, ticker, timeframe, force_refresh=False):
            return trending_bars(seed=1), {"source": "alpaca", "fresh": True, "stale_fallback": False, "error": None}

        mock_get_bars.side_effect = side_effect
        db = make_db()

        stock_analysis.analyze_stock(db, "MSFT", persist=True)
        stock_analysis.analyze_stock(db, "MSFT", persist=True)

        rows = db.execute(
            "SELECT COUNT(*) FROM technical_indicators WHERE ticker='MSFT'"
        ).fetchone()[0]
        self.assertEqual(rows, 1)

        row = db.execute(
            "SELECT trend_label, sector_etf, bars_used FROM technical_indicators WHERE ticker='MSFT'"
        ).fetchone()
        self.assertIsNotNone(row["trend_label"])
        self.assertEqual(row["sector_etf"], SECTOR_ETF_MAP["MSFT"])
        self.assertGreater(row["bars_used"], 0)

    @patch("services.stock_analysis.get_bars_df")
    def test_persist_noop_when_no_last_bar_ts(self, mock_get_bars):
        mock_get_bars.return_value = (empty_bars(), {"source": "cache", "fresh": False, "stale_fallback": False, "error": None})
        db = make_db()

        # Should not raise even though there's nothing meaningful to persist.
        stock_analysis.analyze_stock(db, "AAPL", persist=True)
        rows = db.execute("SELECT COUNT(*) FROM technical_indicators WHERE ticker='AAPL'").fetchone()[0]
        self.assertEqual(rows, 0)

    @patch("services.stock_analysis.get_bars_df")
    def test_uses_passed_in_benchmark_cache_without_refetching(self, mock_get_bars):
        def side_effect(db, ticker, timeframe, force_refresh=False):
            return trending_bars(seed=2), {"source": "alpaca", "fresh": True, "stale_fallback": False, "error": None}

        mock_get_bars.side_effect = side_effect
        db = make_db()

        cache = stock_analysis.build_benchmark_cache(db)
        call_count_after_cache_build = mock_get_bars.call_count

        stock_analysis.analyze_stock(db, "GOOGL", benchmark_cache=cache, persist=False)

        # Only one additional call — for GOOGL's own bars — should have happened.
        self.assertEqual(mock_get_bars.call_count, call_count_after_cache_build + 1)


class TestBuildBenchmarkCache(unittest.TestCase):
    @patch("services.stock_analysis.get_bars_df")
    def test_fetches_spy_qqq_and_all_sector_etfs(self, mock_get_bars):
        def side_effect(db, ticker, timeframe, force_refresh=False):
            return trending_bars(seed=3), {"source": "alpaca", "fresh": True, "stale_fallback": False, "error": None}

        mock_get_bars.side_effect = side_effect
        db = make_db()

        cache = stock_analysis.build_benchmark_cache(db)

        self.assertIn("SPY", cache)
        self.assertIn("QQQ", cache)
        for sector_etf in set(SECTOR_ETF_MAP.values()):
            self.assertIn(sector_etf, cache)
            self.assertIsNotNone(cache[sector_etf]["close"])

    @patch("services.stock_analysis.get_bars_df")
    def test_missing_benchmark_data_yields_none_close_not_crash(self, mock_get_bars):
        mock_get_bars.return_value = (empty_bars(), {"source": "cache", "fresh": False, "stale_fallback": False, "error": "no data"})
        db = make_db()

        cache = stock_analysis.build_benchmark_cache(db)
        self.assertIsNone(cache["SPY"]["close"])


if __name__ == "__main__":
    unittest.main()
