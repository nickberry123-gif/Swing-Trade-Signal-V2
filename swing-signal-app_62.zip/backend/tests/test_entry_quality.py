"""
Tests for services/entry_quality_service.py.

The arithmetic here is trivial; the ways the COMPARISON can lie are not. A rigged comparison
would produce a confident, plausible, wrong answer to "should I bother timing entries at all",
so most of these tests attack the fairness of the comparison rather than the maths.
"""
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import entry_quality_service as eq
from services.backtest_service import MIN_WARMUP_BARS


def bars(n=900, start=100.0, drift=0.2, noise=1.6, seed=0, wave=6.0, period=25):
    """Uptrend with pullbacks — a flat line generates no signals at all."""
    rng = np.random.default_rng(seed)
    trend = start + np.cumsum(drift + rng.normal(0, noise, n))
    cycle = wave * np.sin(np.arange(n) * 2 * np.pi / period)
    closes = np.maximum(trend + cycle, 1.0)
    ts = [(datetime(2021, 1, 4) + timedelta(days=i)).date().isoformat() for i in range(n)]
    return pd.DataFrame({
        "ts": ts, "open": closes, "high": closes * 1.01, "low": closes * 0.99,
        "close": closes, "volume": [1_000_000.0] * n,
    })


class TestForwardReturn(unittest.TestCase):
    def test_measures_from_the_entry_open_to_the_later_close(self):
        df = pd.DataFrame({"ts": ["a", "b", "c"], "open": [100.0, 200.0, 300.0],
                           "high": [0, 0, 0], "low": [0, 0, 0],
                           "close": [110.0, 220.0, 330.0], "volume": [1, 1, 1]})
        # Buy at bar 1's OPEN (200), value at bar 2's CLOSE (330) => +65%.
        self.assertAlmostEqual(eq._forward_return(df, 1, 1), 65.0, places=6)

    def test_horizon_past_the_end_returns_none_not_a_short_period(self):
        df = bars(n=300)
        self.assertIsNone(eq._forward_return(df, 290, 504))
        self.assertIsNone(eq._forward_return(df, 299, 1))

    def test_zero_entry_price_does_not_divide_by_zero(self):
        df = pd.DataFrame({"ts": ["a", "b"], "open": [0.0, 1.0], "high": [0, 0],
                           "low": [0, 0], "close": [1.0, 2.0], "volume": [1, 1]})
        self.assertIsNone(eq._forward_return(df, 0, 1))


class TestNoLookAhead(unittest.TestCase):
    """If entries could see the future, every number this page produces would be void."""

    def test_future_bars_cannot_change_earlier_signal_entries(self):
        base = bars(seed=1, n=700)
        spiked = base.copy()
        spiked.loc[spiked.index[-40:], ["open", "high", "low", "close"]] *= 5.0

        a = eq._signal_entry_indices(base, {}, 62)
        b = eq._signal_entry_indices(spiked, {}, 62)
        cutoff = len(base) - 60
        self.assertEqual([i for i in a if i < cutoff], [i for i in b if i < cutoff])

    def test_entries_fill_on_the_bar_after_the_signal(self):
        df = bars(seed=2, n=600)
        idx = eq._signal_entry_indices(df, {}, 62)
        self.assertTrue(idx, "fixture produced no signals; the test would prove nothing")
        # Every entry index must be at least warmup+1: the signal bar is warmup at the earliest
        # and the fill is the bar after it.
        self.assertGreaterEqual(min(idx), MIN_WARMUP_BARS + 1)

    def test_no_signal_before_warmup_completes(self):
        df = bars(seed=3, n=600)
        for i in eq._signal_entry_indices(df, {}, 62):
            self.assertGreater(i, MIN_WARMUP_BARS)


class TestMonthlyBaseline(unittest.TestCase):
    def test_one_entry_per_calendar_month(self):
        df = bars(n=400)
        idx = eq._monthly_entry_indices(df, 0)
        ts = pd.to_datetime(df["ts"].iloc[idx], format="mixed", utc=True)
        months = list(ts.dt.year * 100 + ts.dt.month)
        self.assertEqual(len(months), len(set(months)), "a month was bought twice")

    def test_takes_the_first_available_day_of_each_month(self):
        df = bars(n=400)
        idx = set(eq._monthly_entry_indices(df, 0))
        ts = pd.to_datetime(df["ts"], format="mixed", utc=True)
        period = ts.dt.year * 100 + ts.dt.month
        for i in idx:
            earlier_same_month = [j for j in range(0, i) if period.iloc[j] == period.iloc[i]]
            self.assertFalse(earlier_same_month,
                             "an earlier day in the same month was available but not used")

    def test_respects_the_start_index_so_it_cannot_predate_the_signal_arm(self):
        """The baseline must not get a head start the signal arm never had — that alone would
        hand it extra months of a rising market."""
        df = bars(n=600)
        idx = eq._monthly_entry_indices(df, 300)
        self.assertTrue(all(i >= 300 for i in idx))


class TestFairComparison(unittest.TestCase):
    """The traps that would make this analysis confidently wrong."""

    def test_all_arms_share_the_same_eligible_window(self):
        df = bars(seed=4, n=800)
        out = eq.analyse_ticker(df, {}, 62)
        for label, horizon in eq.HORIZONS:
            first, last = eq._eligible_window(df, horizon)
            if last < first:
                continue
            every = out["horizons"][label]["EVERY_DAY"]["n"]
            self.assertEqual(every, last - first + 1,
                             f"{label}: control arm window does not match the eligible window")

    def test_window_shrinks_as_the_horizon_lengthens(self):
        """A 24-month horizon must have fewer eligible entry dates than a 1-month one. If they
        matched, some entries would be scored on an incomplete forward period."""
        df = bars(seed=5, n=800)
        out = eq.analyse_ticker(df, {}, 62)
        counts = [out["horizons"][label]["EVERY_DAY"]["n"] for label, _h in eq.HORIZONS]
        self.assertEqual(counts, sorted(counts, reverse=True))

    def test_no_entry_is_scored_on_an_incomplete_forward_period(self):
        df = bars(seed=6, n=800)
        for _label, horizon in eq.HORIZONS:
            first, last = eq._eligible_window(df, horizon)
            if last < first:
                continue
            self.assertLess(last + horizon, len(df))

    def test_ticker_only_counts_when_both_arms_have_entries(self):
        """Otherwise the arms would be built from different companies and the 'edge' would be
        stock picking wearing a timing costume."""
        per_ticker = {
            "AAA": {"horizons": {"12 months": {
                "SIGNAL": {"n": 5, "mean_pct": 30.0, "positive_pct": 80.0},
                "MONTHLY": {"n": 12, "mean_pct": 10.0, "positive_pct": 70.0},
                "EVERY_DAY": {"n": 200, "mean_pct": 11.0, "positive_pct": 70.0}}}},
            "BBB": {"horizons": {"12 months": {
                "SIGNAL": {"n": 0, "mean_pct": None, "positive_pct": None},
                "MONTHLY": {"n": 12, "mean_pct": 99.0, "positive_pct": 90.0},
                "EVERY_DAY": {"n": 200, "mean_pct": 99.0, "positive_pct": 90.0}}}},
        }
        agg = eq._aggregate(per_ticker)["12 months"]
        self.assertEqual(agg["tickers_compared"], 1)
        self.assertEqual(agg["tickers"], ["AAA"])
        # BBB's +99% must not reach the monthly arm; only AAA's +10% counts.
        self.assertEqual(agg["MONTHLY"]["mean_pct"], 10.0)
        self.assertEqual(agg["edge_vs_monthly_pct"], 20.0)

    def test_a_ticker_with_many_signals_cannot_dominate_the_average(self):
        """Equal-weight across tickers: 500 entries on one stock must not outvote 3 on another."""
        per_ticker = {
            "LOUD": {"horizons": {"12 months": {
                "SIGNAL": {"n": 500, "mean_pct": 100.0, "positive_pct": 99.0},
                "MONTHLY": {"n": 12, "mean_pct": 0.0, "positive_pct": 50.0},
                "EVERY_DAY": {"n": 200, "mean_pct": 0.0, "positive_pct": 50.0}}}},
            "QUIET": {"horizons": {"12 months": {
                "SIGNAL": {"n": 3, "mean_pct": 0.0, "positive_pct": 10.0},
                "MONTHLY": {"n": 12, "mean_pct": 0.0, "positive_pct": 50.0},
                "EVERY_DAY": {"n": 200, "mean_pct": 0.0, "positive_pct": 50.0}}}},
        }
        agg = eq._aggregate(per_ticker)["12 months"]
        self.assertEqual(agg["SIGNAL"]["mean_pct"], 50.0)   # (100 + 0) / 2, not ~99


class TestVerdictResistsOverclaiming(unittest.TestCase):
    """The most dangerous output this app can produce is a confident 'the signal wins'."""

    def _overall(self, edge_12, edge_24):
        return {
            "1 month": {"edge_vs_monthly_pct": 5.0},
            "3 months": {"edge_vs_monthly_pct": 5.0},
            "6 months": {"edge_vs_monthly_pct": 5.0},
            "12 months": {"edge_vs_monthly_pct": edge_12},
            "24 months": {"edge_vs_monthly_pct": edge_24},
        }

    def test_negative_long_horizon_edge_reads_as_no_advantage(self):
        self.assertEqual(eq._verdict(self._overall(-3.0, -5.0))["headline"], "NO ADVANTAGE")

    def test_a_small_edge_is_not_sold_as_a_win(self):
        self.assertEqual(eq._verdict(self._overall(1.0, 1.5))["headline"], "TOO SMALL TO RELY ON")

    def test_short_horizon_edge_alone_cannot_produce_a_positive_verdict(self):
        """A one-month edge in a bull market says nothing about holding for years."""
        v = eq._verdict({"1 month": {"edge_vs_monthly_pct": 40.0},
                         "3 months": {"edge_vs_monthly_pct": 40.0}})
        self.assertEqual(v["headline"], "TOO SHORT TO JUDGE")

    def test_an_edge_that_does_not_hold_at_every_long_horizon_is_downgraded(self):
        self.assertEqual(eq._verdict(self._overall(12.0, -1.0))["headline"],
                         "TOO SMALL TO RELY ON")

    def test_a_large_consistent_edge_is_reported_but_still_caveated(self):
        v = eq._verdict(self._overall(9.0, 11.0))
        self.assertEqual(v["headline"], "SOME ADVANTAGE")
        self.assertIn("overlap", v["detail"])

    def test_no_data_is_unavailable_not_zero(self):
        self.assertEqual(eq._verdict({})["headline"], "UNAVAILABLE")


class TestRunEntryQuality(unittest.TestCase):
    def test_end_to_end_produces_all_horizons_and_a_verdict(self):
        out = eq.run_entry_quality({"NVDA": bars(seed=7, n=900)}, ["NVDA"], {})
        self.assertEqual(set(out["overall"].keys()), {l for l, _ in eq.HORIZONS})
        self.assertIn("headline", out["verdict"])
        self.assertTrue(out["limitations"])
        self.assertEqual(out["config"]["min_score_effective"], 62.0)

    def test_min_score_below_the_buy_floor_is_clamped(self):
        out = eq.run_entry_quality({"NVDA": bars(seed=8, n=800)}, ["NVDA"], {"min_score": 10})
        self.assertEqual(out["config"]["min_score"], 10)
        self.assertEqual(out["config"]["min_score_effective"], 62.0)

    def test_ticker_with_too_little_history_is_skipped_and_reported(self):
        out = eq.run_entry_quality({"NVDA": bars(n=50)}, ["NVDA"], {})
        self.assertIn("NVDA", out["tickers_skipped"])
        self.assertNotIn("NVDA", out["by_ticker"])

    def test_missing_ticker_is_skipped_rather_than_crashing(self):
        out = eq.run_entry_quality({}, ["NVDA"], {})
        self.assertIn("NVDA", out["tickers_skipped"])

    def test_survivorship_bias_is_stated_first(self):
        out = eq.run_entry_quality({"NVDA": bars(seed=9, n=800)}, ["NVDA"], {})
        self.assertIn("SURVIVORSHIP", out["limitations"][0])

    def test_overlap_caveat_is_present(self):
        out = eq.run_entry_quality({"NVDA": bars(seed=10, n=800)}, ["NVDA"], {})
        self.assertTrue(any("overlap" in l.lower() for l in out["limitations"]))


class TestPageWiring(unittest.TestCase):
    def setUp(self):
        import app as app_module
        self.client = app_module.create_app().test_client()

    def test_page_still_renders_but_is_deliberately_not_in_the_nav(self):
        """Entry Test was retired from the menu, not deleted.

        It was a diagnostic asking whether the signal score predicts anything. It answered no,
        and so did the other diagnostics, by separate methods. Leaving it one click away invites
        re-running it until it finally reads well. The route is kept working so the finding can
        still be revisited on purpose — restoring it to the menu is one tuple in app.py.
        """
        self.assertEqual(self.client.get("/entry-test").status_code, 200)
        self.assertNotIn(b'href="/entry-test"', self.client.get("/").data)

    def test_script_referenced_by_the_template_exists(self):
        frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
        html = (frontend / "templates" / "entry_test.html").read_text()
        self.assertIn("js/entry_test.js", html)
        self.assertTrue((frontend / "static" / "js" / "entry_test.js").exists())

    def test_run_endpoint_reports_unavailable_without_credentials(self):
        from config import Config
        with patch.object(Config, "has_alpaca_credentials", staticmethod(lambda: False)):
            resp = self.client.post("/api/entry-test/run", json={})
        self.assertEqual(resp.status_code, 200)
        self.assertIn("error", resp.get_json())

    def test_unknown_run_id_is_a_404_not_an_empty_result(self):
        self.assertEqual(self.client.get("/api/entry-test/runs/999999").status_code, 404)


if __name__ == "__main__":
    unittest.main()
