"""
The point-in-time machinery behind the C1 historical validation.

THESE TESTS GATE THE RUN. The validation is worthless — worse than worthless, because it would
look authoritative — if a single filing published after the scoring date can reach the score. So
every guard named in the approved methodology is asserted here before the backtest is allowed to
execute:

  * no filing published after the scoring date enters the score;
  * later restatements cannot leak backwards;
  * the five-period window is fixed;
  * EPS links never cross incompatible filing/share bases;
  * forward outcomes are unreachable from the scoring calculation;
  * future price bars cannot enter a historical score;
  * the C1 constants are exactly the frozen ones;
  * the scoring dates and forward window match the pre-registration.

The last two matter as much as the look-ahead ones. A backtest that quietly tests a slightly
different model, or runs on slightly different dates than were pre-registered, is fitting with
extra steps.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
from config import STOCK_UNIVERSE  # noqa: E402
from providers.edgar_concepts import HISTORY_VALUE_FIELDS  # noqa: E402
from providers.fundamentals_base import AnnualPeriod  # noqa: E402
from services import company_health as ch  # noqa: E402
from services import data_validation_service as dv  # noqa: E402
from services import fundamentals_history_service as fh  # noqa: E402
from services import health_backtest as hb  # noqa: E402

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]))
    conn.commit()
    return conn


def period(period_end, filed, ticker="AAPL", **values):
    full = {f: None for f in HISTORY_VALUE_FIELDS}
    full.update(values)
    return AnnualPeriod(ticker=ticker, source="test", period_end=period_end, filed=filed,
                        taxonomy="us-gaap", currency="USD", form="10-K", values=full)


def store(db, ticker, periods):
    for p in periods:
        p.ticker = ticker
    fh.store_history(db, ticker, periods)


def year(period_end, filed, revenue, ticker="AAPL", **over):
    base = dict(revenue=revenue, gross_profit=revenue * 0.45, operating_income=revenue * 0.25,
                net_income=revenue * 0.20, eps_diluted=revenue / 1e9, basic_shares=1e9,
                diluted_shares=1.02e9, shares_outstanding=1e9, operating_cash_flow=revenue * 0.24,
                capex=revenue * 0.04, total_assets=revenue * 1.2, current_assets=revenue * 0.5,
                current_liabilities=revenue * 0.4, stockholders_equity=revenue * 0.6,
                total_debt=revenue * 0.3, total_cash=revenue * 0.2,
                depreciation_amortisation=revenue * 0.03, interest_expense=revenue * 0.01,
                buybacks=revenue * 0.05, dividends_paid=revenue * 0.02)
    base.update(over)
    return period(period_end, filed, ticker=ticker, **base)


# =================================================================================================
# THE PRE-REGISTRATION, PINNED
# =================================================================================================
class ThePreRegistrationIsExactlyWhatWasApproved(unittest.TestCase):

    def test_the_four_scoring_dates(self):
        self.assertEqual(hb.SCORING_DATES,
                         ("2019-06-30", "2020-06-30", "2021-06-30", "2022-06-30"))

    def test_the_history_window_is_five_periods_and_fixed(self):
        self.assertEqual(hb.HISTORY_PERIODS, 5)

    def test_the_forward_window_is_three_years(self):
        self.assertEqual(hb.FORWARD_YEARS, 3)

    def test_the_five_forward_measures_and_their_directions(self):
        self.assertEqual(hb.FORWARD_MEASURES, (
            ("revenue_cagr_pct", True),
            ("operating_margin_change_pp", True),
            ("roic_change_pp", True),
            ("net_debt_to_ebitda_change", False),
            ("fcf_margin_change_pp", True)))

    def test_the_group_definitions_and_minimum_sample_sizes(self):
        self.assertEqual(hb.STRONG_GROUP, ("STRONG", "SOLID"))
        self.assertEqual(hb.WEAK_GROUP, ("ADEQUATE", "WEAK"))
        self.assertEqual(hb.MIN_COMPANIES_PER_DATE, 25)
        self.assertEqual(hb.MIN_GROUP_SIZE, 8)

    def test_no_p_value_is_produced_anywhere(self):
        """Four overlapping windows over one fixed set of fifty companies are not independent
        observations. A p-value computed as though they were would be the single most misleading
        number this study could publish."""
        result = hb.mann_whitney_u([1.0, 2.0, 3.0], [0.1, 0.2, 0.3])
        self.assertNotIn("p", result)
        self.assertNotIn("p_value", result)
        source = (Path(__file__).resolve().parent.parent / "services" / "health_backtest.py")
        self.assertNotIn("p_value", source.read_text())


class TheFrozenC1ModelIsWhatIsBeingTested(unittest.TestCase):
    """A backtest that quietly tests a slightly different model is fitting with extra steps."""

    def test_the_backtest_imports_the_model_rather_than_reimplementing_it(self):
        source = (Path(__file__).resolve().parent.parent / "services" / "health_backtest.py").read_text()
        self.assertIn("from services import company_health as ch", source)
        # No anchor, weight or band may be restated here — there must be exactly one definition.
        for forbidden in ("COMPANY_HEALTH_MODEL = {", "VERDICT_BANDS = (", "COVERAGE_GATE_PCT ="):
            self.assertNotIn(forbidden, source)

    def test_the_c1_constants_are_the_frozen_ones(self):
        self.assertEqual(ch.COVERAGE_GATE_PCT, 75.0)
        self.assertEqual(ch.RED_FLAG_CATEGORY_SCORE, 25.0)
        self.assertEqual(ch.RED_FLAG_MIN_CATEGORY_COVERAGE_PCT, 50.0)
        self.assertEqual(ch.CAP_AT_N_RED_FLAGS, 2)
        self.assertEqual(ch.SOLVENCY_CATEGORY, "balance_sheet")
        self.assertEqual(ch.VERDICT_BANDS,
                         ((80.0, "STRONG"), (65.0, "SOLID"), (50.0, "ADEQUATE"), (0.0, "WEAK")))
        self.assertEqual({n: w for n, (w, _m) in ch.COMPANY_HEALTH_MODEL.items()},
                         {"profitability_returns": 25, "growth_durability": 20,
                          "cashflow_quality": 15, "balance_sheet": 15, "moat_evidence": 15,
                          "capital_allocation": 10})


# =================================================================================================
# LOOK-AHEAD
# =================================================================================================
class NoFilingPublishedAfterTheScoringDateCanEnter(unittest.TestCase):

    def _db(self):
        db = make_db()
        store(db, "AAPL", [
            year("2016-12-31", "2017-02-10", 100e9),
            year("2017-12-31", "2018-02-10", 110e9),
            year("2018-12-31", "2019-02-10", 120e9),
            # Published AFTER a 2019-06-30 scoring date. Must be invisible.
            year("2019-12-31", "2020-02-10", 400e9),
            year("2020-12-31", "2021-02-10", 500e9),
        ])
        return db

    def test_a_later_filing_is_not_in_the_periods_used(self):
        s = hb.score_at(self._db(), "AAPL", "2019-06-30")
        self.assertNotIn("2019-12-31", s["period_ends"])
        self.assertNotIn("2020-12-31", s["period_ends"])
        self.assertEqual(s["period_ends"][0], "2018-12-31")

    def test_the_score_is_unchanged_by_data_that_did_not_exist_yet(self):
        """THE CENTRAL LOOK-AHEAD TEST. The same company scored at the same date, once with future
        filings present in the database and once without, must produce an identical score. If it
        does not, something is reading past the cutoff."""
        with_future = hb.score_at(self._db(), "AAPL", "2019-06-30")

        without = make_db()
        store(without, "AAPL", [
            year("2016-12-31", "2017-02-10", 100e9),
            year("2017-12-31", "2018-02-10", 110e9),
            year("2018-12-31", "2019-02-10", 120e9),
        ])
        self.assertEqual(with_future["score"], hb.score_at(without, "AAPL", "2019-06-30")["score"])
        self.assertEqual(with_future["coverage_pct"],
                         hb.score_at(without, "AAPL", "2019-06-30")["coverage_pct"])

    def test_a_filing_on_the_scoring_date_itself_is_included(self):
        """The boundary is inclusive: a document published that morning was available."""
        db = make_db()
        store(db, "AAPL", [year("2018-12-31", "2019-06-30", 120e9),
                           year("2017-12-31", "2018-02-10", 110e9),
                           year("2016-12-31", "2017-02-10", 100e9)])
        self.assertIn("2018-12-31", hb.score_at(db, "AAPL", "2019-06-30")["period_ends"])


class RestatementsCannotLeakBackwards(unittest.TestCase):

    def test_a_later_restatement_of_an_old_year_is_excluded(self):
        """The same fiscal year, reported once in 2019 and restated in 2021. A 2019 score must see
        the original figure — excluded by the WHERE clause, not merely ignored."""
        db = make_db()
        store(db, "AAPL", [
            year("2016-12-31", "2017-02-10", 100e9),
            year("2017-12-31", "2018-02-10", 110e9),
            year("2018-12-31", "2019-02-10", 120e9),
            year("2018-12-31", "2021-02-10", 999e9),      # restated, years later
        ])
        rows = fh.history(db, "AAPL", as_of_filed="2019-06-30", limit=5)
        newest = next(r for r in rows if r["period_end"] == "2018-12-31")
        self.assertEqual(newest["revenue"], 120e9)
        self.assertEqual(newest["filed"], "2019-02-10")

    def test_the_restatement_is_visible_once_it_has_been_published(self):
        """The mirror image. Point-in-time must not mean permanently blind — at a later date the
        restated figure is the correct one to use."""
        db = make_db()
        store(db, "AAPL", [
            year("2016-12-31", "2017-02-10", 100e9),
            year("2017-12-31", "2018-02-10", 110e9),
            year("2018-12-31", "2019-02-10", 120e9),
            year("2018-12-31", "2021-02-10", 999e9),
        ])
        rows = fh.history(db, "AAPL", as_of_filed="2022-06-30", limit=5)
        newest = next(r for r in rows if r["period_end"] == "2018-12-31")
        self.assertEqual(newest["revenue"], 999e9)


class TheHistoryWindowIsFixed(unittest.TestCase):

    def test_no_more_than_five_periods_are_used_however_many_exist(self):
        db = make_db()
        store(db, "AAPL", [year(f"{y}-12-31", f"{y + 1}-02-10", 100e9 + y) for y in range(2010, 2019)])
        s = hb.score_at(db, "AAPL", "2019-06-30")
        self.assertEqual(len(s["period_ends"]), 5)
        self.assertEqual(s["period_ends"][0], "2018-12-31")

    def test_the_window_is_the_same_at_every_scoring_date(self):
        db = make_db()
        store(db, "AAPL", [year(f"{y}-12-31", f"{y + 1}-02-10", 100e9 + y) for y in range(2010, 2026)])
        for scoring_date in hb.SCORING_DATES:
            self.assertEqual(len(hb.score_at(db, "AAPL", scoring_date)["period_ends"]),
                             hb.HISTORY_PERIODS, scoring_date)


class EpsLinksNeverCrossAnIncompatibleShareBasis(unittest.TestCase):

    def test_every_growth_link_comes_from_one_filing(self):
        """A split rewrites per-share history. Comparing EPS across two filings would manufacture
        growth that never happened, so each link is formed within a single filing and only then
        chained."""
        db = make_db()
        store(db, "AAPL", [
            # One filing carrying three comparative years — the only place a link may form.
            period("2018-12-31", "2019-02-10", revenue=120e9, eps_diluted=3.00,
                   diluted_shares=1e9, net_income=24e9),
            period("2017-12-31", "2019-02-10", revenue=110e9, eps_diluted=2.50,
                   diluted_shares=1e9, net_income=20e9),
            period("2016-12-31", "2019-02-10", revenue=100e9, eps_diluted=2.00,
                   diluted_shares=1e9, net_income=17e9),
            # An earlier filing on a PRE-SPLIT basis: ten times the per-share figures.
            period("2016-12-31", "2017-02-10", revenue=100e9, eps_diluted=20.00,
                   diluted_shares=100e6, net_income=17e9),
        ])
        out = dv.validate_ticker(db, "AAPL", price=None, as_of_filed="2019-06-30",
                                 years=hb.HISTORY_PERIODS)
        chain = out["eps_chain"]
        for link in chain.get("links") or []:
            self.assertEqual(link["reported_in_filing"], "2019-02-10")

    def test_no_link_is_formed_from_the_pre_split_filing_against_the_post_split_one(self):
        db = make_db()
        store(db, "AAPL", [
            period("2018-12-31", "2019-02-10", revenue=120e9, eps_diluted=3.00, net_income=24e9),
            period("2017-12-31", "2017-02-10", revenue=110e9, eps_diluted=25.00, net_income=20e9),
        ])
        out = dv.validate_ticker(db, "AAPL", price=None, as_of_filed="2019-06-30",
                                 years=hb.HISTORY_PERIODS)
        # Two periods from two different filings: no within-filing pair exists, so no chain.
        self.assertIsNone(out["metrics"]["eps_cagr_pct"]["value"])


class ForwardOutcomesAreUnreachableFromTheScore(unittest.TestCase):

    def _db(self):
        db = make_db()
        store(db, "AAPL", [year(f"{y}-12-31", f"{y + 1}-02-10", 100e9 * (1.1 ** (y - 2014)))
                           for y in range(2014, 2026)])
        return db

    def test_the_scorer_is_never_given_a_forward_outcome(self):
        """Structural, not conventional: there is no parameter through which an outcome, a forward
        date or a price could be supplied to the scorer."""
        import inspect
        params = set(inspect.signature(hb.score_at).parameters)
        self.assertEqual(params, {"db", "ticker", "scoring_date", "cache"})
        for forbidden in ("outcome", "forward", "price", "future", "result"):
            self.assertFalse([p for p in params if forbidden in p], forbidden)

    def test_the_cache_cannot_serve_a_result_from_a_different_as_of_date(self):
        """The cache exists only to avoid recomputing, and it is keyed on the as-of date. If it
        were keyed on the ticker alone, a forward-dated validation computed for the outcome path
        would be handed straight back to the scorer — look-ahead introduced by an optimisation,
        which is exactly how such a bug arrives unnoticed."""
        db = self._db()
        cache = {}
        early = hb.score_at(db, "AAPL", "2019-06-30", cache)
        late = hb.score_at(db, "AAPL", "2022-06-30", cache)
        self.assertEqual(set(cache), {("AAPL", "2019-06-30"), ("AAPL", "2022-06-30")})
        self.assertNotEqual(early["period_ends"], late["period_ends"])

    def test_a_cached_run_gives_identical_results_to_an_uncached_one(self):
        db = self._db()
        uncached = hb.run_date(db, ["AAPL"], "2019-06-30")
        cached = hb.run_date(db, ["AAPL"], "2019-06-30", {})
        self.assertEqual(uncached["companies"], cached["companies"])

    def test_the_forward_outcome_reads_a_strictly_later_period(self):
        o = hb.forward_outcome(self._db(), "AAPL", "2019-06-30")
        self.assertEqual(o["forward_date"], "2022-06-30")
        self.assertGreater(o["forward_period_end"], o["base_period_end"])

    def test_computing_the_outcome_does_not_alter_the_score(self):
        db = self._db()
        before = hb.score_at(db, "AAPL", "2019-06-30")["score"]
        hb.forward_outcome(db, "AAPL", "2019-06-30")
        self.assertEqual(hb.score_at(db, "AAPL", "2019-06-30")["score"], before)

    def test_an_outcome_with_no_later_period_is_excluded_not_invented(self):
        db = make_db()
        store(db, "AAPL", [year("2018-12-31", "2019-02-10", 120e9),
                           year("2017-12-31", "2018-02-10", 110e9),
                           year("2016-12-31", "2017-02-10", 100e9)])
        o = hb.forward_outcome(db, "AAPL", "2019-06-30")
        self.assertIsNotNone(o["excluded"])
        self.assertEqual(o["measures"], {})


class FuturePriceBarsCannotEnterAHistoricalScore(unittest.TestCase):

    def test_no_price_is_passed_to_the_historical_scorer(self):
        source = (Path(__file__).resolve().parent.parent / "services" / "health_backtest.py").read_text()
        self.assertIn("price=None", source)

    def test_the_score_is_identical_with_and_without_bars_in_the_database(self):
        """Company Health touches no price by design. This proves it end to end at a historical
        date: inserting bars dated AFTER the scoring date must change nothing."""
        db = make_db()
        store(db, "AAPL", [year(f"{y}-12-31", f"{y + 1}-02-10", 100e9 + y) for y in range(2014, 2019)])
        before = hb.score_at(db, "AAPL", "2019-06-30")["score"]
        for i, ts in enumerate(("2021-01-04", "2022-01-04", "2025-01-06")):
            db.execute("INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, "
                       "volume) VALUES (?, '1Day', ?, 1, 1, 1, ?, 1)", ("AAPL", ts, 500 + i))
        db.commit()
        self.assertEqual(hb.score_at(db, "AAPL", "2019-06-30")["score"], before)


# =================================================================================================
# STATISTICS
# =================================================================================================
class RankingAndStatistics(unittest.TestCase):

    def test_ranks_are_ascending_with_ties_shared(self):
        self.assertEqual(hb.rank_ascending([10, 20, 30]), [1.0, 2.0, 3.0])
        self.assertEqual(hb.rank_ascending([10, 10, 30]), [1.5, 1.5, 3.0])

    def test_spearman_is_one_for_a_perfect_ordering(self):
        self.assertAlmostEqual(hb.spearman([1, 2, 3, 4], [10, 20, 30, 40]), 1.0)

    def test_spearman_is_minus_one_when_reversed(self):
        self.assertAlmostEqual(hb.spearman([1, 2, 3, 4], [40, 30, 20, 10]), -1.0)

    def test_spearman_refuses_a_sample_too_small_to_mean_anything(self):
        self.assertIsNone(hb.spearman([1, 2], [2, 1]))

    def test_an_inverted_measure_is_flipped_before_ranking(self):
        """Leverage rising is deterioration. A company whose net debt fell must rank BETTER on it
        than one whose net debt rose, and a sign error here would invert the whole result."""
        outcomes = [
            {"ticker": "GOOD", "measures": {"net_debt_to_ebitda_change": -1.0}},
            {"ticker": "BAD", "measures": {"net_debt_to_ebitda_change": +1.0}},
        ]
        composites = hb.composite_ranks(outcomes)
        self.assertGreater(composites["GOOD"][0], composites["BAD"][0])

    def test_a_non_inverted_measure_ranks_the_obvious_way(self):
        outcomes = [
            {"ticker": "GOOD", "measures": {"revenue_cagr_pct": 20.0}},
            {"ticker": "BAD", "measures": {"revenue_cagr_pct": 1.0}},
        ]
        composites = hb.composite_ranks(outcomes)
        self.assertGreater(composites["GOOD"][0], composites["BAD"][0])

    def test_a_company_missing_a_measure_is_ranked_on_the_rest(self):
        """Dropping every company with one gap would quietly select for well-covered companies,
        which is its own bias. The count of measures used travels with the result."""
        outcomes = [
            {"ticker": "FULL", "measures": {"revenue_cagr_pct": 10.0, "roic_change_pp": 2.0}},
            {"ticker": "PART", "measures": {"revenue_cagr_pct": 5.0}},
            {"ticker": "OTHER", "measures": {"revenue_cagr_pct": 1.0, "roic_change_pp": 1.0}},
        ]
        composites = hb.composite_ranks(outcomes)
        self.assertEqual(composites["PART"][1], 1)
        self.assertEqual(composites["FULL"][1], 2)

    def test_the_effect_size_is_plus_one_when_every_a_beats_every_b(self):
        result = hb.mann_whitney_u([5.0, 6.0, 7.0], [1.0, 2.0, 3.0])
        self.assertAlmostEqual(result["rank_biserial"], 1.0)

    def test_the_effect_size_is_minus_one_when_reversed(self):
        result = hb.mann_whitney_u([1.0, 2.0, 3.0], [5.0, 6.0, 7.0])
        self.assertAlmostEqual(result["rank_biserial"], -1.0)


class UnderpoweredResultsAreLabelledNotPresented(unittest.TestCase):

    def test_a_thin_date_is_marked_underpowered_and_gets_no_correlation(self):
        db = make_db()
        for ticker in ("AAPL", "MSFT", "NVDA"):
            store(db, ticker, [year(f"{y}-12-31", f"{y + 1}-02-10", 100e9 + y, ticker=ticker)
                               for y in range(2014, 2026)])
        out = hb.run_date(db, ["AAPL", "MSFT", "NVDA"], "2019-06-30")
        self.assertLess(out["analysed"], hb.MIN_COMPANIES_PER_DATE)
        self.assertTrue(out["underpowered"])
        self.assertIn(hb.UNDERPOWERED, out["underpowered"][0])
        self.assertIsNone(out["spearman_score_vs_forward"])

    def test_every_exclusion_is_named_and_reasoned(self):
        """A silent exclusion is how a backtest becomes flattering without anybody deciding to
        make it so."""
        db = make_db()
        store(db, "AAPL", [year(f"{y}-12-31", f"{y + 1}-02-10", 100e9 + y) for y in range(2014, 2026)])
        out = hb.run_date(db, ["AAPL", "MSFT"], "2019-06-30")
        excluded = out["excluded_at_scoring"] + out["excluded_at_outcome"]
        self.assertTrue(any(e["ticker"] == "MSFT" for e in excluded))
        for entry in excluded:
            self.assertTrue(entry.get("reason"))


if __name__ == "__main__":
    unittest.main()
