"""
Tests for services/strategy_service.py and the Strategy Lab wiring.

Two things must hold or the whole lab is worthless:

  1. The BASELINE must keep behaving exactly as v1.0 always did. It is the control for every
     comparison, and a control that drifts turns every result into noise.
  2. A strategy must only be able to change how components are WEIGHTED and which entries are
     VETOED — never what a component means. Otherwise "strategy B beat strategy A" could be
     measuring two different definitions of momentum rather than two different opinions of it.
"""
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import database
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import strategy_service as ss
from services import backtest_service as bt

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    conn.commit()
    return conn


def bars(n=800, seed=0):
    rng = np.random.default_rng(seed)
    trend = 100 + np.cumsum(0.2 + rng.normal(0, 1.6, n))
    closes = np.maximum(trend + 6.0 * np.sin(np.arange(n) * 2 * np.pi / 25), 1.0)
    ts = [(datetime(2021, 1, 4) + timedelta(days=i)).date().isoformat() for i in range(n)]
    return pd.DataFrame({"ts": ts, "open": closes, "high": closes * 1.01,
                         "low": closes * 0.99, "close": closes,
                         "volume": [1_000_000.0] * n})


class TestBaselineIsUnchanged(unittest.TestCase):
    """The most important tests in this file."""

    def test_default_strategy_matches_the_engine_constants(self):
        from services.signal_engine import SIGNAL_THRESHOLDS, WEIGHTS
        d = ss.default_strategy()
        self.assertEqual(d["buy_threshold"], next(t for t, n in SIGNAL_THRESHOLDS if n == "BUY"))
        self.assertEqual(d["strong_buy_threshold"],
                         next(t for t, n in SIGNAL_THRESHOLDS if n == "STRONG BUY"))
        self.assertEqual(d["weights"]["long_trend"], WEIGHTS["long_term_trend"])
        self.assertEqual(d["weights"]["momentum"], WEIGHTS["momentum"])

    def test_scoring_under_the_default_strategy_equals_the_original_scorer(self):
        """Re-weighting with the DEFAULT weights must reproduce the original number exactly, or
        every historical result recorded before the lab existed becomes incomparable."""
        df = bars(seed=3)
        pre = bt._precompute(df)
        d = ss.default_strategy()
        checked = 0
        for i in range(bt.MIN_WARMUP_BARS, len(df) - 1, 37):
            ind = bt._indicators_at(df, pre, i)
            if not ind.get("bars_used"):
                continue
            old = bt._score_from_indicators(ind, {})
            new = bt._score_with_strategy(ind, {}, d)
            self.assertAlmostEqual(old["score"], new["score"], places=6)
            self.assertEqual(old["label"], new["label"])
            checked += 1
        self.assertGreater(checked, 5, "fixture produced too few bars to prove anything")

    def test_simulating_with_no_strategy_matches_simulating_with_the_baseline(self):
        df = bars(seed=4)
        a = bt._simulate_ticker("NVDA", df, {}, {})
        b = bt._simulate_ticker("NVDA", df, {}, {}, ss.default_strategy())
        self.assertEqual(len(a), len(b))
        for x, y in zip(a, b):
            self.assertEqual(x["signal_date"], y["signal_date"])
            self.assertAlmostEqual(x["entry_price"], y["entry_price"], places=6)


class TestReweighting(unittest.TestCase):
    def test_zero_weight_removes_a_component_entirely(self):
        components = {"long_trend": 20.0, "momentum": 0.0}
        s = ss.normalise_strategy({"weights": {k: 0 for k in ss.TESTABLE_COMPONENTS}})
        s["weights"]["long_trend"] = 10
        # Only long_trend counts, and it scored full marks, so the result is 100.
        self.assertEqual(ss.score_from_components(components, s)["score"], 100.0)

    def test_relative_weights_are_what_matter_not_absolute(self):
        components = {"long_trend": 10.0, "momentum": 15.0}   # half marks, full marks
        small = ss.normalise_strategy({"weights": {"long_trend": 2, "momentum": 2}})
        large = ss.normalise_strategy({"weights": {"long_trend": 20, "momentum": 20}})
        for k in ss.TESTABLE_COMPONENTS:
            if k not in ("long_trend", "momentum"):
                small["weights"][k] = 0
                large["weights"][k] = 0
        self.assertAlmostEqual(ss.score_from_components(components, small)["score"],
                               ss.score_from_components(components, large)["score"], places=6)

    def test_uncomputable_components_are_excluded_not_scored_zero(self):
        s = ss.default_strategy()
        both = ss.score_from_components({"long_trend": 20.0, "momentum": 15.0}, s)
        one = ss.score_from_components({"long_trend": 20.0, "momentum": None}, s)
        # Full marks on what WAS computable is 100 either way. Treating the missing one as zero
        # would drag the second down and quietly punish a stock for a data gap.
        self.assertEqual(both["score"], 100.0)
        self.assertEqual(one["score"], 100.0)

    def test_no_computable_components_gives_no_data_not_zero(self):
        out = ss.score_from_components({k: None for k in ss.TESTABLE_COMPONENTS},
                                       ss.default_strategy())
        self.assertEqual(out["label"], "NO DATA")


class TestValidation(unittest.TestCase):
    def test_garbage_falls_back_to_the_baseline_rather_than_a_broken_rule(self):
        s = ss.normalise_strategy({"weights": {"momentum": "banana"}, "buy_threshold": "x"})
        self.assertEqual(s["weights"]["momentum"], ss.COMPONENT_DEFAULT_MAX["momentum"])
        self.assertEqual(s["buy_threshold"], ss.default_strategy()["buy_threshold"])

    def test_none_produces_a_complete_valid_strategy(self):
        s = ss.normalise_strategy(None)
        self.assertEqual(set(s["weights"]), set(ss.TESTABLE_COMPONENTS))
        self.assertIn("filters", s)
        self.assertIn("exits", s)

    def test_weights_are_clamped(self):
        s = ss.normalise_strategy({"weights": {"momentum": 9999, "volume": -5}})
        self.assertEqual(s["weights"]["momentum"], ss.MAX_WEIGHT)
        self.assertEqual(s["weights"]["volume"], 0)

    def test_strong_buy_below_buy_is_corrected(self):
        """Non-monotonic labels would make STRONG BUY unreachable and every comparison that
        mentions it meaningless."""
        s = ss.normalise_strategy({"buy_threshold": 70, "strong_buy_threshold": 40})
        self.assertGreaterEqual(s["strong_buy_threshold"], s["buy_threshold"])

    def test_thresholds_are_clamped_into_range(self):
        s = ss.normalise_strategy({"buy_threshold": 500, "strong_buy_threshold": -20})
        self.assertLessEqual(s["buy_threshold"], ss.MAX_THRESHOLD)
        self.assertGreaterEqual(s["strong_buy_threshold"], ss.MIN_THRESHOLD)

    def test_empty_filter_values_mean_off_not_zero(self):
        """An RSI filter of 0 would veto everything; an empty box must mean 'no filter'."""
        s = ss.normalise_strategy({"filters": {"max_rsi": "", "min_rsi": None}})
        self.assertIsNone(s["filters"]["max_rsi"])
        self.assertIsNone(s["filters"]["min_rsi"])


class TestFilters(unittest.TestCase):
    def test_filters_can_only_remove_entries(self):
        s = ss.normalise_strategy({"filters": {"max_rsi": 30}})
        ind_high = {"rsi14": 80.0}
        ind_low = {"rsi14": 20.0}
        self.assertFalse(ss.passes_filters(ind_high, {}, s))
        self.assertTrue(ss.passes_filters(ind_low, {}, s))

    def test_unknown_rsi_fails_a_filter_that_needs_it(self):
        """Passing on missing data would silently disable the filter exactly when the data is
        worst, which is the opposite of what the user asked for."""
        s = ss.normalise_strategy({"filters": {"max_rsi": 30}})
        self.assertFalse(ss.passes_filters({"rsi14": None}, {}, s))

    def test_bull_regime_filter(self):
        s = ss.normalise_strategy({"filters": {"require_bull_regime": True}})
        self.assertTrue(ss.passes_filters({}, {"regime": "BULL"}, s))
        self.assertTrue(ss.passes_filters({}, {"regime": "STRONG BULL"}, s))
        self.assertFalse(ss.passes_filters({}, {"regime": "BEAR"}, s))
        self.assertFalse(ss.passes_filters({}, {}, s))

    def test_sma200_filter(self):
        s = ss.normalise_strategy({"filters": {"require_above_sma200": True}})
        self.assertTrue(ss.passes_filters({"reference_price": 110, "sma200": 100}, {}, s))
        self.assertFalse(ss.passes_filters({"reference_price": 90, "sma200": 100}, {}, s))
        self.assertFalse(ss.passes_filters({"reference_price": None, "sma200": 100}, {}, s))

    def test_no_filters_passes_everything(self):
        self.assertTrue(ss.passes_filters({}, {}, ss.default_strategy()))

    def test_a_filter_downgrades_the_label_without_touching_the_score(self):
        df = bars(seed=6)
        pre = bt._precompute(df)
        impossible = ss.normalise_strategy({"filters": {"max_rsi": 0, "min_rsi": 100}})
        for i in range(bt.MIN_WARMUP_BARS, len(df) - 1, 53):
            ind = bt._indicators_at(df, pre, i)
            if not ind.get("bars_used"):
                continue
            out = bt._score_with_strategy(ind, {}, impossible)
            self.assertNotIn(out["label"], ("BUY", "STRONG BUY"))


class TestRandomStrategy(unittest.TestCase):
    def test_random_only_randomises_the_weights(self):
        """If thresholds or filters varied too, a random strategy could beat the real one on a
        better THRESHOLD and the result would be misread as evidence about the weights."""
        rng = np.random.default_rng(1)
        base = ss.normalise_strategy({"buy_threshold": 70, "filters": {"max_rsi": 40}})
        r = ss.random_strategy(rng, base)
        self.assertEqual(r["buy_threshold"], base["buy_threshold"])
        self.assertEqual(r["filters"], base["filters"])
        self.assertEqual(r["exits"], base["exits"])
        self.assertNotEqual(r["weights"], base["weights"])

    def test_random_strategy_is_never_all_zero(self):
        rng = np.random.default_rng(7)
        for _ in range(30):
            self.assertGreater(ss.total_weight(ss.random_strategy(rng)), 0)


class TestPersistence(unittest.TestCase):
    def test_baseline_is_created_once_and_only_once(self):
        db = make_db()
        ss.ensure_baseline(db)
        ss.ensure_baseline(db)
        rows = [s for s in ss.list_strategies(db) if s["is_baseline"]]
        self.assertEqual(len(rows), 1)

    def test_baseline_cannot_be_edited(self):
        db = make_db()
        base = next(s for s in ss.list_strategies(db) if s["is_baseline"])
        with self.assertRaises(ValueError):
            ss.save_strategy(db, {"name": "hacked"}, base["id"])

    def test_baseline_cannot_be_deleted(self):
        db = make_db()
        base = next(s for s in ss.list_strategies(db) if s["is_baseline"])
        with self.assertRaises(ValueError):
            ss.delete_strategy(db, base["id"])

    def test_save_and_read_back_round_trips(self):
        db = make_db()
        new_id = ss.save_strategy(db, {"name": "Pullbacks only",
                                       "weights": {"rsi_pullback": 40, "momentum": 0},
                                       "buy_threshold": 55,
                                       "filters": {"max_rsi": 35}})
        got = ss.get_strategy(db, new_id)
        self.assertEqual(got["config"]["name"], "Pullbacks only")
        self.assertEqual(got["config"]["weights"]["rsi_pullback"], 40)
        self.assertEqual(got["config"]["weights"]["momentum"], 0)
        self.assertEqual(got["config"]["filters"]["max_rsi"], 35)

    def test_attempt_count_excludes_the_baseline(self):
        db = make_db()
        ss.ensure_baseline(db)
        self.assertEqual(ss.attempt_count(db), 0)
        ss.save_strategy(db, {"name": "a"})
        ss.save_strategy(db, {"name": "b"})
        self.assertEqual(ss.attempt_count(db), 2)


class TestStrategyChangesResults(unittest.TestCase):
    """A strategy that cannot change the outcome would make the whole lab theatre."""

    def test_a_different_weighting_produces_different_trades(self):
        """Asserted on the trades themselves, not on how many there are.

        The first version of this test compared trade COUNTS and failed while the engine was
        working perfectly: two very different strategies happened to produce 24 trades each.
        Counts are a lossy summary — the thing that must differ is which bars were bought.
        """
        df = bars(seed=8)
        base = bt._simulate_ticker("NVDA", df, {}, {}, ss.default_strategy())
        only_pullback = ss.normalise_strategy(
            {"weights": {k: (30 if k == "rsi_pullback" else 0) for k in ss.TESTABLE_COMPONENTS}})
        other = bt._simulate_ticker("NVDA", df, {}, {}, only_pullback)
        self.assertTrue(base and other, "fixture produced no trades; the test proves nothing")
        self.assertNotEqual([t["signal_date"] for t in base],
                            [t["signal_date"] for t in other])

    def test_a_different_weighting_changes_the_score_itself(self):
        """The direct version of the same claim, one bar at a time."""
        df = bars(seed=8)
        pre = bt._precompute(df)
        only_pullback = ss.normalise_strategy(
            {"weights": {k: (30 if k == "rsi_pullback" else 0) for k in ss.TESTABLE_COMPONENTS}})
        differences = 0
        for i in range(bt.MIN_WARMUP_BARS, len(df) - 1, 29):
            ind = bt._indicators_at(df, pre, i)
            if not ind.get("bars_used"):
                continue
            a = bt._score_with_strategy(ind, {}, ss.default_strategy())["score"]
            b = bt._score_with_strategy(ind, {}, only_pullback)["score"]
            if abs(a - b) > 1e-9:
                differences += 1
        self.assertGreater(differences, 3, "re-weighting had no effect on any score")

    def test_a_higher_buy_threshold_never_produces_more_trades(self):
        df = bars(seed=9)
        loose = ss.normalise_strategy({"buy_threshold": 55, "strong_buy_threshold": 80})
        tight = ss.normalise_strategy({"buy_threshold": 90, "strong_buy_threshold": 95})
        self.assertGreaterEqual(len(bt._simulate_ticker("NVDA", df, {}, {}, loose)),
                                len(bt._simulate_ticker("NVDA", df, {}, {}, tight)))

    def test_max_holding_days_is_respected_from_the_strategy(self):
        df = bars(seed=10)
        s = ss.normalise_strategy({"exits": {"max_holding_days": 5, "exit_on_signal": False}})
        for t in bt._simulate_ticker("NVDA", df, {}, {}, s):
            if t["exit_reason"] == "TIME_LIMIT":
                self.assertLessEqual(t["holding_days"], 6)

    def test_profit_target_is_measured_from_the_actual_fill(self):
        df = bars(seed=11)
        s = ss.normalise_strategy({"exits": {"profit_target_pct": 3.0, "exit_on_signal": False}})
        hits = [t for t in bt._simulate_ticker("NVDA", df, {}, {}, s)
                if t["exit_reason"] == "TARGET"]
        self.assertTrue(hits, "fixture produced no target exits; test proves nothing")
        for t in hits:
            self.assertAlmostEqual(t["exit_price"] / t["entry_price"], 1.03, places=2)


class TestApiWiring(unittest.TestCase):
    def setUp(self):
        import app as app_module
        self.client = app_module.create_app().test_client()

    def test_page_renders_and_is_in_the_nav(self):
        self.assertEqual(self.client.get("/strategy-lab").status_code, 200)
        self.assertIn(b'href="/strategy-lab"', self.client.get("/").data)

    def test_script_exists(self):
        frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
        self.assertIn("js/strategy_lab.js",
                      (frontend / "templates" / "strategy_lab.html").read_text())
        self.assertTrue((frontend / "static" / "js" / "strategy_lab.js").exists())

    def test_list_returns_the_baseline_and_an_attempt_count(self):
        body = self.client.get("/api/strategies").get_json()
        self.assertTrue(any(s["is_baseline"] for s in body["strategies"]))
        self.assertIn("attempts", body)

    def test_editing_the_baseline_is_rejected_with_a_reason(self):
        body = self.client.get("/api/strategies").get_json()
        base = next(s for s in body["strategies"] if s["is_baseline"])
        resp = self.client.put(f"/api/strategies/{base['id']}", json={"name": "nope"})
        self.assertEqual(resp.status_code, 400)
        self.assertIn("baseline", resp.get_json()["error"].lower())

    def test_unknown_strategy_is_404(self):
        self.assertEqual(self.client.get("/api/strategies/999999").status_code, 404)


class TestEveryTestPageCanChooseAStrategy(unittest.TestCase):
    """The Strategy Lab is useless if the tests cannot be pointed at what it produces.

    The first build of this feature shipped with the API accepting a strategy_id that no page
    ever sent, so strategies could be created and never run. These tests make that failure
    impossible to repeat silently.
    """

    PAGES = [
        ("backtest.html", "backtest.js", "bt-strategy"),
        ("entry_test.html", "entry_test.js", "et-strategy"),
        ("selection_test.html", "selection_test.js", "st-strategy"),
    ]

    def setUp(self):
        self.frontend = Path(__file__).resolve().parent.parent.parent / "frontend"

    def test_each_test_page_has_a_strategy_picker(self):
        for template, _js, element_id in self.PAGES:
            html = (self.frontend / "templates" / template).read_text()
            self.assertIn(f'id="{element_id}"', html, f"{template} has no strategy picker")

    def test_each_page_populates_the_picker(self):
        for _template, js, element_id in self.PAGES:
            src = (self.frontend / "static" / "js" / js).read_text()
            self.assertIn(f'populateStrategySelect("{element_id}")', src,
                          f"{js} never fills its strategy picker")

    def test_each_page_sends_the_chosen_strategy_with_the_run(self):
        """A picker that is displayed but not submitted is worse than none: the result would be
        attributed to a strategy that never ran."""
        for _template, js, element_id in self.PAGES:
            src = (self.frontend / "static" / "js" / js).read_text()
            self.assertIn(f'selectedStrategyId("{element_id}")', src,
                          f"{js} does not send strategy_id when starting a run")

    def test_the_shared_helpers_exist(self):
        api = (self.frontend / "static" / "js" / "api.js").read_text()
        self.assertIn("function populateStrategySelect", api)
        self.assertIn("function selectedStrategyId", api)


if __name__ == "__main__":
    unittest.main()
