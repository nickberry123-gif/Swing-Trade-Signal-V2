"""
Tests for services/selection_service.py.

The danger here is different from the entry test. That one had thousands of rows; this one rests
on roughly 47 monthly decisions, so a plausible-looking result is easy to produce by accident.
These tests check that the ranking is measured honestly, that stocks are aligned by DATE rather
than by row position, and that the wording never promises more than the sample can support.
"""
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import selection_service as sel
from services.backtest_service import MIN_WARMUP_BARS


def bars(n=900, start=100.0, drift=0.2, noise=1.6, seed=0, wave=6.0, period=25, skip_first=0):
    rng = np.random.default_rng(seed)
    trend = start + np.cumsum(drift + rng.normal(0, noise, n))
    cycle = wave * np.sin(np.arange(n) * 2 * np.pi / period)
    closes = np.maximum(trend + cycle, 1.0)
    ts = [(datetime(2021, 1, 4) + timedelta(days=i)).date().isoformat() for i in range(n)]
    df = pd.DataFrame({"ts": ts, "open": closes, "high": closes * 1.01, "low": closes * 0.99,
                       "close": closes, "volume": [1_000_000.0] * n})
    # skip_first simulates a later listing, so row i is a DIFFERENT day for this ticker.
    return df.iloc[skip_first:].reset_index(drop=True)


class TestSpearman(unittest.TestCase):
    def test_perfect_agreement_is_one(self):
        self.assertAlmostEqual(sel._spearman([1, 2, 3, 4], [10, 20, 30, 40]), 1.0, places=6)

    def test_perfectly_backwards_is_minus_one(self):
        self.assertAlmostEqual(sel._spearman([1, 2, 3, 4], [40, 30, 20, 10]), -1.0, places=6)

    def test_identical_scores_have_no_ranking_so_return_none(self):
        """Every stock scoring the same is not a correlation of zero — there is no ordering at
        all, and reporting 0.0 would imply one was measured."""
        self.assertIsNone(sel._spearman([5, 5, 5, 5], [1, 2, 3, 4]))

    def test_ties_are_averaged_not_broken_by_input_order(self):
        a = sel._spearman([1, 1, 2, 2], [10, 20, 30, 40])
        b = sel._spearman([1, 1, 2, 2], [20, 10, 40, 30])
        self.assertAlmostEqual(a, b, places=9)

    def test_too_few_stocks_returns_none(self):
        self.assertIsNone(sel._spearman([1, 2], [3, 4]))


class TestDateAlignment(unittest.TestCase):
    """Two tickers can have different row counts, so row i is not the same day for both. Aligning
    by position instead of date would compare a decision on one day against an outcome on
    another and nobody would ever see it."""

    def test_indices_are_mapped_per_ticker_by_date(self):
        b = {"AAA": bars(n=500), "BBB": bars(n=500, skip_first=30)}
        maps = sel._date_index_maps(b, ["AAA", "BBB"])
        shared = set(maps["AAA"]) & set(maps["BBB"])
        self.assertTrue(shared)
        for d in list(shared)[:20]:
            # Same date, different row number — exactly the case position-matching would break.
            self.assertEqual(str(b["AAA"]["ts"].iloc[maps["AAA"][d]]), d)
            self.assertEqual(str(b["BBB"]["ts"].iloc[maps["BBB"][d]]), d)
        self.assertNotEqual(maps["AAA"], maps["BBB"])

    def test_decision_dates_exist_for_every_ticker(self):
        b = {"AAA": bars(n=700), "BBB": bars(n=700, skip_first=40)}
        maps = sel._date_index_maps(b, ["AAA", "BBB"])
        dates = sel._monthly_decision_dates(b, ["AAA", "BBB"], maps)
        self.assertTrue(dates)
        for d in dates:
            self.assertIn(d, maps["AAA"])
            self.assertIn(d, maps["BBB"])

    def test_decision_dates_are_past_warmup_for_every_ticker(self):
        b = {"AAA": bars(n=700), "BBB": bars(n=700, skip_first=40)}
        maps = sel._date_index_maps(b, ["AAA", "BBB"])
        for d in sel._monthly_decision_dates(b, ["AAA", "BBB"], maps):
            self.assertGreaterEqual(maps["AAA"][d], MIN_WARMUP_BARS)
            self.assertGreaterEqual(maps["BBB"][d], MIN_WARMUP_BARS)

    def test_one_decision_per_calendar_month(self):
        b = {"AAA": bars(n=800)}
        maps = sel._date_index_maps(b, ["AAA"])
        dates = sel._monthly_decision_dates(b, ["AAA"], maps)
        months = [d[:7] for d in dates]
        self.assertEqual(len(months), len(set(months)))

    def test_no_common_dates_gives_no_decisions_rather_than_a_crash(self):
        b = {"AAA": bars(n=400), "BBB": bars(n=400, skip_first=399)}
        maps = sel._date_index_maps(b, ["AAA", "BBB"])
        self.assertEqual(sel._monthly_decision_dates(b, ["AAA", "BBB"], maps), [])


class TestForwardReturn(unittest.TestCase):
    def test_buys_the_bar_after_the_decision(self):
        df = pd.DataFrame({"ts": ["a", "b", "c"], "open": [100.0, 200.0, 300.0],
                           "high": [0, 0, 0], "low": [0, 0, 0],
                           "close": [110.0, 220.0, 330.0], "volume": [1, 1, 1]})
        # Decide on bar 0, buy at bar 1's open (200), value at bar 2's close (330).
        self.assertAlmostEqual(sel._forward_return(df, 0, 1), 65.0, places=6)

    def test_incomplete_horizon_is_none(self):
        self.assertIsNone(sel._forward_return(bars(n=300), 295, 21))


class TestSignificanceIsWithheldWhereInvalid(unittest.TestCase):
    """A t-statistic on overlapping windows is inflated. Printing it with a footnote would be
    worse than not printing it."""

    def test_t_stat_only_reported_for_the_non_overlapping_horizon(self):
        b = {t: bars(n=900, seed=i) for i, t in enumerate(["AAA", "BBB", "CCC", "DDD", "EEE",
                                                           "FFF", "GGG", "HHH", "III"])}
        out = sel.run_selection_test(b, list(b), {"use_regime": False})
        self.assertTrue(out["horizons"]["1 month"]["rank_correlation"]["t_stat_available"])
        for label in ("3 months", "6 months", "12 months", "24 months"):
            rc = out["horizons"][label]["rank_correlation"]
            self.assertFalse(rc["t_stat_available"])
            self.assertIsNone(rc["t_stat"])
            self.assertIn("overlap", rc["t_stat_note"])

    def test_t_stat_maths(self):
        self.assertIsNone(sel._t_stat([1.0, 1.0, 1.0]))       # no variance
        self.assertIsNone(sel._t_stat([1.0]))                  # too few
        self.assertIsNotNone(sel._t_stat([0.1, 0.2, 0.3, 0.15]))


class TestVerdictResistsOverclaiming(unittest.TestCase):
    def _h(self, ic, top_minus_bottom, months=47):
        return {"12 months": {"rank_correlation": {"mean": ic}, "months_used": months,
                              "top_minus_bottom_pct": top_minus_bottom}}

    def test_negative_correlation_reads_as_no_skill(self):
        self.assertEqual(sel._verdict(self._h(-0.08, -4.0))["headline"], "NO SELECTION SKILL")

    def test_a_tiny_correlation_is_not_sold_as_skill(self):
        self.assertEqual(sel._verdict(self._h(0.02, 5.0))["headline"], "WEAK AND INCONSISTENT")

    def test_good_correlation_but_top_losing_to_bottom_is_downgraded(self):
        """The two measures disagreeing means something is being driven by a handful of picks."""
        self.assertEqual(sel._verdict(self._h(0.20, -3.0))["headline"], "WEAK AND INCONSISTENT")

    def test_both_measures_agreeing_is_reported_but_caveated_on_sample_size(self):
        v = sel._verdict(self._h(0.20, 8.0))
        self.assertEqual(v["headline"], "SOME SELECTION SKILL")
        self.assertIn("small sample", v["detail"])

    def test_missing_correlation_is_unavailable(self):
        self.assertEqual(sel._verdict({})["headline"], "UNAVAILABLE")


class TestEndToEnd(unittest.TestCase):
    def setUp(self):
        self.bars = {t: bars(n=900, seed=i) for i, t in enumerate(
            ["AAA", "BBB", "CCC", "DDD", "EEE", "FFF", "GGG", "HHH", "III", "JJJ"])}
        self.out = sel.run_selection_test(self.bars, list(self.bars), {"use_regime": False})

    def test_all_horizons_and_arms_present(self):
        for label, _h in sel.HORIZONS:
            arms = self.out["horizons"][label]["picks"]
            self.assertEqual(set(arms), {"TOP_1", "TOP_3", "EQUAL_WEIGHT", "BOTTOM_1"})

    def test_every_arm_uses_the_same_number_of_months(self):
        """Any difference between arms must be stock choice. Different month counts would make
        it partly a difference in when they bought."""
        for label, _h in sel.HORIZONS:
            counts = {k: v["n"] for k, v in self.out["horizons"][label]["picks"].items()}
            self.assertEqual(len(set(counts.values())), 1, f"{label}: arms used {counts}")

    def test_top1_and_bottom1_bracket_the_equal_weight_arm_is_not_assumed(self):
        """Deliberately NOT asserted — if the score is noise, top can be worse than equal
        weight, and a test demanding otherwise would be encoding a hoped-for result. This test
        only checks the numbers exist and are finite."""
        h = self.out["horizons"]["12 months"]["picks"]
        for arm in ("TOP_1", "EQUAL_WEIGHT", "BOTTOM_1"):
            self.assertIsNotNone(h[arm]["mean_pct"])

    def test_survivorship_warning_comes_first(self):
        self.assertIn("SURVIVORSHIP", self.out["limitations"][0])

    def test_decision_window_is_reported(self):
        self.assertGreater(self.out["decision_dates"], 0)
        self.assertIsNotNone(self.out["first_date"])
        self.assertIsNotNone(self.out["last_date"])

    def test_too_few_tickers_produces_no_months_rather_than_a_ranking_of_two(self):
        out = sel.run_selection_test({"AAA": bars(n=900)}, ["AAA"], {"use_regime": False})
        self.assertEqual(out["horizons"]["12 months"]["months_used"], 0)
        self.assertEqual(out["verdict"]["headline"], "UNAVAILABLE")

    def test_missing_ticker_data_is_ignored_not_crashed_on(self):
        out = sel.run_selection_test(self.bars, list(self.bars) + ["NOPE"], {"use_regime": False})
        self.assertNotIn("NOPE", out["tickers"])


class TestPageWiring(unittest.TestCase):
    def setUp(self):
        import app as app_module
        self.client = app_module.create_app().test_client()

    def test_page_still_renders_but_is_deliberately_not_in_the_nav(self):
        """Selection Test was retired from the menu, not deleted.

        It was a diagnostic asking whether the signal score predicts anything. It answered no,
        and so did the other diagnostics, by separate methods. Leaving it one click away invites
        re-running it until it finally reads well. The route is kept working so the finding can
        still be revisited on purpose — restoring it to the menu is one tuple in app.py.
        """
        self.assertEqual(self.client.get("/selection-test").status_code, 200)
        self.assertNotIn(b'href="/selection-test"', self.client.get("/").data)

    def test_script_exists(self):
        frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
        self.assertIn("js/selection_test.js",
                      (frontend / "templates" / "selection_test.html").read_text())
        self.assertTrue((frontend / "static" / "js" / "selection_test.js").exists())

    def test_run_without_credentials_reports_rather_than_pretends(self):
        from config import Config
        with patch.object(Config, "has_alpaca_credentials", staticmethod(lambda: False)):
            resp = self.client.post("/api/selection-test/run", json={})
        self.assertEqual(resp.status_code, 200)
        self.assertIn("error", resp.get_json())

    def test_unknown_run_is_404(self):
        self.assertEqual(self.client.get("/api/selection-test/runs/999999").status_code, 404)


if __name__ == "__main__":
    unittest.main()
