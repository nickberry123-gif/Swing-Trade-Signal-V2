"""
Unit tests for AlpacaProvider. Network calls are mocked with fixture JSON that matches
Alpaca's documented v2 response schemas — this verifies our parsing/classification logic
is correct WITHOUT requiring outbound network access (this sandbox's egress is locked
down at the org level, so these tests must not depend on reaching alpaca.markets).

Live end-to-end connectivity is verified separately by scripts/check_alpaca_connection.py,
which the user runs on their own machine where normal internet access is available.
"""
import sys
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from providers.base import DataStatus, ProviderError
from providers.alpaca_provider import AlpacaProvider, _parse_ts


def make_provider():
    return AlpacaProvider(
        api_key="TESTKEY", secret_key="TESTSECRET",
        trading_base_url="https://paper-api.alpaca.markets",
        data_base_url="https://data.alpaca.markets",
    )


def fake_response(json_body, status_code=200, text=""):
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_body
    resp.text = text or str(json_body)
    return resp


class TestParseTimestamp(unittest.TestCase):
    def test_nanosecond_precision(self):
        dt = _parse_ts("2024-01-02T14:30:00.123456789Z")
        self.assertEqual(dt.year, 2024)
        self.assertEqual(dt.microsecond, 123456)
        self.assertEqual(dt.tzinfo, timezone.utc)

    def test_no_fraction(self):
        dt = _parse_ts("2024-01-02T14:30:00Z")
        self.assertEqual(dt.second, 0)
        self.assertEqual(dt.microsecond, 0)

    def test_offset_timezone(self):
        dt = _parse_ts("2024-01-02T09:30:00-05:00")
        self.assertEqual(dt.utcoffset(), timedelta(hours=-5))

    def test_none_input(self):
        self.assertIsNone(_parse_ts(None))

    def test_garbage_raises(self):
        with self.assertRaises(ProviderError):
            _parse_ts("not-a-timestamp")


class TestMissingCredentials(unittest.TestCase):
    def test_raises_provider_error_unavailable(self):
        p = AlpacaProvider(api_key=None, secret_key=None,
                            trading_base_url="https://paper-api.alpaca.markets")
        with self.assertRaises(ProviderError) as ctx:
            p.get_market_clock()
        self.assertEqual(ctx.exception.status, DataStatus.UNAVAILABLE)


class TestMarketClock(unittest.TestCase):
    @patch("providers.alpaca_provider.requests.get")
    def test_open_market_is_regular_session(self, mock_get):
        mock_get.return_value = fake_response({
            "timestamp": "2024-06-10T14:00:00-04:00",
            "is_open": True,
            "next_open": "2024-06-11T09:30:00-04:00",
            "next_close": "2024-06-10T16:00:00-04:00",
        })
        status = make_provider().get_market_clock()
        self.assertTrue(status.is_open)
        self.assertEqual(status.session, "REGULAR")

    @patch("providers.alpaca_provider.requests.get")
    def test_closed_market_premarket_session(self, mock_get):
        # 7:00am ET on a weekday, market not open yet -> PRE_MARKET
        mock_get.return_value = fake_response({
            "timestamp": "2024-06-10T07:00:00-04:00",
            "is_open": False,
            "next_open": "2024-06-10T09:30:00-04:00",
            "next_close": "2024-06-10T16:00:00-04:00",
        })
        status = make_provider().get_market_clock()
        self.assertFalse(status.is_open)
        self.assertEqual(status.session, "PRE_MARKET")

    @patch("providers.alpaca_provider.requests.get")
    def test_closed_market_weekend_session(self, mock_get):
        # Saturday -> CLOSED, not pre-market/after-hours
        mock_get.return_value = fake_response({
            "timestamp": "2024-06-08T10:00:00-04:00",  # a Saturday
            "is_open": False,
            "next_open": "2024-06-10T09:30:00-04:00",
            "next_close": "2024-06-10T16:00:00-04:00",
        })
        status = make_provider().get_market_clock()
        self.assertEqual(status.session, "CLOSED")


class TestSnapshot(unittest.TestCase):
    def _snapshot_json(self, trade_ts_iso):
        return {
            "symbol": "AAPL",
            "latestTrade": {"t": trade_ts_iso, "x": "V", "p": 191.23, "s": 100, "c": ["@"], "i": 1, "z": "C"},
            "latestQuote": {"t": trade_ts_iso, "ax": "V", "ap": 191.30, "as": 2, "bx": "V", "bp": 191.20, "bs": 3, "c": ["R"]},
            "minuteBar": {"t": trade_ts_iso, "o": 191.0, "h": 191.5, "l": 190.9, "c": 191.23, "v": 12000},
            "dailyBar": {"t": trade_ts_iso, "o": 189.0, "h": 192.0, "l": 188.5, "c": 191.23, "v": 5000000},
            "prevDailyBar": {"t": trade_ts_iso, "o": 187.0, "h": 189.5, "l": 186.0, "c": 188.9, "v": 4800000},
        }

    @patch("providers.alpaca_provider.requests.get")
    def test_live_when_fresh_and_market_open(self, mock_get):
        fresh_ts = datetime.now(timezone.utc) - timedelta(seconds=30)
        clock_resp = fake_response({
            "timestamp": fresh_ts.isoformat().replace("+00:00", "Z"),
            "is_open": True,
            "next_open": fresh_ts.isoformat().replace("+00:00", "Z"),
            "next_close": fresh_ts.isoformat().replace("+00:00", "Z"),
        })
        snap_resp = fake_response(self._snapshot_json(fresh_ts.isoformat().replace("+00:00", "Z")))
        mock_get.side_effect = [clock_resp, snap_resp]

        snap = make_provider().get_snapshot("AAPL")
        self.assertEqual(snap.data_status, DataStatus.LIVE)
        self.assertEqual(snap.last_price, 191.23)
        self.assertEqual(snap.data_source, "alpaca")

    @patch("providers.alpaca_provider.requests.get")
    def test_market_closed_status_when_market_shut(self, mock_get):
        old_ts = datetime.now(timezone.utc) - timedelta(hours=16)
        clock_resp = fake_response({
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "is_open": False,
            "next_open": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "next_close": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        })
        snap_resp = fake_response(self._snapshot_json(old_ts.isoformat().replace("+00:00", "Z")))
        mock_get.side_effect = [clock_resp, snap_resp]

        snap = make_provider().get_snapshot("AAPL")
        self.assertEqual(snap.data_status, DataStatus.MARKET_CLOSED)

    @patch("providers.alpaca_provider.requests.get")
    def test_stale_when_old_trade_during_market_hours(self, mock_get):
        stale_ts = datetime.now(timezone.utc) - timedelta(minutes=45)
        now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        clock_resp = fake_response({
            "timestamp": now_iso, "is_open": True, "next_open": now_iso, "next_close": now_iso,
        })
        snap_resp = fake_response(self._snapshot_json(stale_ts.isoformat().replace("+00:00", "Z")))
        mock_get.side_effect = [clock_resp, snap_resp]

        snap = make_provider().get_snapshot("AAPL")
        self.assertEqual(snap.data_status, DataStatus.STALE)

    @patch("providers.alpaca_provider.requests.get")
    def test_unavailable_when_no_trade_data(self, mock_get):
        now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        clock_resp = fake_response({
            "timestamp": now_iso, "is_open": True, "next_open": now_iso, "next_close": now_iso,
        })
        snap_resp = fake_response({"symbol": "ZZZZ"})  # no latestTrade at all
        mock_get.side_effect = [clock_resp, snap_resp]

        snap = make_provider().get_snapshot("ZZZZ")
        self.assertEqual(snap.data_status, DataStatus.UNAVAILABLE)
        self.assertIsNone(snap.last_price)


class TestErrorHandling(unittest.TestCase):
    @patch("providers.alpaca_provider.requests.get")
    def test_401_raises_provider_error(self, mock_get):
        mock_get.return_value = fake_response({"message": "forbidden"}, status_code=401, text="forbidden")
        with self.assertRaises(ProviderError):
            make_provider().get_market_clock()

    @patch("providers.alpaca_provider.requests.get")
    def test_network_exception_raises_provider_error(self, mock_get):
        import requests as req_mod
        mock_get.side_effect = req_mod.exceptions.ConnectionError("boom")
        with self.assertRaises(ProviderError):
            make_provider().get_market_clock()

    @patch("providers.alpaca_provider.requests.get")
    def test_missing_ticker_in_multi_snapshot_is_unavailable_not_dropped(self, mock_get):
        now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        clock_resp = fake_response({"timestamp": now_iso, "is_open": True, "next_open": now_iso, "next_close": now_iso})
        snaps_resp = fake_response({"AAPL": {"latestTrade": {"t": now_iso, "p": 190.0}}})  # MSFT absent
        mock_get.side_effect = [clock_resp, snaps_resp]

        result = make_provider().get_snapshots(["AAPL", "MSFT"])
        self.assertIn("AAPL", result)
        self.assertIn("MSFT", result)
        self.assertEqual(result["MSFT"].data_status, DataStatus.UNAVAILABLE)
        self.assertEqual(result["AAPL"].data_status, DataStatus.LIVE)


if __name__ == "__main__":
    unittest.main()
