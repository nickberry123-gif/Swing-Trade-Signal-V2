"""
The market regime must not invent a reading out of missing data.

WHY THIS FILE EXISTS. The regime was the one place in this app that fabricated. Every component
returned a raw signed score with no record of how much of it was measurable, and the total was
bucketed against absolute thresholds — so a component that could not be read contributed 0, which
is "neutral", not "unknown".

That was not a cosmetic problem. `signal_engine.score_market_regime` maps NEUTRAL to 2.5 points
in every one of the 50 stocks' scores, and the UNAVAILABLE branch it carefully provides almost
never fired, because the regime almost never admitted it did not know.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import market_regime as mr  # noqa: E402


def _ind(price=100.0, sma50=95.0, sma200=90.0, slope=1.0, bars=400, roc=0.0):
    return {"reference_price": price, "sma50": sma50, "sma200": sma200,
            "sma200_slope": slope, "bars_used": bars, "roc": roc}


class MissingVolatility(unittest.TestCase):

    def test_unavailable_vixy_is_unknown_not_a_calm_market(self):
        """THE SHARPEST VERSION OF THE BUG. Unavailable VIXY returned 0.0, while a genuinely FLAT
        VIXY returns +0.5. So the ABSENCE of information scored half a point MORE BEARISH than a
        calm market — an invented reading, with a direction."""
        flat, _ = mr._volatility_component(_ind(roc=0.0), 400)
        missing_history, note1 = mr._volatility_component({"bars_used": 3}, 3)
        missing_roc, note2 = mr._volatility_component({"reference_price": 20.0, "roc": None}, 400)

        self.assertEqual(flat, 0.5)
        self.assertIsNone(missing_history)
        self.assertIsNone(missing_roc)
        self.assertIn("not scored", note1)
        self.assertIn("not scored", note2)

    def test_a_real_volatility_spike_still_scores_negative(self):
        """The fix must not blunt the component when data IS present."""
        calm, _ = mr._volatility_component(_ind(roc=-12.0), 400)
        spike, _ = mr._volatility_component(_ind(roc=25.0), 400)
        self.assertGreater(calm, 0)
        self.assertLess(spike, 0)


class MissingBreadth(unittest.TestCase):

    def test_no_readable_sector_is_unknown_not_balanced_breadth(self):
        """Zero breadth and unknown breadth were indistinguishable."""
        score, detail = mr._breadth_component({"XLK": {"reference_price": None, "sma50": None}})
        self.assertIsNone(score)
        self.assertEqual(detail["measured"], 0)

    def test_genuinely_balanced_breadth_scores_zero_and_says_it_measured(self):
        """Balanced IS zero — the point is that it must be distinguishable from unknown."""
        score, detail = mr._breadth_component({
            "UP": {"reference_price": 110.0, "sma50": 100.0},
            "DOWN": {"reference_price": 90.0, "sma50": 100.0},
        })
        self.assertEqual(score, 0.0)
        self.assertEqual(detail["measured"], 2)


class TrendCoverage(unittest.TestCase):

    def test_a_partial_trend_reports_how_many_checks_it_could_do(self):
        """Three days of history gives a price but no SMA50 or SMA200. The old code scored that
        as a flat market."""
        score, notes, checks = mr._trend_component(
            {"reference_price": 100.0, "sma50": None, "sma200": None, "sma200_slope": None})
        self.assertEqual(checks, 0)
        self.assertEqual(score, 0.0)
        self.assertTrue(any("0 of 3" in n for n in notes))

    def test_a_full_trend_reports_three_checks(self):
        _score, _notes, checks = mr._trend_component(_ind())
        self.assertEqual(checks, 3)


class CoverageGate(unittest.TestCase):
    """The end-to-end rule: below MIN_COVERAGE there is no honest label to give."""

    class _FakeDB:
        def rollback(self):
            pass

    def _run(self, monkey_indicators, bars_by_symbol=None):
        """Runs compute_market_regime with the bar loading and indicator maths stubbed, so the
        test exercises the COVERAGE LOGIC rather than pandas."""
        import pandas as pd
        calls = {}

        def fake_bars(db, ticker, timeframe="1Day", **kw):
            n = (bars_by_symbol or {}).get(ticker, 400)
            calls[ticker] = n
            df = pd.DataFrame({"ts": ["2026-01-01"] * n}) if n else pd.DataFrame()
            return df, {"source": "cache"}

        def fake_indicators(df):
            # Identify which symbol this is by the frame length the stub produced.
            return monkey_indicators.get(len(df), {"bars_used": len(df)})

        orig_bars, orig_ind = mr.get_bars_df, mr.compute_all_indicators
        mr.get_bars_df, mr.compute_all_indicators = fake_bars, fake_indicators
        try:
            return mr.compute_market_regime(self._FakeDB())
        finally:
            mr.get_bars_df, mr.compute_all_indicators = orig_bars, orig_ind

    def test_three_days_of_history_produces_unavailable_not_a_confident_neutral(self):
        """THE HEADLINE FAILURE. `have_core_data` only required ONE bar. With three days of SPY
        and QQQ every SMA is None, both trend components score 0, and the app published NEUTRAL —
        which signal_engine then turned into 2.5 points for all 50 stocks."""
        thin = {"reference_price": 100.0, "sma50": None, "sma200": None,
                "sma200_slope": None, "bars_used": 3, "roc": None}
        out = self._run({3: thin, 0: {"bars_used": 0}},
                        bars_by_symbol={s: 3 for s in
                                        ["SPY", "QQQ", "SMH", "SOXX", "XLK", "XLF", "XLV",
                                         "XLY", "XLP", "XLI", mr.VIX_PROXY_TICKER]})
        self.assertEqual(out["regime"], "UNAVAILABLE")
        self.assertIsNone(out["regime_score"])
        self.assertIn("Not enough market data", out["error"])
        self.assertLess(out["coverage_pct"], mr.MIN_COVERAGE * 100)

    def test_full_data_still_produces_a_label_and_reports_full_coverage(self):
        """The gate must not break the normal path."""
        out = self._run({400: _ind(roc=0.0)})
        self.assertNotEqual(out["regime"], "UNAVAILABLE")
        self.assertEqual(out["coverage_pct"], 100.0)
        self.assertEqual(out["components_missing"], [])

    def test_a_label_always_carries_its_coverage(self):
        """Nothing downstream should be able to read a regime without being able to see how much
        of the market it was built from. The dashboard printed 'NEUTRAL (score 0)' with no way to
        know it came from nothing."""
        out = self._run({400: _ind()})
        self.assertIn("coverage_pct", out)
        self.assertIn("components_missing", out)
        self.assertIn("coverage", out["detail"])
        self.assertIn("raw_score_before_scaling", out["detail"]["coverage"])

    def test_the_score_is_scaled_by_what_could_be_measured(self):
        """Same principle as the v2 scorer: score over the weight actually assessable, never over
        a denominator that includes unknowns. Otherwise losing a component silently drags every
        regime toward NEUTRAL."""
        self.assertEqual(mr.FULL_COVERAGE, sum(mr.COMPONENT_WEIGHTS.values()))
        self.assertEqual(mr.FULL_COVERAGE, 11)


class RegimeFeedsEveryStock(unittest.TestCase):
    """Why the above matters, asserted at the boundary where it did damage."""

    def test_an_unavailable_regime_is_excluded_from_a_stock_score_not_scored_zero(self):
        from services import signal_engine as se
        score, reasons = se.score_market_regime({"regime": "UNAVAILABLE"})
        self.assertIsNone(score, "an unknown regime contributed points to all 50 stocks")
        self.assertIn("EXCLUDED", " ".join(reasons))

    def test_the_reason_string_does_not_contradict_itself(self):
        """It used to say the component 'scored 0 and excluded from the total'. It returns None —
        excluded. Saying both is self-contradictory in the one place whose job is explaining a
        score honestly."""
        _score, reasons = __import__("services.signal_engine", fromlist=["x"]).score_market_regime(
            {"regime": None})
        joined = " ".join(reasons).lower()
        self.assertNotIn("scored 0 and excluded", joined)


if __name__ == "__main__":
    unittest.main()
