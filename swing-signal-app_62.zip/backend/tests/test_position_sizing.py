"""
The position-count control, the funded/unfunded split, and the ranking rule.

WHY THESE EXIST

Modelling Nick's measured population (1823 trades, +0.95% average, 66% win rate) through this
engine showed the position count is the most consequential setting in the app — and that it cuts
both ways. Running strategies with a GENUINELY ZERO edge and keeping the best of a hundred tries:

    50 positions -> best reads  +0.8%/yr   (correctly, as nothing)
     5 positions -> best reads +15.2%/yr   (looks like a winner; it is not)

Concentration multiplies luck faster than it multiplies edge. So the control must exist, must
default to the wide setting, and the count of signals the account could not fund must be visible
— because at five positions roughly nine signals in ten are turned away, and averaging returns
over signals that were never funded describes an account that never existed.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import backtest_service as bt


def trade(ticker, entry, exit_, ret, score=70):
    return {"ticker": ticker, "entry_date": entry, "exit_date": exit_,
            "return_pct": ret, "holding_days": 5, "score_at_entry": score,
            "exit_reason": "TARGET"}


class FundedVersusGenerated(unittest.TestCase):

    def test_signals_beyond_capacity_are_recorded_not_dropped(self):
        # Six simultaneous signals, three slots.
        trades = [trade(f"T{i}", "2024-01-02", "2024-01-10", 5.0) for i in range(6)]
        _eq, _dd, funded, unfunded = bt._portfolio_equity(trades, slots=3)
        self.assertEqual(len(funded), 3)
        self.assertEqual(len(unfunded), 3)
        self.assertEqual(len(funded) + len(unfunded), len(trades))

    def test_metrics_average_over_funded_trades_only(self):
        """The bug this fixes: +0.95% a trade against +7.85% total, on one page."""
        # Three funded winners at +10%, three unfunded losers at -50%.
        trades = ([trade(f"W{i}", "2024-01-02", "2024-01-10", 10.0, score=90) for i in range(3)]
                  + [trade(f"L{i}", "2024-01-02", "2024-01-10", -50.0, score=10) for i in range(3)])
        m = bt._metrics(trades, slots=3)
        self.assertEqual(m["signals_generated"], 6)
        self.assertEqual(m["signals_funded"], 3)
        self.assertEqual(m["signals_unfunded"], 3)
        self.assertEqual(m["unfunded_share_pct"], 50.0)
        # Funded average is +10, all-signals average is -20. Both reported, clearly named.
        self.assertEqual(m["avg_return_pct"], 10.0)
        self.assertEqual(m["avg_return_all_signals_pct"], -20.0)
        self.assertEqual(m["trades"], 3)

    def test_at_full_width_almost_nothing_is_turned_away(self):
        trades = [trade(f"T{i}", f"2024-0{1+i%9}-02", f"2024-0{1+i%9}-10", 1.0) for i in range(9)]
        m = bt._metrics(trades, slots=50)
        self.assertEqual(m["signals_unfunded"], 0)
        self.assertEqual(m["avg_return_pct"], m["avg_return_all_signals_pct"])

    def test_the_slot_count_is_reported(self):
        trades = [trade("A", "2024-01-02", "2024-01-10", 1.0)]
        self.assertEqual(bt._metrics(trades, slots=7)["capital_slots"], 7)


class RankingRule(unittest.TestCase):
    """When more signals fire than there are slots, the score decides. It used to be date order."""

    def test_the_highest_scoring_signal_is_funded_first(self):
        trades = [trade("LOW", "2024-01-02", "2024-01-10", -20.0, score=63),
                  trade("HIGH", "2024-01-02", "2024-01-10", 20.0, score=95)]
        _eq, _dd, funded, unfunded = bt._portfolio_equity(trades, slots=1)
        self.assertEqual([t["ticker"] for t in funded], ["HIGH"])
        self.assertEqual([t["ticker"] for t in unfunded], ["LOW"])

    def test_ranking_is_not_alphabetical_or_insertion_order(self):
        """Guards against the assertion above passing for the wrong reason."""
        trades = [trade("AAA", "2024-01-02", "2024-01-10", 1.0, score=64),
                  trade("ZZZ", "2024-01-02", "2024-01-10", 1.0, score=99)]
        _eq, _dd, funded, _u = bt._portfolio_equity(trades, slots=1)
        self.assertEqual(funded[0]["ticker"], "ZZZ")

    def test_a_missing_score_does_not_crash_the_ranking(self):
        a = trade("A", "2024-01-02", "2024-01-10", 1.0); a.pop("score_at_entry")
        b = trade("B", "2024-01-02", "2024-01-10", 1.0, score=80)
        _eq, _dd, funded, _u = bt._portfolio_equity([a, b], slots=1)
        self.assertEqual(funded[0]["ticker"], "B")

    def test_ranking_only_applies_within_the_same_day(self):
        """An earlier trade must not be displaced by a later, higher-scoring one."""
        early = trade("EARLY", "2024-01-02", "2024-01-10", 1.0, score=63)
        late = trade("LATE", "2024-02-02", "2024-02-10", 1.0, score=99)
        _eq, _dd, funded, _u = bt._portfolio_equity([late, early], slots=1)
        self.assertEqual([t["ticker"] for t in funded], ["EARLY", "LATE"])


class PositionCountChangesTheAnswer(unittest.TestCase):

    def setUp(self):
        # Twelve non-overlapping winners; every one is funded whatever the slot count, so the
        # only thing that changes is how much capital each one got.
        self.trades = [trade(f"T{i}", f"2024-01-{2+i:02d}", f"2024-01-{3+i:02d}", 10.0)
                       for i in range(12)]

    def test_fewer_slots_means_bigger_positions_and_bigger_returns(self):
        wide = bt._metrics(self.trades, slots=12)["total_return_pct"]
        narrow = bt._metrics(self.trades, slots=2)["total_return_pct"]
        self.assertGreater(narrow, wide)

    def test_fewer_slots_also_means_deeper_drawdowns(self):
        losers = [trade(f"T{i}", f"2024-01-{2+i:02d}", f"2024-01-{3+i:02d}", -10.0)
                  for i in range(12)]
        wide = bt._metrics(losers, slots=12)["max_drawdown_pct"]
        narrow = bt._metrics(losers, slots=2)["max_drawdown_pct"]
        self.assertLess(narrow, wide)

    def test_the_default_is_unchanged_from_before_the_control_existed(self):
        """One slot per tested ticker. Every earlier result must still reproduce exactly."""
        from tests.test_annual_backtest import bars, make_db
        bars_by = {"AAA": bars(700, seed=1), "BBB": bars(700, seed=2),
                   "SPY": bars(700, seed=4), "QQQ": bars(700, seed=5)}
        db = make_db()
        default = bt.run_backtest(db, ["AAA", "BBB"], bars_by, {"use_regime": True})
        explicit = bt.run_backtest(db, ["AAA", "BBB"], bars_by,
                                   {"use_regime": True, "max_positions": 0})
        self.assertEqual(default["overall"]["total_return_pct"],
                         explicit["overall"]["total_return_pct"])
        self.assertEqual(default["config"]["max_positions"], 2)   # two tested tickers


class TimeToTarget(unittest.TestCase):

    def test_only_target_hits_count(self):
        trades = [
            {**trade("A", "2024-01-02", "2024-01-10", 5.0), "exit_reason": "TARGET",
             "holding_days": 6},
            {**trade("B", "2024-01-02", "2024-02-10", -2.0), "exit_reason": "TIME_LIMIT",
             "holding_days": 40},
        ]
        ttt = bt._time_to_target(trades)
        self.assertEqual(ttt["n"], 1)
        self.assertEqual(ttt["median"], 6.0)
        self.assertEqual(ttt["closed_on_time_limit"], 1)

    def test_a_time_limit_exit_does_not_inflate_the_median(self):
        """Including them would measure the length of the test, not the speed of the strategy."""
        fast = [{**trade("A", "2024-01-02", "2024-01-05", 5.0), "holding_days": 3}]
        slow = fast + [{**trade("B", "2024-01-02", "2024-03-02", -1.0),
                        "exit_reason": "TIME_LIMIT", "holding_days": 60}]
        self.assertEqual(bt._time_to_target(fast)["median"],
                         bt._time_to_target(slow)["median"])

    def test_no_target_hits_is_zero_not_a_crash(self):
        ttt = bt._time_to_target([{**trade("A", "2024-01-02", "2024-02-10", -2.0),
                                   "exit_reason": "TIME_LIMIT"}])
        self.assertEqual(ttt["n"], 0)
        self.assertIsNone(ttt["median"])


class ExitOnSignalIsGone(unittest.TestCase):

    def setUp(self):
        import app as app_module
        self.client = app_module.create_app().test_client()
        self.frontend = Path(__file__).resolve().parent.parent.parent / "frontend"

    def test_neither_page_offers_the_control(self):
        for page in ("backtest.html", "annual_backtest.html"):
            with self.subTest(page=page):
                html = (self.frontend / "templates" / page).read_text()
                self.assertNotIn("Exit on Signal Loss", html)

    def test_neither_script_sends_it(self):
        for js in ("backtest.js", "annual_backtest.js"):
            with self.subTest(js=js):
                text = (self.frontend / "static" / "js" / js).read_text()
                self.assertNotIn("exit_on_signal", text)

    def test_both_routers_hard_wire_it_off(self):
        for router in ("api_backtest.py", "api_annual.py"):
            with self.subTest(router=router):
                src = (Path(__file__).resolve().parent.parent / "routers" / router).read_text()
                self.assertIn('"exit_on_signal": False', src)

    def test_both_pages_offer_the_position_control_instead(self):
        for page, prefix in (("backtest.html", "bt"), ("annual_backtest.html", "ab")):
            with self.subTest(page=page):
                html = (self.frontend / "templates" / page).read_text()
                self.assertIn(f'id="{prefix}-positions"', html)

    def test_both_scripts_send_the_position_count(self):
        for js, prefix in (("backtest.js", "bt"), ("annual_backtest.js", "ab")):
            with self.subTest(js=js):
                text = (self.frontend / "static" / "js" / js).read_text()
                self.assertIn("max_positions", text)
                self.assertIn(f'getElementById("{prefix}-positions")', text)

    def test_the_engine_still_honours_the_flag_when_asked_directly(self):
        """The control is gone from the UI; the capability is not deleted from the engine.

        Removing the mechanism as well would make the measurement that justified this decision
        impossible to reproduce later.
        """
        from tests.test_annual_backtest import bars, make_db
        bars_by = {"AAA": bars(700, seed=1), "SPY": bars(700, seed=4), "QQQ": bars(700, seed=5)}
        db = make_db()
        on = bt.run_backtest(db, ["AAA"], bars_by, {"use_regime": True, "exit_on_signal": True})
        off = bt.run_backtest(db, ["AAA"], bars_by, {"use_regime": True, "exit_on_signal": False})
        self.assertNotEqual(len(on["trades"]), len(off["trades"]))


if __name__ == "__main__":
    unittest.main()
