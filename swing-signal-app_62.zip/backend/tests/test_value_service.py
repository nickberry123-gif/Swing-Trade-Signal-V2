"""
Value pillar — unit tests.

Organised around the ways this specific calculation can produce a plausible wrong number, not
around its functions: point-in-time leakage, the post-filing split, share-basis mismatch,
percentile orientation, UNKNOWN handling and the band boundaries.
"""
from datetime import date, timedelta

import pytest

from services import value_service as vs


# ---------------------------------------------------------------------------- helpers ----
def _bars(start="2020-07-27", days=1600, price=100.0, split_on=None, split_factor=None,
          drift=0.0):
    """Ascending daily closes on both bases.

    `close_adj` is the continuous series; `close_raw` carries the split, exactly as the real data
    does — before a split the raw price is `factor` times the adjusted one.
    """
    out, d = [], date.fromisoformat(start)
    for i in range(days):
        adj = price + drift * i
        factor = 1.0
        if split_on and d.isoformat() < split_on:
            factor = split_factor or 1.0
        out.append({"ts": d.isoformat(), "close_raw": round(adj * factor, 4),
                    "close_adj": round(adj, 4)})
        d += timedelta(days=1)
    return out


def _filing(filed="2021-02-01", period_end="2020-12-31", **kw):
    base = {"filed": filed, "period_end": period_end, "currency": "USD",
            "eps_diluted": 5.0, "shares_outstanding": 1_000_000.0,
            "operating_cash_flow": 12_000_000.0, "capex": 2_000_000.0,
            "operating_income": 9_000_000.0, "revenue": 50_000_000.0,
            "total_debt": 0.0, "total_cash": 0.0}
    base.update(kw)
    return base


# ---------------------------------------------------------------- point-in-time / look-ahead ----
class TestPointInTime:
    def test_filing_published_after_the_day_is_unreachable(self):
        filings = [_filing(filed="2021-02-01"), _filing(filed="2022-02-01", period_end="2021-12-31")]
        assert vs.pick_filing(filings, "2021-06-30")["filed"] == "2021-02-01"

    def test_selection_keys_on_publication_not_period_end(self):
        """A 2023 period filed in 2024 must not be reachable from a 2023 date."""
        filings = [_filing(filed="2023-02-01", period_end="2022-12-31"),
                   _filing(filed="2024-02-01", period_end="2023-12-31")]
        assert vs.pick_filing(filings, "2023-12-31")["period_end"] == "2022-12-31"

    def test_no_filing_yet_returns_none_not_the_earliest(self):
        assert vs.pick_filing([_filing(filed="2021-02-01")], "2020-12-31") is None

    def test_same_day_publication_prefers_later_period(self):
        filings = [_filing(filed="2024-02-01", period_end="2022-12-31"),
                   _filing(filed="2024-02-01", period_end="2023-12-31")]
        assert vs.pick_filing(filings, "2024-06-01")["period_end"] == "2023-12-31"

    def test_percentile_uses_only_earlier_observations(self):
        """The design's own trap: a distribution containing the future."""
        past = [10.0, 20.0, 30.0]
        assert vs.percentile_rank(past, 5.0, higher_is_cheaper=False) == 100.0

    def test_evaluate_ignores_bars_after_as_of(self):
        bars = _bars(days=1600)
        full = vs.evaluate("T", bars, [_filing()])
        early = vs.evaluate("T", bars, [_filing()], as_of="2024-01-01")
        assert full["history"]["last_date"] > early["history"]["last_date"] == "2024-01-01"

    def test_appending_later_data_cannot_change_an_earlier_score(self):
        filings = [_filing()]
        short = vs.evaluate("T", _bars(days=1300, drift=0.05), filings, as_of="2024-01-01")
        longer = vs.evaluate("T", _bars(days=1900, drift=0.05), filings, as_of="2024-01-01")
        assert short["value"] == longer["value"]

    def test_moving_as_of_earlier_only_removes_observations(self):
        bars, filings = _bars(days=1600), [_filing()]
        a = vs.evaluate("T", bars, filings, as_of="2024-06-01")["history"]["observations"]
        b = vs.evaluate("T", bars, filings, as_of="2023-06-01")["history"]["observations"]
        assert b < a

    def test_filing_published_after_as_of_is_excluded_by_evaluate(self):
        bars = _bars(days=1600)
        out = vs.evaluate("T", bars, [_filing(filed="2025-01-01")], as_of="2024-06-01")
        assert out["verdict"] == vs.UNKNOWN
        assert "No point-in-time filing available." in out["notes"]

    def test_split_detector_sees_no_price_after_the_cutoff(self):
        bars = _bars(days=1600, split_on="2025-01-15", split_factor=10.0)
        out = vs.evaluate("T", bars, [_filing()], as_of="2024-06-01")
        assert out["split_withheld"] is None


# ------------------------------------------------------------------- the post-filing split ----
class TestPostFilingSplit:
    def test_ten_for_one_after_the_filing_is_detected(self):
        bars = _bars(days=1600, split_on="2024-06-10", split_factor=10.0)
        s = vs.split_after(bars, "2024-02-01")
        assert s and s["date"] == "2024-06-10" and s["factor"] == pytest.approx(10.0, rel=1e-3)

    def test_fifty_for_one_is_detected(self):
        bars = _bars(days=1600, split_on="2024-06-26", split_factor=50.0)
        assert vs.split_after(bars, "2024-02-01")["factor"] == pytest.approx(50.0, rel=1e-3)

    def test_a_dividend_sized_step_is_not_a_split(self):
        """0.24% was measured on MSFT's real ex-date. It must never read as a corporate action."""
        bars = _bars(days=400)
        for b in bars[200:]:
            b["close_raw"] = round(b["close_adj"] * 1.0024, 6)
        assert vs.split_steps(bars) == []

    def test_a_forty_percent_crash_is_not_a_split(self):
        bars = _bars(days=400)
        for b in bars[200:]:
            b["close_raw"], b["close_adj"] = b["close_raw"] * 0.6, b["close_adj"] * 0.6
        assert vs.split_steps(bars) == []

    def test_split_before_the_filing_is_not_withheld(self):
        """The filing already restated the basis — withholding then would be superstition."""
        bars = _bars(days=1600, split_on="2023-06-10", split_factor=10.0)
        assert vs.split_after(bars, "2024-02-01") is None

    def test_every_metric_is_withheld_not_just_the_per_share_one(self):
        """A split invalidates the share count as well as EPS, so all three go."""
        bars = _bars(days=1600, split_on="2024-06-10", split_factor=10.0)
        out = vs.evaluate("NVDA", bars, [_filing(filed="2024-02-01")], as_of="2024-08-01")
        assert out["verdict"] == vs.UNKNOWN and out["value"] is None
        assert all(out["metrics"][m]["status"] == vs.UNAVAILABLE for m in vs.METRICS)

    def test_the_withheld_result_is_never_mathematically_adjusted(self):
        bars = _bars(days=1600, split_on="2024-06-10", split_factor=10.0)
        out = vs.evaluate("NVDA", bars, [_filing(filed="2024-02-01")], as_of="2024-08-01")
        assert out["split_withheld"]["factor"] == pytest.approx(10.0, rel=1e-3)
        assert all(out["metrics"][m]["value"] is None for m in vs.METRICS)

    def test_the_false_cheap_signal_this_rule_exists_to_prevent(self):
        """Without the rule, a raw price 10x lower against un-restated EPS reads as CHEAP."""
        filing = _filing(filed="2024-02-01")
        pre = vs.metrics_for(1000.0, filing)["pe_ratio"]
        post = vs.metrics_for(100.0, filing)["pe_ratio"]
        assert pre == 200.0 and post == 20.0          # the artefact is real and large
        bars = _bars(days=1600, split_on="2024-06-10", split_factor=10.0)
        assert vs.evaluate("NVDA", bars, [filing], as_of="2024-08-01")["verdict"] == vs.UNKNOWN


# ------------------------------------------------------------------------ the multiples ----
class TestMetrics:
    def test_pe_uses_the_per_share_route_and_needs_no_share_count(self):
        m = vs.metrics_for(100.0, _filing(shares_outstanding=None))
        assert m["pe_ratio"] == 20.0
        assert m["fcf_yield_pct"] is None and m["ev_to_ebit"] is None

    def test_fcf_yield_is_ocf_minus_capex_over_market_cap(self):
        # (12m - 2m) / (100 * 1m) = 10%
        assert vs.metrics_for(100.0, _filing())["fcf_yield_pct"] == pytest.approx(10.0)

    def test_enterprise_value_adds_debt_and_subtracts_cash(self):
        # (100m + 20m - 5m) / 9m
        m = vs.metrics_for(100.0, _filing(total_debt=20_000_000.0, total_cash=5_000_000.0))
        assert m["ev_to_ebit"] == pytest.approx(115_000_000.0 / 9_000_000.0)

    def test_negative_eps_gives_no_pe_rather_than_a_negative_one(self):
        assert vs.metrics_for(100.0, _filing(eps_diluted=-3.0))["pe_ratio"] is None

    def test_negative_operating_profit_gives_no_ev_to_ebit(self):
        assert vs.metrics_for(100.0, _filing(operating_income=-1.0))["ev_to_ebit"] is None

    def test_non_usd_fundamentals_yield_no_multiple_at_all(self):
        assert all(v is None for v in vs.metrics_for(100.0, _filing(currency="EUR")).values())

    def test_zero_shares_does_not_divide_by_zero(self):
        m = vs.metrics_for(100.0, _filing(shares_outstanding=0.0))
        assert m["fcf_yield_pct"] is None and m["pe_ratio"] == 20.0

    def test_unknown_is_never_silently_zero(self):
        m = vs.metrics_for(100.0, _filing(operating_cash_flow=None))
        assert m["fcf_yield_pct"] is None and m["fcf_yield_pct"] != 0

    def test_ev_to_sales_is_computed_as_the_substitute(self):
        assert vs.metrics_for(100.0, _filing())[vs.EV_SALES] == pytest.approx(2.0)


# ------------------------------------------------------------------------ percentiles ----
class TestPercentiles:
    def test_cheapest_ever_reads_one_hundred_for_a_lower_is_cheaper_metric(self):
        assert vs.percentile_rank([10, 20, 30, 40], 5, higher_is_cheaper=False) == 100.0

    def test_most_expensive_ever_reads_zero(self):
        assert vs.percentile_rank([10, 20, 30, 40], 99, higher_is_cheaper=False) == 0.0

    def test_orientation_flips_for_fcf_yield(self):
        """A HIGH free-cash-flow yield is CHEAP. Getting this backwards is undetectable by eye."""
        assert vs.percentile_rank([1, 2, 3, 4], 9, higher_is_cheaper=True) == 100.0
        assert vs.percentile_rank([1, 2, 3, 4], 0.5, higher_is_cheaper=True) == 0.0

    def test_midpoint_reads_about_fifty(self):
        assert vs.percentile_rank(list(range(101)), 50, higher_is_cheaper=False) == pytest.approx(
            50.0, abs=1.0)

    def test_ties_take_mid_rank(self):
        assert vs.percentile_rank([5, 5, 5, 5], 5, higher_is_cheaper=False) == 50.0

    def test_empty_history_is_none_not_fifty(self):
        assert vs.percentile_rank([], 10, higher_is_cheaper=False) is None

    def test_missing_current_value_is_none(self):
        assert vs.percentile_rank([1, 2, 3], None, higher_is_cheaper=False) is None


# ----------------------------------------------------------------------- bands / verdict ----
class TestBands:
    @pytest.mark.parametrize("value,expected", [
        (100.0, "CHEAP"), (75.0, "CHEAP"), (74.9, "FAIR"), (50.0, "FAIR"),
        (25.0, "FAIR"), (24.9, "EXPENSIVE"), (0.0, "EXPENSIVE"),
    ])
    def test_boundaries_are_inclusive_at_the_lower_edge(self, value, expected):
        assert vs.verdict_for(value) == expected

    def test_none_is_unknown_not_expensive(self):
        assert vs.verdict_for(None) == vs.UNKNOWN

    def test_bands_are_frozen_at_the_approved_values(self):
        assert vs.BANDS == ((75.0, "CHEAP"), (25.0, "FAIR"), (0.0, "EXPENSIVE"))


# --------------------------------------------------------------------------- UNKNOWN ----
class TestUnknown:
    def test_fewer_than_two_metrics_is_unknown(self):
        """CVNA in production: share basis UNKNOWN, so only P/E survives."""
        out = vs.evaluate("CVNA", _bars(days=1600), [_filing(shares_outstanding=None)])
        assert out["verdict"] == vs.UNKNOWN and out["coverage"]["available"] == 1

    def test_two_metrics_is_enough(self):
        out = vs.evaluate("T", _bars(days=1600, drift=0.02),
                          [_filing(operating_income=None, revenue=None)])
        assert out["coverage"]["available"] == 2 and out["verdict"] != vs.UNKNOWN

    def test_short_history_is_unknown_not_a_percentile_over_two_years(self):
        out = vs.evaluate("T", _bars(days=600), [_filing()])
        assert out["verdict"] == vs.UNKNOWN
        assert "not a range" in " ".join(out["notes"])

    def test_non_usd_is_unknown_with_the_currency_named(self):
        out = vs.evaluate("ASML", _bars(days=1600), [_filing(currency="EUR")])
        assert out["verdict"] == vs.UNKNOWN
        assert "EUR" in " ".join(out["notes"])

    def test_no_bars_is_unknown_rather_than_an_exception(self):
        assert vs.evaluate("T", [], [_filing()])["verdict"] == vs.UNKNOWN

    def test_no_filings_is_unknown(self):
        assert vs.evaluate("T", _bars(days=1600), [])["verdict"] == vs.UNKNOWN

    def test_an_unavailable_metric_leaves_the_denominator(self):
        """It must not score zero, which would read as maximally expensive."""
        out = vs.evaluate("T", _bars(days=1600, drift=0.02),
                          [_filing(operating_income=None, revenue=None)])
        assert out["coverage"]["available"] == 2
        assert out["value"] == pytest.approx(
            sum(out["metrics"][m]["percentile"] for m in ("fcf_yield_pct", "pe_ratio")) / 2)

    def test_every_unavailable_metric_states_a_reason(self):
        out = vs.evaluate("CVNA", _bars(days=1600), [_filing(shares_outstanding=None)])
        for name, m in out["metrics"].items():
            if m["status"] == vs.UNAVAILABLE:
                assert m["reason"] and len(m["reason"]) > 10, name


# ------------------------------------------------------------------------ substitution ----
class TestSubstitution:
    def test_ev_to_sales_substitutes_when_ebit_is_unusable(self):
        out = vs.evaluate("T", _bars(days=1600, drift=0.02),
                          [_filing(operating_income=None, gross_profit=None,
                                   costs_and_expenses=None, operating_expenses=None)])
        assert out["substitution"]["with"] == vs.EV_SALES
        assert out["metrics"][vs.EV_SALES]["status"] == vs.OK

    def test_the_substitution_is_explicitly_visible(self):
        out = vs.evaluate("T", _bars(days=1600, drift=0.02),
                          [_filing(operating_income=None, gross_profit=None,
                                   costs_and_expenses=None, operating_expenses=None)])
        assert "EV/SALES SUBSTITUTED" in " ".join(out["notes"])
        assert out["metrics"][vs.EV_SALES]["substituted"] is True

    def test_no_substitution_when_ebit_works(self):
        out = vs.evaluate("T", _bars(days=1600, drift=0.02), [_filing()])
        assert out["substitution"] is None and vs.EV_SALES not in out["metrics"]


# ------------------------------------------------------------------ economic plausibility ----
class TestPlausibility:
    def test_a_rising_price_on_flat_fundamentals_becomes_expensive(self):
        bars = _bars(days=1600, price=50.0, drift=0.15)     # 50 -> ~290
        out = vs.evaluate("T", bars, [_filing()])
        assert out["verdict"] == "EXPENSIVE" and out["value"] < 25

    def test_a_falling_price_on_flat_fundamentals_becomes_cheap(self):
        bars = _bars(days=1600, price=300.0, drift=-0.15)
        out = vs.evaluate("T", bars, [_filing()])
        assert out["verdict"] == "CHEAP" and out["value"] >= 75

    def test_value_is_the_mean_of_the_available_percentiles(self):
        out = vs.evaluate("T", _bars(days=1600, drift=0.02), [_filing()])
        pcts = [m["percentile"] for m in out["metrics"].values() if m["status"] == vs.OK]
        assert out["value"] == pytest.approx(sum(pcts) / len(pcts), abs=0.05)

    def test_value_is_bounded_zero_to_one_hundred(self):
        for drift in (-0.2, -0.05, 0.0, 0.05, 0.2):
            out = vs.evaluate("T", _bars(days=1600, drift=drift), [_filing()])
            if out["value"] is not None:
                assert 0.0 <= out["value"] <= 100.0

    def test_quality_never_enters_the_calculation(self):
        """Value must not borrow from Company Health. A profitability change alone cannot move it
        except through the multiples themselves."""
        src = open(vs.__file__).read()
        assert "company_health" not in src and "quality_score" not in src


# ----------------------------------------------------------------------- the data floor ----
class TestDataFloor:
    def test_the_recorded_floor_is_the_measured_one(self):
        assert vs.DATA_FLOOR_OBSERVED == "2020-07-27"

    def test_observed_floor_reports_what_is_actually_stored(self):
        assert vs.observed_floor(_bars(start="2021-01-04", days=10)) == "2021-01-04"

    def test_a_floor_later_than_expected_is_reported_as_a_note(self):
        out = vs.evaluate("T", _bars(start="2021-06-01", days=1500, drift=0.02), [_filing()])
        assert any("later than the observed data floor" in n for n in out["notes"])

    def test_a_date_before_the_floor_returns_unknown_not_a_partial_answer(self):
        out = vs.evaluate("T", _bars(days=1600), [_filing()], as_of="2019-01-01")
        assert out["verdict"] == vs.UNKNOWN

    def test_the_basis_wording_never_overclaims(self):
        out = vs.evaluate("T", _bars(days=1600, drift=0.02), [_filing()])
        assert out["basis"] == "Relative to available valuation history since July 2020."
        text = " ".join(out["notes"]) + out["basis"]
        for forbidden in ("cheapest ever", "most expensive ever", "full-cycle", "all time"):
            assert forbidden not in text.lower()
