"""
Build A — the trend split, the UNCONFIRMED state, and proof that neither changed any verdict.

THE ISOLATION REQUIREMENT IS THE POINT OF THIS FILE. Build A was explicitly scoped to display
and honesty changes: no BUY verdict may move. That cannot be asserted by reading the diff — it
has to be measured, so the last class runs the full v1 and v2 scoring paths and compares against
values captured before the change.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import signal_engine as se  # noqa: E402
from services import signal_v2_service as v2  # noqa: E402
from services.indicators import (TREND_UNCONFIRMED, classify_trend,  # noqa: E402
                                 classify_trend_detail)


class TheSplit(unittest.TestCase):
    """Two clocks, not four equivalent checks."""

    def test_all_four_passing_is_strong_uptrend_with_both_pairs_intact(self):
        d = classify_trend_detail(price=100, sma50=95, sma200=90, sma200_slope=1.0)
        self.assertEqual(d["label"], "Strong Uptrend")
        self.assertEqual(d["long_term"]["status"], "INTACT")
        self.assertEqual(d["short_term"]["status"], "INTACT")

    def test_a_dip_below_the_50_day_leaves_the_long_term_intact(self):
        """THE DISTINCTION THE SPLIT EXISTS FOR. Price crosses its 50-day average several times a
        year in a perfectly healthy stock. The label drops a step; nothing real has happened."""
        d = classify_trend_detail(price=100, sma50=105, sma200=90, sma200_slope=1.0)
        self.assertEqual(d["long_term"]["status"], "INTACT")
        self.assertEqual(d["short_term"]["status"], "WEAKENING")
        self.assertIn("short-term pullback", d["interpretation"])

    def test_the_200_day_rolling_over_is_reported_as_the_serious_event(self):
        """Same one-step label move as above, completely different meaning underneath."""
        d = classify_trend_detail(price=100, sma50=95, sma200=90, sma200_slope=-0.5)
        self.assertEqual(d["long_term"]["status"], "WEAKENING")
        self.assertEqual(d["short_term"]["status"], "INTACT")
        self.assertIn("weakening", d["interpretation"].lower())

    def test_a_broken_long_term_trend_says_so_plainly(self):
        d = classify_trend_detail(price=80, sma50=95, sma200=90, sma200_slope=-0.5)
        self.assertEqual(d["long_term"]["status"], "BROKEN")
        self.assertIn("act on", d["interpretation"])

    def test_the_two_groups_contain_the_right_checks(self):
        d = classify_trend_detail(price=100, sma50=95, sma200=90, sma200_slope=1.0)
        self.assertEqual(set(d["long_term"]["checks"]), {"price_above_sma200", "sma200_rising"})
        self.assertEqual(set(d["short_term"]["checks"]),
                         {"sma50_above_sma200", "price_above_sma50"})


class Unconfirmed(unittest.TestCase):
    """Incomplete evidence must not be scaled up to full confidence."""

    def test_one_available_check_can_no_longer_produce_strong_uptrend(self):
        """THE BUG THIS FIXES. The label was a fraction of the checks that could be MEASURED, not
        out of four. With only `price > sma50` available, one passing check gave 1/1 = 1.0 =
        STRONG UPTREND — a full-confidence verdict from a single comparison."""
        d = classify_trend_detail(price=100, sma50=95, sma200=None, sma200_slope=None)
        self.assertEqual(d["label"], TREND_UNCONFIRMED)
        self.assertFalse(d["confirmed"])
        self.assertNotEqual(d["label"], "Strong Uptrend")

    def test_a_missing_slope_alone_is_enough_to_withhold_the_label(self):
        """Both long-term checks are required. Price above the 200-day tells you little without
        knowing whether that average is rising or falling."""
        d = classify_trend_detail(price=100, sma50=95, sma200=90, sma200_slope=None)
        self.assertFalse(d["confirmed"])
        self.assertEqual(d["long_term"]["status"], "UNCONFIRMED")

    def test_the_same_evidence_gives_the_same_answer_whatever_the_history_length(self):
        """The old ratio moved with the DENOMINATOR: two of three available checks read 0.67 =
        Uptrend, while the identical two of four read 0.50 = Neutral. Identical evidence,
        different label, purely because of how many bars existed."""
        full = classify_trend_detail(price=100, sma50=105, sma200=90, sma200_slope=1.0)
        partial = classify_trend_detail(price=100, sma50=105, sma200=90, sma200_slope=None)
        self.assertEqual(full["label"], "Uptrend")
        self.assertEqual(partial["label"], TREND_UNCONFIRMED)   # not a louder label on less data

    def test_no_data_at_all_is_unconfirmed_not_strong_downtrend(self):
        label, reasons = classify_trend(None, None, None, None)
        self.assertEqual(label, TREND_UNCONFIRMED)
        self.assertTrue(reasons)

    def test_an_unmeasurable_check_shows_as_none_never_as_a_failure(self):
        """"We could not look" and "we looked and it failed" must not render the same."""
        d = classify_trend_detail(price=100, sma50=None, sma200=90, sma200_slope=1.0)
        self.assertIsNone(d["short_term"]["checks"]["price_above_sma50"])
        self.assertIsNot(d["short_term"]["checks"]["price_above_sma50"], False)


class UnconfirmedIsExcludedNotZeroed(unittest.TestCase):
    """The one scoring line Build A touches, and why it had to be touched."""

    def test_an_unconfirmed_trend_removes_the_pullback_component_rather_than_scoring_it_zero(self):
        """Without this, introducing the UNCONFIRMED label would have CREATED a new hard zero:
        the old code fell through to its else branch and scored 0 out of 10 while still counting
        those 10 toward the achievable maximum. A stock would be docked ten points for the app
        not having enough bars — which is not a fact about the stock."""
        score, reasons = se.score_rsi_pullback({"rsi14": 45.0, "trend_label": TREND_UNCONFIRMED})
        self.assertIsNone(score)
        self.assertIn("leaves the total", " ".join(reasons))

    def test_a_confirmed_trend_scores_exactly_as_before(self):
        self.assertEqual(se.score_rsi_pullback({"rsi14": 45.0, "trend_label": "Uptrend"})[0], 10)
        self.assertEqual(se.score_rsi_pullback({"rsi14": 22.0,
                                                "trend_label": "Strong Downtrend"})[0], 0)


def _indicators(price=150.0, **over):
    """A full-history stock — every trend check available, which is every stock in the universe."""
    base = {
        "reference_price": price,
        "sma50": price * 0.95, "sma200": price * 0.85, "sma200_slope": 1.2,
        "ema20": price * 0.98, "ema50": price * 0.95,
        "macd": 1.5, "macd_signal": 1.0, "macd_hist": 0.5,
        "rsi14": 60.0, "adx": 30.0, "roc": 5.0, "atr14": price * 0.02, "atr_pct": 2.0,
        "relative_volume": 1.8, "volume_trend": "Increasing",
        "support_low": price * 0.97, "support_high": price * 0.995,
        "resistance_low": price * 1.10, "resistance_high": price * 1.15,
        "swing_high": price * 1.12, "high_52w": price * 1.20, "low_52w": price * 0.7,
        "high_20d": price * 1.01, "trend_label": "Strong Uptrend",
        "bars_used": 300, "data_status": "OK",
    }
    base.update(over)
    return base


RS = {"labels": {5: "Strong", 20: "Strong", 50: "Strong", 200: "Strong"},
      "rs_spy_5d": 3.0, "rs_spy_20d": 6.0, "rs_spy_50d": 9.0, "rs_spy_200d": 15.0}


class BuildAChangedNoVerdicts(unittest.TestCase):
    """THE ISOLATION GUARANTEE.

    Build A was scoped to display and honesty only. These are the values the v1 and v2 engines
    produced BEFORE the change, captured by running them on the previous build. If any of these
    move, Build A has leaked into the scoring and the scope was broken.

    Every stock in the universe has years of history, so the UNCONFIRMED path is unreachable for
    all fifty in practice — which is exactly why it is safe, and exactly why it must be proved
    rather than asserted.

    The numbers below were MEASURED from the running engine, not recalled. My first draft of this
    file guessed them (3 instead of 6, 92.5 instead of 94.0) and the tests failed — which is the
    correct outcome, and a reminder that a remembered baseline is not a baseline.
    """

    def test_the_guard_clause_cannot_affect_any_confirmed_label(self):
        """THE PROOF, and it is the important test in this class.

        The only scoring line Build A touched added `or trend_label == TREND_UNCONFIRMED` to an
        existing guard. For any of the five confirmed labels that term is False, so the branch
        taken is identical to before — not "probably unchanged", but the same branch by
        construction. Every number below follows from that.
        """
        for label in ("Strong Uptrend", "Uptrend", "Neutral", "Downtrend", "Strong Downtrend"):
            old_would_skip = False                      # rsi present, label present
            new_would_skip = old_would_skip or label == TREND_UNCONFIRMED
            self.assertEqual(old_would_skip, new_would_skip, label)

    def test_v1_total_and_label_are_unchanged_for_a_full_history_stock(self):
        analysis = {**_indicators(), "relative_strength": RS, "ticker": "TEST"}
        out = se.compute_signal(analysis, {"regime": "BULL"})
        self.assertEqual(out["score_total"], 84.0)
        self.assertEqual(out["signal_label"], "STRONG BUY")
        self.assertEqual(out["score_max_currently_available"], 90)

    def test_every_v1_component_is_unchanged(self):
        analysis = {**_indicators(), "relative_strength": RS, "ticker": "TEST"}
        out = se.compute_signal(analysis, {"regime": "BULL"})
        self.assertEqual(
            {k: out[k] for k in ("score_long_trend", "score_short_trend", "score_momentum",
                                 "score_rsi_pullback", "score_volume",
                                 "score_support_resistance", "score_relative_strength",
                                 "score_market_regime")},
            {"score_long_trend": 20.0, "score_short_trend": 10.0, "score_momentum": 15.0,
             "score_rsi_pullback": 6, "score_volume": 10.0, "score_support_resistance": 9.0,
             "score_relative_strength": 10.0, "score_market_regime": 4.0})

    def test_v2_hold_entry_and_action_are_unchanged(self):
        analysis = {**_indicators(), "relative_strength": RS, "ticker": "TEST"}
        out = v2.evaluate(analysis, {"regime": "BULL"}, {"long_term_quality_score": 85})
        self.assertEqual(out["hold_quality"], 94.0)
        self.assertEqual(out["entry_quality"], 85.5)
        self.assertEqual(out["action"], "BUY")

    def test_the_trend_label_itself_is_unchanged_for_a_full_history_stock(self):
        """The label feeds v1's pullback scorer and strategy-setup classifier. For any stock with
        all four checks available it must read exactly as it did before."""
        for price, sma50, sma200, slope, expected in [
            (100, 95, 90, 1.0, "Strong Uptrend"),
            (100, 105, 90, 1.0, "Uptrend"),
            (100, 105, 90, -1.0, "Neutral"),
            (80, 95, 90, -1.0, "Downtrend"),
            (80, 95, 90, 1.0, "Neutral"),
        ]:
            self.assertEqual(classify_trend(price, sma50, sma200, slope)[0], expected,
                             f"label moved for {price}/{sma50}/{sma200}/{slope}")

    def test_strategy_setup_classification_is_unchanged(self):
        ind = _indicators(reference_price=100.0, support_low=97.0, support_high=99.5, rsi14=50.0,
                          sma50=95.0, sma200=85.0, trend_label="Uptrend")
        self.assertEqual(se.classify_strategy_setup(ind), "PULLBACK")


if __name__ == "__main__":
    unittest.main()
