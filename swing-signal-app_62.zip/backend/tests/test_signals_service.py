"""
Unit tests for services/signals_service.py — the Phase 3 orchestration layer that ties
market_regime + stock_analysis + signal_engine together for one ticker or the full 15-stock
universe, and persists into the `signals` table.

get_bars_df is mocked at both places it's imported into (services.market_regime and
services.stock_analysis both do `from services.bars_service import get_bars_df`), matching the
pattern used in test_market_regime.py / test_stock_analysis.py. Persistence is checked against
a real in-memory SQLite DB built from schema.sql.
"""
import sqlite3
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import database
from unittest.mock import patch

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import SECTOR_ETF_MAP, STOCK_UNIVERSE
from services import signals_service

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    """`signals.ticker` has a FOREIGN KEY REFERENCES stocks(ticker), so — unlike the other
    Phase 2 tables, which deliberately have no FK — this test DB must seed `stocks` the same
    way db.py's real init_db() does, or every signals insert fails FK enforcement."""
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]),
        )
    conn.commit()
    return conn


def trending_bars(n=250, start=100.0, daily_drift=0.15, noise=0.3, seed=0):
    rng = np.random.default_rng(seed)
    closes = start + np.cumsum(daily_drift + rng.normal(0, noise, n))
    closes = np.maximum(closes, 1.0)
    ts = [(datetime(2024, 1, 1) + timedelta(days=i)).isoformat() for i in range(n)]
    return pd.DataFrame({
        "ts": ts, "open": closes, "high": closes + 0.5, "low": closes - 0.5,
        "close": closes, "volume": [1_000_000.0] * n,
    })


def empty_bars():
    return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])


def all_bullish_side_effect(db, ticker, timeframe, force_refresh=False):
    # Falling VIXY = calming volatility = a bullish regime contribution, matches
    # test_market_regime.py's convention for a clean bullish scenario.
    if ticker == "VIXY":
        return trending_bars(daily_drift=-0.1, seed=1), {"source": "alpaca", "fresh": True, "stale_fallback": False, "error": None}
    return trending_bars(daily_drift=0.2, seed=hash(ticker) % 1000), {"source": "alpaca", "fresh": True, "stale_fallback": False, "error": None}


class TestComputeSignalForTicker(unittest.TestCase):
    @patch("services.stock_analysis.get_bars_df")
    @patch("services.market_regime.get_bars_df")
    def test_returns_full_signal_and_persists(self, mock_regime_bars, mock_stock_bars):
        mock_regime_bars.side_effect = all_bullish_side_effect
        mock_stock_bars.side_effect = all_bullish_side_effect
        db = make_db()

        signal = signals_service.compute_signal_for_ticker(db, "NVDA", persist=True, include_fundamentals=False)

        self.assertEqual(signal["ticker"], "NVDA")
        self.assertEqual(signal["data_status"], "OK")
        self.assertIsNotNone(signal["score_total"])
        self.assertIn(signal["signal_label"], ("STRONG BUY", "BUY", "WATCH", "NO TRADE", "AVOID"))

        row = db.execute("SELECT * FROM signals WHERE ticker='NVDA'").fetchone()
        self.assertIsNotNone(row)
        self.assertEqual(row["signal_label"], signal["signal_label"])
        self.assertEqual(row["strategy_version"], "v1.0")


class TestComputeAllSignals(unittest.TestCase):
    @patch("services.stock_analysis.get_bars_df")
    @patch("services.market_regime.get_bars_df")
    def test_returns_15_signals_ranked_and_persists_regime(self, mock_regime_bars, mock_stock_bars):
        mock_regime_bars.side_effect = all_bullish_side_effect
        mock_stock_bars.side_effect = all_bullish_side_effect
        db = make_db()

        signals = signals_service.compute_all_signals(db, persist=True, include_fundamentals=False)

        self.assertEqual(len(signals), len(signals_service.TICKERS))
        scores = [s["score_total"] for s in signals if s.get("score_total") is not None]
        self.assertEqual(scores, sorted(scores, reverse=True))  # ranked best-first

        regime_rows = db.execute("SELECT COUNT(*) FROM market_regime").fetchone()[0]
        self.assertEqual(regime_rows, 1)

        signal_rows = db.execute("SELECT COUNT(*) FROM signals").fetchone()[0]
        self.assertEqual(signal_rows, len(signals_service.TICKERS))

    @patch("services.stock_analysis.get_bars_df")
    @patch("services.market_regime.get_bars_df")
    def test_one_bad_ticker_does_not_break_the_batch(self, mock_regime_bars, mock_stock_bars):
        def stock_side_effect(db, ticker, timeframe, force_refresh=False):
            if ticker == "TSLA":
                return empty_bars(), {"source": "cache", "fresh": False, "stale_fallback": False, "error": "no data"}
            return all_bullish_side_effect(db, ticker, timeframe, force_refresh)

        mock_regime_bars.side_effect = all_bullish_side_effect
        mock_stock_bars.side_effect = stock_side_effect
        db = make_db()

        signals = signals_service.compute_all_signals(db, persist=True, include_fundamentals=False)

        self.assertEqual(len(signals), len(signals_service.TICKERS))
        tsla = next(s for s in signals if s["ticker"] == "TSLA")
        self.assertEqual(tsla["signal_label"], "NO DATA")
        self.assertIsNone(tsla["score_total"])
        # TSLA sorts to the end since it has no score
        self.assertEqual(signals[-1]["ticker"], "TSLA")

        # TSLA should NOT have been persisted (no data == nothing meaningful to store)
        row = db.execute("SELECT * FROM signals WHERE ticker='TSLA'").fetchone()
        self.assertIsNone(row)

    @patch("services.stock_analysis.get_bars_df")
    @patch("services.market_regime.get_bars_df")
    def test_shares_one_benchmark_fetch_across_all_15_stocks(self, mock_regime_bars, mock_stock_bars):
        mock_regime_bars.side_effect = all_bullish_side_effect
        mock_stock_bars.side_effect = all_bullish_side_effect
        db = make_db()

        signals_service.compute_all_signals(db, persist=False, include_fundamentals=False)

        # Every tracked stock, plus the benchmark cache (SPY, QQQ and the unique sector ETFs
        # actually referenced by SECTOR_ETF_MAP) built ONCE and shared — not N x (1 + benchmarks)
        # as it would be if each stock fetched its own. Derived from the universe rather than
        # hard-coded, so growing the list cannot silently make this test meaningless.
        from config import STOCK_UNIVERSE
        unique_sector_etfs = len(set(SECTOR_ETF_MAP.values()))
        expected = len(STOCK_UNIVERSE) + 2 + unique_sector_etfs
        self.assertEqual(mock_stock_bars.call_count, expected)
        # The sharing is the point: per-stock fetching would be far larger than this.
        self.assertLess(mock_stock_bars.call_count,
                        len(STOCK_UNIVERSE) * (1 + unique_sector_etfs))



class TestTransactionSafetyAfterFailures(unittest.TestCase):
    """Regression test for a real production failure.

    On PostgreSQL, the first failed statement aborts the entire transaction and every later
    statement returns "current transaction is aborted". Swallowing an enrichment error without
    rolling back therefore broke the rest of the request — /api/explain/NVDA returned 500 even
    though the failure was in an optional fundamentals lookup.

    SQLite does not behave this way, so this can only be tested by asserting the ROLLBACK
    CONTRACT: `_safe` must call rollback on the connection when the wrapped call raises.
    """

    class _RecordingDb:
        def __init__(self):
            self.rollbacks = 0

        def rollback(self):
            self.rollbacks += 1

    def test_safe_rolls_back_when_the_wrapped_call_fails(self):
        db = self._RecordingDb()

        def boom():
            raise RuntimeError("simulated provider failure")

        result = signals_service._safe(db, boom)
        self.assertIsNone(result)
        self.assertEqual(db.rollbacks, 1, "_safe must roll back so Postgres can continue")

    def test_safe_does_not_roll_back_on_success(self):
        db = self._RecordingDb()
        self.assertEqual(signals_service._safe(db, lambda: 42), 42)
        self.assertEqual(db.rollbacks, 0)

    def test_safe_survives_a_connection_whose_rollback_also_fails(self):
        class BadDb:
            def rollback(self):
                raise RuntimeError("connection already dead")

        def boom():
            raise RuntimeError("original failure")

        # Must return None rather than surfacing the rollback error, which would mask the cause.
        self.assertIsNone(signals_service._safe(BadDb(), boom))

    @patch("services.stock_analysis.get_bars_df")
    @patch("services.market_regime.get_bars_df")
    @patch("services.signals_service.get_fundamentals")
    def test_failing_enrichment_still_yields_a_usable_signal(self, mock_fund, mock_regime_bars,
                                                             mock_stock_bars):
        mock_regime_bars.side_effect = all_bullish_side_effect
        mock_stock_bars.side_effect = all_bullish_side_effect
        mock_fund.side_effect = RuntimeError("SEC EDGAR unreachable")
        db = make_db()

        signal = signals_service.compute_signal_for_ticker(db, "NVDA", persist=True)

        # The price-based signal must survive a fundamentals outage entirely.
        self.assertEqual(signal["data_status"], "OK")
        self.assertIsNotNone(signal["score_total"])
        row = db.execute("SELECT * FROM signals WHERE ticker='NVDA'").fetchone()
        self.assertIsNotNone(row, "signal must still persist after an enrichment failure")

if __name__ == "__main__":
    unittest.main()
