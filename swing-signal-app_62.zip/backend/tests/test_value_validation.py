"""
Value performance validation — tests.

The point of failure for a study like this is not arithmetic, it is leakage: a forward return that
leaks into the score, a percentile that sees the future, a cohort measured over a shorter horizon
than its peers. Those are what these tests are aimed at.
"""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from services import value_service as vs
from services import value_validation as vv


def _bars(start="2020-07-27", days=2220, price=100.0, drift=0.0):
    out, d = [], date.fromisoformat(start)
    for i in range(days):
        p = price + drift * i
        out.append({"ts": d.isoformat(), "close_raw": round(p, 4), "close_adj": round(p, 4)})
        d += timedelta(days=1)
    return out


class TestCohortDates:
    def test_first_cohort_is_the_floor_plus_three_years(self):
        assert vv.FIRST_COHORT == "2023-07-27"

    def test_cohorts_are_quarterly(self):
        ds = vv.cohort_dates("2026-08-19")
        assert ds[0] == "2023-07-27"
        assert ds[1].startswith("2023-10")
        assert ds[2].startswith("2024-01")

    def test_a_cohort_without_a_full_forward_year_is_excluded(self):
        """Measuring one cohort over a shorter horizon would produce a number that is not
        comparable with the others — worse than producing none."""
        ds = vv.cohort_dates("2026-08-19")
        for d in ds:
            assert (date.fromisoformat(d) + timedelta(days=vv.FORWARD_DAYS)
                    <= date.fromisoformat("2026-08-19"))

    def test_no_cohorts_when_history_is_too_short(self):
        assert vv.cohort_dates("2024-01-01") == []

    def test_the_forward_window_is_the_pre_registered_one_year(self):
        assert vv.FORWARD_DAYS == 365


class TestForwardReturn:
    def test_uses_the_adjusted_close_not_the_raw_one(self):
        """RAW is for valuation, ADJUSTED is for returns. Swapping them is the error this whole
        phase exists to avoid, so it is asserted rather than assumed."""
        bars = _bars(days=800)
        for b in bars:
            b["close_raw"] = b["close_adj"] * 10.0        # a split-like divergence
        assert vv.forward_return(bars, "2020-08-01") == pytest.approx(0.0, abs=1e-9)

    def test_a_doubling_reads_one_hundred_percent(self):
        bars = _bars(days=800, price=100.0)
        for b in bars:
            if b["ts"] >= "2021-08-01":
                b["close_adj"] = 200.0
        assert vv.forward_return(bars, "2020-08-01") == pytest.approx(100.0)

    def test_missing_forward_price_is_none_not_zero(self):
        assert vv.forward_return(_bars(days=100), "2020-08-01") is None

    def test_a_non_trading_start_date_uses_the_next_available_bar(self):
        bars = [b for b in _bars(days=800) if b["ts"] != "2020-08-01"]
        assert vv.forward_return(bars, "2020-08-01") is not None


class TestStatistics:
    def test_perfect_agreement_is_plus_one(self):
        assert vv.spearman([1, 2, 3, 4], [10, 20, 30, 40]) == 1.0

    def test_perfect_disagreement_is_minus_one(self):
        assert vv.spearman([1, 2, 3, 4], [40, 30, 20, 10]) == -1.0

    def test_too_few_pairs_is_none(self):
        assert vv.spearman([1, 2], [3, 4]) is None

    def test_missing_values_are_dropped_pairwise(self):
        assert vv.spearman([1, None, 3, 4], [10, 20, 30, 40]) == 1.0

    def test_no_p_value_is_reported(self):
        src = Path(vv.__file__).read_text().lower()
        assert "p_value" not in src and "pvalue" not in src


class TestNoLeakage:
    def test_the_score_cannot_see_the_forward_window(self):
        """The decisive test. A cohort's score must be identical whether or not the future exists."""
        bars = _bars(days=2220, drift=0.05)
        filings = [{"filed": f"{y}-02-15", "period_end": f"{y-1}-12-31", "currency": "USD",
                    "eps_diluted": 5.0, "shares_outstanding": 1e6, "operating_cash_flow": 1.2e7,
                    "capex": 2e6, "operating_income": 9e6, "revenue": 5e7,
                    "total_debt": 0.0, "total_cash": 0.0} for y in range(2021, 2027)]
        truncated = [b for b in bars if b["ts"] <= "2024-07-27"]
        assert (vs.evaluate("T", bars, filings, as_of="2024-07-27")["value"]
                == vs.evaluate("T", truncated, filings, as_of="2024-07-27")["value"])

    def test_the_minimums_are_the_pre_registered_ones(self):
        assert vv.MIN_COMPANIES_PER_COHORT == 25
        assert vv.MIN_GROUP_SIZE == 8

    def test_nothing_is_tunable_from_a_query_string(self):
        """A knob is an invitation to turn it until the result reads well."""
        src = Path(vv.__file__).read_text()
        assert "request.args" not in src


class TestSpreadIsDescriptiveOnly:
    def _scored(self, **over):
        filing = {"filed": "2021-02-15", "period_end": "2020-12-31", "currency": "USD",
                  "eps_diluted": 5.0, "shares_outstanding": 1e6, "operating_cash_flow": 1.2e7,
                  "capex": 2e6, "operating_income": 9e6, "revenue": 5e7,
                  "total_debt": 0.0, "total_cash": 0.0}
        filing.update(over)
        return vs.evaluate("T", _bars(days=1600, drift=0.02), [filing])

    def test_spread_is_reported(self):
        out = self._scored()
        assert out["spread"] is not None
        assert out["spread"] == pytest.approx(
            max(m["percentile"] for m in out["metrics"].values() if m["status"] == vs.OK)
            - min(m["percentile"] for m in out["metrics"].values() if m["status"] == vs.OK), abs=0.1)

    def test_spread_does_not_change_the_value(self):
        out = self._scored()
        pcts = [m["percentile"] for m in out["metrics"].values() if m["status"] == vs.OK]
        assert out["value"] == pytest.approx(sum(pcts) / len(pcts), abs=0.05)

    def test_spread_does_not_change_the_verdict(self):
        out = self._scored()
        assert out["verdict"] == vs.verdict_for(out["value"])

    def test_spread_is_none_when_fewer_than_two_metrics(self):
        out = self._scored(shares_outstanding=None)
        assert out["spread"] is None

    def test_the_validation_never_gates_on_spread(self):
        src = Path(vv.__file__).read_text()
        body = src.split("def run(")[1]
        for forbidden in ("if spread", "spread >", "spread <", "spread >="):
            assert forbidden not in body


class TestFrozenAfterDiagnostic:
    """Nothing was changed in response to the 50-stock output or the disagreement diagnostic."""

    def test_the_metric_set_is_unchanged(self):
        assert vs.METRICS == ("fcf_yield_pct", "ev_to_ebit", "pe_ratio")

    def test_the_bands_are_unchanged(self):
        assert vs.BANDS == ((75.0, "CHEAP"), (25.0, "FAIR"), (0.0, "EXPENSIVE"))

    def test_the_mean_is_still_a_plain_mean(self):
        src = Path(vs.__file__).read_text()
        assert "sum(percentiles) / len(percentiles)" in src

    def test_no_agreement_score_was_added(self):
        assert not hasattr(vs, "AGREEMENT_BANDS")
        assert not hasattr(vs, "agreement_for")

    def test_disagreement_never_becomes_unknown(self):
        src = Path(vs.__file__).read_text()
        after = src.split('out["spread"]')[1]
        assert "UNKNOWN" not in after.split("out[\"value\"]")[0]

    def test_company_health_is_not_in_the_validation(self):
        src = Path(vv.__file__).read_text()
        assert "company_health" not in src.replace('"company_health"', "")

    def test_c1_is_untouched(self):
        from services import company_health as ch
        assert ch.COVERAGE_GATE_PCT == 75.0 and ch.CAP_AT_N_RED_FLAGS == 2


if __name__ == "__main__":
    unittest.main()
