"""
Guards against table header/column drift in the frontend.

The Stocks and Dashboard pages share one renderer (renderStocksTable in dashboard.js). When the
JS grew to 10 columns, stocks.html kept its original 6 headers, so every header from "Sector"
onward sat above the wrong column — RSI appeared under "Sector", the trend label under "Data
Status". Nothing errored; the page just quietly lied about what it was showing.

These tests parse the actual templates and JS so the mismatch fails the suite instead of
reaching a user.
"""
import re
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

FRONTEND = Path(__file__).resolve().parent.parent.parent / "frontend"
TEMPLATES = FRONTEND / "templates"
JS = FRONTEND / "static" / "js"


def header_texts(html: str, table_index: int = 0) -> list:
    """Header cell texts of the Nth <thead> in the document."""
    theads = re.findall(r"<thead>(.*?)</thead>", html, re.DOTALL)
    if not theads:
        return []
    return [re.sub(r"<[^>]+>", "", h).strip()
            for h in re.findall(r"<th[^>]*>(.*?)</th>", theads[table_index], re.DOTALL)]


def rendered_cell_count(js: str, function_name: str) -> int:
    """Count <td> cells in the template literal returned by a render function."""
    start = js.find(f"function {function_name}")
    if start == -1:
        raise AssertionError(f"{function_name} not found")
    # The main row template is the last `return \`` block before the closing .join("")
    body = js[start:js.find("\n}", start)]
    rows = re.findall(r"<tr[^>]*>(.*?)</tr>", body, re.DOTALL)
    if not rows:
        raise AssertionError(f"no <tr> template found in {function_name}")
    return max(len(re.findall(r"<td", r)) for r in rows)


class TestStocksTableColumnsMatchRenderer(unittest.TestCase):
    def setUp(self):
        self.js = (JS / "dashboard.js").read_text()
        self.cells = rendered_cell_count(self.js, "renderStocksTable")

    def test_dashboard_headers_match_rendered_cells(self):
        headers = header_texts((TEMPLATES / "dashboard.html").read_text())
        self.assertEqual(len(headers), self.cells,
                         f"dashboard.html has {len(headers)} headers but the renderer emits "
                         f"{self.cells} cells")

    def test_stocks_page_headers_match_rendered_cells(self):
        headers = header_texts((TEMPLATES / "stocks.html").read_text())
        self.assertEqual(len(headers), self.cells,
                         f"stocks.html has {len(headers)} headers but the renderer emits "
                         f"{self.cells} cells — this is the exact drift that put RSI under the "
                         f"'Sector' heading")

    def test_both_pages_use_identical_headers(self):
        """They share a renderer, so their headers must be identical, not merely equal in count."""
        self.assertEqual(header_texts((TEMPLATES / "stocks.html").read_text()),
                         header_texts((TEMPLATES / "dashboard.html").read_text()))

    def test_loading_row_colspan_covers_every_column(self):
        for name in ("stocks.html", "dashboard.html"):
            html = (TEMPLATES / name).read_text()
            for colspan in re.findall(r'class="loading-row"><td colspan="(\d+)"', html):
                self.assertGreaterEqual(
                    int(colspan), self.cells,
                    f"{name}: loading-row colspan {colspan} is narrower than {self.cells} columns")


class TestOtherTablesHaveConsistentWidths(unittest.TestCase):
    """Any table whose empty-state colspan is narrower than its own header count renders a
    ragged row when there's no data.

    The comparison must be made PER TABLE, not per file: a page can legitimately contain several
    tables of different widths (backtest.html has 6-, 7- and 10-column tables), and checking
    every colspan against the widest table on the page is a false positive.
    """

    def test_each_tables_colspan_covers_its_own_headers(self):
        for template in sorted(TEMPLATES.glob("*.html")):
            html = template.read_text()
            for table in re.findall(r"<table[^>]*>(.*?)</table>", html, re.DOTALL):
                theads = re.findall(r"<thead>(.*?)</thead>", table, re.DOTALL)
                if not theads:
                    continue
                width = len(re.findall(r"<th[^>]*>", theads[0]))
                for cs in re.findall(r'<td colspan="(\d+)"', table):
                    self.assertGreaterEqual(
                        int(cs), width,
                        f"{template.name}: a colspan of {cs} is narrower than its own table's "
                        f"{width} columns")


class TestBacktestFormMatchesEngine(unittest.TestCase):
    """The form and the engine must not drift apart.

    The Minimum Score input accepted 0 and defaulted to 0, while the engine could never apply
    anything below the BUY threshold of 62. The result looked like a dead control: every value
    the user tried returned identical results. Pinning the input's floor to the engine's constant
    means retuning the signal thresholds cannot silently recreate that.
    """

    def test_min_score_input_floor_matches_the_engines_entry_floor(self):
        import sys
        from pathlib import Path as _P
        sys.path.insert(0, str(_P(__file__).resolve().parent.parent))
        from services.backtest_service import ENTRY_LABEL_FLOOR

        html = (TEMPLATES / "backtest.html").read_text()
        field = re.search(r'<input[^>]*id="bt-minscore"[^>]*>', html)
        self.assertIsNotNone(field, "the Minimum Score input is missing from backtest.html")
        markup = field.group(0)
        self.assertIn(f'min="{ENTRY_LABEL_FLOOR}"', markup,
                      "the input's minimum must match the engine's entry floor")
        self.assertIn(f'value="{ENTRY_LABEL_FLOOR}"', markup,
                      "the default must be a value that actually does something")

    def test_config_note_target_element_exists(self):
        """backtest.js writes the applied-threshold note into #bt-config-note."""
        self.assertIn('id="bt-config-note"', (TEMPLATES / "backtest.html").read_text())



class TestBuildIdentification(unittest.TestCase):
    """A deploy once reported 'live' while serving a stale archive, and the only symptom was
    that a known-fixed bug was still present. /health now states which build is running and
    which corporate-action adjustment it will apply, so verifying a deploy is one request.
    """

    def test_health_reports_build_id_and_adjustment(self):
        import sys
        from pathlib import Path as _P
        sys.path.insert(0, str(_P(__file__).resolve().parent.parent))
        import app as app_module

        self.assertTrue(app_module.BUILD_ID, "BUILD_ID must not be empty")
        flask_app = app_module.create_app()
        with flask_app.test_client() as c:
            body = c.get("/health").get_json()
        self.assertEqual(body["build_id"], app_module.BUILD_ID)
        self.assertEqual(body["bar_adjustment"], "all")
        self.assertEqual(body["status"], "ok")


class TestDashboardReflectsTheUniverse(unittest.TestCase):
    """Both of these were hard-coded and both were wrong the moment the stock list changed."""

    def test_universe_heading_is_not_a_hard_coded_number(self):
        html = (TEMPLATES / "dashboard.html").read_text()
        self.assertNotIn("15 Stocks", html)
        self.assertIn("stocks|length", html, "the heading must count the universe, not state it")

    def test_dashboard_renders_the_real_count(self):
        import sys
        from pathlib import Path as _P
        sys.path.insert(0, str(_P(__file__).resolve().parent.parent))
        import app as app_module
        from config import STOCK_UNIVERSE
        body = app_module.create_app().test_client().get("/").data.decode()
        self.assertIn(f"{len(STOCK_UNIVERSE)} Stocks", body)

    def test_sector_strip_replaced_the_index_tiles(self):
        html = (TEMPLATES / "dashboard.html").read_text()
        self.assertIn('id="sector-strip"', html)
        for gone in ('id="regime-spy"', 'id="regime-qqq"', 'id="regime-breadth"', 'id="regime-vix"'):
            self.assertNotIn(gone, html)

    def test_the_regime_is_still_reported_somewhere(self):
        """It contributes 5 of the 100 points in every score. Removing the tiles is fine;
        removing all trace of it would make those points unexplainable."""
        self.assertIn('id="regime-summary"', (TEMPLATES / "dashboard.html").read_text())
        self.assertIn("regime-summary", (JS / "dashboard.js").read_text())


if __name__ == "__main__":
    unittest.main()
