"""
Tests for Phase 8 (alerts) and Phase 9 (plain-English explanations).

The two properties that matter most:
  - alerts are informational and de-duplicated (a 15-second dashboard poll must not create the
    same alert 240 times an hour);
  - explanations never contain a number the engine did not compute.
"""
import sys
import unittest
from pathlib import Path

import database

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import STOCK_UNIVERSE
from services import alert_service as al
from services import explanation_service as ex

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]),
        )
    conn.commit()
    return conn


def signal(**overrides):
    base = {
        "ticker": "NVDA", "data_status": "OK", "signal_label": "BUY", "score_total": 72.0,
        "score_max_currently_available": 100, "current_price": 150.0, "ideal_buy": 148.0,
        "buy_zone_low": 145.0, "buy_zone_high": 149.0, "max_entry": 151.0,
        "target1": 160.0, "primary_target": 165.0, "target3": 175.0,
        "expected_upside_pct": 11.5, "strategy_setup": "PULLBACK", "trend_label": "Uptrend",
        "market_regime": "BULL", "long_term_thesis": "STRONG", "long_term_quality": 88.0,
        "earnings_blackout": 0, "days_until_estimated_earnings": 45,
        "score_long_trend": 20.0, "score_short_trend": 9.0, "score_momentum": 12.0,
        "score_rsi_pullback": 9.0, "score_volume": 7.0, "score_support_resistance": 8.0,
        "score_relative_strength": 7.0, "score_market_regime": 4.0, "score_news": 3.5,
        "score_earnings_risk": 5.0,
    }
    base.update(overrides)
    return base


class TestAlertDeduplication(unittest.TestCase):
    def test_same_condition_does_not_realert(self):
        db = make_db()
        first = al.create_alert(db, "NVDA", "BUY_SIGNAL", "msg", dedupe_key="NVDA:BUY_SIGNAL")
        second = al.create_alert(db, "NVDA", "BUY_SIGNAL", "msg", dedupe_key="NVDA:BUY_SIGNAL")
        self.assertTrue(first)
        self.assertFalse(second)
        self.assertEqual(db.execute("SELECT COUNT(*) FROM alerts").fetchone()[0], 1)

    def test_repeated_evaluation_does_not_spam(self):
        db = make_db()
        s = signal()
        for _ in range(20):        # simulates a dashboard polling repeatedly
            al.evaluate_signal_alerts(db, s, held_quantity=0)
        buy_alerts = db.execute(
            "SELECT COUNT(*) FROM alerts WHERE alert_type='BUY_SIGNAL'").fetchone()[0]
        self.assertEqual(buy_alerts, 1)

    def test_different_conditions_alert_separately(self):
        db = make_db()
        al.create_alert(db, "NVDA", "BUY_SIGNAL", "a", dedupe_key="NVDA:BUY_SIGNAL")
        al.create_alert(db, "AMD", "BUY_SIGNAL", "b", dedupe_key="AMD:BUY_SIGNAL")
        self.assertEqual(db.execute("SELECT COUNT(*) FROM alerts").fetchone()[0], 2)


class TestAlertRules(unittest.TestCase):
    def test_buy_signal_only_when_not_already_holding(self):
        db = make_db()
        created = al.evaluate_signal_alerts(db, signal(), held_quantity=0)
        self.assertIn("BUY_SIGNAL", created)

        db2 = make_db()
        created2 = al.evaluate_signal_alerts(db2, signal(), held_quantity=10)
        self.assertNotIn("BUY_SIGNAL", created2)

    def test_enter_buy_zone_fires_when_price_inside_zone(self):
        db = make_db()
        created = al.evaluate_signal_alerts(db, signal(current_price=147.0), held_quantity=0)
        self.assertIn("ENTER_BUY_ZONE", created)

    def test_enter_buy_zone_does_not_fire_above_zone(self):
        db = make_db()
        created = al.evaluate_signal_alerts(db, signal(current_price=200.0), held_quantity=0)
        self.assertNotIn("ENTER_BUY_ZONE", created)

    def test_target_reached_only_when_holding(self):
        db = make_db()
        created = al.evaluate_signal_alerts(db, signal(current_price=170.0), held_quantity=10)
        self.assertTrue(any(c.startswith("TARGET_REACHED") for c in created))

        db2 = make_db()
        created2 = al.evaluate_signal_alerts(db2, signal(current_price=170.0), held_quantity=0)
        self.assertFalse(any(c.startswith("TARGET_REACHED") for c in created2))

    def test_signal_lost_while_holding_is_urgent(self):
        db = make_db()
        created = al.evaluate_signal_alerts(db, signal(signal_label="AVOID", score_total=20.0),
                                            held_quantity=10)
        self.assertIn("SIGNAL_LOST", created)
        row = db.execute("SELECT severity FROM alerts WHERE alert_type='SIGNAL_LOST'").fetchone()
        self.assertEqual(row["severity"], "URGENT")

    def test_earnings_alert_only_when_holding_and_close(self):
        db = make_db()
        created = al.evaluate_signal_alerts(
            db, signal(), held_quantity=10,
            earnings_info={"days_until_estimated_report": 3,
                           "estimated_next_report": "2026-09-01",
                           "estimate_confidence": "MEDIUM"})
        self.assertIn("EARNINGS_APPROACHING", created)
        msg = db.execute("SELECT message FROM alerts WHERE alert_type='EARNINGS_APPROACHING'"
                         ).fetchone()["message"]
        self.assertIn("ESTIMATED", msg)   # must never imply a confirmed date

    def test_thesis_deterioration_alerts_while_holding(self):
        db = make_db()
        created = al.evaluate_signal_alerts(
            db, signal(long_term_thesis="BROKEN"), held_quantity=10)
        self.assertIn("THESIS_DETERIORATING", created)

    def test_data_failure_alerts_and_short_circuits(self):
        db = make_db()
        created = al.evaluate_signal_alerts(
            db, {"ticker": "NVDA", "data_status": "UNAVAILABLE", "signal_label": "NO DATA",
                 "data_error": "network down"}, held_quantity=0)
        self.assertEqual(created, ["DATA_FEED_FAILURE"])


class TestAlertLifecycle(unittest.TestCase):
    def test_acknowledge_single_and_all(self):
        db = make_db()
        al.create_alert(db, "NVDA", "BUY_SIGNAL", "a", dedupe_key="k1")
        al.create_alert(db, "AMD", "BUY_SIGNAL", "b", dedupe_key="k2")
        self.assertEqual(al.unacknowledged_count(db), 2)

        alert_id = al.get_alerts(db)[0]["id"]
        self.assertTrue(al.acknowledge(db, alert_id))
        self.assertEqual(al.unacknowledged_count(db), 1)

        self.assertEqual(al.acknowledge_all(db), 1)
        self.assertEqual(al.unacknowledged_count(db), 0)

    def test_acknowledge_unknown_id_returns_false(self):
        self.assertFalse(al.acknowledge(make_db(), 9999))


class TestExplanationGrounding(unittest.TestCase):
    """The core Phase 9 guarantee: no invented numbers."""

    def _numbers_in(self, text):
        import re
        return {round(float(n.replace(",", "")), 2)
                for n in re.findall(r"-?\d+(?:,\d{3})*(?:\.\d+)?", text)}

    def test_every_number_in_the_text_comes_from_the_engine(self):
        s = signal()
        text = ex.generate_rule_based(s)
        facts = ex.build_source_facts(s)

        allowed = set()
        for v in facts.values():
            if isinstance(v, (int, float)):
                allowed.add(round(float(v), 2))
        # Derived values the generator computes explicitly from two engine numbers.
        price, high = s["current_price"], s["buy_zone_high"]
        allowed.add(round((price - high) / high * 100, 1))
        # Component maxima are structural constants, not data.
        allowed |= {20, 10, 15, 5, 100}

        for n in self._numbers_in(text):
            self.assertTrue(
                any(abs(n - a) < 0.15 for a in allowed),
                f"explanation contains {n}, which the engine never computed")

    def test_no_data_signal_produces_honest_text(self):
        text = ex.generate_rule_based(
            {"ticker": "NVDA", "signal_label": "NO DATA", "score_total": None,
             "data_error": "feed down"})
        self.assertIn("not enough data", text.lower())

    def test_text_never_mentions_a_stop_loss(self):
        for label in ("STRONG BUY", "BUY", "WATCH", "NO TRADE", "AVOID"):
            text = ex.generate_rule_based(signal(signal_label=label)).lower()
            self.assertNotIn("stop loss", text)
            self.assertNotIn("stop-loss", text)

    def test_flags_when_components_were_unavailable(self):
        s = signal(score_news=None, score_earnings_risk=None,
                   score_max_currently_available=90)
        text = ex.generate_rule_based(s)
        self.assertIn("could not be evaluated", text)
        self.assertIn("90", text)

    def test_warns_when_price_is_above_the_buy_zone(self):
        text = ex.generate_rule_based(signal(current_price=200.0))
        self.assertIn("above the top of the buy zone", text)
        self.assertIn("would wait", text)

    def test_deteriorating_thesis_is_called_out(self):
        text = ex.generate_rule_based(signal(long_term_thesis="BROKEN", long_term_quality=15.0))
        self.assertIn("careful", text.lower())

    def test_includes_the_not_advice_disclaimer(self):
        self.assertIn("not advice", ex.generate_rule_based(signal()).lower())


class TestExplanationPersistence(unittest.TestCase):
    def test_generates_and_persists_with_generator_recorded(self):
        db = make_db()
        result = ex.generate_explanation(db, signal(), prefer_llm=False)
        self.assertEqual(result["generator"], ex.RULE_BASED)
        self.assertIn("deterministically", result["generator_note"])
        self.assertTrue(result["text"])
        self.assertIn("score_total", result["source_facts"])

        row = db.execute("SELECT * FROM explanations WHERE ticker='NVDA'").fetchone()
        self.assertIsNotNone(row)
        self.assertEqual(row["generator"], ex.RULE_BASED)

    def test_llm_not_used_without_an_api_key(self):
        import os
        db = make_db()
        saved = os.environ.pop("ANTHROPIC_API_KEY", None)
        try:
            result = ex.generate_explanation(db, signal(), prefer_llm=True)
            self.assertEqual(result["generator"], ex.RULE_BASED)
            self.assertFalse(result["llm_available"])
        finally:
            if saved:
                os.environ["ANTHROPIC_API_KEY"] = saved


if __name__ == "__main__":
    unittest.main()
