"""
Study 2 — Future Fundamental Strength. The pre-registration, and the guards that make it honest.

Study 2 inherits every point-in-time guard from Study 1 by importing its machinery, and those are
already mutation-tested in test_health_backtest.py. What is tested here is what is NEW and what
could be got wrong in a way that produces a flattering number:

  * the pre-registered constants are exactly what was approved;
  * the deterioration anchors are C1's OWN anchors, read from the frozen model rather than copied;
  * levels are levels, not changes — the Study 1 error must not reappear;
  * statistic C really does remove what the base composite explains;
  * a company already weak at the scoring date cannot count as having deteriorated;
  * a company too sparsely measured is classified neither healthy nor weak;
  * Study 1 is untouched.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
from config import STOCK_UNIVERSE  # noqa: E402
from providers.edgar_concepts import HISTORY_VALUE_FIELDS  # noqa: E402
from providers.fundamentals_base import AnnualPeriod  # noqa: E402
from services import company_health as ch  # noqa: E402
from services import health_backtest as hb  # noqa: E402
from services import health_study2 as s2  # noqa: E402

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]))
    conn.commit()
    return conn


# =================================================================================================
# THE PRE-REGISTRATION
# =================================================================================================
class ThePreRegistration(unittest.TestCase):

    def test_the_five_forward_measures_are_levels_not_changes(self):
        """THE STUDY 1 ERROR MUST NOT REAPPEAR. Study 1 measured forward CHANGES in quantities C1
        scores as LEVELS, which built regression to the mean into its own outcome. Every measure
        here is a level (or, for revenue, a rate — as C1 also scores growth as a rate)."""
        names = [m for m, _d in s2.FORWARD_LEVEL_MEASURES]
        self.assertEqual(names, ["revenue_cagr_pct", "roic_pct", "operating_margin_pct",
                                 "net_debt_to_ebitda", "fcf_margin_pct"])
        for name in names:
            self.assertNotIn("_change", name)
            self.assertNotIn("_pp", name)

    def test_leverage_is_the_only_inverted_measure(self):
        inverted = [m for m, higher in s2.FORWARD_LEVEL_MEASURES if not higher]
        self.assertEqual(inverted, ["net_debt_to_ebitda"])

    def test_the_dates_and_windows_are_study_ones(self):
        """Imported rather than restated, so the two studies cannot drift onto different footings."""
        self.assertIs(s2.SCORING_DATES, hb.SCORING_DATES)
        self.assertEqual(s2.SCORING_DATES,
                         ("2019-06-30", "2020-06-30", "2021-06-30", "2022-06-30"))
        self.assertEqual(s2.HISTORY_PERIODS, 5)
        self.assertEqual(s2.FORWARD_YEARS, 3)
        self.assertEqual(s2.MIN_COMPANIES_PER_DATE, 25)
        self.assertEqual(s2.MIN_GROUP_SIZE, 8)

    def test_no_p_value_anywhere(self):
        source = (Path(__file__).resolve().parent.parent / "services" / "health_study2.py").read_text()
        self.assertNotIn("p_value", source)

    def test_study_one_is_untouched(self):
        """Study 1 stands permanently as recorded. Study 2 imports it and changes nothing in it."""
        self.assertEqual(hb.FORWARD_MEASURES, (
            ("revenue_cagr_pct", True), ("operating_margin_change_pp", True),
            ("roic_change_pp", True), ("net_debt_to_ebitda_change", False),
            ("fcf_margin_change_pp", True)))


class TheDeteriorationDefinitionBorrowsC1sOwnAnchors(unittest.TestCase):
    """No threshold is invented. Every number comes from the frozen model, where it was fixed
    before any company had been scored."""

    def test_the_anchors_are_read_from_the_frozen_model(self):
        model = {name: (direction, weak)
                 for _w, defs in ch.COMPANY_HEALTH_MODEL.values()
                 for name, direction, weak, _a, _s in defs}
        for name, _higher in s2.FORWARD_LEVEL_MEASURES:
            self.assertEqual(s2.WEAK_ANCHORS[name], model[name], name)

    def test_the_anchor_values_are_the_approved_c1_ones(self):
        self.assertEqual({k: v[1] for k, v in s2.WEAK_ANCHORS.items()},
                         {"revenue_cagr_pct": 2.0, "roic_pct": 8.0, "operating_margin_pct": 3.0,
                          "net_debt_to_ebitda": 3.5, "fcf_margin_pct": 3.0})

    def test_two_triggered_mirrors_c1s_capping_rule(self):
        self.assertEqual(s2.WEAK_MEASURES_FOR_DETERIORATION, ch.CAP_AT_N_RED_FLAGS)

    def test_a_company_at_the_anchor_counts_as_weak_on_that_measure(self):
        """'At or beyond' — the boundary is inclusive, as pre-registered."""
        weak, triggered, _n = s2.is_fundamentally_weak(
            {"roic_pct": 8.0, "operating_margin_pct": 3.0, "fcf_margin_pct": 20.0})
        self.assertTrue(weak)
        self.assertEqual(sorted(triggered), ["operating_margin_pct", "roic_pct"])

    def test_leverage_is_weak_when_HIGH_not_low(self):
        """A sign error here would invert the deterioration result entirely."""
        weak, triggered, _n = s2.is_fundamentally_weak(
            {"net_debt_to_ebitda": 5.0, "roic_pct": 4.0, "fcf_margin_pct": 25.0})
        self.assertTrue(weak)
        self.assertIn("net_debt_to_ebitda", triggered)
        healthy, triggered2, _n2 = s2.is_fundamentally_weak(
            {"net_debt_to_ebitda": 0.2, "roic_pct": 30.0, "fcf_margin_pct": 25.0})
        self.assertFalse(healthy)
        self.assertEqual(triggered2, [])

    def test_one_weak_measure_is_not_deterioration(self):
        weak, triggered, _n = s2.is_fundamentally_weak(
            {"roic_pct": 4.0, "operating_margin_pct": 20.0, "fcf_margin_pct": 25.0})
        self.assertFalse(weak)
        self.assertEqual(triggered, ["roic_pct"])

    def test_too_few_measures_means_unclassified_not_healthy(self):
        """Calling a barely-measured company healthy is an assumption; calling it weak is worse."""
        weak, _t, assessed = s2.is_fundamentally_weak({"roic_pct": 2.0, "fcf_margin_pct": 1.0})
        self.assertIsNone(weak)
        self.assertEqual(assessed, 2)

    def test_three_measures_is_enough_to_classify(self):
        weak, _t, assessed = s2.is_fundamentally_weak(
            {"roic_pct": 2.0, "fcf_margin_pct": 1.0, "operating_margin_pct": 20.0})
        self.assertIsNotNone(weak)
        self.assertEqual(assessed, 3)


class StatisticC(unittest.TestCase):
    """C must genuinely remove what the base composite explains, or it is just A with extra steps."""

    def test_residuals_of_a_perfect_line_are_zero(self):
        residuals = s2.linear_residuals([1.0, 2.0, 3.0, 4.0], [2.0, 4.0, 6.0, 8.0])
        for r in residuals:
            self.assertAlmostEqual(r, 0.0)

    def test_c_is_zero_when_the_score_only_repeats_the_base_composite(self):
        """THE POINT OF C. If the forward outcome is entirely explained by today's fundamentals,
        a score that merely mirrors those fundamentals adds nothing, and C must say so even though
        A would look excellent."""
        base = [0.1, 0.3, 0.5, 0.7, 0.9]
        forward = [0.15, 0.35, 0.55, 0.75, 0.95]          # a perfect function of base
        score = [10.0, 30.0, 50.0, 70.0, 90.0]            # a perfect function of base too
        a = hb.spearman(score, forward)
        c = hb.spearman(score, s2.linear_residuals(base, forward))
        self.assertAlmostEqual(a, 1.0)
        self.assertIsNone(c) if c is None else self.assertLess(abs(c), 0.2)

    def test_c_is_positive_when_the_score_knows_something_the_base_does_not(self):
        base = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5]
        forward = [0.1, 0.2, 0.3, 0.7, 0.8, 0.9]
        score = [10.0, 20.0, 30.0, 70.0, 80.0, 90.0]
        c = hb.spearman(score, s2.linear_residuals(base, forward))
        self.assertGreater(c, 0.9)

    def test_the_composite_inverts_leverage(self):
        rows = [{"ticker": "LOWDEBT", "forward": {"net_debt_to_ebitda": 0.2}},
                {"ticker": "HIGHDEBT", "forward": {"net_debt_to_ebitda": 6.0}}]
        comp = s2.composite(rows, "forward")
        self.assertGreater(comp["LOWDEBT"][0], comp["HIGHDEBT"][0])

    def test_the_composite_does_not_invert_the_others(self):
        rows = [{"ticker": "GOOD", "forward": {"roic_pct": 30.0}},
                {"ticker": "BAD", "forward": {"roic_pct": 2.0}}]
        comp = s2.composite(rows, "forward")
        self.assertGreater(comp["GOOD"][0], comp["BAD"][0])


class DeteriorationIsATransition(unittest.TestCase):

    def _db_with(self, rows_by_ticker):
        db = make_db()
        for ticker, rows in rows_by_ticker.items():
            periods = []
            for period_end, filed, values in rows:
                full = {f: None for f in HISTORY_VALUE_FIELDS}
                full.update(values)
                p = AnnualPeriod(ticker=ticker, source="test", period_end=period_end, filed=filed,
                                 taxonomy="us-gaap", currency="USD", form="10-K", values=full)
                p.ticker = ticker
                periods.append(p)
            from services import fundamentals_history_service as fh
            fh.store_history(db, ticker, periods)
        return db

    def test_a_company_already_weak_at_the_start_is_not_counted_as_deteriorating(self):
        """Staying weak is not deteriorating. Counting it would inflate the rate in whichever
        group happens to contain the already-weak companies."""
        already = {"roic_pct": 2.0, "operating_margin_pct": 1.0, "fcf_margin_pct": 1.0}
        self.assertTrue(s2.is_fundamentally_weak(already)[0])

    def test_the_healthy_to_weak_transition_is_what_counts(self):
        healthy = {"roic_pct": 25.0, "operating_margin_pct": 20.0, "fcf_margin_pct": 18.0}
        weak = {"roic_pct": 3.0, "operating_margin_pct": 1.0, "fcf_margin_pct": 15.0}
        self.assertFalse(s2.is_fundamentally_weak(healthy)[0])
        self.assertTrue(s2.is_fundamentally_weak(weak)[0])


class ReturnsAreSecondaryAndBounded(unittest.TestCase):

    def test_a_price_far_from_the_target_date_is_refused(self):
        """A close from months away is not that date's price. Better no return than a wrong one."""
        db = make_db()
        db.execute("INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume)"
                   " VALUES ('AAPL', '1Day', '2019-01-02', 1, 1, 1, 100, 1)")
        db.commit()
        close, _ts = s2._close_on_or_before(db, "AAPL", "2019-06-30")
        self.assertIsNone(close)

    def test_a_price_within_the_window_is_accepted(self):
        db = make_db()
        db.execute("INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume)"
                   " VALUES ('AAPL', '1Day', '2019-06-28', 1, 1, 1, 100, 1)")
        db.commit()
        close, ts = s2._close_on_or_before(db, "AAPL", "2019-06-30")
        self.assertEqual(close, 100)
        self.assertEqual(ts, "2019-06-28")

    def test_no_future_bar_is_used_for_the_start_price(self):
        db = make_db()
        db.execute("INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close, volume)"
                   " VALUES ('AAPL', '1Day', '2021-06-28', 1, 1, 1, 500, 1)")
        db.commit()
        self.assertIsNone(s2._close_on_or_before(db, "AAPL", "2019-06-30")[0])

    def test_the_return_is_computed_the_obvious_way(self):
        db = make_db()
        for ts, close in (("2019-06-28", 100.0), ("2022-06-29", 150.0)):
            db.execute("INSERT INTO market_bars (ticker, timeframe, ts, open, high, low, close,"
                       " volume) VALUES ('AAPL', '1Day', ?, 1, 1, 1, ?, 1)", (ts, close))
        db.commit()
        value, _bars = s2.forward_return_pct(db, "AAPL", "2019-06-30", "2022-06-30")
        self.assertAlmostEqual(value, 50.0)


if __name__ == "__main__":
    unittest.main()
