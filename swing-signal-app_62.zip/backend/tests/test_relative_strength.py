import sys
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services.relative_strength import compute_relative_strength, label_excess_return


def const_return_series(n, total_pct_over_5d):
    """A flat-then-jump series so 5-day return is exactly `total_pct_over_5d`%."""
    base = [100.0] * (n - 5)
    end_val = 100.0 * (1 + total_pct_over_5d / 100)
    import numpy as np
    tail = list(np.linspace(100.0, end_val, 6))[1:]
    return pd.Series(base + tail)


class TestLabelExcessReturn(unittest.TestCase):
    def test_strong(self):
        self.assertEqual(label_excess_return(5, 5.0), "Strong")

    def test_weak(self):
        self.assertEqual(label_excess_return(5, -5.0), "Weak")

    def test_in_line(self):
        self.assertEqual(label_excess_return(5, 0.5), "In-line")

    def test_none_passthrough(self):
        self.assertIsNone(label_excess_return(5, None))


class TestComputeRelativeStrength(unittest.TestCase):
    def test_outperformance_is_positive_excess(self):
        stock = const_return_series(30, 10.0)   # stock up 10% over 5d
        spy = const_return_series(30, 2.0)       # SPY up 2% over 5d
        qqq = const_return_series(30, 3.0)
        result = compute_relative_strength(stock, {"spy": spy, "qqq": qqq, "sector": None})
        self.assertAlmostEqual(result["rs_spy_5d"], 8.0, places=1)
        self.assertAlmostEqual(result["rs_qqq_5d"], 7.0, places=1)
        self.assertEqual(result["labels"][5], "Strong")

    def test_underperformance_is_negative_excess(self):
        stock = const_return_series(30, -1.0)
        spy = const_return_series(30, 5.0)
        result = compute_relative_strength(stock, {"spy": spy, "qqq": spy, "sector": None})
        self.assertLess(result["rs_spy_5d"], 0)
        self.assertEqual(result["labels"][5], "Weak")

    def test_missing_sector_benchmark_is_none_not_zero(self):
        stock = const_return_series(30, 1.0)
        spy = const_return_series(30, 1.0)
        result = compute_relative_strength(stock, {"spy": spy, "qqq": spy, "sector": None})
        self.assertIsNone(result["rs_sector_5d"])
        self.assertIsNone(result["rs_sector_200d"])

    def test_insufficient_history_returns_none(self):
        stock = pd.Series([100.0, 101.0])
        spy = pd.Series([100.0, 101.0])
        result = compute_relative_strength(stock, {"spy": spy, "qqq": spy, "sector": None})
        self.assertIsNone(result["rs_spy_200d"])


if __name__ == "__main__":
    unittest.main()
