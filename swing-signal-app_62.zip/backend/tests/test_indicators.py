"""
Unit tests for the indicator engine (services/indicators.py), using synthetic OHLCV series
with hand-computable expected values — no network, no Alpaca, no mocking needed since this
module is pure calculation.
"""
import json
import math
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services.indicators import (
    compute_rsi, compute_macd, compute_atr, compute_adx, compute_bollinger,
    compute_historical_volatility, compute_stoch_rsi, find_swing_points,
    compute_support_resistance, classify_trend, classify_volume_trend,
    compute_all_indicators, compute_returns, _cluster_levels,
)


def make_bars(closes, highs=None, lows=None, volumes=None, start="2024-01-01"):
    n = len(closes)
    if n == 0:
        return pd.DataFrame(columns=["ts", "open", "high", "low", "close", "volume"])
    closes = pd.Series(closes, dtype=float)
    highs = pd.Series(highs, dtype=float) if highs is not None else closes + 1.0
    lows = pd.Series(lows, dtype=float) if lows is not None else closes - 1.0
    opens = closes.shift(1).fillna(closes.iloc[0])
    volumes = pd.Series(volumes, dtype=float) if volumes is not None else pd.Series([1_000_000.0] * n)
    ts = [(datetime.fromisoformat(start) + timedelta(days=i)).isoformat() for i in range(n)]
    return pd.DataFrame({"ts": ts, "open": opens, "high": highs, "low": lows, "close": closes, "volume": volumes})


class TestRSI(unittest.TestCase):
    def test_all_up_days_rsi_is_100(self):
        closes = [100 + i for i in range(30)]  # straight line up
        rsi = compute_rsi(pd.Series(closes, dtype=float), 14)
        self.assertAlmostEqual(rsi.iloc[-1], 100.0, places=4)

    def test_all_down_days_rsi_is_0(self):
        closes = [100 - i for i in range(30)]
        rsi = compute_rsi(pd.Series(closes, dtype=float), 14)
        self.assertAlmostEqual(rsi.iloc[-1], 0.0, places=4)

    def test_flat_price_rsi_is_50_not_100(self):
        closes = [100.0] * 30
        rsi = compute_rsi(pd.Series(closes, dtype=float), 14)
        self.assertAlmostEqual(rsi.iloc[-1], 50.0, places=4)

    def test_insufficient_bars_is_nan(self):
        closes = [100 + i for i in range(5)]
        rsi = compute_rsi(pd.Series(closes, dtype=float), 14)
        self.assertTrue(math.isnan(rsi.iloc[-1]))

    def test_rsi_bounded_0_100(self):
        rng = np.random.default_rng(42)
        closes = 100 + np.cumsum(rng.normal(0, 1, 200))
        rsi = compute_rsi(pd.Series(closes), 14)
        valid = rsi.dropna()
        self.assertTrue((valid >= 0).all() and (valid <= 100).all())


class TestMACD(unittest.TestCase):
    def test_uptrend_macd_positive(self):
        closes = pd.Series([100 + i * 0.5 for i in range(60)])
        macd, signal, hist = compute_macd(closes)
        self.assertGreater(macd.iloc[-1], 0)

    def test_downtrend_macd_negative(self):
        closes = pd.Series([200 - i * 0.5 for i in range(60)])
        macd, signal, hist = compute_macd(closes)
        self.assertLess(macd.iloc[-1], 0)

    def test_flat_macd_near_zero(self):
        closes = pd.Series([100.0] * 60)
        macd, signal, hist = compute_macd(closes)
        self.assertAlmostEqual(macd.iloc[-1], 0.0, places=6)
        self.assertAlmostEqual(hist.iloc[-1], 0.0, places=6)


class TestATR(unittest.TestCase):
    def test_constant_range_converges_to_range(self):
        # Every bar has high-low = 2, no gaps between bars (close each day = next open),
        # so true range == 2 every day -> ATR should converge to 2.
        n = 40
        closes = pd.Series([100.0] * n)
        highs = closes + 1.0
        lows = closes - 1.0
        atr = compute_atr(highs, lows, closes, 14)
        self.assertAlmostEqual(atr.iloc[-1], 2.0, places=4)

    def test_atr_nan_before_period(self):
        closes = pd.Series([100.0] * 5)
        highs, lows = closes + 1, closes - 1
        atr = compute_atr(highs, lows, closes, 14)
        self.assertTrue(math.isnan(atr.iloc[-1]))


class TestADX(unittest.TestCase):
    def test_strong_trend_has_high_adx(self):
        n = 60
        closes = pd.Series([100 + i * 1.5 for i in range(n)])
        highs = closes + 0.5
        lows = closes - 0.5
        adx = compute_adx(highs, lows, closes, 14)
        self.assertGreater(adx.iloc[-1], 25)  # conventionally >25 = trending

    def test_choppy_flat_market_has_low_adx(self):
        rng = np.random.default_rng(7)
        n = 80
        closes = pd.Series(100 + rng.normal(0, 0.3, n).cumsum() * 0)  # perfectly flat
        closes = pd.Series([100.0] * n)
        highs = closes + 0.1
        lows = closes - 0.1
        adx = compute_adx(highs, lows, closes, 14)
        last = adx.iloc[-1]
        self.assertTrue(math.isnan(last) or last < 20)


class TestBollinger(unittest.TestCase):
    def test_flat_series_zero_width(self):
        closes = pd.Series([50.0] * 25)
        upper, middle, lower, width = compute_bollinger(closes, 20, 2.0)
        self.assertAlmostEqual(upper.iloc[-1], 50.0, places=6)
        self.assertAlmostEqual(lower.iloc[-1], 50.0, places=6)
        self.assertAlmostEqual(width.iloc[-1], 0.0, places=6)

    def test_upper_above_lower_when_volatile(self):
        rng = np.random.default_rng(1)
        closes = pd.Series(100 + rng.normal(0, 2, 40).cumsum())
        upper, middle, lower, width = compute_bollinger(closes, 20, 2.0)
        self.assertGreater(upper.iloc[-1], lower.iloc[-1])


class TestHistoricalVolatility(unittest.TestCase):
    def test_flat_series_zero_vol(self):
        closes = pd.Series([100.0] * 25)
        vol = compute_historical_volatility(closes, 20)
        self.assertAlmostEqual(vol.iloc[-1], 0.0, places=6)

    def test_volatile_series_positive_vol(self):
        rng = np.random.default_rng(3)
        closes = pd.Series(100 * np.exp(np.cumsum(rng.normal(0, 0.02, 40))))
        vol = compute_historical_volatility(closes, 20)
        self.assertGreater(vol.iloc[-1], 0)


class TestStochRSI(unittest.TestCase):
    def test_bounded_0_100(self):
        rng = np.random.default_rng(9)
        closes = pd.Series(100 + rng.normal(0, 1, 100).cumsum())
        rsi = compute_rsi(closes, 14)
        stoch = compute_stoch_rsi(rsi, 14)
        valid = stoch.dropna()
        self.assertTrue((valid >= 0).all() and (valid <= 100).all())


class TestSwingPoints(unittest.TestCase):
    def test_detects_obvious_peak_and_trough(self):
        # Clean V shape then peak: down to a trough at index 5, up to a peak at index 10.
        highs = pd.Series([50, 45, 40, 35, 30, 25, 30, 35, 40, 45, 50, 45, 40], dtype=float)
        lows = highs - 2
        swing_high, swing_low = find_swing_points(highs, lows, window=2)
        self.assertTrue(swing_low.iloc[5])   # trough
        self.assertTrue(swing_high.iloc[10])  # peak
        # Neighbors should not also register as swing points
        self.assertFalse(swing_low.iloc[4])
        self.assertFalse(swing_high.iloc[9])

    def test_most_recent_bars_never_confirmed(self):
        highs = pd.Series(list(range(20)), dtype=float)
        lows = highs - 1
        swing_high, swing_low = find_swing_points(highs, lows, window=2)
        # last `window` bars can't be confirmed swing points (no future data yet)
        self.assertFalse(swing_high.iloc[-1])
        self.assertFalse(swing_high.iloc[-2])


class TestClusterLevels(unittest.TestCase):
    def test_groups_close_levels(self):
        clusters = _cluster_levels([100.0, 100.5, 101.0, 150.0, 151.0])
        self.assertEqual(len(clusters), 2)
        self.assertEqual(clusters[0], [100.0, 100.5, 101.0])

    def test_empty_input(self):
        self.assertEqual(_cluster_levels([]), [])


class TestTrendClassification(unittest.TestCase):
    def test_strong_uptrend_all_conditions_true(self):
        label, reasons = classify_trend(price=110, sma50=105, sma200=100, sma200_slope=1.5)
        self.assertEqual(label, "Strong Uptrend")
        self.assertEqual(len(reasons), 4)

    def test_strong_downtrend_all_conditions_false(self):
        label, reasons = classify_trend(price=90, sma50=95, sma200=100, sma200_slope=-1.5)
        self.assertEqual(label, "Strong Downtrend")

    def test_mixed_conditions_not_binary_rejected(self):
        # price above 200sma and 200sma rising, but 50sma below 200sma (temporary dip) —
        # spec explicitly requires this NOT to auto-fail to worst label.
        label, reasons = classify_trend(price=102, sma50=99, sma200=100, sma200_slope=0.5)
        self.assertIn(label, ("Uptrend", "Neutral"))  # scored, not binary-rejected to Downtrend

    def test_insufficient_data(self):
        label, reasons = classify_trend(None, None, None, None)
        self.assertIn("insufficient", label.lower())


class TestVolumeTrend(unittest.TestCase):
    def test_increasing(self):
        self.assertEqual(classify_volume_trend(pd.Series([1]), 130, 100), "Increasing")

    def test_decreasing(self):
        self.assertEqual(classify_volume_trend(pd.Series([1]), 70, 100), "Decreasing")

    def test_flat(self):
        self.assertEqual(classify_volume_trend(pd.Series([1]), 105, 100), "Flat")

    def test_none_when_missing_data(self):
        self.assertIsNone(classify_volume_trend(pd.Series([1]), None, 100))


class TestSupportResistance(unittest.TestCase):
    def test_support_below_resistance_above_current_price(self):
        n = 60
        rng = np.random.default_rng(5)
        closes = 100 + rng.normal(0, 3, n).cumsum()
        closes = closes - closes.min() + 50  # keep positive
        df = make_bars(list(closes))
        swing_high, swing_low = find_swing_points(df["high"], df["low"], window=2)
        current_price = float(df["close"].iloc[-1])
        sl, sh, rl, rh = compute_support_resistance(
            df, swing_high, swing_low, sma50=None, sma200=None,
            high_20d=None, low_20d=None, high_50d=None, low_50d=None,
            current_price=current_price, atr=2.0,
        )
        if sl is not None:
            self.assertLessEqual(sh, current_price)
        if rl is not None:
            self.assertGreaterEqual(rl, current_price)

    def test_zone_is_a_range_not_single_point_when_only_one_level(self):
        df = make_bars([100.0] * 10)
        swing_high = pd.Series([False] * 10)
        swing_low = pd.Series([False] * 10)
        sl, sh, rl, rh = compute_support_resistance(
            df, swing_high, swing_low, sma50=90.0, sma200=None,
            high_20d=None, low_20d=None, high_50d=None, low_50d=None,
            current_price=100.0, atr=2.0,
        )
        self.assertIsNotNone(sl)
        self.assertNotEqual(sl, sh)  # widened into a real range via ATR, not a single price


class TestComputeReturns(unittest.TestCase):
    def test_known_percentage_return(self):
        closes = pd.Series([100.0] * 20 + [110.0])  # 21 bars, last vs 5-bars-ago = 100 -> 110
        returns = compute_returns(closes, periods=(5,))
        self.assertAlmostEqual(returns[5], 10.0, places=4)

    def test_none_when_not_enough_bars(self):
        closes = pd.Series([100.0, 101.0, 102.0])
        returns = compute_returns(closes, periods=(200,))
        self.assertIsNone(returns[200])


class TestComputeAllIndicators(unittest.TestCase):
    def test_full_pipeline_runs_and_returns_expected_keys(self):
        rng = np.random.default_rng(11)
        n = 300
        closes = 100 + rng.normal(0.05, 1.5, n).cumsum()
        closes = closes - closes.min() + 50
        df = make_bars(list(closes))
        result = compute_all_indicators(df)

        for key in ("rsi14", "macd", "atr14", "sma200", "trend_label", "support_low",
                    "resistance_low", "bars_used", "warnings"):
            self.assertIn(key, result)

        self.assertEqual(result["bars_used"], n)
        self.assertEqual(result["warnings"], [])  # plenty of bars, no warnings expected
        self.assertIsInstance(json.loads(result["trend_reasons"]), list)
        self.assertTrue(0 <= result["rsi14"] <= 100)

    def test_short_history_produces_warnings_not_crash(self):
        df = make_bars([100.0 + i for i in range(10)])
        result = compute_all_indicators(df)
        self.assertEqual(result["bars_used"], 10)
        self.assertTrue(len(result["warnings"]) > 0)
        self.assertIsNone(result["sma200"])  # correctly absent, not fabricated

    def test_missing_columns_raises(self):
        df = pd.DataFrame({"ts": [1], "open": [1], "close": [1]})
        with self.assertRaises(ValueError):
            compute_all_indicators(df)

    def test_empty_dataframe(self):
        df = make_bars([])
        result = compute_all_indicators(df)
        self.assertEqual(result["bars_used"], 0)


if __name__ == "__main__":
    unittest.main()
