"""
Which share count is ENTITLED to stand behind a valuation, and what must be said about it.

THE FAILURE THESE TESTS ENCODE. Regeneron was valued on a cover-page share count of 93,955,110
from a document filed in July 2012. Its real count in 2026 is about 104.8 million. The market
capitalisation came out roughly 10% too small — and that is the entire difficulty, because 10%
too small is not absurd. The price/earnings ratio read 16.8 instead of 18.4. Every plausibility
bound passed. Both share-count anomaly checks stayed silent. Nothing looked wrong, and nothing
was going to.

The Booking defect was the easy version of the same thing: a basis so wrong it produced a P/E of
1.20, which cannot be true and was therefore caught by a check on the ANSWER. A count wrong by a
believable margin produces a believable answer, so no threshold on the output will ever find it.
It has to be caught on the INPUT.

So these tests are not "is the market capitalisation about right". They are "was this share count
allowed to be used at all, and does every figure built on it say what it rests on" — which is a
different question, and the only one that would have caught Regeneron.

NOT ONE TEST MENTIONS REGENERON'S TICKER IN AN ASSERTION. The defect is generic and the fix is
generic; the fixtures below are shaped like the real cases (a quarterly filer, an annual foreign
filer, a company whose cover-page facts went dimensional) rather than named after them.
"""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
from config import STOCK_UNIVERSE  # noqa: E402
from providers.edgar_concepts import HISTORY_VALUE_FIELDS  # noqa: E402
from providers.fundamentals_base import AnnualPeriod  # noqa: E402
from services import data_validation_service as dv  # noqa: E402
from services import fundamentals_history_service as fh  # noqa: E402
from services import share_basis as sb  # noqa: E402

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"

TODAY = date.today()


def ago(days: int) -> str:
    return (TODAY - timedelta(days=days)).isoformat()


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]))
    conn.commit()
    return conn


def period(period_end, filed, ticker="REGN", currency="USD", **values):
    full = {f: None for f in HISTORY_VALUE_FIELDS}
    full.update(values)
    return AnnualPeriod(ticker=ticker, source="test", period_end=period_end, filed=filed,
                        taxonomy="us-gaap", currency=currency, form="10-K", values=full)


#: Shaped on Regeneron's real FY2025 figures. `shares_outstanding` is deliberately absent — that
#: is the actual condition: every non-dimensional share-count concept for this company stopped in
#: late 2012, so the annual history genuinely carries no count.
def company_with_no_current_count(db, ticker="REGN", filed=None, currency="USD"):
    filed = filed or ago(195)
    rows = [
        period(ago(230), filed, ticker=ticker, currency=currency,
               revenue=14_342.9e6, gross_profit=11_910e6, operating_income=5_786e6,
               net_income=4_504.9e6, eps_diluted=41.48, basic_shares=104.6e6,
               diluted_shares=108.6e6, operating_cash_flow=5_100e6, capex=900e6,
               total_assets=38_000e6, stockholders_equity=28_000e6, total_debt=2_700e6,
               total_cash=2_000e6, rnd_expense=5_100e6, buybacks=2_200e6,
               depreciation_amortisation=700e6),
        period(ago(595), filed, ticker=ticker, currency=currency,
               revenue=14_202e6, net_income=4_412.6e6, basic_shares=107.9e6,
               diluted_shares=115.1e6, total_assets=35_500e6),
    ]
    for r in rows:
        r.ticker = ticker
    fh.store_history(db, ticker, rows)
    return db


def quarterly_filer(db, ticker="AAPL", cover_age=40):
    """An ordinary US quarterly filer: a 10-K plus a more recent 10-Q cover page."""
    rows = [period(ago(230), ago(190), ticker=ticker, revenue=400e9, gross_profit=184e9,
                   operating_income=123e9, net_income=100e9, eps_diluted=6.5,
                   basic_shares=15.2e9, diluted_shares=15.4e9, shares_outstanding=15.0e9,
                   operating_cash_flow=118e9, capex=11e9, total_assets=365e9,
                   stockholders_equity=57e9, total_debt=95e9, total_cash=30e9,
                   depreciation_amortisation=11e9)]
    for r in rows:
        r.ticker = ticker
    fh.store_history(db, ticker, rows)
    fh.store_share_counts(db, ticker, [
        {"as_of": ago(cover_age + 8), "filed": ago(cover_age), "form": "10-Q",
         "shares": 14_800_000_000},
        {"as_of": ago(cover_age + 98), "filed": ago(cover_age + 90), "form": "10-Q",
         "shares": 14_900_000_000},
        {"as_of": ago(200), "filed": ago(190), "form": "10-K", "shares": 15_000_000_000},
    ])
    return db


# =================================================================================================
# THE RULE ITSELF, TESTED WITHOUT A DATABASE
# =================================================================================================
class TheCadenceRelativeRule(unittest.TestCase):
    """The primary test is not an age. It is "did this app already know about a newer filing"."""

    def test_a_count_from_the_newest_filing_is_actual(self):
        out = sb.resolve(
            cover_count={"shares": 500e6, "filed": ago(40), "as_of": ago(48), "form": "10-Q"},
            latest_row={"filed": ago(190), "shares_outstanding": 490e6},
            filed_dates=[ago(40), ago(130), ago(190)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.ACTUAL)
        self.assertEqual(out["shares"], 500e6)

    def test_a_count_older_than_a_filing_we_already_hold_is_refused(self):
        """THE REGENERON CASE, GENERICALLY. A cover-page count from a document filed years ago,
        while this app is holding a filing from six months ago for the same company. Nothing about
        the count's own age decides it — the newer filing does."""
        out = sb.resolve(
            cover_count={"shares": 93_955_110, "filed": "2012-07-25", "as_of": "2012-07-13",
                         "form": "10-Q"},
            latest_row={"filed": ago(195), "basic_shares": 104.6e6, "diluted_shares": 108.6e6},
            filed_dates=[ago(195), ago(560), "2012-07-25"], reference_date=ago(0))
        self.assertNotEqual(out["provenance"], sb.ACTUAL)
        rejected = [r for r in out["rejected"] if r["shares"] == 93_955_110]
        self.assertEqual(len(rejected), 1)
        self.assertIn("more recent filing", rejected[0]["why"])

    def test_the_filing_before_the_newest_still_qualifies(self):
        """Two filings of latitude, because the cover-page store and the annual history fill up
        from different documents. One filing of lag must not cost a company its valuation."""
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(130), "shares_outstanding": 490e6},
            filed_dates=[ago(40), ago(130), ago(220)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.ACTUAL_ANNUAL)

    def test_three_filings_back_does_not_qualify(self):
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(220), "shares_outstanding": 490e6},
            filed_dates=[ago(40), ago(130), ago(220)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.UNKNOWN)


class TheAgeBackstops(unittest.TestCase):
    """Underneath the cadence rule, and derived from the filing calendar rather than chosen."""

    def test_a_quarterly_source_is_capped_at_two_hundred_days(self):
        out = sb.resolve(
            cover_count={"shares": 500e6, "filed": ago(210), "as_of": ago(218), "form": "10-Q"},
            latest_row={"filed": ago(400), "shares_outstanding": 490e6},
            filed_dates=[ago(210), ago(300), ago(390)], reference_date=ago(0))
        self.assertEqual(out["cadence"]["cadence"], sb.QUARTERLY)
        self.assertEqual(out["provenance"], sb.UNKNOWN)
        self.assertIn("200-day", out["rejected"][0]["why"])

    def test_an_annual_source_is_allowed_four_hundred_and_fifty_days(self):
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(210), "shares_outstanding": 490e6},
            filed_dates=[ago(210), ago(575), ago(940)], reference_date=ago(0))
        self.assertEqual(out["cadence"]["cadence"], sb.ANNUAL)
        self.assertEqual(out["provenance"], sb.ACTUAL_ANNUAL)

    def test_even_the_newest_filing_is_refused_once_it_passes_the_annual_backstop(self):
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(500), "shares_outstanding": 490e6},
            filed_dates=[ago(500), ago(870)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.UNKNOWN)
        self.assertIn("450-day", out["rejected"][0]["why"])

    def test_cadence_is_measured_from_filings_actually_held_not_assumed(self):
        """Alphabet's cover-page count is absent from companyfacts entirely, so this app only
        ever sees its annual figure. Judging it by a quarterly rule would withhold its market
        capitalisation for half of every year over a data gap rather than a data problem."""
        cadence = sb.measure_cadence([ago(190), ago(555), ago(920)], ago(0))
        self.assertEqual(cadence["cadence"], sb.ANNUAL)
        self.assertEqual(cadence["max_age_days"], sb.ANNUAL_MAX_AGE_DAYS)

    def test_a_single_known_filing_gets_the_annual_allowance_not_the_strict_one(self):
        """No rhythm can be measured from one point. The conservative choice is the one that does
        not withhold a figure over an ABSENCE of evidence."""
        cadence = sb.measure_cadence([ago(190)], ago(0))
        self.assertEqual(cadence["cadence"], sb.ANNUAL)
        self.assertIsNone(cadence["median_gap_days"])

    def test_one_odd_gap_cannot_move_the_answer(self):
        """The median, not the mean: an amended filing days after the original is common and must
        not reclassify an annual filer as quarterly."""
        cadence = sb.measure_cadence([ago(188), ago(190), ago(555), ago(920)], ago(0))
        self.assertEqual(cadence["cadence"], sb.ANNUAL)


class TheFallbackOrder(unittest.TestCase):
    """Basic before diluted, and both labelled as estimates."""

    def test_basic_shares_are_preferred_over_diluted(self):
        """Diluted deliberately counts shares that do not exist yet — options, restricted stock,
        convertibles. That is the right denominator for earnings per share and the wrong one for
        a market capitalisation, because those shares cannot be bought.

        Measured against Regeneron's real count of 104,839,032: basic is out by 0.23%, diluted by
        3.6%. Fifteen times the error, for the sake of using the more familiar figure."""
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(195), "basic_shares": 104.6e6, "diluted_shares": 108.6e6},
            filed_dates=[ago(195), ago(560)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.ESTIMATED)
        self.assertEqual(out["shares"], 104.6e6)
        self.assertIn("basic", out["label"])

    def test_diluted_is_used_only_when_basic_is_absent_and_says_which(self):
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(195), "diluted_shares": 108.6e6},
            filed_dates=[ago(195), ago(560)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.ESTIMATED)
        self.assertEqual(out["shares"], 108.6e6)
        self.assertIn("diluted", out["label"])

    def test_an_actual_count_always_beats_an_estimate(self):
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(195), "shares_outstanding": 103.0e6,
                        "basic_shares": 104.6e6, "diluted_shares": 108.6e6},
            filed_dates=[ago(195), ago(560)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.ACTUAL_ANNUAL)
        self.assertEqual(out["shares"], 103.0e6)

    def test_the_estimate_faces_the_same_freshness_test_as_a_count(self):
        """Letting the fallback in unchecked would rebuild the defect one level down: an estimate
        from a filing this app should have superseded is no more usable than a count from one."""
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(900), "basic_shares": 104.6e6},
            filed_dates=[ago(190), ago(545), ago(900)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.UNKNOWN)

    def test_nothing_at_all_is_unknown_and_says_so_plainly(self):
        out = sb.resolve(cover_count=None, latest_row={"filed": ago(190)},
                         filed_dates=[ago(190)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.UNKNOWN)
        self.assertIsNone(out["shares"])
        self.assertIn("no share count", out["reason"])

    def test_a_zero_or_negative_count_is_not_a_count(self):
        out = sb.resolve(cover_count={"shares": 0, "filed": ago(40), "form": "10-Q"},
                         latest_row={"filed": ago(190), "basic_shares": 104.6e6},
                         filed_dates=[ago(40), ago(190)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.ESTIMATED)


# =================================================================================================
# END TO END, THROUGH THE VALIDATOR
# =================================================================================================
class TheRequiredValidationCases(unittest.TestCase):
    """Every case named in the build instruction, each as its own test."""

    def test_a_recent_actual_basis_is_actual_and_unchanged(self):
        out = dv.validate_ticker(quarterly_filer(make_db()), "AAPL", price=230.0)
        self.assertEqual(out["share_basis_provenance"], sb.ACTUAL)
        self.assertEqual(out["share_count"], 14_800_000_000)
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.OK)

    def test_a_one_quarter_old_actual_basis_still_qualifies(self):
        """Ordinary and correct: the newest cover page is a quarter old right before the next
        report lands. It draws a staleness WARNING and keeps its valuation."""
        out = dv.validate_ticker(quarterly_filer(make_db(), cover_age=130), "AAPL", price=230.0)
        self.assertEqual(out["share_basis_provenance"], sb.ACTUAL)
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.OK)

    def test_a_legitimate_annual_foreign_filer_is_not_blocked(self):
        """ASML and Novo file annually. A count 190 days old is their reporting cadence, not
        staleness, and a flat quarterly threshold would have blocked both."""
        db = make_db()
        rows = [period(ago(230), ago(190), ticker="ASML", currency="EUR", revenue=28e9,
                       net_income=7.6e9, shares_outstanding=393e6, basic_shares=394e6,
                       diluted_shares=395e6, total_assets=40e9, stockholders_equity=13e9),
                period(ago(595), ago(555), ticker="ASML", currency="EUR", revenue=27e9,
                       net_income=7.8e9, shares_outstanding=396e6)]
        for r in rows:
            r.ticker = "ASML"
        fh.store_history(db, "ASML", rows)
        out = dv.validate_ticker(db, "ASML", price=900.0)
        self.assertEqual(out["share_basis_provenance"], sb.ACTUAL_ANNUAL)
        # The market cap is still withheld — but for the CURRENCY, which is the pre-existing and
        # correct reason. The share basis must not be blamed for it.
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.UNAVAILABLE)
        self.assertIn("USD", out["metrics"]["market_cap"]["reason"])

    def test_an_extremely_stale_basis_cannot_feed_a_valuation(self):
        """The 2012 count, generically: it is refused, and the estimate takes its place."""
        db = company_with_no_current_count(make_db())
        fh.store_share_counts(db, "REGN", [
            {"as_of": "2012-07-13", "filed": "2012-07-25", "form": "10-Q", "shares": 93_955_110}])
        out = dv.validate_ticker(db, "REGN", price=806.0)
        self.assertNotEqual(out["share_count"], 93_955_110)
        self.assertEqual(out["share_basis_provenance"], sb.ESTIMATED)
        self.assertEqual(out["share_count"], 104.6e6)

    def test_the_stale_count_is_named_in_the_rejected_list_rather_than_vanishing(self):
        """"Why is this company's number different" must be answerable from the result, not by
        re-running anything."""
        db = company_with_no_current_count(make_db())
        fh.store_share_counts(db, "REGN", [
            {"as_of": "2012-07-13", "filed": "2012-07-25", "form": "10-Q", "shares": 93_955_110}])
        detail = dv.validate_ticker(db, "REGN", price=806.0)["share_basis_detail"]
        self.assertTrue(any(r["shares"] == 93_955_110 for r in detail["rejected"]))

    def test_no_valid_fallback_gives_unknown_and_withholds_the_market_cap(self):
        db = make_db()
        rows = [period(ago(230), ago(900), ticker="CRWD", revenue=4e9, net_income=400e6,
                       basic_shares=250e6, diluted_shares=254e6, total_assets=8e9,
                       stockholders_equity=3e9, operating_cash_flow=1.2e9, capex=200e6)]
        for r in rows:
            r.ticker = "CRWD"
        fh.store_history(db, "CRWD", rows)
        fh.store_share_counts(db, "CRWD", [
            {"as_of": ago(600), "filed": ago(590), "form": "10-Q", "shares": 240e6}])
        out = dv.validate_ticker(db, "CRWD", price=400.0)
        self.assertEqual(out["share_basis_provenance"], sb.UNKNOWN)
        self.assertIsNone(out["share_count"])
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.UNAVAILABLE)

    def test_a_multi_class_company_uses_the_aggregate_it_reports(self):
        """Alphabet's three classes are reported as one aggregate figure — 12.088bn against a
        cover page totalling 12.23bn. Nothing here sums classes or infers one; the aggregate is
        taken as filed, which is why no double-counting is possible."""
        db = make_db()
        rows = [period(ago(230), ago(190), ticker="GOOGL", revenue=400e9, net_income=132.17e9,
                       shares_outstanding=12.088e9, diluted_shares=12.23e9, basic_shares=12.1e9,
                       total_assets=500e9, stockholders_equity=350e9, eps_diluted=10.8)]
        for r in rows:
            r.ticker = "GOOGL"
        fh.store_history(db, "GOOGL", rows)
        out = dv.validate_ticker(db, "GOOGL", price=250.0)
        self.assertEqual(out["share_basis_provenance"], sb.ACTUAL_ANNUAL)
        self.assertEqual(out["share_count"], 12.088e9)

    def test_a_corporate_action_between_filing_and_price_is_still_caught(self):
        """The Booking case must keep working: a fresh-but-superseded basis produces an absurd
        P/E, and the existing coherence check withholds every price-based figure. The new
        freshness rule sits in front of that check and must not disarm it."""
        db = make_db()
        rows = [period(ago(200), ago(180), ticker="BKNG", revenue=26_917e6,
                       operating_income=8_825e6, net_income=5_404e6, eps_diluted=165.57,
                       diluted_shares=32.639e6, shares_outstanding=31_673_346,
                       total_assets=29_264e6, stockholders_equity=-5_578e6,
                       operating_cash_flow=9_409e6, capex=322e6)]
        for r in rows:
            r.ticker = "BKNG"
        fh.store_history(db, "BKNG", rows)
        out = dv.validate_ticker(db, "BKNG", price=204.72)
        self.assertEqual(out["share_basis_provenance"], sb.ACTUAL_ANNUAL)
        self.assertFalse(out["price_metrics_reliable"])
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.UNAVAILABLE)

    def test_a_historical_calculation_judges_freshness_at_the_simulated_date(self):
        """LOOK-AHEAD IN REVERSE, AND JUST AS WRONG. A 2019 valuation must ask whether the count
        was current IN 2019. Judging it against today would mark every filing in a backtest stale
        and return UNKNOWN for the whole history — which would look like the rule working and
        would be the rule inverted."""
        db = make_db()
        rows = [period("2019-12-31", "2020-02-10", ticker="AAPL", revenue=260e9,
                       net_income=55e9, shares_outstanding=4.4e9, basic_shares=4.45e9,
                       diluted_shares=4.5e9, eps_diluted=11.89, total_assets=338e9,
                       stockholders_equity=90e9),
                period("2018-12-31", "2019-02-10", ticker="AAPL", revenue=265e9,
                       net_income=59e9, shares_outstanding=4.7e9)]
        for r in rows:
            r.ticker = "AAPL"
        fh.store_history(db, "AAPL", rows)
        out = dv.validate_ticker(db, "AAPL", price=75.0, as_of_filed="2020-04-01")
        # The BASIS still resolves correctly at the simulated date — that is what this test is
        # about, and it is the thing that would break if freshness were judged against today.
        self.assertEqual(out["share_basis_provenance"], sb.ACTUAL_ANNUAL)
        self.assertEqual(out["share_basis_detail"]["shares"], 4.4e9)
        # The market capitalisation is nevertheless withheld, for a separate reason belonging to
        # the PRICE rather than the count: stored bars are adjusted, so a 2020 bar is expressed in
        # today's share basis. See the historical note on the result.
        self.assertTrue(out["historical_valuation_blocked"])
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.UNAVAILABLE)

    def test_a_historical_calculation_cannot_see_a_filing_published_later(self):
        """The freshness test must not become a route for future information: the count that
        disqualifies an older one has to have existed at the simulated date too."""
        db = make_db()
        rows = [period("2019-12-31", "2020-02-10", ticker="AAPL", revenue=260e9, net_income=55e9,
                       shares_outstanding=4.4e9, total_assets=338e9, stockholders_equity=90e9)]
        for r in rows:
            r.ticker = "AAPL"
        fh.store_history(db, "AAPL", rows)
        fh.store_share_counts(db, "AAPL", [
            {"as_of": "2026-06-30", "filed": "2026-07-30", "form": "10-Q", "shares": 15e9}])
        out = dv.validate_ticker(db, "AAPL", price=75.0, as_of_filed="2020-04-01")
        self.assertEqual(out["share_basis_detail"]["shares"], 4.4e9)
        self.assertNotIn("2026", str(out["share_basis_detail"]["accepted_filings"]))

    def test_stale_data_producing_a_plausible_pe_is_still_refused(self):
        """THE CASE THAT DEFINES THIS WORK. The basis is wrong by about 10%, so the P/E lands at
        a completely ordinary 17 and no check on the answer can object. The count is refused on
        its provenance instead, before any figure is built from it."""
        db = company_with_no_current_count(make_db())
        fh.store_share_counts(db, "REGN", [
            {"as_of": "2012-07-13", "filed": "2012-07-25", "form": "10-Q", "shares": 93_955_110}])
        out = dv.validate_ticker(db, "REGN", price=806.0)
        stale_cap = 93_955_110 * 806.0
        stale_pe = stale_cap / 4_504.9e6
        self.assertTrue(3 < stale_pe < 40, "the fixture must produce a BELIEVABLE P/E, not an "
                                           "absurd one — otherwise it tests the easy case")
        self.assertNotEqual(out["metrics"]["market_cap"]["value"], stale_cap)
        self.assertEqual(out["metrics"]["market_cap"]["share_basis"], sb.ESTIMATED)


class DependentMetricsCannotBypassTheBlock(unittest.TestCase):
    """The requirement stated as a test: nothing downstream may reach around an unusable basis."""

    def _blocked(self):
        db = make_db()
        rows = [period(ago(230), ago(900), ticker="NET", revenue=2e9, gross_profit=1.5e9,
                       net_income=100e6, operating_income=150e6, eps_diluted=0.3,
                       basic_shares=340e6, diluted_shares=350e6, operating_cash_flow=500e6,
                       capex=100e6, total_assets=5e9, current_assets=3e9,
                       current_liabilities=1e9, stockholders_equity=1e9, total_debt=2e9,
                       total_cash=1.5e9, depreciation_amortisation=200e6, interest_expense=50e6,
                       buybacks=50e6, dividends_paid=10e6)]
        for r in rows:
            r.ticker = "NET"
        fh.store_history(db, "NET", rows)
        return dv.validate_ticker(db, "NET", price=200.0)

    def test_every_market_cap_dependent_metric_is_unavailable(self):
        out = self._blocked()
        self.assertEqual(out["share_basis_provenance"], sb.UNKNOWN)
        for name in dv.MARKET_CAP_DEPENDENT:
            self.assertEqual(out["metrics"][name]["verdict"], dv.UNAVAILABLE, name)
            self.assertIsNone(out["metrics"][name]["value"], name)

    def test_the_block_is_structural_not_a_list_that_can_drift(self):
        """`shares` is None, so there is nothing left for a metric to bypass the block WITH. A
        new price-based metric added later inherits the block by construction rather than by
        someone remembering to add its name to a list."""
        self.assertIsNone(self._blocked()["share_count"])

    def test_the_reason_names_the_share_basis_rather_than_blaming_the_price(self):
        reason = self._blocked()["metrics"]["market_cap"]["reason"]
        self.assertIn("share count", reason)
        self.assertNotIn("no share price available", reason)

    def test_company_health_is_untouched_by_an_unusable_share_basis(self):
        """The whole point of separating them. Margins, returns, cash flow and the balance sheet
        are ratios of one fundamental to another and never touch a share count."""
        out = self._blocked()
        for name in ("gross_margin_pct", "operating_margin_pct", "net_margin_pct", "roe_pct",
                     "roa_pct", "fcf_margin_pct", "ocf_to_net_income", "current_ratio"):
            self.assertNotEqual(out["metrics"][name]["verdict"], dv.UNAVAILABLE, name)
        self.assertGreater(out["company_health_coverage_pct"], 40)

    def test_company_health_no_longer_overlaps_with_market_cap_at_all(self):
        """C1 CLOSED THIS COMPLETELY, and the history is the reason the test stays.

        Capital allocation used to score buyback YIELD and dividend YIELD, both of which divide by
        market capitalisation — so when one company's market capitalisation became UNKNOWN it lost
        two of its three capital-allocation inputs for a reason that had nothing to do with how it
        allocates capital. C1 replaced them with share dilution and whether distributions are
        funded by free cash flow, neither of which touches a price.

        The assertion is now EMPTY rather than a named pair. A price-based metric added to any
        Company Health category fails here.
        """
        health_inputs = {i for _, inputs in dv.COMPANY_HEALTH_CATEGORIES.values() for i in inputs}
        self.assertEqual(health_inputs & set(dv.MARKET_CAP_DEPENDENT), set())

    def test_an_estimated_basis_costs_company_health_nothing_at_all(self):
        """The distinction that keeps the cost small in practice. An estimate still produces a
        market capitalisation, so the yields still compute and capital allocation is untouched.
        Only a wholly unusable basis reaches Company Health."""
        db = company_with_no_current_count(make_db())
        out = dv.validate_ticker(db, "REGN", price=806.0)
        self.assertEqual(out["share_basis_provenance"], sb.ESTIMATED)
        cap_alloc = out["company_health_categories"]["capital_allocation"]
        self.assertNotIn("buyback_yield_pct", cap_alloc["missing"])


class TheProvenanceTravelsWithTheNumber(unittest.TestCase):
    """A provenance that stays on the share count and never reaches the metrics is one nobody
    reads. Regeneron's market capitalisation was wrong for years while the sentence describing its
    share count sat one level up in the same payload, correct and unread."""

    def _estimated(self):
        db = company_with_no_current_count(make_db())
        return dv.validate_ticker(db, "REGN", price=806.0)

    def test_every_dependent_metric_carries_the_provenance(self):
        m = self._estimated()["metrics"]
        for name in dv.MARKET_CAP_DEPENDENT:
            self.assertEqual(m[name]["share_basis"], sb.ESTIMATED, name)

    def test_an_estimated_figure_is_derived_rather_than_ok(self):
        m = self._estimated()["metrics"]
        self.assertEqual(m["market_cap"]["verdict"], dv.DERIVED)
        self.assertIn("ESTIMATED SHARE BASIS", m["market_cap"]["reason"])

    def test_an_estimate_still_counts_toward_coverage(self):
        """DERIVED is usable. An honest approximation is worth more than a gap, provided it is
        labelled — the failure being fixed was a silent estimate, not an estimate."""
        self.assertIn(dv.DERIVED, dv.USABLE)
        self.assertGreater(self._estimated()["valuation_coverage_pct"], 0)

    def test_an_actual_basis_is_not_relabelled_as_derived(self):
        m = dv.validate_ticker(quarterly_filer(make_db()), "AAPL", price=230.0)["metrics"]
        self.assertEqual(m["market_cap"]["verdict"], dv.OK)
        self.assertEqual(m["market_cap"]["share_basis"], sb.ACTUAL)

    def test_an_impossible_figure_is_not_laundered_into_derived_by_a_label(self):
        """A number that could not be true does not become acceptable by being labelled. If an
        IMPLAUSIBLE verdict were relabelled DERIVED it would enter coverage as usable — a bug
        hidden behind a caveat."""
        db = company_with_no_current_count(make_db(), ticker="REGN")
        out = dv.validate_ticker(db, "REGN", price=806.0)
        for name in dv.MARKET_CAP_DEPENDENT:
            if out["metrics"][name]["verdict"] == dv.IMPLAUSIBLE:
                self.assertNotIn(name, [n for n in out["metrics"]
                                        if out["metrics"][n]["verdict"] == dv.DERIVED])

    def test_the_note_states_the_estimate_in_words_a_person_can_act_on(self):
        note = " ".join(self._estimated()["notes"])
        self.assertIn("ESTIMATED SHARE BASIS", note)
        self.assertIn("not current shares outstanding", note)

    def test_the_pe_says_it_could_not_be_cross_checked_when_the_basis_is_unknown(self):
        db = make_db()
        rows = [period(ago(230), ago(900), ticker="NET", revenue=2e9, net_income=100e6,
                       eps_diluted=0.3, total_assets=5e9, stockholders_equity=1e9)]
        for r in rows:
            r.ticker = "NET"
        fh.store_history(db, "NET", rows)
        pe = dv.validate_ticker(db, "NET", price=200.0)["metrics"]["pe_ratio"]
        self.assertEqual(pe["share_basis"], sb.UNKNOWN)
        if pe["value"] is not None:
            self.assertIn("cross-check", pe["reason"])


class TheRunLevelReport(unittest.TestCase):
    """The universe-wide answer has to be a tally. One company quietly dropping to an estimate is
    invisible in a mean."""

    def test_the_summary_counts_every_basis(self):
        results = [
            {"ticker": "AAPL", "share_basis_provenance": sb.ACTUAL,
             "share_basis_detail": {"age_days": 40}},
            {"ticker": "GOOGL", "share_basis_provenance": sb.ACTUAL_ANNUAL,
             "share_basis_detail": {"age_days": 194}},
            {"ticker": "REGN", "share_basis_provenance": sb.ESTIMATED,
             "share_basis_detail": {"age_days": 195}},
            {"ticker": "XXXX", "share_basis_provenance": sb.UNKNOWN,
             "share_basis_detail": {"age_days": None}},
        ]
        s = dv.summarise(results)
        self.assertEqual(s["share_basis_counts"],
                         {sb.ACTUAL: 1, sb.ACTUAL_ANNUAL: 1, sb.ESTIMATED: 1, sb.UNKNOWN: 1})
        self.assertEqual(s["share_basis_hard_blocked"], ["XXXX"])
        self.assertEqual(s["share_basis_tickers"][sb.ESTIMATED], ["REGN"])


if __name__ == "__main__":
    unittest.main()
