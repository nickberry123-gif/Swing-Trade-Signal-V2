"""
The two bullish setups: Retracement and Base Breakout.

Three things these tests exist to guarantee, in order of importance:

1. LONG-ONLY. No short signal can be produced by any input, including a stock in a clean
   downtrend. Bearish must mean NO SETUP.
2. NO LOOK-AHEAD. A setup detected at bar i must be decided from bars 0..i only, and entered at
   bar i+1's open. The decisive test truncates the future and requires an identical answer.
3. UNKNOWN IS NOT PASS AND NOT FAIL. Five of the strategy's criteria cannot be computed from this
   data. They must be excluded from the score's denominator, never silently counted.
"""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import bullish_setup_service as bs


def bars(closes, start=date(2020, 1, 1), volume=5_000_000, highs=None, lows=None):
    ts, d = [], start
    while len(ts) < len(closes):
        if d.weekday() < 5 and (d.month, d.day) not in {(1, 1), (12, 25)}:
            ts.append(d.isoformat())
        d += timedelta(days=1)
    c = np.asarray(closes, dtype="float64")
    return pd.DataFrame({
        "ts": ts, "open": c, "close": c,
        "high": c * 1.01 if highs is None else np.asarray(highs, dtype="float64"),
        "low": c * 0.99 if lows is None else np.asarray(lows, dtype="float64"),
        "volume": [float(volume)] * len(c)})


def uptrend_with_pullback():
    """A textbook retracement: long uptrend, impulse, three lower closes, a flat bar at the MAs."""
    return np.concatenate([
        np.linspace(50, 120, 400),                 # established trend, MAs rising and stacked
        np.linspace(120, 138, 12),                 # impulse
        np.array([136.5, 134.0, 131.0, 131.2]),    # three lower closes, then near-flat
        np.linspace(131.5, 165, 120),
    ])


def clean_downtrend():
    return np.linspace(200, 40, 600)


class LongOnly(unittest.TestCase):
    """The single most important property of this module."""

    def test_a_downtrend_produces_no_setup_and_no_short(self):
        out = bs.simulate_ticker("DOWN", bars(clean_downtrend()), {"min_quality": "LOW"})
        self.assertEqual(out["trades"], [])
        for s in out["setups"]:
            self.assertIn("BULLISH", s["setup_type"])

    def test_the_fixture_really_is_bearish(self):
        """Guards against the test above passing because the fixture was too short to score."""
        df = bars(clean_downtrend())
        lv = bs.compute_levels(df)
        st = bs._structure(lv, len(df) - 2, bs.DEFAULTS)
        self.assertFalse(st["ema9_rising"])
        self.assertEqual(st["price_vs_sma200"], "BELOW")

    def test_no_setup_type_anywhere_is_bearish(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        for item in out["setups"] + out["trades"]:
            self.assertTrue(item["setup_type"].startswith("BULLISH_"), item["setup_type"])

    def test_every_stop_is_below_every_entry(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        self.assertTrue(out["trades"], "fixture produced no trade — nothing was proven")
        for t in out["trades"]:
            self.assertLess(t["stop_price"], t["entry_price"], "a long stop must be below entry")
            self.assertGreater(t["target_price"], t["entry_price"])
            self.assertGreater(t["position_size_shares"], 0)

    def test_the_module_contains_no_short_vocabulary(self):
        src = (Path(__file__).resolve().parent.parent
               / "services" / "bullish_setup_service.py").read_text().lower()
        for word in ("short_entry", "sell_short", "bearish_setup", "short_signal",
                     "go_short", "short_position"):
            self.assertNotIn(word, src, f"short-side vocabulary '{word}' appeared")

    def test_a_bearish_rejection_says_no_long_setup_not_short(self):
        rej = bs._rejections(
            {"both_mas_flat": False, "price_below_mas": True, "stacked_9_over_20": False,
             "overextended": False, "extension_atr": None},
            {"relative_volume": 1.2, "liquid_enough": True, "avg_volume50": 9_000_000},
            {"meets_min_rr": True, "stop_is_tight": True, "risk_reward": 3.0,
             "stop_distance_pct": 2.0},
            bs.DEFAULTS)
        self.assertTrue(any("NO LONG SETUP" in r for r in rej), rej)


class NoLookAhead(unittest.TestCase):

    def test_truncating_the_future_does_not_change_the_answer(self):
        """The decisive test. Detection at bar i must not read a single bar after i."""
        series = uptrend_with_pullback()
        full = bars(series)
        lv_full = bs.compute_levels(full)

        i = len(series) - 60
        with_future = bs.detect_retracement(lv_full, full, i, bs.DEFAULTS)

        truncated = bars(series[:i + 1])
        lv_trunc = bs.compute_levels(truncated)
        without_future = bs.detect_retracement(lv_trunc, truncated, i, bs.DEFAULTS)

        self.assertEqual(with_future is None, without_future is None)
        if with_future is not None:
            self.assertEqual(with_future["quality"], without_future["quality"])
            self.assertEqual(with_future["scored"]["score"], without_future["scored"]["score"])
            self.assertEqual(with_future["risk"]["entry_price"],
                             without_future["risk"]["entry_price"])

    def test_the_same_holds_for_the_base_breakout(self):
        series = uptrend_with_pullback()
        full = bars(series)
        i = len(series) - 60
        a = bs.detect_base_breakout(bs.compute_levels(full), full, i, bs.DEFAULTS)
        trunc = bars(series[:i + 1])
        b = bs.detect_base_breakout(bs.compute_levels(trunc), trunc, i, bs.DEFAULTS)
        self.assertEqual(a is None, b is None)
        if a is not None:
            self.assertEqual(a["scored"]["score"], b["scored"]["score"])

    def test_entry_is_the_next_bars_open_never_the_signal_bars_close(self):
        df = bars(uptrend_with_pullback())
        out = bs.simulate_ticker("UP", df, {"min_quality": "LOW"})
        self.assertTrue(out["trades"])
        for t in out["trades"]:
            detected_row = df.index[df["ts"] == t["detected_date"]][0]
            self.assertEqual(t["entry_index"], detected_row + 1)
            self.assertEqual(t["entry_price"], round(float(df["open"].iloc[detected_row + 1]), 4))
            self.assertGreater(t["entry_date"], t["detected_date"])

    def test_detection_and_entry_are_reported_separately(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        for t in out["trades"]:
            self.assertIn("detected_date", t)
            self.assertIn("entry_date", t)
            self.assertIn("exit_date", t)
            self.assertIn("exit_reason", t)


class UnknownIsNeitherPassNorFail(unittest.TestCase):

    def test_unknown_criteria_leave_the_denominator(self):
        scored = bs._score([("a", True, ""), ("b", False, ""), ("c", None, "no data")])
        self.assertEqual(scored["score"], 1)
        self.assertEqual(scored["score_out_of"], 2)      # not 3
        self.assertEqual(scored["score_pct"], 50.0)
        self.assertEqual(scored["unknown"], ["c"])
        self.assertEqual(scored["criteria_total"], 3)

    def test_an_all_unknown_setup_scores_nothing_rather_than_full_marks(self):
        scored = bs._score([("a", None, "x"), ("b", None, "y")])
        self.assertIsNone(scored["score_pct"])
        self.assertEqual(bs._quality(scored, [], bs.DEFAULTS), "INVALID")

    def test_the_five_unavailable_criteria_are_always_unknown(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        self.assertTrue(out["setups"])
        for s in out["setups"]:
            for key in ("catalyst_confirmed", "level_2_confirms", "premarket_momentum",
                        "time_of_day_window", "one_hour_trend"):
                self.assertIn(key, s["scored"]["unknown"])

    def test_catalyst_is_never_claimed_as_confirmed(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        for s in out["setups"]:
            self.assertEqual(s["momentum"]["catalyst"], "UNKNOWN")
            self.assertEqual(s["level_2"], "UNKNOWN")


class RetracementRules(unittest.TestCase):

    def test_a_textbook_retracement_is_detected(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        kinds = {s["setup_type"] for s in out["setups"]}
        self.assertIn("BULLISH_RETRACEMENT", kinds)

    def test_the_retracement_percentage_is_measured_and_reported(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        rets = [s for s in out["setups"] if s["setup_type"] == "BULLISH_RETRACEMENT"]
        self.assertTrue(rets)
        r = rets[0]["retracement"]
        self.assertIsInstance(r["retracement_pct"], float)
        self.assertGreaterEqual(r["red_candles"], 1)
        self.assertIn("impulse_pct", r)

    def test_a_shallow_retracement_fails_the_40_60_criterion(self):
        """A 10% dip is not the setup, however good the trend looks."""
        series = np.concatenate([np.linspace(50, 120, 400), np.linspace(120, 140, 12),
                                 np.array([139.0, 138.0, 137.5, 137.6]),
                                 np.linspace(138.0, 160, 60)])
        df = bars(series)
        lv = bs.compute_levels(df)
        found = None
        for i in range(bs.MIN_WARMUP, len(df) - 1):
            f = bs.detect_retracement(lv, df, i, bs.DEFAULTS)
            if f and f["retracement"]["retracement_pct"] < 30:
                found = f
                break
        if found:
            self.assertIn("retracement_40_60", found["scored"]["failed"])

    def test_the_reversal_candle_types_are_exactly_the_three_specified(self):
        doji = bars(np.array([100.0] * 300 + [100.0]),
                    highs=np.array([101.0] * 301), lows=np.array([99.0] * 301))
        lv = bs.compute_levels(doji)
        shape = bs._candle_shape(lv, 300, bs.DEFAULTS)
        self.assertIn("doji", shape["kinds"])
        for kind in shape["kinds"]:
            self.assertIn(kind, ("doji", "bottoming_tail", "narrow_range"))


class BaseBreakoutRules(unittest.TestCase):

    def test_a_breakout_requires_a_close_above_the_base_high(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        bases = [s for s in out["setups"] if s["setup_type"] == "BULLISH_BASE_BREAKOUT"]
        self.assertTrue(bases)
        for b in bases:
            self.assertGreater(b["base"]["breakout_price"], b["base"]["base_high"])

    def test_a_wide_chaotic_range_is_not_a_base(self):
        """A base must be tight. Violent swings around a mean are not consolidation."""
        noisy = 100 + np.random.default_rng(3).normal(0, 12, 400).cumsum() * 0
        noisy = 100 + np.tile([0, 18, -16, 15, -14], 80)      # ~30% swings, never tight
        df = bars(np.concatenate([np.linspace(40, 100, 300), noisy]))
        lv = bs.compute_levels(df)
        for i in range(bs.MIN_WARMUP, len(df) - 1):
            found = bs.detect_base_breakout(lv, df, i, bs.DEFAULTS)
            if found:
                self.assertLessEqual(found["base"]["base_width_pct"],
                                     bs.DEFAULTS["base_max_width_pct"])

    def test_the_base_is_fully_described(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        bases = [s for s in out["setups"] if s["setup_type"] == "BULLISH_BASE_BREAKOUT"]
        b = bases[0]["base"]
        for key in ("base_high", "base_low", "base_bars", "base_width_pct", "breakout_price"):
            self.assertIn(key, b)


class RiskAndSizing(unittest.TestCase):

    def test_position_size_matches_the_specified_arithmetic(self):
        """Entry 10.00, stop 9.90, $100 risk -> 1000 shares. Straight from the brief."""
        cfg = {**bs.DEFAULTS, "max_dollar_risk": 100.0}
        r = bs._risk_block(10.00, 9.90, 10.20, cfg)
        self.assertAlmostEqual(r["risk_per_share"], 0.10, places=4)
        self.assertEqual(r["position_size_shares"], 1000)
        self.assertAlmostEqual(r["max_dollar_loss"], 100.0, places=2)

    def test_below_two_to_one_is_rejected_as_invalid(self):
        cfg = {**bs.DEFAULTS, "min_rr": 2.0}
        r = bs._risk_block(100.0, 95.0, 105.0, cfg)          # 1:1
        self.assertFalse(r["meets_min_rr"])
        scored = bs._score([("risk_reward_2to1", False, "")])
        self.assertEqual(bs._quality(scored, ["R:R below minimum"], cfg), "INVALID")

    def test_exactly_two_to_one_is_accepted(self):
        """It read 'Risk/reward 2.0 is below the 2.0:1 minimum' — correct arithmetic, impossible
        sentence, caused by comparing an unrounded 1.9999999996 against the displayed 2.0."""
        cfg = {**bs.DEFAULTS, "min_rr": 2.0}
        entry, stop = 121.6364, 118.0424
        target = entry + (entry - stop) * 2.0
        r = bs._risk_block(entry, stop, target, cfg)
        self.assertEqual(r["risk_reward"], 2.0)
        self.assertTrue(r["meets_min_rr"],
                        "a setup showing exactly 2.0 was rejected for being below 2.0")

    def test_a_stop_above_entry_is_refused(self):
        r = bs._risk_block(100.0, 105.0, 110.0, bs.DEFAULTS)
        self.assertFalse(r["valid"])

    def test_the_dollar_cap_holds_at_the_actual_fill(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        for t in out["trades"]:
            self.assertLessEqual(t["max_dollar_loss"], bs.DEFAULTS["max_dollar_risk"] + 0.01)


class Outcomes(unittest.TestCase):

    def test_a_bar_spanning_stop_and_target_assumes_the_stop(self):
        """The intrabar path is unknown, so the pessimistic assumption is taken deliberately."""
        src = (Path(__file__).resolve().parent.parent
               / "services" / "bullish_setup_service.py").read_text()
        loop = src[src.index("# ---- manage an open position first"):]
        self.assertLess(loop.index("STOP_HIT"), loop.index("TARGET_HIT"))

    def test_every_trade_records_all_five_stages(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "LOW"})
        for t in out["trades"]:
            for key in ("detected_date", "entry_date", "exit_date", "exit_reason",
                        "dollar_result", "return_pct"):
                self.assertIn(key, t)

    def test_invalid_setups_are_recorded_but_never_entered(self):
        out = bs.simulate_ticker("UP", bars(uptrend_with_pullback()), {"min_quality": "HIGH"})
        entered = {t["detected_date"] for t in out["trades"]}
        for s in out["setups"]:
            if s["quality"] in ("INVALID", "LOW", "MEDIUM"):
                self.assertNotIn(s["detected_date"], entered)


class RunnerShape(unittest.TestCase):

    def setUp(self):
        self.result = bs.run_bullish_setup_test(
            {"AAA": bars(uptrend_with_pullback()), "BBB": bars(clean_downtrend())},
            ["AAA", "BBB"], {"min_quality": "LOW"})

    def test_the_result_declares_itself_long_only(self):
        self.assertTrue(self.result["config"]["long_only"])
        self.assertIn("LONG ONLY", self.result["config"]["rule"][0])

    def test_unavailable_criteria_are_published_with_reasons(self):
        for key in ("catalyst", "level_2", "premarket", "spread", "time_of_day",
                    "one_hour_trend"):
            self.assertIn(key, self.result["unavailable_criteria"])

    def test_the_timeframe_substitution_is_stated_first(self):
        self.assertIn("DAILY-BAR TRANSLATION", self.result["limitations"][0])

    def test_a_warning_names_the_unknown_criteria(self):
        self.assertTrue(any("UNKNOWN" in w for w in self.result["warnings"]))

    def test_results_are_broken_out_by_quality_and_type(self):
        for key in ("by_setup_type", "by_quality", "by_exit_reason", "setups_by_quality"):
            self.assertIn(key, self.result)


if __name__ == "__main__":
    unittest.main()


class PageWiring(unittest.TestCase):
    """A control the API accepts and no page sends, or a page that writes to an element that does
    not exist, has shipped from this project before. These assert the whole chain lines up."""

    def setUp(self):
        import app as app_module
        self.client = app_module.create_app().test_client()
        self.frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
        self.html = (self.frontend / "templates" / "pattern_test.html").read_text()
        self.js = (self.frontend / "static" / "js" / "pattern_test.js").read_text()

    def test_the_page_renders_and_is_in_the_nav(self):
        self.assertEqual(self.client.get("/pattern-test").status_code, 200)
        self.assertIn(b'href="/pattern-test"', self.client.get("/").data)

    def test_every_element_the_script_writes_to_exists(self):
        import re
        for element_id in re.findall(r'getElementById\("([^"]+)"\)', self.js):
            self.assertIn(f'id="{element_id}"', self.html,
                          f"{element_id} is written to by the script but absent from the page")

    def test_every_control_the_script_reads_reaches_the_router(self):
        router = (Path(__file__).resolve().parent.parent / "routers" / "api_pattern.py").read_text()
        for field in ("setup_types", "min_quality", "min_rr", "max_dollar_risk",
                      "retrace_min_pct", "retrace_max_pct", "min_red_candles",
                      "base_max_width_pct", "max_stop_pct", "min_avg_volume"):
            with self.subTest(field=field):
                self.assertIn(field, self.js, f"{field} is never sent by the page")
                self.assertIn(f'payload.get("{field}"', router,
                              f"{field} is sent by the page but ignored by the router")

    def test_the_page_states_the_timeframe_substitution_before_any_result(self):
        """The most important sentence on the page, and it must not be buried."""
        self.assertIn("swing-trading translation", self.html.lower())
        self.assertLess(self.html.lower().index("swing-trading translation"),
                        self.html.index('id="pt-results"'))

    def test_the_page_names_the_five_unknown_criteria(self):
        low = self.html.lower()
        for word in ("catalyst", "level", "pre-market", "spread", "time of day"):
            self.assertIn(word, low)

    def test_the_page_never_offers_a_short(self):
        low = (self.html + self.js).lower()
        for word in ("short setup", "short entry", "bearish setup", "sell short"):
            self.assertNotIn(word, low)
