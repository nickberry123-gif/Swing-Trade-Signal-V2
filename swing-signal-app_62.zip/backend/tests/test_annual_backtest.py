"""
Tests for the annual-reset backtesting framework.

The specification's central promise is that no trade may cross a calendar-year boundary. That is
easy to state and easy to get subtly wrong: closing at the FIRST bar of the new year instead of
the LAST bar of the old one still "resets" but settles the trade at next year's price, and every
number downstream would be wrong by an invisible amount.

The second thing under test is that the STRATEGY is unchanged. This is an evaluation change
only, so within a single year the annual framework must produce exactly the trades the
continuous one produces — anything else means a strategy rule was altered while nobody looked.
"""
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import database
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import annual_backtest_service as ab
from services import backtest_service as bt

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    conn.commit()
    return conn


def bars(n=1400, seed=0, start_date=datetime(2021, 1, 1)):
    """Bars spanning several calendar years, with pullbacks so entries occur.

    Weekends AND New Year's Day / Christmas are skipped. Without holidays the fixture happily
    produced a "first trading day" of 1 January, which no real market has — a test written
    against that would be asserting a property of the fixture rather than of the code.

    n is chosen so the series ends mid-year, which is what makes the final year genuinely
    partial and gives the partial-year flag something real to detect.
    """
    rng = np.random.default_rng(seed)
    trend = 100 + np.cumsum(0.2 + rng.normal(0, 1.6, n))
    closes = np.maximum(trend + 6.0 * np.sin(np.arange(n) * 2 * np.pi / 25), 1.0)
    ts, d = [], start_date
    while len(ts) < n:
        holiday = (d.month, d.day) in {(1, 1), (12, 25)}
        if d.weekday() < 5 and not holiday:
            ts.append(d.date().isoformat())
        d += timedelta(days=1)
    return pd.DataFrame({"ts": ts, "open": closes, "high": closes * 1.01,
                         "low": closes * 0.99, "close": closes,
                         "volume": [1_000_000.0] * n})


class TestNoTradeCrossesAYear(unittest.TestCase):
    """The specification's core guarantee."""

    def setUp(self):
        self.df = bars(seed=1)
        self.trades = bt._simulate_ticker("NVDA", self.df, {}, {}, None, annual_reset=True)

    def test_the_fixture_actually_spans_several_years(self):
        years = {str(t)[:4] for t in self.df["ts"]}
        self.assertGreaterEqual(len(years), 4, "fixture too short to test a year boundary")

    def test_entry_year_equals_exit_year_for_every_trade(self):
        self.assertTrue(self.trades, "no trades were produced; the test would prove nothing")
        for t in self.trades:
            self.assertEqual(str(t["entry_date"])[:4], str(t["exit_date"])[:4],
                             f"trade crossed a year: {t['entry_date']} -> {t['exit_date']}")

    def test_calendar_year_field_matches_the_entry_date(self):
        for t in self.trades:
            self.assertEqual(t["calendar_year"], int(str(t["entry_date"])[:4]))

    def test_continuous_mode_DOES_produce_cross_year_trades(self):
        """The control. If the continuous run also never crossed a year, the annual test would
        be passing for the wrong reason and proving nothing."""
        cont = bt._simulate_ticker("NVDA", self.df, {}, {}, None, annual_reset=False)
        crossing = [t for t in cont
                    if str(t["entry_date"])[:4] != str(t["exit_date"])[:4]]
        self.assertTrue(crossing,
                        "continuous mode produced no cross-year trades, so the annual "
                        "guarantee is untested")


class TestYearEndClosurePrice(unittest.TestCase):
    def test_closes_on_the_final_trading_day_of_the_year_not_the_first_of_the_next(self):
        """Closing at the new year's first bar would still 'reset', while settling the trade at
        a price from the year being excluded. The difference is invisible in the trade count and
        wrong in every return figure."""
        df = bars(seed=2)
        trades = bt._simulate_ticker("NVDA", df, {}, {}, None, annual_reset=True)
        year_ends = [t for t in trades if t["exit_reason"] == "YEAR_END"]
        self.assertTrue(year_ends, "fixture produced no year-end closures")

        dates = list(df["ts"].astype(str))
        for t in year_ends:
            year = str(t["exit_date"])[:4]
            last_of_year = max(d for d in dates if d[:4] == year)
            self.assertEqual(t["exit_date"], last_of_year)

    def test_year_end_exits_are_not_recorded_as_target_hits(self):
        df = bars(seed=3)
        for t in bt._simulate_ticker("NVDA", df, {}, {}, None, annual_reset=True):
            if t["exit_reason"] == "YEAR_END":
                self.assertFalse(t["target_reached"])
                self.assertTrue(t["year_end_exit"])

    def test_target_hits_are_flagged_and_are_not_year_end_exits(self):
        df = bars(seed=4)
        hits = [t for t in bt._simulate_ticker("NVDA", df, {}, {}, None, annual_reset=True)
                if t["exit_reason"] == "TARGET"]
        self.assertTrue(hits, "fixture produced no target hits")
        for t in hits:
            self.assertTrue(t["target_reached"])
            self.assertFalse(t["year_end_exit"])

    def test_every_trade_carries_both_flags(self):
        for t in bt._simulate_ticker("NVDA", bars(seed=5), {}, {}, None, annual_reset=True):
            self.assertIn("target_reached", t)
            self.assertIn("year_end_exit", t)
            self.assertIn("calendar_year", t)


class TestStrategyIsUnchanged(unittest.TestCase):
    """This is an evaluation change. Within a year the two frameworks must agree exactly."""

    def test_trades_opened_and_closed_inside_one_year_are_identical(self):
        df = bars(seed=6)
        cont = bt._simulate_ticker("NVDA", df, {}, {}, None, annual_reset=False)
        ann = bt._simulate_ticker("NVDA", df, {}, {}, None, annual_reset=True)

        # Trades the continuous run completed inside a single year must appear unchanged in the
        # annual run: same signal date, same fill, same exit, same reason.
        same_year_cont = {(t["ticker"], t["signal_date"]): t for t in cont
                          if str(t["entry_date"])[:4] == str(t["exit_date"])[:4]}
        ann_by_key = {(t["ticker"], t["signal_date"]): t for t in ann}
        compared = 0
        for key, c in same_year_cont.items():
            a = ann_by_key.get(key)
            if a is None:
                continue          # the annual reset legitimately changed what came before it
            if a["exit_reason"] in ("YEAR_END", "DATA_END"):
                continue
            self.assertAlmostEqual(c["entry_price"], a["entry_price"], places=6)
            self.assertEqual(c["exit_date"], a["exit_date"])
            self.assertEqual(c["exit_reason"], a["exit_reason"])
            compared += 1
        self.assertGreater(compared, 3, "too few comparable trades to prove equivalence")

    def test_annual_reset_off_is_byte_identical_to_the_original_behaviour(self):
        """Adding the parameter must not have changed the default path at all."""
        df = bars(seed=7)
        a = bt._simulate_ticker("NVDA", df, {}, {})
        b = bt._simulate_ticker("NVDA", df, {}, {}, None, annual_reset=False)
        self.assertEqual(len(a), len(b))
        for x, y in zip(a, b):
            self.assertEqual(x["signal_date"], y["signal_date"])
            self.assertAlmostEqual(x["entry_price"], y["entry_price"], places=9)
            self.assertEqual(x["exit_reason"], y["exit_reason"])


class TestNoLookAhead(unittest.TestCase):
    def test_future_bars_cannot_change_earlier_annual_trades(self):
        base = bars(seed=8)
        tampered = base.copy()
        tampered.loc[tampered.index[-60:], ["open", "high", "low", "close"]] *= 4.0
        a = bt._simulate_ticker("NVDA", base, {}, {}, None, annual_reset=True)
        b = bt._simulate_ticker("NVDA", tampered, {}, {}, None, annual_reset=True)
        cutoff = str(base["ts"].iloc[-90])
        ea = [t for t in a if t["entry_date"] < cutoff]
        eb = [t for t in b if t["entry_date"] < cutoff]
        self.assertEqual([t["entry_date"] for t in ea], [t["entry_date"] for t in eb])


class TestYearBoundsAndPartialYears(unittest.TestCase):
    def test_bounds_use_real_trading_days_not_january_first(self):
        df = bars(seed=9)
        bounds = ab._year_bounds({"NVDA": df})
        for year, b in bounds.items():
            self.assertIn(b["first_trading_day"], set(df["ts"].astype(str)))
            self.assertIn(b["last_trading_day"], set(df["ts"].astype(str)))
            # 1 January is a market holiday, so it can never be a year's first trading day.
            self.assertNotEqual(b["first_trading_day"], f"{year}-01-01")

    def test_a_year_ending_early_is_marked_partial(self):
        bounds = {2025: {"first_trading_day": "2025-01-02", "last_trading_day": "2025-12-31"},
                  2026: {"first_trading_day": "2026-01-02", "last_trading_day": "2026-08-14"}}
        partial = ab._partial_years(bounds)
        self.assertIn(2026, partial)
        self.assertNotIn(2025, partial)

    def test_a_year_starting_late_is_also_marked_partial(self):
        bounds = {2021: {"first_trading_day": "2021-08-16", "last_trading_day": "2021-12-31"}}
        self.assertIn(2021, ab._partial_years(bounds))


class TestStatistics(unittest.TestCase):
    def test_time_to_target_excludes_year_end_exits(self):
        trades = [
            {"target_reached": True, "year_end_exit": False, "holding_days": 10},
            {"target_reached": True, "year_end_exit": False, "holding_days": 20},
            {"target_reached": False, "year_end_exit": True, "holding_days": 300},
        ]
        t = ab._time_to_target(trades)
        self.assertEqual(t["n"], 2)
        self.assertEqual(t["max"], 20)          # the 300-day year-end hold must not appear

    def test_time_to_target_percentiles(self):
        trades = [{"target_reached": True, "year_end_exit": False, "holding_days": d}
                  for d in [10, 20, 30, 40, 100]]
        t = ab._time_to_target(trades)
        self.assertEqual(t["median"], 30.0)
        self.assertEqual(t["min"], 10)
        self.assertEqual(t["max"], 100)
        self.assertIsNotNone(t["p25"])
        self.assertIsNotNone(t["p90"])

    def test_no_target_hits_gives_none_not_zero(self):
        t = ab._time_to_target([{"target_reached": False, "year_end_exit": True,
                                 "holding_days": 50}])
        self.assertEqual(t["n"], 0)
        self.assertIsNone(t["median"])

    def test_year_end_analysis_splits_profitable_from_unprofitable(self):
        trades = [{"year_end_exit": True, "return_pct": 5.0},
                  {"year_end_exit": True, "return_pct": -3.0},
                  {"year_end_exit": True, "return_pct": -8.0},
                  {"year_end_exit": False, "return_pct": 99.0}]
        y = ab._year_end_analysis(trades)
        self.assertEqual(y["n"], 3)
        self.assertEqual(y["profitable"], 1)
        self.assertEqual(y["unprofitable"], 2)
        self.assertEqual(y["best_pct"], 5.0)
        self.assertEqual(y["worst_pct"], -8.0)

    def test_rates_are_none_not_zero_when_there_are_no_trades(self):
        """'0% hit rate' and 'nothing happened' are different facts."""
        s = ab._summarise([])
        self.assertIsNone(s["target_hit_rate_pct"])
        self.assertIsNone(s["year_end_rate_pct"])
        self.assertEqual(s["trades"], 0)

    def test_hit_and_year_end_rates_are_computed_from_completed_trades(self):
        trades = [{"return_pct": 5.0, "target_reached": True, "year_end_exit": False,
                   "holding_days": 5, "entry_date": "2022-01-05", "exit_date": "2022-01-12"},
                  {"return_pct": -2.0, "target_reached": False, "year_end_exit": True,
                   "holding_days": 40, "entry_date": "2022-11-05", "exit_date": "2022-12-30"}]
        s = ab._summarise(trades)
        self.assertEqual(s["target_hit_rate_pct"], 50.0)
        self.assertEqual(s["year_end_rate_pct"], 50.0)


class TestValidationReport(unittest.TestCase):
    BOUNDS = {2022: {"first_trading_day": "2022-01-03", "last_trading_day": "2022-12-30"}}

    def test_clean_trades_pass_every_check(self):
        trades = [{"ticker": "X", "entry_date": "2022-03-01", "exit_date": "2022-05-01",
                   "calendar_year": 2022, "exit_reason": "TARGET"}]
        v = ab._validate(trades, self.BOUNDS)
        self.assertTrue(v["all_passed"])

    def test_a_cross_year_trade_is_caught(self):
        trades = [{"ticker": "X", "entry_date": "2022-11-01", "exit_date": "2023-02-01",
                   "calendar_year": 2022, "exit_reason": "TARGET"}]
        v = ab._validate(trades, self.BOUNDS)
        self.assertFalse(v["all_passed"])
        self.assertFalse(v["checks"][0]["passed"])

    def test_an_exit_after_the_year_end_is_caught(self):
        trades = [{"ticker": "X", "entry_date": "2022-01-05", "exit_date": "2022-12-31",
                   "calendar_year": 2022, "exit_reason": "TARGET"}]
        v = ab._validate(trades, self.BOUNDS)
        self.assertFalse(v["checks"][1]["passed"])

    def test_an_unrecognised_exit_reason_is_caught(self):
        trades = [{"ticker": "X", "entry_date": "2022-01-05", "exit_date": "2022-02-05",
                   "calendar_year": 2022, "exit_reason": "MAGIC"}]
        v = ab._validate(trades, self.BOUNDS)
        self.assertFalse(v["checks"][3]["passed"])

    def test_a_mislabelled_calendar_year_is_caught(self):
        trades = [{"ticker": "X", "entry_date": "2022-01-05", "exit_date": "2022-02-05",
                   "calendar_year": 2021, "exit_reason": "TARGET"}]
        v = ab._validate(trades, self.BOUNDS)
        self.assertFalse(v["checks"][2]["passed"])


class TestEndToEnd(unittest.TestCase):
    def setUp(self):
        self.db = make_db()
        self.bars = {"NVDA": bars(seed=11), "AAPL": bars(seed=12)}
        self.out = ab.run_annual_backtest(self.db, ["NVDA", "AAPL"], self.bars,
                                          {"use_regime": False})

    def test_validation_passes_on_real_output(self):
        failed = [c for c in self.out["validation"]["checks"] if not c["passed"]]
        self.assertEqual(failed, [], f"validation failed: {failed}")

    def test_annual_counts_reconcile_with_the_overall_total(self):
        annual_sum = sum(v["trades"] for v in self.out["by_year"].values())
        self.assertEqual(annual_sum, self.out["overall"]["trades"])

    def test_every_year_is_reported_separately(self):
        years = {t["calendar_year"] for t in self.out["trades"]}
        for y in years:
            self.assertIn(y, self.out["by_year"])

    def test_year_by_stock_rows_exist_with_the_strategy_name(self):
        self.assertTrue(self.out["by_year_stock"])
        for row in self.out["by_year_stock"]:
            self.assertIn("strategy", row)
            self.assertIn("year", row)
            self.assertIn("stock", row)

    def test_partial_years_are_flagged_in_the_annual_rows(self):
        flagged = [y for y, v in self.out["by_year"].items() if v["partial_year"]]
        # The fixture deliberately ends mid-year, so the final year must be flagged partial and
        # the full years in the middle must not be.
        last_year = max(self.out["by_year"])
        self.assertIn(last_year, flagged, "the incomplete final year was not flagged")
        middle = [y for y in self.out["by_year"] if y not in (min(self.out["by_year"]), last_year)]
        for y in middle:
            self.assertFalse(self.out["by_year"][y]["partial_year"],
                             f"{y} is a complete year but was flagged partial")

    def test_overall_is_built_from_annual_tests_not_a_continuous_rerun(self):
        self.assertEqual(self.out["overall"]["annual_test_periods"], len(self.out["by_year"]))
        for t in self.out["trades"]:
            self.assertEqual(str(t["entry_date"])[:4], str(t["exit_date"])[:4])

    def test_comparison_runs_both_frameworks(self):
        out = ab.run_comparison(self.db, ["NVDA"], {"NVDA": self.bars["NVDA"]},
                                {"use_regime": False})
        self.assertIn("annual", out)
        self.assertIn("continuous", out)
        self.assertIn("continuous_trades_crossing_a_year", out["difference"])


class TestPageWiring(unittest.TestCase):
    def setUp(self):
        import app as app_module
        self.client = app_module.create_app().test_client()

    def test_page_renders_and_is_in_the_nav(self):
        self.assertEqual(self.client.get("/annual-backtest").status_code, 200)
        self.assertIn(b'href="/annual-backtest"', self.client.get("/").data)

    def test_script_exists_and_sends_the_strategy(self):
        frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
        js = (frontend / "static" / "js" / "annual_backtest.js")
        self.assertTrue(js.exists())
        self.assertIn('selectedStrategyId("ab-strategy")', js.read_text())

    def test_unknown_run_is_404(self):
        self.assertEqual(self.client.get("/api/annual-backtest/runs/999999").status_code, 404)


class TestYearEndSignalRegression(unittest.TestCase):
    """A signal on the final trading day of December fills in January.

    That trade belongs to the NEW year. The first implementation compared consecutive bars'
    years instead of the trade's own year, so it closed such a trade immediately at the OLD
    year's final close — producing a trade whose exit date preceded its entry date. Validation
    caught it; nothing in the trade count or the return figures would have.
    """

    def test_no_trade_has_an_exit_before_its_entry(self):
        for seed in range(6):
            df = bars(seed=seed)
            for t in bt._simulate_ticker("X", df, {}, {}, None, annual_reset=True):
                self.assertLessEqual(str(t["entry_date"]), str(t["exit_date"]),
                                     f"exit precedes entry: {t}")

    def test_a_january_entry_is_not_closed_at_the_previous_december(self):
        df = bars(seed=1)
        for t in bt._simulate_ticker("X", df, {}, {}, None, annual_reset=True):
            if str(t["entry_date"])[5:7] == "01":
                self.assertEqual(str(t["exit_date"])[:4], str(t["entry_date"])[:4])

    def test_holding_days_are_never_negative(self):
        for seed in range(4):
            for t in bt._simulate_ticker("X", bars(seed=seed), {}, {}, None, annual_reset=True):
                self.assertGreaterEqual(t["holding_days"], 0, f"negative hold: {t}")


if __name__ == "__main__":
    unittest.main()


class OverallReturnIsChainedNotPooled(unittest.TestCase):
    """The bug: overall total return pooled every trade into ONE continuous portfolio.

    That is the continuous backtest this page exists to be an alternative to. On the first real
    50-stock run it reported -0.1% from 1891 trades averaging +0.64% at a 63.5% win rate, while
    chaining the years gave about +24.6%. All six validation checks passed throughout, because
    they tested trade and date integrity and never asked whether the money added up.
    """

    def test_chain_compounds_years_in_order(self):
        by_year = {2021: {"total_return_pct": 10.0}, 2022: {"total_return_pct": -20.0},
                   2023: {"total_return_pct": 50.0}}
        out = ab._chain_years(by_year)
        # 1.10 * 0.80 * 1.50 = 1.32
        self.assertEqual(out["total_return_pct"], 32.0)

    def test_chain_is_not_a_sum(self):
        """A sum would give 40.0 here. Compounding gives 32.0. They must not be confused."""
        by_year = {2021: {"total_return_pct": 10.0}, 2022: {"total_return_pct": -20.0},
                   2023: {"total_return_pct": 50.0}}
        self.assertNotEqual(ab._chain_years(by_year)["total_return_pct"], 40.0)

    def test_cumulative_column_tracks_the_running_total(self):
        by_year = {2021: {"total_return_pct": 10.0}, 2022: {"total_return_pct": 10.0}}
        chain = ab._chain_years(by_year)["chain"]
        self.assertEqual([c["cumulative_pct"] for c in chain], [10.0, 21.0])

    def test_drawdown_spans_years(self):
        """2022 giving back 2021's gains is a real drawdown a yearly figure would hide."""
        by_year = {2021: {"total_return_pct": 25.0}, 2022: {"total_return_pct": -30.0},
                   2023: {"total_return_pct": 5.0}}
        out = ab._chain_years(by_year)
        self.assertLess(out["max_drawdown_pct"], -25.0)

    def test_annualised_is_the_geometric_rate(self):
        by_year = {2021: {"total_return_pct": 21.0}, 2022: {"total_return_pct": 0.0}}
        out = ab._chain_years(by_year)
        self.assertEqual(out["total_return_pct"], 21.0)
        self.assertAlmostEqual(out["annualised_return_pct"], 10.0, places=1)

    def test_years_with_no_trades_are_skipped_not_treated_as_zero(self):
        by_year = {2021: {"total_return_pct": 10.0}, 2022: {"total_return_pct": None}}
        out = ab._chain_years(by_year)
        self.assertEqual(out["total_return_pct"], 10.0)
        self.assertEqual(len(out["chain"]), 1)

    def test_no_years_at_all_is_none_not_zero(self):
        out = ab._chain_years({})
        self.assertIsNone(out["total_return_pct"])
        self.assertEqual(out["chain"], [])


class EconomicReconciliationCheck(unittest.TestCase):
    """The validation gap that let -0.1% through with six green checks."""

    def _run(self):
        db = make_db()
        bars_by = {"AAA": bars(1400, seed=1), "BBB": bars(1400, seed=2),
                   "SPY": bars(1400, seed=4), "QQQ": bars(1400, seed=5)}
        return ab.run_annual_backtest(db, ["AAA", "BBB"], bars_by, {"use_regime": True})

    def test_the_check_exists(self):
        checks = [c["check"] for c in self._run()["validation"]["checks"]]
        self.assertIn("Overall return equals the independent years chained together", checks)

    def test_it_passes_on_a_real_run(self):
        result = self._run()
        check = next(c for c in result["validation"]["checks"]
                     if c["check"].startswith("Overall return equals"))
        self.assertTrue(check["passed"], check.get("failures"))

    def test_overall_matches_the_chain_exactly(self):
        result = self._run()
        chained = ab._chain_years(result["by_year"])["total_return_pct"]
        self.assertEqual(result["overall"]["total_return_pct"], chained)

    def test_the_pooled_figure_is_kept_but_not_used_as_the_headline(self):
        """Kept for comparison, clearly named, and never the number on the tile."""
        result = self._run()
        self.assertIn("total_return_pooled_pct", result["overall"])
        self.assertIn("chained", result["overall"]["total_return_basis"])

    def test_the_check_fails_when_the_two_disagree(self):
        """Proves the check can actually fail — a check that cannot fail proves nothing."""
        by_year = {2021: {"total_return_pct": 10.0, "trades": 1},
                   2022: {"total_return_pct": 10.0, "trades": 1}}
        chain_total = ab._chain_years(by_year)["total_return_pct"]
        reported = -0.1                      # the number the real run actually put on screen
        self.assertFalse(abs(chain_total - reported) < 0.01)

    def test_per_trade_statistics_describe_the_trades_actually_funded(self):
        """This assertion changed on purpose, and the reason matters.

        It used to require avg_return_pct to equal the average over EVERY signal. That was the
        bug: the portfolio can only fund the signals it has capital free for, so averaging over
        all of them describes an account that never existed. On the live fifty it read +0.95% a
        trade against +7.85% total — two numbers that cannot both be true of one account.

        avg_return_pct is now over funded trades. The old basis is kept, and named, as
        avg_return_all_signals_pct so the difference stays visible.
        """
        result = self._run()
        overall = result["overall"]
        completed = [t for t in result["trades"] if t.get("return_pct") is not None]
        all_signals_avg = round(sum(t["return_pct"] for t in completed) / len(completed), 2)

        self.assertAlmostEqual(overall["avg_return_all_signals_pct"], all_signals_avg, places=1)
        self.assertEqual(overall["signals_generated"], len(completed))
        self.assertEqual(overall["signals_funded"] + overall["signals_unfunded"],
                         overall["signals_generated"])
        self.assertEqual(overall["trades"], overall["signals_funded"])
