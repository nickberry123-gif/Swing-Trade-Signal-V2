"""
The five-year EPS chain — splits, holes, amendments, and the point-in-time guarantee.

WHY THE COVERAGE HERE IS DELIBERATELY HEAVY. The bug this module replaces was not loud. Across
NVIDIA's 10-for-1 split, EPS growth computed to about 5% a year — a figure so ordinary that no
bound, no eyeball and no reviewer would have questioned it. The dilution figure from the same
data was 877% and got flagged immediately by a simple range check.

So the loud error was caught by a cheap test and the quiet one would have shipped. Everything
below exists to make the quiet one impossible: the chain either produces a number built entirely
from within-filing comparisons, or it produces UNKNOWN and says where it broke. There is no third
outcome, and no path anywhere in this file infers, looks up or guesses a split factor.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services import eps_chain  # noqa: E402


def row(period_end, filed, eps, ticker="TEST"):
    return {"ticker": ticker, "period_end": period_end, "filed": filed, "eps_diluted": eps}


# A ten-for-one split between the 2023 and 2025 filings. Both filings are correct; the FY2022
# figure simply means something different in each. This is NVIDIA's actual shape.
SPLIT_HISTORY = [
    # FY2025 filing — post-split basis
    row("2024-12-31", "2025-02-01", 1.19),
    row("2023-12-31", "2025-02-01", 0.17),
    row("2022-12-31", "2025-02-01", 0.385),
    # FY2023 filing — pre-split basis, same underlying years
    row("2022-12-31", "2023-02-01", 3.85),
    row("2021-12-31", "2023-02-01", 1.73),
    row("2020-12-31", "2023-02-01", 0.85),
]


class ASplitCannotCreateGrowth(unittest.TestCase):

    def test_every_link_comes_from_a_single_filing(self):
        links = eps_chain.build_links(SPLIT_HISTORY)
        for (older, newer), link in links.items():
            same_filing = [r for r in SPLIT_HISTORY if r["filed"] == link["filed"]]
            ends = {r["period_end"] for r in same_filing}
            self.assertIn(older, ends)
            self.assertIn(newer, ends)

    def test_the_chain_spans_the_split_without_being_distorted_by_it(self):
        """The whole technique in one assertion. FY2020 to FY2024 is a real 5-year run of
        earnings growth; the ratios are 0.85->1.73->3.85 (pre-split) and 0.385->0.17->1.19
        (post-split), and multiplying them is valid because each basis cancels inside its own
        link."""
        out = eps_chain.chain(SPLIT_HISTORY, years=5)
        self.assertIsNotNone(out["value"])
        self.assertGreater(out["value"], 0)
        filings = {link["reported_in_filing"] for link in out["links_used"]}
        self.assertEqual(filings, {"2023-02-01", "2025-02-01"})

    def test_the_naive_cross_filing_comparison_would_have_been_wildly_wrong(self):
        """Evidence that the fix is load-bearing rather than tidy. Comparing the newest EPS with
        the oldest across filings gives a figure that looks entirely reasonable and is not."""
        naive = ((1.19 / 0.85) ** (1 / 4.0) - 1) * 100      # ~8.8% a year, plausible-looking
        chained = eps_chain.chain(SPLIT_HISTORY, years=5)["value"]
        self.assertLess(naive, 15.0)
        self.assertGreater(chained, 40.0)

    def test_two_splits_in_the_history_are_handled_the_same_way(self):
        """Nothing special is done for a second split, because nothing special is done for the
        first — each link is self-contained, so any number of rebasings is transparent."""
        rows = [
            row("2024-12-31", "2025-02-01", 2.0), row("2023-12-31", "2025-02-01", 1.0),
            row("2023-12-31", "2023-02-01", 4.0), row("2022-12-31", "2023-02-01", 2.0),
            row("2022-12-31", "2021-02-01", 20.0), row("2021-12-31", "2021-02-01", 10.0),
        ]
        out = eps_chain.chain(rows, years=5)
        self.assertEqual(len(out["links_used"]), 3)
        # Each link doubles, so three years of doubling is 100% a year regardless of the
        # rebasing. Not exactly 100 because the span is measured in real calendar days and one of
        # those years is a leap year — which is the correct behaviour, not a rounding fudge.
        self.assertAlmostEqual(out["value"], 100.0, delta=0.5)

    def test_no_split_factor_is_ever_computed_anywhere(self):
        """A guessed 10x is worse than an absent number, so the module must contain no notion of
        one. Asserted structurally rather than by inspection."""
        source = (Path(__file__).resolve().parent.parent / "services" / "eps_chain.py").read_text()
        for banned in ("split_factor", "split_ratio", "adjust_for_split", "SPLIT_FACTORS"):
            self.assertNotIn(banned, source)


class WhereItRefuses(unittest.TestCase):

    def test_a_hole_in_the_chain_returns_unknown_rather_than_bridging_it(self):
        """FY2022 and FY2023 never appear in the same filing, so the two halves cannot be
        joined. Bridging them across filings is exactly the error being prevented."""
        rows = [
            row("2024-12-31", "2025-02-01", 2.0), row("2023-12-31", "2025-02-01", 1.0),
            row("2022-12-31", "2022-02-01", 8.0), row("2021-12-31", "2022-02-01", 4.0),
        ]
        out = eps_chain.chain(rows, years=5)
        self.assertEqual(len(out["links_used"]), 1)        # only the newer half is usable
        self.assertLess(out["years_covered"], 2)
        self.assertIn("years of unbroken links", out["reason"])

    def test_a_single_year_of_history_cannot_form_a_link(self):
        out = eps_chain.chain([row("2024-12-31", "2025-02-01", 1.0)], years=5)
        self.assertIsNone(out["value"])
        self.assertIn("one share basis", out["reason"])

    def test_no_filings_at_all_is_a_reason_not_a_crash(self):
        out = eps_chain.chain([], years=5)
        self.assertIsNone(out["value"])
        self.assertTrue(out["reason"])

    def test_a_loss_year_breaks_the_link_rather_than_producing_nonsense(self):
        """A ratio across a sign change is not a growth rate. Going from a loss to a profit is a
        real and important event, but "growth of -240%" describes nothing and compounding it
        produces arithmetic that means even less."""
        rows = [row("2024-12-31", "2025-02-01", 2.0), row("2023-12-31", "2025-02-01", -1.0)]
        self.assertEqual(eps_chain.build_links(rows), {})

    def test_a_zero_eps_year_also_breaks_the_link(self):
        rows = [row("2024-12-31", "2025-02-01", 2.0), row("2023-12-31", "2025-02-01", 0.0)]
        self.assertEqual(eps_chain.build_links(rows), {})

    def test_periods_that_are_not_a_year_apart_are_not_linked(self):
        """A transition-period filing can hold two period ends a few months apart. Treating that
        as a year of growth would annualise a quarter."""
        rows = [row("2024-12-31", "2025-02-01", 2.0), row("2024-06-30", "2025-02-01", 1.0)]
        self.assertEqual(eps_chain.build_links(rows), {})

    def test_a_gap_of_two_years_inside_one_filing_is_not_linked(self):
        rows = [row("2024-12-31", "2025-02-01", 2.0), row("2022-12-31", "2025-02-01", 1.0)]
        self.assertEqual(eps_chain.build_links(rows), {})


class AmendmentsAndDuplicates(unittest.TestCase):

    def test_an_amended_filing_supersedes_the_original_for_the_link_it_covers(self):
        """Both endpoints of the amended link come from the amendment, so it stays internally
        consistent — which is why taking the later filing is safe here and would not be safe if
        endpoints were mixed across filings."""
        rows = [
            row("2024-12-31", "2025-02-01", 2.0), row("2023-12-31", "2025-02-01", 1.0),
            row("2024-12-31", "2025-06-01", 1.8), row("2023-12-31", "2025-06-01", 1.0),
        ]
        links = eps_chain.build_links(rows)
        self.assertEqual(len(links), 1)
        link = links[("2023-12-31", "2024-12-31")]
        self.assertEqual(link["filed"], "2025-06-01")
        self.assertAlmostEqual(link["ratio"], 1.8)

    def test_the_same_period_reported_by_many_filings_does_not_multiply_links(self):
        rows = [
            row("2024-12-31", "2025-02-01", 2.0), row("2023-12-31", "2025-02-01", 1.0),
            row("2023-12-31", "2024-02-01", 1.0), row("2022-12-31", "2024-02-01", 0.5),
            row("2023-12-31", "2023-02-01", 1.0),
        ]
        links = eps_chain.build_links(rows)
        self.assertEqual(len(links), 2)

    def test_a_duplicate_period_within_one_filing_is_resolved_deterministically(self):
        rows = [
            row("2024-12-31", "2025-02-01", 2.0), row("2024-12-31", "2025-02-01", 2.0),
            row("2023-12-31", "2025-02-01", 1.0),
        ]
        links = eps_chain.build_links(rows)
        self.assertEqual(len(links), 1)
        self.assertAlmostEqual(links[("2023-12-31", "2024-12-31")]["ratio"], 2.0)


class PointInTime(unittest.TestCase):
    """A five-year growth rate computed for a past date must be built only from filings that
    existed then. This is the same guarantee as the storage layer's, asserted again here because
    the chain is the one place that deliberately reads EVERY vintage."""

    def test_a_filing_published_after_the_scored_date_is_invisible(self):
        out = eps_chain.chain(SPLIT_HISTORY, years=5, as_of_filed="2024-01-01")
        for link in out["links_used"]:
            self.assertLessEqual(link["reported_in_filing"], "2024-01-01")

    def test_the_answer_changes_with_the_date_which_proves_the_cutoff_is_doing_the_work(self):
        early = eps_chain.chain(SPLIT_HISTORY, years=5, as_of_filed="2024-01-01")
        late = eps_chain.chain(SPLIT_HISTORY, years=5, as_of_filed="2026-01-01")
        self.assertNotEqual(early["years_covered"], late["years_covered"])
        self.assertLess(early["years_covered"], late["years_covered"])

    def test_a_date_before_any_filing_returns_unknown_not_the_newest_data(self):
        out = eps_chain.chain(SPLIT_HISTORY, years=5, as_of_filed="2019-01-01")
        self.assertIsNone(out["value"])
        self.assertIn("no filings", out["reason"])

    def test_removing_the_cutoff_changes_the_result_so_the_test_is_not_vacuous(self):
        """Guards against the cutoff quietly becoming a no-op: with it, the 2025 filing is
        unreachable at a 2024 date; without it, it is used."""
        constrained = eps_chain.chain(SPLIT_HISTORY, years=5, as_of_filed="2024-01-01")
        unconstrained = eps_chain.chain(SPLIT_HISTORY, years=5)
        used_early = {l["reported_in_filing"] for l in constrained["links_used"]}
        used_all = {l["reported_in_filing"] for l in unconstrained["links_used"]}
        self.assertNotIn("2025-02-01", used_early)
        self.assertIn("2025-02-01", used_all)


class TheAnswerDescribesItself(unittest.TestCase):

    def test_the_span_actually_covered_is_reported_not_assumed(self):
        """A three-year answer labelled three years is useful. A three-year answer labelled five
        years is a lie about the evidence behind it."""
        rows = [row("2024-12-31", "2025-02-01", 2.0), row("2023-12-31", "2025-02-01", 1.0)]
        out = eps_chain.chain(rows, years=5)
        self.assertAlmostEqual(out["years_covered"], 1.0, places=1)
        self.assertIn("only 1.0 years", out["reason"])

    def test_every_link_shows_its_inputs_and_its_source_filing(self):
        out = eps_chain.chain(SPLIT_HISTORY, years=5)
        for link in out["links_used"]:
            self.assertEqual(set(link), {"from_period", "to_period", "from_value", "to_value",
                                         "ratio", "reported_in_filing"})

    def test_a_full_five_year_chain_reports_no_shortfall(self):
        rows = []
        for i, filed in enumerate(("2021-02-01", "2023-02-01", "2025-02-01")):
            base = 2021 + i * 2
            rows += [row(f"{base}-12-31", filed, 1.0 * (2 ** i)),
                     row(f"{base + 1}-12-31", filed, 1.5 * (2 ** i)),
                     row(f"{base + 2}-12-31", filed, 2.0 * (2 ** i))]
        out = eps_chain.chain(rows, years=5)
        self.assertGreaterEqual(out["years_covered"], 4.5)
        self.assertIsNotNone(out["value"])


if __name__ == "__main__":
    unittest.main()
