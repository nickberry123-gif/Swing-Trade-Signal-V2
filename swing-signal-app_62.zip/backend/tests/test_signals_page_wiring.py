"""
The Signals page and its script must agree with each other, and with the API.

WHY THIS FILE EXISTS. This project has already shipped a page whose table headers sat above the
wrong columns, because the template and the script drifted apart and nothing checked. A rendering
mismatch produces no error anywhere — the page loads, the numbers appear, and they are simply
under the wrong labels. These tests read both files and compare them.
"""
import re
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app as app_module  # noqa: E402

FRONTEND = Path(__file__).resolve().parent.parent.parent / "frontend"
TEMPLATE = (FRONTEND / "templates" / "signals.html").read_text()
SCRIPT = (FRONTEND / "static" / "js" / "signals.js").read_text()


class SignalsPageWiring(unittest.TestCase):

    def setUp(self):
        self.app = app_module.create_app()
        self.client = self.app.test_client()

    def test_every_element_the_script_writes_to_exists_in_the_template(self):
        """The drift check. A missing id is a silent no-op in the browser, not an error."""
        needed = set(re.findall(r'getElementById\("([^"]+)"\)', SCRIPT))
        present = set(re.findall(r'id="([^"]+)"', TEMPLATE))
        missing = needed - present
        self.assertEqual(missing, set(),
                         f"signals.js writes to elements the template does not define: {missing}")

    def test_the_page_reads_the_v2_endpoint_not_the_v1_one(self):
        self.assertIn('apiGet("/api/signals/v2")', SCRIPT)

    def test_both_v2_endpoints_are_registered(self):
        rules = {str(r) for r in self.app.url_map.iter_rules()}
        self.assertIn("/api/signals/v2", rules)
        self.assertIn("/api/signals/v2/<ticker>", rules)

    def test_the_v1_endpoint_still_exists_because_the_detail_page_uses_it(self):
        """v2 is an addition to the Signals page, not a deletion of v1. The stock detail page's
        'why this score' panel still reads v1, and removing the endpoint would blank it."""
        rules = {str(r) for r in self.app.url_map.iter_rules()}
        self.assertIn("/api/signals", rules)
        self.assertIn("/api/signals/<ticker>", rules)

    def test_the_page_renders_and_names_both_scores(self):
        html = self.client.get("/signals").data.decode()
        self.assertIn("HOLD QUALITY", html)
        self.assertIn("ENTRY QUALITY", html)

    def test_the_page_states_that_a_high_score_is_not_permission(self):
        """The gates are the substantive change. A user who does not know they exist will read a
        WATCH on a 90-scoring stock as a bug."""
        html = self.client.get("/signals").data.decode().lower()
        self.assertIn("gates", html)
        self.assertIn("not permission", html)

    def test_the_page_says_no_stop_loss_and_explains_the_excluded_triggers(self):
        html = self.client.get("/signals").data.decode().lower()
        self.assertIn("no stop-loss", html)
        self.assertIn("moved against you", html)

    def test_the_word_short_never_appears_as_a_trade_direction(self):
        """Long-only, asserted on the rendered page rather than trusted."""
        html = self.client.get("/signals").data.decode().lower()
        for phrase in ("short position", "go short", "short sell", "sell short"):
            self.assertNotIn(phrase, html)

    def test_no_stop_loss_field_is_rendered_anywhere_on_the_page(self):
        html = self.client.get("/signals").data.decode().lower()
        # The page may DISCUSS stop-losses (it explains why there are none). It must not offer
        # one: no input, no label presenting a stop as a level to act on.
        self.assertNotIn('name="stop', html)
        self.assertNotIn("stop price", html)
        self.assertNotIn("stop level</", html)

    def test_unknown_is_rendered_as_its_own_state_not_folded_into_a_score(self):
        self.assertIn("UNKNOWN", SCRIPT)
        self.assertIn("weight removed from the total", SCRIPT)

    def test_the_summary_and_refresh_endpoints_are_registered(self):
        rules = {str(r) for r in self.app.url_map.iter_rules()}
        self.assertIn("/api/signals/v2/summary", rules)
        self.assertIn("/api/signals/v2/refresh", rules)

    def test_the_refresh_endpoint_is_post_only(self):
        """A GET that triggers ninety seconds of SEC and Alpaca requests is one a crawler,
        a prefetcher or a stray reload can fire. Recomputing is an action, not a read."""
        rule = next(r for r in self.app.url_map.iter_rules()
                    if str(r) == "/api/signals/v2/refresh")
        self.assertIn("POST", rule.methods)
        self.assertNotIn("GET", rule.methods)

    def test_the_watcher_polls_the_small_endpoint_not_the_full_payload(self):
        """The full payload is ~150KB. The last time a page polled a heavy endpoint during a long
        job it crossed gunicorn's request limit and killed the run it was watching."""
        watcher = SCRIPT[SCRIPT.index("async function watchRefresh"):
                         SCRIPT.index("const refreshBtn")]
        self.assertIn("/api/signals/v2/summary", watcher)
        self.assertNotIn('apiGet("/api/signals/v2")', watcher)

    def test_the_page_shows_how_old_the_reading_is(self):
        """A cached page that does not say it is cached is worse than a slow one."""
        self.assertIn('id="v2-freshness"', TEMPLATE)
        self.assertIn("oldest of the 50", SCRIPT)

    def test_standing_conditions_are_not_rendered_as_warning_banners(self):
        """The cry-wolf guard, asserted on the rendering and not only on the data. 18 of 50
        tickers once showed a SELL TRIGGER banner because a trend broken for months was reported
        as breaking. Only what CHANGED may use the alarm styling."""
        block = SCRIPT[SCRIPT.index("function renderSells"):SCRIPT.index("function renderSummary")]
        standing_part = block[block.index("const ongoing"):]
        self.assertNotIn("warn-banner", standing_part)
        self.assertIn("ongoing, not new", standing_part)

    def test_the_summary_shows_changed_and_ongoing_as_separate_counts(self):
        self.assertIn("Changed for the worse", SCRIPT)
        self.assertIn("Currently failing", SCRIPT)

    def test_changes_are_shown_above_the_ranked_list(self):
        """Ordering is the point, not decoration: the stated purpose of the page is not missing a
        change, and a change placed under fifteen cards is a change nobody reads."""
        self.assertLess(TEMPLATE.index('id="v2-changes"'), TEMPLATE.index('id="signals-grid"'))


if __name__ == "__main__":
    unittest.main()
