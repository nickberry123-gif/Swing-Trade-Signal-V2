"""
News fetching, caching and scoring (Phase 4).

Cached for 30 minutes — news moves faster than fundamentals but far slower than price, and this
keeps the dashboard's 15-second poll from hammering Alpaca's news endpoint.

The sentiment attached to each headline is the transparent keyword classifier documented in
providers/news_provider.py, and is described as "keyword-based" wherever it is shown. No claim
of NLP/AI sentiment analysis is made anywhere.
"""
from datetime import datetime, timedelta, timezone

from config import Config
from providers.base import ProviderError
from providers.news_provider import AlpacaNewsProvider

NEWS_TTL = timedelta(minutes=30)
NEWS_LOOKBACK_DAYS = 14

_provider = None


def get_news_provider():
    global _provider
    if _provider is None:
        _provider = AlpacaNewsProvider(Config.ALPACA_API_KEY, Config.ALPACA_SECRET_KEY)
    return _provider


def _cache_is_fresh(db, ticker: str) -> bool:
    row = db.execute(
        "SELECT MAX(fetched_at) AS last FROM news WHERE ticker = ?", (ticker,)
    ).fetchone()
    last = row["last"] if row else None
    if not last:
        return False
    try:
        ts = datetime.fromisoformat(last)
    except (TypeError, ValueError):
        return False
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - ts) < NEWS_TTL


def _store(db, ticker: str, items: list):
    now = datetime.now(timezone.utc).isoformat()
    for item in items:
        # De-duplicate on (ticker, url) — the same story often arrives via several symbols.
        #
        # NULL-safe comparison has to be written out explicitly rather than using `url IS ?`:
        # that is valid SQLite (where IS doubles as a null-safe equality operator) but invalid
        # PostgreSQL, where IS only accepts NULL/TRUE/FALSE/UNKNOWN and a bound parameter is a
        # syntax error. Branching in Python keeps it portable across both backends.
        if item.url is None:
            existing = db.execute(
                "SELECT id FROM news WHERE ticker = ? AND url IS NULL LIMIT 1", (ticker,)
            ).fetchone()
        else:
            existing = db.execute(
                "SELECT id FROM news WHERE ticker = ? AND url = ? LIMIT 1", (ticker, item.url)
            ).fetchone()
        if existing:
            db.execute(
                "UPDATE news SET headline=?, summary=?, source=?, published_at=?, sentiment=?, "
                "impact=?, fetched_at=? WHERE id=?",
                (item.headline, item.summary, item.source, item.published_at, item.sentiment,
                 item.impact, now, existing["id"]),
            )
        else:
            db.execute(
                "INSERT INTO news (ticker, headline, summary, source, url, published_at, "
                "sentiment, impact, fetched_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (ticker, item.headline, item.summary, item.source, item.url, item.published_at,
                 item.sentiment, item.impact, now),
            )
    db.commit()


def refresh_news(db, tickers: list, force: bool = False) -> dict:
    """Fetches news for the given tickers in ONE batched Alpaca call (the endpoint accepts a
    comma-separated symbol list), then fans the results out per ticker."""
    stale = [t for t in tickers if force or not _cache_is_fresh(db, t)]
    if not stale:
        return {"fetched": 0, "error": None}

    try:
        items = get_news_provider().get_news(stale, days_back=NEWS_LOOKBACK_DAYS, limit=50)
    except ProviderError as e:
        return {"fetched": 0, "error": str(e)}

    by_ticker = {t: [] for t in stale}
    for item in items:
        for sym in (item.symbols or []):
            if sym in by_ticker:
                by_ticker[sym].append(item)

    for ticker, ticker_items in by_ticker.items():
        _store(db, ticker, ticker_items)
        if not ticker_items:
            # Record the fetch attempt so an empty-but-successful result doesn't cause a refetch
            # on every single request.
            db.execute(
                "INSERT INTO news (ticker, headline, source, url, published_at, sentiment, "
                "impact, fetched_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (ticker, "__no_recent_news__", None, None, None, "NEUTRAL", "NORMAL",
                 datetime.now(timezone.utc).isoformat()),
            )
            db.commit()

    return {"fetched": len(items), "error": None}


def get_news_for_ticker(db, ticker: str, limit: int = 15) -> list:
    rows = db.execute(
        "SELECT headline, summary, source, url, published_at, sentiment, impact, fetched_at "
        "FROM news WHERE ticker = ? AND headline != '__no_recent_news__' "
        "ORDER BY COALESCE(published_at, fetched_at) DESC LIMIT ?",
        (ticker, limit),
    ).fetchall()
    return [dict(r) for r in rows]


def score_news(db, ticker: str) -> tuple:
    """5 points of the 100-point signal score.

    Deliberately conservative and asymmetric: bearish news is penalised more than bullish news
    is rewarded. For a long-only strategy, a headline warning of a lawsuit or a guidance cut is
    far more actionable than one celebrating a rally that has already happened.

    Returns (score, reasons). Score is None (not 0) when there's genuinely no news data — the
    caller must be able to distinguish "no news" from "bad news".
    """
    items = get_news_for_ticker(db, ticker, limit=25)
    checked = db.execute(
        "SELECT COUNT(*) AS c FROM news WHERE ticker = ?", (ticker,)
    ).fetchone()["c"]

    if checked == 0:
        return None, ["No news data has been fetched for this stock yet."]

    if not items:
        return 3.5, ["No notable news in the last 14 days (neutral — treated as mildly positive "
                     "for a long-only swing setup, since no news is better than bad news)."]

    cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
    recent = [i for i in items if (i.get("published_at") or "") >= cutoff] or items[:5]

    bullish = sum(1 for i in recent if i.get("sentiment") == "BULLISH")
    bearish = sum(1 for i in recent if i.get("sentiment") == "BEARISH")
    high_impact_bearish = sum(
        1 for i in recent if i.get("sentiment") == "BEARISH" and i.get("impact") == "HIGH")

    score = 3.0  # neutral baseline
    score += min(bullish, 3) * 0.5
    score -= min(bearish, 3) * 0.8
    score -= min(high_impact_bearish, 2) * 0.7
    score = round(max(0.0, min(5.0, score)), 2)

    reasons = [
        f"{len(recent)} recent headline(s) reviewed: {bullish} bullish, {bearish} bearish, "
        f"{len(recent) - bullish - bearish} neutral (keyword-based classification)"
    ]
    if high_impact_bearish:
        reasons.append(f"{high_impact_bearish} high-impact negative headline(s) — score reduced")
    return score, reasons


def score_earnings_risk(earnings_info: dict) -> tuple:
    """5 points. Rewards being clear of an earnings event and penalises entering right before an
    estimated report — a swing trade held through earnings is an overnight gap risk this
    strategy shouldn't take blindly.

    Because the report date is ESTIMATED from filing cadence (never company-confirmed), the
    penalty is capped and the reason string always says so.
    """
    if not earnings_info or earnings_info.get("data_status") == "UNAVAILABLE":
        return None, ["Earnings timing unavailable — this component could not be evaluated."]

    days = earnings_info.get("days_until_estimated_report")
    confidence = earnings_info.get("estimate_confidence") or "LOW"
    if days is None:
        return None, ["No estimated earnings date could be derived from SEC filing history."]

    caveat = (f"estimated from SEC filing cadence ({confidence} confidence) — not a "
              f"company-confirmed date")

    if days < 0:
        return 4.0, [f"Most recent report already filed; next estimate has passed ({caveat})."]
    if days <= 5:
        return 0.5, [f"~{days} day(s) to the estimated next report — high earnings-gap risk ({caveat})."]
    if days <= 12:
        return 2.0, [f"~{days} days to the estimated next report — elevated earnings risk ({caveat})."]
    if days <= 25:
        return 3.5, [f"~{days} days to the estimated next report ({caveat})."]
    return 5.0, [f"~{days} days to the estimated next report — clear of earnings ({caveat})."]
