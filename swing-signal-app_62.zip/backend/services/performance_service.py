"""
Phase 6: append-only signal history, forward-return evaluation, and performance analytics.

The honesty problem this module exists to solve: it is trivially easy to build a performance
page that looks like a track record after three days of data. Everything here is therefore
sample-size aware — every statistic carries `sample_size`, and anything computed from fewer
than MIN_MEANINGFUL_SAMPLE observations is explicitly flagged as not yet meaningful rather than
being displayed as a clean percentage.

Forward returns are measured from the price recorded AT THE TIME the signal was generated
against the actual close N trading days later, read from the same cached bar data the rest of
the app uses. A horizon is only evaluated once enough time has genuinely elapsed — never
extrapolated to fill a gap.
"""
from datetime import datetime, timedelta, timezone

HORIZONS = (5, 10, 20)
MIN_MEANINGFUL_SAMPLE = 20

# Only these labels represent an actionable "the system suggested buying" call. WATCH/NO
# TRADE/AVOID are non-actions and are tracked separately rather than being scored as if they
# were entries.
ACTIONABLE_LABELS = ("STRONG BUY", "BUY")


def snapshot_signals(db, signals: list) -> int:
    """Append the current signals to signal_history. Append-only by design: history is never
    overwritten or recomputed, because a strategy's past calls must remain exactly as they were
    made, including the bad ones."""
    written = 0
    for s in signals:
        if s.get("score_total") is None or s.get("data_status") != "OK":
            continue
        db.execute(
            """
            INSERT INTO signal_history (ticker, ts, score_total, signal_label, current_price,
                                         ideal_buy, buy_zone_low, buy_zone_high, max_entry,
                                         target1, primary_target, target3, market_regime,
                                         long_term_quality, long_term_thesis, strategy_version)
            VALUES (:ticker, :ts, :score_total, :signal_label, :current_price, :ideal_buy,
                    :buy_zone_low, :buy_zone_high, :max_entry, :target1, :primary_target,
                    :target3, :market_regime, :long_term_quality, :long_term_thesis,
                    :strategy_version)
            """,
            {
                "ticker": s.get("ticker"),
                "ts": datetime.now(timezone.utc).isoformat(),
                "score_total": s.get("score_total"), "signal_label": s.get("signal_label"),
                "current_price": s.get("current_price"), "ideal_buy": s.get("ideal_buy"),
                "buy_zone_low": s.get("buy_zone_low"), "buy_zone_high": s.get("buy_zone_high"),
                "max_entry": s.get("max_entry"), "target1": s.get("target1"),
                "primary_target": s.get("primary_target"), "target3": s.get("target3"),
                "market_regime": s.get("market_regime"),
                "long_term_quality": s.get("long_term_quality"),
                "long_term_thesis": s.get("long_term_thesis"),
                "strategy_version": s.get("strategy_version"),
            },
        )
        written += 1
    db.commit()
    return written


def get_signal_history(db, ticker: str | None = None, limit: int = 200) -> list:
    if ticker:
        rows = db.execute(
            "SELECT * FROM signal_history WHERE ticker = ? ORDER BY ts DESC LIMIT ?",
            (ticker.upper(), limit)).fetchall()
    else:
        rows = db.execute("SELECT * FROM signal_history ORDER BY ts DESC LIMIT ?",
                          (limit,)).fetchall()
    return [dict(r) for r in rows]


def _price_on_or_after(db, ticker: str, target_dt: datetime):
    """First cached daily close at/after `target_dt`. Returns None if the bar cache doesn't yet
    reach that far forward — which is the correct answer for a horizon that hasn't elapsed."""
    row = db.execute(
        "SELECT ts, close FROM market_bars WHERE ticker = ? AND timeframe = '1Day' AND ts >= ? "
        "ORDER BY ts ASC LIMIT 1",
        (ticker, target_dt.isoformat()),
    ).fetchone()
    return (row["close"], row["ts"]) if row else (None, None)


def evaluate_signal_outcomes(db, horizons=HORIZONS) -> dict:
    """For every historical signal, record the forward return at each horizon once that horizon
    has actually elapsed AND a real forward price exists in the bar cache."""
    evaluated = 0
    skipped_not_elapsed = 0
    skipped_no_price = 0

    rows = db.execute(
        "SELECT id, ticker, ts, signal_label, score_total, current_price FROM signal_history "
        "WHERE current_price IS NOT NULL ORDER BY ts ASC"
    ).fetchall()

    now = datetime.now(timezone.utc)
    for row in rows:
        try:
            signal_dt = datetime.fromisoformat(row["ts"])
        except (TypeError, ValueError):
            continue
        if signal_dt.tzinfo is None:
            signal_dt = signal_dt.replace(tzinfo=timezone.utc)

        for horizon in horizons:
            already = db.execute(
                "SELECT 1 FROM signal_outcomes WHERE signal_history_id = ? AND horizon_days = ?",
                (row["id"], horizon)).fetchone()
            if already:
                continue

            # ~7 calendar days per 5 trading days; only evaluate once genuinely elapsed.
            target_dt = signal_dt + timedelta(days=horizon * 7 / 5)
            if target_dt > now:
                skipped_not_elapsed += 1
                continue

            price, _ = _price_on_or_after(db, row["ticker"], target_dt)
            if price is None:
                skipped_no_price += 1
                continue

            entry = row["current_price"]
            ret = ((price - entry) / entry * 100) if entry else None
            db.execute(
                """
                INSERT INTO signal_outcomes (signal_history_id, ticker, signal_label,
                                              score_total, signal_ts, signal_price, horizon_days,
                                              evaluated_price, return_pct)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(signal_history_id, horizon_days) DO NOTHING
                """,
                (row["id"], row["ticker"], row["signal_label"], row["score_total"], row["ts"],
                 entry, horizon, price, round(ret, 4) if ret is not None else None),
            )
            evaluated += 1

    db.commit()
    return {"evaluated": evaluated, "pending_time": skipped_not_elapsed,
            "pending_price_data": skipped_no_price}


def _stats(returns: list) -> dict:
    if not returns:
        return {"sample_size": 0, "avg_return_pct": None, "win_rate_pct": None,
                "best_pct": None, "worst_pct": None, "meaningful": False}
    wins = sum(1 for r in returns if r > 0)
    return {
        "sample_size": len(returns),
        "avg_return_pct": round(sum(returns) / len(returns), 2),
        "win_rate_pct": round(wins / len(returns) * 100, 1),
        "best_pct": round(max(returns), 2),
        "worst_pct": round(min(returns), 2),
        "meaningful": len(returns) >= MIN_MEANINGFUL_SAMPLE,
    }


def get_performance_summary(db) -> dict:
    """Signal accuracy broken down by label and by horizon, plus score-band analysis.

    Every block carries its own sample size and a `meaningful` flag. Nothing here should be read
    as a validated edge until those flags turn true — and even then this is forward-tracking of
    live signals, not a backtest (that's Phase 7).
    """
    rows = db.execute(
        "SELECT signal_label, score_total, horizon_days, return_pct FROM signal_outcomes "
        "WHERE return_pct IS NOT NULL").fetchall()

    by_label = {}
    by_horizon = {}
    by_score_band = {}
    actionable_by_horizon = {}

    for r in rows:
        label = r["signal_label"] or "UNKNOWN"
        horizon = r["horizon_days"]
        ret = r["return_pct"]

        by_label.setdefault(label, {}).setdefault(horizon, []).append(ret)
        by_horizon.setdefault(horizon, []).append(ret)
        if label in ACTIONABLE_LABELS:
            actionable_by_horizon.setdefault(horizon, []).append(ret)

        score = r["score_total"]
        if score is not None:
            band = ("80+" if score >= 80 else "70-79" if score >= 70 else
                    "60-69" if score >= 60 else "50-59" if score >= 50 else "<50")
            by_score_band.setdefault(band, {}).setdefault(horizon, []).append(ret)

    total_signals = db.execute("SELECT COUNT(*) AS c FROM signal_history").fetchone()["c"]
    total_outcomes = len(rows)

    result = {
        "total_signals_recorded": total_signals,
        "total_outcomes_evaluated": total_outcomes,
        "min_meaningful_sample": MIN_MEANINGFUL_SAMPLE,
        "horizons": list(HORIZONS),
        "by_label": {l: {h: _stats(v) for h, v in hs.items()} for l, hs in by_label.items()},
        "by_horizon": {h: _stats(v) for h, v in by_horizon.items()},
        "actionable_by_horizon": {h: _stats(v) for h, v in actionable_by_horizon.items()},
        "by_score_band": {b: {h: _stats(v) for h, v in hs.items()} for b, hs in by_score_band.items()},
        "warnings": [],
    }

    if total_outcomes == 0:
        result["warnings"].append(
            "No signal outcomes have been evaluated yet. Signals need to be recorded and then "
            "given time to play out before any accuracy figure exists — this page will stay "
            "empty rather than show a placeholder number.")
    elif total_outcomes < MIN_MEANINGFUL_SAMPLE:
        result["warnings"].append(
            f"Only {total_outcomes} outcome(s) evaluated. Below {MIN_MEANINGFUL_SAMPLE} these "
            f"numbers are noise, not a track record — they are shown for transparency, not as "
            f"evidence the strategy works.")
    return result


def get_trade_performance(db) -> dict:
    """Realised performance of the user's own manually-recorded trades — separate from signal
    accuracy, because a signal being right and the user's execution being profitable are two
    different questions."""
    from services.portfolio_service import _fifo_walk, get_trades

    tickers = [r["ticker"] for r in
               db.execute("SELECT DISTINCT ticker FROM trades").fetchall()]
    all_sales = []
    for ticker in tickers:
        all_sales.extend(_fifo_walk(get_trades(db, ticker))["sales"])

    if not all_sales:
        return {"closed_trades": 0, "warnings": [
            "No completed (sold) trades recorded yet — realised performance will appear here "
            "once you record a sale."]}

    pnls = [s["realized_pnl"] for s in all_sales]
    pcts = [s["realized_pnl_pct"] for s in all_sales if s["realized_pnl_pct"] is not None]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p <= 0]

    out = {
        "closed_trades": len(all_sales),
        "total_realized_pnl": round(sum(pnls), 2),
        "win_rate_pct": round(len(wins) / len(pnls) * 100, 1) if pnls else None,
        "avg_return_pct": round(sum(pcts) / len(pcts), 2) if pcts else None,
        "best_trade_pct": round(max(pcts), 2) if pcts else None,
        "worst_trade_pct": round(min(pcts), 2) if pcts else None,
        "avg_win": round(sum(wins) / len(wins), 2) if wins else None,
        "avg_loss": round(sum(losses) / len(losses), 2) if losses else None,
        "recent_sales": sorted(all_sales, key=lambda s: s["trade_date"], reverse=True)[:20],
        "warnings": [],
    }
    if len(all_sales) < MIN_MEANINGFUL_SAMPLE:
        out["warnings"].append(
            f"Only {len(all_sales)} closed trade(s). This is far too small a sample to judge a "
            f"strategy — treat these figures as a record of what happened, not as a measured "
            f"edge.")
    return out
