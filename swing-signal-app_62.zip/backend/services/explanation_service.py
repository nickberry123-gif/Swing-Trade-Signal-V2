"""
Phase 9: plain-English explanations of a signal.

=== A NOTE ON "AI-GENERATED" ===

The original spec asked for AI-generated explanations "built strictly from the engine's own
calculated numbers". Those two requirements pull in opposite directions: a language model is
free to write a fluent sentence containing a number nobody computed. Since this app's governing
rule is never to present invented data as real, the DEFAULT generator here is deterministic — it
composes prose from the engine's actual output and literally cannot introduce a fact the engine
did not produce.

An optional LLM path exists for users who want more natural phrasing. It is:
  - off unless ANTHROPIC_API_KEY is configured,
  - given ONLY the computed numbers, with explicit instructions to invent nothing,
  - always labelled with the model that wrote it, so no reader can mistake LLM prose for a
    deterministic derivation.

Whichever path runs, `generator` is recorded alongside the text and `source_facts` stores the
exact numbers it was built from, so any sentence can be audited against the engine afterwards.
"""
import json
import os
from datetime import datetime, timezone

RULE_BASED = "rule-based"

_COMPONENTS = [
    ("score_long_trend", 20, "long-term trend"),
    ("score_short_trend", 10, "short-term trend"),
    ("score_momentum", 15, "momentum"),
    ("score_rsi_pullback", 10, "pullback quality"),
    ("score_volume", 10, "volume"),
    ("score_support_resistance", 10, "position vs support/resistance"),
    ("score_relative_strength", 10, "relative strength"),
    ("score_market_regime", 5, "market regime"),
    ("score_news", 5, "news"),
    ("score_earnings_risk", 5, "earnings risk"),
]

_LABEL_OPENERS = {
    "STRONG BUY": "This is one of the strongest setups in the tracked universe right now.",
    "BUY": "This looks like a reasonable entry candidate.",
    "WATCH": "This is worth watching, but it is not an entry yet.",
    "NO TRADE": "There is no trade here at the moment.",
    "AVOID": "This is one to stay away from for now.",
    "NO DATA": "There is not enough data to say anything about this stock right now.",
}


def _pct_of_max(value, maximum):
    if value is None or not maximum:
        return None
    return value / maximum * 100


def _strengths_and_weaknesses(signal: dict):
    strong, weak, missing = [], [], []
    for key, maximum, label in _COMPONENTS:
        value = signal.get(key)
        if value is None:
            missing.append(label)
            continue
        pct = _pct_of_max(value, maximum)
        if pct >= 75:
            strong.append((label, value, maximum))
        elif pct <= 35:
            weak.append((label, value, maximum))
    return strong, weak, missing


def _join(items: list) -> str:
    items = [str(i) for i in items]
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    return ", ".join(items[:-1]) + " and " + items[-1]


def build_source_facts(signal: dict) -> dict:
    """The complete, explicit set of numbers any explanation is allowed to reference."""
    return {
        "ticker": signal.get("ticker"),
        "signal_label": signal.get("signal_label"),
        "score_total": signal.get("score_total"),
        "score_max_currently_available": signal.get("score_max_currently_available"),
        "strategy_setup": signal.get("strategy_setup"),
        "trend_label": signal.get("trend_label"),
        "market_regime": signal.get("market_regime"),
        "current_price": signal.get("current_price"),
        "ideal_buy": signal.get("ideal_buy"),
        "buy_zone_low": signal.get("buy_zone_low"),
        "buy_zone_high": signal.get("buy_zone_high"),
        "max_entry": signal.get("max_entry"),
        "primary_target": signal.get("primary_target"),
        "expected_upside_pct": signal.get("expected_upside_pct"),
        "long_term_thesis": signal.get("long_term_thesis"),
        "long_term_quality": signal.get("long_term_quality"),
        "earnings_blackout": signal.get("earnings_blackout"),
        "days_until_estimated_earnings": signal.get("days_until_estimated_earnings"),
        **{k: signal.get(k) for k, _, _ in _COMPONENTS},
    }


def generate_rule_based(signal: dict) -> str:
    """Deterministic prose. Every number it prints comes from `signal`; it has no capacity to
    invent one."""
    label = signal.get("signal_label") or "NO DATA"
    ticker = signal.get("ticker", "This stock")

    if label == "NO DATA" or signal.get("score_total") is None:
        return (f"{_LABEL_OPENERS['NO DATA']} "
                f"{signal.get('data_error') or 'No price data is currently available.'}")

    score = signal.get("score_total")
    max_avail = signal.get("score_max_currently_available") or 100
    parts = [f"{ticker} scores {score} out of a possible {max_avail}. {_LABEL_OPENERS.get(label, '')}"]

    strong, weak, missing = _strengths_and_weaknesses(signal)
    if strong:
        parts.append("What's working: " + _join([f"{l} ({v}/{m})" for l, v, m in strong]) + ".")
    if weak:
        parts.append("What's holding it back: " + _join([f"{l} ({v}/{m})" for l, v, m in weak]) + ".")

    setup = signal.get("strategy_setup")
    if setup and setup != "NONE":
        setup_text = {
            "PULLBACK": "The setup is a pullback: an established uptrend has dipped back toward "
                        "support, which is where this strategy prefers to buy.",
            "BREAKOUT": "The setup is a breakout: price is pushing to recent highs on heavier "
                        "than usual volume.",
            "DEEP_CORRECTION": "The setup is a deep correction: price has fallen well below its "
                               "50-day average but is holding above longer-term support. These "
                               "carry more risk than a standard pullback.",
        }.get(setup)
        if setup_text:
            parts.append(setup_text)

    price = signal.get("current_price")
    ideal, low, high = signal.get("ideal_buy"), signal.get("buy_zone_low"), signal.get("buy_zone_high")
    max_entry = signal.get("max_entry")
    if price is not None and low is not None and high is not None:
        if low <= price <= high:
            parts.append(f"At ${price} it is currently inside the buy zone (${low} – ${high}).")
        elif price > high:
            over = (price - high) / high * 100
            parts.append(
                f"At ${price} it sits {over:.1f}% above the top of the buy zone "
                f"(${low} – ${high}), so buying now means paying up. The strategy would wait "
                f"for a pullback rather than chase, and would not pay more than ${max_entry}.")
        else:
            parts.append(f"At ${price} it is below the buy zone (${low} – ${high}), which "
                         f"usually means the trend is under pressure — check why before buying.")

    target, upside = signal.get("primary_target"), signal.get("expected_upside_pct")
    if target is not None and upside is not None:
        parts.append(f"The primary target is ${target}, about {upside}% above the ideal buy "
                     f"of ${ideal}.")

    thesis = signal.get("long_term_thesis")
    if thesis:
        quality = signal.get("long_term_quality")
        base = thesis.split(" ")[0]
        qual_txt = f" (quality score {quality}/100)" if quality is not None else ""
        if base in ("STRONG", "HEALTHY"):
            parts.append(f"On the long-term view the business looks {base.lower()}{qual_txt}, "
                         f"so if a swing trade went against you, holding is a defensible option.")
        elif base in ("DETERIORATING", "BROKEN"):
            parts.append(f"Be careful: the long-term quality picture is {base.lower()}{qual_txt}. "
                         f"This strategy depends on being willing to hold a losing trade, and "
                         f"that is harder to justify here.")
        elif base == "UNAVAILABLE":
            parts.append("The long-term quality score is unavailable, so there is no fundamental "
                         "check on whether this is a business you'd want to hold through a "
                         "drawdown.")

    if signal.get("earnings_blackout"):
        days = signal.get("days_until_estimated_earnings")
        parts.append(f"An estimated earnings report is about {days} day(s) away. Holding through "
                     f"earnings is an overnight gap risk, and that date is estimated from filing "
                     f"history rather than confirmed by the company.")

    regime = signal.get("market_regime")
    if regime:
        parts.append(f"The broader market regime is {regime}, which is part of the score above.")

    if missing:
        parts.append(f"Note: {_join(missing)} could not be evaluated, so the score is out of "
                     f"{max_avail} rather than 100.")

    parts.append("This is analysis, not advice, and no order is placed by this app.")
    return " ".join(p for p in parts if p)


def generate_with_llm(signal: dict, api_key: str, model: str = "claude-sonnet-4-5") -> tuple:
    """Optional LLM phrasing, tightly grounded. Returns (text, generator_label).

    The model receives ONLY the computed facts and is told not to introduce numbers. Any failure
    falls back to the deterministic generator rather than surfacing an error to the user.
    """
    facts = build_source_facts(signal)
    try:
        import requests  # noqa: PLC0415
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": api_key, "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            json={
                "model": model,
                "max_tokens": 500,
                "system": (
                    "You explain stock trading signals in plain English for a non-technical "
                    "reader. You are given a JSON object of numbers computed by a scoring "
                    "engine. Rules you must follow exactly:\n"
                    "1. Use ONLY numbers present in the JSON. Never introduce, estimate or "
                    "round to a different figure, and never mention a metric that is absent.\n"
                    "2. Never predict what the price will do. Describe what the engine measured.\n"
                    "3. Never recommend an action. This is analysis, not advice.\n"
                    "4. Never mention a stop-loss; this system has none by design.\n"
                    "5. If a value is null, say it is unavailable rather than guessing.\n"
                    "6. 4-6 sentences, calm and concrete."
                ),
                "messages": [{"role": "user", "content": json.dumps(facts)}],
            },
            timeout=30,
        )
        if resp.status_code != 200:
            return generate_rule_based(signal), RULE_BASED
        blocks = resp.json().get("content", [])
        text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text").strip()
        if not text:
            return generate_rule_based(signal), RULE_BASED
        return text, model
    except Exception:  # noqa: BLE001 — never let explanation generation break the signal page
        return generate_rule_based(signal), RULE_BASED


def generate_explanation(db, signal: dict, prefer_llm: bool = False, persist: bool = True) -> dict:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if prefer_llm and api_key:
        text, generator = generate_with_llm(signal, api_key)
    else:
        text, generator = generate_rule_based(signal), RULE_BASED

    facts = build_source_facts(signal)
    result = {
        "ticker": signal.get("ticker"),
        "generator": generator,
        "generator_note": (
            "Composed deterministically from the engine's own numbers — it cannot introduce a "
            "figure the engine did not calculate."
            if generator == RULE_BASED else
            f"Written by {generator}, given only the engine's computed numbers and instructed "
            f"to invent nothing. Cross-check any figure against the breakdown above."
        ),
        "llm_available": bool(api_key),
        "text": text,
        "source_facts": facts,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }

    if persist and signal.get("score_total") is not None:
        try:
            db.execute(
                "INSERT INTO explanations (ticker, generator, score_total, signal_label, text, "
                "source_facts_json) VALUES (?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(ticker, generator, score_total, signal_label) DO NOTHING",
                (signal.get("ticker"), generator, signal.get("score_total"),
                 signal.get("signal_label"), text, json.dumps(facts)),
            )
            db.commit()
        except Exception:  # noqa: BLE001 — persistence is a nicety, never a blocker
            db.rollback()

    return result
