"""
Long-term quality score (0-100) — the real, fundamentals-based version that replaces Phase 3's
explicitly-labeled technical-only placeholder.

This is the score that answers the user's actual core premise: "if a swing trade goes wrong and
I end up holding this stock, am I still comfortable owning it?" It is therefore built ONLY from
audited financial statement data (SEC XBRL), never from price action — price already drives the
100-point trading score, and letting it drive the quality score too would just be the same
signal counted twice wearing a different hat.

Eight criteria, 12.5 points each. Any criterion whose underlying data is missing is EXCLUDED
(not scored zero), and the final score is rescaled across whatever was actually available, with
`coverage_pct` reported so a score built from 3 of 8 criteria is never mistaken for a complete
assessment.
"""
import json

CRITERIA_POINTS = 12.5

# (key, label, thresholds) — thresholds are (full_points_at, half_points_at) and are documented
# as reasonable large-cap heuristics, not precise academic cutoffs.
THRESHOLDS = {
    "revenue_growth_pct": (10.0, 3.0),
    "eps_growth_pct": (10.0, 3.0),
    "gross_margin_pct": (45.0, 30.0),
    "operating_margin_pct": (20.0, 10.0),
    "fcf_margin_pct": (15.0, 7.0),
    "roic_pct": (15.0, 8.0),
}

LABELS = {
    "revenue_growth_pct": "Revenue growth (YoY)",
    "eps_growth_pct": "EPS growth (YoY)",
    "gross_margin_pct": "Gross margin",
    "operating_margin_pct": "Operating margin",
    "fcf_margin_pct": "Free cash flow margin",
    "roic_pct": "Return on invested capital (proxy)",
    "balance_sheet": "Balance sheet strength (cash vs debt)",
    "fcf_positive": "Free cash flow is positive",
}


def _score_threshold(value, full_at, half_at):
    if value is None:
        return None
    if value >= full_at:
        return CRITERIA_POINTS
    if value >= half_at:
        return CRITERIA_POINTS * 0.6
    if value > 0:
        return CRITERIA_POINTS * 0.25
    return 0.0


def compute_quality_score(fundamentals: dict) -> dict:
    """`fundamentals` is a plain dict of the Fundamentals dataclass fields (or a DB row).
    Returns {score, coverage_pct, criteria_evaluated, criteria_total, breakdown, thesis,
    warnings} — or score=None when nothing at all could be evaluated."""
    breakdown = []
    earned = 0.0
    possible = 0.0

    for key, (full_at, half_at) in THRESHOLDS.items():
        value = fundamentals.get(key)
        pts = _score_threshold(value, full_at, half_at)
        if pts is None:
            breakdown.append({"criterion": LABELS[key], "points": None, "max": CRITERIA_POINTS,
                              "value": None, "note": "not reported in the source filings"})
            continue
        earned += pts
        possible += CRITERIA_POINTS
        breakdown.append({"criterion": LABELS[key], "points": round(pts, 2),
                          "max": CRITERIA_POINTS, "value": value,
                          "note": f"{value:.1f}% (full credit at {full_at}%)"})

    # Balance sheet: cash vs total debt.
    cash, debt = fundamentals.get("total_cash"), fundamentals.get("total_debt")
    if cash is not None and debt is not None:
        if debt == 0:
            pts, note = CRITERIA_POINTS, "no long-term debt reported"
        else:
            ratio = cash / debt
            if ratio >= 1.5:
                pts, note = CRITERIA_POINTS, f"cash is {ratio:.1f}x total debt"
            elif ratio >= 0.75:
                pts, note = CRITERIA_POINTS * 0.6, f"cash is {ratio:.1f}x total debt"
            elif ratio >= 0.3:
                pts, note = CRITERIA_POINTS * 0.25, f"cash is {ratio:.1f}x total debt"
            else:
                pts, note = 0.0, f"cash is only {ratio:.2f}x total debt"
        earned += pts
        possible += CRITERIA_POINTS
        breakdown.append({"criterion": LABELS["balance_sheet"], "points": round(pts, 2),
                          "max": CRITERIA_POINTS, "value": None, "note": note})
    else:
        breakdown.append({"criterion": LABELS["balance_sheet"], "points": None,
                          "max": CRITERIA_POINTS, "value": None,
                          "note": "cash and/or debt not reported"})

    # Free cash flow positive.
    fcf = fundamentals.get("free_cash_flow")
    if fcf is not None:
        pts = CRITERIA_POINTS if fcf > 0 else 0.0
        earned += pts
        possible += CRITERIA_POINTS
        breakdown.append({"criterion": LABELS["fcf_positive"], "points": round(pts, 2),
                          "max": CRITERIA_POINTS, "value": fcf,
                          "note": "positive" if fcf > 0 else "negative"})
    else:
        breakdown.append({"criterion": LABELS["fcf_positive"], "points": None,
                          "max": CRITERIA_POINTS, "value": None,
                          "note": "free cash flow not computable from the source filings"})

    criteria_total = len(THRESHOLDS) + 2
    criteria_evaluated = int(round(possible / CRITERIA_POINTS)) if possible else 0

    if possible <= 0:
        return {
            "score": None, "coverage_pct": 0.0, "criteria_evaluated": 0,
            "criteria_total": criteria_total, "breakdown": breakdown,
            "thesis": "UNAVAILABLE",
            "warnings": ["No fundamental data could be evaluated — quality score unavailable. "
                         "This is not a score of zero; it means the data is missing."],
        }

    score = round(earned / possible * 100, 1)
    coverage = round(possible / (criteria_total * CRITERIA_POINTS) * 100, 1)

    if score >= 80:
        thesis = "STRONG"
    elif score >= 62:
        thesis = "HEALTHY"
    elif score >= 45:
        thesis = "WATCH"
    elif score >= 28:
        thesis = "DETERIORATING"
    else:
        thesis = "BROKEN"

    warnings = []
    if coverage < 60:
        warnings.append(
            f"Only {criteria_evaluated} of {criteria_total} quality criteria had data available "
            f"({coverage:.0f}% coverage) — treat this score as partial."
        )
    return {
        "score": score, "coverage_pct": coverage, "criteria_evaluated": criteria_evaluated,
        "criteria_total": criteria_total, "breakdown": breakdown, "thesis": thesis,
        "warnings": warnings,
    }


def breakdown_to_json(result: dict) -> str:
    return json.dumps({
        "score": result.get("score"), "coverage_pct": result.get("coverage_pct"),
        "criteria_evaluated": result.get("criteria_evaluated"),
        "criteria_total": result.get("criteria_total"),
        "breakdown": result.get("breakdown", []), "warnings": result.get("warnings", []),
    })
