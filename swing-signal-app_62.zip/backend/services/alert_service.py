"""
Phase 8: alerts.

HARD RULE: an alert is a notification to a human and nothing else. No alert in this system
places, modifies or cancels an order, moves money, or changes any position. There is no code
path from an alert to a broker, and there must never be one. Alerts exist so the user can go and
look at something themselves and decide.

Deduplication matters more than it sounds: the dashboard polls every 15 seconds, and a naive
implementation would create "NVDA entered its buy zone" 240 times an hour until the price moved.
Each rule produces a stable `dedupe_key` describing the CONDITION (not the moment), and a key is
only re-alerted after DEDUPE_WINDOW has elapsed.
"""
import json
from datetime import datetime, timedelta, timezone

DEDUPE_WINDOW = timedelta(hours=12)

SEVERITY_INFO = "INFO"
SEVERITY_IMPORTANT = "IMPORTANT"
SEVERITY_URGENT = "URGENT"

# Fires when the estimated report is this close AND a position is open.
EARNINGS_WARN_DAYS = 7


# `created_at` is written by the database's own clock, which renders as "YYYY-MM-DD HH:MM:SS"
# (space-separated) on both SQLite and Postgres. Python's .isoformat() uses a "T" separator, and
# because these are TEXT columns the comparison is lexicographic: " " sorts before "T", so an
# isoformat cutoff never matches any row and deduplication silently fails open. Matching the
# database's own format is what makes the comparison correct.
DB_TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def _recently_alerted(db, dedupe_key: str) -> bool:
    cutoff = (datetime.now(timezone.utc) - DEDUPE_WINDOW).strftime(DB_TIME_FORMAT)
    row = db.execute(
        "SELECT 1 FROM alerts WHERE dedupe_key = ? AND created_at >= ? LIMIT 1",
        (dedupe_key, cutoff)).fetchone()
    return row is not None


def create_alert(db, ticker, alert_type, message, severity=SEVERITY_INFO, details=None,
                 dedupe_key=None) -> bool:
    """Returns True if an alert was actually created, False if suppressed as a duplicate."""
    dedupe_key = dedupe_key or f"{ticker}:{alert_type}"
    if _recently_alerted(db, dedupe_key):
        return False
    db.execute(
        "INSERT INTO alerts (ticker, alert_type, severity, message, details_json, dedupe_key) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (ticker, alert_type, severity, message, json.dumps(details or {}), dedupe_key),
    )
    db.commit()
    return True


# ---------------------------------------------------------------- rules

def evaluate_signal_alerts(db, signal: dict, held_quantity: float = 0.0,
                           earnings_info: dict | None = None) -> list:
    """Evaluate every alert rule for one stock. Returns the alerts actually created.

    `held_quantity` comes from the user's manual trade journal — several rules only make sense
    when a position is genuinely open (there is no point warning about earnings risk on a stock
    the user doesn't own).
    """
    created = []
    ticker = signal.get("ticker")

    if signal.get("data_status") == "UNAVAILABLE" or signal.get("signal_label") == "NO DATA":
        if create_alert(db, ticker, "DATA_FEED_FAILURE",
                        f"{ticker}: market data unavailable — signals cannot be computed. "
                        f"{signal.get('data_error') or ''}".strip(),
                        SEVERITY_IMPORTANT, {"data_error": signal.get("data_error")},
                        dedupe_key=f"{ticker}:DATA_FEED_FAILURE"):
            created.append("DATA_FEED_FAILURE")
        return created

    label = signal.get("signal_label")
    price = signal.get("current_price")
    score = signal.get("score_total")

    # 1. A fresh actionable buy signal. Keyed on the label so BUY -> STRONG BUY re-alerts.
    if label in ("BUY", "STRONG BUY") and held_quantity <= 0:
        if create_alert(
            db, ticker, "BUY_SIGNAL",
            f"{ticker} is showing {label} at {score}/100. Ideal buy "
            f"${signal.get('ideal_buy')}, maximum entry ${signal.get('max_entry')}.",
            SEVERITY_IMPORTANT,
            {"score": score, "ideal_buy": signal.get("ideal_buy"),
             "max_entry": signal.get("max_entry")},
            dedupe_key=f"{ticker}:BUY_SIGNAL:{label}",
        ):
            created.append("BUY_SIGNAL")

    # 2. Price has entered the buy zone — the moment the user actually wants to know about.
    low, high = signal.get("buy_zone_low"), signal.get("buy_zone_high")
    if (price is not None and low is not None and high is not None
            and low <= price <= high and held_quantity <= 0):
        if create_alert(
            db, ticker, "ENTER_BUY_ZONE",
            f"{ticker} at ${price} is inside its buy zone (${low} – ${high}).",
            SEVERITY_IMPORTANT, {"price": price, "buy_zone_low": low, "buy_zone_high": high},
            dedupe_key=f"{ticker}:ENTER_BUY_ZONE",
        ):
            created.append("ENTER_BUY_ZONE")

    # 3. Targets reached — only relevant while actually holding.
    if held_quantity > 0 and price is not None:
        for name, target in (("TARGET1", signal.get("target1")),
                             ("PRIMARY_TARGET", signal.get("primary_target")),
                             ("TARGET3", signal.get("target3"))):
            if target is not None and price >= target:
                if create_alert(
                    db, ticker, "TARGET_REACHED",
                    f"{ticker} at ${price} has reached {name.replace('_', ' ').lower()} "
                    f"(${target}). Consider whether to take profit — this app will not do it "
                    f"for you.",
                    SEVERITY_IMPORTANT, {"price": price, "target": target, "which": name},
                    dedupe_key=f"{ticker}:TARGET_REACHED:{name}",
                ):
                    created.append(f"TARGET_REACHED:{name}")

    # 4. Signal deteriorated while holding — this is the sell-signal notification.
    if held_quantity > 0 and label in ("NO TRADE", "AVOID"):
        if create_alert(
            db, ticker, "SIGNAL_LOST",
            f"{ticker} has dropped to {label} ({score}/100) while you hold a position. "
            f"Review whether the trade thesis still stands.",
            SEVERITY_URGENT, {"score": score, "label": label},
            dedupe_key=f"{ticker}:SIGNAL_LOST:{label}",
        ):
            created.append("SIGNAL_LOST")

    # 5. Earnings approaching while holding — overnight gap risk this strategy shouldn't take
    #    blindly. Explicitly labelled as an estimate, because it is one.
    if held_quantity > 0 and earnings_info:
        days = earnings_info.get("days_until_estimated_report")
        if days is not None and 0 <= days <= EARNINGS_WARN_DAYS:
            if create_alert(
                db, ticker, "EARNINGS_APPROACHING",
                f"{ticker} has an ESTIMATED earnings report in ~{days} day(s) and you hold a "
                f"position. This date is estimated from SEC filing history, not confirmed by "
                f"the company — verify before relying on it.",
                SEVERITY_IMPORTANT,
                {"days": days, "estimated_date": earnings_info.get("estimated_next_report"),
                 "confidence": earnings_info.get("estimate_confidence")},
                dedupe_key=f"{ticker}:EARNINGS_APPROACHING:{earnings_info.get('estimated_next_report')}",
            ):
                created.append("EARNINGS_APPROACHING")

    # 6. Long-term thesis deteriorating — the "should I still be comfortable owning this?" alarm.
    thesis = (signal.get("long_term_thesis") or "").split(" ")[0]
    if thesis in ("DETERIORATING", "BROKEN") and held_quantity > 0:
        if create_alert(
            db, ticker, "THESIS_DETERIORATING",
            f"{ticker}'s long-term quality thesis is {thesis} while you hold a position. The "
            f"premise of this strategy is being comfortable holding through a bad trade — "
            f"re-examine whether that still applies here.",
            SEVERITY_URGENT,
            {"thesis": thesis, "quality": signal.get("long_term_quality")},
            dedupe_key=f"{ticker}:THESIS_DETERIORATING:{thesis}",
        ):
            created.append("THESIS_DETERIORATING")

    return created


def evaluate_all(db, signals: list, holdings_by_ticker: dict | None = None,
                 earnings_by_ticker: dict | None = None) -> dict:
    holdings_by_ticker = holdings_by_ticker or {}
    earnings_by_ticker = earnings_by_ticker or {}
    total = []
    for s in signals:
        ticker = s.get("ticker")
        total.extend(evaluate_signal_alerts(
            db, s, held_quantity=holdings_by_ticker.get(ticker, 0.0),
            earnings_info=earnings_by_ticker.get(ticker)))
    return {"created": len(total), "types": total}


# ---------------------------------------------------------------- queries

def get_alerts(db, unacknowledged_only: bool = False, limit: int = 100) -> list:
    sql = ("SELECT id, ticker, alert_type, severity, message, details_json, created_at, "
           "acknowledged FROM alerts")
    params = []
    if unacknowledged_only:
        sql += " WHERE acknowledged = 0"
    sql += " ORDER BY created_at DESC, id DESC LIMIT ?"
    params.append(limit)
    rows = db.execute(sql, tuple(params)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["details"] = json.loads(d.pop("details_json") or "{}")
        except (TypeError, ValueError):
            d["details"] = {}
        out.append(d)
    return out


def acknowledge(db, alert_id: int) -> bool:
    row = db.execute("SELECT 1 FROM alerts WHERE id = ?", (alert_id,)).fetchone()
    if not row:
        return False
    db.execute("UPDATE alerts SET acknowledged = 1 WHERE id = ?", (alert_id,))
    db.commit()
    return True


def acknowledge_all(db) -> int:
    rows = db.execute("SELECT COUNT(*) AS c FROM alerts WHERE acknowledged = 0").fetchone()
    count = rows["c"] if rows else 0
    db.execute("UPDATE alerts SET acknowledged = 1 WHERE acknowledged = 0")
    db.commit()
    return count


def unacknowledged_count(db) -> int:
    row = db.execute("SELECT COUNT(*) AS c FROM alerts WHERE acknowledged = 0").fetchone()
    return row["c"] if row else 0
