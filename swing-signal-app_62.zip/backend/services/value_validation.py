"""
VALUE — the pre-registered performance validation. Part F of VALUE-SPECIFICATION.md.

THE QUESTION, AS AGREED BEFORE ANY OF THIS WAS BUILT:

    For fundamentally investable companies, when a stock was cheap relative to its own available
    historical valuation, were subsequent returns generally better than when that same stock was
    expensive?

WHY FORWARD RETURN IS THE RIGHT OUTCOME HERE, AND WAS THE WRONG ONE FOR COMPANY HEALTH. Study 2
established that fundamental quality and subsequent returns are different questions, which is why
C1 must not be judged on returns. Value makes the opposite claim: it asserts something about PRICE.
If paying a low multiple does not improve subsequent returns, Value has failed at its own stated
purpose. The outcome that was wrong for Health is exactly right here.

RUN ONCE. No parameter sweeps, no thresholds invented after seeing an outcome, no re-running until
a number reads well. Everything below — cohort spacing, forward window, minimum sample sizes, the
statistics computed and what would count as failure — was fixed in the specification you approved
before the model produced a single number.

THE TWO PRICE BASES, KEPT APART. The valuation uses RAW bars, because a multiple pairs a price with
an as-reported per-share figure and the two must share a basis. The RETURN uses ADJUSTED bars,
because a total return between two dates must account for splits and dividends. Using either one
for the other's job is the specific error this whole phase was built to avoid.

WHAT THIS STUDY CANNOT DO. One year is short for a valuation signal — cheapness typically expresses
itself over three to five years — and the nine cohorts overlap heavily, so they are nowhere near
nine independent observations. This can detect a strong effect. It cannot establish the absence of
a weak one, and no better design would rescue it: the binding constraint is the 27 July 2020 data
floor, not the method.
"""
from datetime import date, datetime, timedelta, timezone

from services import fundamentals_history_service as fh
from services import value_bars_service as vb
from services import value_service as vs

# ---- FROZEN AT PRE-REGISTRATION. Changing any of these after seeing a result is the failure ----
# ---- mode this project exists to avoid. -------------------------------------------------------
FIRST_COHORT = "2023-07-27"      # the data floor plus the 3 years of history a percentile needs
COHORT_MONTHS = 3                # quarterly
FORWARD_DAYS = 365               # one year
MIN_COMPANIES_PER_COHORT = 25
MIN_GROUP_SIZE = 8               # below this a group is reported as underpowered, not interpreted

BANDS = ("CHEAP", "FAIR", "EXPENSIVE")
COMPONENTS = ("fcf_yield_pct", "ev_to_ebit", vs.EV_SALES, "pe_ratio")
_VINTAGE_LIMIT = 80


def cohort_dates(last_bar: str, first: str = FIRST_COHORT) -> list:
    """Quarterly scoring dates that still have a full forward year of prices after them.

    A cohort whose forward window runs past the end of the data is EXCLUDED rather than measured
    over a shorter period. Mixing horizons would make the averages incomparable while still
    producing a number.
    """
    try:
        cutoff = date.fromisoformat(last_bar[:10]) - timedelta(days=FORWARD_DAYS)
        d = date.fromisoformat(first)
    except (ValueError, TypeError):
        return []
    out = []
    while d <= cutoff:
        out.append(d.isoformat())
        month = d.month + COHORT_MONTHS
        year = d.year + (month - 1) // 12
        d = date(year, (month - 1) % 12 + 1, min(d.day, 28))
    return out


# --------------------------------------------------------------------------------------------
# Returns — ADJUSTED basis
# --------------------------------------------------------------------------------------------
def price_on_or_after(bars: list, day: str):
    """The first ADJUSTED close on or after `day`. Markets close; a date is not always a bar."""
    for b in bars:
        if (b.get("ts") or "")[:10] >= day[:10]:
            c = vs._v(b.get("close_adj"))
            if c and c > 0:
                return c, b["ts"][:10]
    return None, None


def forward_return(bars: list, start: str, days: int = FORWARD_DAYS):
    """Total return over `days`, on the adjusted series. None when either end is missing.

    Adjusted rather than raw ON PURPOSE: a return must include splits and dividends. This is the
    one place in the Value pillar where the adjusted series is the correct input.
    """
    p0, d0 = price_on_or_after(bars, start)
    if not p0:
        return None
    try:
        target = (date.fromisoformat(start[:10]) + timedelta(days=days)).isoformat()
    except (ValueError, TypeError):
        return None
    p1, d1 = price_on_or_after(bars, target)
    if not p1:
        return None
    return (p1 / p0 - 1.0) * 100.0


# --------------------------------------------------------------------------------------------
# Statistics — deliberately local, so Value depends on no other pillar's code
# --------------------------------------------------------------------------------------------
def _ranks(values: list) -> list:
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        avg = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def spearman(xs: list, ys: list):
    """Rank correlation. No p-value: this sample cannot support a significance claim, and
    printing one would invite exactly the over-reading the pre-registration forbids."""
    pairs = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
    if len(pairs) < 3:
        return None
    rx, ry = _ranks([p[0] for p in pairs]), _ranks([p[1] for p in pairs])
    n = len(pairs)
    mx, my = sum(rx) / n, sum(ry) / n
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    den = (sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry)) ** 0.5
    return round(num / den, 4) if den else None


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return round(sum(xs) / len(xs), 2) if xs else None


def _median(xs):
    xs = sorted(x for x in xs if x is not None)
    if not xs:
        return None
    m = len(xs) // 2
    return round(xs[m] if len(xs) % 2 else (xs[m - 1] + xs[m]) / 2.0, 2)


# --------------------------------------------------------------------------------------------
# The run
# --------------------------------------------------------------------------------------------
def observations_for(db, tickers: list, dates: list) -> list:
    """One row per (company, cohort date) that produced a Value AND a full forward year.

    Every point-in-time protection is inherited rather than reimplemented: `vs.evaluate` is given
    `as_of`, and it filters bars and filings itself, applies the expanding-window percentile, the
    three-year minimum, the two-metric minimum, the currency refusal and the post-filing split
    withhold. Nothing here reaches around it.
    """
    rows = []
    for ticker in tickers:
        bars = vb.bars(db, ticker)                       # full series; evaluate() cuts it
        if not bars:
            continue
        filings = fh.history_all_vintages(db, ticker, as_of_filed=None, limit=_VINTAGE_LIMIT)
        for d in dates:
            scored = vs.evaluate(ticker, bars, filings, as_of=d)
            if scored["value"] is None:
                continue
            # The forward window is measured on the SAME stored bars, adjusted basis.
            fwd = forward_return(bars, d)
            if fwd is None:
                continue
            row = {"ticker": ticker, "date": d, "value": scored["value"],
                   "verdict": scored["verdict"], "forward_return_pct": round(fwd, 2),
                   "spread": scored.get("spread"), "components": {}}
            for name in COMPONENTS:
                m = scored["metrics"].get(name) or {}
                if m.get("status") == vs.OK:
                    row["components"][name] = m.get("percentile")
            rows.append(row)
    return rows


def _band_stats(rows: list) -> dict:
    out = {}
    for band in BANDS:
        group = [r["forward_return_pct"] for r in rows if r["verdict"] == band]
        out[band] = {
            "n": len(group), "mean_return_pct": _mean(group), "median_return_pct": _median(group),
            "powered": len(group) >= MIN_GROUP_SIZE,
        }
    return out


def run(db, tickers: list) -> dict:
    """The whole pre-registered study. One call, one result, reported as produced."""
    tickers = sorted(tickers)
    last = max((vb.stored_summary(db, t)["last"] or "") for t in tickers)
    dates = cohort_dates(last) if last else []
    rows = observations_for(db, tickers, dates)

    per_cohort = []
    for d in dates:
        cohort = [r for r in rows if r["date"] == d]
        entry = {
            "date": d, "n": len(cohort),
            "powered": len(cohort) >= MIN_COMPANIES_PER_COHORT,
            # PRIMARY, pre-registered: does a cheaper Value precede a better forward year?
            "spearman_value_vs_forward_return": spearman(
                [r["value"] for r in cohort], [r["forward_return_pct"] for r in cohort]),
            "bands": _band_stats(cohort),
            "mean_forward_return_pct": _mean([r["forward_return_pct"] for r in cohort]),
            # SECONDARY B, pre-registered: does the three-metric mean beat its own components?
            "components": {
                name: spearman([r["components"].get(name) for r in cohort],
                               [r["forward_return_pct"] for r in cohort])
                for name in COMPONENTS
            },
        }
        per_cohort.append(entry)

    powered = [c for c in per_cohort if c["powered"]]
    primary = [c["spearman_value_vs_forward_return"] for c in powered
               if c["spearman_value_vs_forward_return"] is not None]

    pooled_bands = _band_stats(rows)
    monotonic = None
    if all(pooled_bands[b]["mean_return_pct"] is not None for b in BANDS):
        monotonic = (pooled_bands["CHEAP"]["mean_return_pct"]
                     > pooled_bands["FAIR"]["mean_return_pct"]
                     > pooled_bands["EXPENSIVE"]["mean_return_pct"])

    # DESCRIPTIVE ONLY, and labelled as such wherever it appears. Recorded because the 50-stock
    # run showed the headline can conceal disagreement. No threshold is derived from it and no
    # predictive claim is made about it — doing either would be inventing a rule after seeing the
    # data, which is the thing the pre-registration exists to prevent.
    spreads = [r["spread"] for r in rows if r.get("spread") is not None]
    spread_desc = {
        "observations_with_spread": len(spreads),
        "mean_spread": _mean(spreads), "median_spread": _median(spreads),
        "over_25": sum(1 for s in spreads if s > 25),
        "over_50": sum(1 for s in spreads if s > 50),
        "over_75": sum(1 for s in spreads if s > 75),
        "note": ("Descriptive only. Spread does not enter the Value score, the verdict, any gate "
                 "or any statistic above. No threshold is derived from it and no predictive claim "
                 "is made about it."),
    }

    return {
        "cohorts": len(dates), "cohort_dates": dates,
        "observations": len(rows),
        "companies": len({r["ticker"] for r in rows}),
        "forward_window_days": FORWARD_DAYS,
        "per_cohort": per_cohort,
        "primary": {
            "statistic": "Spearman(Value percentile, forward 1-year total return)",
            "per_powered_cohort": primary,
            "positive_cohorts": sum(1 for s in primary if s > 0),
            "negative_cohorts": sum(1 for s in primary if s < 0),
            "mean": _mean(primary),
            "predominantly_positive": (sum(1 for s in primary if s > 0) > len(primary) / 2)
            if primary else None,
        },
        "pooled_bands": pooled_bands,
        "monotonic_cheap_gt_fair_gt_expensive": monotonic,
        "components_pooled": {
            name: spearman([r["components"].get(name) for r in rows],
                           [r["forward_return_pct"] for r in rows])
            for name in COMPONENTS
        },
        "spread_descriptive": spread_desc,
        "company_health": {
            "included": False,
            "note": ("The approved Part F pre-registration contains NO Company Health component. "
                     "Adding one now would be changing the methodology after seeing the Value "
                     "output. 'Fundamentally investable' describes the 50-stock universe, which "
                     "was selected on that basis; it is not a Company Health gate applied here."),
        },
        "limitations": [
            "Raw price history begins 2020-07-27, so the March 2020 crash is absent. The cheap end "
            "of every company's range is higher than it would otherwise be.",
            "Three years of history plus one forward year must both fit inside 6.06 years, so the "
            "forward window is ONE YEAR — short for a valuation signal, which typically expresses "
            "itself over three to five.",
            "Cohorts are quarterly and overlap heavily. They are not independent observations and "
            "no significance is claimed.",
            "Fifty companies selected in 2026, none of which failed. Survivorship applies exactly "
            "as it did to Studies 1 and 2.",
            "Fundamentals are ANNUAL, so a multiple can be up to a year stale between filings.",
            "No p-values. This sample cannot support a significance claim.",
        ],
    }
