"""
Operating profit: reported where reported, reconciled where it can be, UNKNOWN where it cannot.

WHY THIS IS ITS OWN MODULE. Twenty-two of the fifty companies — Eli Lilly among them — do not
print an operating income subtotal. Their income statements run revenue → costs → income before
taxes. That is a legitimate presentation choice, not missing data. But seven metrics hang off
operating profit (operating margin, ROIC, ROIC persistence, EV/EBIT, EBITDA, net debt to EBITDA,
interest coverage), so one absent subtotal empties three of the six Company Health categories.

THE DERIVATION I FIRST PROPOSED WAS WRONG, and it is worth recording why rather than quietly
replacing it. I suggested:

    operating profit = pre-tax income + interest expense

That is not operating profit. Pre-tax income already contains investment income, foreign-exchange
gains and losses, one-off settlements, equity-method earnings and asset disposals. Adding back
only interest leaves every other non-operating item inside, so in a year with a large investment
gain the "operating" figure is inflated by something that has nothing to do with operations — and
it is inflated silently, in the direction that makes the company look better.

WHAT IS DONE INSTEAD. Three reconciliation routes, tried in order of how little they assume:

    A. revenue − total costs and expenses          (assumes nothing; a stated total)
    B. gross profit − operating expenses           (assumes the two lines are complementary)
    C. pre-tax income − ALL non-operating items    (only when the aggregate is itself reported)

Route C is the corrected version of my original suggestion: it removes the whole non-operating
aggregate the company reports, not just interest, and it is refused outright when that aggregate
is absent — because "the items I happen to know about" is not the same as "all of them".

THEN IT IS CHECKED, NOT TRUSTED:
  * the result must be arithmetically possible against revenue and gross profit;
  * where two routes are available they must agree, and a material disagreement means UNKNOWN
    rather than picking the flattering one;
  * the basis is reported alongside the number, always, so DERIVED never reads as reported.

The rule the whole module exists to serve: **never force a value simply to improve coverage.**
UNKNOWN is a perfectly good answer and it is the right one more often than a reconciliation that
nearly works.
"""

REPORTED = "reported"
UNKNOWN = None

# How far two independent reconciliations may differ and still be believed, as a fraction of
# revenue. Expressed against revenue rather than against each other because a percentage gap
# between two small numbers is meaningless — a company with an operating profit near zero would
# fail any relative test for a rounding difference.
AGREEMENT_TOLERANCE_OF_REVENUE = 0.01     # 1% of the top line

# An operating profit larger than revenue is arithmetically impossible for an operating company.
# A loss larger than revenue is possible but rare, so the downside bound is looser: it is there to
# catch a sign or scale error, not to have an opinion about how badly a company may do.
MAX_MARGIN = 1.0
MIN_MARGIN = -3.0


def _v(x):
    try:
        return float(x) if x is not None else None
    except (TypeError, ValueError):
        return None


def _plausible(value, revenue, gross_profit):
    """Could this number be an operating profit for a company with this revenue?

    Three checks, each of which has a real failure behind it:
      * bigger than revenue — the cost line captured only part of the costs;
      * bigger than gross profit — operating expenses cannot be negative in aggregate, so an
        operating profit above gross profit means one of the two inputs is measuring something
        else (this is the United Rentals shape of error, one level down);
      * absurd relative to revenue — a sign or scale error.
    """
    if value is None or revenue is None or revenue <= 0:
        return False, "no revenue to check the result against"
    margin = value / revenue
    if margin > MAX_MARGIN:
        return False, (f"the reconciled operating profit ({value:,.0f}) exceeds revenue "
                       f"({revenue:,.0f}), so the cost lines cannot be complete")
    if margin < MIN_MARGIN:
        return False, (f"the reconciled operating profit ({value:,.0f}) is more than three times "
                       f"revenue in the negative, which indicates a sign or scale error")
    if gross_profit is not None and value > gross_profit + abs(revenue) * 1e-6:
        return False, (f"the reconciled operating profit ({value:,.0f}) exceeds gross profit "
                       f"({gross_profit:,.0f}), which is not possible once operating expenses "
                       f"are deducted")
    return True, None


def reconcile(period: dict, gross_profit=None) -> dict:
    """Resolve one period's operating profit.

    `period` is a stored fundamentals_history row. `gross_profit` may be passed in when it was
    itself derived (revenue − cost of revenue), so the two derivations stay consistent.

    Returns {value, basis, checked, rejected, note}:
      value    — the figure, or None
      basis    — "reported", a description of the derivation used, or None when UNKNOWN
      checked  — every route that was attempted, with its result, so the reasoning is inspectable
      rejected — routes that produced a number which failed validation, and why
    """
    out = {"value": None, "basis": None, "checked": [], "rejected": [], "note": None}

    reported = _v(period.get("operating_income"))
    revenue = _v(period.get("revenue"))
    if gross_profit is None:
        gross_profit = _v(period.get("gross_profit"))
    gross_profit = _v(gross_profit)

    # ---- 1. Reported always wins. No derivation is better than the company's own subtotal. ----
    if reported is not None:
        out.update({"value": reported, "basis": REPORTED})
        out["checked"].append({"route": REPORTED, "value": reported, "used": True})
        return out

    candidates = []

    # ---- A. revenue − total costs and expenses ----
    costs = _v(period.get("costs_and_expenses"))
    if revenue is not None and costs is not None:
        candidates.append(("derived: revenue less total costs and expenses", revenue - costs))

    # ---- B. gross profit − operating expenses ----
    opex = _v(period.get("operating_expenses"))
    if gross_profit is not None and opex is not None:
        candidates.append(("derived: gross profit less operating expenses", gross_profit - opex))

    # ---- C. pre-tax income − the reported non-operating aggregate ----
    # Refused when the aggregate is absent. Adding back interest alone — my original proposal —
    # would leave investment income, disposals and one-off items inside the result.
    pretax = _v(period.get("pretax_income"))
    nonop = _v(period.get("nonoperating_income_expense"))
    if pretax is not None and nonop is not None:
        candidates.append(("derived: pre-tax income less reported non-operating items",
                           pretax - nonop))
    elif pretax is not None:
        out["checked"].append({
            "route": "pre-tax income less non-operating items", "value": None, "used": False,
            "why_not": "the company reports pre-tax income but no aggregate of non-operating "
                       "items, so the walk back to an operating figure would silently keep "
                       "investment income, disposals and one-off items inside it"})

    # ---- validate each candidate ----
    valid = []
    for basis, value in candidates:
        ok, why = _plausible(value, revenue, gross_profit)
        out["checked"].append({"route": basis, "value": round(value, 2), "used": ok,
                               **({"why_not": why} if not ok else {})})
        if ok:
            valid.append((basis, value))
        else:
            out["rejected"].append({"route": basis, "value": round(value, 2), "why": why})

    if not valid:
        out["note"] = ("Operating profit is not reported and could not be reconciled from the "
                       "income statement. Left UNKNOWN rather than forced — every metric that "
                       "depends on it is reported UNKNOWN too.")
        return out

    # ---- where two routes agree, that agreement is the evidence ----
    if len(valid) > 1 and revenue:
        spread = max(v for _, v in valid) - min(v for _, v in valid)
        if spread > abs(revenue) * AGREEMENT_TOLERANCE_OF_REVENUE:
            out["note"] = (
                f"Two independent reconciliations of operating profit disagree by "
                f"{spread:,.0f} on revenue of {revenue:,.0f}. One of the cost lines is measuring "
                f"something other than what its name suggests, so neither figure is used.")
            out["basis"] = None
            return out

    basis, value = valid[0]
    out.update({"value": value, "basis": basis})
    if len(valid) > 1:
        out["note"] = (f"Reconciled by {len(valid)} independent routes which agree to within "
                       f"1% of revenue.")
    return out


def ebitda(operating_profit, depreciation_amortisation):
    """EBITDA from an operating profit that has already been resolved and validated.

    Takes the resolved figure rather than the raw row so a rejected reconciliation cannot reach
    EBITDA through a side door — if operating profit is UNKNOWN, so is this.
    """
    op, dna = _v(operating_profit), _v(depreciation_amortisation)
    if op is None or dna is None:
        return None
    return op + dna
