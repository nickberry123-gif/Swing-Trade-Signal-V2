"""Which share count may stand behind a current market capitalisation, and how sure we are of it.

WHY THIS MODULE EXISTS
======================
Regeneron was valued using a cover-page share count of 93,955,110 from a document filed in
**July 2012**. The company's actual count in 2026 is about 104.8 million. The resulting market
capitalisation was roughly 10% too small — and that is the whole problem, because 10% too small
is not absurd. The price/earnings ratio came out at 16.8 instead of 18.4. Every plausibility
check passed. Nothing looked wrong.

The earlier Booking Holdings defect was the easy version of this: a share basis so wrong it
produced a P/E of 1.20, which cannot be true and was therefore caught. A share count wrong by a
*plausible* margin produces a *plausible* valuation, and no threshold on the answer will ever
find it. The error has to be caught on the INPUT — by asking whether the count is entitled to be
used at all — because by the time it reaches the output it is indistinguishable from a real one.

Investigation established that this is not a selection bug. Every non-dimensional share concept
Regeneron publishes stops in late 2012:

    dei:EntityCommonStockSharesOutstanding    9 facts, newest filed 2012-07-25
    us-gaap:CommonStockSharesOutstanding     19 facts, newest filed 2012-10-24
    us-gaap:CommonStockSharesIssued          22 facts, newest filed 2012-10-24
    us-gaap:TreasuryStockCommonShares        31 facts, newest filed 2026-07-30

Treasury stock is current because it is not broken out by share class; everything that IS broken
out by class disappeared from SEC's `companyfacts` the moment the company began tagging per
class. So there is no aggregate route left, including issued-minus-treasury — the issued side is
just as stale. The count genuinely is not obtainable from the API this app reads.

That leaves one honest question, which is what this module answers: given that the newest actual
count may be missing, WHICH figure is allowed to stand behind a market capitalisation, and what
must be said about it.

THE RULE THAT DOES THE WORK
===========================
Not an age in days. The primary test is cadence-relative:

    A share count may feed current valuation only if it comes from the most recent filing this
    app holds for the company, or the one immediately before it.

This is self-calibrating and needs no filer classification. It catches Regeneron immediately and
for exactly the right reason: the app was holding a Regeneron 10-K **filed 2026-02-04** while
valuing the company on a count from a filing published in **2012**. It already knew about a newer
document and used an older one. No number of days expresses that as directly, and any fixed
threshold that caught it would have been chosen to catch it.

Two filings of latitude rather than one, because the two stores fill up independently: a
cover-page count and an annual figure arrive from different documents, and a company should not
lose its valuation because the newest filing happened to be the one carrying the other kind.

Day counts sit UNDERNEATH as a backstop, for the case where the newest filing this app holds is
itself old. They are derived from the filing calendar rather than picked:

    quarterly source — a new document every ~90 days, filed up to ~45 days after the period it
                       covers, so ~135 days is the longest a current count should ever be.
                       200 allows one late cycle.
    annual source    — 365 + ~60 days of filing lag = ~425. 450 rounds it up.

CADENCE IS MEASURED, NOT ASSUMED
================================
Which backstop applies is decided by how often filings ACTUALLY arrive in this app, not by what
the company theoretically files. That distinction matters: Alphabet is a quarterly filer whose
cover-page count is absent from `companyfacts` entirely, so this app only ever sees its annual
figure. Judging it against a 200-day quarterly rule would withhold Alphabet's market
capitalisation for half of every year over a data-availability gap rather than a data problem.
Measuring the cadence of what actually arrives gives Alphabet the annual allowance, which is the
truthful description of what this app knows about Alphabet.

WHAT THE FALLBACK IS, AND WHY IT IS BASIC RATHER THAN DILUTED
=============================================================
When no actual count qualifies, the weighted-average share count from the income statement is
used instead, labelled ESTIMATED so that nothing downstream can mistake it for a real one.

It must be BASIC, not diluted. Diluted deliberately counts shares that do not exist yet —
options, restricted stock, convertibles — because that is the right denominator for earnings per
share. It is the wrong denominator for a market capitalisation, because those shares cannot be
bought. Measured on Regeneron against the actual all-class count of 104,839,032 from the 10-Q
filed 2026-04-29:

    2012 cover-page count      93,955,110    -10.4%    <- what the app was using
    weighted-average diluted  108,600,000     +3.6%
    weighted-average basic    104,600,000     -0.23%   <- what this module selects

Basic is still an average across a year rather than a point in time, so it lags a company that
is buying back or issuing heavily — roughly half the annual change. That is why it is published
as ESTIMATED and never as a count.

WHAT IS NOT HERE
================
No cover-page extraction from filing documents. The figure IS reachable — FilingSummary.xml
names R1.htm, and Regeneron's R1.htm carries Class A 1,817,146 and Common 103,902,660 — but that
route serves exactly one company in this fifty, adds HTML shape-parsing and two extra requests
per company per run, and carries a class-aggregation double-count risk that cannot be validated
against a single example. Building it would repeat the pattern this work exists to stop.
"""
from __future__ import annotations

from datetime import date, datetime, timezone

# ---- provenance -----------------------------------------------------------------------------
# Structured, not prose. Every metric built on a share count carries one of these, so a reader
# never has to infer from a sentence whether a number rests on a measurement or an estimate.
ACTUAL = "ACTUAL"                  # a real count, from the newest filing carrying one
ACTUAL_ANNUAL = "ACTUAL_ANNUAL"    # a real count, but from the annual filing rather than a newer one
ESTIMATED = "ESTIMATED"            # weighted-average shares — an average, not a count
UNKNOWN = "UNKNOWN"                # nothing qualifies; publish no market capitalisation

#: Provenances a market capitalisation may be published under.
PUBLISHABLE = (ACTUAL, ACTUAL_ANNUAL, ESTIMATED)

#: Provenances that are a genuine point-in-time count of shares in issue.
COUNTED = (ACTUAL, ACTUAL_ANNUAL)

QUARTERLY = "QUARTERLY"
ANNUAL = "ANNUAL"

# ---- the thresholds, all derived above rather than chosen ------------------------------------
QUARTERLY_MAX_AGE_DAYS = 200
ANNUAL_MAX_AGE_DAYS = 450

#: Filings closer together than this mean documents are arriving more often than once a year.
QUARTERLY_CADENCE_MAX_GAP_DAYS = 150

#: How far back to look when measuring cadence. Three years is enough to see the rhythm and
#: short enough that a company's filing history from a decade ago cannot distort it — which
#: matters here, because Regeneron's only cover-page filings are from 2012.
CADENCE_LOOKBACK_DAYS = 1100

#: How many of the most recent filings may carry the count. See the module note.
ACCEPTED_FILING_DEPTH = 2

# ---- corporate actions -----------------------------------------------------------------------
# A share count and a price can also be on different bases because the SHARES changed, not
# because the count went stale. Carvana split five-for-one on 5 May 2026, three months after the
# filing its basis came from, and the result was a market capitalisation of $9.2bn against a real
# $104bn — with no staleness to detect, because the filing was recent.
#
# A count changing by this much between two consecutive filings is a corporate action. It is not
# a buyback and it is not an issuance: no company retires two thirds of its stock or triples it in
# a quarter. Booking's stored counts go 31,673,346 → 774,878,436 between the filings of
# 2026-02-18 and 2026-04-28, a factor of 24.5.
#
# THE FACTOR IS NEVER APPLIED. This is a detector, and only a detector. The ratio is recorded so a
# person can see what was found, and the response is always to prefer a basis from AFTER the
# action or to publish nothing — never to multiply a stale count by a number this app worked out.
SPLIT_LIKE_RATIO = 3.0

# ---- economic equity -------------------------------------------------------------------------
# The share count can also be right and still not describe the whole company.
#
# In an umbrella-partnership structure the listed entity owns part of an operating company and the
# rest is held as units exchangeable into listed shares. Those units are the same economic equity
# as the quoted stock, but they sit outside the share count — so a market capitalisation built
# from that count covers a fraction of the business, and every enterprise-value figure built on it
# understates by the same fraction.
#
# THE FIRST VERSION OF THIS CHECK WAS WRONG AND IS WORTH RECORDING, BECAUSE ITS FAILURE IS THE
# WHOLE REASON THE RULE BELOW IS SHAPED AS IT IS.
#
# It asked whether the diluted share count exceeded the basic count by a wide margin, reasoning
# that an exchangeable block of units would show up as dilution. That was measured on Carvana's
# FY2025 annual figures, where the gap is 62.9% — 137,634,000 basic against 224,277,000 diluted.
# It then failed in production, because the units dropped out of the diluted count in the very
# next filing: Carvana's Q2 2026 gap is 3.1%, 717,691,000 against 739,960,000. The change that
# fixed the stock split moved the app onto the quarterly figures and thereby removed the signal
# the check depended on, and $48.1bn was published for a company worth $104.29bn.
#
# So the test must not depend on how a company happens to present dilution in one filing. It asks
# the epistemic question directly instead:
#
#     Can this app demonstrate that the share count it is using covers ALL the equity?
#
# Two conditions, and both are facts rather than proxies:
#
#   1. The selected basis is a weighted AVERAGE rather than a real outstanding count. A cover-page
#      or balance-sheet count of shares outstanding is an aggregate over every class by
#      construction. A weighted-average basic count is the denominator of earnings per share for
#      ONE class, and there is nothing in it that promises to cover the others.
#   2. A material part of the consolidated equity belongs to somebody other than the listed
#      shareholders.
#
# Condition 2 is measured as noncontrolling interest over TOTAL consolidated equity — parent plus
# noncontrolling — because that ratio is literally the fraction of the equity the share count
# fails to represent. Parent equity alone is the wrong denominator: it is negative for companies
# that have bought back more stock than they have retained earnings (HCA's is -$6.0bn), which
# makes the ratio meaningless exactly where a clear answer is needed.
#
# THE 5% THRESHOLD IS THE ORDINARY MATERIALITY CONVENTION, not a number chosen to fit these
# companies. Five per cent of a relevant base is the long-standing rule of thumb in financial
# reporting for whether a misstatement matters — and SEC Staff Accounting Bulletin 99 is explicit
# that it is a starting point rather than a safe harbour, which is why this is paired with
# condition 1 rather than used alone. Applying it here says: if more than a twentieth of the
# equity sits outside the shares being counted, a market capitalisation built from that count is
# materially incomplete.
#
# Measured on this universe, with the separation being an order of magnitude rather than a
# borderline call — so the exact threshold is not load-bearing:
#     Carvana   $762m NCI on $4,203m total equity  = 18.1%   -> withheld
#     Palantir  $101m NCI on $7,488m total equity  =  1.3%   -> published
#
# WHAT THIS RULE DOES NOT DO. It does not reconstruct the missing equity. No exchangeable unit is
# counted, no economic share count is derived, no ownership percentage is inferred. The rule
# exists to withhold an unreliable valuation, and withholding is its entire output — which also
# means firing wrongly costs coverage and never correctness.
ECONOMIC_EQUITY_MATERIAL_NCI = 0.05


def _as_date(value):
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value)[:10]).date()
    except (TypeError, ValueError):
        return None


def _days_between(earlier, later):
    a, b = _as_date(earlier), _as_date(later)
    if a is None or b is None:
        return None
    return (b - a).days


def _today():
    return datetime.now(timezone.utc).date().isoformat()


def _number(value):
    """A positive quantity, or None. Share counts and balances that must be positive to mean
    anything go through here."""
    try:
        out = float(value) if value is not None else None
    except (TypeError, ValueError):
        return None
    return out if (out is not None and out > 0) else None


def _signed_number(value):
    """A quantity that may legitimately be negative — shareholders' equity, most obviously, which
    is below zero for companies that have bought back more stock than they have retained."""
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def known_filing_dates(*date_lists) -> list:
    """Every distinct filing date this app holds for one company, newest first.

    The union of the two stores on purpose. A cover-page count and an annual figure come from
    different documents filed on different days, and the question "is there a newer filing than
    the one this count came from" can only be answered by looking at both.
    """
    seen = set()
    for group in date_lists:
        for value in group or ():
            parsed = _as_date(value)
            if parsed is not None:
                seen.add(parsed.isoformat())
    return sorted(seen, reverse=True)


def measure_cadence(filed_dates, reference_date=None) -> dict:
    """How often filings actually reach this app for one company.

    Uses the MEDIAN gap rather than the mean so that one unusual interval — an amended filing
    days after the original, or a gap while a company was late — cannot move the answer. A
    company with fewer than two filings inside the window has no measurable rhythm, and is given
    the annual allowance: the app has no evidence it files more often, and the conservative
    choice is the one that does not withhold a figure over an absence of evidence.
    """
    reference = _as_date(reference_date) or _as_date(_today())
    recent = []
    for value in filed_dates or ():
        parsed = _as_date(value)
        if parsed is None:
            continue
        age = (reference - parsed).days
        if 0 <= age <= CADENCE_LOOKBACK_DAYS:
            recent.append(parsed)
    recent.sort(reverse=True)

    if len(recent) < 2:
        return {"cadence": ANNUAL, "max_age_days": ANNUAL_MAX_AGE_DAYS,
                "median_gap_days": None, "filings_in_window": len(recent),
                "why": ("fewer than two filings in the last three years, so no filing rhythm can "
                        "be measured — the annual allowance is used rather than assuming a "
                        "cadence the evidence does not show")}

    gaps = sorted((recent[i] - recent[i + 1]).days for i in range(len(recent) - 1))
    middle = len(gaps) // 2
    median_gap = gaps[middle] if len(gaps) % 2 else (gaps[middle - 1] + gaps[middle]) / 2.0

    if median_gap <= QUARTERLY_CADENCE_MAX_GAP_DAYS:
        return {"cadence": QUARTERLY, "max_age_days": QUARTERLY_MAX_AGE_DAYS,
                "median_gap_days": median_gap, "filings_in_window": len(recent),
                "why": (f"filings arrive about every {median_gap:.0f} days, so a current count "
                        f"should never be more than {QUARTERLY_MAX_AGE_DAYS} days old")}
    return {"cadence": ANNUAL, "max_age_days": ANNUAL_MAX_AGE_DAYS,
            "median_gap_days": median_gap, "filings_in_window": len(recent),
            "why": (f"filings reach this app about every {median_gap:.0f} days, so the annual "
                    f"allowance of {ANNUAL_MAX_AGE_DAYS} days applies — this describes what this "
                    f"app receives, not how often the company files")}


def _qualify(filed, accepted, cadence, reference_date):
    """Whether a figure from `filed` is entitled to stand behind a current valuation."""
    filed_iso = _as_date(filed)
    filed_iso = filed_iso.isoformat() if filed_iso else None
    if filed_iso is None:
        return False, "the filing date of this figure is not recorded, so its age cannot be checked"

    age = _days_between(filed_iso, reference_date)
    if filed_iso not in accepted:
        newest = accepted[0] if accepted else "an unknown date"
        return False, (
            f"it comes from a filing published {filed_iso}, but this app already holds a more "
            f"recent filing for this company ({newest}). A count is only current if it comes "
            f"from the newest filing, or the one before it"
            + (f" — this one is {age:,} days old" if age is not None else ""))

    if age is not None and age > cadence["max_age_days"]:
        return False, (
            f"it comes from a filing published {filed_iso}, {age:,} days ago, beyond the "
            f"{cadence['max_age_days']}-day limit for this company — {cadence['why']}")
    return True, None


#: Ranking WITHIN one filing date. Freshness decides first — a basis from a later filing is on
#: the later side of any corporate action, which matters more than what kind of measurement it is.
#: Only when two candidates come from the SAME filing does the measurement type break the tie, and
#: then a real count beats an average.
PROVENANCE_RANK = {ACTUAL: 0, ACTUAL_ANNUAL: 1, ESTIMATED: 2}


def detect_split_like_action(stored_counts) -> dict | None:
    """A corporate action read off consecutive cover-page counts already in the database.

    Returns {between, ratio, direction, source} or None. Never returns a factor to apply — see
    SPLIT_LIKE_RATIO. The direction is MEASURED (the count went up, or it went down) rather than
    inferred from a published ratio, which is the part that cannot be trusted: SEC's own
    `StockholdersEquityNoteStockSplitConversionRatio1` is 0.2 for Carvana's five-for-one and 10
    for NVIDIA's ten-for-one, so its orientation carries no reliable meaning.

    `stored_counts` must be newest-filing first.
    """
    rows = [r for r in (stored_counts or []) if r.get("shares") and r.get("filed")]
    for newer, older in zip(rows, rows[1:]):
        a, b = float(newer["shares"]), float(older["shares"])
        if a <= 0 or b <= 0 or newer["filed"] == older["filed"]:
            continue
        ratio = a / b
        if ratio >= SPLIT_LIKE_RATIO or ratio <= 1.0 / SPLIT_LIKE_RATIO:
            return {
                "between": [older["filed"], newer["filed"]],
                "ratio": round(ratio, 4),
                "direction": "forward" if ratio > 1 else "reverse",
                "source": "cover-page share counts already stored by this app",
                "detail": (f"the count moved from {b:,.0f} to {a:,.0f} between the filings of "
                           f"{older['filed']} and {newer['filed']} — a factor of {ratio:,.2f}, "
                           f"which no buyback or issuance produces"),
            }
    return None


def action_is_in_scope(action, selected_basis_filed, provenance) -> bool:
    """Is this corporate action relevant to the figures actually being published?

    Detection has to look at the whole history — a candidate filed before any action must be
    rejected, and that means knowing the action exists. Reporting has to be narrower, or the
    warning describes the past rather than the present. NVIDIA's 2024 ten-for-one is a real event
    and is entirely irrelevant to a share basis filed in May 2026.

    In scope when the selected basis is NOT provably on the later side of the action:

      * `between[1]` is the filing by which the action had certainly occurred. A basis filed on or
        after that date sits after the action, so there is nothing to say.
      * An UNKNOWN basis is always in scope. If the action is why nothing could be published, that
        is precisely when a person needs to be told.
    """
    if not action:
        return False
    if provenance == UNKNOWN:
        return True
    window = action.get("between") or []
    known_by = window[1] if len(window) > 1 else action.get("effective_date")
    basis_date, known_by = _as_date(selected_basis_filed), _as_date(known_by)
    if basis_date is None or known_by is None:
        return True          # cannot show it is out of scope, so say so rather than stay quiet
    return basis_date < known_by


def economic_equity_incomplete(latest_row, provenance) -> dict | None:
    """Whether the selected share basis can be shown to cover all the company's equity.

    Returns a withholding reason, or None. See the note above ECONOMIC_EQUITY_MATERIAL_NCI for
    why this asks about the KIND of count and the ownership split rather than about dilution.

    NOTHING IS RECONSTRUCTED HERE. This function never estimates the missing units, never derives
    an economic share count and never infers an ownership percentage. Its only output is a
    refusal, which is the correct shape for a question this app cannot answer from the data it
    reads.
    """
    if provenance not in (ESTIMATED,):
        # An outstanding-share count — cover page or balance sheet — is an aggregate across every
        # class by construction, so the question does not arise. HCA reports a $3.3bn
        # noncontrolling interest and is unaffected for exactly this reason.
        return None

    minority = _number((latest_row or {}).get("minority_interest"))
    if minority is None:
        return None

    parent_equity = _signed_number((latest_row or {}).get("stockholders_equity"))
    if parent_equity is None:
        return None
    total_equity = parent_equity + minority
    if total_equity <= 0:
        # Cannot demonstrate the interest is immaterial, so it is not assumed to be. Conservative
        # in the only direction that costs coverage rather than correctness.
        share = None
    else:
        share = minority / total_equity
        if share < ECONOMIC_EQUITY_MATERIAL_NCI:
            return None

    portion = (f"{share * 100:.1f}% of the consolidated equity" if share is not None
               else "an unquantifiable share of the consolidated equity, because total equity is "
                    "not positive")
    return {
        "minority_interest": minority,
        "parent_equity": parent_equity,
        "total_equity": total_equity,
        "nci_share_of_total_equity_pct": round(share * 100, 2) if share is not None else None,
        "why": (f"the share basis for this company is a weighted-average count, which is the "
                f"denominator of earnings per share for one class of stock and carries no promise "
                f"of covering the others — and {portion} belongs to holders other than the listed "
                f"shareholders (a noncontrolling interest of {minority:,.0f} against total equity "
                f"of {total_equity:,.0f}). A market capitalisation built from that count would "
                f"therefore describe only part of the company, and every enterprise-value figure "
                f"built on it would understate by the same fraction. This app does not attempt to "
                f"reconstruct the missing equity — it withholds the figure instead."),
    }


def resolve(cover_count, latest_row, filed_dates, reference_date=None,
            share_period=None, corporate_action=None) -> dict:
    """Pick the share basis, or refuse to pick one.

    `cover_count`  — the newest stored cover-page count, or None
    `latest_row`   — the newest annual history row (shares_outstanding, basic_shares, ...)
    `filed_dates`  — every filing date this app holds for the company (see `known_filing_dates`)
    `reference_date` — the date the price is from; today when omitted

    Returns a dict that always carries `provenance`, and carries `shares` only when that
    provenance is publishable. The rejected candidates travel with it, because "why is this
    company's market capitalisation missing" must be answerable from the result rather than by
    re-running anything.
    """
    reference = _as_date(reference_date)
    reference = reference.isoformat() if reference else _today()
    latest_row = latest_row or {}

    cadence = measure_cadence(filed_dates, reference)
    accepted = list(filed_dates or ())[:ACCEPTED_FILING_DEPTH]

    out = {
        "provenance": UNKNOWN,
        "shares": None,
        "source": None,
        "source_form": None,
        "source_filed": None,
        "as_of": None,
        "age_days": None,
        "cadence": cadence,
        "accepted_filings": accepted,
        "candidates": [],
        "rejected": [],
        "corporate_action": corporate_action,
        "economic_equity": None,
        "reason": None,
        "label": None,
    }

    annual_filed = latest_row.get("filed")

    # Level 1 — a real count from a cover page, quarterly or annual, whichever is newest.
    # Level 2 — the annual filing's own count, when no newer document carried one.
    # Level 3 — weighted-average basic shares. Level 3b — diluted, only if basic is absent.
    #
    # Every level faces the SAME qualification test. An estimate from a filing this app should
    # have superseded is no more usable than a count from one, and letting the fallback in
    # unchecked would rebuild the defect one level down.
    sp = share_period or {}
    period_filed = sp.get("filed")
    period_label_suffix = (f" for the period ending {sp.get('period_end')}"
                           if sp.get("period_end") else "")

    candidates = [
        (ACTUAL, _number((cover_count or {}).get("shares")), (cover_count or {}).get("filed"),
         (cover_count or {}).get("as_of"), (cover_count or {}).get("form"),
         "cover-page count", None),
        (ACTUAL_ANNUAL, _number(latest_row.get("shares_outstanding")), annual_filed,
         latest_row.get("period_end"), latest_row.get("form"),
         "shares outstanding reported in the annual filing", None),
        # THE QUARTERLY FIGURES, AND WHY THEY OUTRANK THE ANNUAL ONES WHEN THEY ARE NEWER.
        # A weighted average published after a corporate action is already on the post-action
        # basis, because the company restated it. That is the whole repair for a stock split, and
        # it needs no split factor: Carvana's Q2 2026 filing says 717,691,000 where its FY2025
        # filing said 137,634,000, and this app never divides one by the other.
        (ESTIMATED, _number(sp.get("basic_shares")), period_filed, sp.get("period_end"),
         sp.get("form"), "weighted-average basic shares" + period_label_suffix,
         "weighted-average basic shares over a reported period, not current shares outstanding"),
        (ESTIMATED, _number(sp.get("diluted_shares")), period_filed, sp.get("period_end"),
         sp.get("form"), "weighted-average diluted shares" + period_label_suffix,
         "weighted-average diluted shares over a reported period, not current shares outstanding "
         "— basic shares were not reported for it, and diluted includes shares that do not exist"),
        (ESTIMATED, _number(latest_row.get("basic_shares")), annual_filed,
         latest_row.get("period_end"), latest_row.get("form"),
         "weighted-average basic shares from the annual filing",
         "weighted-average basic shares, not current shares outstanding"),
        (ESTIMATED, _number(latest_row.get("diluted_shares")), annual_filed,
         latest_row.get("period_end"), latest_row.get("form"),
         "weighted-average diluted shares from the annual filing",
         "weighted-average diluted shares, not current shares outstanding — basic shares were "
         "not reported, and diluted includes shares that do not yet exist"),
    ]

    # FRESHNESS FIRST, MEASUREMENT TYPE SECOND. A basis from a later filing sits on the later side
    # of any corporate action in between, and being on the right side of a split matters more than
    # being a count rather than an average. Within one filing the tie goes to the real count.
    usable = [c for c in candidates if c[1] is not None]
    usable.sort(key=lambda c: ((_as_date(c[2]).isoformat() if _as_date(c[2]) else ""),
                               -PROVENANCE_RANK[c[0]]), reverse=True)
    out["candidates"] = [
        {"provenance": p, "source": src, "shares": sh,
         "filed": _as_date(f).isoformat() if _as_date(f) else None}
        for p, sh, f, _a, _fm, src, _l in usable]

    # EVERY CANDIDATE IS JUDGED, NOT JUST THE ONES AHEAD OF THE WINNER.
    #
    # An earlier version stopped at the first candidate that qualified, which meant a dangerous
    # candidate sitting further down the list was never evaluated and never appeared in the
    # rejected list. Regeneron's 2012 count silently vanished from the output the moment a better
    # basis was found — and "why is this company's number different from what I expected" has to
    # be answerable from the result rather than by re-running anything. The cost is a few
    # comparisons; the benefit is that the reject list is complete.
    chosen = None
    for provenance, shares, filed, as_of, form, source, label in usable:
        filed_iso = _as_date(filed).isoformat() if _as_date(filed) else None
        ok, why = _qualify(filed, accepted, cadence, reference)
        if ok:
            # A basis filed BEFORE a corporate action is on the wrong side of it, however recent
            # it is. Nothing is adjusted — the candidate is refused, and if none survives the
            # answer is UNKNOWN rather than a number multiplied by a factor this app invented.
            why = _predates_action(filed_iso, corporate_action, reference)
            ok = why is None
        if not ok:
            out["rejected"].append({"provenance": provenance, "source": source, "shares": shares,
                                    "filed": filed_iso, "why": why})
            continue
        if chosen is None:
            chosen = {
                "provenance": provenance,
                "shares": shares,
                "source": source,
                "source_form": form,
                "source_filed": filed_iso,
                "as_of": _as_date(as_of).isoformat() if _as_date(as_of) else None,
                "age_days": _days_between(filed, reference),
                "label": label,
            }

    if chosen is None:
        out["reason"] = _unknown_reason(out["rejected"])
        return out
    out.update(chosen)

    # THE LAST TEST, AND IT OVERRIDES A PERFECTLY GOOD COUNT. Everything above asks whether the
    # count is current. This asks whether it describes the whole company, which is a different
    # question and has a different answer for an umbrella-partnership structure.
    incomplete = economic_equity_incomplete(latest_row, out["provenance"])
    if incomplete:
        out["economic_equity"] = incomplete
        out["rejected"].append({"provenance": out["provenance"], "source": out["source"],
                                "shares": out["shares"], "filed": out["source_filed"],
                                "why": incomplete["why"]})
        out.update({"provenance": UNKNOWN, "shares": None, "label": None,
                    "reason": incomplete["why"]})
    return out


def _predates_action(filed_iso, corporate_action, reference):
    """Whether a basis filed on `filed_iso` sits on the wrong side of a known corporate action."""
    if not corporate_action or not filed_iso:
        return None
    window = corporate_action.get("between") or []
    effective = corporate_action.get("effective_date") or (window[0] if window else None)
    if not effective:
        return None
    if not (_as_date(filed_iso) and _as_date(effective)):
        return None
    if _as_date(filed_iso) > _as_date(effective):
        return None
    if _as_date(reference) and _as_date(effective) > _as_date(reference):
        return None      # the action is in the future relative to the date being scored
    return (f"it comes from a filing published {filed_iso}, before a corporate action "
            f"({corporate_action.get('direction') or 'basis-changing'}) identified from "
            f"{corporate_action.get('source')}: {corporate_action.get('detail') or effective}. "
            f"A share count from before the action cannot be multiplied by a price from after "
            f"it, and this app does not apply a correction factor of its own.")


def _unknown_reason(rejected):
    if not rejected:
        return ("no share count of any kind appears in the filings this app reads for this "
                "company, so no market capitalisation can be calculated")
    worst = rejected[0]
    return (f"no share count is current enough to stand behind a valuation. The best available "
            f"is {worst['source']} of {worst['shares']:,.0f}, and {worst['why']}. A market "
            f"capitalisation built on it would be wrong by however much the count has moved "
            f"since, which is exactly the kind of error that still produces a believable number.")


def describe(resolved: dict) -> str:
    """One sentence a person can check, for the diagnostic page."""
    if resolved["provenance"] == UNKNOWN:
        return resolved["reason"] or "no usable share basis"
    age = resolved.get("age_days")
    parts = [f"{resolved['provenance']}: {resolved['shares']:,.0f} shares from "
             f"{resolved['source']}"]
    if resolved.get("source_form"):
        parts.append(f"in the {resolved['source_form']}")
    if resolved.get("source_filed"):
        parts.append(f"filed {resolved['source_filed']}")
    if age is not None:
        parts.append(f"({age:,} days old)")
    if resolved.get("label"):
        parts.append(f"— {resolved['label']}")
    return " ".join(parts)
