"""
Storage and point-in-time reads for the dual-basis daily closes the Value pillar needs.

SEPARATE FROM `bars_service` ON PURPOSE. That module serves the adjusted series every other part of
the app uses, and its correctness is settled. Fetching a second basis through it would mean changing
a path that signals, backtests and the dashboard all depend on, to serve a pillar that does not
exist yet. This module writes to its own table and nothing else reads it.

TRANSFER COST. Six years of daily closes is about 1,520 rows per ticker, or roughly 76,000 rows for
the universe — a few megabytes once, written with executemany. Refetched only when asked, never on
a request path, and the per-ticker read moves tens of kilobytes. The Neon free tier allows 5 GB a
month and a previous incident spent it in under two days on repeated reads.
"""
from datetime import datetime, timedelta, timezone

from providers.base import ProviderError
from services import value_service
from services.market_service import get_provider

# The two bases fetched for every day. "all" is split- AND dividend-adjusted, which is what makes
# the ratio a complete corporate-action record rather than a split-only one.
RAW, ADJUSTED = "raw", "all"

# One trading day short of seven years. The floor is 27 July 2020 and Alpaca simply returns nothing
# earlier, so asking for more costs one request and removes any need to hard-code the floor into
# the fetch — the data decides where it starts, which is the point of recording it.
FETCH_YEARS = 7


def _rows_by_day(bars) -> dict:
    return {b.ts.date().isoformat(): b.close for b in bars if b.close}


def refresh(db, ticker: str, years: int = FETCH_YEARS) -> dict:
    """Fetch both bases for one ticker and upsert. Returns what happened, including failures."""
    ticker = ticker.upper()
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=int(years * 365.25))
    try:
        provider = get_provider()
        raw = _rows_by_day(provider.get_bars_with_adjustment(
            ticker, "1Day", start, end, RAW, limit=10000))
        adj = _rows_by_day(provider.get_bars_with_adjustment(
            ticker, "1Day", start, end, ADJUSTED, limit=10000))
    except ProviderError as e:
        return {"ticker": ticker, "status": "UNAVAILABLE", "error": str(e), "rows": 0}

    days = sorted(set(raw) | set(adj))
    if not days:
        return {"ticker": ticker, "status": "UNAVAILABLE",
                "error": "no bars returned on either basis", "rows": 0}

    now = datetime.now(timezone.utc).isoformat()
    rows = [(ticker, d, raw.get(d), adj.get(d), now) for d in days]
    db.executemany(
        """INSERT INTO value_raw_bars (ticker, ts, close_raw, close_adj, fetched_at)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(ticker, ts) DO UPDATE SET
               close_raw = excluded.close_raw,
               close_adj = excluded.close_adj,
               fetched_at = excluded.fetched_at""",
        rows)
    db.commit()
    return {"ticker": ticker, "status": "OK", "rows": len(rows),
            "first": days[0], "last": days[-1],
            # Recorded every refresh so that a rolling data window is visible as a change rather
            # than as a percentile that moves while appearing stable.
            "observed_floor": days[0],
            "floor_matches_expected": days[0] <= value_service.DATA_FLOOR_OBSERVED
            or days[0] == value_service.DATA_FLOOR_OBSERVED}


def bars(db, ticker: str, as_of: str | None = None) -> list:
    """Stored closes ascending, never later than `as_of`.

    The cutoff is applied in SQL rather than by the caller, for the same reason the fundamentals
    layer does it: a rule that depends on the next person remembering it is not a rule.
    """
    ticker = ticker.upper()
    cutoff = (as_of or datetime.now(timezone.utc).date().isoformat())[:10]
    rows = db.execute(
        """SELECT ts, close_raw, close_adj FROM value_raw_bars
           WHERE ticker = ? AND ts <= ? ORDER BY ts ASC""", (ticker, cutoff)).fetchall()
    return [{"ts": r["ts"], "close_raw": r["close_raw"], "close_adj": r["close_adj"]}
            for r in rows]


def stored_summary(db, ticker: str) -> dict:
    ticker = ticker.upper()
    r = db.execute(
        """SELECT COUNT(*) AS n, MIN(ts) AS first, MAX(ts) AS last
           FROM value_raw_bars WHERE ticker = ?""", (ticker,)).fetchone()
    return {"ticker": ticker, "rows": (r["n"] if r else 0) or 0,
            "first": r["first"] if r else None, "last": r["last"] if r else None}
