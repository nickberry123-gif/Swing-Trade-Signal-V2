"""
Relative strength: how a stock's return over a lookback period compares to SPY, QQQ, and its
mapped sector ETF, over 5 / 20 / 50 / 200 trading days (per project spec).

Pure calculation — callers pass in each series' close-price history already fetched via
bars_service; this module doesn't know about Alpaca, the DB, or HTTP.
"""
from services.indicators import compute_returns

PERIODS = (5, 20, 50, 200)

# Excess-return bands used to label relative strength qualitatively. Wider bands for longer
# lookbacks since normal drift accumulates over time — these are a reasonable heuristic, not
# a scientifically exact threshold, and are documented as such rather than presented as fact.
STRENGTH_BANDS = {5: 2.0, 20: 4.0, 50: 7.0, 200: 12.0}


def label_excess_return(period: int, excess: float | None) -> str | None:
    if excess is None:
        return None
    band = STRENGTH_BANDS.get(period, 5.0)
    if excess >= band:
        return "Strong"
    if excess <= -band:
        return "Weak"
    return "In-line"


def compute_relative_strength(stock_close, benchmark_closes: dict) -> dict:
    """
    stock_close: pandas Series of the stock's close prices (ascending).
    benchmark_closes: {"spy": Series, "qqq": Series, "sector": Series|None}

    Returns a flat dict: rs_spy_5d, rs_spy_20d, ..., rs_qqq_*, rs_sector_*, plus
    the raw stock/benchmark returns and qualitative labels for transparency.
    """
    stock_returns = compute_returns(stock_close, PERIODS)
    out = {"stock_returns": stock_returns, "labels": {}}

    for bench_key in ("spy", "qqq", "sector"):
        series = benchmark_closes.get(bench_key)
        if series is None or len(series) == 0:
            for p in PERIODS:
                out[f"rs_{bench_key}_{p}d"] = None
            continue
        bench_returns = compute_returns(series, PERIODS)
        for p in PERIODS:
            sr, br = stock_returns.get(p), bench_returns.get(p)
            excess = round(sr - br, 4) if (sr is not None and br is not None) else None
            out[f"rs_{bench_key}_{p}d"] = excess
            if bench_key == "spy":
                out["labels"][p] = label_excess_return(p, excess)

    return out
