"""
Build B2 — does the data actually support v3, and are the numbers it produces possible?

WHY THIS EXISTS RATHER THAN "THE FIELDS ARE POPULATED, SHIP IT"
--------------------------------------------------------------
This project's recurring failure is not missing data. It is CORRECT CODE PRODUCING IMPOSSIBLE
NUMBERS: unadjusted prices, a fundamentals mix-up, a +88,446% backtest return. Every one had
passing tests and a populated field. A report that only counts non-null values would have called
all three healthy.

So three separate jobs, reported separately and never merged into one comforting percentage:

  1. COVERAGE — is the input present, weighted exactly as the v3 spec weights it. Answers "would
     v3 clear its own 75% gate", which is what decides whether Build C can start.
  2. PLAUSIBILITY — could the computed figure be true. Outside a stated bound is IMPLAUSIBLE: a
     bug until proven otherwise.
  3. ANOMALIES — figures that are possible but suspicious. These are WARNINGS THAT PROMPT A LOOK,
     never rejections. A company is not wrong because its price-to-sales is unusual, and throwing
     out real data on an arbitrary threshold is its own kind of error.

FOUR VERDICTS, AND THE DIFFERENCES ARE THE WHOLE POINT
  OK           — computed, inside the bound
  DERIVED      — computed from a reconciliation rather than a reported figure, and labelled so
  IMPLAUSIBLE  — computed, outside the bound. A bug until shown otherwise.
  UNAVAILABLE  — could not be computed, with the reason. NOT a zero, and NOT a statement about
                 the company: "we have no share count" and "the company has no shares" are
                 different claims and only one of them is ever true.

INFERRED NIL is a fifth and narrower thing, used only where absence is itself evidence — see
`_nil_evidence`. It is never the global rule that a missing tag means zero.

CURRENCY. Every price-based metric refuses unless the fundamentals are in USD, because no FX
conversion exists anywhere in this app. The refusal names the currency rather than hiding.

THE STANDARD: correct data and correct calculations, not maximum coverage. Nothing here forces a
value to make a percentage look better.
"""
import logging
from datetime import datetime, timezone

from providers.alpaca_provider import BAR_ADJUSTMENT
from providers.edgar_concepts import HISTORY_VALUE_FIELDS
from services import eps_chain
from services import fundamentals_history_service as fh
from services import operating_profit as op
from services import company_health as ch
from services import share_basis

logger = logging.getLogger(__name__)

OK = "OK"
DERIVED = "DERIVED"
IMPLAUSIBLE = "IMPLAUSIBLE"
UNAVAILABLE = "UNAVAILABLE"
INFERRED_NIL = "INFERRED NIL"

# NOT APPLICABLE is distinct from UNAVAILABLE and the difference is not cosmetic. UNAVAILABLE
# means this app could not measure the thing. NOT APPLICABLE means the thing does not exist to be
# measured: interest coverage at a company with no debt, distribution sustainability at a company
# that distributes nothing. Both leave the denominator rather than scoring zero, but only one of
# them is a gap in our data — and a reader deserves to know which they are looking at.
NOT_APPLICABLE = "NOT APPLICABLE"

# Verdicts that mean "we have a usable number". DERIVED counts — a reconciled figure that passed
# validation is a real measurement, and the label exists for transparency, not to demote it.
# NOT APPLICABLE deliberately does NOT count: there is no number, and inventing one is the whole
# class of error this project exists to prevent.
USABLE = (OK, DERIVED, INFERRED_NIL)

# (low, high) bounds. These separate IMPOSSIBLE from UNUSUAL. They are not opinions about what
# makes a good company: a P/E of 300 is a real stock, a gross margin of 4,000% is a parsing bug.
BOUNDS = {
    "pe_ratio":            (0.0, 500.0),
    "enterprise_value":    (0.0, 1.2e13),
    "ev_to_ebit":          (0.0, 500.0),
    "ev_to_ebitda":        (0.0, 500.0),
    "fcf_yield_pct":       (-50.0, 50.0),
    "gross_margin_pct":    (-100.0, 100.0),
    "operating_margin_pct": (-200.0, 100.0),
    "fcf_margin_pct":      (-200.0, 100.0),
    "net_margin_pct":      (-500.0, 100.0),
    "roic_pct":            (-200.0, 500.0),
    "roe_pct":             (-500.0, 500.0),
    "roa_pct":             (-200.0, 200.0),
    "accruals_ratio":      (-2.0, 2.0),
    "interest_coverage":   (-1000.0, 10000.0),
    "net_debt_to_ebitda":  (-50.0, 50.0),
    "current_ratio":       (0.0, 50.0),
    # Widened deliberately, and the reason is recorded so it does not read as tuning: NVIDIA's
    # FY2024 diluted EPS went from $0.17 to $1.19 — real, reported, about +600%. A 300% ceiling
    # flagged a fact as a fault, and a check that flags real things teaches you to ignore it.
    "revenue_cagr_pct":    (-50.0, 500.0),
    "eps_cagr_pct":        (-100.0, 2000.0),
    "share_change_pct":    (-90.0, 500.0),
    "buyback_yield_pct":   (0.0, 30.0),
    "dividend_yield_pct":  (0.0, 30.0),
    "rnd_intensity_pct":   (0.0, 100.0),
    # NO BOUND ON market_cap. The old $100m-$10tn range was so wide it never fired — Booking's
    # wrong $6.5bn walked straight through it — and a check that never fires is worse than no
    # check, because it looks like one. Market capitalisation is now examined by the anomaly
    # tests below, which compare it against other things we know rather than against a range
    # somebody picked.
}

# ---- anomaly thresholds. WARNINGS, NOT GATES. -----------------------------------------------
# Crossing one of these means "look at this", never "discard this". Legitimate companies sit
# outside all of them: a business between funding rounds can have a bizarre price-to-sales, and
# dual-class or treasury-heavy structures make share counts differ for real accounting reasons.
SHARE_COUNT_DIVERGENCE_WARN = 0.30    # diluted vs outstanding, as a fraction
PRICE_TO_SALES_LOW = 0.05
PRICE_TO_SALES_HIGH = 100.0

# ---- SHARE-BASIS COHERENCE -------------------------------------------------------------------
# The defect this exists for: share counts and per-share figures come from a FILING, the price
# comes from TODAY, and a corporate action between the two makes them incomparable. Booking
# Holdings had 31,673,346 shares from a February 10-K against an August price of $204.72 — a
# market capitalisation of $6.5bn for a company earning $8.8bn of operating profit, and a
# price/earnings ratio of 1.24. Nothing in the data itself looked wrong; each figure was correct
# on its own basis.
#
# Two independent routes to the same ratio make the mismatch visible:
#     basis-free   P/E = market capitalisation / net income   (no per-share figure involved)
#     per-share    P/E = price / diluted EPS                  (entirely per-share)
# They must agree. When they do not, a corporate action has moved the share basis, and the
# per-share route is the one that cannot be trusted against today's price.
PE_ROUTE_DISAGREEMENT_WARN = 0.25     # 25% apart is far beyond rounding

# A profitable company does not trade at one-and-a-bit times its earnings. When only the
# per-share route is available, a ratio this low is a unit mismatch rather than a bargain — the
# single cheapest way to catch a split between the filing and the price.
MIN_CREDIBLE_PE = 2.0

# How stale a share count may be before it is worth saying so.
#
# Derived from the filing calendar rather than picked: a quarterly filer publishes a new cover
# page every ~90 days, and the filing itself lands up to ~45 days after the period it covers. So
# roughly 135 days is the longest a CURRENT count should ever be — beyond that, an expected
# filing is missing, or the company does not file quarterly at all. Either way the price has had
# time to move onto a different basis, which is precisely the window the Booking error lived in
# (its count was 180 days old).
SHARE_COUNT_STALE_DAYS = 135

# ---------------------------------------------------------------------------------------------
# The v3 spec's weights. Coverage is measured against these because the spec's Gate 4 is expressed
# in them: BUY requires >= 75% coverage, and an unmeasurable component's weight leaves the
# denominator rather than scoring zero.
#
# REVENUE CONSISTENCY APPEARS EXACTLY ONCE. It used to sit in both Growth & Durability and Moat
# Evidence, so one measurement quietly drove 35% of Company Health. It belongs to growth.
# Competitive Strength Evidence now uses genuinely independent measures — and it is named as
# evidence because this system infers competitive strength from a financial footprint. It does
# not measure a moat and does not claim to. Market share, switching costs and customer
# concentration have no source and are not invented.
# ---------------------------------------------------------------------------------------------
COMPANY_HEALTH_CATEGORIES = ch.COMPANY_HEALTH_CATEGORIES

VALUATION_METRICS = {
    "forward_pe_vs_history": 7,     # needs analyst estimates — no free source carries them
    "forward_pe_vs_peers":   4,
    "ev_to_ebit":            4,
    "fcf_yield_pct":         6,
    "growth_adjusted_pe":    5,
    "intrinsic_value":       9,     # deliberately not built — see the note where it is reported
}
COMPANY_HEALTH_BUY_GATE = 75.0

# EVERY METRIC THAT MULTIPLIES OR DIVIDES BY A CURRENT MARKET CAPITALISATION.
#
# One list, used for both jobs: withholding these when the share basis cannot be trusted, and
# stamping the basis provenance onto them when it can. Two lists would drift, and the failure
# mode of drift here is a figure that quietly keeps its old value while its neighbours are
# withheld — which is precisely the shape of the defect this exists to prevent.
#
# COMPANY HEALTH IS NOW COMPLETELY INDEPENDENT OF THIS LIST, AND IT DID NOT USED TO BE.
#
# Growth, margins, cash flow, profitability, the balance sheet and durability are ratios of one
# fundamental to another and never touch a share count. The per-share growth chain is
# dimensionless by construction (see eps_chain.py) and is likewise unaffected.
#
# Capital allocation used to be the exception: two of its three inputs were buyback YIELD and
# dividend YIELD, and a yield needs a market capitalisation for its denominator. That coupling was
# not theoretical — when one company's market capitalisation became UNKNOWN it lost two of its
# three capital-allocation inputs, for a reason that had nothing whatever to do with how it
# allocates capital. C1 replaced both with measures that carry no price: share dilution, and
# whether distributions are funded by free cash flow.
#
# test_company_health.py now asserts the overlap is EMPTY, so a price-based input added to a
# Company Health category fails a test rather than quietly rebuilding the coupling.
MARKET_CAP_DEPENDENT = ("market_cap", "enterprise_value", "ev_to_ebit", "ev_to_ebitda",
                        "fcf_yield_pct", "buyback_yield_pct", "dividend_yield_pct")


def _v(value):
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _div(a, b):
    a, b = _v(a), _v(b)
    if a is None or b in (None, 0):
        return None
    return a / b


def _pct(a, b):
    r = _div(a, b)
    return None if r is None else r * 100.0


def _verdict(name, value, reason_if_missing=None, derived_note=None):
    """One metric's result. Never a bare number — the verdict and the provenance travel with it."""
    if value is None:
        return {"value": None, "verdict": UNAVAILABLE,
                "reason": reason_if_missing or "not reported in the filings this app reads"}
    low, high = BOUNDS.get(name, (float("-inf"), float("inf")))
    if not (low <= value <= high):
        return {"value": round(value, 4), "verdict": IMPLAUSIBLE,
                "reason": f"outside the plausible range {low:g} to {high:g} — treat as a parsing "
                          f"or arithmetic fault until shown otherwise"}
    if derived_note:
        return {"value": round(value, 4), "verdict": DERIVED, "reason": derived_note}
    return {"value": round(value, 4), "verdict": OK, "reason": None}


def _derive_gross_profit(revenue, cost_of_revenue):
    """revenue - cost of revenue, or None when the result cannot be a gross profit.

    The identity is exact; the risk is a cost line narrower than the whole cost of revenue, which
    makes the difference larger than any gross profit could be. Refused in that case — a missing
    margin is a far smaller problem than a margin that looks fine and is not.
    """
    revenue, cost_of_revenue = _v(revenue), _v(cost_of_revenue)
    if revenue is None or cost_of_revenue is None or revenue <= 0:
        return None
    derived = revenue - cost_of_revenue
    if not (-revenue <= derived <= revenue):
        return None
    return derived


def _cagr(latest, earliest, years):
    """Compound annual growth. None when the base is non-positive — a CAGR from a negative
    starting value is not a number that means anything, and producing one anyway is how a
    nonsensical growth rate ends up on a page looking authoritative."""
    latest, earliest = _v(latest), _v(earliest)
    if latest is None or earliest is None or years <= 0:
        return None
    if earliest <= 0 or latest <= 0:
        return None
    return ((latest / earliest) ** (1.0 / years) - 1.0) * 100.0


def _consistency(series):
    """Percentage of year-on-year changes that were positive. Newest-first input.

    The plainest honest measure of durability from annual figures: how often the number went up,
    and nothing more.
    """
    values = [_v(x) for x in series if _v(x) is not None]
    if len(values) < 3:
        return None
    ups = sum(1 for a, b in zip(values, values[1:]) if a > b)
    return ups / (len(values) - 1) * 100.0


def _resilience(series):
    """The WORST year-on-year change in the history, as a percentage. Newest-first input.

    Deliberately a different measurement from consistency, not a rephrasing of it. Consistency
    asks how often revenue rose; resilience asks how far it fell in its worst year. A company
    that grew in four years out of five and collapsed 40% in the fifth scores well on one and
    badly on the other, which is exactly the distinction Competitive Strength Evidence needs and
    the reason revenue consistency no longer appears in two categories at once.
    """
    values = [_v(x) for x in series if _v(x) is not None]
    if len(values) < 3:
        return None
    changes = [(a - b) / abs(b) * 100.0 for a, b in zip(values, values[1:]) if b]
    return min(changes) if changes else None


def _stability(series):
    """Coefficient of variation inverted onto 0-100. A margin held steady for years is the
    financial footprint of a competitive advantage — evidence of one, not a measurement of it."""
    values = [_v(x) for x in series if _v(x) is not None]
    if len(values) < 3:
        return None
    mean = sum(values) / len(values)
    if mean == 0:
        return None
    var = sum((x - mean) ** 2 for x in values) / len(values)
    cv = (var ** 0.5) / abs(mean)
    return max(0.0, min(100.0, (1.0 - cv) * 100.0))


# ---------------------------------------------------------------------------------------------
# INFERRED NIL
# ---------------------------------------------------------------------------------------------
def _nil_evidence(period: dict, kind: str) -> tuple:
    """May an absent cash-flow line be read as zero for this period? Returns (allowed, why).

    NOT a global "missing tag means zero" rule — that would undo the principle this whole project
    is built on. Zero is only permitted where absence is itself positive evidence, which requires
    two things to be true at once:

      * the cash-flow statement was demonstrably parsed for this period — operating cash flow AND
        capital expenditure are both present, so we are not looking at a period where the
        statement simply never came through;
      * the OTHER financing line is present, which proves the financing section specifically was
        read. Without that, absence tells us nothing: a company with no dividends line and no
        buybacks line may have paid both and had neither parsed.

    BUYBACKS ARE HELD TO THE SAME BAR AND THEN SOME, because a repurchase legitimately appears
    under several different concepts. The chain checked for them is deliberately the longer one,
    and "absent from the one tag I happened to read" is never evidence a company bought nothing
    back. Where the evidence is not there, the answer is UNKNOWN.
    """
    ocf, capex = _v(period.get("operating_cash_flow")), _v(period.get("capex"))
    if ocf is None or capex is None:
        return False, ("the cash-flow statement for this period is not fully parsed (operating "
                       "cash flow or capital expenditure is missing), so an absent line is not "
                       "evidence of a nil amount")
    other = "buybacks" if kind == "dividends_paid" else "dividends_paid"
    if _v(period.get(other)) is None:
        return False, (f"neither a dividend nor a share-repurchase line was found, so there is no "
                       f"positive evidence that the financing section was read — absence here "
                       f"could mean nil or could mean unparsed, and those are different")
    return True, (f"INFERRED NIL — the cash-flow statement for this period is present and every "
                  f"supported {kind.replace('_', ' ')} concept was checked; none is reported")


def _nil_or_unknown(period: dict, kind: str, market_cap, no_price_reason):
    """Yield-style metric for a capital-allocation line, with nil inferred only on evidence."""
    raw = _v(period.get(kind))
    if raw is not None:
        return _pct(raw, market_cap), None, no_price_reason
    allowed, why = _nil_evidence(period, kind)
    if allowed:
        return (0.0 if market_cap else None), why, (no_price_reason or why)
    return None, None, why


def _days_between(a, b):
    try:
        return abs((datetime.fromisoformat(str(b)) - datetime.fromisoformat(str(a))).days)
    except (TypeError, ValueError):
        return None


def _share_basis_check(out, pe_basis_free, pe_per_share, price, eps, net_income, market_cap):
    """Do the price and the per-share figures agree about what a share is?

    Returns (coherent, pe_to_use, reason_if_none, note). `coherent` is None when there is not
    enough to judge — which is not the same as agreement, and is reported as such.

    THE POINT. Every figure involved can be individually correct and the combination still wrong,
    because a filing and a price can describe different share bases. Two independent routes to the
    same ratio is the cheapest way to see it:

        basis-free  = market cap / net income   — no per-share figure anywhere in it
        per-share   = price / diluted EPS       — entirely per-share

    Agreement is evidence. Disagreement means a corporate action has moved the basis, and the
    per-share route is the one that cannot be trusted against today's price.
    """
    # THE FLOOR IS APPLIED FIRST, AND TO WHICHEVER ROUTE IS AVAILABLE.
    #
    # An earlier version only checked credibility when the basis-free route was missing, on the
    # assumption that two agreeing routes must both be right. Booking Holdings disproved that:
    # its share count and its EPS come from the SAME stale filing, so the two routes agreed at
    # about 1.2 and corroborated each other into publishing a price/earnings ratio of 1.20.
    #
    # Agreement between two figures drawn from one source is not evidence. The floor has to be an
    # absolute check on the answer, not a fallback for when cross-checking is impossible.
    candidate = pe_basis_free if pe_basis_free is not None else pe_per_share
    if (candidate is not None and candidate < MIN_CREDIBLE_PE and (net_income or 0) >= 0
            and (eps is None or eps > 0)):
        out["anomalies"].append({
            "check": "share_basis_mismatch",
            "severity": "WARNING",
            "detail": (f"price/earnings works out at {candidate:.2f}"
                       + (f" (price {price:,.2f} against diluted EPS {eps:,.2f})" if eps else "")),
            "why_it_matters": ("a profitable company does not trade at that multiple. The share "
                               "count and the price are on different bases — a corporate action "
                               "between the last filing and today — and because BOTH routes draw "
                               "on the same filing they can agree with each other while both "
                               "disagree with the price. Every price-based figure for this "
                               "company is withheld rather than published wrong."),
        })
        # NOTHING price-based survives this branch. The absurd answer came from the market cap
        # itself, which means the share count behind it is the stale one.
        out["price_metrics_reliable"] = False
        return False, None, (f"price and the reported earnings imply a price/earnings ratio of "
                             f"{candidate:.2f}, which is not a valuation but a sign that the "
                             f"share count and the price are on different bases"), None

    if pe_basis_free is not None and pe_per_share is not None:
        spread = abs(pe_basis_free - pe_per_share) / max(abs(pe_basis_free), 1e-9)
        if spread > PE_ROUTE_DISAGREEMENT_WARN:
            out["anomalies"].append({
                "check": "share_basis_mismatch",
                "severity": "WARNING",
                "detail": (f"price/earnings computed two ways disagrees: {pe_basis_free:.2f} from "
                           f"market capitalisation and net income, {pe_per_share:.2f} from price "
                           f"and diluted EPS"),
                "why_it_matters": ("the two routes can only differ if the share count behind one "
                                   "of them is on a different basis from the price — almost "
                                   "always a stock split between the last filing and today. The "
                                   "basis-free route is used and the per-share route is "
                                   "discarded; nothing is adjusted by a guessed split factor."),
            })
            # The market capitalisation survives here — it was built from the fresh count, and
            # it is the PER-SHARE side that is stale. Withholding it too would throw away the
            # figure the fix exists to produce.
            return False, pe_basis_free, None, ("computed from market capitalisation and net "
                                                "income, because the per-share route disagrees "
                                                "and is on a different share basis")
        return True, pe_basis_free, None, None

    if pe_basis_free is not None:
        return None, pe_basis_free, None, ("computed from market capitalisation and net income; "
                                           "no diluted EPS available to cross-check the share "
                                           "basis")

    # Only the per-share route exists and it passed the floor. It cannot be cross-checked, so
    # coherence is reported as unknown rather than as agreement.
    return None, pe_per_share, None, None


def validate_ticker(db, ticker: str, price: float | None = None,
                    as_of_filed: str | None = None, years: int = 6,
                    price_as_of: str | None = None) -> dict:
    """Every v3 input for one company: computed, bounded, verdicted and attributed.

    `price` is the latest stored close. When it is absent — or the fundamentals are not in USD —
    every price-based metric reports UNAVAILABLE with the reason rather than being skipped
    silently or computed against a currency it does not belong to.
    """
    ticker = ticker.upper()
    rows = fh.history(db, ticker, as_of_filed=as_of_filed, limit=years)
    out = {
        "ticker": ticker,
        "price": _v(price),
        "price_as_of": price_as_of,
        "as_of_filed": as_of_filed or "today",
        "periods": len(rows),
        "period_ends": [r["period_end"] for r in rows],
        "currency": rows[0]["currency"] if rows else None,
        "taxonomy": rows[0]["taxonomy"] if rows else None,
        "metrics": {},
        "notes": [],
        "anomalies": [],
        "derived": [],
    }
    if not rows:
        out["notes"].append(
            "No stored fundamentals history for this ticker. Nothing below can be computed, and "
            "that is a gap in this app's data — not a statement about the company.")
        out["company_health_coverage_pct"] = 0.0
        out["valuation_coverage_pct"] = 0.0
        out["clears_75pct_gate"] = False
        return out

    latest = rows[0]
    currency = latest.get("currency")
    usd = currency == "USD"
    if not usd:
        out["notes"].append(
            f"Figures are in {currency or 'an unrecorded currency'}. No currency conversion "
            f"exists anywhere in this app, so every metric that multiplies a fundamental by a "
            f"US-dollar share price is reported UNAVAILABLE rather than converted at a guessed "
            f"rate. Ratios that divide {currency} by {currency} are unaffected.")

    g = latest.get
    revenue, net_income = _v(g("revenue")), _v(g("net_income"))
    ocf, capex = _v(g("operating_cash_flow")), _v(g("capex"))
    fcf = (ocf - capex) if (ocf is not None and capex is not None) else None
    equity, debt, cash = _v(g("stockholders_equity")), _v(g("total_debt")), _v(g("total_cash"))
    dna, interest = _v(g("depreciation_amortisation")), _v(g("interest_expense"))
    total_assets = _v(g("total_assets"))

    # ---- gross profit: reported, else the revenue-minus-cost identity ----
    gross_profit = _v(g("gross_profit"))
    out["gross_profit_basis"] = "reported" if gross_profit is not None else None
    if gross_profit is None and revenue:
        derived_gp = _derive_gross_profit(revenue, g("cost_of_revenue"))
        if derived_gp is not None:
            gross_profit = derived_gp
            out["gross_profit_basis"] = "derived: revenue - cost of revenue"
            out["derived"].append("gross_profit")

    # ---- operating profit: reported, else reconciled, else UNKNOWN ----
    resolved_op = op.reconcile(latest, gross_profit=gross_profit)
    op_income = resolved_op["value"]
    out["operating_income_basis"] = resolved_op["basis"]
    out["operating_income_routes"] = resolved_op["checked"]
    if resolved_op["note"]:
        out["notes"].append(resolved_op["note"])
    op_is_derived = bool(resolved_op["basis"]) and resolved_op["basis"] != op.REPORTED
    if op_is_derived:
        out["derived"].append("operating_income")
    op_note = resolved_op["basis"] if op_is_derived else None
    ebitda = op.ebitda(op_income, dna)

    # ---- share count: only one that is ENTITLED to stand behind a current valuation ----
    #
    # This used to take the newest non-null figure it could find, in the order cover page →
    # annual → diluted, with no test of whether any of them was current. That is how Regeneron
    # came to be valued on a count from a document filed in 2012 while this same code held a
    # 10-K filed 2026-02-04 for the same company: both facts were stored, in different tables,
    # and nothing compared them.
    #
    # The test now lives in services/share_basis.py and is cadence-relative — the count must come
    # from the newest filing this app holds, or the one before it — with an age backstop derived
    # from how often filings actually arrive. See that module for why it is not a day threshold.
    price_v = _v(price)
    # THE DATE FRESHNESS IS JUDGED AGAINST, IN PRIORITY ORDER.
    #
    # The price date first, because "is this count current" only means anything relative to the
    # price it will be multiplied by. Then the as-of date, because a historical calculation asks
    # whether the count was current AT THAT DATE — judging a 2019 valuation against today would
    # mark every filing in the backtest stale and return UNKNOWN for the entire history, which
    # would look like the rule working and would in fact be the rule inverted. Today last.
    price_day = ((out.get("price_as_of") or "")[:10] or as_of_filed or None)
    stored_counts = [r for r in fh.stored_share_counts(db, ticker)
                     if not as_of_filed or (r.get("filed") or "") <= as_of_filed]
    action = share_basis.detect_split_like_action(stored_counts)
    basis = share_basis.resolve(
        cover_count=fh.latest_share_count(db, ticker, as_of_filed=as_of_filed),
        latest_row=latest,
        filed_dates=fh.known_filing_dates(db, ticker, as_of_filed=as_of_filed),
        reference_date=price_day,
        share_period=fh.latest_share_period(db, ticker, as_of_filed=as_of_filed),
        corporate_action=action,
    )

    # WHEN NOTHING QUALIFIES, `shares` IS NONE — not "None but available if you look".
    # Every price-based figure below is built from this one variable, so an UNKNOWN basis cannot
    # be routed around by a metric that reaches for the count some other way. That is deliberate:
    # the requirement is that dependent valuation metrics CANNOT bypass the block, and the
    # cheapest proof of that is that there is nothing left for them to bypass it with.
    shares = basis["shares"] if basis["provenance"] in share_basis.PUBLISHABLE else None
    if bool(as_of_filed) and BAR_ADJUSTMENT != "raw":
        shares = None      # see the historical-valuation note below
    shares_filed = basis.get("source_filed")
    out["share_basis_provenance"] = basis["provenance"]
    out["share_basis_detail"] = basis
    out["shares_basis"] = share_basis.describe(basis)
    out["share_count_as_of"] = basis.get("as_of")
    out["share_count_filed"] = shares_filed
    out["share_count"] = shares
    # THE WARNING IS SCOPED TO THE WINDOW BETWEEN THE SHARE BASIS AND THE PRICE.
    #
    # Detection deliberately scans the whole stored history, because a candidate filed before ANY
    # action has to be rejected and that requires knowing about it. Warning on the same footing
    # was wrong: it fired for seventeen of fifty companies on splits from 2020, 2022 and 2024 —
    # NVIDIA's ten-for-one against a share basis filed in May 2026 — none of which had any bearing
    # on the figures being published, and none of which produced a wrong number. A check that
    # fires on a third of the universe is one a person learns to scroll past.
    #
    # An action is only worth raising if the selected basis is NOT provably on the later side of
    # it. `between[1]` is the filing by which the action had certainly happened, so a basis filed
    # on or after that date is safe and silent. Nothing about the threshold changed.
    if action and share_basis.action_is_in_scope(action, out.get("share_count_filed"),
                                                 basis["provenance"]):
        out["anomalies"].append({
            "check": "corporate_action_detected",
            "severity": "WARNING",
            "detail": action["detail"],
            "why_it_matters": ("a share count from before this action and a price from after it "
                               "are on different bases. No correction factor is applied — a "
                               "basis from after the action is used if one exists, and otherwise "
                               "nothing price-based is published."),
        })
    # HISTORICAL VALUATION IS BLOCKED, AND THE REASON IS THE PRICE SERIES RATHER THAN THE COUNT.
    #
    # Bars are stored split- and dividend-adjusted (BAR_ADJUSTMENT), so a historical bar is
    # expressed in TODAY's basis, not the basis in force on its own date. Pairing it with an
    # as-reported historical share count is wrong by every corporate action since. Pairing it with
    # a today's-basis count would import knowledge of a future split into a past date, which is
    # look-ahead. There is no arrangement of adjusted prices and as-reported counts that yields a
    # correct historical market capitalisation — it needs raw bars, which this app does not store.
    #
    # So a market capitalisation is published for TODAY only. This costs nothing at present: no
    # backtest consumes valuation. It exists so that none silently can.
    historical = bool(as_of_filed) and BAR_ADJUSTMENT != "raw"
    if historical:
        out["historical_valuation_blocked"] = True
        out["notes"].append(
            f"Historical valuation is not computed. Stored bars are adjusted "
            f"({BAR_ADJUSTMENT}), so a past price is expressed in today's share basis while the "
            f"share count is as-reported at the time. Combining them is wrong by every corporate "
            f"action since; correcting the count with a factor would be look-ahead. Raw "
            f"unadjusted bars would be needed, and this app does not store them.")

    if basis["provenance"] == share_basis.UNKNOWN:
        out["notes"].append("Market capitalisation and every figure derived from it are withheld: "
                            + (basis["reason"] or "no usable share basis."))
    elif basis["provenance"] == share_basis.ESTIMATED:
        out["notes"].append(
            f"ESTIMATED SHARE BASIS — {basis['label']}. Every price-based figure for this company "
            f"is an approximation on that basis, not a measurement. No actual share count from a "
            f"recent enough filing exists in the data this app reads.")

    no_price = ("no share price available" if price_v is None else
                f"fundamentals are in {currency}, not USD" if not usd else None)
    no_basis = None if shares else (
        ("this is a historical calculation, and a market capitalisation cannot be computed from "
         "adjusted bars against an as-reported share count — see the note on this result")
        if historical else
        (basis.get("reason") or "no share count in any filing this app reads"))
    market_cap = (shares * price_v) if (shares and price_v and usd) else None
    ev = ((market_cap + (debt or 0.0) - (cash or 0.0)) if market_cap is not None else None)

    m = out["metrics"]

    # ---- valuation (price x fundamental) ----
    m["market_cap"] = _verdict("market_cap", market_cap, no_basis or no_price)
    m["enterprise_value"] = _verdict("enterprise_value", ev,
                                     no_price or "market capitalisation unavailable")
    eps = _v(g("eps_diluted"))
    pe_per_share = (price_v / eps) if (price_v and eps and eps > 0 and usd) else None
    pe_basis_free = (_div(market_cap, net_income)
                     if (market_cap and net_income and net_income > 0) else None)
    coherent, pe, pe_reason, pe_note = _share_basis_check(
        out, pe_basis_free, pe_per_share, price_v, eps, net_income, market_cap)
    m["pe_ratio"] = _verdict(
        "pe_ratio", pe,
        no_price or pe_reason
        or ("diluted EPS is zero or negative, so a P/E would not be meaningful"
            if eps is not None and eps <= 0 else "no diluted EPS reported"),
        pe_note)
    out["share_basis_coherent"] = coherent
    m["ev_to_ebit"] = _verdict(
        "ev_to_ebit", _div(ev, op_income) if (op_income and op_income > 0) else None,
        no_price or ("operating profit could not be reconciled" if op_income is None
                     else "operating profit is not positive"), op_note)
    m["ev_to_ebitda"] = _verdict(
        "ev_to_ebitda", _div(ev, ebitda) if (ebitda and ebitda > 0) else None,
        no_price or "EBITDA needs an operating profit and depreciation; one is missing", op_note)
    m["fcf_yield_pct"] = _verdict("fcf_yield_pct", _pct(fcf, market_cap),
                                  no_price or "free cash flow needs operating cash flow and capex")

    # ---- profitability (currency-neutral: safe for every filer) ----
    m["gross_margin_pct"] = _verdict(
        "gross_margin_pct", _pct(gross_profit, revenue), None,
        out["gross_profit_basis"] if "derived" in (out["gross_profit_basis"] or "") else None)
    m["operating_margin_pct"] = _verdict(
        "operating_margin_pct", _pct(op_income, revenue),
        "operating profit is not reported and could not be reconciled from the income statement",
        op_note)
    m["net_margin_pct"] = _verdict("net_margin_pct", _pct(net_income, revenue))
    m["fcf_margin_pct"] = _verdict("fcf_margin_pct", _pct(fcf, revenue))
    invested = (equity + (debt or 0.0)) if equity is not None else None
    m["roic_pct"] = _verdict(
        "roic_pct", _pct(op_income, invested) if invested else None,
        "needs an operating profit and shareholders' equity", op_note)
    # RETURN ON EQUITY IS UNKNOWN WHEN EQUITY IS NOT POSITIVE, AND THAT IS A CORRECTNESS FIX.
    #
    # The old test was `if equity`, which is true for a NEGATIVE number. HCA earned $6,784m on
    # equity of -$6,027m and was reported as -112.6% return on equity; Booking earned $5,404m on
    # -$5,578m and was reported as -96.9%. Both are among the most profitable companies in the
    # universe — their equity is negative because they have bought back more stock than they have
    # retained, which is a capital-structure fact and not distress.
    #
    # A ratio with a negative denominator carries no meaning here, and the plausibility bound of
    # (-500%, +500%) accepted both. While the figure was only counted toward coverage nobody
    # noticed; the moment it is SCORED, two excellent companies take a zero inside a category
    # weighted 25. The honest answer is that return on equity is not defined for them.
    m["roe_pct"] = _verdict(
        "roe_pct", _pct(net_income, equity) if (equity is not None and equity > 0) else None,
        ("shareholders' equity is negative, which happens when a company has returned more to "
         "shareholders than it has retained. A return on a negative denominator is not a "
         "meaningful figure, so none is reported — this says nothing about profitability, which "
         "is measured by return on invested capital and return on assets."
         if (equity is not None and equity <= 0) else
         "needs net income and shareholders' equity"))

    # ---- return on assets: the spec asked for it and total assets were being stored unused ----
    # Average assets where two periods are available, because net income is earned across a year
    # while the balance sheet is a single instant. Ending assets otherwise, and the basis is said.
    prior_assets = _v(rows[1].get("total_assets")) if len(rows) > 1 else None
    if total_assets is not None and prior_assets is not None:
        assets_base, assets_note = (total_assets + prior_assets) / 2.0, "average of opening and closing assets"
    else:
        assets_base, assets_note = total_assets, "closing assets only — no prior year available"
    out["assets_basis"] = assets_note if total_assets is not None else None
    m["roa_pct"] = _verdict("roa_pct", _pct(net_income, assets_base) if assets_base else None,
                            "needs net income and total assets")

    # ---- cash-flow quality ----
    m["fcf_to_net_income"] = _verdict("fcf_to_net_income", _div(fcf, net_income)
                                      if (net_income and net_income > 0) else None,
                                      "needs free cash flow and positive net income")
    m["ocf_to_net_income"] = _verdict("ocf_to_net_income", _div(ocf, net_income)
                                      if (net_income and net_income > 0) else None,
                                      "needs operating cash flow and positive net income")
    # Accruals: the gap between reported profit and the cash that arrived, scaled by the assets
    # that produced it. A large positive value means earnings are running ahead of cash, which is
    # the classic early sign of aggressive revenue recognition — the reason the spec asks for it.
    m["accruals_ratio"] = _verdict(
        "accruals_ratio",
        _div((net_income - ocf) if (net_income is not None and ocf is not None) else None,
             assets_base) if assets_base else None,
        "needs net income, operating cash flow and total assets")

    # ---- balance sheet ----
    net_debt = ((debt or 0.0) - (cash or 0.0)) if (debt is not None or cash is not None) else None
    m["net_debt_to_ebitda"] = _verdict(
        "net_debt_to_ebitda", _div(net_debt, ebitda) if (ebitda and ebitda > 0) else None,
        "needs net debt and EBITDA, and EBITDA needs an operating profit", op_note)
    m["interest_coverage"] = _verdict(
        "interest_coverage", _div(op_income, interest) if (interest and interest > 0) else None,
        # Apple stopped tagging interest expense separately after FY2023. That is a real
        # disclosure gap, not a parser fault, and it is left UNKNOWN rather than invented.
        "interest expense is not separately tagged in these filings, and it cannot be safely "
        "derived from anything else that is", op_note)
    m["current_ratio"] = _verdict("current_ratio",
                                  _div(g("current_assets"), g("current_liabilities")))

    # ---- growth and durability ----
    # Revenue is an absolute currency amount, untouched by share splits, so it spans the whole
    # history regardless of which filing each year came from.
    span_years = max(len(rows) - 1, 0)
    m["revenue_cagr_pct"] = _verdict(
        "revenue_cagr_pct", _cagr(revenue, rows[-1].get("revenue"), span_years),
        f"needs at least two annual periods (this ticker has {len(rows)})")

    # PER-SHARE FIGURES ARE NOT. Growth is chained from within-filing links, so no comparison
    # ever crosses a share basis. See services/eps_chain.py for why this is not a split guess.
    all_vintages = fh.history_all_vintages(db, ticker, as_of_filed=as_of_filed)
    chained = eps_chain.chain(all_vintages, years=5, as_of_filed=as_of_filed)
    out["eps_chain"] = chained
    m["eps_cagr_pct"] = _verdict(
        "eps_cagr_pct", chained["value"],
        chained["reason"] or "no usable per-share growth chain",
        chained["basis"] if chained["value"] is not None else None)
    if chained["value"] is not None:
        out["derived"].append("eps_cagr_pct")

    m["revenue_consistency"] = _verdict("revenue_consistency",
                                        _consistency([r.get("revenue") for r in rows]),
                                        "needs at least three annual periods")

    # ---- competitive strength evidence (a financial footprint, never a measured moat) ----
    margins, op_margins = [], []
    for r in rows:
        gp = _v(r.get("gross_profit")) or _derive_gross_profit(r.get("revenue"),
                                                               r.get("cost_of_revenue"))
        margins.append(_pct(gp, r.get("revenue")))
        row_op = op.reconcile(r, gross_profit=gp)["value"]
        op_margins.append(_pct(row_op, r.get("revenue")))
    m["gross_margin_stability"] = _verdict("gross_margin_stability", _stability(margins),
                                           "needs a gross margin in at least three periods")
    m["operating_margin_stability"] = _verdict(
        "operating_margin_stability", _stability(op_margins),
        "needs an operating margin in at least three periods")
    roics = [_pct(op.reconcile(r)["value"],
                  (_v(r.get("stockholders_equity")) or 0) + (_v(r.get("total_debt")) or 0) or None)
             for r in rows]
    m["roic_persistence"] = _verdict("roic_persistence", _stability(roics),
                                     "needs an operating profit and equity in three periods")
    m["revenue_resilience"] = _verdict(
        "revenue_resilience", _resilience([r.get("revenue") for r in rows]),
        "needs at least three annual periods")
    m["rnd_intensity_pct"] = _verdict(
        "rnd_intensity_pct", _pct(g("rnd_expense"), revenue),
        "no research and development expense is separately tagged — normal outside technology "
        "and pharmaceuticals, and NOT the same as spending nothing")

    # ---- capital allocation, with nil inferred only on positive evidence ----
    # The two YIELDS are still reported, because they are useful figures — but they no longer
    # score, because they divide by market capitalisation and Company Health must not depend on
    # the valuation machinery. See services/company_health.py.
    for line, metric in (("buybacks", "buyback_yield_pct"), ("dividends_paid", "dividend_yield_pct")):
        value, nil_note, reason = _nil_or_unknown(latest, line, market_cap, no_price)
        m[metric] = _verdict(metric, value, reason)
        if nil_note and value is not None:
            m[metric]["verdict"] = INFERRED_NIL
            m[metric]["reason"] = nil_note
            out["derived"].append(metric)

    # What DOES score: whether distributions are funded by the cash the business generates. No
    # price anywhere in it, and a company that distributes nothing is set aside rather than
    # awarded a mark it has not earned.
    dist_value, dist_status, dist_note = ch.distribution_sustainability(latest, fcf)
    if dist_status == "OK":
        m["distribution_sustainability"] = _verdict("distribution_sustainability", dist_value)
    else:
        m["distribution_sustainability"] = {
            "value": None,
            "verdict": NOT_APPLICABLE if dist_status == "NOT_APPLICABLE" else UNAVAILABLE,
            "reason": dist_note,
        }

    # Dilution: same split problem as EPS, same fix — one filing, one basis.
    vintage_rows = [r for r in rows if r.get("filed") == latest.get("filed")]
    out["per_share_comparison_filing"] = latest.get("filed")
    out["per_share_comparison_years"] = len(vintage_rows)
    oldest_shares = (vintage_rows[-1].get("diluted_shares")
                     or vintage_rows[-1].get("shares_outstanding")) if vintage_rows else None
    newest_shares = g("diluted_shares") or g("shares_outstanding")
    m["share_change_pct"] = _verdict(
        "share_change_pct",
        _pct((_v(newest_shares) - _v(oldest_shares)), oldest_shares)
        if (len(vintage_rows) >= 2 and _v(newest_shares) is not None and _v(oldest_shares))
        else None,
        f"per-share figures can only be compared within one filing (a split rewrites them), and "
        f"the filing of {latest.get('filed')} covers {len(vintage_rows)} year(s)")

    # ---- the remaining valuation components ----
    peg = None
    if (m["pe_ratio"]["verdict"] in USABLE and m["eps_cagr_pct"]["verdict"] in USABLE
            and (m["eps_cagr_pct"]["value"] or 0) > 0):
        peg = m["pe_ratio"]["value"] / m["eps_cagr_pct"]["value"]
    m["growth_adjusted_pe"] = _verdict(
        "growth_adjusted_pe", peg,
        "needs a positive P/E and a positive EPS growth rate; one is missing or negative")
    m["forward_pe_vs_history"] = _verdict(
        "forward_pe_vs_history", None,
        "needs forward analyst EPS estimates. No source this app reads carries them, so this is "
        "permanently unavailable unless an estimates provider is added.")
    m["forward_pe_vs_peers"] = _verdict(
        "forward_pe_vs_peers", None,
        "needs forward estimates for genuine sector peers. The other 49 tickers are not a sector.")
    m["intrinsic_value"] = _verdict(
        "intrinsic_value", None,
        "NOT BUILT, by decision. A discounted cash flow is dominated by three subjective "
        "assumptions — growth, discount rate and terminal value — and can look authoritative "
        "while being arbitrary. Lower valuation coverage containing reliable measurements is "
        "preferred to higher coverage containing a weak DCF. This 9% is NOT redistributed.")

    # ---- when the share basis is unreliable, WITHHOLD the price-based figures ----
    # Booking Holdings was reported as two IMPLAUSIBLE metrics — a 140% free-cash-flow yield and
    # a 99% buyback yield — labelled "parsing or arithmetic fault". Both numbers were arithmetic
    # perfect; the fault was combining a February share count with an August price. Publishing
    # them with the wrong diagnosis is worse than not publishing them, because it sends the next
    # person looking for a parser bug that does not exist.
    #
    # So when the basis is known to be wrong and cannot be corrected, every figure that multiplies
    # a fundamental by a price is UNAVAILABLE with the real reason. Coverage falls, which is the
    # truthful consequence rather than something to be avoided.
    if out.get("price_metrics_reliable") is False:
        why = ("the share count and the price are on different bases — a corporate action between "
               "the last filing and today — so any figure combining them would be wrong by the "
               "size of that action. No more recent share count is available to correct it.")
        for name in MARKET_CAP_DEPENDENT:
            if m.get(name, {}).get("verdict") in (OK, DERIVED, IMPLAUSIBLE):
                m[name] = {"value": None, "verdict": UNAVAILABLE, "reason": why}
        out["notes"].append(
            "Price-based figures are withheld for this company: " + why)

    # ---- coherence tested against EVERY candidate basis, not merely the selected one ----
    _candidate_coherence(out, basis, price_v, eps, net_income, usd)

    # ---- the share basis travels with every figure built on it ----
    # A provenance that stays on the share count and never reaches the metrics is a provenance
    # nobody reads. Regeneron's market capitalisation was wrong for years while the sentence
    # describing its share count sat one level up in the same payload, correct and unread. So the
    # label goes ON the number: anything derived from an estimate says so where the number is,
    # and a reader never has to know to look somewhere else.
    for name in MARKET_CAP_DEPENDENT:
        metric = m.get(name)
        if not metric:
            continue
        metric["share_basis"] = basis["provenance"]
        if metric.get("value") is None:
            continue
        if basis["provenance"] == share_basis.ESTIMATED:
            # OK becomes DERIVED — the figure is real but rests on an approximation. An
            # IMPLAUSIBLE verdict is left alone: a number that could not be true does not become
            # acceptable by being labelled, and relabelling it would hide a bug behind a caveat.
            if metric.get("verdict") == OK:
                metric["verdict"] = DERIVED
            metric["reason"] = (f"ESTIMATED SHARE BASIS — {basis['label']}. "
                                + (metric.get("reason") or "")).strip()
    # The P/E is a special case worth stating rather than lumping in. Its basis-free route runs
    # through the market capitalisation and inherits the basis; its per-share route is price over
    # reported EPS and touches no share count at all. What an unusable basis costs there is not
    # the number but the CROSS-CHECK — with no market capitalisation there is no second route to
    # disagree with the first, and the Booking-style mismatch would pass unseen.
    if m.get("pe_ratio"):
        m["pe_ratio"]["share_basis"] = basis["provenance"]
        if (basis["provenance"] == share_basis.UNKNOWN
                and m["pe_ratio"].get("value") is not None):
            m["pe_ratio"]["reason"] = (
                "computed from price and reported diluted EPS. No current share count is "
                "available, so this could NOT be cross-checked against a market-capitalisation "
                "route — a corporate action since the last filing would leave it wrong and "
                "undetected. " + (m["pe_ratio"].get("reason") or "")).strip()

    # ---- anomalies: suspicion, never rejection ----
    _add_anomalies(out, m, latest, price_v, market_cap, revenue, shares, usd)

    # ---- cross-check that names its own cause ----
    if (gross_profit is not None and revenue is not None and revenue > 0
            and gross_profit > revenue):
        out["notes"].append(
            f"Reported gross profit ({gross_profit:,.0f}) exceeds reported revenue "
            f"({revenue:,.0f}), which is impossible. The revenue tag has almost certainly "
            f"captured only part of the top line — lease, interest or royalty income excluded — "
            f"so every margin, growth rate and valuation multiple for this company is suspect.")

    # ---- C1: Company Health — the score, and the coverage behind it ----
    # Both numbers, always, side by side. Coverage says how much of the model could be measured;
    # the score says how the company did on what was measured. Reporting one without the other is
    # how "we could not measure this" turns into "this is a bad company", which is a different and
    # far more damaging statement.
    health = ch.evaluate(m, USABLE)
    out["company_health"] = health
    out["company_health_score"] = health["score"]
    out["company_health_verdict"] = health["verdict"]
    out["company_health_red_flags"] = health["red_flags"]
    out["company_health_coverage_pct"] = health["coverage_pct"]
    out["clears_75pct_gate"] = health["coverage_pct"] >= COMPANY_HEALTH_BUY_GATE

    # The per-category view the coverage report has always published, kept in the same shape so
    # nothing downstream has to change, now carrying the score alongside the coverage.
    out["company_health_categories"] = {
        name: {"weight": c["weight"], "inputs": len(COMPANY_HEALTH_CATEGORIES[name][1]),
               "available": len(c["metrics_scored"]), "coverage_pct": c["coverage_pct"],
               "score": c["score"], "red_flag": c["red_flag"], "missing": c["metrics_missing"]}
        for name, c in health["categories"].items()}

    val = sum(w for n, w in VALUATION_METRICS.items() if m.get(n, {}).get("verdict") in USABLE)
    out["valuation_coverage_pct"] = round(val / sum(VALUATION_METRICS.values()) * 100, 1)
    out["valuation_unavailable"] = [n for n in VALUATION_METRICS
                                    if m.get(n, {}).get("verdict") not in USABLE]

    out["implausible"] = [n for n, r in m.items() if r["verdict"] == IMPLAUSIBLE]
    out["unknown"] = {n: r["reason"] for n, r in m.items() if r["verdict"] == UNAVAILABLE}
    out["fields_never_reported"] = [f for f in HISTORY_VALUE_FIELDS
                                    if all(r.get(f) is None for r in rows)]
    return out


def _candidate_coherence(out, basis, price, eps, net_income, usd):
    """Test every candidate share basis against the per-share route, not just the chosen one.

    THE REASON THIS EXISTS. Carvana's coherence warning disappeared not because the company got
    better but because the SELECTED basis changed: moving from the diluted count to the basic one
    pulled the two price/earnings routes from 25.8% apart to 20.8% apart, under the threshold,
    while both remained pre-split and both remained wrong. A check that only ever looks at the
    selected basis can be silenced by changing the selection, which is the one thing a check
    against wrong bases must not permit.

    AGREEMENT HERE IS NOT CORROBORATION, AND MUST NEVER BE REPORTED AS SUCH. Every candidate comes
    from the same filings and they all move together under a split, so their agreeing with one
    another says only that the filings are internally consistent. Booking Holdings published a
    price/earnings ratio of 1.20 precisely because a share count and an EPS drawn from one stale
    filing agreed with each other. Only something outside the filings — the price, or a corporate
    action record — can confirm the basis is current. So this function raises warnings on
    disagreement and stays silent on agreement; silence is not a pass.
    """
    if not (price and eps and eps > 0 and net_income and net_income > 0 and usd):
        return
    per_share_pe = price / eps
    selected = basis.get("shares")
    worst = None
    for candidate in basis.get("candidates") or []:
        shares = candidate.get("shares")
        if not shares or shares == selected:
            continue
        candidate_pe = (shares * price) / net_income
        spread = abs(candidate_pe - per_share_pe) / max(abs(per_share_pe), 1e-9)
        if spread > PE_ROUTE_DISAGREEMENT_WARN and (worst is None or spread > worst[0]):
            worst = (spread, candidate, candidate_pe)
    if worst is None:
        return
    spread, candidate, candidate_pe = worst
    out["anomalies"].append({
        "check": "candidate_basis_disagreement",
        "severity": "WARNING",
        "detail": (f"a share basis this app also holds — {candidate['source']} of "
                   f"{candidate['shares']:,.0f} from the filing of {candidate['filed']} — implies "
                   f"a price/earnings ratio of {candidate_pe:.2f} against {per_share_pe:.2f} from "
                   f"price and diluted EPS, a difference of {spread * 100:.0f}%"),
        "why_it_matters": ("the candidates cannot all be on the same basis as today's price, so at "
                           "least one of them describes a different company from the one being "
                           "priced — usually a corporate action between two filings. This is "
                           "raised whichever candidate was selected, so changing the selection "
                           "cannot silence it. It is a warning: the disagreement says something "
                           "is inconsistent, not which figure is wrong."),
    })


def _add_anomalies(out, m, latest, price, market_cap, revenue, shares, usd):
    """Figures that are possible but worth a second look.

    THE DISTINCTION FROM `implausible` IS DELIBERATE AND LOAD-BEARING. An implausible metric is a
    bug: it could not be true. An anomaly could perfectly well be true — dual-class structures,
    heavy treasury holdings and companies between growth phases all sit outside these thresholds
    legitimately. So nothing here rejects data or removes a metric from coverage. It raises a
    hand, names the numbers, and leaves the judgement to a person.
    """
    diluted = _v(latest.get("diluted_shares"))
    outstanding = _v(latest.get("shares_outstanding"))
    if diluted and outstanding:
        divergence = abs(diluted - outstanding) / outstanding
        if divergence > SHARE_COUNT_DIVERGENCE_WARN:
            out["anomalies"].append({
                "check": "share_count_consistency",
                "severity": "WARNING",
                "detail": (f"diluted shares ({diluted:,.0f}) and shares outstanding "
                           f"({outstanding:,.0f}) differ by {divergence * 100:.0f}%"),
                "why_it_matters": ("these two counts describe the same company, so a large gap "
                                   "usually means one of them is measuring something else — "
                                   "shares ISSUED including treasury stock is the common case, "
                                   "and it halves a market capitalisation. It can also be a "
                                   "legitimate consequence of the company's share structure, so "
                                   "this is a prompt to look, not a reason to discard."),
            })

    if market_cap and revenue and revenue > 0:
        ps = market_cap / revenue
        if ps < PRICE_TO_SALES_LOW or ps > PRICE_TO_SALES_HIGH:
            out["anomalies"].append({
                "check": "price_to_sales",
                "severity": "WARNING",
                "detail": (f"price-to-sales of {ps:.2f} (market cap {market_cap:,.0f} on revenue "
                           f"{revenue:,.0f})"),
                "why_it_matters": ("an extreme multiple is more often a wrong share count or a "
                                   "mis-parsed revenue line than a real valuation — but real "
                                   "companies do trade at extreme multiples, so this is a "
                                   "warning and never a validity gate."),
            })

    # STALENESS. A share count is only as current as the filing that carried it, and the price is
    # always today's. Saying how far apart they are does not fix a corporate action in between —
    # nothing here can — but it says where to look when a price-based figure reads oddly.
    filed = out.get("share_count_filed")
    price_date = (out.get("price_as_of") or "")[:10]
    gap = _days_between(filed, price_date or datetime.now(timezone.utc).date().isoformat())
    if gap is not None:
        out["share_count_age_days"] = gap
        if gap > SHARE_COUNT_STALE_DAYS:
            out["anomalies"].append({
                "check": "stale_share_count",
                "severity": "WARNING",
                "detail": (f"the share count comes from a filing dated {filed}, {gap} days before "
                           f"the price being used"),
                "why_it_matters": ("a corporate action in that window would put the count and the "
                                   "price on different bases and make every price-based figure "
                                   "wrong by the split factor. Most companies file quarterly, so "
                                   "a gap this large usually means no newer cover page was "
                                   "found."),
            })

    # The arithmetic that produced the market cap, restated so it can be checked by eye against
    # an outside source. This is the cross-check that no internal test can replace.
    if market_cap and shares and price:
        out["market_cap_check"] = {
            "shares": shares, "price": price, "market_cap": market_cap,
            "implied_price_per_share": round(market_cap / shares, 4),
            "share_count_from": out.get("shares_basis"),
            "note": ("market cap = share count x last stored close. If the market cap looks "
                     "wrong, one of these two inputs is wrong — compare both against an outside "
                     "source rather than trusting the product."),
        }


def summarise(results: list) -> dict:
    """The one thing B2 has to answer: can Build C start, and if not, what is stopping it."""
    n = len(results)
    if not n:
        return {"tickers": 0}
    clearing = [r for r in results if r.get("clears_75pct_gate")]
    implausible = {r["ticker"]: r["implausible"] for r in results if r.get("implausible")}
    anomalies = {r["ticker"]: [a["check"] for a in r["anomalies"]]
                 for r in results if r.get("anomalies")}
    derived = {r["ticker"]: sorted(set(r.get("derived") or []))
               for r in results if r.get("derived")}

    missing_counts, unknown_reasons = {}, {}
    for r in results:
        for info in (r.get("company_health_categories") or {}).values():
            for miss in info["missing"]:
                missing_counts[miss] = missing_counts.get(miss, 0) + 1
        for metric, reason in (r.get("unknown") or {}).items():
            unknown_reasons.setdefault(metric, reason)

    # SHARE BASIS, COUNTED RATHER THAN DESCRIBED. The universe-wide question is not "did it run"
    # but "how many of these fifty valuations rest on a real, current share count" — and that has
    # to be a tally, because a single company quietly dropping to an estimate is invisible in a
    # mean.
    by_provenance = {}
    for r in results:
        by_provenance.setdefault(r.get("share_basis_provenance") or "NOT_RECORDED",
                                 []).append(r["ticker"])
    basis_ages = {r["ticker"]: (r.get("share_basis_detail") or {}).get("age_days")
                  for r in results if (r.get("share_basis_detail") or {}).get("age_days") is not None}

    # ---- C1 Company Health, summarised across the universe ----
    # Tallies rather than means wherever a mean would hide a single company: one company dropping
    # to INSUFFICIENT DATA is invisible in an average and is exactly what a reader needs to see.
    verdicts, red_flags, capped, category_coverage, category_scores = {}, {}, {}, {}, {}
    unknown_metrics = {}
    for r in results:
        health = r.get("company_health") or {}
        verdicts.setdefault(health.get("verdict") or "NOT_RECORDED", []).append(r["ticker"])
        if health.get("red_flags"):
            red_flags[r["ticker"]] = {
                name: (health["categories"][name]["score"],
                       sorted(health["categories"][name]["metrics_scored"]))
                for name in health["red_flags"]}
        if health.get("capped"):
            capped[r["ticker"]] = health.get("cap_reason")
        for name, category in (health.get("categories") or {}).items():
            category_coverage.setdefault(name, []).append(category["coverage_pct"])
            if category["score"] is not None:
                category_scores.setdefault(name, []).append(category["score"])
            for missing in category["metrics_missing"]:
                unknown_metrics[missing] = unknown_metrics.get(missing, 0) + 1

    scored = [r for r in results if r.get("company_health_score") is not None]

    return {
        "tickers": n,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "company_health_verdicts": {k: len(v) for k, v in sorted(verdicts.items())},
        "company_health_verdict_tickers": {k: sorted(v) for k, v in sorted(verdicts.items())},
        "company_health_scored": len(scored),
        "mean_company_health_score": (
            round(sum(r["company_health_score"] for r in scored) / len(scored), 1)
            if scored else None),
        "company_health_red_flags": red_flags,
        "company_health_capped": capped,
        "company_health_category_mean_coverage_pct": {
            name: round(sum(v) / len(v), 1) for name, v in sorted(category_coverage.items())},
        "company_health_category_mean_score": {
            name: round(sum(v) / len(v), 1) for name, v in sorted(category_scores.items())},
        "most_frequently_unknown_metrics": sorted(unknown_metrics.items(), key=lambda kv: -kv[1]),
        "share_basis_counts": {k: len(v) for k, v in sorted(by_provenance.items())},
        "share_basis_tickers": {k: sorted(v) for k, v in sorted(by_provenance.items())},
        "share_basis_hard_blocked": sorted(by_provenance.get(share_basis.UNKNOWN, [])),
        "oldest_share_basis_days": sorted(basis_ages.items(), key=lambda kv: -kv[1])[:8],
        "clearing_the_75pct_gate": len(clearing),
        "blocked_by_coverage": n - len(clearing),
        "mean_company_health_coverage_pct": round(
            sum(r.get("company_health_coverage_pct") or 0 for r in results) / n, 1),
        "mean_valuation_coverage_pct": round(
            sum(r.get("valuation_coverage_pct") or 0 for r in results) / n, 1),
        "tickers_with_no_history": [r["ticker"] for r in results if not r.get("periods")],
        "tickers_not_in_usd": [r["ticker"] for r in results
                               if r.get("currency") not in (None, "USD")],
        "tickers_with_implausible_metrics": implausible,
        "tickers_with_anomaly_warnings": anomalies,
        "tickers_using_derived_figures": derived,
        "most_commonly_missing_inputs": sorted(missing_counts.items(), key=lambda kv: -kv[1])[:15],
        "why_each_metric_is_unknown": unknown_reasons,
        "verdict": (
            "READY — coverage clears the gate on enough of the universe for Build C to proceed."
            if len(clearing) >= n * 0.8 and not implausible else
            "NOT READY — see blocked_by_coverage and tickers_with_implausible_metrics. An "
            "implausible metric is a bug to fix before any score consumes it, not a row to skip."),
        "valuation_note": (
            "Valuation coverage is reported separately and deliberately. Removing the 200-day "
            "moving average as a BUY gate makes valuation the load-bearing constraint, and a "
            "weakly populated valuation score must not be allowed to issue BUY verdicts. The "
            "missing forward-estimate and intrinsic-value weights are NOT redistributed."),
    }
