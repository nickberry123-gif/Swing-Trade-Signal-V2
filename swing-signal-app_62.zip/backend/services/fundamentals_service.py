"""
Fundamentals + earnings caching layer (Phase 4).

Fundamentals change ~4 times a year, so they're cached aggressively (30 days for fundamentals,
7 days for earnings timing) — SEC's fair-access policy expects exactly this kind of restraint,
and there is no benefit to refetching a 10-K on every page load.

On a provider failure the last cached row is served with `stale=True` rather than nothing, but
it is never relabeled as fresh; if there's no cache at all, the result is an explicit
UNAVAILABLE with the real error message attached.
"""
import json
from dataclasses import asdict
from datetime import datetime, timedelta, timezone

from providers.base import ProviderError
from providers.sec_edgar_provider import SecEdgarProvider
from services.quality_score import breakdown_to_json, compute_quality_score

FUNDAMENTALS_TTL = timedelta(days=30)
EARNINGS_TTL = timedelta(days=7)

_provider = None


def get_fundamentals_provider():
    """Single shared provider instance so the SEC ticker->CIK map is fetched once per process."""
    global _provider
    if _provider is None:
        _provider = SecEdgarProvider()
    return _provider


def _is_fresh(fetched_at: str | None, ttl: timedelta) -> bool:
    if not fetched_at:
        return False
    try:
        ts = datetime.fromisoformat(fetched_at)
    except (TypeError, ValueError):
        return False
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - ts) < ttl


def _row_to_dict(row):
    return dict(row) if row is not None else None


def _store_fundamentals(db, f_dict: dict, quality: dict):
    db.execute(
        """
        INSERT INTO fundamentals (
            ticker, revenue, revenue_prior, revenue_growth_pct, net_income, eps_diluted,
            eps_growth_pct, gross_profit, gross_margin_pct, operating_income,
            operating_margin_pct, operating_cash_flow, capex, free_cash_flow, fcf_margin_pct,
            roic_pct, total_debt, total_cash, stockholders_equity, long_term_quality_score,
            long_term_quality_breakdown, fiscal_year, filed, taxonomy, currency,
            warnings_json, source, as_of, fetched_at)
        VALUES (:ticker, :revenue, :revenue_prior, :revenue_growth_pct, :net_income,
                :eps_diluted, :eps_growth_pct, :gross_profit, :gross_margin_pct,
                :operating_income, :operating_margin_pct, :operating_cash_flow, :capex,
                :free_cash_flow, :fcf_margin_pct, :roic_pct, :total_debt, :total_cash,
                :stockholders_equity, :long_term_quality_score, :long_term_quality_breakdown,
                :fiscal_year, :filed, :taxonomy, :currency, :warnings_json, :source,
                :as_of, :fetched_at)
        ON CONFLICT(ticker) DO UPDATE SET
            revenue=excluded.revenue, revenue_prior=excluded.revenue_prior,
            revenue_growth_pct=excluded.revenue_growth_pct, net_income=excluded.net_income,
            eps_diluted=excluded.eps_diluted, eps_growth_pct=excluded.eps_growth_pct,
            gross_profit=excluded.gross_profit, gross_margin_pct=excluded.gross_margin_pct,
            operating_income=excluded.operating_income,
            operating_margin_pct=excluded.operating_margin_pct,
            operating_cash_flow=excluded.operating_cash_flow, capex=excluded.capex,
            free_cash_flow=excluded.free_cash_flow, fcf_margin_pct=excluded.fcf_margin_pct,
            roic_pct=excluded.roic_pct, total_debt=excluded.total_debt,
            total_cash=excluded.total_cash, stockholders_equity=excluded.stockholders_equity,
            long_term_quality_score=excluded.long_term_quality_score,
            long_term_quality_breakdown=excluded.long_term_quality_breakdown,
            fiscal_year=excluded.fiscal_year, filed=excluded.filed,
            taxonomy=excluded.taxonomy, currency=excluded.currency,
            warnings_json=excluded.warnings_json, source=excluded.source, as_of=excluded.as_of,
            fetched_at=excluded.fetched_at
        """,
        {
            **{k: f_dict.get(k) for k in (
                "ticker", "revenue", "revenue_prior", "revenue_growth_pct", "net_income",
                "eps_diluted", "eps_growth_pct", "gross_profit", "gross_margin_pct",
                "operating_income", "operating_margin_pct", "operating_cash_flow", "capex",
                "free_cash_flow", "fcf_margin_pct", "roic_pct", "total_debt", "total_cash",
                "stockholders_equity", "fiscal_year", "filed", "taxonomy", "currency",
                "source", "as_of")},
            "long_term_quality_score": quality.get("score"),
            "long_term_quality_breakdown": breakdown_to_json(quality),
            "warnings_json": json.dumps(f_dict.get("warnings") or []),
            "fetched_at": datetime.now(timezone.utc).isoformat(),
        },
    )
    db.commit()


def get_fundamentals(db, ticker: str, force_refresh: bool = False) -> dict:
    ticker = ticker.upper()
    cached = _row_to_dict(
        db.execute("SELECT * FROM fundamentals WHERE ticker = ?", (ticker,)).fetchone())

    if not force_refresh and cached and _is_fresh(cached.get("fetched_at"), FUNDAMENTALS_TTL):
        return _shape(cached, stale=False, source_status="CACHED")

    try:
        f = get_fundamentals_provider().get_fundamentals(ticker)
    except ProviderError as e:
        if cached:
            out = _shape(cached, stale=True, source_status="STALE_CACHE")
            out["data_error"] = str(e)
            return out
        return {
            "ticker": ticker, "data_status": "UNAVAILABLE", "data_error": str(e),
            "long_term_quality_score": None, "thesis": "UNAVAILABLE",
            "quality_breakdown": [], "warnings": [
                "Fundamental data could not be retrieved — quality score unavailable. "
                "This is not a score of zero."],
        }

    f_dict = asdict(f)
    f_dict["fetched_at"] = f.fetched_at.isoformat() if f.fetched_at else None
    quality = compute_quality_score(f_dict)
    _store_fundamentals(db, f_dict, quality)

    row = _row_to_dict(db.execute("SELECT * FROM fundamentals WHERE ticker = ?", (ticker,)).fetchone())
    return _shape(row, stale=False, source_status="LIVE")


def _shape(row: dict, stale: bool, source_status: str) -> dict:
    """Normalise a DB row into the API/UI shape, re-deriving the quality breakdown from the
    stored JSON so cached rows expose exactly the same structure as freshly-fetched ones."""
    try:
        stored = json.loads(row.get("long_term_quality_breakdown") or "{}")
    except (TypeError, ValueError):
        stored = {}
    try:
        warnings = json.loads(row.get("warnings_json") or "[]")
    except (TypeError, ValueError):
        warnings = []

    score = row.get("long_term_quality_score")
    thesis = "UNAVAILABLE"
    if score is not None:
        thesis = ("STRONG" if score >= 80 else "HEALTHY" if score >= 62 else
                  "WATCH" if score >= 45 else "DETERIORATING" if score >= 28 else "BROKEN")

    out = {k: row.get(k) for k in (
        "ticker", "revenue", "revenue_prior", "revenue_growth_pct", "net_income", "eps_diluted",
        "eps_growth_pct", "gross_profit", "gross_margin_pct", "operating_income",
        "operating_margin_pct", "operating_cash_flow", "capex", "free_cash_flow",
        "fcf_margin_pct", "roic_pct", "total_debt", "total_cash", "stockholders_equity",
        "long_term_quality_score", "fiscal_year", "filed", "taxonomy", "currency", "source",
        "as_of", "fetched_at")}
    out.update({
        # THE GUARD FOR EVERY PRICE-TIMES-FUNDAMENTAL CALCULATION IN v3. Market cap, P/E,
        # enterprise value and FCF yield all multiply a fundamental by a US-dollar share price.
        # That is only valid when the fundamental is itself in dollars, and two of the fifty
        # companies report in euros and kroner. Strictly True only for a recorded "USD": a row
        # cached before this column existed reads NULL, and "we didn't record it" must not be
        # read as "it was dollars" — it forces a refetch instead of a wrong ratio.
        "can_combine_with_usd_prices": row.get("currency") == "USD",
        "data_status": "STALE" if stale else "OK",
        "source_status": source_status,
        "thesis": thesis,
        "quality_breakdown": stored.get("breakdown", []),
        "coverage_pct": stored.get("coverage_pct"),
        "criteria_evaluated": stored.get("criteria_evaluated"),
        "criteria_total": stored.get("criteria_total"),
        "warnings": warnings + (stored.get("warnings") or []),
    })
    return out


def get_earnings_info(db, ticker: str, force_refresh: bool = False) -> dict:
    ticker = ticker.upper()
    cached = _row_to_dict(
        db.execute("SELECT * FROM earnings_info WHERE ticker = ?", (ticker,)).fetchone())

    if not force_refresh and cached and _is_fresh(cached.get("fetched_at"), EARNINGS_TTL):
        return _shape_earnings(cached, stale=False)

    try:
        info = get_fundamentals_provider().get_earnings_info(ticker)
    except ProviderError as e:
        if cached:
            out = _shape_earnings(cached, stale=True)
            out["data_error"] = str(e)
            return out
        return {"ticker": ticker, "data_status": "UNAVAILABLE", "data_error": str(e),
                "estimated_next_report": None, "estimate_confidence": None, "warnings": []}

    db.execute(
        """
        INSERT INTO earnings_info (ticker, last_period_end, last_filed, last_form,
                                    median_days_between_reports, estimated_next_report,
                                    estimate_confidence, warnings_json, source, fetched_at)
        VALUES (:ticker, :last_period_end, :last_filed, :last_form,
                :median_days_between_reports, :estimated_next_report, :estimate_confidence,
                :warnings_json, :source, :fetched_at)
        ON CONFLICT(ticker) DO UPDATE SET
            last_period_end=excluded.last_period_end, last_filed=excluded.last_filed,
            last_form=excluded.last_form,
            median_days_between_reports=excluded.median_days_between_reports,
            estimated_next_report=excluded.estimated_next_report,
            estimate_confidence=excluded.estimate_confidence,
            warnings_json=excluded.warnings_json, source=excluded.source,
            fetched_at=excluded.fetched_at
        """,
        {
            "ticker": info.ticker, "last_period_end": info.last_period_end,
            "last_filed": info.last_filed, "last_form": info.last_form,
            "median_days_between_reports": info.median_days_between_reports,
            "estimated_next_report": info.estimated_next_report,
            "estimate_confidence": info.estimate_confidence,
            "warnings_json": json.dumps(info.warnings), "source": info.source,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
        },
    )
    db.commit()
    row = _row_to_dict(db.execute("SELECT * FROM earnings_info WHERE ticker = ?", (ticker,)).fetchone())
    return _shape_earnings(row, stale=False)


def _shape_earnings(row: dict, stale: bool) -> dict:
    try:
        warnings = json.loads(row.get("warnings_json") or "[]")
    except (TypeError, ValueError):
        warnings = []
    out = {k: row.get(k) for k in (
        "ticker", "last_period_end", "last_filed", "last_form",
        "median_days_between_reports", "estimated_next_report", "estimate_confidence",
        "source", "fetched_at")}
    out["data_status"] = "STALE" if stale else "OK"
    out["warnings"] = warnings
    out["days_until_estimated_report"] = _days_until(row.get("estimated_next_report"))
    return out


def _days_until(date_str: str | None):
    if not date_str:
        return None
    try:
        target = datetime.fromisoformat(date_str).replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None
    return (target - datetime.now(timezone.utc)).days
