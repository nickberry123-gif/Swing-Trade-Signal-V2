"""
Shared plumbing for the long-running background analyses (backtest, annual backtest, entry test,
selection test, pattern test).

WHY THIS MODULE EXISTS — the failure it was written to prevent
-------------------------------------------------------------
Every one of those routers used to do this:

    db = database.connect(...)          # opened FIRST
    bars = load(db)                     # seconds
    result = compute(bars)              # SIXTEEN TO NINETEEN MINUTES, db sitting idle
    db.execute("UPDATE ... status='complete'", ...)   # <-- fails here

Neon (the production Postgres) closes idle connections after a few minutes. Two annual-backtest
runs completed their work correctly and then lost all of it at the final write:

    psycopg.OperationalError: sending query and params failed:
    SSL connection has been closed unexpectedly

The error handler then tried to record the failure down that SAME dead connection, so it threw
too and was swallowed by a bare `except: pass`. The run row was left saying 'running' forever
with no thread behind it, and the page polled it indefinitely.

THE RULE THIS MODULE ENFORCES
-----------------------------
A database connection is opened, used, and closed inside one short operation. It is never held
across the computation. Concretely:

  * load phase   — own connection, closed before computing
  * compute      — NO connection held at all
  * progress     — own short-lived connection per write (which is also why progress writes are
                   safe: they cannot inherit a stale socket)
  * save phase   — a FRESH connection, opened after the compute finishes
  * failure path — also a fresh connection, because the old one is the prime suspect

Every write here is best-effort and must never raise into the worker thread: a failure to record
progress must not destroy a result that took twenty minutes to produce.
"""
import json
import logging
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone

import database
from config import Config

logger = logging.getLogger(__name__)

# A run still marked 'running' after this long is treated as dead. Chosen well above the slowest
# observed real run (~19 minutes for the annual comparison on the free tier's 0.15 CPU) so a
# genuinely slow run is never reaped out from under itself.
STALE_RUN_MINUTES = 45

STALE_ERROR = (
    "This run stopped without finishing — most often because the server restarted or went to "
    "sleep while it was working. Nothing was saved. Start it again."
)


def open_db():
    """A brand-new connection. Callers must close it."""
    return database.connect(Config.DATABASE_URL, Config.DATABASE_PATH)


@contextmanager
def short_lived_db():
    """Open, use, close — the only connection lifetime this module permits."""
    db = open_db()
    try:
        yield db
    finally:
        try:
            db.close()
        except Exception:  # noqa: BLE001 — closing a dead socket must not mask the real error
            logger.debug("Ignoring error while closing a short-lived connection", exc_info=True)


# ---------------------------------------------------------------- status writes

def write_progress(table: str, run_id: int, message: str) -> bool:
    """Record human-readable progress. Best-effort: returns False rather than raising.

    Losing a progress line is cosmetic. Raising here would abort a run that is working fine.
    """
    try:
        with short_lived_db() as db:
            db.execute(f"UPDATE {table} SET progress=? WHERE id=?", (message, run_id))
            db.commit()
        return True
    except Exception:  # noqa: BLE001
        logger.warning("Could not write progress for %s run %s", table, run_id, exc_info=True)
        return False


def mark_complete(table: str, run_id: int, result: dict) -> None:
    """Save the result on a FRESH connection. This is the write that used to be lost."""
    with short_lived_db() as db:
        db.execute(
            f"UPDATE {table} SET results_json=?, status='complete', progress=? WHERE id=?",
            (json.dumps(result), "Complete.", run_id))
        db.commit()


def mark_failed(table: str, run_id: int, error: str) -> None:
    """Record a failure on its own fresh connection.

    Deliberately does NOT reuse the caller's connection: when a run fails, a dead connection is
    the single most likely cause, and reusing it is how the original bug stayed invisible.
    """
    try:
        with short_lived_db() as db:
            db.execute(f"UPDATE {table} SET status='failed', error=?, progress=? WHERE id=?",
                       (str(error)[:2000], "Failed.", run_id))
            db.commit()
    except Exception:  # noqa: BLE001
        logger.exception("Could not even record the failure of %s run %s", table, run_id)


# ---------------------------------------------------------------- stale runs

def _parse_ts(value) -> datetime | None:
    """created_at is TEXT UTC in both backends, but Postgres may hand back a datetime."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    try:
        parsed = datetime.fromisoformat(str(value).strip().replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def reap_stale_runs(db, table: str, minutes: int = STALE_RUN_MINUTES) -> int:
    """Flip abandoned 'running' rows to 'failed'. Returns how many were reaped.

    Without this a killed thread leaves a row claiming to be in progress with nothing working on
    it, and the page polls it forever. Called on the list/detail endpoints so it self-heals on
    the next page load with no cron, no scheduler and no extra moving parts.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=minutes)
    try:
        rows = db.execute(
            f"SELECT id, created_at FROM {table} WHERE status = 'running'").fetchall()
    except Exception:  # noqa: BLE001 — never let housekeeping break a read endpoint
        logger.warning("Could not scan %s for stale runs", table, exc_info=True)
        return 0

    reaped = 0
    for row in rows:
        created = _parse_ts(dict(row).get("created_at"))
        if created is None or created > cutoff:
            continue
        try:
            db.execute(f"UPDATE {table} SET status='failed', error=?, progress=? WHERE id=?",
                       (STALE_ERROR, "Abandoned.", dict(row)["id"]))
            db.commit()
            reaped += 1
        except Exception:  # noqa: BLE001
            logger.warning("Could not reap %s run %s", table, dict(row).get("id"), exc_info=True)
    if reaped:
        logger.info("Reaped %s stale run(s) from %s", reaped, table)
    return reaped


# ---------------------------------------------------------------- the runner

def run_background_job(app, *, table: str, run_id: int, label: str, load, compute, save=None):
    """Run one analysis with the connection discipline described at the top of this module.

    load(db)        -> whatever compute needs. Runs with a short-lived connection.
    compute(loaded, progress) -> the result dict. Runs with NO connection held.
                                 `progress` is a callable taking a message string.
    save(db, result) -> optional custom persistence on a FRESH connection. When omitted the
                        result is written to `table`.results_json.
    """
    def progress(message: str) -> None:
        # Swallows everything, deliberately. A progress line is cosmetic; a result is twenty
        # minutes of work. Nothing about reporting where we are may be capable of destroying it.
        try:
            write_progress(table, run_id, message)
        except Exception:  # noqa: BLE001
            logger.debug("Progress write failed for %s run %s", table, run_id, exc_info=True)

    with app.app_context():
        try:
            progress("Loading price history…")
            with short_lived_db() as db:
                loaded = load(db)

            # ---- no database connection is held from here until the compute returns ----
            result = compute(loaded, progress)

            progress("Saving results…")
            if save is None:
                mark_complete(table, run_id, result)
            else:
                with short_lived_db() as db:
                    save(db, result)
        except Exception as e:  # noqa: BLE001 — must be recorded, never lost silently
            logger.exception("%s run %s failed", label, run_id)
            mark_failed(table, run_id, str(e))
