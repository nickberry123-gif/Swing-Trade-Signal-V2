"""
Sector baskets: the 50 treated as five home-made ETFs, measured against the real ones.

WHAT THIS ANSWERS
-----------------
"If I'd held my ten semiconductor picks as an equal-weight fund, how would that have done
against SMH?" — for each of the five sectors, and for the whole 50 against SPY.

THE BIAS THAT WOULD MAKE EVERY NUMBER HERE A LIE, IF IT WERE NOT LABELLED
------------------------------------------------------------------------
These fifty stocks were chosen in 2026, by a person who already knew which ones had gone up.
NVDA is in the list BECAUSE of what it did between 2020 and 2026. So the basket will beat SMH,
and it will beat it by a lot, and approximately none of that is skill — it is the answer being
known before the question was asked.

Every basket therefore carries `hindsight_selected: True` and the sector ETF beside it. The ETF
is the honest comparator precisely because nobody picked its holdings with a 2026 newspaper: it
is what the sector did, against what the sector did *to the ten you happened to choose*.

What is NOT here, deliberately: a "random ten from the same sector" control. That would be the
statistically proper comparison, and it cannot be built — the app knows about fifty companies,
not the several hundred that would be needed to sample from. Constructing the control from a
list I made up would be fabricating the very evidence the control exists to provide.

THE WEIGHTING SCHEMES, AND WHY THERE IS NO SEARCH FOR THE BEST ONE
------------------------------------------------------------------
Asked for "a pie that beats the ETFs", the tempting move is to search weights until one wins.
That search always wins, and it means nothing: this app has already measured strategies with
ZERO real edge returning +15.2% a year when the best of a hundred attempts was kept.

So there are four schemes, all fixed in advance, none of them tuned:

  equal              — 1/N. The baseline, and hard to beat honestly.
  sector_equal       — 20% to each of the five sectors, split evenly inside.
  inverse_volatility — more money in the steadier names. Weights come from the PRIOR calendar
                       year's daily volatility, never the year being measured.
  momentum_tilt      — equal weight across the best HALF from LAST year. A pre-committed rule
                       using only past data, which is what a momentum fund actually is.

And they are judged out of sample: picked on the early years, scored on the later ones. A scheme
that wins on the years used to choose it has demonstrated nothing at all.

LOOK-AHEAD
----------
Both data-driven schemes read strictly the PRIOR calendar year. `_prior_year_inputs` is the only
place weights are derived, it is given year-1 and never year, and there is a test that breaks if
that ever changes. Weighting 2022 by 2022's volatility would be a perfect strategy and a
fictional one.
"""
import logging
import statistics
from datetime import date, datetime, timezone

import pandas as pd

from config import STOCK_UNIVERSE
from services.yearly_service import YEARS_SHOWN, load_bars_for_year_view

log = logging.getLogger(__name__)

# The sector each basket is measured against. One real, liquid, US-listed fund per sector, which
# is the point: it is priced by the market rather than assembled here.
SECTOR_BENCHMARK = {
    "Semiconductors": "SMH",
    "Technology": "XLK",
    "Consumer": "XLY",
    "Industrials": "XLI",
    "Healthcare": "XLV",
}

WHOLE_UNIVERSE_BENCHMARKS = ["SPY", "QQQ"]

# Fewer bars than this in a calendar year and the year is not scored for that stock. A company
# that listed in October has a "year return" covering two months, and averaging it beside eleven
# full years would silently overweight a partial one.
MIN_BARS_FOR_YEAR = 120

# Keep the best HALF, as a fraction rather than a count.
#
# It was a flat 25 first, and that was wrong in a way no test of the whole universe would have
# caught: each sector basket holds ten stocks, so "keep the top 25" kept all ten and the scheme
# quietly became equal weight on every sector while still being labelled momentum. A fraction
# scales; a count only worked for the one basket it was written for.
#
# A half is fixed in advance and never tuned. The moment this becomes a range that gets searched,
# the page stops measuring anything — zero-edge strategies returned +15.2% a year in this app
# when the best of a hundred tries was kept.
MOMENTUM_KEEP_FRACTION = 0.5


def _sectors() -> dict:
    out = {}
    for s in STOCK_UNIVERSE:
        out.setdefault(s["sector"], []).append(s["ticker"])
    return out


def _prepare(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    d = df.copy()
    ts = pd.to_datetime(d["ts"], format="mixed", utc=True)
    d["_date"] = ts.dt.date
    d["_year"] = ts.dt.year
    return d.sort_values("_date")


def _year_return(d: pd.DataFrame, year: int):
    """A calendar year's return from first close to last close, or None if too thin to score.

    First-to-last CLOSE, not the yearly average the price table uses. An average answers "what
    did it typically trade at"; a basket needs "what did a pound put in on 1 January become",
    and those are different questions with different answers.
    """
    rows = d[d["_year"] == year]
    if len(rows) < MIN_BARS_FOR_YEAR:
        return None, len(rows)
    first = float(rows["close"].iloc[0])
    last = float(rows["close"].iloc[-1])
    if not first:
        return None, len(rows)
    return round((last - first) / first * 100, 3), len(rows)


def _year_volatility(d: pd.DataFrame, year: int):
    """Standard deviation of daily returns within one calendar year, in percent."""
    rows = d[d["_year"] == year]
    if len(rows) < MIN_BARS_FOR_YEAR:
        return None
    changes = rows["close"].pct_change().dropna()
    if len(changes) < 2:
        return None
    return float(statistics.pstdev(changes.tolist())) * 100


def load_universe(db, today: date | None = None) -> dict:
    """One pass over the bars: year returns and year volatilities for every ticker and benchmark.

    Loaded once and reused by every scheme. Loading per scheme would walk six years of daily bars
    for fifty stocks four times over, which is precisely how the Yearly page previously became
    indistinguishable from a hung server.
    """
    today = today or datetime.now(timezone.utc).date()
    years = [today.year - i for i in range(YEARS_SHOWN - 1, -1, -1)]
    symbols = [s["ticker"] for s in STOCK_UNIVERSE]
    symbols += sorted(set(SECTOR_BENCHMARK.values()) | set(WHOLE_UNIVERSE_BENCHMARKS))

    data, failures = {}, {}
    for sym in symbols:
        try:
            df, _meta = load_bars_for_year_view(db, sym, today)
            d = _prepare(df)
            if d.empty:
                failures[sym] = "no bars"
                continue
            per_year = {y: _year_return(d, y) for y in years}
            data[sym] = {
                "returns": {y: per_year[y][0] for y in years},
                "bars": {y: per_year[y][1] for y in years},
                "volatility": {y: _year_volatility(d, y) for y in years},
            }
        except Exception as e:  # noqa: BLE001 — one bad symbol must not blank the page
            try:
                db.rollback()
            except Exception:  # noqa: BLE001
                pass
            log.warning("Sector basket load failed for %s: %s", sym, e)
            failures[sym] = str(e)
    return {"years": years, "data": data, "failures": failures, "today": today}


# ------------------------------------------------------------------ weighting schemes

def _prior_year_inputs(loaded: dict, members: list, year: int) -> dict:
    """Everything a data-driven weighting is allowed to see: strictly year MINUS ONE.

    THE ONLY PLACE weights touch historical numbers. Passing `year` here instead of `year - 1`
    would weight each year by its own outcome, producing a flawless strategy that could never
    have been run. There is a test that fails if this function is ever handed the current year.
    """
    prior = year - 1
    return {
        t: {"return": loaded["data"].get(t, {}).get("returns", {}).get(prior),
            "volatility": loaded["data"].get(t, {}).get("volatility", {}).get(prior)}
        for t in members
    }


def weights_equal(members: list, loaded: dict, year: int) -> dict:
    return {t: 1.0 for t in members}


def weights_sector_equal(members: list, loaded: dict, year: int) -> dict:
    """20% to each sector present, split evenly inside it.

    Different from equal weight only because the sectors are not the same size — here they are
    ten each, so on the full universe the two coincide. It is kept anyway because it stops
    coinciding the moment a stock is added or dropped, and a scheme that silently becomes a
    duplicate is worse than one that is visibly the same.
    """
    by_sector = {}
    for sector, tickers in _sectors().items():
        present = [t for t in tickers if t in members]
        if present:
            by_sector[sector] = present
    if not by_sector:
        return {}
    per_sector = 1.0 / len(by_sector)
    weights = {}
    for present in by_sector.values():
        for t in present:
            weights[t] = per_sector / len(present)
    return weights


def weights_inverse_volatility(members: list, loaded: dict, year: int) -> dict:
    """More money in the names that were steadier LAST year.

    A stock with no prior-year volatility gets the median weight rather than being dropped or
    given zero: dropping it silently changes the basket's membership, and zero would be a claim
    that it is infinitely volatile. Neither is true; "we don't know" is.
    """
    inputs = _prior_year_inputs(loaded, members, year)
    vols = {t: v["volatility"] for t, v in inputs.items()
            if v["volatility"] is not None and v["volatility"] > 0}
    if not vols:
        return weights_equal(members, loaded, year)
    raw = {t: 1.0 / v for t, v in vols.items()}
    median = statistics.median(raw.values())
    return {t: raw.get(t, median) for t in members}


def weights_momentum_tilt(members: list, loaded: dict, year: int) -> dict:
    """Equal weight across the 25 that did best LAST year; nothing in the rest.

    A pre-committed rule reading only past data — which is what a momentum fund is. It is NOT a
    search: the 25 was fixed before any result was seen and is not adjusted afterwards.
    """
    inputs = _prior_year_inputs(loaded, members, year)
    ranked = sorted((t for t in members if inputs[t]["return"] is not None),
                    key=lambda t: inputs[t]["return"], reverse=True)
    if not ranked:
        # No prior year to rank on — the first year of the window. Equal weight is the honest
        # fallback; guessing a ranking would invent one.
        return weights_equal(members, loaded, year)
    n_keep = max(1, round(len(ranked) * MOMENTUM_KEEP_FRACTION))
    keep = set(ranked[:n_keep])
    return {t: (1.0 if t in keep else 0.0) for t in members}


SCHEMES = {
    "equal": {"fn": weights_equal, "label": "Equal weight",
              "description": "Same amount in each. The baseline, and harder to beat than it looks."},
    "sector_equal": {"fn": weights_sector_equal, "label": "Sector equal",
                     "description": "20% to each sector, split evenly inside it."},
    "inverse_volatility": {"fn": weights_inverse_volatility, "label": "Inverse volatility",
                           "description": "More in the steadier names, measured on LAST year only."},
    "momentum_tilt": {"fn": weights_momentum_tilt, "label": "Momentum tilt",
                      "description": f"Equal weight across the best "
                                     f"{int(MOMENTUM_KEEP_FRACTION * 100)}% from LAST year."},
}


# ------------------------------------------------------------------ basket construction

def basket_year_return(loaded: dict, members: list, year: int, weight_fn) -> dict:
    """One calendar year of one basket, rebalanced to target weights on 1 January.

    Members with no scoreable year (listed late, delisted, data missing) are EXCLUDED and
    counted, not treated as zero. A stock that did not exist did not return 0% — it returned
    nothing, and averaging a zero in would drag the basket toward a number no investor could
    have experienced.
    """
    weights = weight_fn(members, loaded, year)
    contributions, missing = [], []
    for t in members:
        r = loaded["data"].get(t, {}).get("returns", {}).get(year)
        w = weights.get(t, 0.0)
        if r is None:
            missing.append(t)
            continue
        if w > 0:
            contributions.append((w, r))
    total_w = sum(w for w, _ in contributions)
    if total_w <= 0:
        return {"year": year, "return_pct": None, "holdings": 0, "missing": missing,
                "reason": "no member had a scoreable year"}
    weighted = sum(w * r for w, r in contributions) / total_w
    return {"year": year, "return_pct": round(weighted, 2), "holdings": len(contributions),
            "missing": missing,
            "partial": bool(missing),
            "reason": (f"{len(missing)} member(s) had no usable data this year: "
                       f"{', '.join(missing)}" if missing else None)}


def _chain(year_returns: list):
    """Compound a list of yearly percentages into one total.

    Chained, not summed. Three years of +10% is +33.1%, not +30%, and the difference grows with
    every year — a page that adds them would understate a good run and flatter a bad one.
    """
    usable = [y["return_pct"] for y in year_returns if y.get("return_pct") is not None]
    if not usable:
        return None
    total = 1.0
    for r in usable:
        total *= (1 + r / 100.0)
    return round((total - 1) * 100, 2)


def _benchmark_years(loaded: dict, symbol: str) -> list:
    return [{"year": y,
             "return_pct": loaded["data"].get(symbol, {}).get("returns", {}).get(y)}
            for y in loaded["years"]]


def build_basket(loaded: dict, name: str, members: list, benchmark: str | None,
                 scheme: str = "equal") -> dict:
    weight_fn = SCHEMES[scheme]["fn"]
    years = [basket_year_return(loaded, members, y, weight_fn) for y in loaded["years"]]
    total = _chain(years)

    bench_years = _benchmark_years(loaded, benchmark) if benchmark else []
    bench_total = _chain(bench_years) if bench_years else None

    per_year_gap = []
    for by in bench_years:
        mine = next((y["return_pct"] for y in years if y["year"] == by["year"]), None)
        per_year_gap.append({
            "year": by["year"],
            "basket_pct": mine,
            "benchmark_pct": by["return_pct"],
            "gap_pct": (round(mine - by["return_pct"], 2)
                        if mine is not None and by["return_pct"] is not None else None),
        })
    beat = [g for g in per_year_gap if g["gap_pct"] is not None and g["gap_pct"] > 0]
    scored = [g for g in per_year_gap if g["gap_pct"] is not None]

    return {
        "name": name,
        "scheme": scheme,
        "scheme_label": SCHEMES[scheme]["label"],
        "members": members,
        "member_count": len(members),
        "benchmark": benchmark,
        "years": years,
        "total_pct": total,
        "benchmark_years": bench_years,
        "benchmark_total_pct": bench_total,
        "total_gap_pct": (round(total - bench_total, 2)
                          if total is not None and bench_total is not None else None),
        "per_year": per_year_gap,
        "years_beaten": len(beat),
        "years_scored": len(scored),
        # THE LABEL THAT STOPS EVERY NUMBER ABOVE FROM BEING A LIE.
        "hindsight_selected": True,
        "hindsight_note": (
            "These holdings were chosen in 2026 by someone who already knew which had gone up. "
            "Beating the sector ETF here is mostly evidence of that, not of skill. The ETF is "
            "the honest comparator because nobody picked ITS holdings with hindsight."),
    }


def compute_sector_baskets(db, today: date | None = None, scheme: str = "equal",
                           loaded: dict | None = None) -> dict:
    loaded = loaded or load_universe(db, today)
    baskets = [build_basket(loaded, sector, members, SECTOR_BENCHMARK.get(sector), scheme)
               for sector, members in sorted(_sectors().items())]
    whole = build_basket(loaded, "All 50", [s["ticker"] for s in STOCK_UNIVERSE],
                         WHOLE_UNIVERSE_BENCHMARKS[0], scheme)
    return {
        "years": loaded["years"],
        "scheme": scheme,
        "sectors": baskets,
        "whole_universe": whole,
        "failures": loaded["failures"],
        "computed_at": datetime.now(timezone.utc).isoformat(),
        "basis": ("Each basket is rebalanced to its target weights on 1 January and held for the "
                  "year. A year's return is first close to last close. Totals are CHAINED, not "
                  "added."),
    }


# ------------------------------------------------------------------ out-of-sample comparison

def compute_scheme_comparison(db, today: date | None = None, loaded: dict | None = None) -> dict:
    """All four weightings on the whole 50, chosen on the early years and scored on the later ones.

    WHY THE SPLIT IS THE WHOLE POINT. Every scheme here will show a large positive total, because
    the holdings were picked with hindsight — that is a constant and it tells you nothing about
    the WEIGHTING. What the split asks is narrower and answerable: did the scheme that looked
    best on the first half stay best on the second half? If the winner changes, the first result
    was noise, and any confidence taken from it would have been misplaced.
    """
    loaded = loaded or load_universe(db, today)
    years = loaded["years"]
    if len(years) < 4:
        return {"error": "Not enough years of history to split into two halves.",
                "years": years, "schemes": []}

    split = len(years) // 2
    early, late = years[:split], years[split:]
    members = [s["ticker"] for s in STOCK_UNIVERSE]

    rows = []
    for key, meta in SCHEMES.items():
        by_year = {y: basket_year_return(loaded, members, y, meta["fn"]) for y in years}
        rows.append({
            "scheme": key,
            "label": meta["label"],
            "description": meta["description"],
            "years": [by_year[y] for y in years],
            "early_total_pct": _chain([by_year[y] for y in early]),
            "late_total_pct": _chain([by_year[y] for y in late]),
            "total_pct": _chain([by_year[y] for y in years]),
        })

    def _best(field):
        scored = [r for r in rows if r[field] is not None]
        return max(scored, key=lambda r: r[field])["scheme"] if scored else None

    best_early, best_late = _best("early_total_pct"), _best("late_total_pct")
    spy_years = {y: loaded["data"].get("SPY", {}).get("returns", {}).get(y) for y in years}

    return {
        "years": years,
        "chosen_on": early,
        "measured_on": late,
        "schemes": rows,
        "best_on_chosen_years": best_early,
        "best_on_measured_years": best_late,
        "held_up": bool(best_early and best_early == best_late),
        "benchmark": {
            "symbol": "SPY",
            "early_total_pct": _chain([{"return_pct": spy_years[y]} for y in early]),
            "late_total_pct": _chain([{"return_pct": spy_years[y]} for y in late]),
            "total_pct": _chain([{"return_pct": spy_years[y]} for y in years]),
        },
        "verdict": (
            f"The best weighting on {early[0]}-{early[-1]} was '{best_early}'. On "
            f"{late[0]}-{late[-1]} it was '{best_late}'. "
            + ("The same scheme won both halves, which is weak evidence it is doing something "
               "real — weak, because four schemes over one universe is a small test."
               if best_early == best_late else
               "The winner CHANGED between the two halves. That is what picking a weighting on "
               "past returns looks like when the pattern was noise, and it is the reason this "
               "page does not search for a best one.")
            if best_early and best_late else "Not enough scored years to judge."),
        "hindsight_note": (
            "Every scheme below is applied to fifty stocks picked in 2026 with hindsight, so all "
            "of them will look strong. Compare the schemes with EACH OTHER, and only across the "
            "two halves. Do not read any single total as a return you could have earned."),
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
