"""
Does the score help choose WHICH stock to buy, given that you are buying anyway?

The entry test answered the timing question by holding the stock constant and varying the date.
This holds the DATE constant and varies the stock: on the first trading day of each month —
every month, no exceptions — does putting the money into the highest-scoring of the 15 beat
spreading it across all 50?

TWO MEASURES, AND THE SECOND IS THE ONE TO TRUST
------------------------------------------------
1. PICK SIMULATION — buy the top-scoring stock each month, or the top 3, or all 50 equally, or
   the bottom-scoring one. Readable, and the closest thing to what a person would actually do.
   It is also statistically weak: about 47 monthly decisions exist in five years, so one lucky
   NVDA pick can carry the entire result.

2. RANK CORRELATION — on each decision date, rank the 15 by score and rank them by what they
   went on to return, then measure how well the two orderings agree (Spearman). This uses every
   stock in every month rather than one pick, so roughly 700 observations instead of 47, and it
   cannot be swung by a single fortunate choice. In practitioner terms this is the information
   coefficient.

The BOTTOM arm is what makes either measure a test rather than a demonstration. If the score
carries information, the top should beat the bottom. If top, bottom and equal-weight all land in
the same place, the ranking is decoration — and no amount of the top arm looking good in a bull
market changes that.

WHY SIGNIFICANCE IS ONLY REPORTED AT ONE HORIZON
------------------------------------------------
Monthly decisions with a one-month forward return do not overlap: each observation covers a
distinct stretch of time, so an ordinary t-statistic means what it normally means. At 3 months
and beyond, consecutive monthly observations share most of their window — a single good quarter
is counted repeatedly — and a t-statistic computed on them is inflated, sometimes by a factor of
three or more. Rather than print a number that flatters the result, the longer horizons report
the correlation with significance explicitly marked unavailable.
"""
import logging
import math
from datetime import datetime, timezone

import pandas as pd

from services.backtest_service import (MIN_WARMUP_BARS, _components_from_indicators,
                                       _indicators_at, _precompute, _regime_by_date)
from services.entry_quality_service import HORIZONS

log = logging.getLogger(__name__)

MIN_TICKERS_PER_DATE = 8     # below this a cross-sectional ranking is not worth computing
TOP_N = 3


def _date_index_maps(bars_by_ticker: dict, tickers: list) -> dict:
    """ticker -> {date string: row index}. Dates are matched by VALUE, never by position.

    Two tickers can have different row counts — a later listing, a missing session — so index i
    is not the same day for both. Aligning on the date string is what stops a decision date for
    one stock being silently compared against a different day for another.
    """
    out = {}
    for t in tickers:
        df = bars_by_ticker.get(t)
        if df is None:
            continue
        out[t] = {str(ts): i for i, ts in enumerate(df["ts"])}
    return out


def _monthly_decision_dates(bars_by_ticker: dict, tickers: list, maps: dict) -> list:
    """First trading day of each calendar month that EVERY ticker has a bar for.

    Restricted to dates where every ticker is also past its warm-up, so the choice is made from
    a full field of 15 rather than from whichever subset happened to have enough history.
    """
    if not maps:
        return []
    common = None
    for t in tickers:
        if t not in maps:
            continue
        eligible = {d for d, i in maps[t].items() if i >= MIN_WARMUP_BARS}
        common = eligible if common is None else (common & eligible)
    if not common:
        return []

    dates = sorted(common)
    seen = set()
    out = []
    for d in dates:
        key = d[:7]          # YYYY-MM
        if key not in seen:
            seen.add(key)
            out.append(d)
    return out


def _forward_return(df: pd.DataFrame, signal_i: int, horizon: int):
    """Buy at the open AFTER the decision bar; value at the close `horizon` bars later."""
    entry_i = signal_i + 1
    exit_i = entry_i + horizon
    if exit_i >= len(df) or entry_i >= len(df):
        return None
    entry = float(df["open"].iloc[entry_i])
    if entry <= 0:
        return None
    return (float(df["close"].iloc[exit_i]) - entry) / entry * 100


def _spearman(scores: list, returns: list):
    """Rank correlation between two lists. None when it is not defined.

    Ranks are averaged over ties, which matters here: scores repeat, and breaking ties by input
    order would invent an ordering the data does not contain.
    """
    if len(scores) < 3:
        return None
    s = pd.Series(scores).rank()
    r = pd.Series(returns).rank()
    if s.nunique() < 2 or r.nunique() < 2:
        return None                       # every score identical: no ranking exists
    c = s.corr(r)
    return None if c is None or (isinstance(c, float) and math.isnan(c)) else float(c)


def _t_stat(values: list):
    """Ordinary one-sample t-statistic. The caller decides whether it is legitimate."""
    if len(values) < 3:
        return None
    s = pd.Series(values, dtype="float64")
    sd = float(s.std(ddof=1))
    if sd == 0:
        return None
    return round(float(s.mean()) / (sd / math.sqrt(len(s))), 2)


def _components_on_date(bars_by_ticker, maps, tickers, date, regime_by_date, pre_cache) -> dict:
    """Every ticker's raw COMPONENTS on one date, computed from that date's history only.

    Components rather than a finished score, because this is the expensive step and it does not
    depend on the strategy. Once cached, scoring the user's strategy and several hundred random
    ones costs almost nothing — which is the only reason a proper null distribution is
    affordable here at all.
    """
    out = {}
    for t in tickers:
        idx = maps.get(t, {}).get(date)
        if idx is None or idx < MIN_WARMUP_BARS:
            continue
        df = bars_by_ticker[t]
        ind = _indicators_at(df, pre_cache[t], idx)
        if not ind.get("bars_used"):
            continue
        out[t] = _components_from_indicators(ind, regime_by_date.get(df["ts"].iloc[idx], {}))
    return out


def _scores_from_components(components_by_ticker: dict, strategy: dict) -> dict:
    from services.strategy_service import score_from_components
    return {t: score_from_components(c, strategy)["score"]
            for t, c in components_by_ticker.items()}


def _summarise(values: list) -> dict:
    if not values:
        return {"n": 0, "mean_pct": None, "median_pct": None, "positive_pct": None}
    s = pd.Series(values, dtype="float64")
    return {
        "n": int(len(s)),
        "mean_pct": round(float(s.mean()), 2),
        "median_pct": round(float(s.median()), 2),
        "positive_pct": round(float((s > 0).mean() * 100), 1),
    }


def _evaluate(dates, components_by_date, bars_by_ticker, maps, strategy) -> dict:
    """Everything a strategy scores, from pre-computed components. Cheap by construction."""
    horizons_out = {}
    for label, horizon in HORIZONS:
        ics, picks = [], {"TOP_1": [], f"TOP_{TOP_N}": [], "EQUAL_WEIGHT": [], "BOTTOM_1": []}
        months_used = 0
        for d in dates:
            comps = components_by_date.get(d, {})
            if len(comps) < MIN_TICKERS_PER_DATE:
                continue
            scores = _scores_from_components(comps, strategy)
            rets = {}
            for t in scores:
                r = _forward_return(bars_by_ticker[t], maps[t][d], horizon)
                if r is not None:
                    rets[t] = r
            usable = [t for t in scores if t in rets]
            if len(usable) < MIN_TICKERS_PER_DATE:
                continue
            months_used += 1
            ic = _spearman([scores[t] for t in usable], [rets[t] for t in usable])
            if ic is not None:
                ics.append(ic)
            ranked = sorted(usable, key=lambda t: scores[t], reverse=True)
            picks["TOP_1"].append(rets[ranked[0]])
            picks[f"TOP_{TOP_N}"].append(
                sum(rets[t] for t in ranked[:TOP_N]) / min(TOP_N, len(ranked)))
            picks["EQUAL_WEIGHT"].append(sum(rets[t] for t in usable) / len(usable))
            picks["BOTTOM_1"].append(rets[ranked[-1]])

        non_overlapping = horizon <= 21
        top = _summarise(picks["TOP_1"])
        bottom = _summarise(picks["BOTTOM_1"])
        equal = _summarise(picks["EQUAL_WEIGHT"])
        horizons_out[label] = {
            "months_used": months_used,
            "rank_correlation": {
                "mean": round(sum(ics) / len(ics), 4) if ics else None,
                "months_positive_pct": (round(sum(1 for i in ics if i > 0) / len(ics) * 100, 1)
                                        if ics else None),
                "n": len(ics),
                "t_stat": _t_stat(ics) if non_overlapping else None,
                "t_stat_available": non_overlapping,
                "t_stat_note": (None if non_overlapping else
                                "Not computed: monthly observations at this horizon overlap, so a "
                                "t-statistic would be inflated and misleading."),
            },
            "picks": {k: _summarise(v) for k, v in picks.items()},
            "top_minus_bottom_pct": (round(top["mean_pct"] - bottom["mean_pct"], 2)
                                     if top["mean_pct"] is not None and bottom["mean_pct"] is not None
                                     else None),
            "top_minus_equal_pct": (round(top["mean_pct"] - equal["mean_pct"], 2)
                                    if top["mean_pct"] is not None and equal["mean_pct"] is not None
                                    else None),
        }
    return horizons_out


def run_selection_test(bars_by_ticker: dict, tickers: list, config: dict | None = None,
                       strategy: dict | None = None, random_trials: int = 0) -> dict:
    from services.strategy_service import default_strategy, normalise_strategy, random_strategy
    strategy = normalise_strategy(strategy) if strategy else default_strategy()
    config = config or {}
    tickers = [t for t in tickers if t in bars_by_ticker]
    regime_by_date = (_regime_by_date(bars_by_ticker) if config.get("use_regime", True) else {})

    maps = _date_index_maps(bars_by_ticker, tickers)
    dates = _monthly_decision_dates(bars_by_ticker, tickers, maps)
    pre_cache = {t: _precompute(bars_by_ticker[t]) for t in tickers}

    # Components are computed once per decision date and reused for every horizon AND every
    # strategy — the user's and all the random ones. This is what makes a real null distribution
    # affordable instead of a nice idea.
    components_by_date = {d: _components_on_date(bars_by_ticker, maps, tickers, d,
                                                 regime_by_date, pre_cache)
                          for d in dates}

    horizons_out = _evaluate(dates, components_by_date, bars_by_ticker, maps, strategy)

    # THE NULL DISTRIBUTION. Random weightings run through the identical test, so "is this
    # better than noise?" has a measured answer. Thresholds, filters and exits are held fixed
    # so the comparison isolates the weights.
    null = None
    if random_trials and random_trials > 0:
        import numpy as np
        rng = np.random.default_rng(12345)     # fixed seed: the same result twice, not a lottery
        samples = {label: [] for label, _h in HORIZONS}
        for _ in range(int(random_trials)):
            rand = random_strategy(rng, strategy)
            rout = _evaluate(dates, components_by_date, bars_by_ticker, maps, rand)
            for label, _h in HORIZONS:
                ic = (rout.get(label, {}).get("rank_correlation") or {}).get("mean")
                if ic is not None:
                    samples[label].append(ic)
        null = {}
        for label, _h in HORIZONS:
            vals = sorted(samples[label])
            mine = (horizons_out.get(label, {}).get("rank_correlation") or {}).get("mean")
            if not vals or mine is None:
                null[label] = {"trials": len(vals), "percentile": None, "median": None}
                continue
            beaten = sum(1 for v in vals if v < mine)
            null[label] = {
                "trials": len(vals),
                "percentile": round(beaten / len(vals) * 100, 1),
                "median": round(vals[len(vals) // 2], 4),
                "best": round(vals[-1], 4),
                "worst": round(vals[0], 4),
            }

    return {
        "config": {
            "strategy_name": strategy.get("name"),
            "strategy": strategy,
            "use_regime": config.get("use_regime", True),
            "decision_rule": "First trading day of every calendar month, without exception.",
            "arms": {
                "TOP_1": "All of the month's money into the highest-scoring stock.",
                f"TOP_{TOP_N}": f"Split equally across the {TOP_N} highest-scoring stocks.",
                "EQUAL_WEIGHT": "Split equally across all stocks — the do-nothing baseline.",
                "BOTTOM_1": "All of it into the LOWEST-scoring stock — the control that makes "
                            "this a test. If the score works, this should be the worst arm.",
            },
            "horizons": [{"label": l, "trading_days": h} for l, h in HORIZONS],
        },
        "tickers": tickers,
        "decision_dates": len(dates),
        "first_date": dates[0] if dates else None,
        "last_date": dates[-1] if dates else None,
        "horizons": horizons_out,
        "null_distribution": null,
        "verdict": _verdict(horizons_out, null),
        "limitations": LIMITATIONS,
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }


def _verdict(horizons: dict, null: dict | None = None) -> dict:
    """Deliberately hard to please.

    The failure mode to guard against is a bull market making every arm look good and the top
    arm looking best by luck. So a positive reading requires the score to rank correctly on
    average AND the top arm to beat the bottom arm — a single strong pick can move the second
    without moving the first.
    """
    h12 = horizons.get("12 months") or {}
    ic12 = (h12.get("rank_correlation") or {}).get("mean")
    tmb12 = h12.get("top_minus_bottom_pct")
    months = h12.get("months_used") or 0

    if ic12 is None:
        return {"headline": "UNAVAILABLE",
                "detail": "Not enough overlapping history to rank the stocks against each other."}

    sample_note = (f" Based on {months} monthly decisions, which is a small sample — treat the "
                   f"size of any effect as indicative, not measured.")
    # A strategy that only beats half the random weightings has demonstrated nothing, however
    # good its raw number looks. This sentence is the difference between a finding and a fluke.
    pct = ((null or {}).get("12 months") or {}).get("percentile")
    if pct is not None:
        sample_note += (f" It beat {pct}% of randomly-weighted strategies run through the same "
                        f"test; below about 95% that is indistinguishable from luck.")

    if ic12 <= 0 and (tmb12 is None or tmb12 <= 0):
        return {"headline": "NO SELECTION SKILL",
                "detail": ("Higher-scoring stocks did not go on to outperform lower-scoring ones "
                           "at 12 months, and picking the top scorer did not beat picking the "
                           "bottom one." + sample_note),
                "ic_12m": ic12}
    if ic12 <= 0.05 or tmb12 is None or tmb12 <= 0:
        return {"headline": "WEAK AND INCONSISTENT",
                "detail": (f"The ranking agreed with what actually happened only slightly "
                           f"(correlation {ic12:+.3f}), and the top-versus-bottom result does not "
                           f"clearly support it. Not something to act on." + sample_note),
                "ic_12m": ic12}
    if pct is not None and pct < 95:
        return {"headline": "WEAK AND INCONSISTENT",
                "detail": ("The ranking looked helpful, but it did not stand out against random "
                           "weightings of the same components." + sample_note),
                "ic_12m": ic12}
    return {"headline": "SOME SELECTION SKILL",
            "detail": (f"Higher-scoring stocks did tend to outperform lower-scoring ones at 12 "
                       f"months (correlation {ic12:+.3f}), and the top scorer beat the bottom "
                       f"scorer by {tmb12:.1f} percentage points on average." + sample_note),
            "ic_12m": ic12}


LIMITATIONS = [
    "SURVIVORSHIP BIAS: every name here is one of today's winners, so every arm — including picking the "
    "WORST-scoring stock each month — is choosing between companies already known to have done "
    "well. Real selection means avoiding the ones that failed, and none are in this universe.",
    "About 47 monthly decisions exist in five years. The pick simulation rests on that handful, "
    "so one fortunate month can carry it. The rank correlation uses every stock in every month "
    "and is the more reliable of the two measures.",
    "Beyond one month the monthly observations overlap, so no significance test is reported for "
    "those horizons — a t-statistic computed on overlapping windows would be inflated.",
    "Concentrating a whole month's contribution into one stock is far riskier than spreading it, "
    "and nothing here measures that risk. A higher average return from the top-1 arm is not the "
    "same as a better outcome.",
    "No fees, spreads, slippage or tax, and nothing is ever sold.",
    "One market period, beginning near the 2022 low.",
]
