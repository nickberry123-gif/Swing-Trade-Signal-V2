"""
The 52-week / 200-day-average pattern, tested exactly as described.

THE RULE
--------
  1. New 52-week low            -> BUY
  2. Price reaches 5% BELOW the 200MA (rising into it)   -> SELL   (take the bounce)
  3. Price reaches 5% ABOVE the 200MA (break confirmed)  -> BUY
  4. Price reaches 5% BELOW the 52-week high             -> SELL   (out before resistance)

Every threshold is adjustable. The sequence is a state machine per ticker: a 52-week low arms
it, and it walks forward through the four steps. Two positions are never open at once.

WHY THIS IS TESTABLE AND "IF IT HOLDS" WAS NOT
----------------------------------------------
The idea was first described as "if the 200MA holds, price goes back to the high". You only know
it held afterwards, so coding that literally would peek at the future and produce a beautiful,
worthless result. Every trigger here is instead a price LEVEL that is either reached on a given
day or not — knowable at that day's close, acted on at the next day's open. The question "did it
hold?" is answered by the forward return, never by the entry rule.

THE THREE CAUSALITY GUARANTEES
------------------------------
1. `rolling(252).min()` at row i uses rows i-251..i only. Pandas rolling windows are
   backward-looking by construction, so the 52-week low on a given day is the low as it was
   known that day, not the low of the whole series.
2. A trigger detected on bar i is FILLED at bar i+1's open. You cannot trade a close you have
   just watched print.
3. The state machine only ever reads the current bar. It has no access to later rows.

WHAT THIS TEST WILL PROBABLY SAY, AND WHY THE COUNTS COME FIRST
---------------------------------------------------------------
All 15 of these companies fell in 2022 and have mostly risen since, so 52-week lows are likely
to be clustered in a single stretch of months. Fifteen trades all entered within one quarter of
each other are not fifteen independent observations — they are one observation about one market
event, wearing a sample size. The result therefore reports the event count and the clustering
BEFORE any return figure, because if the pattern only fires eleven times no return number on the
page means anything.
"""
import logging
from datetime import datetime, timezone

import pandas as pd

log = logging.getLogger(__name__)

LOOKBACK_52W = 252          # trading days in a year
MA_PERIOD = 200
MIN_WARMUP = 252            # need a full year before a "52-week low" means anything

DEFAULTS = {
    "cash_rate_pct": 0.0,           # what idle cash earns between trades, annualised

    "sell_pct_below_200ma": 5.0,     # step 2: sell when price rises to within this of the 200MA
    "buy_pct_above_200ma": 5.0,      # step 3: buy when price gets this far above the 200MA
    "sell_pct_below_52w_high": 5.0,  # step 4: sell when price gets this close to the 52-week high

    # Maximum TRADING days a leg may stay open before it is closed at the market.
    #
    # WHY THIS EXISTS. Without it, a leg that never reaches its trigger simply never closes, and
    # the ticker's state machine freezes: that stock stops producing trades for the rest of the
    # test. It was not that losses were hidden — the residual position is still valued at the
    # last bar — but a stock that stalls leaves the sample after one bad trade, so the sample
    # fills up with the stocks that kept completing the cycle. Leg 2 is the worst case, because
    # its exit level (near the 52-week high) sits ABOVE its entry level (just above the 200MA)
    # by construction: a leg-2 trade that closes on its trigger is almost bound to be a winner,
    # so the only way it can record a loss is by failing to close at all.
    #
    # A time limit is NOT a stop-loss. It never exits because the price moved against you; it
    # exits because the time allowed has run out, in either direction. The main backtest has
    # used exactly this mechanism from the start.
    "max_holding_days": 60,
}


def _levels(df: pd.DataFrame) -> pd.DataFrame:
    """200-day average and trailing 52-week high/low, all strictly backward-looking."""
    out = pd.DataFrame(index=df.index)
    out["close"] = df["close"].astype(float)
    out["open"] = df["open"].astype(float)
    out["sma200"] = out["close"].rolling(MA_PERIOD).mean()
    # min_periods equal to the window: a "52-week low" computed from 30 bars is not one.
    out["low_52w"] = df["low"].astype(float).rolling(LOOKBACK_52W, min_periods=LOOKBACK_52W).min()
    out["high_52w"] = df["high"].astype(float).rolling(LOOKBACK_52W, min_periods=LOOKBACK_52W).max()
    return out


def simulate_ticker(ticker: str, df: pd.DataFrame, config: dict | None = None) -> dict:
    """Walk the state machine over one ticker. Returns trades plus why it did what it did."""
    cfg = {**DEFAULTS, **(config or {})}
    lv = _levels(df.reset_index(drop=True))
    ts = df["ts"].reset_index(drop=True)

    sell_below = cfg["sell_pct_below_200ma"] / 100.0
    buy_above = cfg["buy_pct_above_200ma"] / 100.0
    sell_near_high = cfg["sell_pct_below_52w_high"] / 100.0
    max_hold = int(cfg.get("max_holding_days") or 0)

    def _close_trade(trade, fill_index, price, reason):
        """Settle a trade at `price`, filled on bar `fill_index`."""
        trade.update({
            "exit_date": str(ts.iloc[fill_index]), "exit_price": round(float(price), 4),
            "exit_reason": reason,
            "return_pct": round((float(price) - trade["entry_price"])
                                / trade["entry_price"] * 100, 4),
            "holding_days": fill_index - trade["entry_index"], "exit_index": fill_index,
            "timed_out": reason == "TIME_LIMIT",
        })
        return trade

    trades = []
    events = {"new_52w_low": 0, "leg1_entries": 0, "leg1_exits": 0,
              "leg2_entries": 0, "leg2_exits": 0,
              "leg1_timeouts": 0, "leg2_timeouts": 0}
    state = "FLAT"          # FLAT -> LONG_1 -> ARMED (waiting for the break) -> LONG_2 -> FLAT
    open_trade = None

    n = len(lv)
    for i in range(MIN_WARMUP, n - 1):      # -1: every fill needs a NEXT bar
        close = lv["close"].iloc[i]
        sma200 = lv["sma200"].iloc[i]
        low52 = lv["low_52w"].iloc[i]
        high52 = lv["high_52w"].iloc[i]
        if pd.isna(sma200) or pd.isna(low52) or pd.isna(high52):
            continue

        next_open = float(lv["open"].iloc[i + 1])
        date, next_date = str(ts.iloc[i]), str(ts.iloc[i + 1])

        # A new 52-week low means today's low IS the trailing 252-day low.
        at_new_low = float(df["low"].iloc[i]) <= low52 * 1.0000001
        # Counted here, ONCE, regardless of state. The first version incremented this only when
        # a low produced an entry, so a stock that kept making lower lows while already held
        # reported "1 new 52-week low" for a year of them — and the page labelled that number
        # "52-week lows hit". How often the setup OCCURS and how often it can be ACTED ON are
        # different questions, and the second one is not an honest answer to the first.
        if at_new_low:
            events["new_52w_low"] += 1

        if state == "FLAT":
            if at_new_low:
                events["leg1_entries"] += 1
                open_trade = {"ticker": ticker, "leg": 1, "signal_date": date,
                              "entry_date": next_date, "entry_price": round(next_open, 4),
                              "entry_reason": "NEW_52W_LOW", "entry_index": i + 1}
                state = "LONG_1"
            continue

        if state == "LONG_1":
            # Step 2: price has risen back to within `sell_below` of the 200MA.
            # The strategy's own trigger is checked FIRST: if both would fire on the same bar,
            # the rule's exit is what actually happened and the time limit never bound.
            if close >= sma200 * (1 - sell_below):
                events["leg1_exits"] += 1
                trades.append(_close_trade(
                    open_trade, i + 1, next_open,
                    f"REACHED_{cfg['sell_pct_below_200ma']}PCT_BELOW_200MA"))
                open_trade = None
                state = "ARMED"
            elif max_hold and (i + 1 - open_trade["entry_index"]) >= max_hold:
                # Out of time. The setup failed, so the sequence restarts from FLAT and waits
                # for a fresh 52-week low rather than progressing to the break leg.
                events["leg1_timeouts"] += 1
                trades.append(_close_trade(open_trade, i + 1, next_open, "TIME_LIMIT"))
                open_trade = None
                state = "FLAT"
            continue

        if state == "ARMED":
            # Step 3: the break. Price is now `buy_above` clear of the 200MA.
            if close >= sma200 * (1 + buy_above):
                events["leg2_entries"] += 1
                open_trade = {"ticker": ticker, "leg": 2, "signal_date": date,
                              "entry_date": next_date, "entry_price": round(next_open, 4),
                              "entry_reason": f"BROKE_{cfg['buy_pct_above_200ma']}PCT_ABOVE_200MA",
                              "entry_index": i + 1}
                state = "LONG_2"
            # If it makes a fresh 52-week low instead, the sequence has failed and restarts.
            elif at_new_low:
                events["leg1_entries"] += 1
                open_trade = {"ticker": ticker, "leg": 1, "signal_date": date,
                              "entry_date": next_date, "entry_price": round(next_open, 4),
                              "entry_reason": "NEW_52W_LOW", "entry_index": i + 1}
                state = "LONG_1"
            continue

        if state == "LONG_2":
            # Step 4: within `sell_near_high` of the 52-week high.
            if close >= high52 * (1 - sell_near_high):
                events["leg2_exits"] += 1
                trades.append(_close_trade(
                    open_trade, i + 1, next_open,
                    f"REACHED_{cfg['sell_pct_below_52w_high']}PCT_BELOW_52W_HIGH"))
                open_trade = None
                state = "FLAT"
            elif max_hold and (i + 1 - open_trade["entry_index"]) >= max_hold:
                # The break did not carry to the high in the time allowed. This is the case that
                # used to freeze the ticker for the remainder of the test.
                events["leg2_timeouts"] += 1
                trades.append(_close_trade(open_trade, i + 1, next_open, "TIME_LIMIT"))
                open_trade = None
                state = "FLAT"
            continue

    # A position with no trigger left is held to the end — there is no stop in this rule, so
    # this is a real outcome and is reported rather than quietly discarded. With a time limit in
    # force this can now only be a trade opened within `max_holding_days` of the final bar.
    if open_trade is not None:
        last_close = float(lv["close"].iloc[-1])
        trades.append(_close_trade(open_trade, n - 1, last_close, "STILL_OPEN_AT_END"))

    return {"trades": trades, "events": events, "bars": n}



def _summarise(trades: list) -> dict:
    rets = [t["return_pct"] for t in trades if t.get("return_pct") is not None]
    if not rets:
        return {"trades": 0, "mean_pct": None, "median_pct": None, "win_rate_pct": None,
                "best_pct": None, "worst_pct": None, "avg_holding_days": None}
    s = pd.Series(rets, dtype="float64")
    holds = [t["holding_days"] for t in trades if t.get("holding_days") is not None]
    return {
        "trades": len(rets),
        "mean_pct": round(float(s.mean()), 2),
        "median_pct": round(float(s.median()), 2),
        "win_rate_pct": round(float((s > 0).mean() * 100), 1),
        "best_pct": round(float(s.max()), 2),
        "worst_pct": round(float(s.min()), 2),
        "avg_holding_days": round(sum(holds) / len(holds), 1) if holds else None,
    }


def _clustering(trades: list) -> dict:
    """How concentrated in time the entries are.

    This is the number that decides whether the rest of the page means anything. Fifteen trades
    all opened in the same quarter are one observation about one market event, not fifteen
    independent tests of a rule — and a win rate computed across them describes that quarter.
    """
    dates = sorted(str(t["entry_date"])[:7] for t in trades if t.get("entry_date"))
    if not dates:
        return {"entries": 0, "distinct_months": 0, "busiest_month": None,
                "busiest_month_share_pct": None, "first": None, "last": None}
    counts = {}
    for m in dates:
        counts[m] = counts.get(m, 0) + 1
    busiest = max(counts, key=counts.get)
    return {
        "entries": len(dates),
        "distinct_months": len(counts),
        "busiest_month": busiest,
        "busiest_month_share_pct": round(counts[busiest] / len(dates) * 100, 1),
        "first": dates[0],
        "last": dates[-1],
    }






def run_pattern_test(bars_by_ticker: dict, tickers: list, config: dict | None = None) -> dict:
    cfg = {**DEFAULTS, **(config or {})}
    per_ticker, all_trades, skipped = {}, [], {}
    totals = {"new_52w_low": 0, "leg1_entries": 0, "leg1_exits": 0,
              "leg2_entries": 0, "leg2_exits": 0,
              "leg1_timeouts": 0, "leg2_timeouts": 0}

    for t in tickers:
        df = bars_by_ticker.get(t)
        if df is None or len(df) < MIN_WARMUP + 30:
            skipped[t] = f"needs more than {MIN_WARMUP + 30} daily bars, has {0 if df is None else len(df)}"
            continue
        d = df.reset_index(drop=True)
        out = simulate_ticker(t, d, cfg)
        per_ticker[t] = {
            "summary": _summarise(out["trades"]),
            "events": out["events"],
        }
        all_trades.extend(out["trades"])
        for k in totals:
            totals[k] += out["events"][k]

    leg1 = [t for t in all_trades if t["leg"] == 1]
    leg2 = [t for t in all_trades if t["leg"] == 2]
    tested = [t for t in tickers if t not in skipped]

    result = {
        "config": {**cfg, "rule": [
            "1. New 52-week low -> BUY (fill next open)",
            f"2. Price reaches {cfg['sell_pct_below_200ma']}% below the 200MA -> SELL",
            f"3. Price reaches {cfg['buy_pct_above_200ma']}% above the 200MA -> BUY",
            f"4. Price reaches {cfg['sell_pct_below_52w_high']}% below the 52-week high -> SELL",
            f"5. A leg still open after {cfg['max_holding_days']} trading days is closed at the "
            f"market. This is a TIME limit, not a stop-loss: it never exits because the price "
            f"moved against you.",
        ]},
        "events": totals,
        "clustering": _clustering(all_trades),
        "overall": _summarise(all_trades),
        "leg1": _summarise(leg1),
        "leg2": _summarise(leg2),
        "by_exit_reason": _by_exit_reason(all_trades),
        "by_ticker": per_ticker,
        "tickers_tested": tested,
        "tickers_skipped": skipped,
        "trades": sorted(all_trades, key=lambda t: str(t.get("entry_date"))),
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
    result["warnings"] = _warnings(result)
    result["limitations"] = LIMITATIONS
    return result


def _warnings(result: dict) -> list:
    """Said loudly, at the top, before any return figure gets read."""
    out = []
    c = result["clustering"]
    n = result["overall"]["trades"]

    if n == 0:
        return ["The pattern never triggered. Nothing on this page can tell you anything about it."]
    if n < 30:
        out.append(f"Only {n} trades. Below about 30 these numbers are noise — a single good or "
                   f"bad trade moves the average materially.")
    if c["distinct_months"] and c["distinct_months"] <= 6:
        out.append(f"Every entry falls in just {c['distinct_months']} different months "
                   f"({c['first']} to {c['last']}). These are not independent observations: they "
                   f"describe one or two market events, not a repeatable rule.")
    if c["busiest_month_share_pct"] and c["busiest_month_share_pct"] >= 40:
        out.append(f"{c['busiest_month_share_pct']}% of all entries happened in the single month "
                   f"of {c['busiest_month']}. The result is largely a statement about what "
                   f"happened next after that one month.")

    still_open = [t for t in result["trades"] if t.get("exit_reason") == "STILL_OPEN_AT_END"]
    if still_open:
        out.append(f"{len(still_open)} position(s) were still open when the data ran out and are "
                   f"valued at the last close. With a time limit in force these can only be "
                   f"trades opened near the end of the history.")

    timed = [t for t in result["trades"] if t.get("timed_out")]
    if timed:
        share = round(len(timed) / max(1, result["overall"]["trades"]) * 100, 1)
        out.append(f"{len(timed)} trade(s) — {share}% — were closed by the "
                   f"{result['config']['max_holding_days']}-day time limit rather than by the "
                   f"rule's own sell trigger. The rule did not complete its sequence in those "
                   f"cases, so a high share here means the pattern is describing the market less "
                   f"often than the trade count suggests.")

    # Repeated re-entry into the same falling stock. Once a time limit can close a losing leg-1
    # position, the next bar of a stock that is STILL falling is another new 52-week low, and
    # rule 1 says that is a buy. The rule will therefore buy the same falling knife over and
    # over. That is what the rule says to do; it is not what most people picture when they read
    # "buy the 52-week low", so it is stated plainly rather than left in the trade list.
    by_ticker_entries = {}
    for t in result["trades"]:
        if t.get("leg") == 1:
            by_ticker_entries[t["ticker"]] = by_ticker_entries.get(t["ticker"], 0) + 1
    repeat = {k: v for k, v in by_ticker_entries.items() if v >= 3}
    if repeat:
        worst = max(repeat, key=repeat.get)
        out.append(f"{len(repeat)} stock(s) were re-entered three or more times on leg 1 — "
                   f"{worst} was bought {repeat[worst]} times. When a stock keeps falling, every "
                   f"new low is another buy signal, so the rule re-buys it each time the clock "
                   f"closes the previous position. Check those trades before trusting any "
                   f"average on this page.")

    # Leg 2's exit level sits above its entry level by construction, so a leg-2 trade that closes
    # on its own trigger is close to guaranteed profitable. If leg 2 still shows a near-perfect
    # win rate AFTER timed-out trades are counted, that is worth saying out loud rather than
    # letting it read as skill.
    leg2 = result.get("leg2") or {}
    if leg2.get("trades") and (leg2.get("win_rate_pct") or 0) >= 95:
        out.append(f"Leg 2 wins {leg2['win_rate_pct']}% of the time. Treat that with suspicion: "
                   f"leg 2 sells near the 52-week high and buys just above the 200MA, so its exit "
                   f"is above its entry by construction. A win rate this high usually measures "
                   f"the shape of the rule, not the quality of the idea.")
    return out


def _by_exit_reason(trades: list) -> dict:
    """How each trade actually ended, and what it was worth.

    The single most important table on the page once a time limit exists: it separates the trades
    where the rule genuinely worked from the ones where the clock simply ran out.
    """
    buckets = {}
    for t in trades:
        reason = t.get("exit_reason") or "UNKNOWN"
        # Collapse the parameterised trigger names so the buckets stay readable when thresholds
        # are edited on the page.
        if "BELOW_200MA" in reason:
            key = "Reached the 200MA (leg 1 target)"
        elif "BELOW_52W_HIGH" in reason:
            key = "Reached the 52-week high (leg 2 target)"
        elif reason == "TIME_LIMIT":
            key = "Time limit"
        elif reason == "STILL_OPEN_AT_END":
            key = "Still open when data ended"
        else:
            key = reason
        buckets.setdefault(key, []).append(t)
    return {k: _summarise(v) for k, v in sorted(buckets.items())}


LIMITATIONS = [
    "SURVIVORSHIP BIAS: every company here recovered. A rule that buys 52-week lows is "
    "flattered enormously by a universe containing no company that kept falling — and the "
    "expanded list makes this WORSE, not better: it includes several of the largest "
    "recoveries of the last three years and none of the failures alongside them.",
    "52-week lows in this universe cluster around one market episode. Clustered trades are not "
    "independent evidence, however many rows they produce.",
    "There is NO STOP-LOSS. A position is never closed because the price moved against it. The "
    "time limit closes trades that run out of clock, in whichever direction they happen to be.",
    "The time limit is itself a rule you have chosen, and it can be tuned. Trying several values "
    "and keeping whichever reads best is how a backtest gets fitted to the past — the count of "
    "values you have tried belongs alongside whichever one you settle on.",
    "Fills use the next bar's open with no slippage, spread, commission or tax.",
    "Intrabar path is unknown: a trigger is judged on the day's close, so a level touched and "
    "reversed within a day may be missed, and a gap through a level fills at the gapped price.",
    "One market period. A rule built around 'it bounces back' has never been tested here on a "
    "decade where it did not.",
]
