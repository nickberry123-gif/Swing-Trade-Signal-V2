"""
VALUE — "Am I paying a reasonable price?"

The second of the three independent pillars. It answers its own question and borrows nothing from
Company Health or Entry: an expensive excellent company is expensive, and nothing here is adjusted
for quality.

WHAT THIS MEASURES, STATED EXACTLY. Three multiples, each expressed as a percentile of THAT
COMPANY'S OWN history since 27 July 2020 — the earliest date Alpaca serves bars for this account,
established by bisection in run 10 rather than assumed. The wording everywhere is "relative to
available valuation history since July 2020". It is not the cheapest a company has ever been, it is
not a full-cycle valuation, and no data exists before that date.

THE LIMITATION THAT MATTERS, RECORDED RATHER THAN ENGINEERED AROUND. The window begins four months
after the March 2020 low, so it contains the 2020-21 boom, the 2022 drawdown and the recovery but no
genuine panic. The bias is directional and predictable: the cheapest a company appears ON THIS DATA
is not the cheapest it has ever been, so this model will call ordinary prices cheap more readily
than it should. Shortening the window further would make that worse, not better.

WHY RAW PRICES. A multiple pairs a price with an as-reported per-share figure, and the two must be
on the same share basis:

    RAW price      + as-reported fundamentals  -> a valid historical valuation   (this module)
    ADJUSTED price + adjusted price            -> a valid return                 (the backtester)

Run 10 proved the raw series is genuinely unadjusted across five splits from 4:1 to 50:1, across
NVIDIA's two splits three years apart, and against a single dated dividend.

THE HAZARD RAW PRICES CREATE, AND THE ONE THIS MODULE EXISTS TO PREVENT. A filing states EPS and a
share count on the basis in force when it was filed. If a split happens AFTER that filing, the raw
price falls by the split factor while the filed figures do not. Every one of these three multiples
would collapse by that factor. NVIDIA in June 2024 would have read as ten times cheaper overnight —
a maximum-strength CHEAP signal produced entirely by an artefact, on exactly the kind of company
this app is built around.

The cover-page share-count detector cannot help: it only fires at the NEXT filing, which is
precisely the exposed window. So the detector here reads the ratio of the raw series to the adjusted
series, which changes ONLY at corporate actions and separates the two kinds by three orders of
magnitude — splits step 4x to 50x, dividends 0.24%. When a step is seen after the latest filing the
metrics are WITHHELD, not restated. Restating by arithmetic would preserve coverage and is exactly
the class of change this project has repeatedly been burned by; one quarter of UNKNOWN is much
cheaper than a wrong multiple that looks right.
"""
from datetime import date, datetime, timedelta, timezone

from services import operating_profit

# The earliest date Alpaca serves bars for this account. MEASURED, not assumed: 2016-06, 2017-06,
# 2018-06 and 2019-06 all returned empty; two 30-day windows covering 5 June - 18 September 2020
# both begin here and neither returns anything earlier.
#
# Whether this floor is FIXED or ROLLS FORWARD cannot be established from one measurement — both
# hypotheses look identical from a single point in time, and they diverge only on re-measurement.
# `observed_floor()` reports what the stored data actually starts at, so a rolling window shows up
# as a recorded change rather than as a percentile that drifts while appearing stable.
DATA_FLOOR_OBSERVED = "2020-07-27"

MIN_HISTORY_YEARS = 3.0          # below this a percentile is not a range, it is an anecdote
MIN_METRICS_FOR_VALUE = 2        # one metric is an opinion, not a valuation
MIN_OBSERVATIONS = 250           # roughly one trading year of days, as a floor under the above

# A split steps this ratio by its factor (4x-50x observed); a dividend steps it by well under 1%.
# 1.5 sits three orders of magnitude clear of the largest dividend step measured.
SPLIT_STEP_RATIO = 1.5

# Frozen at approval. If results are poor the response is to report them, not to move 75 to 70.
BANDS = ((75.0, "CHEAP"), (25.0, "FAIR"), (0.0, "EXPENSIVE"))

UNKNOWN = "UNKNOWN"
OK = "OK"
UNAVAILABLE = "UNAVAILABLE"

# Equal weights. Not a guess at the right answer — the honest position before any validation
# exists. Study 2 found C1's six weighted categories, gates and capping rules added close to
# nothing over an equally weighted average of five fundamentals, and the simple benchmark beat the
# full model at all four dates. Inventing weights here would be optimising before the calculation
# is trusted.
METRICS = ("fcf_yield_pct", "ev_to_ebit", "pe_ratio")

# True where a HIGHER number means CHEAPER.
HIGHER_IS_CHEAPER = {"fcf_yield_pct": True, "ev_to_ebit": False, "ev_to_sales": False,
                     "pe_ratio": False}

EV_SALES = "ev_to_sales"

METRIC_LABELS = {"fcf_yield_pct": "FCF yield", "ev_to_ebit": "EV/EBIT",
                 "ev_to_sales": "EV/Sales (substitute)", "pe_ratio": "P/E"}

BASIS_NOTE = "Relative to available valuation history since July 2020."


def _v(x):
    """A number, or None. Booleans are not numbers."""
    if x is None or isinstance(x, bool):
        return None
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    return None if f != f or f in (float("inf"), float("-inf")) else f


def _years_between(first: str, last: str) -> float:
    try:
        a, b = date.fromisoformat(first[:10]), date.fromisoformat(last[:10])
    except (ValueError, TypeError):
        return 0.0
    return (b - a).days / 365.25


# --------------------------------------------------------------------------------------------
# Point-in-time filing selection
# --------------------------------------------------------------------------------------------
def pick_filing(filings: list, day: str):
    """The newest filing PUBLISHED on or before `day`.

    Keyed on `filed`, never on `period_end`: the relevant date is when a figure became public, not
    the period it describes. A filing published after `day` cannot be reached from here, which is
    the whole point — this is the same discipline the fundamentals history layer applies, restated
    at the one place a valuation series could otherwise leak the future.
    """
    if not filings or not day:
        return None
    day = day[:10]
    eligible = [f for f in filings if (f.get("filed") or "")[:10] <= day]
    if not eligible:
        return None
    # Newest publication wins; where two were published the same day, the later fiscal period is
    # the more current statement of the business.
    return max(eligible, key=lambda f: ((f.get("filed") or "")[:10],
                                        (f.get("period_end") or "")[:10]))


# --------------------------------------------------------------------------------------------
# Corporate-action detection from the raw/adjusted ratio
# --------------------------------------------------------------------------------------------
def split_steps(bars: list, threshold: float = SPLIT_STEP_RATIO) -> list:
    """Every date where raw/adjusted steps by `threshold` or more — i.e. every split.

    `bars` is ascending, each row carrying `ts`, `close_raw` and `close_adj`. The ratio of the two
    series changes only at corporate actions. A dividend moves it by a fraction of a percent; a
    split moves it by the split factor. Returns [{date, factor}] for the split-sized steps only.
    """
    out, prev_ratio, prev_ts = [], None, None
    for b in bars:
        raw, adj = _v(b.get("close_raw")), _v(b.get("close_adj"))
        if not raw or not adj or adj <= 0:
            continue
        ratio = raw / adj
        if prev_ratio and prev_ratio > 0:
            step = max(ratio / prev_ratio, prev_ratio / ratio)
            if step >= threshold:
                out.append({"date": b.get("ts", "")[:10], "factor": round(step, 4),
                            "previous_date": prev_ts})
        prev_ratio, prev_ts = ratio, b.get("ts", "")[:10]
    return out


def split_after(bars: list, since: str, threshold: float = SPLIT_STEP_RATIO):
    """The first split strictly after `since`, or None. `since` is normally a filing's `filed`."""
    if not since:
        return None
    for s in split_steps(bars, threshold):
        if s["date"] > since[:10]:
            return s
    return None


# --------------------------------------------------------------------------------------------
# The multiples themselves
# --------------------------------------------------------------------------------------------
def metrics_for(price_raw, filing: dict) -> dict:
    """The three multiples for one raw price and one filing, plus the EV/Sales substitute.

    Every figure comes from the same filing, so the share basis is internally consistent by
    construction. Returns {metric: value or None}; None always means "cannot be computed", never
    zero and never a pass.
    """
    price = _v(price_raw)
    out = {m: None for m in METRICS}
    out[EV_SALES] = None
    if not price or price <= 0 or not filing:
        return out
    if (filing.get("currency") or "USD").upper() != "USD":
        return out  # a USD price against non-USD fundamentals is not a ratio, it is a mistake

    # ---- the per-share route. Needs no share count, so it survives an UNKNOWN share basis. ----
    eps = _v(filing.get("eps_diluted"))
    if eps and eps > 0:
        out["pe_ratio"] = price / eps

    # ---- the market-cap route. The cover-page count is point-in-time AT THAT FILING, which is
    # the basis the price must also be on; a split between the two is caught by the caller. ----
    shares = _v(filing.get("shares_outstanding"))
    if not shares or shares <= 0:
        return out
    market_cap = price * shares
    debt, cash = _v(filing.get("total_debt")) or 0.0, _v(filing.get("total_cash")) or 0.0
    ev = market_cap + debt - cash

    ocf, capex = _v(filing.get("operating_cash_flow")), _v(filing.get("capex"))
    if ocf is not None and capex is not None and market_cap > 0:
        out["fcf_yield_pct"] = (ocf - capex) / market_cap * 100.0

    if ev > 0:
        revenue = _v(filing.get("revenue"))
        if revenue and revenue > 0:
            out[EV_SALES] = ev / revenue
        op = operating_profit.reconcile(filing).get("value")
        op = _v(op)
        if op and op > 0:
            out["ev_to_ebit"] = ev / op
    return out


def build_series(bars: list, filings: list) -> list:
    """One row per trading day: the raw close, the filing in force, and the multiples.

    Days on which no filing had yet been published are still emitted, with every multiple None, so
    that the length of the series is the length of the price history rather than something quietly
    shortened.
    """
    series = []
    for b in bars:
        day = (b.get("ts") or "")[:10]
        if not day:
            continue
        filing = pick_filing(filings, day)
        row = {"date": day, "close_raw": _v(b.get("close_raw")),
               "filed": (filing or {}).get("filed"), "period_end": (filing or {}).get("period_end")}
        row.update(metrics_for(b.get("close_raw"), filing or {}))
        series.append(row)
    return series


# --------------------------------------------------------------------------------------------
# Percentiles
# --------------------------------------------------------------------------------------------
def percentile_rank(history: list, current, higher_is_cheaper: bool):
    """Where `current` sits in `history`, oriented so 100 = cheapest.

    `history` must contain only observations STRICTLY BEFORE the date being scored — an expanding
    window. This is the one place a backtest of this model could leak the future: using the whole
    six-year distribution to score a 2021 date would let the 2021 peak inform its own percentile
    and would make the result look excellent for a purely mechanical reason.

    Ties take mid-rank, so a value equal to every past observation reads 50 rather than 0 or 100.
    """
    cur = _v(current)
    vals = [v for v in (_v(h) for h in history) if v is not None]
    if cur is None or not vals:
        return None
    if higher_is_cheaper:
        more_expensive = sum(1 for v in vals if v < cur)
    else:
        more_expensive = sum(1 for v in vals if v > cur)
    ties = sum(1 for v in vals if v == cur)
    return round((more_expensive + 0.5 * ties) / len(vals) * 100.0, 1)


def verdict_for(value):
    if value is None:
        return UNKNOWN
    for threshold, label in BANDS:
        if value >= threshold:
            return label
    return "EXPENSIVE"


# --------------------------------------------------------------------------------------------
# The pillar
# --------------------------------------------------------------------------------------------
def evaluate(ticker: str, bars: list, filings: list, as_of: str | None = None) -> dict:
    """Value for one company. Pure — no database, no network, no clock beyond `as_of`.

    `bars` ascending, each with `ts`, `close_raw`, `close_adj`. `filings` are stored
    fundamentals_history rows. `as_of` scores a past date; None means today.
    """
    ticker = (ticker or "").upper()
    cutoff = (as_of or datetime.now(timezone.utc).date().isoformat())[:10]

    bars = [b for b in (bars or []) if (b.get("ts") or "")[:10] <= cutoff]
    filings = [f for f in (filings or []) if (f.get("filed") or "")[:10] <= cutoff]

    out = {
        "ticker": ticker, "as_of": cutoff, "basis": BASIS_NOTE,
        "data_floor_observed": DATA_FLOOR_OBSERVED,
        "value": None, "verdict": UNKNOWN, "metrics": {}, "notes": [], "spread": None,
        "split_withheld": None, "substitution": None,
        "history": {"first_date": None, "last_date": None, "observations": 0, "years": 0.0},
        "coverage": {"available": 0, "required": MIN_METRICS_FOR_VALUE, "of": len(METRICS)},
    }

    def unavailable(name, reason):
        out["metrics"][name] = {"label": METRIC_LABELS.get(name, name), "status": UNAVAILABLE,
                                "value": None, "percentile": None, "reason": reason}

    if not bars:
        for m in METRICS:
            unavailable(m, "no raw price history stored for this company")
        out["notes"].append("No stored raw bars. Value cannot be computed.")
        return out

    series = build_series(bars, filings)
    first, last = series[0]["date"], series[-1]["date"]
    span = _years_between(first, last)
    out["history"] = {"first_date": first, "last_date": last, "observations": len(series),
                      "years": round(span, 2)}
    if first > DATA_FLOOR_OBSERVED:
        out["notes"].append(
            f"Stored history begins {first}, later than the observed data floor "
            f"{DATA_FLOOR_OBSERVED}.")

    latest_filing = pick_filing(filings, cutoff)
    if not latest_filing:
        for m in METRICS:
            unavailable(m, "no filing had been published by this date")
        out["notes"].append("No point-in-time filing available.")
        return out

    currency = (latest_filing.get("currency") or "USD").upper()
    if currency != "USD":
        for m in METRICS:
            unavailable(m, f"fundamentals are reported in {currency}, not USD")
        out["notes"].append(
            f"Fundamentals are in {currency}. A USD price divided by a {currency} figure is not a "
            f"valuation, so every multiple is withheld.")
        return out

    # ---- the post-filing split check, before anything is scored ----
    split = split_after(bars, latest_filing.get("filed"))
    if split:
        out["split_withheld"] = split
        for m in METRICS:
            unavailable(m, f"a {split['factor']}x split-sized corporate action was detected on "
                           f"{split['date']}, after the latest filing was published on "
                           f"{(latest_filing.get('filed') or '')[:10]}. The raw price is on the new "
                           f"basis and the filed figures are not.")
        out["notes"].append(
            f"POST-FILING SPLIT WITHHELD — {split['factor']}x on {split['date']}, after the filing "
            f"of {(latest_filing.get('filed') or '')[:10]}. Every multiple is withheld until a "
            f"filing restates the per-share basis. Nothing has been mathematically adjusted.")
        return out

    if span < MIN_HISTORY_YEARS or len(series) < MIN_OBSERVATIONS:
        for m in METRICS:
            unavailable(m, f"only {span:.1f} years of price history stored; "
                           f"{MIN_HISTORY_YEARS:.0f} are required for a percentile")
        out["notes"].append(
            f"Only {span:.1f} years of history. A percentile over less than "
            f"{MIN_HISTORY_YEARS:.0f} years is not a range.")
        return out

    # ---- EV/Sales substitution, declared in advance and always visible ----
    today_row = series[-1]
    ebit_name = "ev_to_ebit"
    if today_row.get("ev_to_ebit") is None and today_row.get(EV_SALES) is not None:
        ebit_name = EV_SALES
        op = operating_profit.reconcile(latest_filing)
        why = ("operating profit could not be reconciled" if op.get("value") is None
               else "operating profit is not positive")
        out["substitution"] = {"replaced": "ev_to_ebit", "with": EV_SALES, "reason": why}
        out["notes"].append(
            f"EV/SALES SUBSTITUTED FOR EV/EBIT — {why}. This is the approved substitution and it "
            f"is applied to the whole history, not only to today.")

    scored = [("fcf_yield_pct", "fcf_yield_pct"), (ebit_name, ebit_name), ("pe_ratio", "pe_ratio")]

    percentiles = []
    for name, key in scored:
        current = today_row.get(key)
        # EXPANDING WINDOW: strictly earlier observations only.
        past = [r[key] for r in series[:-1] if r.get(key) is not None]
        dated = [r["date"] for r in series[:-1] if r.get(key) is not None]
        if current is None:
            unavailable(name, _why_missing(name, latest_filing))
            continue
        if not past:
            unavailable(name, "no earlier observation of this multiple exists")
            continue
        metric_span = _years_between(dated[0], dated[-1])
        if metric_span < MIN_HISTORY_YEARS:
            unavailable(name, f"only {metric_span:.1f} years of this multiple stored; "
                              f"{MIN_HISTORY_YEARS:.0f} are required")
            continue
        pct = percentile_rank(past, current, HIGHER_IS_CHEAPER[name])
        out["metrics"][name] = {
            "label": METRIC_LABELS.get(name, name), "status": OK,
            "value": round(current, 4), "percentile": pct,
            "observations": len(past), "years": round(metric_span, 2),
            "substituted": name == EV_SALES,
        }
        if pct is not None:
            percentiles.append(pct)

    out["coverage"]["available"] = len(percentiles)

    # COMPONENT SPREAD — DESCRIPTIVE ONLY. It is deliberately computed AFTER the score and feeds
    # nothing: not the mean, not the bands, not the verdict, not any gate. Recorded because the
    # 50-stock run showed the headline number can conceal economically meaningful disagreement —
    # MSFT sat at the 3.5th percentile on free-cash-flow yield and the 90.7th on P/E and reported
    # "FAIR 60.4", which is arithmetically right and tells a reader nothing true about the
    # company. Ten of 41 scored companies differed by more than 25 percentile points.
    #
    # Preserving it is not the same as acting on it. Turning spread into a gate, a weight or an
    # UNKNOWN would be changing a pre-registered model after seeing its output, which is the
    # failure mode this project exists to avoid.
    out["spread"] = (round(max(percentiles) - min(percentiles), 1)
                     if len(percentiles) >= 2 else None)

    if len(percentiles) < MIN_METRICS_FOR_VALUE:
        out["notes"].append(
            f"Only {len(percentiles)} of {len(METRICS)} metrics available. "
            f"{MIN_METRICS_FOR_VALUE} are required — one metric is an opinion, not a valuation.")
        return out

    out["value"] = round(sum(percentiles) / len(percentiles), 1)
    out["verdict"] = verdict_for(out["value"])
    return out


def _why_missing(name, filing: dict) -> str:
    if name == "pe_ratio":
        eps = _v(filing.get("eps_diluted"))
        if eps is None:
            return "no diluted EPS in the latest filing"
        return "diluted EPS is zero or negative, so a P/E would not be meaningful"
    shares = _v(filing.get("shares_outstanding"))
    if not shares or shares <= 0:
        return ("no cover-page share count in the latest filing, so no market capitalisation and "
                "therefore no EV- or market-cap-based multiple")
    if name == "fcf_yield_pct":
        return "free cash flow needs operating cash flow and capital expenditure"
    if name == EV_SALES:
        return "no revenue reported"
    return "operating profit could not be reconciled, or is not positive"


def observed_floor(bars: list):
    """The earliest date actually stored. Recorded so a rolling data window becomes visible."""
    dates = sorted((b.get("ts") or "")[:10] for b in (bars or []) if b.get("ts"))
    return dates[0] if dates else None
