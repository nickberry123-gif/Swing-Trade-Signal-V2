"""
C1 — Company Health. One question, answered from audited annual filings and nothing else:

    Is this fundamentally a strong, durable company that remains suitable for long-term ownership?

Not whether the shares are cheap. Not whether now is a good moment to buy. Not how much to hold.
Company Health touches no price, no market capitalisation and no valuation input anywhere in this
module — which is what makes it usable as the thing you fall back on when a trade goes against you
and you find yourself holding the stock.

THE SPECIFICATION IN THIS FILE IS LOCKED.
=========================================
Every weight, anchor, gate and band below was approved BEFORE any company had been scored, and no
figure here has ever been checked against what it produces for the fifty. That ordering is the
whole point. Thresholds fitted to a known set of results measure the set, not the companies — and
this project has already had one rule (the basic-versus-diluted dilution gap) that was validated
against one filing and failed in production against the next.

So: if a result looks economically wrong, the response is to report the company, the score, the
category and the underlying inputs — never to move a number until the answer reads better. A
model that is quietly adjusted until it agrees with intuition has stopped being a measurement.

WHAT IS DELIBERATELY NOT MEASURED
=================================
Market share, switching costs, customer concentration, management quality, product cycles. None
has a source in this app's data. Competitive Strength Evidence is named EVIDENCE because it infers
strength from a financial footprint; it does not measure a moat and does not claim to.

CROSS-INDUSTRY COMPARABILITY, AND WHY MARGINS ARE SCORED AS FLOORS
==================================================================
This universe runs from a wholesaler at roughly 12% gross margin to software houses at 75-90%. An
absolute margin ladder would not measure durability — it would classify industries, and it would
mark a company owned precisely BECAUSE it is a durable low-margin operator as weak.

So the metrics scored as quality ladders are the ones where a dollar is a dollar in any industry:
returns on capital, cash conversion, leverage. Margin LEVELS are scored as floor tests — is this a
solidly profitable business — rather than as rankings. Margin QUALITY is picked up separately by
the stability measures in Competitive Strength Evidence.

Peer-relative scoring was rejected for a harder reason than taste: a company's score would move
because a DIFFERENT company moved, which makes any historical score impossible to reproduce and
quietly breaks the point-in-time guarantee the rest of this app is built on.
"""
from __future__ import annotations

# ---- scoring shape ---------------------------------------------------------------------------
# Three anchors per metric, straight lines between them. Bands were rejected because a cliff at a
# round number is false precision: 14.9% and 15.1% describe the same company.
HIGHER = "higher"          # a larger value is better
LOWER = "lower"            # a smaller value is better — leverage, accruals, dilution

WEAK_SCORE = 0.0
ADEQUATE_SCORE = 60.0
STRONG_SCORE = 100.0

# ---- gates and bands -------------------------------------------------------------------------
#: Below this much of the model measurable, no score is produced at all. A company with too little
#: data is NOT a weak company, and reporting it as one would be the most damaging error this
#: module could make. It reports INSUFFICIENT DATA and says what was missing.
COVERAGE_GATE_PCT = 75.0

#: A category at or below this is a FUNDAMENTAL RED FLAG: reported, named, and always visible.
RED_FLAG_CATEGORY_SCORE = 25.0

#: ...but only when enough of the category was actually measurable. A category scored on one
#: metric out of four is far too thin a basis on which to call a company fundamentally flawed,
#: and without this guard a red flag becomes an artefact of missing data rather than a finding.
RED_FLAG_MIN_CATEGORY_COVERAGE_PCT = 50.0

VERDICT_BANDS = ((80.0, "STRONG"), (65.0, "SOLID"), (50.0, "ADEQUATE"), (0.0, "WEAK"))
INSUFFICIENT = "INSUFFICIENT DATA"
WEAK = "WEAK"

#: The one category whose failure caps the verdict on its own, and the reason is not statistical.
#: Five of the six categories describe how WELL a business performs; the balance sheet describes
#: whether it SURVIVES. Weak growth makes a company a poor investment; an inability to service
#: debt can stop it being an investment at all. The premise of this whole strategy is that a trade
#: going wrong leaves you holding the company for years — and solvency is the single weakness that
#: cannot be waited out, because the waiting is what kills you. Every other failure is survivable
#: by a shareholder with patience.
SOLVENCY_CATEGORY = "balance_sheet"

#: Two independent categories failing at once is a pattern rather than a phase. One weak area can
#: be deliberate strategy or a cyclical trough — heavy reinvestment suppressing margins, one bad
#: year in a good decade. No new threshold is introduced here: it is the same 25, twice.
CAP_AT_N_RED_FLAGS = 2

# ---- the model -------------------------------------------------------------------------------
# (metric, direction, WEAK anchor, ADEQUATE anchor, STRONG anchor)
#
# Every anchor carries its reasoning in the comments. Where a number looks arbitrary it is not —
# and where it IS a judgement, the comment says so rather than dressing it up.
COMPANY_HEALTH_MODEL = {
    # Returns on capital are the backbone: a dollar of capital is comparable across industries in
    # a way that a margin is not.
    "profitability_returns": (25, [
        # 8% is roughly the cost of capital for a large-cap. Below it, growth destroys value
        # rather than creating it. Sustained 25%+ is difficult without a real advantage.
        ("roic_pct", HIGHER, 8.0, 15.0, 25.0),
        # Anchored higher than ROIC throughout, because leverage flatters return on equity.
        ("roe_pct", HIGHER, 8.0, 18.0, 30.0),
        # Anchored low on purpose: asset-heavy businesses can be excellent businesses.
        ("roa_pct", HIGHER, 2.0, 7.0, 14.0),
        # FLOOR TESTS, not ladders. These ask "is there a real gross profit here", not "is this a
        # software company". See the module note on comparability.
        ("gross_margin_pct", HIGHER, 5.0, 15.0, 30.0),
        ("operating_margin_pct", HIGHER, 3.0, 12.0, 25.0),
        ("net_margin_pct", HIGHER, 2.0, 10.0, 20.0),
    ]),
    "growth_durability": (20, [
        # 2% is approximately nominal GDP: below it the business is shrinking in real terms.
        ("revenue_cagr_pct", HIGHER, 2.0, 8.0, 15.0),
        # Above the revenue anchors, because buybacks and margin expansion should contribute.
        # Built from the within-filing chain, so no share split can ever enter it.
        ("eps_cagr_pct", HIGHER, 3.0, 10.0, 20.0),
        # Already 0-100: the percentage of years revenue rose. With six periods the only
        # attainable values are 0, 20, 40, 60, 80 and 100.
        ("revenue_consistency", HIGHER, 50.0, 75.0, 100.0),
    ]),
    "cashflow_quality": (15, [
        ("fcf_margin_pct", HIGHER, 3.0, 10.0, 20.0),
        # Profit that does not turn into cash is the classic early warning.
        ("fcf_to_net_income", HIGHER, 0.6, 0.9, 1.1),
        # Higher anchors than free cash flow, because operating cash flow is before capex.
        ("ocf_to_net_income", HIGHER, 0.9, 1.2, 1.5),
        # INVERTED. High accruals — profit running ahead of the cash — is the best-documented
        # predictor of disappointing future results in the accounting literature.
        ("accruals_ratio", LOWER, 0.15, 0.05, -0.05),
    ]),
    "balance_sheet": (15, [
        # INVERTED. 3-3.5x is the conventional covenant zone; 0.0 is net cash.
        ("net_debt_to_ebitda", LOWER, 3.5, 1.5, 0.0),
        ("interest_coverage", HIGHER, 3.0, 8.0, 20.0),
        # A DISTRESS FLOOR, not a ladder. Excellent companies run near 1.0 deliberately, and
        # hoarding working capital is not a virtue — so no extra credit above 1.5.
        ("current_ratio", HIGHER, 0.8, 1.1, 1.5),
    ]),
    "moat_evidence": (15, [
        ("roic_persistence", HIGHER, 40.0, 65.0, 85.0),
        # Gross margin is the most stable line for a company with genuine pricing power, so the
        # bar is set high; operating margin legitimately swings more, so its bar is lower.
        ("gross_margin_stability", HIGHER, 60.0, 80.0, 93.0),
        ("operating_margin_stability", HIGHER, 50.0, 72.0, 88.0),
        # The WORST year-on-year change in the history, so it is legitimately negative. Growing
        # even in the bad year is the strong case.
        ("revenue_resilience", HIGHER, -15.0, -2.0, 5.0),
        # R&D INTENSITY IS DELIBERATELY ABSENT. Scoring it rewards pharmaceuticals and software
        # and penalises distribution and services for no durability reason whatsoever. It is
        # still reported; it simply does not score.
    ]),
    # NOTHING IN THIS CATEGORY TOUCHES A SHARE PRICE, AND THAT IS A CHANGE.
    # It used to score buyback yield and dividend yield, both of which divide by market
    # capitalisation. That made Company Health depend on the valuation machinery — and it bit:
    # when one company's market capitalisation became UNKNOWN, it lost two of its three
    # capital-allocation inputs for a reason that had nothing to do with capital allocation.
    # A yield is also a valuation statement. For long-term ownership the durable question is
    # whether distributions are funded by the cash the business generates.
    "capital_allocation": (10, [
        # INVERTED, annualised. Dilution is a real cost to a long-term holder; steady buybacks are
        # the opposite. Computed within a single filing, so no split can distort it.
        ("share_change_pct", LOWER, 3.0, 0.0, -2.0),
        # INVERTED. (buybacks + dividends) / free cash flow. At or below 0.8 the distribution is
        # covered by the cash coming in; above 1.0 it is being funded by debt or the balance
        # sheet. A company that distributes NOTHING is NOT APPLICABLE here rather than excellent —
        # see distribution_sustainability() for why that matters.
        ("distribution_sustainability", LOWER, 1.3, 1.0, 0.8),
    ]),
}

#: Backwards-compatible view for the coverage report: {category: (weight, [metric names])}.
#: Derived from the model rather than maintained alongside it, because two lists drift and the
#: failure mode of drift is a metric that is scored but not counted, or counted but not scored.
COMPANY_HEALTH_CATEGORIES = {
    name: (weight, [m[0] for m in metrics])
    for name, (weight, metrics) in COMPANY_HEALTH_MODEL.items()
}


def score_metric(value, direction, weak, adequate, strong):
    """One metric's 0-100 score, or None when there is nothing to score.

    Piecewise linear through (weak, 0), (adequate, 60), (strong, 100), clamped outside. An
    inverted metric is handled by negating the axis rather than by a second code path, so there is
    only one place for an off-by-one to live.
    """
    if value is None:
        return None
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None

    if direction == LOWER:
        value, weak, adequate, strong = -value, -weak, -adequate, -strong

    if value <= weak:
        return WEAK_SCORE
    if value >= strong:
        return STRONG_SCORE
    if value <= adequate:
        span = adequate - weak
        if span <= 0:
            return ADEQUATE_SCORE
        return (value - weak) / span * ADEQUATE_SCORE
    span = strong - adequate
    if span <= 0:
        return STRONG_SCORE
    return ADEQUATE_SCORE + (value - adequate) / span * (STRONG_SCORE - ADEQUATE_SCORE)


def distribution_sustainability(period, fcf):
    """(buybacks + dividends) / free cash flow — or NOT APPLICABLE, or UNKNOWN.

    ZERO DISTRIBUTION IS NOT APPLICABLE, NOT EXCELLENT, and that distinction is the whole reason
    this function exists rather than a division. Returning nothing to shareholders is not evidence
    of good capital allocation: the company may be reinvesting productively, holding cash
    sensibly, or wasting it, and this measurement cannot tell those three apart. Scoring it as
    STRONG would hand a full mark to every one of them indiscriminately.

    It is equally not evidence of BAD allocation, so it is not penalised either. The metric simply
    has nothing to say about a non-payer, so it says nothing and its weight leaves the denominator
    — the same treatment as interest coverage at a company with no debt.

    WHY RETURN ON CAPITAL IS NOT USED HERE TO ESTABLISH "PRODUCTIVE REINVESTMENT". It is tempting:
    a company retaining all its cash while earning a high ROIC is, by definition, reinvesting
    well, and ROIC is measured reliably. But ROIC is already scored in Profitability & Returns,
    and reusing it here would put one measurement behind 35% of Company Health across two
    categories. That is exactly the defect corrected earlier in this project, when revenue
    consistency sat in both Growth and Moat and quietly drove 35% of the score. It is not being
    rebuilt, and no new reinvestment-quality metric is invented to fill the gap, because no
    reliable source for one exists in the data this app reads.

    Returns (value, status, note) where status is "OK", "NOT_APPLICABLE" or "UNKNOWN".
    """
    if fcf is None or fcf <= 0:
        return None, "UNKNOWN", ("free cash flow is not positive, so the share of it returned to "
                                 "shareholders is not a meaningful ratio")

    def _v(x):
        try:
            return float(x) if x is not None else None
        except (TypeError, ValueError):
            return None

    buybacks, dividends = _v(period.get("buybacks")), _v(period.get("dividends_paid"))
    if buybacks is None and dividends is None:
        return None, "UNKNOWN", ("neither a share-repurchase nor a dividend line was found, so "
                                 "whether anything was distributed cannot be established")

    total = (buybacks or 0.0) + (dividends or 0.0)
    if total <= 0:
        return None, "NOT_APPLICABLE", (
            "this company distributed nothing to shareholders in the period. That is NOT scored "
            "as excellent capital allocation: it may mean productive reinvestment, appropriate "
            "retention, or poor allocation, and this measurement cannot distinguish them. The "
            "metric is set aside and its weight leaves the denominator rather than awarding a "
            "mark that has not been earned.")
    return total / fcf, "OK", None


def evaluate(metrics: dict, usable_verdicts) -> dict:
    """Score one company against the locked model.

    `metrics` is the validated metric map — each entry carrying a value and a verdict, so a figure
    this app could not stand behind never reaches a score. `usable_verdicts` is the set of
    verdicts that count as measured.

    An unmeasurable metric's weight leaves the denominator of its category; it never scores zero.
    An unmeasurable CATEGORY's weight leaves the overall denominator. Missing data reduces
    confidence, and confidence is reported separately from quality — it never masquerades as a
    poor result.
    """
    categories, weighted_score, weighted_coverage, live_weight = {}, 0.0, 0.0, 0.0

    for name, (weight, definitions) in COMPANY_HEALTH_MODEL.items():
        scored, missing = {}, []
        for metric, direction, weak, adequate, strong in definitions:
            entry = metrics.get(metric) or {}
            if entry.get("verdict") not in usable_verdicts:
                missing.append(metric)
                continue
            value = score_metric(entry.get("value"), direction, weak, adequate, strong)
            if value is None:
                missing.append(metric)
                continue
            scored[metric] = round(value, 1)

        coverage = len(scored) / len(definitions) * 100.0 if definitions else 0.0
        category_score = (sum(scored.values()) / len(scored)) if scored else None

        # A red flag needs both a bad score AND enough of the category measured to mean it.
        red_flag = bool(
            category_score is not None
            and category_score < RED_FLAG_CATEGORY_SCORE
            and coverage >= RED_FLAG_MIN_CATEGORY_COVERAGE_PCT)

        categories[name] = {
            "weight": weight,
            "score": round(category_score, 1) if category_score is not None else None,
            "coverage_pct": round(coverage, 1),
            "metrics_scored": scored,
            "metrics_missing": missing,
            "red_flag": red_flag,
            "insufficient_data": category_score is None or (
                category_score < RED_FLAG_CATEGORY_SCORE
                and coverage < RED_FLAG_MIN_CATEGORY_COVERAGE_PCT),
        }

        weighted_coverage += weight * coverage / 100.0
        if category_score is not None:
            weighted_score += weight * category_score
            live_weight += weight

    total_weight = sum(w for w, _ in COMPANY_HEALTH_MODEL.values())
    overall_coverage = weighted_coverage / total_weight * 100.0 if total_weight else 0.0
    overall_score = (weighted_score / live_weight) if live_weight else None

    red_flags = [n for n, c in categories.items() if c["red_flag"]]
    out = {
        "categories": categories,
        "coverage_pct": round(overall_coverage, 1),
        "score": round(overall_score, 1) if overall_score is not None else None,
        "red_flags": red_flags,
        "capped": False,
        "cap_reason": None,
        "verdict": None,
        "verdict_reason": None,
    }

    # THE COVERAGE GATE COMES FIRST AND OVERRIDES EVERYTHING BELOW IT. Too little data is not a
    # bad company; publishing a score built on a third of the model would be inventing confidence.
    if overall_coverage < COVERAGE_GATE_PCT or overall_score is None:
        out["score"] = None
        out["verdict"] = INSUFFICIENT
        out["verdict_reason"] = (
            f"only {overall_coverage:.1f}% of the Company Health model could be measured for this "
            f"company, against the {COVERAGE_GATE_PCT:.0f}% needed to answer. No score is given: "
            f"a company this app cannot measure is not the same as a weak company, and reporting "
            f"one as the other would be the worst mistake available here.")
        return out

    out["verdict"] = next(name for floor, name in VERDICT_BANDS if overall_score >= floor)

    # Capping. Applied AFTER the score so the number is always visible — a capped verdict shows
    # what the company scored and why the verdict disagrees with it.
    if SOLVENCY_CATEGORY in red_flags:
        out.update({
            "capped": True,
            "verdict": WEAK,
            "cap_reason": (
                f"the {SOLVENCY_CATEGORY.replace('_', ' ')} category scored "
                f"{categories[SOLVENCY_CATEGORY]['score']}, below {RED_FLAG_CATEGORY_SCORE:.0f}. "
                f"Every other category describes how well this business performs; this one "
                f"describes whether it survives. A shareholder can wait out weak growth or poor "
                f"capital allocation — an inability to service debt is the one weakness where "
                f"waiting is what does the damage."),
        })
    elif len(red_flags) >= CAP_AT_N_RED_FLAGS:
        out.update({
            "capped": True,
            "verdict": WEAK,
            "cap_reason": (
                f"{len(red_flags)} categories scored below {RED_FLAG_CATEGORY_SCORE:.0f} "
                f"({', '.join(r.replace('_', ' ') for r in red_flags)}). One weak area can be a "
                f"deliberate strategy or a bad year; two independent areas failing at once is a "
                f"pattern rather than a phase."),
        })

    if out["capped"]:
        out["verdict_reason"] = (
            f"scored {overall_score:.1f}, which alone would read "
            f"{next(n for f, n in VERDICT_BANDS if overall_score >= f)}, but the verdict is capped "
            f"at WEAK: {out['cap_reason']}")
    else:
        out["verdict_reason"] = (
            f"scored {overall_score:.1f} on {overall_coverage:.1f}% of the model"
            + (f", with fundamental red flags in {', '.join(red_flags)}" if red_flags else ""))
    return out
