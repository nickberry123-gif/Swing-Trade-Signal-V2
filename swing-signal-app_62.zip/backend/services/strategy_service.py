"""
Editable trading strategies — the thing the Backtest, Entry Test and Selection Test run against.

A strategy is four groups of settings:

  WEIGHTS     how many of the 100 points each component contributes
  THRESHOLDS  the score at which a signal becomes BUY or STRONG BUY
  FILTERS     hard conditions that veto an entry regardless of score
  EXITS       used by the backtest only; the entry and selection tests never sell

HOW RE-WEIGHTING WORKS WITHOUT REWRITING THE SCORERS
----------------------------------------------------
Each scorer in signal_engine already returns points out of its own fixed default (long-term
trend out of 20, momentum out of 15, and so on). Dividing by that default turns it into a
fraction from 0 to 1 — "how well did this component score" — independent of any weighting.
Multiplying the fraction by the strategy's weight then applies the new one. Nothing inside the
scorers changes, so a strategy can never silently alter what a component MEANS, only how much
it counts.

Components that could not be computed are excluded from the denominator rather than scored
zero, exactly as the live engine does. A stock is not penalised for data the app could not get.

THE OVERFITTING PROBLEM, WHICH IS THE REAL SUBJECT OF THIS MODULE
-----------------------------------------------------------------
Searching many strategies against one fixed five-year window produces a winner by arithmetic,
not by insight. If you try 40 variants, the best of 40 will look good even when every one of
them is worthless. Three defences are built in rather than left as advice:

  * every strategy is stored, so the number of attempts is known and displayed;
  * results are split in-sample / out-of-sample, and only the out-of-sample half counts;
  * a strategy can be compared against hundreds of RANDOM weightings run through the identical
    test, which shows what luck alone produces. Beating 50% of random noise is nothing.

None of that makes searching safe. It makes the self-deception visible.
"""
import json
import logging

from services.signal_engine import SIGNAL_THRESHOLDS, WEIGHTS as DEFAULT_WEIGHTS

log = logging.getLogger(__name__)

# The components a HISTORICAL test can actually compute. News, earnings risk and fundamentals
# are excluded everywhere in the test path because no point-in-time source exists for them —
# using today's values on past dates would be look-ahead bias.
TESTABLE_COMPONENTS = ["long_trend", "short_trend", "momentum", "rsi_pullback",
                       "volume", "support_resistance", "relative_strength", "market_regime"]

# Default points per component, as the scorers themselves are written. These are the divisors
# that turn a scorer's output back into a 0-1 fraction.
COMPONENT_DEFAULT_MAX = {
    "long_trend": DEFAULT_WEIGHTS["long_term_trend"],
    "short_trend": DEFAULT_WEIGHTS["short_term_trend"],
    "momentum": DEFAULT_WEIGHTS["momentum"],
    "rsi_pullback": DEFAULT_WEIGHTS["rsi_pullback"],
    "volume": DEFAULT_WEIGHTS["volume"],
    "support_resistance": DEFAULT_WEIGHTS["support_resistance"],
    "relative_strength": DEFAULT_WEIGHTS["relative_strength"],
    "market_regime": DEFAULT_WEIGHTS["market_regime"],
}

BASELINE_NAME = "v1.0 baseline"

MAX_WEIGHT = 50
MIN_THRESHOLD, MAX_THRESHOLD = 1, 99


def default_strategy() -> dict:
    """Strategy v1.0 exactly as the app has always behaved. The control for every comparison."""
    return {
        "name": BASELINE_NAME,
        "weights": dict(COMPONENT_DEFAULT_MAX),
        "buy_threshold": next(t for t, n in SIGNAL_THRESHOLDS if n == "BUY"),
        "strong_buy_threshold": next(t for t, n in SIGNAL_THRESHOLDS if n == "STRONG BUY"),
        "filters": {
            "require_bull_regime": False,
            "max_rsi": None,
            "min_rsi": None,
            "require_above_sma200": False,
        },
        "exits": {
            "max_holding_days": 40,
            "exit_on_signal": True,
            "profit_target_pct": None,     # None = use the engine's own primary target
        },
        "notes": "The strategy as originally built. Kept as the control — do not edit.",
    }


def normalise_strategy(raw: dict | None) -> dict:
    """Coerce anything into a complete, valid strategy. Never raises on bad input.

    A half-filled strategy from an old row or a hand-edited payload must not be able to produce
    a subtly different scoring rule that nobody notices — missing keys fall back to the
    baseline, and out-of-range numbers are clamped rather than silently accepted.
    """
    base = default_strategy()
    if not raw:
        return base
    out = dict(base)
    out["name"] = str(raw.get("name") or base["name"])[:80]
    out["notes"] = str(raw.get("notes") or "")[:500]

    weights = dict(base["weights"])
    for k in TESTABLE_COMPONENTS:
        v = (raw.get("weights") or {}).get(k)
        if v is None:
            continue
        try:
            weights[k] = max(0, min(MAX_WEIGHT, float(v)))
        except (TypeError, ValueError):
            pass
    out["weights"] = weights

    def _thr(key, fallback):
        try:
            return max(MIN_THRESHOLD, min(MAX_THRESHOLD, float(raw.get(key, fallback))))
        except (TypeError, ValueError):
            return fallback

    out["buy_threshold"] = _thr("buy_threshold", base["buy_threshold"])
    out["strong_buy_threshold"] = _thr("strong_buy_threshold", base["strong_buy_threshold"])
    # STRONG BUY below BUY would make the labels non-monotonic and every downstream comparison
    # meaningless, so the ordering is enforced rather than trusted.
    if out["strong_buy_threshold"] < out["buy_threshold"]:
        out["strong_buy_threshold"] = out["buy_threshold"]

    f = dict(base["filters"])
    rf = raw.get("filters") or {}
    f["require_bull_regime"] = bool(rf.get("require_bull_regime", False))
    f["require_above_sma200"] = bool(rf.get("require_above_sma200", False))
    for key in ("max_rsi", "min_rsi"):
        v = rf.get(key)
        if v in (None, "", "null"):
            f[key] = None
        else:
            try:
                f[key] = max(0.0, min(100.0, float(v)))
            except (TypeError, ValueError):
                f[key] = None
    out["filters"] = f

    e = dict(base["exits"])
    re_ = raw.get("exits") or {}
    try:
        e["max_holding_days"] = max(1, min(500, int(re_.get("max_holding_days", 40))))
    except (TypeError, ValueError):
        pass
    e["exit_on_signal"] = bool(re_.get("exit_on_signal", True))
    v = re_.get("profit_target_pct")
    if v in (None, "", "null"):
        e["profit_target_pct"] = None
    else:
        try:
            e["profit_target_pct"] = max(0.5, min(200.0, float(v)))
        except (TypeError, ValueError):
            e["profit_target_pct"] = None
    out["exits"] = e
    return out


def total_weight(strategy: dict) -> float:
    return sum(strategy["weights"].get(k, 0) for k in TESTABLE_COMPONENTS)


def score_from_components(components: dict, strategy: dict) -> dict:
    """Apply a strategy's weights to already-computed component points.

    `components` maps component key -> points on the DEFAULT scale, or None where the component
    could not be computed. Splitting scoring in two like this is what makes the strategy lab
    affordable: the expensive part (deriving the components from bars) happens once, and trying
    another weighting afterwards is arithmetic.
    """
    earned = 0.0
    available = 0.0
    for k in TESTABLE_COMPONENTS:
        pts = components.get(k)
        if pts is None:
            continue                      # not computable: excluded, never scored zero
        denom = COMPONENT_DEFAULT_MAX.get(k) or 0
        if denom <= 0:
            continue
        w = strategy["weights"].get(k, 0)
        earned += (pts / denom) * w
        available += w
    if available <= 0:
        return {"score": 0.0, "label": "NO DATA", "available_weight": 0.0}
    score = round(earned / available * 100, 2)
    return {"score": score, "label": label_for(score, strategy), "available_weight": available}


def label_for(score: float, strategy: dict) -> str:
    if score >= strategy["strong_buy_threshold"]:
        return "STRONG BUY"
    if score >= strategy["buy_threshold"]:
        return "BUY"
    if score >= 45:
        return "WATCH"
    if score >= 25:
        return "NO TRADE"
    return "AVOID"


def passes_filters(ind: dict, regime: dict, strategy: dict) -> bool:
    """Hard vetoes applied AFTER scoring. A filter can only ever remove an entry, never add one.

    Kept separate from the weights on purpose: a weight shifts a preference, a filter refuses.
    Mixing the two would make it impossible to tell which of the pair caused a change in results.
    """
    f = strategy.get("filters") or {}

    if f.get("require_bull_regime"):
        if (regime or {}).get("regime") not in ("BULL", "STRONG BULL"):
            return False

    rsi = ind.get("rsi14")
    if f.get("max_rsi") is not None:
        if rsi is None or rsi > f["max_rsi"]:
            return False                  # unknown RSI fails a filter that requires knowing it
    if f.get("min_rsi") is not None:
        if rsi is None or rsi < f["min_rsi"]:
            return False

    if f.get("require_above_sma200"):
        price, sma200 = ind.get("reference_price"), ind.get("sma200")
        if price is None or sma200 is None or price <= sma200:
            return False

    return True


def random_strategy(rng, template: dict | None = None) -> dict:
    """A strategy with random weights, for the null distribution.

    Thresholds, filters and exits are held at the template's values so the comparison isolates
    the weighting. If the random ones were randomised too, a strategy could beat the null by
    having a better THRESHOLD while its weights were no better than noise, and the result would
    be read as evidence about the weights.
    """
    base = normalise_strategy(template)
    weights = {k: float(rng.integers(0, MAX_WEIGHT + 1)) for k in TESTABLE_COMPONENTS}
    if sum(weights.values()) <= 0:
        weights[TESTABLE_COMPONENTS[0]] = 10.0
    out = dict(base)
    out["weights"] = weights
    out["name"] = "random"
    return out


# ---------------------------------------------------------------- persistence

def ensure_baseline(db) -> None:
    """Guarantee the control strategy exists, once, and is never edited into something else."""
    row = db.execute("SELECT id FROM strategies WHERE name = ?", (BASELINE_NAME,)).fetchone()
    if row:
        return
    s = default_strategy()
    db.execute(
        "INSERT INTO strategies (name, config_json, is_baseline) VALUES (?, ?, 1)",
        (s["name"], json.dumps(s)))
    db.commit()


def list_strategies(db) -> list:
    ensure_baseline(db)
    rows = db.execute(
        "SELECT id, name, config_json, is_baseline, created_at FROM strategies ORDER BY id ASC"
    ).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["config"] = normalise_strategy(json.loads(d.pop("config_json")))
        except (TypeError, ValueError):
            d["config"] = default_strategy()
        d["is_baseline"] = bool(d.get("is_baseline"))
        out.append(d)
    return out


def get_strategy(db, strategy_id: int) -> dict | None:
    row = db.execute("SELECT id, name, config_json, is_baseline FROM strategies WHERE id = ?",
                     (strategy_id,)).fetchone()
    if row is None:
        return None
    d = dict(row)
    try:
        d["config"] = normalise_strategy(json.loads(d.pop("config_json")))
    except (TypeError, ValueError):
        d["config"] = default_strategy()
    d["is_baseline"] = bool(d.get("is_baseline"))
    return d


def save_strategy(db, config: dict, strategy_id: int | None = None) -> int:
    cfg = normalise_strategy(config)
    if strategy_id:
        existing = get_strategy(db, strategy_id)
        if existing and existing["is_baseline"]:
            raise ValueError("The baseline strategy is the control for every comparison and "
                             "cannot be edited. Duplicate it instead.")
        db.execute("UPDATE strategies SET name = ?, config_json = ? WHERE id = ?",
                   (cfg["name"], json.dumps(cfg), strategy_id))
        db.commit()
        return strategy_id
    new_id = db.insert_returning_id(
        "INSERT INTO strategies (name, config_json, is_baseline) VALUES (?, ?, 0)",
        (cfg["name"], json.dumps(cfg)))
    db.commit()
    return new_id


def delete_strategy(db, strategy_id: int) -> None:
    existing = get_strategy(db, strategy_id)
    if existing and existing["is_baseline"]:
        raise ValueError("The baseline strategy cannot be deleted.")
    db.execute("DELETE FROM strategies WHERE id = ?", (strategy_id,))
    db.commit()


def attempt_count(db) -> int:
    """How many non-baseline strategies exist — i.e. how many variants have been tried.

    Displayed next to every result. With N attempts the best of N looks better than any one of
    them deserves, and the only defence is knowing what N is.
    """
    row = db.execute("SELECT COUNT(*) AS n FROM strategies WHERE is_baseline = 0").fetchone()
    return int(dict(row)["n"]) if row else 0
