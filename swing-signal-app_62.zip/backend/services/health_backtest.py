"""
Historical validation of the FROZEN C1 Company Health model.

THE QUESTION
    Did companies scoring STRONG/SOLID subsequently show better company health than those scoring
    ADEQUATE/WEAK?

WHAT THIS MODULE MAY NOT DO, AND THE REASON IT IS WRITTEN THIS WAY
==================================================================
A backtest is the most powerful tuning device available. Given results and a free hand, anyone can
find a window length, a date, an outcome measure or a group boundary that improves the answer, and
the improvement will feel like insight rather than fitting. The only real defence is that the
output of this module cannot reach back into the thing it tests.

So: **C1 is frozen and nothing here can change it.** This module imports the model, it does not
reimplement it, and `test_health_backtest.py` asserts that every constant below matches the
pre-registered methodology exactly. There is no parameter sweep anywhere — no mechanism for trying
several windows and choosing among them. If it cannot be swept, it cannot be fitted.

THE LIMITATION THAT OUTWEIGHS EVERY RESULT
==========================================
The fifty companies were selected in 2026 on the basis of what they look like in 2026, and
**nothing in the universe failed** — no delisting, no bankruptcy, no permanent impairment. A
quality model's most valuable property is avoiding disasters, and there are no disasters here.
This study cannot measure that.

The DIRECTION of the selection bias cannot be established either. The universe contains companies
chosen partly because they later transformed, which would penalise the model, and only companies
that did well enough to be chosen at all, which would flatter it. Both are present; neither is
measurable from this sample. So a positive result means "encouraging evidence within this selected
universe, requiring validation on an independent historical universe before being treated as
evidence of general robustness" — and a negative or null result is reported as produced and
investigated on its merits, not waved away because the universe is selected.

LOOK-AHEAD
==========
Scoring uses `as_of_filed`, which filters on the date SEC PUBLISHED a filing, so a restatement
issued later is excluded by the query rather than merely ignored. Forward outcomes are computed by
a separate function that the scoring path never calls and whose results are never passed into it.
No price is supplied to the historical scorer at all.
"""
from __future__ import annotations

from datetime import date, timedelta

from services import company_health as ch
from services import data_validation_service as dv
from services import fundamentals_history_service as fh
from services import operating_profit as op

# =================================================================================================
# PRE-REGISTERED CONSTANTS. Approved before any result existed; asserted by test_health_backtest.py.
# =================================================================================================

#: 30 June rather than 1 January: by mid-year a calendar-year filer has published its prior-year
#: 10-K, so companies are compared on filings of broadly similar age rather than on an artefact of
#: the calendar.
SCORING_DATES = ("2019-06-30", "2020-06-30", "2021-06-30", "2022-06-30")

#: FIXED at every scoring date. The live model asks for six periods, but a 2019 score cannot have
#: six, and a five-year growth rate is not the same measurement as a six-year one. Holding the
#: window fixed is what makes the four dates comparable to each other — and it means these scores
#: are NOT comparable to the live run-9 scores, which is stated wherever they are reported.
HISTORY_PERIODS = 5

#: Long enough for a fundamental trend to appear, short enough to fit inside the stored data.
FORWARD_YEARS = 3

#: Ranked, never thresholded. Inventing five more thresholds after seeing outcomes is precisely the
#: fitting this exercise exists to prevent. `higher_is_better=False` marks leverage, where an
#: increase is deterioration.
FORWARD_MEASURES = (
    ("revenue_cagr_pct", True),
    ("operating_margin_change_pp", True),
    ("roic_change_pp", True),
    ("net_debt_to_ebitda_change", False),
    ("fcf_margin_change_pp", True),
)

STRONG_GROUP = ("STRONG", "SOLID")
WEAK_GROUP = ("ADEQUATE", "WEAK")

MIN_COMPANIES_PER_DATE = 25
MIN_GROUP_SIZE = 8

UNDERPOWERED = "UNDERPOWERED — NOT INTERPRETED"


def _iso_plus_years(iso: str, years: int) -> str:
    d = date.fromisoformat(iso)
    try:
        return d.replace(year=d.year + years).isoformat()
    except ValueError:                       # 29 February
        return (d.replace(year=d.year + years, day=28)).isoformat()


# =================================================================================================
# SCORING — POINT IN TIME
# =================================================================================================
def _validate_cached(db, ticker: str, as_of: str, cache=None) -> dict:
    """One validated result per (ticker, date), computed once.

    Purely a cost measure: eight distinct dates across four scoring dates and their forward dates,
    times fifty companies, is 400 validations rather than 600 — and several dates are shared,
    because the forward date of one cohort is the scoring date of a later one. The cache is keyed
    on the as-of date, so it can never serve a result computed under a different cutoff.
    """
    key = (ticker, as_of)
    if cache is not None and key in cache:
        return cache[key]
    result = dv.validate_ticker(db, ticker, price=None, as_of_filed=as_of,
                                years=HISTORY_PERIODS)
    if cache is not None:
        cache[key] = result
    return result


def score_at(db, ticker: str, scoring_date: str, cache=None) -> dict:
    """The frozen C1 score for one company, as it could have been computed on `scoring_date`.

    NO PRICE IS PASSED. Company Health touches no price by design, and passing one would create a
    channel through which a future bar could reach a historical score. `price=None` closes it at
    the call site rather than trusting the model to ignore what it is given.

    `years=HISTORY_PERIODS` fixes the window. `as_of_filed` does the point-in-time work: rows are
    selected by the date SEC published them, so a restatement issued after `scoring_date` is
    removed by the WHERE clause and cannot be reached from here.
    """
    result = _validate_cached(db, ticker, scoring_date, cache)
    return {
        "ticker": ticker,
        "scoring_date": scoring_date,
        "score": result.get("company_health_score"),
        "verdict": result.get("company_health_verdict"),
        "coverage_pct": result.get("company_health_coverage_pct"),
        "periods_used": result.get("periods"),
        "period_ends": result.get("period_ends"),
        "red_flags": result.get("company_health_red_flags") or [],
        "capped": bool((result.get("company_health") or {}).get("capped")),
    }


# =================================================================================================
# FORWARD OUTCOMES — A SEPARATE PATH THE SCORER NEVER TOUCHES
# =================================================================================================
def _metrics_at(db, ticker: str, as_of: str, cache=None) -> tuple:
    """The validated metric map and newest annual row available at `as_of`."""
    result = _validate_cached(db, ticker, as_of, cache)
    rows = fh.history(db, ticker, as_of_filed=as_of, limit=HISTORY_PERIODS)
    return result.get("metrics") or {}, (rows[0] if rows else None)


def _usable(metric):
    return metric.get("value") if metric and metric.get("verdict") in dv.USABLE else None


def forward_outcome(db, ticker: str, scoring_date: str, cache=None) -> dict:
    """The five forward fundamental measures, FY(t) → FY(t+FORWARD_YEARS).

    DELIBERATELY NOT THE FUTURE COMPANY HEALTH SCORE. Scoring the model against itself would
    reward persistence rather than prediction: a model that simply repeated last year's answer
    would look excellent. Every measure here is a directly reported fundamental.

    The forward figures are read at `scoring_date + FORWARD_YEARS`, which is by construction later
    than anything the score could see. This function is never called from `score_at` and its return
    value is never passed into it — the separation is structural, not a convention.
    """
    forward_date = _iso_plus_years(scoring_date, FORWARD_YEARS)
    base_metrics, base_row = _metrics_at(db, ticker, scoring_date, cache)
    fwd_metrics, fwd_row = _metrics_at(db, ticker, forward_date, cache)

    out = {"ticker": ticker, "scoring_date": scoring_date, "forward_date": forward_date,
           "base_period_end": (base_row or {}).get("period_end"),
           "forward_period_end": (fwd_row or {}).get("period_end"),
           "measures": {}, "missing": [], "excluded": None}

    if base_row is None or fwd_row is None:
        out["excluded"] = "no annual history at the scoring date or the forward date"
        return out
    if not (fwd_row["period_end"] > base_row["period_end"]):
        out["excluded"] = (
            f"the newest annual period available at {forward_date} "
            f"({fwd_row['period_end']}) is not later than the one available at {scoring_date} "
            f"({base_row['period_end']}), so no forward change can be measured")
        return out

    # Revenue growth, annualised over the ACTUAL gap between the two fiscal period ends rather
    # than an assumed three years — fiscal calendars drift and some companies will land on a two-
    # or four-year gap.
    base_rev, fwd_rev = dv._v(base_row.get("revenue")), dv._v(fwd_row.get("revenue"))
    span_days = (date.fromisoformat(fwd_row["period_end"])
                 - date.fromisoformat(base_row["period_end"])).days
    years = span_days / 365.25
    out["forward_span_years"] = round(years, 2)
    if base_rev and fwd_rev and base_rev > 0 and fwd_rev > 0 and years > 0:
        out["measures"]["revenue_cagr_pct"] = ((fwd_rev / base_rev) ** (1.0 / years) - 1.0) * 100.0
    else:
        out["missing"].append("revenue_cagr_pct")

    for name, metric in (("operating_margin_change_pp", "operating_margin_pct"),
                         ("roic_change_pp", "roic_pct"),
                         ("net_debt_to_ebitda_change", "net_debt_to_ebitda"),
                         ("fcf_margin_change_pp", "fcf_margin_pct")):
        before, after = _usable(base_metrics.get(metric)), _usable(fwd_metrics.get(metric))
        if before is None or after is None:
            out["missing"].append(name)
            continue
        out["measures"][name] = after - before
    return out


# =================================================================================================
# RANKING AND STATISTICS — written out rather than imported, so they can be tested directly
# =================================================================================================
def rank_ascending(values: list) -> list:
    """Average ranks, ties shared. 1 is the smallest value."""
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        shared = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[order[k]] = shared
        i = j + 1
    return ranks


def composite_ranks(outcomes: list) -> dict:
    """Average of each company's rank on every forward measure it has.

    A company missing a measure is ranked on the ones it has, and the count travels with it. The
    alternative — dropping any company with one gap — would quietly select for well-covered
    companies, which is its own bias.
    """
    per_measure = {}
    for name, higher_is_better in FORWARD_MEASURES:
        present = [o for o in outcomes if name in o["measures"]]
        if len(present) < 2:
            continue
        values = [o["measures"][name] for o in present]
        ranks = rank_ascending(values)
        n = len(present)
        for o, r in zip(present, ranks):
            # Normalise to 0-1 so measures with different sample sizes are comparable, and flip
            # the ones where a smaller number is the better outcome.
            scaled = (r - 1) / (n - 1) if n > 1 else 0.5
            per_measure.setdefault(o["ticker"], []).append(
                scaled if higher_is_better else 1.0 - scaled)
    return {ticker: (sum(v) / len(v), len(v)) for ticker, v in per_measure.items()}


def spearman(xs: list, ys: list):
    """Rank correlation. Returns None when there is nothing to correlate."""
    if len(xs) != len(ys) or len(xs) < 3:
        return None
    rx, ry = rank_ascending(xs), rank_ascending(ys)
    n = len(xs)
    mx, my = sum(rx) / n, sum(ry) / n
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    dx = sum((a - mx) ** 2 for a in rx) ** 0.5
    dy = sum((b - my) ** 2 for b in ry) ** 0.5
    if dx == 0 or dy == 0:
        return None
    return num / (dx * dy)


def mann_whitney_u(group_a: list, group_b: list):
    """U for group A against group B, with the rank-biserial effect size.

    NO p-VALUE IS RETURNED, and that is deliberate rather than an omission. Four scoring dates a
    year apart with three-year forward windows, over one fixed set of fifty companies, produce
    observations that are not independent in any direction. A p-value computed as though they were
    would be the most misleading number this study could publish.
    """
    if not group_a or not group_b:
        return None
    combined = group_a + group_b
    ranks = rank_ascending(combined)
    rank_a = sum(ranks[:len(group_a)])
    n_a, n_b = len(group_a), len(group_b)
    u_a = rank_a - n_a * (n_a + 1) / 2.0
    return {"u": u_a, "n_a": n_a, "n_b": n_b,
            # +1 means every A outranked every B; -1 the reverse; 0 no separation.
            "rank_biserial": 2.0 * u_a / (n_a * n_b) - 1.0,
            "mean_rank_a": rank_a / n_a,
            "mean_rank_b": (sum(ranks) - rank_a) / n_b}


# =================================================================================================
# THE RUN
# =================================================================================================
def run_date(db, tickers, scoring_date: str, cache=None) -> dict:
    """One scoring date, start to finish. Every exclusion is named and counted."""
    scored, excluded = [], []
    for ticker in sorted(tickers):
        try:
            s = score_at(db, ticker, scoring_date, cache)
        except Exception as e:                                   # noqa: BLE001
            excluded.append({"ticker": ticker, "reason": f"scoring failed: {e}"})
            continue
        if s["score"] is None:
            excluded.append({"ticker": ticker,
                             "reason": f"{s['verdict']} at the scoring date",
                             "coverage_pct": s["coverage_pct"]})
            continue
        scored.append(s)

    outcomes, outcome_excluded = [], []
    for s in scored:
        o = forward_outcome(db, s["ticker"], scoring_date, cache)
        if o["excluded"] or not o["measures"]:
            outcome_excluded.append({"ticker": s["ticker"],
                                     "reason": o["excluded"] or "no forward measure available"})
            continue
        outcomes.append(o)

    composites = composite_ranks(outcomes)
    paired = [(s, composites[s["ticker"]][0]) for s in scored if s["ticker"] in composites]

    out = {
        "scoring_date": scoring_date,
        "forward_date": _iso_plus_years(scoring_date, FORWARD_YEARS),
        "universe": len(tickers),
        "scored": len(scored),
        "analysed": len(paired),
        "excluded_at_scoring": excluded,
        "excluded_at_outcome": outcome_excluded,
        "verdicts": {},
        "companies": sorted(
            [{"ticker": s["ticker"], "score": s["score"], "verdict": s["verdict"],
              "coverage_pct": s["coverage_pct"], "capped": s["capped"],
              "forward_composite": round(c, 4),
              "measures_used": composites[s["ticker"]][1]}
             for s, c in paired], key=lambda r: -r["score"]),
        "spearman_score_vs_forward": None,
        "group_comparison": None,
        "underpowered": [],
    }
    for s in scored:
        out["verdicts"][s["verdict"]] = out["verdicts"].get(s["verdict"], 0) + 1

    if len(paired) < MIN_COMPANIES_PER_DATE:
        out["underpowered"].append(
            f"{UNDERPOWERED}: {len(paired)} companies analysed, "
            f"below the pre-registered minimum of {MIN_COMPANIES_PER_DATE}")
        return out

    out["spearman_score_vs_forward"] = spearman([s["score"] for s, _c in paired],
                                                [c for _s, c in paired])

    strong = [c for s, c in paired if s["verdict"] in STRONG_GROUP]
    weak = [c for s, c in paired if s["verdict"] in WEAK_GROUP]
    if len(strong) >= MIN_GROUP_SIZE and len(weak) >= MIN_GROUP_SIZE:
        out["group_comparison"] = mann_whitney_u(strong, weak)
    else:
        out["underpowered"].append(
            f"{UNDERPOWERED}: group comparison needs {MIN_GROUP_SIZE} in each group; "
            f"STRONG/SOLID has {len(strong)}, ADEQUATE/WEAK has {len(weak)}")
    return out


def run(db, tickers) -> dict:
    """Every pre-registered scoring date. One pass, no alternatives, nothing selected afterwards."""
    cache = {}
    dates = [run_date(db, tickers, d, cache) for d in SCORING_DATES]
    return {
        "methodology": {
            "scoring_dates": list(SCORING_DATES),
            "history_periods": HISTORY_PERIODS,
            "forward_years": FORWARD_YEARS,
            "forward_measures": [m for m, _d in FORWARD_MEASURES],
            "min_companies_per_date": MIN_COMPANIES_PER_DATE,
            "min_group_size": MIN_GROUP_SIZE,
            "c1_model_frozen": True,
        },
        "dates": dates,
        "interpretation": (
            "A positive result is encouraging evidence WITHIN this selected 50-stock universe, and "
            "requires validation on an independent historical universe before being treated as "
            "evidence of general robustness. A negative or null result is reported as produced and "
            "investigated on its merits. No company in this universe was delisted or failed, so "
            "the model's ability to avoid permanent impairment is untested here. No p-value is "
            "reported: four overlapping windows over one fixed set of companies do not provide "
            "independent observations, and significance cannot be claimed from this sample."),
    }
