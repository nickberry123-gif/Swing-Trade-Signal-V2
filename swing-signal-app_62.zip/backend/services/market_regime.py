"""
Market regime classification: STRONG BULL / BULL / NEUTRAL / CAUTIOUS / BEAR.

Built from four transparent, independently-scored components (never a black box):
  1. SPY trend  (price vs 200-day SMA, 200-day SMA direction, price vs 50-day SMA)
  2. QQQ trend  (same three checks)
  3. Sector breadth  (how many of the tracked sector ETFs are in an uptrend)
  4. Volatility proxy  (10-day rate of change of VIXY — true CBOE VIX is not available from
     Alpaca; see config.VIX_PROXY_TICKER)

Each component contributes a small signed score; the total is bucketed into the five regime
labels. The full breakdown is returned alongside the label so the UI (and, later, the
trading-score engine) can show exactly why the regime is what it is — mirrors the "WHY THIS
SCORE?" transparency requirement applied one level up, at the market level.

MISSING DATA USED TO BE SCORED AS CALM, AND THAT WAS A FABRICATION
-----------------------------------------------------------------
Every component returned a raw signed score with no record of how much of it could actually be
measured, and the total was bucketed against absolute thresholds. So an unavailable component
contributed 0 — which is not "unknown", it is "neutral", and the two are different claims.

Three concrete consequences, all verified before the fix:

  * VIXY unavailable returned 0.0, while a genuinely FLAT VIXY returns +0.5. Missing volatility
    data was therefore not even neutral: it read half a point more bearish than calm markets.
  * All sector ETFs missing returned 0.0 for breadth — indistinguishable from perfectly balanced
    breadth.
  * `have_core_data` only required ONE bar of SPY and QQQ. With three days of history every SMA
    is None, both trend components score 0, and the app published a confident NEUTRAL built from
    nothing at all.

And NEUTRAL is not harmless: signal_engine maps it to 2.5 points in every one of the 50 stocks'
scores. The UNAVAILABLE branch that engine carefully provides almost never fired.

THE RULE NOW: every component reports how many of its checks it could evaluate. Coverage below
MIN_COVERAGE returns UNAVAILABLE rather than a label. Above it, the score is scaled by what was
measurable — the same principle the v2 signal scorer uses, where an unknown component leaves the
denominator instead of counting as a pass.
"""
from datetime import datetime, timezone

from config import BROAD_MARKET_SYMBOLS, VIX_PROXY_TICKER, SECTOR_ETF_SYMBOLS
from services.bars_service import get_bars_df
from services.indicators import compute_all_indicators

# The signed "weight" each component can contribute when fully measurable. Used only to work
# out coverage — how much of the picture was actually visible — never to alter a score directly.
COMPONENT_WEIGHTS = {"spy_trend": 3, "qqq_trend": 3, "sector_breadth": 3, "volatility_proxy": 2}
FULL_COVERAGE = sum(COMPONENT_WEIGHTS.values())      # 11

# Below this fraction of the picture, there is no honest label to give. Chosen so that losing the
# volatility proxy alone (2 of 11) still leaves a usable reading, but losing an index trend does
# not.
MIN_COVERAGE = 0.6

# Each index trend needs at least this many of its three checks before it counts as measured. A
# stock with three days of history has a price but no SMA50 or SMA200, and scoring that as a flat
# market is exactly the fabrication this guards against.
MIN_TREND_CHECKS = 2

REGIME_THRESHOLDS = [
    (7, "STRONG BULL"),
    (3, "BULL"),
    (-2, "NEUTRAL"),
    (-6, "CAUTIOUS"),
    (float("-inf"), "BEAR"),
]


def _signed(value: float, zero_tolerance: float = 0.0) -> int:
    """+1 / -1 / 0, with a small dead zone around zero so near-exact ties (e.g. a
    genuinely flat market) score as neutral rather than being arbitrarily pushed bearish."""
    if value > zero_tolerance:
        return 1
    if value < -zero_tolerance:
        return -1
    return 0


def _trend_component(ind: dict) -> tuple[float, list[str], int]:
    """Score a single index's trend on -3..+3 using price vs SMA200 / SMA200 direction /
    price vs SMA50 — same three checks the qualitative trend_label uses, kept numeric here.
    Each check has a small neutral dead-zone (~0.1%) so near-flat conditions score as 0,
    not an arbitrary -1."""
    score = 0.0
    notes = []
    checks = 0                      # how many of the three could actually be evaluated
    price = ind.get("reference_price")
    sma50, sma200, slope = ind.get("sma50"), ind.get("sma200"), ind.get("sma200_slope")

    if price is not None and sma200 is not None and sma200 != 0:
        checks += 1
        pct_diff = (price - sma200) / sma200 * 100
        s = _signed(pct_diff, zero_tolerance=0.1)
        score += s
        notes.append(f"price {'above' if s > 0 else 'below' if s < 0 else 'in line with'} 200d SMA ({pct_diff:+.2f}%)")
    if slope is not None:
        checks += 1
        s = _signed(slope, zero_tolerance=0.05)
        score += s
        notes.append(f"200d SMA {'rising' if s > 0 else 'falling' if s < 0 else 'flat'} ({slope:+.2f}%)")
    if price is not None and sma50 is not None and sma50 != 0:
        checks += 1
        pct_diff = (price - sma50) / sma50 * 100
        s = _signed(pct_diff, zero_tolerance=0.1)
        score += s
        notes.append(f"price {'above' if s > 0 else 'below' if s < 0 else 'in line with'} 50d SMA ({pct_diff:+.2f}%)")
    if checks < 3:
        notes.append(f"only {checks} of 3 trend checks could be evaluated")
    return score, notes, checks


def _breadth_component(sector_indicators: dict) -> tuple[float, dict]:
    up, down, unknown = [], [], []
    for ticker, ind in sector_indicators.items():
        price, sma50 = ind.get("reference_price"), ind.get("sma50")
        if price is None or sma50 is None or sma50 == 0:
            unknown.append(ticker)
        else:
            pct_diff = (price - sma50) / sma50 * 100
            s = _signed(pct_diff, zero_tolerance=0.1)
            if s > 0:
                up.append(ticker)
            elif s < 0:
                down.append(ticker)
            else:
                unknown.append(ticker)
    total = len(up) + len(down)
    if total == 0:
        # NOT 0.0-and-carry-on. No sector could be read, so breadth is unknown — which is a very
        # different statement from "breadth is perfectly balanced", and the old code made both
        # look identical.
        return None, {"up": up, "down": down, "unknown": unknown, "measured": 0}
    score = (len(up) - len(down)) / total * 3
    return round(score, 3), {"up": up, "down": down, "unknown": unknown, "measured": total}


def _volatility_component(vix_proxy_ind: dict, vix_proxy_bars_len: int) -> tuple[float | None, str]:
    """None means UNKNOWN, and that is the whole point of this signature.

    It used to return 0.0 when VIXY was unavailable. A genuinely FLAT VIXY returns +0.5, so
    "no data" scored half a point MORE BEARISH than a calm market — an invented reading, in the
    bearish direction, produced by the absence of information.
    """
    if vix_proxy_bars_len < 6:
        return None, "insufficient VIXY history — volatility not scored"
    roc = vix_proxy_ind.get("roc")  # 10-day ROC computed by the shared indicator engine
    if roc is None:
        return None, "VIXY rate-of-change unavailable — volatility not scored"
    # Rising VIXY = rising fear = risk-off. Falling VIXY = calming = risk-on.
    if roc <= -8:
        return 2.0, f"VIXY down {roc:.1f}% (10d) — volatility calming"
    if roc <= 5:
        return 0.5, f"VIXY roughly flat ({roc:+.1f}% 10d)"
    if roc <= 15:
        return -1.5, f"VIXY up {roc:.1f}% (10d) — rising volatility"
    return -3.0, f"VIXY up {roc:.1f}% (10d) — sharp volatility spike"


def classify(score: float) -> str:
    for threshold, label in REGIME_THRESHOLDS:
        if score >= threshold:
            return label
    return "BEAR"


def compute_market_regime(db) -> dict:
    now = datetime.now(timezone.utc).isoformat()

    index_indicators = {}
    index_meta = {}
    for ticker in BROAD_MARKET_SYMBOLS:
        df, meta = get_bars_df(db, ticker, "1Day")
        index_meta[ticker] = meta
        index_indicators[ticker] = compute_all_indicators(df) if not df.empty else {"bars_used": 0, "warnings": ["no data"]}

    sector_indicators = {}
    sector_meta = {}
    for ticker in SECTOR_ETF_SYMBOLS:
        df, meta = get_bars_df(db, ticker, "1Day")
        sector_meta[ticker] = meta
        sector_indicators[ticker] = compute_all_indicators(df) if not df.empty else {"bars_used": 0, "warnings": ["no data"]}

    vix_df, vix_meta = get_bars_df(db, VIX_PROXY_TICKER, "1Day")
    vix_ind = compute_all_indicators(vix_df) if not vix_df.empty else {"bars_used": 0, "warnings": ["no data"]}

    spy_ind, qqq_ind = index_indicators.get("SPY", {}), index_indicators.get("QQQ", {})

    spy_score, spy_notes, spy_checks = _trend_component(spy_ind)
    qqq_score, qqq_notes, qqq_checks = _trend_component(qqq_ind)
    breadth_score, breadth_detail = _breadth_component(sector_indicators)
    vix_score, vix_note = _volatility_component(vix_ind, vix_ind.get("bars_used", 0))

    # HOW MUCH OF THE PICTURE WAS ACTUALLY VISIBLE. Previously nothing tracked this, so a
    # component that could not be measured contributed 0 and the total was bucketed as though
    # everything had been seen.
    measured, missing = 0, []
    if spy_checks >= MIN_TREND_CHECKS:
        measured += COMPONENT_WEIGHTS["spy_trend"]
    else:
        missing.append(f"SPY trend ({spy_checks} of 3 checks — not enough history)")
    if qqq_checks >= MIN_TREND_CHECKS:
        measured += COMPONENT_WEIGHTS["qqq_trend"]
    else:
        missing.append(f"QQQ trend ({qqq_checks} of 3 checks — not enough history)")
    if breadth_score is not None:
        measured += COMPONENT_WEIGHTS["sector_breadth"]
    else:
        missing.append("sector breadth (no sector ETF could be read)")
    if vix_score is not None:
        measured += COMPONENT_WEIGHTS["volatility_proxy"]
    else:
        missing.append(f"volatility proxy ({vix_note})")

    coverage = measured / FULL_COVERAGE

    if coverage < MIN_COVERAGE:
        # An honest refusal. The old code published a confident NEUTRAL here, and signal_engine
        # turned that into 2.5 points in all 50 stocks' scores.
        return {
            "regime": "UNAVAILABLE",
            "regime_score": None,
            "coverage_pct": round(coverage * 100, 1),
            "components_missing": missing,
            "error": ("Not enough market data to classify a regime — "
                      + "; ".join(missing) + ". No label is better than an invented one."),
            "computed_at": now,
        }

    raw = round(sum(x for x in (spy_score, qqq_score, breadth_score, vix_score)
                    if x is not None), 3)
    # Scale by what could be measured, so the thresholds keep meaning the same thing whether or
    # not every component was available. Same principle as the v2 signal scorer: score over the
    # weight that was actually assessable, never over a denominator that includes unknowns.
    total = round(raw / measured * FULL_COVERAGE, 3) if measured else raw
    regime = classify(total)

    def _chg_pct(ind):
        roc = ind.get("roc")
        return roc  # 10-day ROC used as the headline "change" figure for regime tiles

    detail = {
        "components": {
            "spy_trend": {"score": spy_score, "notes": spy_notes,
                          "checks_evaluated": spy_checks, "checks_possible": 3},
            "qqq_trend": {"score": qqq_score, "notes": qqq_notes,
                          "checks_evaluated": qqq_checks, "checks_possible": 3},
            "sector_breadth": {"score": breadth_score, "detail": breadth_detail,
                               "measured": breadth_score is not None},
            "volatility_proxy": {"score": vix_score, "note": vix_note,
                                 "measured": vix_score is not None},
        },
        "coverage": {"measured_weight": measured, "full_weight": FULL_COVERAGE,
                     "pct": round(coverage * 100, 1), "missing": missing,
                     "raw_score_before_scaling": raw},
        "sector_readings": {
            t: {"price": ind.get("reference_price"), "sma50": ind.get("sma50"),
                "trend_label": ind.get("trend_label"), "chg_pct": _chg_pct(ind)}
            for t, ind in sector_indicators.items()
        },
        "vix_true_index_status": "UNAVAILABLE (Alpaca does not provide CBOE index data; see VIX_PROXY_TICKER)",
    }

    return {
        "regime": regime,
        "regime_score": total,
        # Travels WITH the label, so nothing downstream can read a regime without being able to
        # see how much of the market it was built from.
        "coverage_pct": round(coverage * 100, 1),
        "components_missing": missing,
        # One entry per sector the tracked universe actually contains, with the ETF that stands
        # in for it. Derived from the universe rather than listed by hand, so changing the stock
        # list can never leave the dashboard showing a sector nobody holds — or hiding one they
        # do. SOXX, XLF and XLP are still fetched for the breadth score but do not appear here
        # unless a tracked stock maps to them.
        "sector_view": _sector_view(sector_indicators),
        "spy_price": spy_ind.get("reference_price"),
        "spy_chg_pct": _chg_pct(spy_ind),
        "spy_trend_label": spy_ind.get("trend_label"),
        "qqq_price": qqq_ind.get("reference_price"),
        "qqq_chg_pct": _chg_pct(qqq_ind),
        "qqq_trend_label": qqq_ind.get("trend_label"),
        "vix_status": "UNAVAILABLE",
        "vix_proxy_ticker": VIX_PROXY_TICKER,
        "vix_proxy_price": vix_ind.get("reference_price"),
        "vix_proxy_roc_10d": vix_ind.get("roc"),
        "detail": detail,
        "computed_at": now,
    }


def store_market_regime(db, result: dict):
    import json
    db.execute(
        """
        INSERT INTO market_regime (ts, spy_price, spy_chg_pct, qqq_price, qqq_chg_pct,
                                    vix_price, vix_status, vix_proxy_ticker, vix_proxy_price,
                                    vix_proxy_chg_5d_pct, regime_score, regime, detail_json)
        VALUES (:ts, :spy_price, :spy_chg_pct, :qqq_price, :qqq_chg_pct, NULL, :vix_status,
                :vix_proxy_ticker, :vix_proxy_price, :vix_proxy_roc_10d, :regime_score, :regime,
                :detail_json)
        """,
        {
            "ts": result.get("computed_at"),
            "spy_price": result.get("spy_price"), "spy_chg_pct": result.get("spy_chg_pct"),
            "qqq_price": result.get("qqq_price"), "qqq_chg_pct": result.get("qqq_chg_pct"),
            "vix_status": result.get("vix_status"), "vix_proxy_ticker": result.get("vix_proxy_ticker"),
            "vix_proxy_price": result.get("vix_proxy_price"), "vix_proxy_roc_10d": result.get("vix_proxy_roc_10d"),
            "regime_score": result.get("regime_score"), "regime": result.get("regime"),
            "detail_json": json.dumps(result.get("detail", {})),
        },
    )
    db.commit()


def _sector_view(sector_indicators: dict) -> list:
    """The sectors present in the tracked universe, each with its proxy ETF's reading.

    Ordered by how many tracked companies sit in the sector, largest first, so the dashboard
    leads with where the money actually is.
    """
    from config import SECTOR_ETF_MAP, STOCK_UNIVERSE

    counts, etf_for = {}, {}
    for stock in STOCK_UNIVERSE:
        sector = stock.get("sector") or "Other"
        etf = SECTOR_ETF_MAP.get(stock["ticker"])
        if not etf:
            continue
        counts[(sector, etf)] = counts.get((sector, etf), 0) + 1

    out = []
    for (sector, etf), n in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0][0])):
        ind = sector_indicators.get(etf) or {}
        out.append({
            "sector": sector,
            "etf": etf,
            "stocks": n,
            "price": ind.get("reference_price"),
            # Reads `roc` directly rather than calling the local _chg_pct closure defined
            # inside compute_market_regime — a module-level helper cannot see it, and relying on
            # it here raised NameError on every regime computation.
            "chg_pct": ind.get("roc"),
            "trend_label": ind.get("trend_label"),
        })
    return out
