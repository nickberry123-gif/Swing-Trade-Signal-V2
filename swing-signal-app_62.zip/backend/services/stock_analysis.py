"""
Orchestration layer: ties bars_service + indicators + relative_strength + market_regime
together for one ticker (or the whole 50-stock universe), and persists results to
`technical_indicators`. Routers call this module; they never touch pandas or the provider
directly.
"""

from config import SECTOR_ETF_MAP, BROAD_MARKET_SYMBOLS
from services.bars_service import get_bars_df
from services.indicators import compute_all_indicators
from services.relative_strength import compute_relative_strength


def build_benchmark_cache(db, timeframe: str = "1Day") -> dict:
    """Fetch SPY/QQQ + every sector ETF actually used in SECTOR_ETF_MAP ONCE per request,
    rather than once per stock — these are shared across all 50 tickers."""
    cache = {}
    tickers = set(BROAD_MARKET_SYMBOLS) | set(SECTOR_ETF_MAP.values())
    for ticker in tickers:
        df, meta = get_bars_df(db, ticker, timeframe)
        cache[ticker] = {"close": df["close"] if not df.empty else None, "meta": meta}
    return cache


def analyze_stock(db, ticker: str, timeframe: str = "1Day", benchmark_cache: dict | None = None,
                   persist: bool = True) -> dict:
    df, bars_meta = get_bars_df(db, ticker, timeframe)

    if df.empty:
        return {
            "ticker": ticker, "timeframe": timeframe, "bars_used": 0,
            "warnings": ["No bar data available."],
            "data_status": "UNAVAILABLE", "data_error": bars_meta.get("error"),
        }

    indicators = compute_all_indicators(df)

    sector_etf = SECTOR_ETF_MAP.get(ticker)
    if benchmark_cache is None:
        benchmark_cache = build_benchmark_cache(db, timeframe)

    spy_close = (benchmark_cache.get("SPY") or {}).get("close")
    qqq_close = (benchmark_cache.get("QQQ") or {}).get("close")
    sector_close = (benchmark_cache.get(sector_etf) or {}).get("close") if sector_etf else None

    rs = compute_relative_strength(df["close"], {"spy": spy_close, "qqq": qqq_close, "sector": sector_close})

    result = {
        "ticker": ticker,
        "timeframe": timeframe,
        "sector_etf": sector_etf,
        "data_status": "OK" if bars_meta.get("source") == "alpaca" or not bars_meta.get("stale_fallback") else "STALE_CACHE",
        "data_error": bars_meta.get("error"),
        **indicators,
        "relative_strength": rs,
    }

    if persist:
        _persist(db, result)

    return result


def _persist(db, result: dict):
    ind = result
    rs = result.get("relative_strength", {})
    row = {
        "ticker": result["ticker"], "timeframe": result["timeframe"],
        "ts": result.get("last_bar_ts"),
        "ema20": ind.get("ema20"), "ema50": ind.get("ema50"),
        "sma20": ind.get("sma20"), "sma50": ind.get("sma50"),
        "sma100": ind.get("sma100"), "sma200": ind.get("sma200"),
        "sma200_slope": ind.get("sma200_slope"),
        "rsi14": ind.get("rsi14"), "rsi7": ind.get("rsi7"),
        "macd": ind.get("macd"), "macd_signal": ind.get("macd_signal"), "macd_hist": ind.get("macd_hist"),
        "adx": ind.get("adx"), "roc": ind.get("roc"), "stoch_rsi": ind.get("stoch_rsi"),
        "atr14": ind.get("atr14"), "atr_pct": ind.get("atr_pct"),
        "bb_upper": ind.get("bb_upper"), "bb_middle": ind.get("bb_middle"),
        "bb_lower": ind.get("bb_lower"), "bb_width": ind.get("bb_width"),
        "hist_volatility": ind.get("hist_volatility"),
        "volume": ind.get("volume"), "avg_volume_20d": ind.get("avg_volume_20d"),
        "relative_volume": ind.get("relative_volume"), "volume_trend": ind.get("volume_trend"),
        "swing_high": ind.get("swing_high"), "swing_low": ind.get("swing_low"),
        "high_20d": ind.get("high_20d"), "low_20d": ind.get("low_20d"),
        "high_50d": ind.get("high_50d"), "low_50d": ind.get("low_50d"),
        "high_52w": ind.get("high_52w"), "low_52w": ind.get("low_52w"),
        "support_low": ind.get("support_low"), "support_high": ind.get("support_high"),
        "resistance_low": ind.get("resistance_low"), "resistance_high": ind.get("resistance_high"),
        "trend_label": ind.get("trend_label"), "trend_reasons": ind.get("trend_reasons"),
        "sector_etf": result.get("sector_etf"),
        "rs_spy_5d": rs.get("rs_spy_5d"), "rs_spy_20d": rs.get("rs_spy_20d"),
        "rs_spy_50d": rs.get("rs_spy_50d"), "rs_spy_200d": rs.get("rs_spy_200d"),
        "rs_qqq_5d": rs.get("rs_qqq_5d"), "rs_qqq_20d": rs.get("rs_qqq_20d"),
        "rs_qqq_50d": rs.get("rs_qqq_50d"), "rs_qqq_200d": rs.get("rs_qqq_200d"),
        "rs_sector_5d": rs.get("rs_sector_5d"), "rs_sector_20d": rs.get("rs_sector_20d"),
        "rs_sector_50d": rs.get("rs_sector_50d"), "rs_sector_200d": rs.get("rs_sector_200d"),
        "bars_used": ind.get("bars_used"),
    }
    if not row["ts"]:
        return  # nothing meaningful to key a row on

    columns = list(row.keys())
    placeholders = ", ".join(f":{c}" for c in columns)
    update_clause = ", ".join(f"{c}=excluded.{c}" for c in columns if c not in ("ticker", "timeframe", "ts"))
    db.execute(
        f"""
        INSERT INTO technical_indicators ({", ".join(columns)})
        VALUES ({placeholders})
        ON CONFLICT(ticker, timeframe, ts) DO UPDATE SET {update_clause}
        """,
        row,
    )
    db.commit()
