"""
Study 2 — Future Fundamental Strength. Historical validation of the FROZEN C1 model.

    Did companies with higher C1 Company Health scores subsequently REMAIN fundamentally stronger
    businesses?

Not which companies improved most. That was Study 1, which measured forward CHANGES in quantities
C1 scores as LEVELS, built regression to the mean into its own outcome, and returned negative
correlations at all four dates. **Study 1 stands permanently as recorded.** Nothing here re-runs
it, re-cuts it, or explains it away, and this module cannot alter C1 either.

THE PROBLEM WITH FORWARD LEVELS, AND WHY THERE ARE THREE STATISTICS
===================================================================
Study 1's outcome was biased AGAINST the model. Forward levels are biased FOR it, and the second
error is the more dangerous one after the first: return on capital, margins and leverage are
strongly autocorrelated, so a company earning 35% on capital today will probably still be earning
well in three years. A correlation between today's score and a future LEVEL is therefore
substantially mechanical — it would appear even if C1 held no insight beyond reading today's income
statement. Publishing that number alone would produce a reassuring result that means very little.

So three statistics, always reported together, each answering a different question:

    A  PERSISTENCE        spearman(C1 score, forward level composite)
                          Does a higher score identify companies that REMAIN stronger? Directly
                          relevant to whether Company Health does its long-term monitoring job.
                          Inflated by autocorrelation, so it is never reported on its own.

    B  SIMPLE BENCHMARK   spearman(base level composite, forward level composite)
                          How much of A is obtainable from the five current fundamentals alone?

    C  INCREMENTAL VALUE  spearman(C1 score, forward composite residualised on the base composite)
                          Does C1's additional structure add anything BEYOND that benchmark?

Read together, and this reading is fixed in advance:

    high A + high B + C near zero   current financial strength is useful and persistent, but C1
                                    may be unnecessarily complex for what it delivers
    high A + materially positive C  encouraging evidence that C1 adds information beyond the
                                    simple benchmark
    low or negative A               concerning for C1's intended purpose, whatever C says
    negative C                      C1's extra structure may be making the simple information worse

No numerical threshold is defined for "high", "materially positive" or "concerning", and none may
be invented after seeing the values. The actual numbers are reported and interpreted cautiously.

C IS A DEMANDING TEST AND NEAR-ZERO IS ITS EXPECTED OUTCOME. The base composite overlaps heavily
with what C1 already measures, so residualising on it removes much of what C1 does. A C near zero
is not, on its own, a failure.
"""
from __future__ import annotations

from services import company_health as ch
from services import data_validation_service as dv
from services import fundamentals_history_service as fh
from services import health_backtest as hb

# =================================================================================================
# PRE-REGISTERED CONSTANTS
# =================================================================================================

#: THE SAME FOUR DATES AND THE SAME WINDOW AS STUDY 1 — imported rather than restated, so the two
#: studies cannot silently drift onto different footings.
SCORING_DATES = hb.SCORING_DATES
HISTORY_PERIODS = hb.HISTORY_PERIODS
FORWARD_YEARS = hb.FORWARD_YEARS
MIN_COMPANIES_PER_DATE = hb.MIN_COMPANIES_PER_DATE
MIN_GROUP_SIZE = hb.MIN_GROUP_SIZE
STRONG_GROUP = hb.STRONG_GROUP
WEAK_GROUP = hb.WEAK_GROUP
UNDERPOWERED = hb.UNDERPOWERED

#: LEVELS at the end of the window, not changes. Revenue is a rate because C1 scores growth as a
#: rate; the other four are the levels C1 scores as levels. `higher_is_better=False` marks leverage.
#: Equally weighted — weighting them unequally would mean choosing weights after Study 1, which is
#: exactly the fitting these rules exist to prevent.
FORWARD_LEVEL_MEASURES = (
    ("revenue_cagr_pct", True),
    ("roic_pct", True),
    ("operating_margin_pct", True),
    ("net_debt_to_ebitda", False),
    ("fcf_margin_pct", True),
)

#: The deterioration test borrows C1's OWN weak anchors rather than inventing thresholds. They were
#: fixed and approved before any company was scored, so no number here could have been chosen with
#: outcomes in view. Read out of the frozen model at import time: if C1 ever changed, this would
#: change with it rather than quietly disagreeing — and C1 cannot change.
def _weak_anchors() -> dict:
    out = {}
    for _weight, definitions in ch.COMPANY_HEALTH_MODEL.values():
        for name, direction, weak, _adequate, _strong in definitions:
            if name in dict(FORWARD_LEVEL_MEASURES):
                out[name] = (direction, weak)
    return out


WEAK_ANCHORS = _weak_anchors()

#: Mirrors C1's own capping rule — one weak area can be a strategy or a bad year, two at once is a
#: pattern. The structure is borrowed, not invented, for the same reason the anchors are.
WEAK_MEASURES_FOR_DETERIORATION = ch.CAP_AT_N_RED_FLAGS

#: A company measurable on fewer than this cannot be classified either way. Three of five is the
#: smallest whole number that satisfies C1's existing 50% category-coverage floor, so it is derived
#: from an approved rule rather than picked. Unclassifiable companies are reported, never assumed
#: healthy and never assumed weak.
MIN_MEASURES_TO_CLASSIFY = 3

#: A closing price more than this far from the target date is not that date's price. Secondary
#: analysis only.
MAX_PRICE_GAP_DAYS = 15


# =================================================================================================
# LEVELS
# =================================================================================================
def level_measures(db, ticker: str, as_of: str, cache=None) -> dict:
    """The five measures AS LEVELS at `as_of`, from filings available then.

    Used for both ends of the study: at the scoring date it is the base composite (the simple
    benchmark), and at the forward date it is the outcome. Identical definitions at both ends, so
    the comparison is like for like.
    """
    result = hb._validate_cached(db, ticker, as_of, cache)
    metrics = result.get("metrics") or {}
    out = {}
    for name, _higher in FORWARD_LEVEL_MEASURES:
        entry = metrics.get(name) or {}
        if entry.get("verdict") in dv.USABLE and entry.get("value") is not None:
            out[name] = entry["value"]
    return out


def is_fundamentally_weak(measures: dict):
    """(weak, triggered, assessed) — or (None, ...) when too little is measurable to say.

    Weak on a measure means at or beyond C1's own WEAK anchor for it. Weak overall means two or
    more, mirroring C1's capping rule. A company measurable on fewer than three of the five is not
    classified: calling it healthy would be an assumption and calling it weak would be worse.
    """
    triggered, assessed = [], 0
    for name, _higher in FORWARD_LEVEL_MEASURES:
        if name not in measures:
            continue
        assessed += 1
        direction, anchor = WEAK_ANCHORS[name]
        value = measures[name]
        if (value <= anchor) if direction == ch.HIGHER else (value >= anchor):
            triggered.append(name)
    if assessed < MIN_MEASURES_TO_CLASSIFY:
        return None, triggered, assessed
    return len(triggered) >= WEAK_MEASURES_FOR_DETERIORATION, triggered, assessed


def composite(rows: list, key: str) -> dict:
    """Within-date ranks of `rows[i][key]`, scaled 0-1, inverted where lower is better, averaged.

    Same construction as Study 1 so the two studies remain comparable in method even though they
    measure different things.
    """
    per_ticker = {}
    for name, higher_is_better in FORWARD_LEVEL_MEASURES:
        present = [r for r in rows if name in r[key]]
        if len(present) < 2:
            continue
        ranks = hb.rank_ascending([r[key][name] for r in present])
        n = len(present)
        for r, rank in zip(present, ranks):
            scaled = (rank - 1) / (n - 1) if n > 1 else 0.5
            per_ticker.setdefault(r["ticker"], []).append(
                scaled if higher_is_better else 1.0 - scaled)
    return {t: (sum(v) / len(v), len(v)) for t, v in per_ticker.items()}


def linear_residuals(xs: list, ys: list) -> list:
    """`ys` with the part explained by a straight line in `xs` removed.

    One least-squares fit, no parameter, nothing to sweep. This is what turns statistic A into
    statistic C: what remains of future fundamental strength once today's fundamentals have had
    their say.
    """
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    var = sum((x - mx) ** 2 for x in xs)
    slope = (sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / var) if var else 0.0
    intercept = my - slope * mx
    return [y - (intercept + slope * x) for x, y in zip(xs, ys)]


# =================================================================================================
# SECONDARY — RETURNS
# =================================================================================================
def _close_on_or_before(db, ticker: str, target: str):
    row = db.execute(
        "SELECT close, ts FROM market_bars WHERE ticker = ? AND timeframe = '1Day' AND ts <= ? "
        "ORDER BY ts DESC LIMIT 1", (ticker, target + "T23:59:59")).fetchone()
    if row is None:
        return None, None
    d = dict(row)
    gap = hb._iso_plus_years(str(d["ts"])[:10], 0)
    from datetime import date as _date
    try:
        days = (_date.fromisoformat(target) - _date.fromisoformat(gap)).days
    except ValueError:
        return None, None
    if days > MAX_PRICE_GAP_DAYS:
        return None, str(d["ts"])[:10]
    return d["close"], str(d["ts"])[:10]


def forward_return_pct(db, ticker: str, scoring_date: str, forward_date: str):
    start, start_ts = _close_on_or_before(db, ticker, scoring_date)
    end, end_ts = _close_on_or_before(db, ticker, forward_date)
    if not start or not end or start <= 0:
        return None, {"start_bar": start_ts, "end_bar": end_ts}
    return (end / start - 1.0) * 100.0, {"start_bar": start_ts, "end_bar": end_ts}


# =================================================================================================
# THE RUN
# =================================================================================================
def run_date(db, tickers, scoring_date: str, cache=None) -> dict:
    forward_date = hb._iso_plus_years(scoring_date, FORWARD_YEARS)
    scored, excluded = [], []

    for ticker in sorted(tickers):
        s = hb.score_at(db, ticker, scoring_date, cache)
        if s["score"] is None:
            excluded.append({"ticker": ticker, "reason": f"{s['verdict']} at the scoring date",
                             "coverage_pct": s["coverage_pct"]})
            continue
        base = level_measures(db, ticker, scoring_date, cache)
        fwd = level_measures(db, ticker, forward_date, cache)
        if not base or not fwd:
            excluded.append({"ticker": ticker,
                             "reason": "no measurable level at the scoring or forward date"})
            continue
        scored.append({"ticker": ticker, "score": s["score"], "verdict": s["verdict"],
                       "coverage_pct": s["coverage_pct"], "base": base, "forward": fwd})

    base_comp = composite(scored, "base")
    fwd_comp = composite(scored, "forward")
    paired = [r for r in scored if r["ticker"] in base_comp and r["ticker"] in fwd_comp]

    out = {
        "scoring_date": scoring_date, "forward_date": forward_date,
        "universe": len(tickers), "scored": len(scored), "analysed": len(paired),
        "excluded": excluded, "verdicts": {},
        "A_persistence": None, "B_simple_benchmark": None, "C_incremental_value": None,
        "group_comparison": None, "deterioration": None,
        "secondary_returns": None, "underpowered": [],
        "companies": [],
    }
    for r in scored:
        out["verdicts"][r["verdict"]] = out["verdicts"].get(r["verdict"], 0) + 1

    # ---- deterioration: transitions only ----
    not_weak_at_base, already_weak, unclassified = [], [], []
    for r in paired:
        base_weak, _t, _a = is_fundamentally_weak(r["base"])
        fwd_weak, triggered, _a2 = is_fundamentally_weak(r["forward"])
        if base_weak is None or fwd_weak is None:
            unclassified.append(r["ticker"])
            continue
        if base_weak:
            already_weak.append(r["ticker"])
            continue
        not_weak_at_base.append((r, fwd_weak, triggered))

    def _rate(group_names):
        members = [(r, w, t) for r, w, t in not_weak_at_base if r["verdict"] in group_names]
        if not members:
            return {"n": 0, "deteriorated": 0, "rate_pct": None, "tickers": []}
        bad = [r["ticker"] for r, w, _t in members if w]
        return {"n": len(members), "deteriorated": len(bad),
                "rate_pct": round(len(bad) / len(members) * 100, 1), "tickers": sorted(bad)}

    strong_rate, weak_rate = _rate(STRONG_GROUP), _rate(WEAK_GROUP)
    out["deterioration"] = {
        "definition": (f"at or beyond C1's own WEAK anchor on {WEAK_MEASURES_FOR_DETERIORATION} or "
                       f"more of the five measures; transitions only"),
        "already_weak_at_scoring_date": sorted(already_weak),
        "unclassified": sorted(unclassified),
        "eligible": len(not_weak_at_base),
        "strong_solid": strong_rate, "adequate_weak": weak_rate,
        "difference_pp": (round(strong_rate["rate_pct"] - weak_rate["rate_pct"], 1)
                          if strong_rate["rate_pct"] is not None
                          and weak_rate["rate_pct"] is not None else None),
        "underpowered": (strong_rate["n"] < MIN_GROUP_SIZE or weak_rate["n"] < MIN_GROUP_SIZE),
    }

    # ---- secondary: three-year total return ----
    returns = []
    for r in paired:
        value, bars = forward_return_pct(db, r["ticker"], scoring_date, forward_date)
        if value is not None:
            returns.append((r, value))
        r["_bars"] = bars
    if len(returns) >= MIN_COMPANIES_PER_DATE:
        out["secondary_returns"] = {
            "n": len(returns),
            "spearman_score_vs_return": hb.spearman([r["score"] for r, _v in returns],
                                                    [v for _r, v in returns]),
            "note": ("SECONDARY. A near-zero result is the expected outcome for a model containing "
                     "no valuation input, and is not a failure."),
        }
    else:
        out["secondary_returns"] = {
            "n": len(returns),
            "note": (f"{UNDERPOWERED}: {len(returns)} companies have usable bars at both ends, "
                     f"below the minimum of {MIN_COMPANIES_PER_DATE}. Stored bar history is "
                     f"roughly five years, so early dates are expected to be unavailable."),
        }

    out["companies"] = sorted(
        [{"ticker": r["ticker"], "score": r["score"], "verdict": r["verdict"],
          "base_composite": round(base_comp[r["ticker"]][0], 4),
          "forward_composite": round(fwd_comp[r["ticker"]][0], 4),
          "base_measures": len(r["base"]), "forward_measures": len(r["forward"])}
         for r in paired], key=lambda x: -x["score"])

    if len(paired) < MIN_COMPANIES_PER_DATE:
        out["underpowered"].append(
            f"{UNDERPOWERED}: {len(paired)} companies analysed, below the minimum of "
            f"{MIN_COMPANIES_PER_DATE}")
        return out

    scores = [r["score"] for r in paired]
    bases = [base_comp[r["ticker"]][0] for r in paired]
    forwards = [fwd_comp[r["ticker"]][0] for r in paired]

    out["A_persistence"] = hb.spearman(scores, forwards)
    out["B_simple_benchmark"] = hb.spearman(bases, forwards)
    out["C_incremental_value"] = hb.spearman(scores, linear_residuals(bases, forwards))

    strong = [f for r, f in zip(paired, forwards) if r["verdict"] in STRONG_GROUP]
    weak = [f for r, f in zip(paired, forwards) if r["verdict"] in WEAK_GROUP]
    if len(strong) >= MIN_GROUP_SIZE and len(weak) >= MIN_GROUP_SIZE:
        out["group_comparison"] = hb.mann_whitney_u(strong, weak)
    else:
        out["underpowered"].append(
            f"{UNDERPOWERED}: group comparison needs {MIN_GROUP_SIZE} in each group; "
            f"STRONG/SOLID has {len(strong)}, ADEQUATE/WEAK has {len(weak)}")
    return out


def run(db, tickers) -> dict:
    cache = {}
    return {
        "study": "Study 2 — Future Fundamental Strength",
        "methodology": {
            "scoring_dates": list(SCORING_DATES),
            "history_periods": HISTORY_PERIODS,
            "forward_years": FORWARD_YEARS,
            "forward_level_measures": [m for m, _d in FORWARD_LEVEL_MEASURES],
            "weak_anchors": {k: v[1] for k, v in sorted(WEAK_ANCHORS.items())},
            "weak_measures_required": WEAK_MEASURES_FOR_DETERIORATION,
            "min_companies_per_date": MIN_COMPANIES_PER_DATE,
            "min_group_size": MIN_GROUP_SIZE,
            "c1_model_frozen": True,
            "study_1_result_stands": True,
        },
        "dates": [run_date(db, tickers, d, cache) for d in SCORING_DATES],
        "interpretation": (
            "A, B and C answer different questions and are read together. A (persistence) asks "
            "whether a higher score identifies companies that REMAIN stronger — directly relevant "
            "to Company Health's monitoring purpose, and inflated by autocorrelation. B is how "
            "much of that is obtainable from the five current fundamentals alone. C is whether "
            "C1's additional structure adds anything beyond that benchmark, and is the primary "
            "measure of incremental model value. High A with high B and C near zero means current "
            "financial strength is useful and persistent but C1 may be unnecessarily complex. "
            "High A with materially positive C is encouraging. Low or negative A is concerning "
            "whatever C says. Negative C suggests the extra structure makes the simple information "
            "worse. No numerical threshold defines 'high' or 'concerning'; the actual values are "
            "reported and interpreted cautiously. This universe was selected in 2026 and nothing "
            "in it failed, so no result generalises beyond it, and no significance is claimed."),
    }
