"""
Five-year EPS growth that a stock split cannot corrupt.

THE PROBLEM, CONCRETELY. NVIDIA's FY2022 diluted EPS was printed as $3.85 in a 2024 filing and
its FY2026 EPS as $4.90 in a 2026 filing. Dividing one by the other gives about 5% a year. The
company's earnings per share actually grew enormously over that period; the 10-for-1 split in
between rewrote the earlier number's basis. And 5% a year is a perfectly ordinary-looking figure,
so nothing about the output says it is wrong.

That is the worst class of error this project has: not a number that screams, a number that
whispers. A dilution figure of 877% gets flagged by any sanity check. A growth rate of 5% gets
believed.

THE FIX, WHICH INFERS NOTHING. A single annual report states two or three consecutive years on
ONE share basis — whatever basis was in force when it was printed. Growth computed inside one
filing is therefore always correct, whatever splits happened before or after it.

So: compute a growth RATIO inside each filing, and chain overlapping filings end to end.

    2026 filing:  FY2024 -> FY2026     ratio r1   (one basis, whatever it is)
    2024 filing:  FY2022 -> FY2024     ratio r2   (a different basis, and it does not matter)

    five-year growth factor = r1 x r2

A ratio is dimensionless. Multiplying two ratios computed on two different share bases is valid
precisely because each is internally consistent — the basis cancels within each link and never
crosses between them. No split factor is ever inferred, looked up or guessed.

WHERE IT REFUSES. If two consecutive fiscal years never appear together in any single filing, the
chain has a hole and there is no honest way to bridge it. The answer is UNKNOWN. It is never
patched by comparing across filings, which is the very thing this module exists to prevent.

POINT-IN-TIME. Every function takes the as-of date and only ever sees filings published on or
before it, so a historical score cannot reach a filing that did not exist yet.
"""
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

# A link is only usable when both endpoints are positive. A ratio across a sign change is not a
# growth rate — going from a loss to a profit is a real event but "growth of -240%" describes
# nothing, and compounding it produces arithmetic that means even less.
MIN_USABLE = 0.0

# How far apart two fiscal period ends must be to count as consecutive years. Fiscal year ends
# drift by days, so this is a window rather than exactly 365.
MIN_YEAR_GAP_DAYS = 300
MAX_YEAR_GAP_DAYS = 430


def _v(x):
    try:
        return float(x) if x is not None else None
    except (TypeError, ValueError):
        return None


def _days(a: str, b: str):
    try:
        return abs((datetime.fromisoformat(a) - datetime.fromisoformat(b)).days)
    except (TypeError, ValueError):
        return None


def build_links(rows: list, field: str = "eps_diluted") -> dict:
    """Every within-filing year-on-year ratio available, keyed by (older_period, newer_period).

    `rows` is every stored (period, filing) record — NOT one row per period. The whole technique
    depends on seeing the same fiscal year as reported by more than one filing.

    Where several filings supply the same link, the LATEST-FILED one wins: it is the most recent
    statement of that pair and is still internally consistent, since both of its endpoints come
    from the same document. That is also what makes amended filings behave correctly — an
    amendment simply supersedes the original for the links it covers.
    """
    by_filing = {}
    for row in rows:
        filed, period_end = row.get("filed"), row.get("period_end")
        value = _v(row.get(field))
        if not filed or not period_end or value is None:
            continue
        # A duplicate (filing, period) can only differ by a restatement inside one filing, which
        # does not happen — but if it did, taking the last is deterministic rather than arbitrary.
        by_filing.setdefault(filed, {})[period_end] = value

    links = {}
    for filed, periods in by_filing.items():
        ends = sorted(periods)
        for older, newer in zip(ends, ends[1:]):
            gap = _days(older, newer)
            if gap is None or not (MIN_YEAR_GAP_DAYS <= gap <= MAX_YEAR_GAP_DAYS):
                continue                       # not consecutive years
            a, b = periods[older], periods[newer]
            if a <= MIN_USABLE or b <= MIN_USABLE:
                continue                       # a ratio across zero or a loss is not growth
            key = (older, newer)
            existing = links.get(key)
            if existing is None or filed > existing["filed"]:
                links[key] = {"ratio": b / a, "filed": filed, "from": a, "to": b}
    return links


def chain(rows: list, years: int = 5, field: str = "eps_diluted",
          as_of_filed: str | None = None) -> dict:
    """Compound growth over `years`, built from within-filing links only.

    Returns {value, years_covered, links_used, basis, reason}. `value` is the annualised
    percentage, or None with a reason that says exactly where the chain broke.
    """
    out = {"value": None, "years_covered": 0, "links_used": [], "basis": None, "reason": None}

    visible = [r for r in rows
               if not as_of_filed or (r.get("filed") or "") <= as_of_filed]
    if not visible:
        out["reason"] = ("no filings had been published by this date" if as_of_filed
                         else "no stored filings")
        return out

    links = build_links(visible, field=field)
    if not links:
        out["reason"] = (f"no single filing reports {field} for two consecutive years, so no "
                         f"growth link can be formed on one share basis — comparing across "
                         f"filings would let a stock split invent growth that did not happen")
        return out

    # Walk backwards from the newest period for which a link ends.
    periods = sorted({p for pair in links for p in pair})
    newest = periods[-1]

    factor, span_days, used = 1.0, 0, []
    cursor = newest
    while True:
        candidates = [(older, link) for (older, newer), link in links.items() if newer == cursor]
        if not candidates:
            break
        older, link = max(candidates, key=lambda c: c[1]["filed"])
        factor *= link["ratio"]
        gap = _days(older, cursor) or 365
        span_days += gap
        used.append({"from_period": older, "to_period": cursor,
                     "from_value": round(link["from"], 4), "to_value": round(link["to"], 4),
                     "ratio": round(link["ratio"], 6), "reported_in_filing": link["filed"]})
        cursor = older
        if span_days >= years * 365 - 45:
            break

    if not used:
        out["reason"] = "no usable link ends at the most recent period"
        return out

    span_years = span_days / 365.0
    out["links_used"] = list(reversed(used))
    out["years_covered"] = round(span_years, 2)
    out["basis"] = (f"chained from {len(used)} within-filing link(s); no comparison crosses a "
                    f"filing boundary, so a stock split cannot affect the result")

    if span_years < 1.0:
        out["reason"] = "less than one year of linked history"
        return out
    if factor <= 0:
        out["reason"] = "the chained growth factor is not positive, so no annual rate exists"
        return out

    # Reported honestly when the chain is shorter than requested: a three-year answer labelled
    # three years is useful, a three-year answer labelled five years is a lie about the evidence.
    if span_years < years - 0.5:
        out["reason"] = (f"only {span_years:.1f} years of unbroken links are available; the "
                         f"{years}-year figure would require a link that no single filing "
                         f"provides")

    out["value"] = (factor ** (1.0 / span_years) - 1.0) * 100.0
    return out
