"""
Thin service layer between Flask routes and the MarketDataProvider.

This is the ONLY place that constructs a concrete provider — routes and any future
signal-engine code call get_provider() and only ever see the MarketDataProvider
interface, never AlpacaProvider directly. Swapping providers later means changing
this one function.

A small in-memory TTL cache avoids hammering Alpaca's rate limits when the dashboard
polls repeatedly; it never invents data — every cached Snapshot still carries its real
fetched_at/data_status, and cache entries are simply skipped once older than TTL.
"""
import threading
import time

from config import Config
from providers import AlpacaProvider, MarketDataProvider, Snapshot, MarketStatus, ProviderError

_lock = threading.Lock()
_provider: MarketDataProvider | None = None

_snapshot_cache: dict[str, tuple[float, Snapshot]] = {}
_clock_cache: tuple[float, MarketStatus] | None = None
SNAPSHOT_CACHE_TTL_SECONDS = 15
CLOCK_CACHE_TTL_SECONDS = 15


def get_provider() -> MarketDataProvider:
    global _provider
    if _provider is None:
        with _lock:
            if _provider is None:
                _provider = AlpacaProvider(
                    api_key=Config.ALPACA_API_KEY,
                    secret_key=Config.ALPACA_SECRET_KEY,
                    trading_base_url=Config.ALPACA_TRADING_BASE_URL,
                    data_base_url=Config.ALPACA_DATA_BASE_URL,
                )
    return _provider


def get_market_clock_cached() -> MarketStatus:
    global _clock_cache
    now = time.monotonic()
    if _clock_cache is not None and (now - _clock_cache[0]) < CLOCK_CACHE_TTL_SECONDS:
        return _clock_cache[1]
    status = get_provider().get_market_clock()
    _clock_cache = (now, status)
    return status


def get_snapshots_cached(tickers: list[str]) -> dict[str, Snapshot]:
    """Fetch snapshots for tickers, using per-ticker cache entries younger than TTL and
    batching a single Alpaca call for everything else."""
    now = time.monotonic()
    fresh: dict[str, Snapshot] = {}
    missing: list[str] = []
    for t in tickers:
        entry = _snapshot_cache.get(t)
        if entry and (now - entry[0]) < SNAPSHOT_CACHE_TTL_SECONDS:
            fresh[t] = entry[1]
        else:
            missing.append(t)

    if missing:
        provider = get_provider()
        result = provider.get_snapshots(missing)
        for t, snap in result.items():
            _snapshot_cache[t] = (now, snap)
            fresh[t] = snap

    return fresh
