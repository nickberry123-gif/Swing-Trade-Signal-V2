"""
Corporate actions, quarterly share bases, and equity the share count does not cover.

THREE SEPARATE DEFECTS, KEPT SEPARATE ON PURPOSE. They arrived together through one company and
are easy to conflate, which would produce a fix that appears to work for the wrong reason:

  1. STALE BASIS — a share count from a filing this app should have superseded. Regeneron: a 2012
     cover page against a 2026 price. Solved by the freshness rule in share_basis.py.
  2. CORPORATE ACTION — a share count that is recent and still on the wrong basis, because the
     shares themselves changed after it was filed. Carvana split five-for-one on 5 May 2026, three
     months after the 10-K its basis came from. $9.2bn against a real $104bn, with nothing stale
     about it.
  3. ECONOMIC EQUITY — a share count that is current, correct, and still describes only part of
     the company, because equity is held in units outside the listed shares. Carvana again, and
     not fixed by fixing the split.

THE FIX FOR (2) COMPUTES NO SPLIT FACTOR AND THESE TESTS PROVE IT. A weighted-average share count
published after a split is already post-split, because the company restated it. So the repair is
to read a later filing, not to work out a multiplier. That matters because the multiplier cannot
be obtained safely: SEC's own `StockholdersEquityNoteStockSplitConversionRatio1` is 0.2 for
Carvana's five-for-one and 10 for NVIDIA's ten-for-one, so the same event is recorded as a number
and as its reciprocal by different filers, and applying it the wrong way round is wrong by its
square.
"""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
from config import STOCK_UNIVERSE  # noqa: E402
from providers.edgar_concepts import HISTORY_VALUE_FIELDS  # noqa: E402
from providers.fundamentals_base import AnnualPeriod  # noqa: E402
from providers.sec_edgar_provider import SecEdgarProvider  # noqa: E402
from services import data_validation_service as dv  # noqa: E402
from services import fundamentals_history_service as fh  # noqa: E402
from services import share_basis as sb  # noqa: E402

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"
TODAY = date.today()


def ago(days: int) -> str:
    return (TODAY - timedelta(days=days)).isoformat()


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]))
    conn.commit()
    return conn


def period(period_end, filed, ticker="CVNA", **values):
    full = {f: None for f in HISTORY_VALUE_FIELDS}
    full.update(values)
    return AnnualPeriod(ticker=ticker, source="test", period_end=period_end, filed=filed,
                        taxonomy="us-gaap", currency="USD", form="10-K", values=full)


def store(db, ticker, periods):
    for p in periods:
        p.ticker = ticker
    fh.store_history(db, ticker, periods)


# =================================================================================================
# PARSING THE QUARTERLY FACTS THAT WERE ALREADY BEING DOWNLOADED
# =================================================================================================
class QuarterlySharePeriodsAreParsed(unittest.TestCase):
    """These facts sat in every payload this app downloaded and were discarded, because the annual
    parser keeps only ~365-day durations."""

    PAYLOAD = {"facts": {"us-gaap": {
        "Revenues": {"units": {"USD": [
            {"start": "2025-01-01", "end": "2025-12-31", "val": 20322e6, "form": "10-K",
             "filed": "2026-02-18"}]}},
        "WeightedAverageNumberOfSharesOutstandingBasic": {"units": {"shares": [
            # The annual figure, pre-split.
            {"start": "2025-01-01", "end": "2025-12-31", "val": 137634000, "form": "10-K",
             "filed": "2026-02-18"},
            # The quarter filed after the split — already restated by the company.
            {"start": "2026-04-01", "end": "2026-06-30", "val": 717691000, "form": "10-Q",
             "filed": "2026-07-29"},
            # A cumulative year-to-date figure ending the same day, from the same filing.
            {"start": "2026-01-01", "end": "2026-06-30", "val": 715728000, "form": "10-Q",
             "filed": "2026-07-29"},
        ]}},
    }}}

    def test_quarterly_periods_are_read(self):
        rows = SecEdgarProvider.parse_share_periods(self.PAYLOAD)
        self.assertTrue(any(r["basic_shares"] == 717691000 for r in rows))

    def test_the_newest_filing_comes_first(self):
        rows = SecEdgarProvider.parse_share_periods(self.PAYLOAD)
        self.assertEqual(rows[0]["filed"], "2026-07-29")

    def test_a_discrete_quarter_is_preferred_to_a_year_to_date_figure(self):
        """Both end on 30 June and both come from the same filing. The quarter averages over less
        time, so it sits closer to the count on the day."""
        rows = SecEdgarProvider.parse_share_periods(self.PAYLOAD)
        self.assertEqual(rows[0]["basic_shares"], 717691000)
        self.assertEqual(rows[0]["days"], 90)

    def test_no_split_factor_is_computed_anywhere(self):
        """The two figures differ by almost exactly five. This app must never notice that."""
        rows = SecEdgarProvider.parse_share_periods(self.PAYLOAD)
        values = {r["basic_shares"] for r in rows}
        self.assertIn(137634000, values)
        self.assertIn(717691000, values)
        for row in rows:
            self.assertNotIn("ratio", row)
            self.assertNotIn("split_factor", row)

    def test_the_annual_history_is_not_polluted_by_quarterly_figures(self):
        """Company Health is computed from fiscal years. A quarter must never enter that table."""
        annual = SecEdgarProvider().parse_history("CVNA", self.PAYLOAD)
        for record in annual:
            self.assertNotIn("2026-06-30", record.period_end)


# =================================================================================================
# THE SPLIT, END TO END
# =================================================================================================
class ASplitAfterTheFilingIsSurvived(unittest.TestCase):

    def _carvana_shaped(self, with_quarter=True):
        db = make_db()
        store(db, "CVNA", [period(ago(230), ago(181), ticker="CVNA", revenue=20322e6,
                                  net_income=1407e6, operating_income=1800e6, eps_diluted=8.45,
                                  eps_basic=10.22, basic_shares=137634000,
                                  diluted_shares=224277000, total_assets=15000e6,
                                  stockholders_equity=2000e6, operating_cash_flow=1800e6,
                                  capex=200e6)])
        if with_quarter:
            fh.store_share_periods(db, "CVNA", [
                {"period_start": ago(140), "period_end": ago(49), "days": 91,
                 "filed": ago(20), "form": "10-Q", "basic_shares": 717691000,
                 "diluted_shares": None}])
        return db

    def test_the_post_action_quarterly_count_is_selected(self):
        out = dv.validate_ticker(self._carvana_shaped(), "CVNA", price=65.05)
        self.assertEqual(out["share_basis_detail"]["candidates"][0]["shares"], 717691000)

    def test_the_pre_split_annual_count_is_not_what_gets_used(self):
        out = dv.validate_ticker(self._carvana_shaped(), "CVNA", price=65.05)
        self.assertNotEqual(out["share_count"], 137634000)

    def test_without_the_quarterly_figure_the_old_wrong_answer_returns(self):
        """The control. If this passed either way the test above would prove nothing."""
        out = dv.validate_ticker(self._carvana_shaped(with_quarter=False), "CVNA", price=65.05)
        self.assertEqual(out["share_basis_detail"]["candidates"][0]["shares"], 137634000)


class SplitDetectionFromStoredCounts(unittest.TestCase):
    """Booking's split is already visible in this app's own database and was never read."""

    BOOKING = [
        {"as_of": "2026-07-27", "filed": "2026-08-04", "form": "10-Q", "shares": 751380500.0},
        {"as_of": "2026-04-20", "filed": "2026-04-28", "form": "10-Q", "shares": 774878436.0},
        {"as_of": "2026-02-10", "filed": "2026-02-18", "form": "10-K", "shares": 31673346.0},
        {"as_of": "2025-10-20", "filed": "2025-10-28", "form": "10-Q", "shares": 32233815.0},
    ]

    def test_the_discontinuity_is_detected(self):
        action = sb.detect_split_like_action(self.BOOKING)
        self.assertIsNotNone(action)
        self.assertEqual(action["between"], ["2026-02-18", "2026-04-28"])
        self.assertEqual(action["direction"], "forward")

    def test_a_reverse_split_is_detected_and_named_correctly(self):
        """Direction is MEASURED from which way the count moved, never inferred from a published
        ratio — the orientation of that ratio is not consistent between filers."""
        action = sb.detect_split_like_action([
            {"filed": "2026-05-01", "shares": 10_000_000.0},
            {"filed": "2026-02-01", "shares": 100_000_000.0}])
        self.assertEqual(action["direction"], "reverse")

    def test_an_ordinary_buyback_is_not_mistaken_for_an_action(self):
        self.assertIsNone(sb.detect_split_like_action([
            {"filed": "2026-08-06", "shares": 253_035_047.0},
            {"filed": "2026-05-07", "shares": 255_640_360.0},
            {"filed": "2026-03-02", "shares": 256_975_993.0}]))

    def test_a_basis_filed_before_the_action_is_refused(self):
        out = sb.resolve(
            cover_count={"shares": 31_673_346, "filed": "2026-02-18", "form": "10-K"},
            latest_row={"filed": "2026-02-18"},
            filed_dates=["2026-04-28", "2026-02-18"],
            reference_date="2026-08-18",
            corporate_action=sb.detect_split_like_action(self.BOOKING))
        self.assertEqual(out["provenance"], sb.UNKNOWN)
        self.assertIn("before a corporate action", out["rejected"][0]["why"])

    def test_a_basis_filed_after_the_action_is_accepted(self):
        out = sb.resolve(
            cover_count={"shares": 751_380_500, "filed": "2026-08-04", "form": "10-Q"},
            latest_row={"filed": "2026-02-18"},
            filed_dates=["2026-08-04", "2026-04-28"],
            reference_date="2026-08-18",
            corporate_action=sb.detect_split_like_action(self.BOOKING))
        self.assertEqual(out["provenance"], sb.ACTUAL)
        self.assertEqual(out["shares"], 751_380_500)

    def test_no_correction_factor_is_ever_produced(self):
        action = sb.detect_split_like_action(self.BOOKING)
        self.assertNotIn("apply", action)
        self.assertNotIn("factor", action)
        # The ratio is recorded so a person can see what was found. Nothing multiplies by it.
        self.assertIn("ratio", action)

    def test_a_future_action_cannot_affect_a_historical_calculation(self):
        """Look-ahead: scoring March 2026 must not be disturbed by a split that happens in May."""
        out = sb.resolve(
            cover_count={"shares": 31_673_346, "filed": "2026-02-18", "form": "10-K"},
            latest_row={"filed": "2026-02-18"},
            filed_dates=["2026-02-18"],
            reference_date="2026-03-01",
            corporate_action={"effective_date": "2026-05-05", "direction": "forward",
                              "source": "test", "detail": "a split in the future"})
        self.assertEqual(out["provenance"], sb.ACTUAL)


# =================================================================================================
# EQUITY THE SHARE COUNT DOES NOT COVER
# =================================================================================================
class EconomicEquityMustBeWholeOrUnknown(unittest.TestCase):
    """Fixing the split does not make Carvana's valuation right, and saying so is the point."""

    def test_a_large_dilution_gap_with_a_minority_interest_gives_unknown(self):
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(190), "basic_shares": 137634000,
                        "diluted_shares": 224277000, "minority_interest": 762e6},
            filed_dates=[ago(190), ago(555)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.UNKNOWN)
        self.assertIsNone(out["shares"])
        self.assertIsNotNone(out["economic_equity"])
        self.assertGreater(out["economic_equity"]["dilution_gap_pct"], 60)

    def test_an_ordinary_company_with_a_minority_interest_is_not_blocked(self):
        """HCA carries a $3.3bn noncontrolling interest and 236,413,000 basic against 239,495,000
        diluted — a 1.3% gap. It is an ordinary company and must keep its valuation. A rule that
        fired on a noncontrolling interest alone would take it away."""
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(190), "shares_outstanding": 236413000,
                        "basic_shares": 236413000, "diluted_shares": 239495000,
                        "minority_interest": 3256e6},
            filed_dates=[ago(190), ago(555)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.ACTUAL_ANNUAL)
        self.assertIsNone(out["economic_equity"])

    def test_a_dilution_gap_without_a_minority_interest_is_not_blocked(self):
        """An option overhang is not equity held outside the listed shares. Both conditions are
        required precisely so ordinary dilution does not withhold a valuation."""
        out = sb.resolve(
            cover_count=None,
            latest_row={"filed": ago(190), "shares_outstanding": 100e6, "basic_shares": 100e6,
                        "diluted_shares": 160e6},
            filed_dates=[ago(190), ago(555)], reference_date=ago(0))
        self.assertEqual(out["provenance"], sb.ACTUAL_ANNUAL)

    def test_the_two_counts_must_come_from_the_same_filing(self):
        """Comparing a post-split quarterly basic count against a pre-split annual diluted one
        gives a negative gap and a reassuring pass — exactly where the check is most needed."""
        result = sb.economic_equity_incomplete(
            {"basic_shares": 137634000, "diluted_shares": 224277000, "minority_interest": 762e6},
            {"basic_shares": 717691000, "diluted_shares": None})
        self.assertIsNotNone(result)
        self.assertEqual(result["basic_shares"], 137634000)

    def test_the_whole_valuation_block_is_withheld_not_merely_labelled(self):
        db = make_db()
        store(db, "CVNA", [period(ago(230), ago(190), ticker="CVNA", revenue=20322e6,
                                  net_income=1407e6, operating_income=1800e6, eps_diluted=8.45,
                                  basic_shares=137634000, diluted_shares=224277000,
                                  minority_interest=762e6, total_assets=15000e6,
                                  stockholders_equity=2000e6, operating_cash_flow=1800e6,
                                  capex=200e6, total_debt=6000e6, total_cash=1000e6,
                                  depreciation_amortisation=300e6)])
        out = dv.validate_ticker(db, "CVNA", price=65.05)
        self.assertEqual(out["share_basis_provenance"], sb.UNKNOWN)
        for name in dv.MARKET_CAP_DEPENDENT:
            self.assertEqual(out["metrics"][name]["verdict"], dv.UNAVAILABLE, name)

    def test_company_health_survives_an_unknown_economic_equity(self):
        """The reason for keeping these separate. Margins and returns are unaffected by a question
        about who owns the equity."""
        db = make_db()
        store(db, "CVNA", [period(ago(230), ago(190), ticker="CVNA", revenue=20322e6,
                                  gross_profit=4000e6, net_income=1407e6, operating_income=1800e6,
                                  basic_shares=137634000, diluted_shares=224277000,
                                  minority_interest=762e6, total_assets=15000e6,
                                  stockholders_equity=2000e6, operating_cash_flow=1800e6,
                                  capex=200e6)])
        out = dv.validate_ticker(db, "CVNA", price=65.05)
        for name in ("gross_margin_pct", "operating_margin_pct", "net_margin_pct", "roe_pct"):
            self.assertNotEqual(out["metrics"][name]["verdict"], dv.UNAVAILABLE, name)


# =================================================================================================
# COHERENCE THAT A CHANGE OF SELECTION CANNOT SILENCE
# =================================================================================================
class CoherenceCoversEveryCandidate(unittest.TestCase):
    """The regression that prompted this: moving the selected basis from diluted to basic pulled
    the two price/earnings routes from 25.8% apart to 20.8% apart, under the threshold, and the
    warning vanished while both bases stayed pre-split and wrong."""

    def _two_bases(self):
        db = make_db()
        store(db, "CVNA", [period(ago(230), ago(181), ticker="CVNA", revenue=20322e6,
                                  net_income=1407e6, operating_income=1800e6, eps_diluted=8.45,
                                  basic_shares=137634000, diluted_shares=224277000,
                                  total_assets=15000e6, stockholders_equity=2000e6)])
        fh.store_share_periods(db, "CVNA", [
            {"period_start": ago(140), "period_end": ago(49), "days": 91, "filed": ago(20),
             "form": "10-Q", "basic_shares": 717691000, "diluted_shares": None}])
        return db

    def test_a_disagreeing_candidate_raises_a_warning_even_when_not_selected(self):
        out = dv.validate_ticker(self._two_bases(), "CVNA", price=65.05)
        self.assertIn("candidate_basis_disagreement", [a["check"] for a in out["anomalies"]])

    def test_the_warning_names_the_candidate_and_its_filing(self):
        out = dv.validate_ticker(self._two_bases(), "CVNA", price=65.05)
        anomaly = next(a for a in out["anomalies"]
                       if a["check"] == "candidate_basis_disagreement")
        # The WORST-disagreeing candidate is named, which here is the pre-split diluted count
        # rather than the pre-split basic one. Either identifies the same problem; what matters is
        # that a candidate from the pre-split filing is named, with its filing date.
        self.assertTrue(any(v in anomaly["detail"] for v in ("137,634,000", "224,277,000")),
                        anomaly["detail"])
        self.assertIn(ago(181), anomaly["detail"])

    def test_it_stays_a_warning_and_removes_no_metric(self):
        """The instruction is explicit: the threshold is not tuned and the mismatch does not gate.
        On the evidence it is right one time in three — BKNG and CELH both fire it while being
        entirely correct."""
        out = dv.validate_ticker(self._two_bases(), "CVNA", price=65.05)
        for anomaly in out["anomalies"]:
            self.assertEqual(anomaly["severity"], "WARNING")
        self.assertEqual(dv.PE_ROUTE_DISAGREEMENT_WARN, 0.25)

    def test_candidate_agreement_is_never_reported_as_confirmation(self):
        """Every candidate comes from the same filings and they all move together under a split,
        so agreeing with each other proves only internal consistency. Booking's P/E of 1.20 was
        published because a count and an EPS from one stale filing agreed."""
        db = make_db()
        store(db, "AAPL", [period(ago(230), ago(190), ticker="AAPL", revenue=400e9,
                                  net_income=100e9, eps_diluted=6.5, basic_shares=15.2e9,
                                  diluted_shares=15.4e9, shares_outstanding=15.0e9,
                                  total_assets=365e9, stockholders_equity=57e9)])
        out = dv.validate_ticker(db, "AAPL", price=230.0)
        self.assertNotIn("candidate_basis_disagreement", [a["check"] for a in out["anomalies"]])
        blob = " ".join(out["notes"]) + str(out["share_basis_detail"])
        for phrase in ("basis confirmed", "corroborat", "verified against"):
            self.assertNotIn(phrase, blob.lower())


class TheSplitRatioTagIsNeverUsedAsArithmetic(unittest.TestCase):
    """SEC publishes a split ratio and it cannot be trusted for arithmetic: Carvana records its
    five-for-one as 0.2 and NVIDIA records its ten-for-one as 10. The same kind of event, as a
    number and as its reciprocal. Applying it the wrong way round is wrong by its square."""

    def test_the_tag_is_not_in_any_concept_chain(self):
        from providers.edgar_concepts import CONCEPTS
        for concept, namespaces in CONCEPTS.items():
            for tags in namespaces.values():
                for tag in tags:
                    self.assertNotIn("SplitConversionRatio", tag,
                                     f"{concept} reads a split ratio — it must not")

    def test_no_module_reads_the_ratio_in_executable_code(self):
        """The tag is discussed at length in comments — that is the point, it records WHY it is
        not used. This test therefore has to distinguish prose from code, or it would fail on its
        own explanation.
        """
        import ast

        for path in (Path(__file__).resolve().parent.parent / "services" / "share_basis.py",
                     Path(__file__).resolve().parent.parent / "providers" / "edgar_concepts.py",
                     Path(__file__).resolve().parent.parent / "providers" /
                     "sec_edgar_provider.py"):
            tree = ast.parse(path.read_text())
            docstrings = set()
            for node in ast.walk(tree):
                if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                                     ast.AsyncFunctionDef)):
                    doc = ast.get_docstring(node, clean=False)
                    if doc:
                        docstrings.add(doc)
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant) and isinstance(node.value, str):
                    if node.value in docstrings:
                        continue
                    self.assertNotIn("SplitConversionRatio", node.value,
                                     f"{path.name} reads the split-ratio tag in code")
                if isinstance(node, ast.Attribute):
                    self.assertNotIn("SplitConversionRatio", node.attr)


if __name__ == "__main__":
    unittest.main()


class HistoricalValuationIsBlocked(unittest.TestCase):
    """Recorded as a guard rather than as a comment, so no backtest can quietly consume it.

    Stored bars are split- AND dividend-adjusted, which means a bar from 2020 is expressed in
    today's share basis rather than the one in force in 2020. Multiplying it by an as-reported
    2020 share count is wrong by every corporate action since; correcting the count with a factor
    would be look-ahead. There is no combination of the two that is right, so the answer is
    withheld until raw unadjusted bars exist.
    """

    def _historical(self):
        db = make_db()
        store(db, "AAPL", [period("2019-12-31", "2020-02-10", ticker="AAPL", revenue=260e9,
                                  net_income=55e9, shares_outstanding=4.4e9, eps_diluted=11.89,
                                  total_assets=338e9, stockholders_equity=90e9)])
        return dv.validate_ticker(db, "AAPL", price=75.0, as_of_filed="2020-04-01")

    def test_market_cap_dependent_metrics_are_withheld_for_a_past_date(self):
        out = self._historical()
        self.assertTrue(out["historical_valuation_blocked"])
        for name in dv.MARKET_CAP_DEPENDENT:
            self.assertEqual(out["metrics"][name]["verdict"], dv.UNAVAILABLE, name)

    def test_the_reason_names_the_price_basis_not_the_share_count(self):
        """The share count is fine. The price series is the problem, and saying otherwise would
        send the next person looking in the wrong place."""
        reason = self._historical()["metrics"]["market_cap"]["reason"]
        self.assertIn("historical", reason.lower())

    def test_a_present_day_calculation_is_unaffected(self):
        """The block must be exactly as narrow as the problem."""
        db = make_db()
        store(db, "AAPL", [period(ago(230), ago(190), ticker="AAPL", revenue=400e9,
                                  net_income=100e9, shares_outstanding=15e9, eps_diluted=6.5,
                                  total_assets=365e9, stockholders_equity=57e9)])
        out = dv.validate_ticker(db, "AAPL", price=230.0)
        self.assertNotIn("historical_valuation_blocked", out)
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.OK)

    def test_company_health_is_untouched_by_the_historical_block(self):
        """A DIFFERENTIAL, not a threshold. This fixture is deliberately sparse, so its absolute
        coverage is low either way and asserting a number would only measure the fixture. What
        matters is that blocking historical VALUATION costs Company Health nothing — the same
        company, scored at a past date and at today's, must reach the same coverage.
        """
        db = make_db()
        rows = [period("2019-12-31", "2020-02-10", ticker="AAPL", revenue=260e9,
                       gross_profit=98e9, operating_income=63e9, net_income=55e9,
                       shares_outstanding=4.4e9, eps_diluted=11.89, total_assets=338e9,
                       current_assets=162e9, current_liabilities=105e9, stockholders_equity=90e9,
                       operating_cash_flow=69e9, capex=10e9, total_debt=108e9, total_cash=48e9,
                       depreciation_amortisation=12e9, interest_expense=3e9)]
        for r in rows:
            r.ticker = "AAPL"
        fh.store_history(db, "AAPL", rows)

        past = dv.validate_ticker(db, "AAPL", price=75.0, as_of_filed="2020-04-01")
        # The same fixture with no as-of date is not a historical calculation, so nothing is
        # blocked — but its filing is now years old, so the share basis is separately UNKNOWN.
        # Company Health does not depend on either, which is the whole point.
        present = dv.validate_ticker(db, "AAPL", price=75.0)
        self.assertTrue(past["historical_valuation_blocked"])
        self.assertEqual(past["company_health_coverage_pct"],
                         present["company_health_coverage_pct"])
        for name in ("gross_margin_pct", "operating_margin_pct", "net_margin_pct", "roe_pct",
                     "current_ratio", "interest_coverage"):
            self.assertNotEqual(past["metrics"][name]["verdict"], dv.UNAVAILABLE, name)
