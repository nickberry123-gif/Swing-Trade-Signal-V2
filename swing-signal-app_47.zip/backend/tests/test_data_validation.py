"""
Build B2 — the plausibility gate, the coverage arithmetic, and the currency refusal.

THE POINT OF THIS FILE. Every disaster this project has had was a populated field producing an
impossible number: unadjusted prices, the fundamentals mix-up, the +88,446% return. All three had
passing tests and non-null data. So these tests are not "does the metric compute" — they are
"does the app notice when the metric could not possibly be true", which is a different question
and the one that has actually mattered.

The bounds are wide on purpose and the tests say so: a P/E of 300 must PASS, because that is a
real stock and not a bug. A gross margin of 4,000% must FAIL, because that is arithmetic going
wrong. A test that flagged both would be a test that taught us to ignore the flag.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
from config import STOCK_UNIVERSE  # noqa: E402
from providers.edgar_concepts import HISTORY_VALUE_FIELDS  # noqa: E402
from providers.fundamentals_base import AnnualPeriod  # noqa: E402
from services import data_validation_service as dv  # noqa: E402
from services import fundamentals_history_service as fh  # noqa: E402

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


def make_db():
    conn = database.connect(None, ":memory:")
    conn.executescript(SCHEMA_PATH.read_text())
    for s in STOCK_UNIVERSE:
        conn.execute(
            "INSERT INTO stocks (ticker, name, sector, industry, exchange) VALUES (?, ?, ?, ?, ?)",
            (s["ticker"], s["name"], s["sector"], s["industry"], s["exchange"]))
    conn.commit()
    return conn


def period(period_end, filed, currency="USD", **values):
    full = {f: None for f in HISTORY_VALUE_FIELDS}
    full.update(values)
    return AnnualPeriod(ticker="AAPL", source="test", period_end=period_end, filed=filed,
                        taxonomy="us-gaap", currency=currency, form="10-K", values=full)


def healthy_year(end, filed, scale=1.0, currency="USD"):
    """A plausible large-cap year. Deliberately modelled on real proportions so the tests are
    exercising ordinary values rather than round numbers that hide sign and scale errors."""
    return period(
        end, filed, currency=currency,
        revenue=400e9 * scale, gross_profit=184e9 * scale, operating_income=123e9 * scale,
        net_income=100e9 * scale, rnd_expense=31e9 * scale, interest_expense=3.9e9 * scale,
        depreciation_amortisation=11e9 * scale, eps_diluted=6.5 * scale,
        diluted_shares=15.4e9, shares_outstanding=15.0e9,
        operating_cash_flow=118e9 * scale, capex=11e9 * scale, buybacks=90e9 * scale,
        dividends_paid=15e9 * scale, acquisitions=1e9 * scale,
        total_assets=365e9, current_assets=153e9, current_liabilities=176e9,
        total_liabilities=308e9, total_cash=30e9, stockholders_equity=57e9, total_debt=95e9)


def store(db, ticker, periods):
    for p in periods:
        p.ticker = ticker
    fh.store_history(db, ticker, periods)


class PlausibilityBounds(unittest.TestCase):
    """The could-this-be-true-in-the-real-world question, encoded."""

    def test_a_high_but_real_pe_passes(self):
        """A P/E of 300 is a real stock, not a bug. Flagging it would train us to ignore flags."""
        db = make_db()
        store(db, "AAPL", [healthy_year("2024-12-31", "2025-02-01")])
        out = dv.validate_ticker(db, "AAPL", price=1950.0)   # 1950 / 6.5 = 300
        self.assertEqual(out["metrics"]["pe_ratio"]["verdict"], dv.OK)
        self.assertAlmostEqual(out["metrics"]["pe_ratio"]["value"], 300.0, places=2)

    def test_an_impossible_gross_margin_is_flagged_not_displayed(self):
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=1e9, gross_profit=40e9)])
        out = dv.validate_ticker(db, "AAPL", price=100.0)
        gm = out["metrics"]["gross_margin_pct"]
        self.assertEqual(gm["verdict"], dv.IMPLAUSIBLE)
        self.assertEqual(gm["value"], 4000.0)          # the actual number is quoted, not hidden
        self.assertIn("gross_margin_pct", out["implausible"])

    def test_a_ninety_two_percent_gross_margin_passes(self):
        """NVIDIA territory. The bound separates impossible from unusual, not good from bad."""
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=100e9, gross_profit=92e9)])
        out = dv.validate_ticker(db, "AAPL", price=100.0)
        self.assertEqual(out["metrics"]["gross_margin_pct"]["verdict"], dv.OK)

    def test_an_absurd_market_cap_is_flagged(self):
        """The failure mode this catches: a share count read out of the wrong unit block turns
        15.4 billion shares into a figure that values one company above world GDP."""
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=1e9,
                                  shares_outstanding=15.4e15)])
        out = dv.validate_ticker(db, "AAPL", price=230.0)
        self.assertEqual(out["metrics"]["market_cap"]["verdict"], dv.IMPLAUSIBLE)

    def test_a_real_market_cap_passes_and_is_the_right_size(self):
        db = make_db()
        store(db, "AAPL", [healthy_year("2024-12-31", "2025-02-01")])
        out = dv.validate_ticker(db, "AAPL", price=230.0)
        cap = out["metrics"]["market_cap"]
        self.assertEqual(cap["verdict"], dv.OK)
        self.assertAlmostEqual(cap["value"] / 1e12, 3.45, places=2)   # 15.0bn shares x $230

    def test_a_negative_eps_gives_no_pe_rather_than_a_negative_one(self):
        """A negative P/E is not a cheap stock; it is a meaningless ratio. It must be withheld
        with the reason, not printed as a small number that sorts to the top of a list."""
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=1e9, eps_diluted=-2.0)])
        pe = dv.validate_ticker(db, "AAPL", price=100.0)["metrics"]["pe_ratio"]
        self.assertEqual(pe["verdict"], dv.UNAVAILABLE)
        self.assertIn("negative", pe["reason"])


class MissingIsNeverZero(unittest.TestCase):

    def test_an_absent_input_is_unavailable_with_a_reason_not_a_zero(self):
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=1e9)])
        r = dv.validate_ticker(db, "AAPL", price=100.0)["metrics"]["interest_coverage"]
        self.assertEqual(r["verdict"], dv.UNAVAILABLE)
        self.assertIsNone(r["value"])
        self.assertTrue(r["reason"])

    def test_no_price_withholds_every_price_based_metric_and_says_why(self):
        db = make_db()
        store(db, "AAPL", [healthy_year("2024-12-31", "2025-02-01")])
        out = dv.validate_ticker(db, "AAPL", price=None)
        for name in ("market_cap", "pe_ratio", "enterprise_value", "fcf_yield_pct"):
            self.assertEqual(out["metrics"][name]["verdict"], dv.UNAVAILABLE, name)
            self.assertIn("price", out["metrics"][name]["reason"])
        # ...but currency-neutral ratios are unaffected, which is the whole point of separating them
        self.assertEqual(out["metrics"]["gross_margin_pct"]["verdict"], dv.OK)

    def test_a_ticker_with_no_history_says_so_about_the_app_not_the_company(self):
        out = dv.validate_ticker(make_db(), "AAPL", price=100.0)
        self.assertEqual(out["periods"], 0)
        self.assertEqual(out["company_health_coverage_pct"], 0.0)
        self.assertFalse(out["clears_75pct_gate"])
        self.assertIn("not a statement about the company", " ".join(out["notes"]))

    def test_missing_rnd_is_not_treated_as_spending_nothing(self):
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=1e9)])
        r = dv.validate_ticker(db, "AAPL", price=100.0)["metrics"]["rnd_intensity_pct"]
        self.assertEqual(r["verdict"], dv.UNAVAILABLE)
        self.assertIn("NOT the same as spending nothing", r["reason"])


class CurrencyRefusal(unittest.TestCase):

    def _euro(self):
        db = make_db()
        store(db, "ASML", [healthy_year("2024-12-31", "2025-02-01", scale=0.07, currency="EUR")])
        return db

    def test_price_based_metrics_are_withheld_for_a_non_usd_filer(self):
        out = dv.validate_ticker(self._euro(), "ASML", price=900.0)
        self.assertEqual(out["currency"], "EUR")
        for name in ("market_cap", "pe_ratio", "fcf_yield_pct", "ev_to_ebit"):
            self.assertEqual(out["metrics"][name]["verdict"], dv.UNAVAILABLE, name)
            self.assertIn("EUR", out["metrics"][name]["reason"])

    def test_currency_neutral_ratios_still_work_for_a_non_usd_filer(self):
        """Margins divide euros by euros. Withholding them too would be over-correction, and
        would leave ASML with no Company Health score at all for no reason."""
        out = dv.validate_ticker(self._euro(), "ASML", price=900.0)
        for name in ("gross_margin_pct", "operating_margin_pct", "roic_pct", "roe_pct"):
            self.assertEqual(out["metrics"][name]["verdict"], dv.OK, name)

    def test_the_reason_names_the_currency_rather_than_saying_unsupported(self):
        note = " ".join(dv.validate_ticker(self._euro(), "ASML", price=900.0)["notes"])
        self.assertIn("EUR", note)
        self.assertIn("guessed rate", note)


class CoverageArithmetic(unittest.TestCase):
    """Coverage is measured against the v3 spec's OWN weights, because its Gate 4 is expressed
    in them. Counting non-null fields instead would answer a question nobody asked."""

    def test_the_category_weights_match_the_spec_and_sum_to_one_hundred(self):
        self.assertEqual(sum(w for w, _ in dv.COMPANY_HEALTH_CATEGORIES.values()), 100)
        self.assertEqual(dv.COMPANY_HEALTH_CATEGORIES["profitability_returns"][0], 25)
        self.assertEqual(dv.COMPANY_HEALTH_CATEGORIES["growth_durability"][0], 20)
        self.assertEqual(dv.COMPANY_HEALTH_CATEGORIES["cashflow_quality"][0], 15)
        self.assertEqual(dv.COMPANY_HEALTH_CATEGORIES["balance_sheet"][0], 15)
        self.assertEqual(dv.COMPANY_HEALTH_CATEGORIES["moat_evidence"][0], 15)
        self.assertEqual(dv.COMPANY_HEALTH_CATEGORIES["capital_allocation"][0], 10)

    def test_the_moat_category_is_named_as_evidence_not_as_a_measured_moat(self):
        """Nick's instruction: do not claim the system measures an economic moat."""
        self.assertIn("moat_evidence", dv.COMPANY_HEALTH_CATEGORIES)
        self.assertNotIn("moat", [k for k in dv.COMPANY_HEALTH_CATEGORIES if k == "moat"])

    def test_a_company_with_nothing_but_revenue_falls_far_below_the_gate(self):
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=1e9)])
        out = dv.validate_ticker(db, "AAPL", price=100.0)
        self.assertLess(out["company_health_coverage_pct"], 75.0)
        self.assertFalse(out["clears_75pct_gate"])

    def test_a_fully_reported_company_clears_the_gate(self):
        db = make_db()
        store(db, "AAPL", [healthy_year(f"{y}-12-31", f"{y + 1}-02-01", scale=1 - (2024 - y) * 0.08)
                           for y in range(2019, 2025)])
        out = dv.validate_ticker(db, "AAPL", price=230.0)
        self.assertGreaterEqual(out["company_health_coverage_pct"], 75.0)
        self.assertTrue(out["clears_75pct_gate"])
        self.assertEqual(out["implausible"], [])

    def test_the_missing_list_names_the_specific_inputs(self):
        """"62% covered" is not actionable. Which input is missing, is."""
        db = make_db()
        store(db, "AAPL", [period("2024-12-31", "2025-02-01", revenue=1e9)])
        cats = dv.validate_ticker(db, "AAPL", price=100.0)["company_health_categories"]
        self.assertIn("roic_pct", cats["profitability_returns"]["missing"])
        self.assertIn("interest_coverage", cats["balance_sheet"]["missing"])

    def test_the_growth_adjusted_pe_is_computed_rather_than_left_blank(self):
        """Derivable from two figures already on the page, so leaving it empty would be laziness
        dressed as caution."""
        db = make_db()
        store(db, "AAPL", [healthy_year(f"{y}-12-31", f"{y + 1}-02-01",
                                        scale=1 - (2024 - y) * 0.08) for y in range(2019, 2025)])
        peg = dv.validate_ticker(db, "AAPL", price=230.0)["metrics"]["growth_adjusted_pe"]
        self.assertEqual(peg["verdict"], dv.OK)
        self.assertGreater(peg["value"], 0)

    def test_intrinsic_value_is_declared_unbuilt_rather_than_silently_absent(self):
        """It is the most authoritative-looking number available and the most arbitrary. Saying
        so in the reason is the difference between a known gap and a forgotten one."""
        db = make_db()
        store(db, "AAPL", [healthy_year("2024-12-31", "2025-02-01")])
        r = dv.validate_ticker(db, "AAPL", price=230.0)["metrics"]["intrinsic_value"]
        self.assertEqual(r["verdict"], dv.UNAVAILABLE)
        self.assertIn("assumption-driven", r["reason"])

    def test_forward_estimates_are_reported_as_a_data_gap_not_an_app_gap(self):
        db = make_db()
        store(db, "AAPL", [healthy_year("2024-12-31", "2025-02-01")])
        r = dv.validate_ticker(db, "AAPL", price=230.0)["metrics"]["forward_pe_vs_history"]
        self.assertIn("estimates", r["reason"])
        self.assertIn("No source this app reads", r["reason"])

    def test_forward_looking_valuation_stays_unavailable_because_no_source_carries_it(self):
        """Forward P/E needs analyst estimates. Nothing this app reads has them, and the coverage
        figure must reflect that rather than quietly excluding the component."""
        db = make_db()
        store(db, "AAPL", [healthy_year("2024-12-31", "2025-02-01")])
        out = dv.validate_ticker(db, "AAPL", price=230.0)
        self.assertIn("forward_pe_vs_history", out["valuation_unavailable"])
        self.assertIn("forward_pe_vs_peers", out["valuation_unavailable"])
        self.assertLess(out["valuation_coverage_pct"], 100.0)


class GrowthMaths(unittest.TestCase):

    def test_a_cagr_from_a_negative_base_is_refused_rather_than_invented(self):
        """((now/then) ** (1/n)) is not a real number when `then` is negative. Producing one
        anyway is how a nonsense growth rate ends up on a page looking authoritative."""
        self.assertIsNone(dv._cagr(100.0, -50.0, 5))
        self.assertIsNone(dv._cagr(-100.0, 50.0, 5))

    def test_a_known_cagr_is_computed_correctly(self):
        self.assertAlmostEqual(dv._cagr(200.0, 100.0, 5), 14.8698, places=3)

    def test_consistency_needs_at_least_three_periods(self):
        self.assertIsNone(dv._consistency([100, 90]))
        self.assertEqual(dv._consistency([120, 110, 100]), 100.0)     # newest-first, always up
        self.assertEqual(dv._consistency([100, 110, 100]), 50.0)

    def test_stability_rewards_a_steady_margin_over_a_swinging_one(self):
        steady = dv._stability([70.0, 70.5, 69.8, 70.2])
        swinging = dv._stability([70.0, 20.0, 55.0, 5.0])
        self.assertGreater(steady, swinging)
        self.assertLessEqual(steady, 100.0)


class Summary(unittest.TestCase):

    def test_any_implausible_metric_anywhere_blocks_the_ready_verdict(self):
        """One impossible number is a bug in the app. Build C must not start on top of it, no
        matter how good the coverage percentages look."""
        good = {"ticker": "A", "clears_75pct_gate": True, "periods": 3, "currency": "USD",
                "company_health_coverage_pct": 90, "valuation_coverage_pct": 60,
                "implausible": [], "company_health_categories": {}}
        bad = dict(good, ticker="B", implausible=["gross_margin_pct"])
        self.assertTrue(dv.summarise([good] * 9 + [good]).get("verdict").startswith("READY"))
        self.assertTrue(dv.summarise([good] * 9 + [bad]).get("verdict").startswith("NOT READY"))

    def test_thin_coverage_across_the_universe_also_blocks_it(self):
        thin = {"ticker": "A", "clears_75pct_gate": False, "periods": 1, "currency": "USD",
                "company_health_coverage_pct": 40, "valuation_coverage_pct": 10,
                "implausible": [], "company_health_categories": {}}
        self.assertTrue(dv.summarise([thin] * 10).get("verdict").startswith("NOT READY"))

    def test_the_summary_ranks_what_is_missing_so_the_biggest_fix_is_visible(self):
        r = {"ticker": "A", "clears_75pct_gate": False, "periods": 2, "currency": "USD",
             "company_health_coverage_pct": 50, "valuation_coverage_pct": 20, "implausible": [],
             "company_health_categories": {
                 "balance_sheet": {"weight": 15, "inputs": 3, "available": 1, "coverage_pct": 33,
                                   "missing": ["interest_coverage", "net_debt_to_ebitda"]}}}
        out = dv.summarise([r, r, r])
        top = dict(out["most_commonly_missing_inputs"])
        self.assertEqual(top["interest_coverage"], 3)


class NoTradingOrStopLoss(unittest.TestCase):
    """The standing structural guard, extended to everything B2 adds."""

    FILES = ("services/data_validation_service.py", "routers/api_validation.py",
             "../frontend/static/js/data_validation.js",
             "../frontend/templates/data_validation.html")

    def test_nothing_here_trades_shorts_or_computes_a_stop(self):
        root = Path(__file__).resolve().parent.parent
        for rel in self.FILES:
            text = (root / rel).read_text().lower()
            for banned in ("stop_loss", "stop loss", "stoploss", "submit_order", "place_order",
                           "short_sell", "websocket"):
                if banned == "stop loss" and "no stop loss" in text:
                    continue      # the base template's standing disclaimer, which must stay
                self.assertNotIn(banned, text, f"{banned} appeared in {rel}")


if __name__ == "__main__":
    unittest.main()


class NarrowReadsOfAWideResult(unittest.TestCase):
    """The three compact endpoints, and why they exist.

    The full run payload is fifty companies times about thirty metrics. The first attempt to read
    one over HTTP came back with the ticker COUNT rendered as a ticker LIST, a company plainly
    reporting in kroner missing from the non-USD list, and a verdict string that this code cannot
    produce. Every number in it looked reasonable, which is the point: a large document read
    imprecisely does not fail loudly, it paraphrases.

    These tests pin the shape of the small documents that replaced that read.
    """

    def _app(self):
        import os, tempfile
        os.environ["DATABASE_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
        from app import create_app
        return create_app().test_client()

    def _seed(self, client, payload):
        from db import get_db
        import json as _json
        with client.application.app_context():
            db = get_db()
            db.execute("INSERT INTO data_validation_runs (results_json, status) "
                       "VALUES (?, 'complete')", (_json.dumps(payload),))
            db.commit()
            row = db.execute("SELECT MAX(id) AS id FROM data_validation_runs").fetchone()
            return int(dict(row)["id"])

    PAYLOAD = {
        "summary": {"tickers": 50, "clearing_the_75pct_gate": 42, "verdict": "NOT READY — x"},
        "results": [
            {"ticker": "AAPL", "periods": 6, "currency": "USD", "price": 230.0,
             "company_health_coverage_pct": 100.0, "clears_75pct_gate": True,
             "valuation_coverage_pct": 42.9, "implausible": [],
             "metrics": {"market_cap": {"value": 3.4e12, "verdict": "OK", "reason": None}}},
            {"ticker": "CMG", "periods": 5, "currency": "USD", "price": 55.0,
             "company_health_coverage_pct": 88.0, "clears_75pct_gate": True,
             "valuation_coverage_pct": 30.0, "implausible": ["pe_ratio"],
             "metrics": {"market_cap": {"value": 7.4e10, "verdict": "OK", "reason": None},
                         "pe_ratio": {"value": 900.0, "verdict": "IMPLAUSIBLE",
                                      "reason": "outside the plausible range"}}},
        ],
    }

    def test_the_summary_endpoint_returns_the_summary_verbatim_and_nothing_else(self):
        c = self._app()
        rid = self._seed(c, self.PAYLOAD)
        body = c.get(f"/api/data-validation/runs/{rid}/summary").get_json()
        self.assertEqual(body, self.PAYLOAD["summary"])
        self.assertNotIn("results", body)

    def test_the_flags_endpoint_quotes_the_actual_impossible_value(self):
        """A flagged metric that is only counted is a bug nobody fixes. The number has to travel."""
        c = self._app()
        rid = self._seed(c, self.PAYLOAD)
        body = c.get(f"/api/data-validation/runs/{rid}/flags").get_json()
        self.assertEqual(body["count"], 1)
        self.assertEqual(body["flagged"][0]["ticker"], "CMG")
        self.assertEqual(body["flagged"][0]["metric"], "pe_ratio")
        self.assertEqual(body["flagged"][0]["value"], 900.0)
        self.assertEqual(body["flagged"][0]["price"], 55.0)

    def test_the_table_endpoint_is_one_short_line_per_company(self):
        c = self._app()
        rid = self._seed(c, self.PAYLOAD)
        body = c.get(f"/api/data-validation/runs/{rid}/table").get_json()
        self.assertEqual(body["count"], 2)
        self.assertEqual(set(body["rows"][0]), {"t", "yrs", "cur", "health", "gate", "val",
                                                "cap_bn", "bad"})

    def test_the_table_is_sorted_worst_coverage_first(self):
        """The rows worth reading are the ones failing, so they must not be at the bottom of a
        fifty-row list."""
        c = self._app()
        rid = self._seed(c, self.PAYLOAD)
        rows = c.get(f"/api/data-validation/runs/{rid}/table").get_json()["rows"]
        self.assertEqual([r["t"] for r in rows], ["CMG", "AAPL"])

    def test_an_unknown_run_is_a_404_not_an_empty_success(self):
        c = self._app()
        for suffix in ("summary", "flags", "table"):
            self.assertEqual(c.get(f"/api/data-validation/runs/9999/{suffix}").status_code, 404)
